# Destina

## Branches Pipeline Status and Code Coverage
### Master
[![pipeline status](https://dhgitlab.dunnhumby.co.uk/CMP/destina/badges/master/pipeline.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/destina/commits/master)

[![coverage report](https://dhgitlab.dunnhumby.co.uk/CMP/destina/badges/master/coverage.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/destina/commits/master)

### Develop
[![pipeline status](https://dhgitlab.dunnhumby.co.uk/CMP/destina/badges/develop/pipeline.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/destina/commits/develop)

[![coverage report](https://dhgitlab.dunnhumby.co.uk/CMP/destina/badges/develop/coverage.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/destina/commits/develop)

#### SBT Dependencies
```
resolvers += "Artifactory Realm" at "https://artifactory.dunnhumby.com/artifactory/libs-release-local/"
libraryDependencies += "com.dunnhumby" %% "destina" % "<Version>"
```