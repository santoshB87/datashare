package com.dunnhumby.destina

import scala.collection.JavaConverters._

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.log4j.Logger
import org.apache.spark.sql.{functions => F, _}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, lit, row_number, when}
import org.apache.spark.sql.types.{StructField, TimestampType}

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.destina.configuration.DestinaGlobalConfiguration

/** Companion Object for Rules Bank
  * The Rules Bank comprises all the allocation rules.
  * These rules are used to calculate recommendations for customers.
  *
  * @param sparkSession Spark Session Object
  * @param destinaGlobalConfiguration DestinaGlobalConfiguration
  */
class RulesBank(sparkSession: SparkSession, destinaGlobalConfiguration: DestinaGlobalConfiguration) {

  // scalastyle:off scaladoc
  val logger: Logger = Logger.getRootLogger
  val sqlContext: SQLContext = sparkSession.sqlContext
  // scalastyle:on scaladoc

  /**
    * This method is used to associate store level hierarchy  with the promotions.
    * It is required when some market asks for the banner/storeregion level recommendations.
    *
    * @param storeDF: Store DF
    * @param promoDF: Promotions DF
    * @param config Input config
    * {{{
    *   {
    *     allocationLevel: "",
    *     joinKey: ""
    *   }
    * }}}
    * allocationLevel: Store level hierarchy on which recommendation needs to be served
    * joinKey: Join Keys List
    * @return Allocation Level added DF
    */
  def getAllocationLevel(storeDF: DataFrame, promoDF: DataFrame, config: Config): List[DataFrame] = {

    val promotionColumnName = destinaGlobalConfiguration.promotionColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName

    val allocationLevel = config.getString("allocationLevel")
    val joinKey = config.getStringList("joinKey").asScala.toList

    val promoWithLevelDF = if (allocationLevel.nonEmpty && !promoDF.columns.contains(allocationLevel)) {
      promoDF.join(storeDF, joinKey).select(promoDF.col("*"), storeDF.col(allocationLevel))
    }
    else promoDF

    val promoWC = List(productColumnName, promotionColumnName, allocationLevelColumnName).filter(_.nonEmpty)

    List(promoWithLevelDF.dropDuplicates(promoWC))
  }

  /**
    * This function aims to associate each relevant product for a customer with all
    * the store hierarchy under which the customer has bought the product (atleast n times) in last n weeks.
    *
    * @param scoreDF: Score DF
    * @param featureDF: Feature DF
    * @param config Input config
    * {{{
    *   {
    *     filterCondition: "",
    *     joinKey: ""
    *   }
    * }}}
    * filterCondition: "banner_baskets_1w26w > 0"
    * joinKey: Join Keys List
    * @return Allocation level for Non RP
    */
  def getAllocationLevelForNonRP(scoreDF: DataFrame, featureDF: DataFrame, config: Config): List[DataFrame] = {

    val filterCondition = config.getString("filterCondition")
    val joinKey = config.getStringList("joinKey").asScala.toList

    val joinDF = featureDF.join(scoreDF, joinKey).filter(filterCondition)
    List(joinDF)
  }

  /** Get Entities namely - store, customer, product
    * Logic - Read promo_df with promotions data from a given hive db/table, keeping only promotions that are
    * active today and for the next N days.
    *
    * @param config Read Config -
    * {{{
    *   {
    *      "type":"table.hive",
    *      "option":{
    *         "path":"databaseName.tableName",
    *         "columnList":["a", "b", "c"]  // List of columns to read
    *      },
    *      "parameter":{
    *         "keepInactivePromos":false,
    *         "promoActiveDays":7,
    *         "activeDaysOffset":0
    *      }
    *   }
    * }}}
    * @return DataFrame according to config
    */
  def getPromos(config: Config): List[DataFrame] = {
    val parameterConfig = config.getConfig("parameter")
    val keepInactivePromosFlag = parameterConfig.hasPath("keepInactivePromos") &&
      parameterConfig.getBoolean("keepInactivePromos")
    val startDateColumnName = destinaGlobalConfiguration.promotionStartDateColumnName
    val endDateColumnName = destinaGlobalConfiguration.promotionEndDateColumnName
    // TODO check this Cache action

    val readDF = DataFrameReadWriteFormat(config).readDataFrame(sqlContext)

    // If keepInactivePromosFlag is true then it will simply return the promo df otherwise it will filter to include
    // the active promos
    val filteredPromoDF = if (!keepInactivePromosFlag) {
      val promoActiveDays = parameterConfig.getInt("promoActiveDays")
      val activeDaysOffset = parameterConfig.getInt("activeDaysOffset")
      val checkStartDateFilterConditionColumn = F.date_add(F.current_date(), activeDaysOffset).cast(TimestampType)
      val checkEndDateFilterConditionColumn = F.date_add(F.current_date(), promoActiveDays).cast(TimestampType)

      // TODO for Meijer end date >= checkEndDateFilterConditionColumn but for other clients it is
      // end date > checkEndDateFilterConditionColumn. Take from config
      val filteredReadDF = readDF
        .where(col(startDateColumnName) <= checkStartDateFilterConditionColumn
        && col(endDateColumnName) >= checkEndDateFilterConditionColumn)
      filteredReadDF
    } else {
      readDF
    }

    val castedFilteredPromoDF = filteredPromoDF
      .withColumn(startDateColumnName, col(startDateColumnName).cast(TimestampType))
      .withColumn(endDateColumnName, col(endDateColumnName).cast(TimestampType))

    List(castedFilteredPromoDF)
  }

  /**
    * This function is used to apply the exclusion/inclusion based on product hierarchy
    * It filters out/in the recommendations if the product hierarchy value is in the exclusion/inclusion list
    *
    * @param inputDF: Input DF
    * @param config Read Config:-
    * {{{
    *   {
    *    exclusionRulesList: [
    *      {
    *        "col": "Introstoreshelf",
    *        "values": ["F", "B", "G", "N"],
    *        "condition": "=",
    *        "substring_length": "1"
    *      },
    *      {
    *        "col": "Discount",
    *        "values": [3],
    *        "condition": ">",
    *        "substring_length": ""
    *      }
    *    ]
    *   }
    * }}}
    * @return DataFrame with exclusion filtered
    */
  def applyExclusion(inputDF: DataFrame, config: Config): List[DataFrame] = {

    val exclusionRulesConfigList = config.getConfigList("exclusionRulesList").asScala.toList

    val queryList = exclusionRulesConfigList.map{exclRuleConfig =>
      val colName = exclRuleConfig.getString("col")
      val operator = exclRuleConfig.getString("condition")
      val value = exclRuleConfig.getStringList("values").asScala
      val substringLength = exclRuleConfig.getString("substring_length")
      val compare_column = if (!substringLength.isEmpty) {
        s"SUBSTRING($colName, 1, $substringLength)"
      }
      else {
        s"$colName"
      }
      val (final_operator, compValue) = if (value.length > 1 || (value.length == 1 && substringLength.nonEmpty)) {
        operator match {
          case "=" | "==" => ("in", value.mkString( """('""", """','""", """')"""))
          case "!=" => ("not in", value.mkString( """('""", """','""", """')"""))
        }
      }
      else {
        (operator, value.mkString("'", "','", "'"))
      }
      compare_column.concat(" " + final_operator + " " + compValue)
    }
//    val filterQuery = queryList.map { filterString =>
//      new Column(parseExpression(filterString))
//    }.reduce(_ and _)

    // println(queryList.mkString("", " and ", ""))

    val filteredDF = inputDF.where(queryList.mkString("", " and ", ""))
    List(filteredDF)
  }

  /**
    * Given the rank of each recommendation for a customer, randomise the order
    * of recommendations after startPosition(inclusive) for each customer.
    *
    * @param df: DataFrame for which randomisation needs to be applied
    * @param config Read Config:-
    * rankingColumn: Column holding the rank of recommendation
    * startPosition: Rank after which(inclusive) the randomness is applied
    * @return DataFrame with randomness over recommendations applied
    */
  def randomShuffle(df: DataFrame, config: Config): List[DataFrame] = {

    val rankingColumn = config.getString("rankingColumn")
    val startPosition = config.getString("startPosition")

    val customerKey = destinaGlobalConfiguration.customerColumnName
    val randomShuffleCol = "randomShuffle"

    val ws = Window.partitionBy(customerKey).orderBy(F.col(randomShuffleCol).asc)

    val shuffledDF = df.withColumn(randomShuffleCol,
      F.when(F.col(rankingColumn) < startPosition, F.col(rankingColumn)).otherwise(F.rand(123) + startPosition))

    val rankedDF = shuffledDF.withColumn(rankingColumn, F.row_number().over(ws)).drop(randomShuffleCol)
    List(rankedDF)
  }

  /** Generic Store Ranging
    * Ranging limits the recommendations served to a customer to it's preferred store-hierarchy(store/banner) only.
    * </br>
    * For R.P : It will restrict promotions served to a customer that are available on his preferred store-hierarchy
    * </br>
    * For Non-R.P : It will recommend product to a customer under store-hierarchy in which he has bought the product or
    *               the product has been sold to anyone under his preferred range-hierarchy.
    *
    * Here the customer could have more than one preferred store-hierarchy and the hierarchies are there in priority
    * order such that the promotion available on most preferred hierarchy should be recommended.
    *
    * Ranging(i.e. Recommendation on Customer's Preferred Range-hierarchy) could be applied by following multiple ways:
    * <ul>
    * <li> Type1 : Include the promotion/product for a customer under his preferred store/banner,
    *      if the customer itself has bought that product from his preferred store/banner. </li>
    * <li> Type2 :Include the promotion/product for a customer under his preferred store/banner,
    *      if product has been sold to anyone under that preferred store/banner. </li>
    * <li> Type3 :Include the promotion/product for a customer under his preferred store/banner,
    *      irrespective of product transaction on rangeHierarchy.
    *      Note : Only For RP(no need of feature)</li>
    * </ul>
//    *
    * Logic -
    * <ol>
    * <li> Explode the customer's preferred hierarchies and rank them. </li>
    * <li> If featureDF is present, then join it with the allocation df
    *      based on columns present in feature, e.g:
    *      for feature product_all_store_all: join key => product
    *      for feature product_customer_store_all: join key => (customer, product)
    * </li>
    * <li> Join the df and exploded df using customer and range hierarchy. </li>
    * <li> Group By Customer, Product and Allocation Level and filter in the recommendations with minimum rank. </li>
    * </ol>
    *
    * @param allocationInputDF: Recommendation(RP or Non-RP) DataFrame per allocation level
    * @param explodedDF: Exploded Customer's Preferred Store DF,
    *                  eg : If a Customer has 3 Preferred Stores, then this exploded dataframe will be input as follows:
    *                       Customer  Store   Rank
    *                       C1        S1      2
    *                       C1        S2      1
    *                       C1        S3      3
    * @param featureDFOption: Feature DataFrame(mandatory for Non RP, optional for RP).
    *                         For RP/Non-RP-Type1 Ranging input feature should be
    *                         : product_customer_store/banner_all_1wXw
    *                         For RP/Non-RP-Type2 Ranging input feature should be : product_all_store/banner_all_1wXw
    *                         For For RP Only-Type3 Features will be absent

    * @param config Store Ranging Config:-
    * {{{
    *   {
    *       "propositionType": "non-rp",
    *       "rangeRankOutputColumnName": "rangeRank"(this should be in the exploded DF),
    *       "hierarchy": "Store"
    *   }
    * }}}
    * @return Store Ranging applied DataFrame
    */
  def applyRanging(allocationInputDF: DataFrame, explodedDF: DataFrame, featureDFOption: Option[DataFrame],
                   config: Config): List[DataFrame] = {

    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName

    val rangeHierarchy = config.getString("hierarchy")
    val rangeRankOutputColumnName = config.getString("rangeRankOutputColumnName")

    val propositionType = config.getString("propositionType") // RP or HYF/Usuals

    val df = featureDFOption match {
      case Some(featureDF) =>
        // feature containing customer column represents customer-prod-hierarchy level features
        val customerRanging = featureDF.columns.contains(customerColumnName)

        val (joinKeys, keepColumns) = propositionType.toLowerCase match {
          case "rp" if customerRanging =>
            (List(customerColumnName, productColumnName, rangeHierarchy), Nil)
          case "rp" =>
            (List(productColumnName, rangeHierarchy), Nil)
          case "non-rp" if customerRanging =>
            (List(customerColumnName, productColumnName), List(rangeHierarchy))
          case "non-rp" =>
            (List(productColumnName), List(rangeHierarchy))
          case _ =>
            throw new IllegalArgumentException(s"${getClass.getName} does not support ranging type - $propositionType")
        }

        // println(s"joinkeys => $joinKeys")
        val joinConfig = ConfigFactory.parseString(s"""
        {
          "joinColumnList": ${joinKeys.asJava},
          "columns": ${keepColumns.asJava}
        }""")

        joinDataFrame(allocationInputDF, featureDF, joinConfig).head

      case None => allocationInputDF
    }

    val joinConfig = ConfigFactory.parseString(s"""
        {
          "joinColumnList": [$customerColumnName, $rangeHierarchy],
          "columns": [$rangeRankOutputColumnName]
        }""".stripMargin)
    val joinedDF = joinDataFrame(df, explodedDF, joinConfig).head

    val groupByColumns = List(customerColumnName, productColumnName, allocationLevelColumnName)
      .filter(_.nonEmpty).asJava

    val generatePosConfig = ConfigFactory.parseString(
      s"""{
         | partitionByCol: $groupByColumns,
         | rankColName: "minRank",
         | orderByCol: [
         |  {
         |     "colName": $rangeRankOutputColumnName,
         |     "sortOrder": "asc"
         |   }
         | ]
         |}""".stripMargin)

    val singleBestStoreDF = generatePosition(joinedDF, generatePosConfig).head
      .where("minRank == 1").drop("minRank").drop(rangeRankOutputColumnName)

    List(singleBestStoreDF)
  }

  /** Implement Special Category Limit
    *
    * If required, ensure we only make up to N special products recommendation per customer, controlled by
    * specialCategoryConfig.
    *
    * @param inputDF: Input DataFrame
    * @param config Special Category Config
    * {{{
    *   {
    *      "rankingColumnName":"score",
    *      "productIdentifierColumnName":"product",
    *      "isCustomerRequired":true, // if customer key is required or not
    *      "substringLength" : N, // Optional if provided then match the column substring otherwise full match
    *      "productIdentifiers":["W"],
    *      "recommendedValue":1
    *   }
    * }}}
    * keys are:
    * `productIdentifierColumnName`: column to match first N characters against list of chars to identify products
    * `productIdentifiers`: list of characters used to identify special category products
    * `recommendedValue`: maximum number of special product recommendations per customer
    * @return Special category limit applied DataFrame
    */
  def applySpecialCategoryCapping(inputDF: DataFrame, config: Config): List[DataFrame] = {

    val productIdentifierColumnName = config.getString("productIdentifierColumnName")
    val productIdentifierStringList = config.getStringList("productIdentifiers").asScala.toList
    val customerRequired = config.getBoolean("isCustomerRequired")

    val modifiedProductIdentifierColumnName = if (config.hasPath("substringLength")) {
      val substringLength = config.getInt("substringLength")
      col(productIdentifierColumnName).substr(1, substringLength)
    } else {
      col(productIdentifierColumnName)
    }

    val recommendedValue = config.getInt("recommendedValue")
    val specialCategoryFlaggedDF = inputDF.withColumn("specialCategoryFlag",
      when(modifiedProductIdentifierColumnName.isin(productIdentifierStringList: _*),
        1).otherwise(0))

    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val allocationLevel = destinaGlobalConfiguration.allocationLevelColumnName
    val scoreType = destinaGlobalConfiguration.scoreTypeColumnName
    val scoreColumnName = destinaGlobalConfiguration.scoreColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName

    val partitionColumnList = if (customerRequired) {
      List(customerColumnName, "specialCategoryFlag", allocationLevel).filter(_.nonEmpty)
    } else {
      List("specialCategoryFlag", allocationLevel).filter(_.nonEmpty)
    }

    val ws = Window.partitionBy(partitionColumnList.head, partitionColumnList.tail: _*)
      .orderBy(col(scoreType).asc, col(scoreColumnName).desc, col(productColumnName).desc)

    logger.info(
      s"Keep the top $recommendedValue special category recommendation with the highest $scoreColumnName"
    )

    val specialCategoryLimitDF = specialCategoryFlaggedDF.withColumn("rankSpecial", row_number().over(ws))
      .where((col("specialCategoryFlag") === 0) ||
        (col("specialCategoryFlag") === 1 && col("rankSpecial") <= recommendedValue))
      .drop("specialCategoryFlag").drop("rankSpecial")

    List(specialCategoryLimitDF)
  }

  /** Apply Required Diversity
    *
    * Apply required diversity rules on inputDF based on requiredDiversityRules, which should be a list
    * of configs indicating column and diversity count, eg:
    *
    * @param inputDF: Input DataFrame
    * @param config Diversity Rules Config
    * {{{
    *   {
    *     "isCustomerRequired":true,
    *     "diversityRules":[
    *        {
    *           "diversityColumn":"Promotion",
    *           "diversityCount":2
    *        },
    *        {
    *           "diversityColumn":"Group",
    *           "diversityCount":1
    *        }
    *     ]
    *   }
    * }}}
    *
    * Also for making customer optional - set `isCustomerRequired` to true
    *
    * For each column in the list:
    * rank inputDF by descending scoreColumn, partitioned by customerKey and column specified, and keep only the top N
    * ranked Promotion in each partition.
    *
    * So, in the example above, top 1 ranked promotion per product_subgroup_1 and top two ranked promotion per
    * product_subgroup_2.
    * @return DataFrame with diversity
    */
  def applyRequiredDiversity(inputDF: DataFrame, config: Config): List[DataFrame] = {

    val diversityRulesConfigList = config.getConfigList("diversityRules").asScala.toList
    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val allocationLevel = destinaGlobalConfiguration.allocationLevelColumnName
    val scoreColumnName = destinaGlobalConfiguration.scoreColumnName
    val scoreTypeColumnName = destinaGlobalConfiguration.scoreTypeColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val rangeHierarchyColumnName = destinaGlobalConfiguration.rangeHierarchyColumnName

    val isCustomerRequired = config.getBoolean("isCustomerRequired")

    val diversityRulesAppliedDF = diversityRulesConfigList.foldLeft(inputDF) { (df, diversityConfig) =>
      val diversityColumn = diversityConfig.getString("diversityColumn")
      val diversityCount = diversityConfig.getInt("diversityCount")
      val orderByColumns = List(F.col(scoreTypeColumnName).asc, F.col(scoreColumnName).desc,
        col(productColumnName).desc)
      val partitionColumnList = if (isCustomerRequired) {
        List(customerColumnName, diversityColumn, allocationLevel).filter(_.nonEmpty)
      } else {
        // Range Hierarchy is used so as to maintain the flow for popular promotions everything will
        // be done on range hierarchy.
        List(diversityColumn, allocationLevel, rangeHierarchyColumnName).filter(_.nonEmpty).distinct
      }
      val ws = Window.partitionBy(partitionColumnList.head, partitionColumnList.tail: _*)
        .orderBy(orderByColumns: _*)

      val inputDFWithRank = df.withColumn("rankColumn", F.row_number().over(ws))

      inputDFWithRank.filter(F.col("rankColumn") <= diversityCount).drop("rankColumn")
    }
    List(diversityRulesAppliedDF)
  }

  /** Sensitivity is based on customer's purchase behaviour of sensitive products in the recent weeks.
    * It works as there are certain product/product-hierarchies that are considered sensitive as per market
    * and they shall only be recommended if the customer has bought the product/product-hierarchy in last
    * N weeks.
    *
    * It uses the features data to check the customer product transaction for the given interval.
    * @param allocationDF: allocation DataFrame
    * @param config sensitivity execution config :-
    * {{{
    *   {
    *       "isPetGroup":{
    *          "feature":{
    *             "input":{
    *                "type":"table.hive",
    *                "option":{
    *                   "path":"f1",
    *                   "columnNames":["customer", "product", "baskets_1w4w"]
    *                },
    *                "rename":{
    *                   "product":"product_subgroup"
    *                }
    *             }
    *          },
    *          "sensitivityLevel":"product_subgroup",
    *          "sensitivityBucketGrain":"baskets_1w4w",
    *          "sensitivityExclusionCriteria":" > 0",
    *          "dimensionFilter":{
    *             "value":["G3"],
    *             "substringLength":2
    *          },
    *          "joinColumn":["customer", "product_subgroup"]
    *     }
    *   }
    * }}}
    * rename: feature product's column to be renamed with the allocation
    * dataframe product/hierarchy on which sensitivity is to be applied.
    * joinColumn: keys on which allocation df and feature df is to be joined
    * @return allocation df with sensitivity applied
    */

  def applySensitivityExclusion(allocationDF: DataFrame, config: Config): List[DataFrame] = {

    val sensitivityRulesList = config.root().keySet().asScala.toList

    val cadenceWeekColumnName = destinaGlobalConfiguration.cadenceWeekColumnName
    val sensitivityAppliedDF = sensitivityRulesList.foldLeft(allocationDF) {
      case (df, rule) =>
        val ruleConfig = config.getConfig(rule)
        val featureInputConfig = ruleConfig.getConfig("feature.input")
        print(featureInputConfig)
        // TODO: the below reader/writer should be injected
        val featureDF = DataFrameReadWriteFormat(featureInputConfig)
          .readDataFrame(sqlContext).drop(cadenceWeekColumnName)

        val dimensionFilterConfig = ruleConfig.getConfig("dimensionFilter")
        val valueList = dimensionFilterConfig.getStringList("value").asScala.toList

        val sensitivityLevel = ruleConfig.getString("sensitivityLevel")
        val sensitivityBucketGrain = ruleConfig.getString("sensitivityBucketGrain")
        val bucketCheckCondition = ruleConfig.getString("sensitivityExclusionCriteria")
        val joinColumn = ruleConfig.getStringList("joinColumn").asScala.toList

        val sensitiveProdCol = if (dimensionFilterConfig.hasPath("substringLength")) {
          val substringLength = dimensionFilterConfig.getInt("substringLength")

          if (valueList.exists(_.length < substringLength)) {
            throw new IllegalArgumentException(s"${getClass.getName} -" +
              s" Values in value list does not match substring length")
          }
          // println(s"F.col(sensitivityLevel).substr(0, substringLength)
          // => ${F.col(sensitivityLevel).substr(0, substringLength)}")
          F.col(sensitivityLevel).substr(0, substringLength)
        }
        else {
          F.col(sensitivityLevel)
        }

        // fetching only products that are sensitive and are bought minimum required times per customer
        val sensitivityCheckFilteredFeatureDF = featureDF
          .where(sensitiveProdCol.isin(valueList: _*))
          .where(sensitivityBucketGrain + bucketCheckCondition).drop(sensitivityBucketGrain)

        val (sensitiveDF, nonSensitiveDF) = (df.filter(sensitiveProdCol.isin(valueList: _*)),
          df.filter(!sensitiveProdCol.isin(valueList: _*)))

        val joinedDF = sensitiveDF.join(sensitivityCheckFilteredFeatureDF, joinColumn, "inner")

         unionDataFrame(joinedDF, nonSensitiveDF).head

    }
    List(sensitivityAppliedDF)
  }

  /** Infilling from generic DF
    *
    * If rangeHierarchy is present then we join generic products DF with the customer with their preferred
    * hierarchy(store, banner etc) on that specific hierarchy and then grouping them on the basis of
    * infillingType(`Promotion` or `Product`) and keeping the top ranked row on the basis of
    * top most preferred hierarchy.
    *
    * If hierarchy is not applied then simply `cross join` the customer who needs infilling with all
    * the generic products.
    *
    * @param genericDF: Generic Products and Promotions DF
    * @param customerWHoNeedInfillingDF: Customers who need infilling DF with only the Customer ID's
    * @param explodedRangeHierarchyCstDF: Exploded Customer with his/her exploded preferred range hierarchy DF
    * @param config Ranging Config
    * {{{
    *   {
    *     "rangeRankOutputColumnName": "rangeRank",
    *     "infillingType": "promotions"
    *   }
    * }}}
    * @return Sorted Generic DF with promotions or product infilling
    */
  def infilling(genericDF: DataFrame, customerWHoNeedInfillingDF: DataFrame,
                       explodedRangeHierarchyCstDF: DataFrame, config: Config): List[DataFrame] = {

    val rangeHierarchy = destinaGlobalConfiguration.rangeHierarchyColumnName
    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val promotionColumnName = destinaGlobalConfiguration.promotionColumnName
    val scoreTypeColumnName = destinaGlobalConfiguration.scoreTypeColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName

    val infilledDF = if (rangeHierarchy.nonEmpty) {
      val rangeRankColumnName = config.getString("rangeRankOutputColumnName")

      val joinConfig = ConfigFactory.parseString(s"""{
        "joinColumnList": [$customerColumnName],
        "columns": []
      }""")

      val rangeHierarchyAddedDF =
        joinDataFrame(explodedRangeHierarchyCstDF, customerWHoNeedInfillingDF, joinConfig)
          .head

      val infillingConfig = ConfigFactory.parseString(s"""{
        "joinColumnList": [$rangeHierarchy],
        "columns": [$customerColumnName, $rangeRankColumnName]
      }""")

      val infillingDF =
        joinDataFrame(genericDF, rangeHierarchyAddedDF, infillingConfig).head

      // TODO - Below logic can be skipped in case of single preferred store
      val groupByColumns = List(customerColumnName, productColumnName, allocationLevelColumnName)
        .filter(_.nonEmpty).asJava

      val generatePosConfig = ConfigFactory.parseString(
        s"""{
           | partitionByCol: $groupByColumns,
           | rankColName: "minRank",
           | orderByCol: [
           |  {
           |     "colName": $rangeRankColumnName,
           |     "sortOrder": "asc"
           |   }
           | ]
           |}""".stripMargin)

      generatePosition(infillingDF, generatePosConfig).head
        .where("minRank == 1").drop("minRank")
    }
    else {
      // TODO customerWHoNeedInfillingDF will have customer and allocationLevel and inner join with genericDF
      //  on allocationLevel else if customerWHoNeedInfillingDF doesn't have allocationLevel then cross join
      if (allocationLevelColumnName.isEmpty) {
        val onlyGenericPromotions = genericDF.select(promotionColumnName).dropDuplicates()
        val crossJoinDF = customerWHoNeedInfillingDF.crossJoin(onlyGenericPromotions)
        // TODO can we join with generic to get al the details later on after score type filtering.
        crossJoinDF.join(genericDF, List(promotionColumnName), "inner")
          .withColumn(scoreTypeColumnName, F.lit(3))
      }
      else {
        customerWHoNeedInfillingDF.join(genericDF, List(allocationLevelColumnName), "inner")
          .withColumn(scoreTypeColumnName, F.lit(3))
      }
    }
    List(infilledDF)
  }

  /** Infilling from generic DF
    *
    * If rangeHierarchy is present then we join generic products DF with the customer with their preferred
    * hierarchy(store, banner etc) on that specific hierarchy and then grouping them on the basis of
    * infillingType(`Promotion` or `Product`) and keeping the top ranked row on the basis of
    * top most preferred hierarchy.
    *
    * If hierarchy is not applied then simply `cross join` the customer who needs infilling with all
    * the generic products.
    *
    * @param genericDF: Generic Products and Promotions DF
    * @param customerWHoNeedInfillingDF: Customers who need infilling DF with only the Customer ID's
    * @param explodedRangeHierarchyCstDF: Exploded Customer with his/her exploded preferred range hierarchy DF
    * @param config Ranging Config
    * {{{
    *   {
    *     "rangeRankOutputColumnName": "rangeRank",
    *     "infillingType": "promotions"
    *   }
    * }}}
    * @return Sorted Generic DF with promotions or product infilling
    */
  def nonRPInfilling(genericDF: DataFrame, customerWHoNeedInfillingDF: DataFrame,
                explodedRangeHierarchyCstDF: DataFrame, config: Config): List[DataFrame] = {

    val rangeHierarchy = destinaGlobalConfiguration.rangeHierarchyColumnName
    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val scoreTypeColumnName = destinaGlobalConfiguration.scoreTypeColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName

    val infilledDF = if (rangeHierarchy.nonEmpty) {
      val rangeRankColumnName = config.getString("rangeRankOutputColumnName")

      val joinConfig = ConfigFactory.parseString(s"""{
        "joinColumnList": [$customerColumnName],
        "columns": []
      }""")

      val rangeHierarchyAddedDF =
        joinDataFrame(explodedRangeHierarchyCstDF, customerWHoNeedInfillingDF, joinConfig)
          .head

      val infillingConfig = ConfigFactory.parseString(s"""{
        "joinColumnList": [$rangeHierarchy],
        "columns": [$customerColumnName, $rangeRankColumnName]
      }""")

      val infillingDF =
        joinDataFrame(genericDF, rangeHierarchyAddedDF, infillingConfig).head

      val groupByColumns = List(customerColumnName, productColumnName, allocationLevelColumnName)
        .filter(_.nonEmpty).asJava

      val generatePosConfig = ConfigFactory.parseString(
        s"""{
           | partitionByCol: $groupByColumns,
           | rankColName: "minRank",
           | orderByCol: [
           |  {
           |     "colName": $rangeRankColumnName,
           |     "sortOrder": "asc"
           |   }
           | ]
           |}""".stripMargin)

      generatePosition(infillingDF, generatePosConfig).head
        .where("minRank == 1").drop("minRank")
      .withColumn(scoreTypeColumnName, F.lit(3))
    }
    else {
      if (allocationLevelColumnName.isEmpty) {
          customerWHoNeedInfillingDF.crossJoin(F.broadcast(genericDF))
            .withColumn(scoreTypeColumnName, F.lit(3))
      }
      else {
        customerWHoNeedInfillingDF.join(F.broadcast(genericDF), List(allocationLevelColumnName), "inner")
          .withColumn(scoreTypeColumnName, F.lit(3))
      }
    }
    List(infilledDF)
  }

  /**
    * Given the partitionColumns and the order sequence, it calculates the rank within the partitionColumns of DataFrame
    * used to calculate the position of products or customer on the basis of Product Score
    * Example:- Here, the below input config will be used to generate new offerPosition column
    * signifying the position of a product for a customer
    *
    * @param df: DataFrame for which ranks need to be calculated
    * @param config Read Config -
    * {{{
    *   {
    *     partitionByCol: ["customer", "group"],
    *     rankColName: "OfferPosition",
    *     orderByCol: [
    *       {
    *         "colName": "scoreType",
    *         "sortOrder": "asc"
    *       },
    *       {
    *         "colName": "score",
    *         "sortOrder": "desc"
    *       }
    *     ]
    *   }
    * }}}
    *
    *
    * partitionByCol: column names which will make the partition window
    * orderByCol: column names and order type(asc/desc) in sequence,
    * using which data needs to be ordered within a partition
    * rankColName: new column name to be added as rank column
    * @return DataFrame with rank column added
    *
    *         eg: generatePosition(List(inputDF), config)
    *
    */
  def generatePosition(df: DataFrame, config: Config): List[DataFrame] = {

    val partitionByCol = config.getStringList("partitionByCol").asScala.toList
    val rankColName = config.getString("rankColName")
    val orderByColConfig = config.getConfigList("orderByCol").asScala.toList
    val orderByColMap = orderByColConfig.map{ conf =>
      (conf.getString("colName"), conf.getString("sortOrder"))
    }.filter(_._1.nonEmpty)

    val orderBy = orderByColMap.map {
      case (x, y) => y match {
        case sortBy if sortBy.equalsIgnoreCase("desc") => F.col(x).desc_nulls_last
        case _ => F.col(x).asc_nulls_last
      }
    }

    val ws = Window
      .partitionBy(partitionByCol.head, partitionByCol.tail: _*)
      .orderBy(orderBy: _*)

    val rowNumberDF = df.withColumn(rankColName, F.row_number().over(ws))

    List(rowNumberDF)
  }

  /** Add attributed from another DataFrame to the parent DataFrame
    *
    * @param xDF Parent DF
    * @param yDF Attribute DF
    *
    * @param config Read Config -
    * {{{
    *   {
    *     "joinColumnList": [],
    *     "columns": [],
    *     "filterCondition": "",
    *     "joinType": ""
    *   }
    * }}}
    *   joinColumnList List of Columns on which to perform join
    *   columns Columns to be added to the parent DataFrame
    *   filterCondition Filter String :- "X = 'x' AND Y != 'y'"
    *   joinType Join Type - "inner", "outer", "full", "full_outer", "left", "left_outer","right",
    *                         "right_outer", "left_semi", "left_anti"
    * @return DataFrame with added attributes
    */
  def joinDataFrame(xDF: DataFrame, yDF: DataFrame, config: Config): List[DataFrame] = {

    val joinColumnList = config.getStringList("joinColumnList").asScala.toList
    val columns = config.getStringList("columns").asScala.toList

    val joinType = if (config.hasPath("joinType")) {
      config.getString("joinType")
    } else {
      "inner"
    }
    val finalColumnList = (xDF.columns.toList ++ columns).distinct
    val yDFColumns = joinColumnList ++ columns
    val attributeAddedDF = xDF.join(yDF.select(yDFColumns.head, yDFColumns.tail: _*), joinColumnList, joinType)
      .select(finalColumnList.head, finalColumnList.tail: _*)

    val filteredDF = if (config.hasPath("filterCondition") && config.getString("filterCondition").nonEmpty) {
      val filterCondition = config.getString("filterCondition")
      attributeAddedDF.filter(filterCondition)
    } else {
      attributeAddedDF
    }
    List(filteredDF)
  }

  /** Explode Range Hierarchy on the basis of their preferred hierarchy
    *
    * @param customerDF CustomerDF
    * @param config Ranging Config
    * {{{
    *   {
    *     "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
    *     "rangeRankOutputColumnName": "rangeRank",
    *     "hierarchy": "Store"
    *   }
    * }}}
    * @return Exploded Range Hierarchy DF
    */
  def explodeRangeHierarchy(customerDF: DataFrame, config: Config): List[DataFrame] = {

    val customerColumnName = destinaGlobalConfiguration.customerColumnName

    val rangeHierarchy = config.getString("hierarchy")
    val rangeRankOutputColumnName = config.getString("rangeRankOutputColumnName")
    val preferredColumnNamesList = config.getStringList("preferredColumnNames").asScala.toList
    val preferredColumnsList = preferredColumnNamesList.map(F.col)

    val customerSelectColumnsDF = customerDF.select(F.col(customerColumnName) :: preferredColumnsList: _*)
    val mergedLevelDF = customerSelectColumnsDF.withColumn(rangeHierarchy,
      F.concat_ws("|", preferredColumnsList: _*))
      .select(customerColumnName, rangeHierarchy)

    val mergedStoresDFColumnList = List(F.col(customerColumnName), F.posexplode(F.split(F.col(rangeHierarchy), "\\|")))

    val explodedDF = mergedLevelDF.select(mergedStoresDFColumnList: _*)
      .withColumnRenamed("col", rangeHierarchy).withColumnRenamed("pos", rangeRankOutputColumnName)

    List(explodedDF)
  }

  /** Promotion Filtering On ScoreType
    *
    * Ranging then taking the top ranked row based on infillingType and score type from Infilled promotions
    * to customers who needs infilling after combining them with the relevant promotions.
    *
    * InfillingType -
    * Product - Make a window on Customer, Promotion, Product and AllocationLevel, then rank them
    * on the basis of scoreTypeColumn values and then take the rows with rank = 1.
    *
    * Promotion - Make a window on Customer, Promotion and AllocationLevel, then rank them
    * on the basis of scoreTypeColumn values and then take the rows with rank = 1.
    *
    * @param rpDF Relevant Promotions DF
    * @param infilledDF Infilled DF
    * @param customerWHoNeedInfillingDF Customers who need infilling DF with only the Customer ID's
    * @param config Ranging Config
    * {{{
    *   {
    *     "infillingType": "promotion"
    *   }
    * }}}
    * infillingType Infilling Type i.e Product or Promotion
    * @return Infilled DF
    */
  def promotionFilteringOnScoreType(rpDF: DataFrame, infilledDF: DataFrame, customerWHoNeedInfillingDF: DataFrame,
                                    config: Config): List[DataFrame] = {

    val infillingType = config.getString("infillingType")
    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName
    val scoreTypeColumnName = destinaGlobalConfiguration.scoreTypeColumnName
    val promotionColumnName = destinaGlobalConfiguration.promotionColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName

    val joinList = List(customerColumnName, allocationLevelColumnName).filter(_.nonEmpty).asJava
    val joinConfig = ConfigFactory.parseString(s"""{
        "joinColumnList": $joinList,
        "columns": []
      }""")

    val rpDetailsDF = joinDataFrame(rpDF, customerWHoNeedInfillingDF, joinConfig).head
    val infillingDF = unionDataFrame(rpDetailsDF, infilledDF).head

    // remove the possibility of product duplicacy on relevant and infilling
    val windowColumnList = infillingType.toLowerCase match {
      case "promotion" => List(customerColumnName, promotionColumnName, allocationLevelColumnName)
      case "product" => List(customerColumnName, promotionColumnName, productColumnName, allocationLevelColumnName)
      case _ => throw new IllegalArgumentException(s"${getClass.getSimpleName} method promotionFilteringOnScoreType " +
        s"only supports Promotion and Product as InfillingType and got - $infillingType")
    }
    val emptyFilteredWindowList = windowColumnList.filter(_.nonEmpty)
    val ws = Window
      .partitionBy(emptyFilteredWindowList.head, emptyFilteredWindowList.tail: _*)
      .orderBy(col(scoreTypeColumnName).asc)

    // Using `rank` instead of 'row_number' because we need to rank the rows and only take the first
    // group of rows after ordering by scoreTypeColumn
    val infillingFilteredDF = infillingDF.withColumn("rankOnScoreType", F.rank().over(ws))
      .where("rankOnScoreType == 1").drop("rankOnScoreType")

    List(infillingFilteredDF)
  }

  /**
    * This function aims to generate popular promotions by first generating the popular products and then joining them
    * with the current promotions. Popular products could be there already cooked by PPP or can be generated using
    * all_product_all_all_1w_Nw feature.
    * {{{
    *   {
    *    "input":{
    *       "type":"table.hive",
    *       "option":{
    *          "path":"all_product_all_all",
    *          "columnNames":["product", "baskets_1w4w"]
    *       },
    *       "rename":{
    *          "baskets_1w4w" : "score"
    *       }
    *    }
    * }
    * }}}
    *
    * Note: the input feature/scoring dataframe should have a `score` column,
    * like in above case baskets_1w4w is renamed to score
    *
    * @param promoDF promotional dataFrame
    * @param ppDF popular promotional dataFrame
    * @return popular promotion datFrame
    */
  def getPopularPromotions(promoDF: DataFrame, ppDF: DataFrame): List[DataFrame] = {

    val productRank = destinaGlobalConfiguration.productRank
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val cadenceWeekColumnName = destinaGlobalConfiguration.cadenceWeekColumnName

    // this key will be filled based on which level, popular promotion needs to be created
    // will be filled if feature/score are created per allocation level(eg : product_all_banner_all_1w4w)

    val popularPromotionLevel = destinaGlobalConfiguration.popularPromotionLevel
    val score = destinaGlobalConfiguration.scoreColumnName
    val scoreType = destinaGlobalConfiguration.scoreTypeColumnName
    val scorePrecision = destinaGlobalConfiguration.scorePrecision
    // in case of store-hierarchy ranging, the  product ranking will be created at that store-hierarchy level
    // using productColName in window to remove the randomness among ranks, in case products are having same score
    // Allocation level / Range Hierarchy value can't be used instead of  popularPromotionLevel. For eg :- Allocation
    // level can be banner but for infilling, PopularProduct may not be required at any level
    val wc = if (popularPromotionLevel.nonEmpty) {
      Window.partitionBy(popularPromotionLevel).orderBy(F.col(score).desc, F.col(productColumnName))
    } else {
      Window.orderBy(F.col(score).desc, F.col(productColumnName))
    }

    val rankedProducts = ppDF.withColumn(productRank, F.row_number().over(wc))

    val createScoreConfig = ConfigFactory.parseString(
      s"""
        |{
            "rankingColumn": $productRank,
            "outputColumn": $score,
            "roundValue": $scorePrecision,
            "scoreLength": $scorePrecision
          }
      """.stripMargin)

    val scoredProducts = createScore(rankedProducts, createScoreConfig).head
    val joinList = List(popularPromotionLevel, productColumnName).filter(_.nonEmpty).asJava

    val joinConfig = ConfigFactory.parseString(s"""{
        "joinColumnList": $joinList,
        "columns": [$productRank, $score]
      }""")

    // TODO : need to check if we need productRank further
    val joinedDF = joinDataFrame(promoDF, scoredProducts, joinConfig).head
      .drop(cadenceWeekColumnName)
      .drop(productRank)
    List(joinedDF.withColumn(scoreType, F.lit(3)))
  }

  /**
    * Given a rank of a column, it calculates the score for that column by dividing 1 by rank  (1/column)
    * Used for Morphing the product score
    * @param df DataFrame
    * @param config Read Config
    * {{{
    *   {
    *     "rankingColumn": "score",
    *     "outputColumn": "rank",
    *     "roundValue": 8,
    *     "scoreLength": 8
    *   }
    * }}}
    * rankingColumn column which holds tha rank
    * outputColumn new column name holding the scores
    * roundValue value to scale decimal precision
    * scoreLength exact length for the score column
    * @return DataFrame with score column added
    */
  def createScore(df: DataFrame, config: Config): List[DataFrame] = {

    val rankingColumn = config.getString("rankingColumn")
    val outputColumn = config.getString("outputColumn")
    val roundValue = config.getInt("roundValue")
    val scoreLength = config.getInt("scoreLength")

    val scoredDF = df.withColumn(outputColumn,
      F.format_number(F.round(F.lit(1).divide(df(rankingColumn)), roundValue), scoreLength))

    List(scoredDF)
  }

  /** Calculate the promotions rank by first calculating the promotion score(max score among all the product's
    * score of that promotion) and than ranking the promotions based on the calculated Promotion score. <br>
    * Uses:-<br>
    * 1.) Rank the Promotion in the Allocation DataFrame. (isCustomerRequired--> True)<br>
    * 2.) Rank the Promotion in the Generic DataFrame.(Popular Promotion for infilling, isCustomerRequired--> False)
    *
    * @param popularPromotionsDF popular promotion dataFrame
    * @param config Read Config
    * {{{
    *   {
    *     "isCustomerRequired": true,
    *     "relevanceColumnName": "relevance"    //product Score column
    *   }
    * }}}
    * New columns:<br>
    *             [ offerRelevance]  signifying the promotion Score(Max of Product Score)<br>
    *             [promotionRank ]   signifying the promotion rank
    * @return capped popular promotion dataFrame
    */
  def rankPromotions(popularPromotionsDF: DataFrame, config: Config): List[DataFrame] = {

    // TODO
    val promotionColumnName = destinaGlobalConfiguration.promotionColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName
    val rangeHierarchyColumnName = destinaGlobalConfiguration.rangeHierarchyColumnName
    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val promotionRank = destinaGlobalConfiguration.promotionRank
    val offerRelevance = destinaGlobalConfiguration.offerRelevance
    val score = destinaGlobalConfiguration.scoreColumnName
    val relevanceColName = if (config.hasPath("relevanceColumnName")) {
      config.getString("relevanceColumnName")
    }
    else {
      score
    }

    // If both rangeHierarchyColumnName and allocationLevelColumnName are nonEmpty then they should be same.
    val isCustomerRequired = config.getBoolean("isCustomerRequired")

    val partitionCol = if (isCustomerRequired) {
      List(allocationLevelColumnName, promotionColumnName, customerColumnName).filter(_.nonEmpty)
    } else {
      List(allocationLevelColumnName, promotionColumnName, rangeHierarchyColumnName).filter(_.nonEmpty).distinct
    }

    val createOfferRelevanceConfig = ConfigFactory.parseString(
      s"""
        |{
        | "partitionCol": ${partitionCol.asJava},
        | "productRelevance": $relevanceColName,
        | "offerRelevance": $offerRelevance
        |}
      """.stripMargin)
    val relevanceDF = createOfferRelevance(popularPromotionsDF, createOfferRelevanceConfig)
      .head

    val partitionList = if (isCustomerRequired) {
      List(allocationLevelColumnName, customerColumnName).filter(_.nonEmpty)
    } else {
      List(allocationLevelColumnName, rangeHierarchyColumnName).filter(_.nonEmpty).distinct
    }

    val wc = if (partitionList.isEmpty) {
      Window.orderBy(F.col(offerRelevance).desc, F.col(promotionColumnName))
    } else {
      Window.partitionBy(partitionList.head, partitionList.tail: _*)
        .orderBy(F.col(offerRelevance).desc, F.col(promotionColumnName).asc)
    }

    // here below dense_rank is used so that all the products under same promotion get same promotionRank
    val rankedDF = relevanceDF.withColumn(promotionRank, F.dense_rank().over(wc))

    // TODO: need to add creation of genericCstDF also
    List(rankedDF)
  }

  /**
    * Given the offer's partition window and the product relevance column, it calculates the offer relevance
    * by picking the max relevance among all the product relevance in the partition.
    *
    * @param df: DataFrame for which relevance needs to be calculated
    * @param config Read Config
    * {{{
    *   {
    *     "partitionCol": [],
    *     "productRelevance": "",
    *     "offerRelevance": ""
    *   }
    * }}}
    * partitionCol columns grouping together to form a unique offer
    * productRelevance product relevance(Score) column
    * offerRelevance new column to be added as offer relevance
    * @return DataFrame with partition relevance column added
    *         eg:
    *         For RP directly to Customer, Offer = (Customer, Promotion)
    *         For RP under Banner to Customer Offer = (Customer, Banner, Promotion)
    *         For Product on Promotion, Offer = (Promotion)
    */
  def createOfferRelevance(df: DataFrame, config: Config): List[DataFrame] = {

    val partitionCol = config.getStringList("partitionCol").asScala.toList
    val offerRelevance = config.getString("offerRelevance")
    val productRelevance = config.getString("productRelevance")

    // TODO please check the need of orderBy for aggregate functions over window
    val ws = Window.partitionBy(partitionCol.head, partitionCol.tail: _*).orderBy(col(productRelevance).desc)

    val offerRelevanceDF = df.withColumn(offerRelevance, F.max(df(productRelevance)).over(ws))
    List(offerRelevanceDF)
  }

  /**
    * This function divides the customers into three sets:
    * 1. Customers who have got the required number of promotions
    * 2. Customers who have received some promotions but less than the required one.
    * 3. Customers who have not got any promotion.
    *
    * @param allocationDF: customerDatFrame with each customer alloted some offers
    * @param scoresDF: all active customers
    * @param promoDF: promotion DataFrame
    * @param cstDF: customer DataFrame
    * @param config Read Config
    * {{{
    *   {
    *     "offerLimit": 20
    *   }
    * }}}
    * offerLimit minimum required offers per customer per allocationLevel
    * @return active customer partitioned into three sets based on number of promotions allocated
    *         1. customersWhoDontNeedInfilling
    *         2. customersWhoNeedPartialInfilling
    *         3. customersWhoNeedFullInfilling
    *
    *
    */
  def customerBifurcation(allocationDF: DataFrame, scoresDF: DataFrame, promoDF: DataFrame,
                          cstDF: DataFrame, config: Config): List[DataFrame] = {

    val offerLimit = config.getInt("offerLimit")

    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val promotionColumnName = destinaGlobalConfiguration.promotionColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName
    val rangeHierarchyColumnName = destinaGlobalConfiguration.rangeHierarchyColumnName

    val selectColumn = List(customerColumnName, promotionColumnName, allocationLevelColumnName).filter(_.nonEmpty)
    val df = allocationDF.select(selectColumn.head, selectColumn.tail: _*).dropDuplicates()

    val partitionBy = List(customerColumnName, allocationLevelColumnName).filter(_.nonEmpty)
    val wc = Window.partitionBy(partitionBy.head, partitionBy.tail: _*)

    val distinctPromotionDF = df.withColumn("distinctPromotions",
      F.size(F.collect_set(promotionColumnName).over(wc))).cache()

    val columns = Seq(customerColumnName, allocationLevelColumnName, rangeHierarchyColumnName)
      .filter(_.nonEmpty).distinct

    val customersWhoDontNeedInfilling = distinctPromotionDF
      .where(F.col("distinctPromotions") >= offerLimit)
      .select(columns.map(F.col): _*).dropDuplicates()

    val customersWhoNeedPartialInfilling = distinctPromotionDF
      .where(F.col("distinctPromotions") < offerLimit)
      .select(columns.map(F.col): _*).dropDuplicates()

    val allCustomers = if (allocationLevelColumnName.isEmpty) {
      scoresDF.select(customerColumnName).dropDuplicates()
    }
    // if preferred ranging is on , then the infilling needs to be done for customer's rangeHierarchy level only.
    else if (rangeHierarchyColumnName.nonEmpty) {
      scoresDF.select(customerColumnName).dropDuplicates().join(cstDF, customerColumnName)
    }
    else {
      scoresDF.select(customerColumnName).dropDuplicates().crossJoin(
        promoDF.select(allocationLevelColumnName).dropDuplicates())
    }


    val customersWhoNeedFullInfilling = allCustomers.join(allocationDF.select(columns.map(F.col): _*)
      .dropDuplicates, columns, "left_anti")

    List(customersWhoDontNeedInfilling, customersWhoNeedPartialInfilling, customersWhoNeedFullInfilling)
  }

  /**
    * This function divides the customers into three sets for non RP proposition:
    * 1. Customers who have got the required number of promotions
    * 2. Customers who have received some promotions but less than the required one.
    * 3. Customers who have not got any promotion.
    *
    * @param allocationDF: customerDatFrame with each customer alloted some offers
    * @param rawScoresDF: all active customers
    * @param bannerDF: all active banners
    * @param cstDF: customer DataFrame
    * @param config Read Config
    * {{{
    *   {
    *     "offerLimit": 20
    *   }
    * }}}
    * offerLimit minimum required offers per customer per allocationLevel
    * @return active customer partitioned into three sets based on number of promotions allocated
    *         1. customersWhoDontNeedInfilling
    *         2. customersWhoNeedPartialInfilling
    *         3. customersWhoNeedFullInfilling
    *
    *
    */
  def nonRPCustomerBifurcation(allocationDF: DataFrame, rawScoresDF: DataFrame, bannerDF: DataFrame,
                          cstDF: DataFrame, config: Config): List[DataFrame] = {
    val offerLimit = config.getInt("limit")

    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName
    val rangeHierarchyColumnName = destinaGlobalConfiguration.rangeHierarchyColumnName

    val selectColumn = List(customerColumnName, productColumnName, allocationLevelColumnName).filter(_.nonEmpty)
    val df = allocationDF.select(selectColumn.head, selectColumn.tail: _*).dropDuplicates()

    val partitionBy = List(customerColumnName, allocationLevelColumnName).filter(_.nonEmpty)
    val wc = Window.partitionBy(partitionBy.head, partitionBy.tail: _*)

    val distinctProductsDF = df.withColumn("distinctProducts",
      F.size(F.collect_set(productColumnName).over(wc))).cache()

    val columns = Seq(customerColumnName, allocationLevelColumnName, rangeHierarchyColumnName)
      .filter(_.nonEmpty).distinct

    val customersWhoDontNeedInfilling = distinctProductsDF
      .where(F.col("distinctProducts") >= offerLimit)
      .select(columns.map(F.col): _*).dropDuplicates()

    val customersWhoNeedPartialInfilling = distinctProductsDF
      .where(F.col("distinctProducts") < offerLimit)
      .select(columns.map(F.col): _*).dropDuplicates()

    val allCustomers = if (allocationLevelColumnName.isEmpty) {
      rawScoresDF.select(customerColumnName).dropDuplicates()
    }
    // if preferred ranging is on , then the infilling needs to be done for customer's rangeHierarchy level only.
    else if (rangeHierarchyColumnName.nonEmpty) {
      rawScoresDF.select(customerColumnName).dropDuplicates().join(cstDF, customerColumnName)
    }
    else {
      rawScoresDF.select(customerColumnName).dropDuplicates().crossJoin(
        F.broadcast(bannerDF.select(allocationLevelColumnName)))
    }
    val customersWhoNeedFullInfilling = allCustomers.join(allocationDF.select(columns.map(F.col): _*)
      .dropDuplicates, columns, "left_anti")

    List(customersWhoDontNeedInfilling, customersWhoNeedPartialInfilling, customersWhoNeedFullInfilling)
  }

  /** Read Entity
    *
    * @param config Read Config
    * @return Speciic Entity as DataFrame
    */
  def getEntity(config: Config): List[DataFrame] = {
    val entityDF = DataFrameReadWriteFormat(config).readDataFrame(sqlContext)
    List(entityDF)
  }

  /** Read Dataframe and return the same df
    * This function is used when a persisted Dataframe needs some transformation before being given as
    * an input to another function.
    * @param inputDF Input Dataframe
    * @return inputDF
    */
  def getIdentityDF(inputDF: DataFrame): List[DataFrame] = {
    List(inputDF)
  }

  /** Write Output
    *
    * @param df Input DF
    * @param config Write Config
    * @return DF which is written to the specified location
    */
  def writeOutput(df: DataFrame, config: Config): List[DataFrame] = {
    DataFrameReadWriteFormat(config).writeDataFrame(df)
    List(df)
  }

  // scalastyle:off
  def dummy(str: String, df: DataFrame): List[DataFrame] = {
    List(df, df)
  }

  /** Get Best Promotion For A Product
    *
    * Get best promotions for a product on the basis of max discount or max storeCount
    *
    * @param promoDF Promotion DF
    * @return Best promotion for a product DF
    */
  def getBestPromotionForAProduct(promoDF: DataFrame): List[DataFrame] = {

    val promotionColumnName = destinaGlobalConfiguration.promotionColumnName
    val productColumnName = destinaGlobalConfiguration.productColumnName
    val storeColumnName = destinaGlobalConfiguration.storeColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName
    val discountColumnName = destinaGlobalConfiguration.discountColumnName
    val rangeHierarchyColumnName = destinaGlobalConfiguration.rangeHierarchyColumnName

    val selectColumns = List(productColumnName, promotionColumnName, storeColumnName,
      allocationLevelColumnName, discountColumnName, rangeHierarchyColumnName)
      .filter(_.nonEmpty).distinct

    val promoPartitionColumns = List(promotionColumnName,
      allocationLevelColumnName).filter(_.nonEmpty)

    val selectPromoDF = promoDF.select(selectColumns.head, selectColumns.tail: _*).dropDuplicates()

    val promoWindow = Window.partitionBy(promoPartitionColumns.head, promoPartitionColumns.tail: _*)

    val storeCountDF = selectPromoDF.withColumn("count", F.size(F.collect_set(storeColumnName).over(promoWindow)))

    val partitionByColumns = List(productColumnName,
      allocationLevelColumnName, rangeHierarchyColumnName).filter(_.nonEmpty).asJava

    val selectAndJoinColumnList = List(promotionColumnName, productColumnName, allocationLevelColumnName,
      rangeHierarchyColumnName)
      .filter(_.nonEmpty).distinct

    // If discount column is empty that means we don't want to consider discount for calculating
    // best promotion hence filtering it out in generate position function.

    val generatePositionConfig = ConfigFactory.parseString(
      s"""{
        | partitionByCol: $partitionByColumns,
        | rankColName: "rank",
        | orderByCol: [
        |   {
        |     "colName": "$discountColumnName"
        |     "sortOrder": "desc"
        |   },
        |   {
        |     "colName": "count"
        |     "sortOrder": "desc"
        |   },
        |   {
        |     "colName": "$promotionColumnName"
        |     "sortOrder": "asc"
        |   }
        | ]
        |}""".stripMargin)

    val rankedDF = generatePosition(storeCountDF, generatePositionConfig).head.where("rank == 1")
      .select(selectAndJoinColumnList.map(F.col): _*).distinct()

    val originalDetailsAddedDF = rankedDF.join(promoDF, selectAndJoinColumnList).drop("count")

    val bestPromotionDF = originalDetailsAddedDF.dropDuplicates(List(productColumnName,
      allocationLevelColumnName, rangeHierarchyColumnName).filter(_.nonEmpty).distinct)


    List(bestPromotionDF)
  }

  /** Caps the recommendation by first calculating the recommendation count using the recommendation rank column.<br>
    * Uses: <br>
    * 1.) Optionally used to filter out the customer with less than required recommendation. <br>
    * 2.) Used to limit the recommendation to a customer to the max cap. <br>
    * 3.) To filter in the top N promotions from the generic DF.
    *
    * @param toBeCapDF Input DF to be capped
    * @param config Capping config
    *
    * {{{
    *   {
    *    "offerLimit": 10,
    *    "alcoholicLimit": 2,
    *    "rankColumnName": "promotionRank",
    *    "minimumOffers": 4 (optional)
    *   }
    * }}}
    * '''offerLimit''' maximum number of promotion required per customer <br>
    * '''alcoholicLimit''' maximum number of alcoholic recommendation that can be served to a customer <br>
    * '''rankColumnName''' columnName on which capping is required: <br>
    *                                                             .PromotionRank in RP<br>
    *                                                             .OfferPosition in Non RP<br>
    * '''MinimumOffers''' minimum number of promotion required per customer<br>
    * @return Capped DF
    */
  def capping(toBeCapDF: DataFrame, config: Config): List[DataFrame] = {

    val offerLimit = config.getInt("offerLimit")
    val alcoholicLimit = config.getInt("alcoholicLimit")
    val rankColumnName = config.getString("rankColumnName")
    val customerColumnName = destinaGlobalConfiguration.customerColumnName
    val allocationLevelColumnName = destinaGlobalConfiguration.allocationLevelColumnName

    val capLimit = offerLimit + alcoholicLimit

    // remove customers who have offers less then required number of offer/recommendation
    val capDF = if (config.hasPath("minimumOffers")) {
      val wc = List(customerColumnName, allocationLevelColumnName).filter(_.nonEmpty)
      val window = Window.partitionBy(wc.head, wc.tail: _*)
      toBeCapDF.withColumn("recommendationCount", F.max(rankColumnName).over(window))
        .filter(F.col("recommendationCount") >= config.getInt("minimumOffers"))
        .drop("recommendationCount")
    }
    else {
      toBeCapDF
    }

    List(capDF.filter(F.col(rankColumnName) <= capLimit))
  }

  /** Multiple Campaign Email
   *
   * Filters the allocated products to a customer which are less than required number under a mechanic code
   *
   * @param inputDF Input DF
   * @param config Multiple Campaign Email Config
   * @return Multiple campaign filtered DF
   */
  def multipleCampaignEmail(inputDF: DataFrame, config: Config): List[DataFrame] = {

    val multipleCampaignEmailFilterList = config.getConfigList("multipleCampaignRules").asScala.toList
    if (multipleCampaignEmailFilterList.isEmpty) {
      logger.info(s"No Multiple Campaign Email Rules to apply")
      List(inputDF)
    } else {
      val allMechanicCodes = multipleCampaignEmailFilterList.map{conf =>
        conf.getStringList("mechanicCodesList").asScala.toList
      }.reduce(_ ++ _)

      val customerColumnName = destinaGlobalConfiguration.customerColumnName
      val productColumnName = destinaGlobalConfiguration.productColumnName
      val mechanicCodeColumnName = destinaGlobalConfiguration.mechanicCodeColumnName

      val ws = Window.partitionBy(customerColumnName, mechanicCodeColumnName)

      val maxProductCountColumnName = "maxProductCount"
      val inputDFWithProductCount = inputDF.withColumn(maxProductCountColumnName,
        F.count(col(productColumnName)).over(ws))

      val exclusionDF = inputDFWithProductCount.filter(!col(mechanicCodeColumnName).isin(allMechanicCodes: _*))

      val unionFilteredDF = multipleCampaignEmailFilterList.map{multipleCampaignEmailFilterConfig =>
        val mechanicCodesList = multipleCampaignEmailFilterConfig.getStringList("mechanicCodesList").asScala.toList
        val maxProductCount = multipleCampaignEmailFilterConfig.getInt(maxProductCountColumnName)

        inputDFWithProductCount
          .filter(col(mechanicCodeColumnName).isin(mechanicCodesList: _*))
          .filter(col(maxProductCountColumnName) > maxProductCount)
      }.reduce(_ union _)

      val exclusionUnionFilteredDF = exclusionDF.union(unionFilteredDF)

      List(exclusionUnionFilteredDF.drop(maxProductCountColumnName))
    }
  }

  /** Union 2 DF and if the schema of both the DataFrame
    *  are same return the unioned DF else throw exception.
    *
    * @param xDF: DataFrame - First DF to union
    * @param yDF: DataFrame - Second DF to union
    * @return union dataframe
    */
  def unionDataFrame(xDF: DataFrame, yDF: DataFrame): List[DataFrame] = {
    val xDFSchema = xDF.schema
    val yDFSchema = yDF.schema

    val combinedSchema = (xDFSchema ++ yDFSchema).distinct
    val combinedColumns = (xDF.columns ++ yDF.columns).distinct

    val combinedSchemaNullableInferred = combinedSchema
      .map(schema => (schema.name, schema.dataType)).distinct

    if (combinedSchemaNullableInferred.length != combinedColumns.length) {
      val combinedSchemaColumns = combinedSchemaNullableInferred.map(_._1).toList
      val columnWithTypeDifference = combinedSchemaColumns.diff(combinedColumns.toList)

      throw new IllegalStateException(s"${getClass.getName} - DataFrame cannot be unioned -" +
        s" conflicting dataypes of column - ${columnWithTypeDifference.mkString(",")}")
    } else {
      val xDFDeltaSchema = combinedSchema.toSet.filter(x => !xDF.columns.contains(x.name))
      val yDFDeltaSchema = combinedSchema.toSet.filter(y => !yDF.columns.contains(y.name))

      val xDFComplete = addDeltaColumns(xDFDeltaSchema, combinedColumns, xDF)
      val yDFComplete = addDeltaColumns(yDFDeltaSchema, combinedColumns, yDF)

      List(xDFComplete.union(yDFComplete))
    }
  }

  /** Add the difference columns to DataFrame
    *
    * @param deltaSchema: Seq[StructField]
    * @param combinedColumns: Array[String]
    * @param initialDF: DataFrame
    * @return
    */

  private def addDeltaColumns(deltaSchema: Set[StructField], combinedColumns: Array[String],
                              initialDF: DataFrame): DataFrame = {
    val outputDF = if (deltaSchema.nonEmpty) {
      deltaSchema.foldLeft(initialDF)((df, column) => {
        df.withColumn(column.name, lit(null).cast(column.dataType).alias(column.name))
      })
    } else {
      initialDF
    }
    outputDF.select(combinedColumns.head, combinedColumns.tail: _*)
  }

}


// scalastyle:off scaladoc
// TODO - Need to think about it so that we can test with different application.conf for different tests as required
object RulesBank {
  /** Default Constructor
    *
    * @param applicationConfig Application Config
    * @param sparkSession Spark Session Object
    * @return RulesBank Object
    */
  def apply(applicationConfig: Config, sparkSession: SparkSession): RulesBank = {

    val destinaGlobalConfiguration: DestinaGlobalConfiguration = new DestinaGlobalConfiguration(applicationConfig)
    new RulesBank(sparkSession, destinaGlobalConfiguration)
  }
}
