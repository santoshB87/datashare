package com.dunnhumby.destina.configuration

import com.typesafe.config.Config

/** DestinaGlobalConfiguration
  *
  * @param applicationConfig Application Config
  */
class DestinaGlobalConfiguration(applicationConfig: Config) {

  // scalastyle:off scaladoc
  val globalConfiguration: Config = applicationConfig.getConfig("globalConfiguration")
  // Todo If allocation level is selected then range hierarchy if set should be on same column name

  val allocationLevelColumnName: String = globalConfiguration.getString("allocationLevel")
  val rangeHierarchyColumnName: String = globalConfiguration.getString("rangeHierarchy")
  val cadenceWeekColumnName: String = globalConfiguration.getString("cadenceWeekColumnName")
  val mechanicCodeColumnName: String = if (globalConfiguration.hasPath("mechanicCodeColumnName")) {
    globalConfiguration.getString("mechanicCodeColumnName")
  } else {
    ""
  }

  // Customer
  val customerInputConfig: Config = globalConfiguration.getConfig("customer")
  val customerColumnName: String = customerInputConfig.getString("customerColumnName")

  // Product
  val productInputConfig: Config = globalConfiguration.getConfig("product")
  val productColumnName: String = productInputConfig.getString("productColumnName")
  val productRank: String = productInputConfig.getString("productRank")

  // Promotions
  val promotionInputConfig: Config = globalConfiguration.getConfig("promotions")
  val promotionColumnName: String = getOptString(promotionInputConfig, "promotionColumnName")
  val promotionRank: String = getOptString(promotionInputConfig, "promotionRank")
  val promotionStartDateColumnName: String = getOptString(promotionInputConfig, "promotionStartDate")
  val promotionEndDateColumnName: String = getOptString(promotionInputConfig, "promotionEndDate")
  val offerRelevance: String = getOptString(promotionInputConfig, "offerRelevance")
  val popularPromotionLevel: String = getOptString(promotionInputConfig, "popularPromotionLevel")
  val discountColumnName: String = getOptString(promotionInputConfig, "discountColumnName")

  // Stores
  val storeInputConfig: Config = globalConfiguration.getConfig("store")
  val storeColumnName: String = storeInputConfig.getString("storeColumnName")

  // Scores
  val scoreInputConfig: Config = globalConfiguration.getConfig("score")
  val scoreTypeColumnName: String = scoreInputConfig.getString("scoreTypeColumnName")
  val scoreColumnName: String = scoreInputConfig.getString("scoreColumnName")
  val scorePrecision: Int = scoreInputConfig.getInt("scorePrecision")


  def getOptString(config: Config, key: String) : String = {
    if (config.hasPath(key)) {
      config.getString(key)
    } else {
      ""
    }
  }

}
