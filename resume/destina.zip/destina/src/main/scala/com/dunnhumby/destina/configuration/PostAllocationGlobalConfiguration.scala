package com.dunnhumby.destina.configuration

import com.typesafe.config.Config

/** PostAllocationGlobalConfiguration
  *
  * @param applicationConfig Application Config
  */
class PostAllocationGlobalConfiguration(applicationConfig: Config) {

  // scalastyle:off scaladoc

  val propositionNameColumnName: String = applicationConfig.getString("propositionNameColumnName")

  val eventIdColumnName: String = applicationConfig.getString("eventIdColumnName")
  val trancheIdColumnName: String = applicationConfig.getString("trancheIdColumnName")
  val variationIdColumnName: String = applicationConfig.getString("variationIdColumnName")

  val customerColumnName: String = applicationConfig.getString("customerColumnName")

  val startDateColumnName: String = applicationConfig.getString("startDateColumnName")
  val endDateColumnName: String = applicationConfig.getString("endDateColumnName")
  val runDateColumnName: String = applicationConfig.getString("runDateColumnName")
  val typeName: String = applicationConfig.getString("type")
  val allocationTypeName: String = applicationConfig.getString("allocationTypeName")
  val controlTypeName: String = applicationConfig.getString("controlTypeName")
  val targetTypeName: String = applicationConfig.getString("targetTypeName")
  val programControlTypeName: String = applicationConfig.getString("programControlTypeName")
}
