package com.dunnhumby.destina.orchestrator

// scalastyle:off
import com.dunnhumby.destina.RulesBank

/** AllocationState
  * Created by Shreyansh Gupta on 9/5/2019
  */
case class AllocationState(obj: RulesBank, currentMethod: String,
                           allParams: Map[String, Any])