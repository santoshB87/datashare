package com.dunnhumby.destina.orchestrator

import scala.language.postfixOps
import scala.reflect.runtime.{universe => ru}

import com.twitter.util.Memoize
import org.apache.spark.sql.DataFrame

import com.dunnhumby.destina.RulesBank

/** DestinaReflectionHelper
  * Created by Shreyansh Gupta on 9/5/2019
  */
object DestinaReflectionHelper {
  /**
    * Get the runtime instance mirror of any object of type RulesBank.
    * Memoization helps avoiding loading of the object over and over.
    */
  val getObjectReflection: RulesBank => ru.InstanceMirror =
    Memoize { obj: RulesBank => ru.runtimeMirror(getClass.getClassLoader).reflect(obj) }
  /**
    * This function loads the required method based on the passed
    * specifications, runs it and returns the output as a List[DataFrame].
    * Please note that it works only for the methods defined in the
    * object of type `RulesBank`. It employs memoization for the
    * optimisation purposes.
    */
  val getExecutableMethod: AllocationState => List[DataFrame] =
    Memoize {
      case AllocationState(obj: RulesBank, methodName: String, allParams: Map[String, Any]) =>
        val objReflection = getObjectReflection(obj)
        val methodSymbol = getMethodSymbol(objReflection, methodName)
        val methodParamsList = getParamsList(methodSymbol)
        val methodMirror = getMethodMirror(objReflection, methodSymbol)
        val preppedParams = methodParamsList map (methodName => allParams(methodName))
        methodMirror(preppedParams: _*).asInstanceOf[List[DataFrame]]
    }

  /**
    * Get the symbol of required method from the object mirror.
    *
    * @param objMirror  runtime instance mirror
    * @param methodName name of the method whose symbol is required
    * @return runtime symbol of required method
    */
  def getMethodSymbol(objMirror: ru.InstanceMirror, methodName: String): ru.MethodSymbol =
    ru.appliedType(objMirror.symbol).member(ru.TermName(methodName)).asMethod

  /**
    * Get the method mirror or the actually executable method instance
    * from the runtime instance mirror against a given method symbol.
    *
    * @param objMirror runtime instance mirror
    * @param method    runtime symbol of required method
    * @return executable instance of the method
    */
  def getMethodMirror(objMirror: ru.InstanceMirror, method: ru.MethodSymbol): ru.MethodMirror =
    objMirror.reflectMethod(method)

  /**
    * Get the list of all the parameters a given method takes.
    *
    * @param method symbol of the method of interest
    * @return list of all parameter the given method takes
    */
  def getParamsList(method: ru.MethodSymbol): List[String] = method.paramLists.flatten.map(x => x.name.toString)
}
