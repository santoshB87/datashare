package com.dunnhumby.destina.orchestrator

// scalastyle:off
import java.io.File
import java.sql.Date
import java.text.SimpleDateFormat

import scala.collection.JavaConverters._

import com.typesafe.config.{Config, ConfigFactory, ConfigValueFactory}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, Row, SparkSession, SQLContext}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.destina.RulesBank

/** Orchestrator
  * Created by Shreyansh Gupta on 9/5/2019
  */
object Orchestrator {

  def getMaxCadenceWeek(config: Config, sqlLContext: SQLContext): String = {
    val cadenceWeekColumnName = "cadence_week"
    val readDF = DataFrameReadWriteFormat(config).readDataFrame(sqlLContext)
    val maxCadenceWeek = readDF.select(max(cadenceWeekColumnName)).collect().head.getString(0)
    maxCadenceWeek
  }

  def main(args: Array[String]): Unit = {

    Logger.getRootLogger.setLevel(Level.ERROR)

    val sparkSession = SparkSession.builder()
      .appName("destina-orchestrator")
      .enableHiveSupport()
      .getOrCreate()

    sparkSession.sparkContext.setLogLevel("ERROR")

    val latestCadenceWeek = args(0)
    val proposition = args(1)
    System.setProperty("latestCadenceWeek", latestCadenceWeek)
    println(s"latestCadenceWeek : " + System.getProperty("latestCadenceWeek"))

    /* Initializing the runtime variable for the allocation run*/
    val currentRunTime = System.currentTimeMillis()
    val currRunDate = new java.util.Date(currentRunTime).toString
    val readFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy")
    val writeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
    val readDate = readFormat.parse(currRunDate)
    val outputRunTimeString = writeFormat.format(readDate)
    System.setProperty("runTime", outputRunTimeString)
    println("runTime : " + System.getProperty("runTime"))

    val orchestratorConfigList = ConfigFactory.parseFile(new File("orchestrator.conf"))
      .getConfigList(proposition).asScala.toList
    val applicationConfig = ConfigFactory.parseFile(new File("application.conf")).getConfig(proposition)
    val rulesBankObject = RulesBank(applicationConfig, sparkSession)
    val businessConfig = ConfigFactory.parseFile(new File("businessConfig.conf")).getConfig(proposition)
      .withValue("latestCadenceWeek", ConfigValueFactory.fromAnyRef(latestCadenceWeek))
      .withValue("runTime", ConfigValueFactory.fromAnyRef(outputRunTimeString)).resolve()

    val intermediateDataFrameReferenceMap: Map[String, DataFrame] = Map[String, DataFrame]("null" -> null)
    orchestratorConfigList.foldLeft(intermediateDataFrameReferenceMap) { case (refMap, orchestratorConfig) =>
      val ruleName = orchestratorConfig.getString("ruleName")
      val ruleConfig = orchestratorConfig.getConfig("ruleConfig")
      val inputConfig = ruleConfig.getConfig("input")
      val inputKeys = inputConfig.root().keySet().asScala.toList
      val allParams = inputKeys.map { inputKey =>
        val value = inputKey match {
          case s if s.toLowerCase().contains("df") => {
            val dfName = inputConfig.getString(inputKey)
            val RDD = sparkSession.sparkContext.parallelize(Seq.empty[Row])
            val schema = StructType(Array.empty[StructField])
            if (dfName.trim.isEmpty) sparkSession.sqlContext.createDataFrame(RDD, schema) else refMap(dfName)
          }
          case "config" => businessConfig.getConfig(inputConfig.getString(inputKey))
          case _ => throw new IllegalArgumentException(s"Rule $ruleName should be provided with at least one parameter")
        }
        (inputKey, value)
      }.toMap

      val intermediateAllocationState = AllocationState(rulesBankObject, ruleName, allParams)
      println(s"AllocationState -> ruleName = $ruleName")
      val output = DestinaReflectionHelper.getExecutableMethod(intermediateAllocationState)
      if (ruleConfig.hasPath("output")) {
        val outputConfigList = ruleConfig.getConfigList("output").asScala.toList

        formatAndUpdateReferenceMap(output, outputConfigList, refMap, ruleName)
      } else {
        refMap
      }
    }

    /** Format and update reference map
      *
      * @param dfList DF List
      * @param outputConfigList Output configuration List
      * @param refMap Reference Map
      * @return Updated Map
      */
    def formatAndUpdateReferenceMap(dfList: List[DataFrame], outputConfigList: List[Config],
                                    refMap: Map[String, DataFrame], ruleName: String): Map[String, DataFrame] = {

      val zippedList = outputConfigList.zip(dfList)
      val newEntryMap = zippedList.map { case (conf, df) =>
        val formattedDF = formatDF(df, conf)
        val dfName = conf.getString("dfName")
        (dfName, formattedDF)
      }.toMap

      refMap ++ newEntryMap
    }

    /** Format DF
      * This function is used to format the output dataframe of any rule business
      * Format df  includes literal, selecting columns, dropping columns, repartitioning and persisting the DataFrame
      *
      * @param df   Input DF
      * @param conf Input Config
      * @return Formatted DF
      */
    def formatDF(df: DataFrame, conf: Config): DataFrame = {

      val exprDF = if (conf.hasPath("expression")) {
        val expressionConfig = conf.getConfig("expression")
        val columnNames = expressionConfig.root().entrySet().asScala.map(_.getKey)
        columnNames.foldLeft(df) { (df, col) =>
          df.withColumn(col, expr(expressionConfig.getString(col)))
        }
      } else {
        df
      }

      val litDF = if (conf.hasPath("literal")) {
        val literalConfig = conf.getConfig("literal")
        val columnNames = literalConfig.root().entrySet().asScala.map(_.getKey)
        val outputDF: DataFrame = columnNames.foldLeft(exprDF) { (df, col) =>
          df.withColumn(col, lit(literalConfig.getAnyRef(col)))
        }
        outputDF
      } else {
        exprDF
      }

      val filteredDF = if (conf.hasPath("filterList")) {
        val filterConfigList = conf.getConfigList("filterList").asScala.toList
        val filterQuery = filterConfigList.map { config =>
          val operator = config.getString("operator")
          val leftColumn = config.getString("left_column")
          val columnStructField = litDF.schema.find(structField => structField.name == leftColumn)
            .getOrElse(
              throw new IllegalArgumentException(s"${getClass.getSimpleName} $leftColumn" +
                s" Not present in Input Data Frame"))

          val castValue = if (config.hasPath("value")) {
            val value = config.getString("value")
            castValueDataType(columnStructField, value)
          }
          else {
            val rightColumn = config.getString("right_column")
            litDF(rightColumn)
          }

          operator match {
            case ">" => litDF(leftColumn).gt(castValue)
            case ">=" => litDF(leftColumn).geq(castValue)
            case "<" => litDF(leftColumn).lt(castValue)
            case "<=" => litDF(leftColumn).leq(castValue)
            case "=" => litDF(leftColumn) === castValue
            case "!=" | "=!=" => litDF(leftColumn).notEqual(castValue)
            case "<=>" => litDF(leftColumn) <=> castValue || litDF(leftColumn).isNull
            case "!<=>" => !(litDF(leftColumn) <=> castValue)
            case "like" => litDF(leftColumn).like(castValue.asInstanceOf[String])
            case _ => throw new IllegalArgumentException(s"${getClass.getName} does not support specified " +
              s"operator $operator")
          }
        }.reduce(_ && _)
        litDF.filter(filterQuery)
      } else {
        litDF
      }

      val intersectedDF = if(conf.hasPath("intersect")) {
        val intersectConfig = conf.getConfig("intersect")
        val col1 = intersectConfig.getString("column1")
        val col2 = intersectConfig.getString("column2")
        val outputColumn = intersectConfig.getString("outputColumn")
        val intersectUDF = udf(
          (xs: Seq[String], ys: Seq[String]) => xs.intersect(ys).filter(x => x!= null && x.nonEmpty)
        )
        filteredDF.withColumn(outputColumn, intersectUDF(col(col1), col(col2)))
      } else {
        filteredDF
      }

      val explodedDF = if(conf.hasPath("explode")) {
        val explodeConfigList = conf.getConfigList("explode").asScala.toList
        explodeConfigList.foldLeft(intersectedDF) {
          case (interDF, explodeConfig) =>
            val outputColumn = explodeConfig.getString("outputColumn")
            val explodeColumn = explodeConfig.getString("explodeColumn")
            explodeConfig.hasPath("isSplit") && explodeConfig.getBoolean("isSplit") match {
              case true =>
                val splitPattern = explodeConfig.getString("splitPattern")
                interDF.withColumn(outputColumn, explode(split(col(explodeColumn), splitPattern)))

              case false =>
                interDF.withColumn(outputColumn, explode(col(explodeColumn)))
            }
        }
      } else {
        intersectedDF
      }

      val sqlRunDF = if(conf.hasPath("sqlRun")) {
        val sqlRunConfig = conf.getConfig("sqlRun")
        val tempViewTableName = sqlRunConfig.getString("tableName")
        explodedDF.createOrReplaceTempView(tempViewTableName)
        val sqlCommand = sqlRunConfig.getString("sqlCommand")
        sparkSession.sql(sqlCommand)
      } else {
        explodedDF
      }

      val selectDF = if (conf.hasPath("selectColumns")) {
        val selectColumnList = conf.getStringList("selectColumns").asScala.toList
        sqlRunDF.select(selectColumnList.map(col): _*)
      } else {
        sqlRunDF
      }

      val droppedDF = if (conf.hasPath("dropColumns")) {
        val dropColumnList = conf.getStringList("dropColumns").asScala.toList
        selectDF.drop(dropColumnList: _*)
      } else {
        selectDF
      }

      val dropDuplicatesDF = if (conf.hasPath("dropDuplicates") && conf.getBoolean("dropDuplicates")) {
        droppedDF.dropDuplicates
      } else {
        droppedDF
      }

      val repartitionDF = if (conf.hasPath("repartition") && !conf.getConfig("repartition").isEmpty) {
        val repartitionConfig = conf.getConfig("repartition")
        if (repartitionConfig.hasPath("noOfPartitions")
          && !repartitionConfig.hasPath("repartitionColumnList")) {
          val noOfPartitions = repartitionConfig.getInt("noOfPartitions")
          dropDuplicatesDF.repartition(noOfPartitions)
        } else if (!repartitionConfig.hasPath("noOfPartitions")
          && repartitionConfig.hasPath("repartitionColumnList")) {
          val repartitionColumnList = repartitionConfig.getStringList("repartitionColumnList").asScala.toList
          dropDuplicatesDF.repartition(repartitionColumnList.map(col): _*)
        } else {
          val noOfPartitions = repartitionConfig.getInt("noOfPartitions")
          val repartitionColumnList = repartitionConfig.getStringList("repartitionColumnList").asScala.toList
          dropDuplicatesDF.repartition(noOfPartitions, repartitionColumnList.map(col): _*)
        }
      } else {
        dropDuplicatesDF
      }

      val persistedDF = if (conf.hasPath("persist") && conf.getBoolean("persist")) {
        repartitionDF.persist()
        val dfName = conf.getString("dfName")
        println(s"$dfName count -> ${repartitionDF.count()}")
        repartitionDF
      } else {
        repartitionDF
      }

      persistedDF
    }

    /** Cast The Value Into Given Type
      *
      * @param columnStructField Column Struct Field
      * @param value    Value Which Need To Cast
      * @return
      */
    def castValueDataType(columnStructField: StructField, value: String): Any = {
      val dataType = columnStructField.dataType
      try {
        dataType match {
          case StringType => String.valueOf(value)
          case DateType => Date.valueOf(value)
          case BooleanType => value.toBoolean
          case FloatType => value.toFloat
          case LongType => value.toLong
          case DoubleType => value.toDouble
          case IntegerType => value.toInt
        }
      } catch {
        case _: MatchError => throw new IllegalArgumentException(s"${getClass.getSimpleName} does not support" +
          s" specified dataType $dataType")
        case _: Throwable => throw new IllegalArgumentException(s"${getClass.getSimpleName} " +
          s"Type of ${columnStructField.name} and $value does not match")
      }
    }
  }
}
