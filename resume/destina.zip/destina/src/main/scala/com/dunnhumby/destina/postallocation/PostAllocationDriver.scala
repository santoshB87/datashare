package com.dunnhumby.destina.postallocation

import java.io.File

import scala.collection.JavaConverters._

import com.typesafe.config.{Config, ConfigFactory, ConfigValueFactory}
import org.apache.hadoop.fs.Path
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.destina.configuration.PostAllocationGlobalConfiguration

/** PostAllocation Driver
  * Created by Shreyansh Gupta on 10/22/2019
  */
object PostAllocationDriver {

  /** Main Driver Function
    *
    * @param args Arguments
    */
  def main(args: Array[String]): Unit = {

    Logger.getRootLogger.setLevel(Level.ERROR)

    val sparkSession = SparkSession.builder()
      .appName("destina-post-allocation")
      .enableHiveSupport()
      .getOrCreate()

    val propositionName = args(0)

    val postAllocationConfig: Config = ConfigFactory.parseFile(new File("postAllocation.conf"))

    val applicationConfig: Config = ConfigFactory.parseFile(new File("postAllocationGlobalConfig.conf"))
      .getConfig(propositionName)

    val postAllocationGlobalConfiguration = new PostAllocationGlobalConfiguration(applicationConfig)
    val propositionConfig = postAllocationConfig.getConfig(propositionName)
    val fileSystemString = propositionConfig.getString("fileSystem")
    val fs = new Path(fileSystemString).getFileSystem(sparkSession.sparkContext.hadoopConfiguration)

    val allocationOutputTable = propositionConfig.getString("allocationOutputTable")

    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val eventColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val typeName = postAllocationGlobalConfiguration.typeName
    val allocationTypeName = postAllocationGlobalConfiguration.allocationTypeName

    val allocationOutputDF = sparkSession.read.table(allocationOutputTable)


    // If run date is passed as an argument, then the whole code flow will run for that particular date
    // otherwise will pick up the latest allocation run date.
    // Each proposition will have their own table that will be partitioned by run-date.
    val allocationLatestRunDttm = if (args.length > 1) {
      args(1)
    } else {
      allocationOutputDF
      .agg(max(runDateColumnName))
      .head.toString().replaceAll("[^0-9]+", "")
    }
    // scalastyle:off
    println(s"propositionName => $propositionName")
    println(s"allocationLatestRunDttm => $allocationLatestRunDttm")
    // scalastyle:on

    sparkSession.sparkContext.setLogLevel("ERROR")

    val postAllocationHelper = PostAllocationHelper(sparkSession, applicationConfig, propositionName,
      allocationLatestRunDttm, fs)

    val metaCatalogueConfig = propositionConfig.getConfig("metaCatalogue")

    val (updatedEventID, updatedTrancheId, updatedVariationId) = postAllocationHelper.updateEventID(metaCatalogueConfig)

    val allocDF = allocationOutputDF.where(col(runDateColumnName) === allocationLatestRunDttm)

    val allocationWarehouseConfig = propositionConfig.getConfig("allocationWarehouse")
    val pathSuffix = s"/$eventColumnName=$updatedEventID" + s"/$typeName=$allocationTypeName" +
      s"/$runDateColumnName=$allocationLatestRunDttm"

    val finalPath = allocationWarehouseConfig.getString("writeConfig.option.path") + pathSuffix
    val allocationWarehouseColumnNames = allocationWarehouseConfig
      .getStringList("writeConfig.option.columnNames").asScala.toList.map(_.toLowerCase)
    val filteredSchema = allocDF.schema.filter{col => allocationWarehouseColumnNames
      .contains(col.name.toLowerCase)}.toList
    val allocationWarehouseSchema = filteredSchema.map{field =>
      field.name + " " + getTypeFromDataType(field.dataType)
    }.mkString(",")
    val partitionByColLst = allocationWarehouseConfig.getStringList("readConfig.option.partitionBy").asScala
    val partitionByString = partitionByColLst
      .toList.map{ _ + " String" }.mkString(",")

    val allocationWarehouseTableName = allocationWarehouseConfig.getString("readConfig.option.path")
    postAllocationHelper.executeCreateExternalTableCommand(
      allocationWarehouseTableName, allocationWarehouseSchema,
      allocationWarehouseConfig.getString("writeConfig.option.path"), partitionByString)

    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    // move the latest allocation file to the allocation warehouse
    DataFrameReadWriteFormat(allocationWarehouseConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(finalPath))).writeDataFrame(allocDF)

    sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

     val applyControlFlag = postAllocationConfig.hasPath("rp.control.applyControlFlag") &&
      postAllocationConfig.getBoolean("rp.control.applyControlFlag")

    if (applyControlFlag) {
      val controlDfMap = postAllocationHelper.applyControl(allocDF,
        postAllocationConfig,
        updatedEventID)

      postAllocationHelper.generateSendControlFiles(allocDF,
        controlDfMap,
        propositionConfig,
        updatedEventID,
        allocationLatestRunDttm)
    }

    postAllocationHelper.generateFinalFormattedFiles(
      postAllocationConfig,
      propositionName, updatedEventID, updatedTrancheId, updatedVariationId)
  }

  /** Get Type from DataType String
    *
    * @param dt DataType
    * @return Type as in `string`, `boolean`, `byte`, `short`, `int`, `long`,
    *         float`, `double`, `decimal`, `date`, `timestamp`.
    */
  def getTypeFromDataType(dt: DataType): String = {
    dt match {
      case StringType => "string"
      case BooleanType => "boolean"
      case ByteType => "byte"
      case ShortType => "short"
      case IntegerType => "int"
      case LongType => "long"
      case FloatType => "float"
      case DoubleType => "double"
      case DateType => "date"
      case TimestampType => "timestamp"
    }
  }
}
