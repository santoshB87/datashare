package com.dunnhumby.destina.postallocation

import java.text.SimpleDateFormat

import scala.collection.JavaConverters._
import scala.collection.mutable

import com.typesafe.config.{Config, ConfigValueFactory}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, Row, SparkSession, SQLContext}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.core.unittest.dataframe.DataFrameUtility
import com.dunnhumby.destina.configuration.PostAllocationGlobalConfiguration

/** PostAllocationHelper
  * Created by Shreyansh Gupta on 11/12/2019
  * @param sparkSession SparkSession
  * @param postAllocationGlobalConfiguration PostAllocationGlobalConfiguration
  * @param propositionName Proposition Name
  * @param runDate Date Time String of the format (yyyyMMddHHmmss)
  * @param fs FileSystem Object
  */
class PostAllocationHelper(sparkSession: SparkSession,
                           postAllocationGlobalConfiguration: PostAllocationGlobalConfiguration,
                           propositionName: String, runDate: String, fs: FileSystem) {

  /** This function update the event-id(if required) and run-date for the meta files tables.
    * Each Meta Table(event, tranche, variation) is partitioned by proposition, event, run-date
    *
    * @param metaCatalogueConfig Meta Catalogue Config
    * @return (updatedEventID, updatedTrancheId, updatedVariationId)
    */
  def updateEventID(metaCatalogueConfig: Config): (String, String, String) = {

    val sqlContext = sparkSession.sqlContext
    val propositionColumnName = postAllocationGlobalConfiguration.propositionNameColumnName
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val trancheIdColumnName = postAllocationGlobalConfiguration.trancheIdColumnName
    val variationIdColumnName = postAllocationGlobalConfiguration.variationIdColumnName
    val startDateColumnName = postAllocationGlobalConfiguration.startDateColumnName
    val endDateColumnName = postAllocationGlobalConfiguration.endDateColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName

    val dateFormatPattern = "yyyyMMddHHmmss"
    val newFormat = new SimpleDateFormat(dateFormatPattern)

    val currentDate = new DateTime(newFormat.parse(runDate))

    val eventConfig = metaCatalogueConfig.getConfig("event")
    val trancheConfig = metaCatalogueConfig.getConfig("tranche.readWriteConfig")
    val variationConfig = metaCatalogueConfig.getConfig("variation.readWriteConfig")


    val updateEventIdFlag = metaCatalogueConfig.hasPath("updateEventIdFlag") &&
      metaCatalogueConfig.getBoolean("updateEventIdFlag")

    val eventReadConfig = eventConfig.getConfig("readWriteConfig")
    val eventSchedule = eventConfig.getString("eventSchedule")


    val metaTable = metaCatalogueConfig.getConfig(_: String).getString("tableName")

    val eventTableName = metaTable("event")
    val trancheTableName = metaTable("tranche")
    val variationTableName = metaTable("variation")

    /**
      * we need to insert with initial values in case
      * . if the eventSchedule  is on-demand, will be set in case we want to update event details from config
      * . if event table path does not exist that indicates fresh deployment
      */
    if (!eventSchedule.equalsIgnoreCase("on-demand") &&
      fs.exists(new Path(metaCatalogueConfig.getString("event.readWriteConfig.option.path"))) &&
      sparkSession.sqlContext.read.table(eventTableName)
        .filter(col(propositionColumnName) === propositionName).count() > 0
    ) {
      // scalastyle:off
      println("eventIdDF is not empty that indicates successive run")
      // scalastyle:on
      createMetaTable("event", metaCatalogueConfig)
      createMetaTable("tranche", metaCatalogueConfig)
      createMetaTable("variation", metaCatalogueConfig)
      val eventTableName = eventConfig.getString("tableName")
      val eventIdDF = sparkSession.sqlContext.read.table(eventTableName)
      val orderedEventIdDF = eventIdDF.filter(col(propositionColumnName) === propositionName)
        .orderBy(col(eventIdColumnName).desc_nulls_last, col(runDateColumnName).desc_nulls_last)

      val latestEventIdRow = orderedEventIdDF.first()


      val latestEventID = latestEventIdRow.getAs[String](eventIdColumnName).toInt
      val latestStartDateString = latestEventIdRow.getAs[String](startDateColumnName)
      val latestEndDateString = latestEventIdRow.getAs[String](endDateColumnName)
      val latestRunDateString = latestEventIdRow.getAs[String](runDateColumnName)

      val latestEventIdDF = orderedEventIdDF.filter(col(propositionColumnName) === propositionName
      && col(runDateColumnName) === latestRunDateString).distinct()

      val latestEndDate = new DateTime(newFormat.parse(latestEndDateString))

      val (updatedEventID, updatedStartDate, updatedEndDate) =
      // if latest event is over and needs to be updated
        if (updateEventIdFlag && (currentDate.compareTo(latestEndDate) == 1)) {
          val newEventId = (latestEventID + 1).toString

          val (newStartDate, newEndDate) = eventSchedule.toLowerCase() match {
            case "weekly" =>
              (currentDate.withDayOfWeek(1).withTime(0, 0, 0, 0), currentDate.withDayOfWeek(7).withTime(23, 59, 59, 0))
            case "daily" =>
              (currentDate.withTimeAtStartOfDay, currentDate.withTime(23, 59, 59, 0))
          }
          val parsedStartDate = DateTimeFormat.forPattern(dateFormatPattern).print(newStartDate)
          val parsedEndDate = DateTimeFormat.forPattern(dateFormatPattern).print(newEndDate)

          (newEventId, parsedStartDate, parsedEndDate)
        } else {
          (latestEventID.toString, latestStartDateString, latestEndDateString)
        }

      val eventIdLitValueMap = Map(eventIdColumnName -> updatedEventID,
        startDateColumnName-> updatedStartDate,
        endDateColumnName -> updatedEndDate,
        runDateColumnName -> runDate)

      // latestEventIdDF will have single row only, creating new event row by replacing existing values
      val updatedEventIdDF = litValues(latestEventIdDF, eventIdLitValueMap)

      val litValuesMap = Map(eventIdColumnName -> updatedEventID, runDateColumnName -> runDate)

      // Update Tranche
      sparkSession.sql(s"refresh table ${metaCatalogueConfig.getString("tranche.tableName")}").count()
      val trancheDF = DataFrameReadWriteFormat(trancheConfig).readDataFrame(sqlContext)

      val latestTrancheDF = trancheDF.filter(col(propositionColumnName) === propositionName
        && col(runDateColumnName) === latestRunDateString).distinct()

      val trancheId = latestTrancheDF.select(trancheIdColumnName).collect().toList.head.getString(0)

      val updatedTrancheDF = litValues(latestTrancheDF, litValuesMap)

      // Update Variation
      sparkSession.sql(s"refresh table ${metaCatalogueConfig.getString("variation.tableName")}").count()
      val variationDF = DataFrameReadWriteFormat(variationConfig).readDataFrame(sqlContext)

      val latestVariationDF = variationDF.filter(col(propositionColumnName) === propositionName
        && col(runDateColumnName) === latestRunDateString).distinct().orderBy(variationIdColumnName)

      val variationId = latestVariationDF.select(variationIdColumnName).collect().toList.head.getString(0)

      val updatedVariationDF = litValues(latestVariationDF, litValuesMap)

      // TODO : think about the housekeeping of the event table
      // append meta catalogue in respective tables
      // in config the write path is a parquet file and write mode will be append,
      // thus below writing will add the new event row in the table
      sparkSession.sql(s"refresh table $eventTableName").count()
      sparkSession.sql(s"refresh table $trancheTableName").count()
      sparkSession.sql(s"refresh table $variationTableName").count()

      DataFrameReadWriteFormat(eventReadConfig).writeDataFrame(updatedEventIdDF)
      DataFrameReadWriteFormat(trancheConfig).writeDataFrame(updatedTrancheDF)
      DataFrameReadWriteFormat(variationConfig).writeDataFrame(updatedVariationDF)

      sparkSession.sql(s"refresh table $eventTableName").count()
      sparkSession.sql(s"refresh table $trancheTableName").count()
      sparkSession.sql(s"refresh table $variationTableName").count()

      (updatedEventID, trancheId, variationId)
    } else {
      // scalastyle:off
      println("eventIdDF is either empty that indicates fresh deployment or eventSchedule is set to on-demand")
      // scalastyle:on
      // if eventIdDF is empty that indicates fresh deployment and in this case we need to insert with initial values

      createMetaTable("event", metaCatalogueConfig)
      createMetaTable("tranche", metaCatalogueConfig)
      createMetaTable("variation", metaCatalogueConfig)

      sparkSession.sql(s"refresh table $eventTableName").count()
      sparkSession.sql(s"refresh table $trancheTableName").count()
      sparkSession.sql(s"refresh table $variationTableName").count()

      val mandatoryColumnsKeyValueMap = Map(propositionColumnName -> propositionName, runDateColumnName -> runDate)
      insertInitialMetaData(sqlContext, "event", metaCatalogueConfig, mandatoryColumnsKeyValueMap)
      insertInitialMetaData(sqlContext, "tranche", metaCatalogueConfig, mandatoryColumnsKeyValueMap)
      insertInitialMetaData(sqlContext, "variation", metaCatalogueConfig, mandatoryColumnsKeyValueMap)

      sparkSession.sql(s"refresh table $eventTableName").count()
      sparkSession.sql(s"refresh table $trancheTableName").count()
      sparkSession.sql(s"refresh table $variationTableName").count()

      val metaConfigWithValuesPartialFunc = metaCatalogueConfig.getConfig(_: String)
        .getConfigList("initialParams").asScala.head.getString(_: String)
      (
        metaConfigWithValuesPartialFunc("event", eventIdColumnName),
        metaConfigWithValuesPartialFunc("tranche", trancheIdColumnName),
        metaConfigWithValuesPartialFunc("variation", variationIdColumnName)
      )
    }
  }

  /**
    * Apply Control logic on the Allocation Output as follows
    * For the given weight, it splits the Final Allocated Customers into two groups Control and Target
    *
    * @param allocDF            Final Allocation Recommendations
    * @param postAllocationConf postAllocationConf
    * @param event            Latest Allocation event
    * @return Map containing two split of final customers
    */
  def applyControl(allocDF: DataFrame,
                   postAllocationConf: Config,
                   event: String
                  ): Map[String, DataFrame] = {

    val controlConfig = postAllocationConf.getConfig(s"$propositionName.control")

    val variationConfig = postAllocationConf.getConfig(s"$propositionName.metaCatalogue.variation.readWriteConfig")
    val customerColumnName = postAllocationGlobalConfiguration.customerColumnName
    val propositionColumnName = postAllocationGlobalConfiguration.propositionNameColumnName
    val typeColumnName = postAllocationGlobalConfiguration.typeName
    val controlTypeName = postAllocationGlobalConfiguration.controlTypeName
    val targetTypeName = postAllocationGlobalConfiguration.targetTypeName

    val sqlContext = sparkSession.sqlContext

    val controlFilesConfig = controlConfig.getConfig("files")
    val targetGroupConfig = controlFilesConfig.getConfig("targetGroup")
    val controlGroupConfig = controlFilesConfig.getConfig("controlGroup")
    val programControlGroupConfig = controlFilesConfig.getConfig("programControlGroup")

    // control initialising table
    val controlColumnNames = controlGroupConfig.getStringList("readConfig.option.columnNames").asScala.toList

    val controlSchema = controlColumnNames.map { _ + " String" }.mkString(",")
    val partitionByColLst = controlGroupConfig.getStringList("readConfig.option.partitionBy").asScala
    val partitionByString = partitionByColLst
      .toList.map{ _ + " String" }.mkString(",")

    // Control Group
    executeCreateExternalTableCommand(
      controlGroupConfig.getString("readConfig.option.path"), controlSchema,
      controlGroupConfig.getString("writeConfig.option.path"), partitionByString)

    // Control, Target and program control have only one column as schema(i.e. Customer) hence mapping them as same.
    executeCreateExternalTableCommand(
      targetGroupConfig.getString("readConfig.option.path"), controlSchema,
      targetGroupConfig.getString("writeConfig.option.path"), partitionByString)

    // Program Control Group
    executeCreateExternalTableCommand(
      programControlGroupConfig.getString("readConfig.option.path"), controlSchema,
      programControlGroupConfig.getString("writeConfig.option.path"), partitionByString)

    sparkSession.sql(s"refresh table ${targetGroupConfig.getString("readConfig.option.path")}").count()
    sparkSession.sql(s"refresh table ${controlGroupConfig.getString("readConfig.option.path")}").count()

    val targetGroupDF = DataFrameReadWriteFormat(targetGroupConfig.getConfig("readConfig"))
      .readDataFrame(sqlContext).distinct()
    val controlGroupDF = DataFrameReadWriteFormat(controlGroupConfig.getConfig("readConfig"))
      .readDataFrame(sqlContext).distinct()

    val knownCustomers = DataFrameUtility.unionDataFrame(targetGroupDF, controlGroupDF).distinct()

    val newCustomers = allocDF.select(customerColumnName).distinct()
      .except(knownCustomers.select(customerColumnName))

    newCustomers.persist()

    // TODO : check need of aliasing in below
    val pgControlRegex = programControlGroupConfig.getString("regex")
    val newProgramControlGroupDF = newCustomers.where(
      regexp_extract(col(customerColumnName), pgControlRegex, 1) =!= "")

    val control_weight = controlGroupConfig.getDouble("weight")
    val weight_split = Array(control_weight, 1.0 - control_weight)

    val customerSplit = newCustomers.randomSplit(weight_split, 0L)
    val newControlGroupDF = customerSplit(0)
    val newTargetGroupDF = customerSplit(1)

    val updatedControlGroupDF = DataFrameUtility.unionDataFrame(newControlGroupDF, controlGroupDF)
    val updatedTargetGroupDF = DataFrameUtility.unionDataFrame(newTargetGroupDF, targetGroupDF)

    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val propositionNameColumnName = postAllocationGlobalConfiguration.propositionNameColumnName

    val partitionColDirectory = Map(eventIdColumnName -> event, runDateColumnName -> runDate,
      propositionNameColumnName -> propositionName)

    val extraPath = partitionByColLst.foldLeft("/") { case (initialString, key) =>
      val value = partitionColDirectory(key)
      initialString + s"/$key=$value"
    }

    val basePathPcg = programControlGroupConfig.getString("writeConfig.option.path") + extraPath
    val basePathCg = controlGroupConfig.getString("writeConfig.option.path") + extraPath
    val basePathTg = targetGroupConfig.getString("writeConfig.option.path") + extraPath

    val tableNamesPartialFunc = controlFilesConfig.getConfig(_: String).getString("readConfig.option.path")
    val controlGroupTableName = tableNamesPartialFunc("controlGroup")
    val targetGroupTableName = tableNamesPartialFunc("targetGroup")
    val programControlGroupTableName = tableNamesPartialFunc("programControlGroup")

    sparkSession.sql(s"refresh table $controlGroupTableName").count()
    sparkSession.sql(s"refresh table $targetGroupTableName").count()
    sparkSession.sql(s"refresh table $programControlGroupTableName").count()

    DataFrameReadWriteFormat(programControlGroupConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(basePathPcg))).writeDataFrame(newProgramControlGroupDF)
    DataFrameReadWriteFormat(controlGroupConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(basePathCg))).writeDataFrame(newControlGroupDF)
    DataFrameReadWriteFormat(targetGroupConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(basePathTg))).writeDataFrame(newTargetGroupDF)

    sparkSession.sql(s"msck repair table $controlGroupTableName").count()
    sparkSession.sql(s"msck repair table $targetGroupTableName").count()
    sparkSession.sql(s"msck repair table $programControlGroupTableName").count()

    sparkSession.sql(s"refresh table $controlGroupTableName").count()
    sparkSession.sql(s"refresh table $targetGroupTableName").count()
    sparkSession.sql(s"refresh table $programControlGroupTableName").count()

    // Update Variation
    createMetaTable("variation", postAllocationConf.getConfig(s"$propositionName.metaCatalogue"))

    val litValuesMap = Map(eventIdColumnName -> event, runDateColumnName -> runDate)
    sparkSession.sql(s"refresh table ${postAllocationConf
      .getString(s"$propositionName.metaCatalogue.variation.tableName")}").count()
    val variationDF = DataFrameReadWriteFormat(variationConfig).readDataFrame(sqlContext)

    val latestVariationControlDF = variationDF.filter(col(propositionColumnName) === propositionName)
      .filter(col(typeColumnName) === controlTypeName)
      .orderBy(col(runDateColumnName).desc_nulls_last).limit(1)

    val latestVariationTargetDF = variationDF.filter(col(propositionColumnName) === propositionName)
      .filter(col(typeColumnName) === targetTypeName)
      .orderBy(col(runDateColumnName).desc_nulls_last).limit(1)

    val updatedVariationControlDF = litValues(latestVariationControlDF, litValuesMap)
    val updatedVariationTargetDF = litValues(latestVariationTargetDF, litValuesMap)

    val variationTableName = postAllocationConf.getString(s"$propositionName.metaCatalogue.variation.tableName")

    sparkSession.sql(s"refresh table $variationTableName").count()

    DataFrameReadWriteFormat(variationConfig).writeDataFrame(updatedVariationControlDF)
    DataFrameReadWriteFormat(variationConfig).writeDataFrame(updatedVariationTargetDF)

    sparkSession.sql(s"refresh table $variationTableName").count()

    Map(
      "controlGroupDF" -> updatedControlGroupDF,
      "targetGroupDF" -> updatedTargetGroupDF
    )
  }

  /**
    * Place the control weight split files on the file location after fetching relevant columns from allocationDF.
    *
    * @param allocDF            Final Allocation Recommendations
    * @param controlDFMap       ControlDF is Map containing two split of final customers
    * @param propositionConfig  Proposition Config
    * @param updatedEventID     Current Event Id
    * @param runDateDttm        Allocation Latest Run Date-Time
    */
  def generateSendControlFiles(allocDF: DataFrame,
                               controlDFMap: Map[String, DataFrame],
                               propositionConfig: Config,
                               updatedEventID: String,
                               runDateDttm: String
                               ): Unit = {

    val customerColumnName = postAllocationGlobalConfiguration.customerColumnName
    val controlGroupDF = controlDFMap("controlGroupDF")
    val targetGroupDF = controlDFMap("targetGroupDF")

    val allocationControlGroupDF = allocDF.join(controlGroupDF, Seq(customerColumnName), "inner").distinct()
    val allocationTargetGroupDF = allocDF.join(targetGroupDF, Seq(customerColumnName), "inner").distinct()

    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val typeName = postAllocationGlobalConfiguration.typeName
    val controlTypeName = postAllocationGlobalConfiguration.controlTypeName
    val targetTypeName = postAllocationGlobalConfiguration.targetTypeName

    val controlPathSuffix = s"/$eventIdColumnName=$updatedEventID" + s"/$typeName=$controlTypeName" +
      s"/$runDateColumnName=$runDateDttm"

    val targetPathSuffix = s"/$eventIdColumnName=$updatedEventID" + s"/$typeName=$targetTypeName" +
      s"/$runDateColumnName=$runDateDttm"

    val controlPath = propositionConfig.getString("allocationWarehouse.writeConfig.option.path") + controlPathSuffix
    val targetPath = propositionConfig.getString("allocationWarehouse.writeConfig.option.path") + targetPathSuffix

    val allocationWarehouseTableName = propositionConfig.getString("allocationWarehouse.readConfig.option.path")

    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    DataFrameReadWriteFormat(propositionConfig.getConfig("allocationWarehouse.writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(controlPath)))
      .writeDataFrame(allocationControlGroupDF)

    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    DataFrameReadWriteFormat(propositionConfig.getConfig("allocationWarehouse.writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(targetPath)))
      .writeDataFrame(allocationTargetGroupDF)

    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

  }

  /** Generate Final formatted files
    *
    * @param postAllocationConfig Post Allocation Config
    * @param propositionName propositionName
    * @param eventId eventId
    * @param trancheId trancheId
    * @param variationId evariationIdventId
    */
  def generateFinalFormattedFiles(postAllocationConfig: Config,
                                  propositionName: String,
                                  eventId: String,
                                  trancheId: String, variationId: String): Unit = {

    val finalOutputConfig = postAllocationConfig.getConfig(s"$propositionName.finalOutput")
    val destinations = finalOutputConfig.root().keySet().asScala.toList

    destinations.foreach { destinationName =>
      val destConfig = finalOutputConfig.getConfig(destinationName)

      val outputFiles = destConfig.root().keySet().asScala.toList

      val fileReplacementMap = Map(
        "{dttm}" -> runDate,
        "{evt}" -> eventId,
        "{alg}" -> propositionName,
        "{var}" -> variationId,
        "{tr}" -> trancheId
      )

      val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
      val typeColumnName = postAllocationGlobalConfiguration.typeName
      val controlColumnName = postAllocationGlobalConfiguration.controlTypeName
      val targetColumnName = postAllocationGlobalConfiguration.targetTypeName
      val programControlTypeName = postAllocationGlobalConfiguration.programControlTypeName

      val variationIdColumnName = postAllocationGlobalConfiguration.variationIdColumnName

      val variationTableName = postAllocationConfig.getString(s"$propositionName.metaCatalogue.variation.tableName")
      val variationTableDF = sparkSession.read.table(variationTableName)

      outputFiles.foreach {
        case "meta" =>
          val metaConfig = destConfig.getConfig("meta")
          // meta files pass to another function for formatting
          generateFinalMetaFiles(metaConfig, fileReplacementMap)
        case "recommendations" =>
          val recommendationConfig = destConfig.getConfig("recommendations")

          generateFinalAllocationFile(recommendationConfig, fileReplacementMap)
        case "control" =>
          val controlVariationID = variationTableDF
            .filter(col(runDateColumnName) === runDate)
            .filter(lower(col(typeColumnName)) === controlColumnName.toLowerCase)
            .head().getAs[String](variationIdColumnName)

          val controlConfig = destConfig.getConfig(controlColumnName)

          val modifiedFileReplacementMap = fileReplacementMap
            .updated("{var}", controlVariationID)

          generateFinalGroupFiles(controlConfig, modifiedFileReplacementMap, controlColumnName)
        case "target" =>
          val targetVariationID = variationTableDF
            .filter(col(runDateColumnName) === runDate)
            .filter(lower(col(typeColumnName)) === targetColumnName.toLowerCase)
            .head().getAs[String](variationIdColumnName)

          val targetConfig = destConfig.getConfig(targetColumnName)

          val modifiedFileReplacementMap = fileReplacementMap
            .updated("{var}", targetVariationID)

          generateFinalGroupFiles(targetConfig, modifiedFileReplacementMap, targetColumnName)
        case "programControl" =>
          val programControlVariationID = variationTableDF
            .filter(col(runDateColumnName) === runDate)
            .filter(lower(col(typeColumnName)) === programControlTypeName.toLowerCase)
            .head().getAs[String](variationIdColumnName)

          val programControlConfig = destConfig.getConfig(programControlTypeName)

          val modifiedFileReplacementMap = fileReplacementMap
            .updated("{var}", programControlVariationID)

          generateFinalGroupFiles(programControlConfig, modifiedFileReplacementMap, programControlTypeName)
      }
    }
  }

  /** Generate Final Group files
    *
    * @param groupConfig Group Config
    * @param fileReplacementMap: Map[String, String]
    * @param typeString Type value will signify if it is for control/target/programm-control
    */
  def generateFinalGroupFiles(groupConfig: Config,
                              fileReplacementMap: Map[String, String],
                              typeString: String): Unit = {


    val readConfig = groupConfig.getConfig("readConfig")
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val typeName = postAllocationGlobalConfiguration.typeName

    val eventId = fileReplacementMap("{evt}")
    val runDateDttm = fileReplacementMap("{dttm}")

    val modifiedDTTMString = modifyDTTMPattern(runDateDttm, groupConfig)

    sparkSession.sql(s"refresh table ${readConfig.getString("option.path")}").count()
    val groupDF = DataFrameReadWriteFormat(readConfig).readDataFrame(sparkSession.sqlContext)
      .filter(col(eventIdColumnName) === eventId)
      .filter(lower(col(typeName)) === typeString.toLowerCase)
      .filter(col(runDateColumnName) === runDateDttm)

    val writeConfig = groupConfig.getConfig("writeConfig")

    val fileNameTemplate = groupConfig.getString("fileNameTemplate")
    val startWithIndex = if (groupConfig.hasPath("startIndexForFile")) {
      groupConfig.getInt("startIndexForFile")
    } else {1}

    val fileExtension = if (writeConfig.hasPath("option.codec")) {
      writeConfig.getString("type").split("file.").last + ".gz"}
    else {
      writeConfig.getString("type").split("file.").last
    }

    val finalFileName = deriveFileName(fileNameTemplate, fileReplacementMap.updated("{dttm}", modifiedDTTMString))
    val writePath = writeConfig.getString("option.path") + s"/$runDateDttm/$finalFileName"
    val updatedConfig = writeConfig.withValue("option.path", ConfigValueFactory.fromAnyRef(writePath))

    DataFrameReadWriteFormat(updatedConfig).writeDataFrame(groupDF)

    // rename files
    val dotCompleteFlag = groupConfig.hasPath("dotComplete") && groupConfig.getBoolean("dotComplete")
    renameSparkFiles(writePath, finalFileName, fileExtension, dotCompleteFlag, startWithIndex)

    // write dot complete
    val overallDotCompleteFlag = groupConfig.hasPath("overallDotComplete") &&
      groupConfig.getBoolean("overallDotComplete")
    if (overallDotCompleteFlag) {
      val writePathParent = writeConfig.getString("option.path") + s"/$runDateDttm/"
      val completeFileBasePath = writePathParent + finalFileName
      createCompleteFile(completeFileBasePath)
    }
  }

  /** Generate Final Allocation files formatted as per client need, mentioned in the config
    *
    * @param recommendationConfig Recommendation Config
    * @param fileReplacementMap: Map[String, String]
    */
  def generateFinalAllocationFile(recommendationConfig: Config,
                                  fileReplacementMap: Map[String, String]): Unit = {

    val eventId = fileReplacementMap("{evt}")
    val runDateDttm = fileReplacementMap("{dttm}")
    val allocationReadConfig = recommendationConfig.getConfig("readConfig")

    val modifiedDTTMString = modifyDTTMPattern(runDateDttm, recommendationConfig)

    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val typeColumnName = postAllocationGlobalConfiguration.typeName
    val allocationTypeName = postAllocationGlobalConfiguration.allocationTypeName

    sparkSession.sql(s"refresh table ${allocationReadConfig.getString("option.path")}").count()
    val allocationDF = DataFrameReadWriteFormat(allocationReadConfig).readDataFrame(sparkSession.sqlContext)
    val filteredAllocationDF = allocationDF
      .filter(lower(col(typeColumnName)) === allocationTypeName.toLowerCase)
      .filter(col(eventIdColumnName) === eventId)
      .filter(col(runDateColumnName) === runDateDttm)

    val attachUUIDDF = if (recommendationConfig.hasPath("attachUUID")) {
      getUUID(filteredAllocationDF, recommendationConfig.getConfig("attachUUID"))
    } else {
      filteredAllocationDF
    }

    val transformedOutputDF = if (recommendationConfig.hasPath("transformOutput")) {
      val transformOutputConfig = recommendationConfig.getConfig("transformOutput")
      transformOutput(attachUUIDDF, transformOutputConfig)
    } else {
      attachUUIDDF
    }

    val writeConfig = recommendationConfig.getConfig("writeConfig")

    val fileNameTemplate = recommendationConfig.getString("fileNameTemplate")
    val startWithIndex = if (recommendationConfig.hasPath("startIndexForFile")) {
      recommendationConfig.getInt("startIndexForFile")
    } else {1}
    val fileExtension = if (writeConfig.hasPath("option.codec")) {
      writeConfig.getString("type").split("file.").last + ".gz"}
    else {
      writeConfig.getString("type").split("file.").last
    }
    val finalFileName = deriveFileName(fileNameTemplate, fileReplacementMap.updated("{dttm}", modifiedDTTMString))
    val writePath = writeConfig.getString("option.path") + s"/$runDateDttm/$finalFileName"
    val updatedConfig = if (writeConfig.hasPath("mergeFiles")) {
      writeConfig.withValue("option.path", ConfigValueFactory.fromAnyRef(writePath))
        .withValue("mergeFiles.path", ConfigValueFactory.fromAnyRef(writePath))
    } else {
      writeConfig.withValue("option.path", ConfigValueFactory.fromAnyRef(writePath))
    }


    DataFrameReadWriteFormat(updatedConfig).writeDataFrame(transformedOutputDF)

    val dotCompleteFlag = recommendationConfig.hasPath("dotComplete") && recommendationConfig.getBoolean("dotComplete")

    // rename all part files of the allocation as per the format in the config
    // and add dot complete file for each part file (optional - driven as per config)
    renameSparkFiles(writePath, finalFileName, fileExtension, dotCompleteFlag, startWithIndex)

    // write dot complete
    val overallDotCompleteFlag = recommendationConfig.hasPath("overallDotComplete") &&
      recommendationConfig.getBoolean("overallDotComplete")
    if (overallDotCompleteFlag) {
      val writePathParent = writeConfig.getString("option.path") + s"/$runDateDttm/"
      val completeFileBasePath = writePathParent + finalFileName
      createCompleteFile(completeFileBasePath)
    }
  }

  /** This method transpose column data into rows by applying groupBy on hshd_code and UUID.
    * for the given column names, their values will be transposed to columns
    *
    * eg, for given data
    * UUID, HSHD_CODE, IMAGE_URL, IMAGE_DESCRIPTION .....
    * U1, H1, IU1, ID1
    * U1, H1, IU2, ID2
    * U1, H1, IU3, ID3
    *
    * by grouping (UUID, HSHD_CODE) will be transposed to :
    *
    * UUID, IMAGE_URL1, IMAGE_URL2, IMAGE_URL3, IMAGE_DESCRIPTION1, IMAGE_DESCRIPTION2, IMAGE_DESCRIPTION3
    * U1,IU1,IU2,IU#,ID1,ID2,ID3
    *
    * This functions can also be used to just rename the column names
    *
    *
    * @param allocDF Allocation DF
    * @param transformOutputConfig Config
    * @return Transformed DataFrame
    */
  def transformOutput(allocDF: DataFrame, transformOutputConfig: Config): DataFrame = {

    val renameConfig = transformOutputConfig.getConfig("renameConfig")
    val keys = renameConfig.root().keySet().asScala.toList
    if (transformOutputConfig.hasPath("transform")) {
      val formattedDF = allocDF.withColumn("MechanicCode", concat(col("MechanicCode"), lit(".png")))

      val groupByColumns = transformOutputConfig.getStringList("transform.groupByColumns").asScala.toList
      val transformColumns = transformOutputConfig.getStringList("transform.transformColumns").asScala.toList
      val listLength = transformOutputConfig.getInt("transform.listLength")
      val aggList = keys.map{ key => collect_list(key).alias(key) }
      // collecting the given column values as a single list
      val aggAllocDF = formattedDF.select(transformColumns.map(col): _*).groupBy(groupByColumns.map(col): _*)
        .agg(aggList.head, aggList.tail: _*)

      val updateValueUDF = udf(
        (colList: mutable.WrappedArray[String], index: Int) => { colList.lift(index).orNull})

      val newColumns = keys.flatMap { column =>
        (0 until listLength).toList.map{ index =>
        val newColumn = renameConfig.getString(column).replace("{num}", (index + 1).toString)
          val updatedValue = updateValueUDF(col(column), lit(index))
          newColumn -> updatedValue
        }
      }.toMap

      val updatedDF = newColumns.foldLeft(aggAllocDF) { case (df, (key, value)) =>
        df.withColumn(key, value)
      }

      updatedDF.drop(keys: _*)

    } else {
      val renameMap = keys.map{ key =>
        (key, renameConfig.getString(key))
      }
      renameMap.foldLeft(allocDF) { case (df, (key, value)) =>
        df.withColumn(key, lit(value))
      }
    }
  }

  /** Get UUID
    *
    * @param allocDF Allocation DF
    * @param attachUUIDConfig Config
    * @return UUID DataFrame
    */
  def getUUID(allocDF: DataFrame, attachUUIDConfig: Config): DataFrame = {

    val customerColumnName = postAllocationGlobalConfiguration.customerColumnName

    val dbName = attachUUIDConfig.getString("dbName")

    val dotcomIdLookupQuery = s"""SELECT web_identity_code, hshd_code, web_identity_alt_code as UUID
        , b.EMAIL_CONTACT_TYPE_CODE, b.LOYAL_MAIL_SUPPRESS_CODE, b.status_code, b.ADHOC_SUPPRESS_CODE,
        c.current_flag, d.CREATED_DTTM, d.MODIFIED_DTTM, d.HSHD_ID FROM $dbName.web_identity_dim_c b
        INNER JOIN $dbName.identity_source_map_fct c ON b.web_identity_id = c.identity_2_id
        INNER JOIN $dbName.card_dim_c d ON c.identity_1_id = d.card_id
        """

    val dotcomIdLookupDF = sparkSession.sql(dotcomIdLookupQuery)
      .where("""EMAIL_CONTACT_TYPE_CODE is not null AND current_flag='Y' AND nvl(LOYAL_MAIL_SUPPRESS_CODE, '-') <> 'Y'
        AND status_code = '4' AND nvl(ADHOC_SUPPRESS_CODE, '-') NOT IN ('0','N','Y','1')
        AND substr(web_identity_code, 7, 2) <> '73'""")

    val hshdSegmentDF = DataFrameReadWriteFormat(attachUUIDConfig.getConfig("hshdSegment"))
      .readDataFrame(sparkSession.sqlContext)

    val hshdSegmentDotcomIdLookupDF = dotcomIdLookupDF.join(hshdSegmentDF,
      List("HSHD_ID"), "inner")

    val window = Window.partitionBy("UUID").orderBy(col("HSHD_SEG_LAST_SHOP_DATE_ID").desc)
    val latestShopDateIdDF = hshdSegmentDotcomIdLookupDF.withColumn("rowNumber", row_number().over(window))
      .where(col("rowNumber") === 1)
      .drop("rowNumber")
    allocDF.join(latestShopDateIdDF, allocDF(customerColumnName) === latestShopDateIdDF("hshd_code"), "inner")
  }

  /** Generate Final Formatted Meta files
    *  The meta data is present separately in each individual table(event, tranche and variation),
    *  this function will generate the final meta files, formatted as per the client.
    *
    * @param metaConfig Final Output Config
    * @param fileReplacementMap: Map[String, String]
    */
  def generateFinalMetaFiles(metaConfig: Config,
                             fileReplacementMap: Map[String, String]): Unit = {

    val eventId = fileReplacementMap("{evt}")
    val propositionName = fileReplacementMap("{alg}")
    val runDateDttm = fileReplacementMap("{dttm}")

    val modifiedDTTMString = modifyDTTMPattern(runDateDttm, metaConfig)

    val metaFilesNames = metaConfig.root().keySet().asScala.toList
    val propositionColumnName = postAllocationGlobalConfiguration.propositionNameColumnName
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName

    metaFilesNames.foreach { metaFileName =>
      val metaFileConfig = metaConfig.getConfig(metaFileName)

      val metaReadConfig = metaFileConfig.getConfig("readConfig")
      sparkSession.sql(s"refresh table ${metaReadConfig.getString("option.path")}").count()
      val metaDF = DataFrameReadWriteFormat(metaReadConfig).readDataFrame(sparkSession.sqlContext)

      // latest event row will be the only data that will be send to client
      val metaFilteredDF = metaDF
        .filter(col(propositionColumnName) === propositionName)
        .filter(col(runDateColumnName) === runDateDttm)
        .distinct()

      val writeConfig = metaFileConfig.getConfig("writeConfig")

      val fileNameTemplate = metaFileConfig.getString("fileNameTemplate")

      val fileExtension = if (writeConfig.hasPath("option.codec")) {
        writeConfig.getString("type").split("file.").last + ".gz"}
      else {
        writeConfig.getString("type").split("file.").last
      }
      val finalFileName = deriveFileName(fileNameTemplate, fileReplacementMap.updated("{dttm}", modifiedDTTMString))
      val writePath = writeConfig.getString("option.path") + s"/$runDateDttm/$finalFileName"
      val updatedConfig = writeConfig.withValue("option.path", ConfigValueFactory.fromAnyRef(writePath))

      DataFrameReadWriteFormat(updatedConfig).writeDataFrame(metaFilteredDF)

      // rename files
      val dotCompleteFlag = metaConfig.hasPath(s"$metaFileName.dotComplete") &&
        metaConfig.getBoolean(s"$metaFileName.dotComplete")

      renameSparkFiles(writePath, finalFileName, fileExtension, dotCompleteFlag)
    }
  }

  /** Modify the Event RunDate DTTM as per the format to be send to the client as mentioned in the config
    *
    * @param actualDateString Actual Event Date
    * @param config Config
    * @param originalPattern Original Pattern
    * @return Modified DTTM String
    */
  def modifyDTTMPattern(actualDateString: String, config: Config,
                        originalPattern: String = "yyyyMMddHHmmss"): String = {

    val modifiedDTTMString = if (config.hasPath("dttmFormat")) {
      val newFormat = new SimpleDateFormat(originalPattern)
      val actualRunDateDTTM = new DateTime(newFormat.parse(actualDateString))
      val dttmFormat = config.getString("dttmFormat")
      DateTimeFormat.forPattern(dttmFormat).print(actualRunDateDTTM)
    } else {
      actualDateString
    }

    modifiedDTTMString
  }

  /** Insert Initial Data for all the Meta Files (reading default values from input config)
    *
    * @param sqlContext SQLContext
    * @param metaName Meta Name
    * @param metaCatalogueConfig Meta Catalogue Config
    * @param mandatoryColumnsKeyValueMap Mandatory Default Column Names
    */
  def insertInitialMetaData(sqlContext: SQLContext, metaName: String, metaCatalogueConfig: Config,
                            mandatoryColumnsKeyValueMap: Map[String, String]): Unit = {
    val metaConfig = metaCatalogueConfig.getConfig(s"$metaName")
    val metaInitialParamsList = metaConfig.getConfigList("initialParams").asScala.toList
    val mandatoryColumnKeys = mandatoryColumnsKeyValueMap.keys.toList
    val keys = metaInitialParamsList.head.root().keySet().asScala.toList
    val keySet = mandatoryColumnKeys ++ keys

    val rowList = metaInitialParamsList.map{metaInitialParams =>
      val values = mandatoryColumnKeys.map(mandatoryColumnsKeyValueMap) ++
        keys.map(metaInitialParams.getString)
      Row.fromSeq(values)
    }
    val metaDataConfig = metaConfig.getConfig("readWriteConfig")
    val metaInitialParamsRowList = sparkSession.sparkContext.parallelize(rowList)

    val metaInitialRowSchema = StructType(keySet.map(StructField(_, StringType)))

    val metaInitialDF = sqlContext.createDataFrame(metaInitialParamsRowList, metaInitialRowSchema)
    DataFrameReadWriteFormat(metaDataConfig).writeDataFrame(metaInitialDF)
  }

  /** Create Tables For All Meta Files
    *
    * @param metaName                    Meta Name
    * @param metaCatalogueConfig         Meta Catalogue Config
    * @param mandatoryDefaultColumnNames Mandatory Default Column Names
    */
  def createMetaTable(metaName: String, metaCatalogueConfig: Config,
                      mandatoryDefaultColumnNames: List[String] = List("proposition_name", "run_time")
                     ): Unit = {
    val metaConfig = metaCatalogueConfig.getConfig(s"$metaName")
    val metaTable = metaConfig.getString("tableName")
    val initialParamsKeys = metaConfig.getConfigList("initialParams").asScala.toList.head.root().keySet().asScala.toList
    val metaSchema = (mandatoryDefaultColumnNames ++ initialParamsKeys).toSet.map { x: String =>
      x + " " + "String"
    }.mkString(",")
    val partitionByString = if (metaConfig.hasPath("readWriteConfig.option.partitionBy")) {
      metaConfig.getStringList("readWriteConfig.option.partitionBy")
        .asScala.toList.map{ _ + " String" }.mkString(",")
    } else {
      ""
    }
    val path = metaConfig.getString("readWriteConfig.option.path")
    executeCreateExternalTableCommand(metaTable, metaSchema, path, partitionByString)
  }

  /** Create External Table If Not Exist
    *
    * @param tableName Table Name
    * @param tableSchema Table Schema String
    * @param dataPath Path which, the external table will be referring
    * @param partitionByString Partition By String - format - "columnName x, columnName y, columnName z";
    *                          By default empty string
    */
  def executeCreateExternalTableCommand(tableName: String, tableSchema: String,
                                        dataPath: String, partitionByString: String = ""): Unit = {

    // TODO - need to ask for permissions for creating table
    val createTableCommand = s"""
                                |CREATE EXTERNAL TABLE IF NOT EXISTS $tableName ($tableSchema)
                                |COMMENT 'This table is created for $tableName'
                                |${if (partitionByString.nonEmpty) {s"PARTITIONED BY ($partitionByString)"} else ""}
                                |ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
                                |STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
                                |OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
                                |LOCATION '$dataPath'
                                |""".stripMargin

    sparkSession.sql(createTableCommand)
  }

  /** Given a input map, it adds the input map keys as column and lit the given values
    *
    * @param inputDF Input DF
    * @param dict Dict containing columnName -> columnValue
    * @return Lit values added DataFrame
    */
  def litValues(inputDF: DataFrame, dict: Map[String, String]): DataFrame = {
    dict.foldLeft(inputDF) {
      case (df, (colName, colValue)) => df.withColumn(colName, lit(colValue))
    }
  }

  /** Derive File Name by replacing the placeholders with the in-context map values
    *
    * eg. for given file_string : event_speoff_{dttm} and
    *     given map : Map("{dttm}" -> runDateDttm, "{evt}" -> eventId,
    *                     "{alg}" -> propositionName)
    *
    * the event_speoff_{dttm} will become event_speoff_201810111234
    *
    * @param fileString input file string
    * @param stringReplacementMap file replacement map
    * @return Derived File Name
    */
  def deriveFileName(fileString: String, stringReplacementMap: Map[String, String]): String = {

    stringReplacementMap.foldLeft(fileString) { case (inputString, (replacementKey, replacementValue)) =>
      inputString.replace(replacementKey, replacementValue)
    }
  }

  /** Create Complete File
    *
    * @param path Path
    * @param suffix Suffix = .complete
    */
  def createCompleteFile(path: String, suffix: String = ".complete"): Unit = {
    fs.createNewFile(new Path(path + suffix))
  }

  /** Rename Files, also add file part number
    *
    * @param path Path to be renamed
    * @param fileName Final File Name
    * @param fileExtension File Extension
    * @param dotCompleteFlag Dot Complete Flag for individual files
    * @param startWith start the index with some value passed, by default 1.
    */
  def renameSparkFiles(path: String,
                       fileName: String,
                       fileExtension: String,
                       dotCompleteFlag: Boolean,
                       startWith: Int = 1): Unit = {

    val files = fs.globStatus(new Path(path + "/part*")).map(_.getPath.getName).toList
    if (files.isEmpty) {
      val dirs = fs.globStatus(new Path(path + "/*")).map(_.getPath.getName).toList
      if (dirs.nonEmpty) {
        dirs.foreach{dir =>
          val internalPathString = s"${path}/$dir"
          val partitionedCol = dir.split("=").last
          val internalFiles = fs.globStatus(new Path(s"${internalPathString}/part*")).map(_.getPath.getName).toList
          if (internalFiles.size == 1) {
            val srcPath = new Path(internalPathString + s"/${internalFiles.head}")
            val splittedPath = internalPathString.split('/')
            val modPath = splittedPath.take(splittedPath.length - 2).mkString("/")
            val renamePath = if (startWith != 1) {
              new Path(s"${modPath}/${fileName}_${partitionedCol}_${startWith}.$fileExtension")}
            else {new Path(s"${modPath}/${fileName}_${partitionedCol}.$fileExtension")}

            fs.rename(srcPath, renamePath)
            if (dotCompleteFlag) {
              createCompleteFile(renamePath.toString)
            }
          } else {
            val zippedFilesList = internalFiles.zipWithIndex// .map(x => (x._1, x._2 + 1))
            zippedFilesList.foreach{ case (partFile, index) =>
              val initialPath = new Path(s"$internalPathString/$partFile")
              // scalastyle:off
              println(s"initialPath => $initialPath")
              val splittedPath = internalPathString.split('/')
              val modPath = splittedPath.take(splittedPath.length - 2).mkString("/")
              val renamePath =
                new Path(s"$modPath/${fileName}_${partitionedCol}_${index + startWith}.$fileExtension")
              println(s"renamePath => $renamePath")
              // scalastyle:on
              fs.rename(initialPath, renamePath)
              if (dotCompleteFlag) {
                createCompleteFile(renamePath.toString)
              }
            }
          }
        }
      }
    }
    else if (files.size == 1) {
      val srcPath = new Path(path + s"/${files.head}")
      val splittedPath = path.split('/')
      val modPath = splittedPath.take(splittedPath.length - 1).mkString("/")
      val renamePath = new Path(s"${modPath}/$fileName.$fileExtension")
      fs.rename(srcPath, renamePath)
      if (dotCompleteFlag) {
        createCompleteFile(renamePath.toString)
      }
    }
    else {
      val zippedFilesList = files.zipWithIndex// .map(x => (x._1, x._2 + 1))
      zippedFilesList.foreach{ case (partFile, index) =>
        val initialPath = new Path(s"$path/$partFile")
        // scalastyle:off
        println(s"initialPath => $initialPath")
        val splittedPath = path.split('/')
        val modPath = splittedPath.take(splittedPath.length - 1).mkString("/")
        val renamePath = new Path(s"$modPath/${fileName}_${index + startWith}.$fileExtension")
        println(s"renamePath => $renamePath")
        // scalastyle:on
        fs.rename(initialPath, renamePath)
        if (dotCompleteFlag) {
          createCompleteFile(renamePath.toString)
        }
      }
    }
    fs.delete(new Path(path), true)
  }
  }

/** PostAllocationHelper Companion Object
  *
  */
object PostAllocationHelper {

  /** Default Constructor
    *
    * @param sparkSession Spark Session Object
    * @param applicationConfig Application Config
    * @param propositionName Proposition Name
    * @param runDate Run Date
    * @param fs FileSystem Object
    * @return PostAllocationHelper Object
    */
  def apply(sparkSession: SparkSession, applicationConfig: Config,
            propositionName: String, runDate: String, fs: FileSystem): PostAllocationHelper = {
    val postAllocationGlobalConfiguration = new PostAllocationGlobalConfiguration(applicationConfig)
    new PostAllocationHelper(sparkSession, postAllocationGlobalConfiguration, propositionName, runDate, fs)
  }
}