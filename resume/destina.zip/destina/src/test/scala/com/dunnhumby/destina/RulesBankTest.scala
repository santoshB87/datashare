package com.dunnhumby.destina

import java.io.File
import java.sql.Date

import scala.collection.JavaConverters._

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.scalatest.{BeforeAndAfterEach, FunSuite}

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.core.unittest.dataframe.DataFrameUtility.assertDataFrame
import com.dunnhumby.core.unittest.sharedcontext.SharedSparkSession

// scalastyle:off scaladoc
class RulesBankTest extends FunSuite with SharedSparkSession with BeforeAndAfterEach {
  Logger.getRootLogger.setLevel(Level.ERROR)

  val applicationConfig: Config = ConfigFactory.load("application")

  override def beforeEach(): Unit = {
    super.beforeEach()
    new File("metastore_db/db.lck").delete()
    new File("metastore_db/dbex.lck").delete()
  }

  override def beforeAll(): Unit = {
    super.beforeAll()
    sqlContext.setConf("spark.sql.shuffle.partitions", "1")
    val configPath = "/com/dunnhumby/destina/PromoTableWrite.json"
    val configResource = getClass.getResource(configPath).getFile
    val configFile = new File(configResource)
    val config = ConfigFactory.parseFile(configFile)
    val format = DataFrameReadWriteFormat(config)
    val promoCSVPath = "src/test/resources/com/dunnhumby/destina/promo.csv"
    val promoCSVReadConfig = ConfigFactory.parseString(
      s"""
         |{
         |  "type": "file.csv",
         |  "option": {
         |    "path": $promoCSVPath,
         |    "header": true,
         |    "inferSchema": true
         |  }
         |}
      """.stripMargin)
    val csvReadDF = DataFrameReadWriteFormat(promoCSVReadConfig).readDataFrame(sqlContext)

    format.writeDataFrame(csvReadDF)
  }

  test("RulesBankTest - getAllocationLevel should return a joined DF between promoDF & StoreDF " +
    "as allocation level is not present") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._
    val promoDF = Seq(
      ("aq8", "bat", "Store1", "Banner1"),
      ("pq4", "ball", "Store2", "Banner2"),
      ("de7", "bag", "Store3", "Banner3")
    ).toDF("Promotion", "Product", "Store", "Banner")

    val storeDF = Seq(
      ("Rob", "bat", "Store1", "Region1"),
      ("John", "ball", "Store2", "Region2"),
      ("Arya", "bag", "Store3", "Region3")
    ).toDF("Customer", "Product", "Store", "Region")

    val allocationLevel = "Region"

    val config = ConfigFactory.parseString(
      """{
        | allocationLevel: "Region",
        | joinKey: ["Store", "Product"]
        |}""".stripMargin)

    val actualDataFrame = RulesBank(applicationConfig, sparkSession)
      .getAllocationLevel(storeDF, promoDF, config).head

    val expectedDataFrame = Seq(
      ("aq8", "bat", "Store1", "Banner1", "Region1"),
      ("pq4", "ball", "Store2", "Banner2", "Region2"),
      ("de7", "bag", "Store3", "Banner3", "Region3")
    ).toDF("Promotion", "Product", "Store", "Banner", "Region")
    assertDataFrame(actualDataFrame, expectedDataFrame)
  }

  test("RulesBankTest - getAllocationLevel should return the promoDF since allocation level is " +
    "present in promoDF ") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._
    val promoDF = Seq(
      ("aq8", "bat", "Store1", "Banner1"),
      ("pq4", "ball", "Store2", "Banner2"),
      ("de7", "bag", "Store3", "Banner3")
    ).toDF("Promotion", "Product", "Store", "Banner")

    val storeDF = Seq(
      ("Rob", "bat", "Store1"),
      ("John", "ball", "Store2"),
      ("Arya", "bag", "Store3")
    ).toDF("Customer", "Product", "Store")

    val config = ConfigFactory.parseString(
      """{
        | allocationLevel: "Banner",
        | joinKey: ["Store", "Product"]
        |}""".stripMargin)

    val actualDataFrame = RulesBank(applicationConfig, sparkSession)
      .getAllocationLevel(storeDF, promoDF, config).head

    assertDataFrame(actualDataFrame, promoDF)
  }

  test("RulesBankTest - getAllocationLevelForNonRP should return a joinedDF between scoreDF and " +
    "FeatureDF along with filtered condition ") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._
    val featureDF = Seq(
      ("Rob", "bat", "Store1", 3),
      ("John", "ball", "Store2", 10),
      ("Arya", "bag", "Store3", 5)
    ).toDF("Customer", "Product", "Store", "Basket")

    val scoreDF = Seq(
      ("Rob", "bat", .01),
      ("John", "ball", 0.9),
      ("Arya", "bag", 0.5)
    ).toDF("Customer", "Product", "Score")

    val expectedDataFrame = Seq(
      ("ball", "John", "Store2", 10, .9)
    ).toDF("Product", "Customer", "Store", "Basket", "Score")

    val config = ConfigFactory.parseString(
      """{
        | filterCondition: "Basket > 5"
        | joinKey: ["Product", "Customer"]
        |}""".stripMargin)

    val actualDataFrame = RulesBank(applicationConfig, sparkSession)
      .getAllocationLevelForNonRP(scoreDF, featureDF, config).head

    assertDataFrame(actualDataFrame, expectedDataFrame)
  }

  test("RulesBankTest - Get Promos - Keeping Inactive Promos") {
    val readConfig = ConfigFactory.parseString(
      """
        |{
        |  "type": "table.hive",
        |  "option": {
        |    "path": "t1",
        |    "columnList": ["promotion_id", "store_code", "product_code", "promo_start", "promo_end"]
        |  },
        |  "parameter": {
        |    "keepInactivePromos": true,
        |    "promoActiveDays": 7,
        |    "activeDaysOffset": 0
        |  }
        |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).getPromos(readConfig)
      .head

    val expectedDFSchema = StructType(
      Array(
        StructField("promotion_id", IntegerType),
        StructField("store_code", IntegerType),
        StructField("product_code", LongType),
        StructField("promo_start", DateType),
        StructField("promo_end", DateType),
        StructField("sqoop_load_date", DateType)
      )
    )

    val expectedRowList = List(
      Row(3046755, 31071, 2003010637851L,
        Date.valueOf("2019-03-28"),
        Date.valueOf("2019-06-26"),
        Date.valueOf("2019-05-25")
      ),
      Row(3046755, 31098, 2003010637851L,
        Date.valueOf("2019-03-28"),
        Date.valueOf("2019-06-26"),
        Date.valueOf("2019-05-25")
      )
    )
    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)
      .withColumn("promo_start", col("promo_start").cast(TimestampType))
      .withColumn("promo_end", col("promo_end").cast(TimestampType))
      .withColumn("sqoop_load_date", col("sqoop_load_date").cast(TimestampType))
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Get Promos - Discarding Inactive Promos") {
    val readConfig = ConfigFactory.parseString(
      """
        |{
        |  "type": "table.hive",
        |  "option": {
        |    "path": "t1",
        |    "columnList": ["promotion_id", "store_code", "product_code", "promo_start", "promo_end"]
        |  },
        |  "parameter": {
        |    "keepInactivePromos": false,
        |    "promoActiveDays": 7,
        |    "activeDaysOffset": 0
        |  }
        |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).getPromos(readConfig)
      .head

    val expectedDFSchema = StructType(
      Array(
        StructField("promotion_id", IntegerType),
        StructField("store_code", IntegerType),
        StructField("product_code", LongType),
        StructField("promo_start", TimestampType),
        StructField("promo_end", TimestampType),
        StructField("sqoop_load_date", TimestampType)
      )
    )
    val expectedDF = sparkSession.createDataFrame(sc.emptyRDD[Row], expectedDFSchema)
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Join DataFrame should return attribute added DataFrame") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val xDF = Seq(
      ("Rob", "bat", 0.01),
      ("John", "ball", 0.9),
      ("Arya", "bag", 0.5)
    ).toDF("Customer", "Product", "Score")

    val yDF = Seq(
      ("Rob", "bat", "Store1", 3),
      ("John", "ball", "Store2", 10)
    ).toDF("Customer", "Product", "Store", "Basket")

    val expectedDF = Seq(
      ("Rob", "bat", 0.01, "Store1", 3),
      ("John", "ball", 0.9, "Store2", 10)
    ).toDF("Customer", "Product", "Score", "Store", "Basket")

    val joinColumnList = List("Customer", "Product").asJava
    val columnList = List("Store", "Basket").asJava

    val joinConfig = ConfigFactory.parseString(
      s"""
        {
          "joinColumnList": $joinColumnList,
          "columns": $columnList
        }""".stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).joinDataFrame(xDF, yDF, joinConfig)
      .head
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Join DataFrame should return attribute added DataFrame and filter") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val xDF = Seq(
      ("Rob", "bat", .01),
      ("John", "ball", 0.9),
      ("Arya", "bag", 0.5)
    ).toDF("Customer", "Product", "Score")

    val yDF = Seq(
      ("Rob", "bat", "Store1", 3),
      ("John", "ball", "Store2", 10)
    ).toDF("Customer", "Product", "Store", "Basket")

    val expectedDF = Seq(
      ("Rob", "bat", 0.01, "Store1", 3)
    ).toDF("Customer", "Product", "Score", "Store", "Basket")

    val joinColumnList = List("Customer", "Product").asJava
    val columnList = List("Store", "Basket").asJava

    val joinConfig = ConfigFactory.parseString(
      s"""
        {
          "joinColumnList": $joinColumnList,
          "columns": $columnList,
          "filterCondition": "Customer = 'Rob' AND Product = 'bat'"
        }""".stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .joinDataFrame(xDF, yDF, joinConfig).head
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - GeneratePosition should return correct positions of column ") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1"),
      ("C1", "P2", "Pr1", "0.5", "1", "G1"),
      ("C1", "P3", "Pr1", "0.9", "2", "G1"),
      ("C1", "P3", "Pr2", "0.8", "1", "G2"),
      ("C1", "P4", "Pr2", "0.6", "1", "G2"),
      ("C1", "P5", "Pr2", "0.9", "1", "G2")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "Group")

    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", 1),
      ("C1", "P2", "Pr1", "0.5", "1", "G1", 2),
      ("C1", "P3", "Pr1", "0.9", "2", "G1", 3),
      ("C1", "P3", "Pr2", "0.8", "1", "G2", 2),
      ("C1", "P4", "Pr2", "0.6", "1", "G2", 3),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", 1)
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "Group", "OfferPosition")


    val config = ConfigFactory.parseString(
      """{
        | partitionByCol: ["customer", "group"],
        | rankColName: "OfferPosition",
        | orderByCol: [
        |   {
        |     "colName": "scoreType",
        |     "sortOrder": "asc"
        |   },
        |   {
        |     "colName": "score",
        |     "sortOrder": "desc"
        |   }
        | ]
        |}""".stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).generatePosition(inputDF, config)
      .head

    assertDataFrame(actualDF, expectedDF)

  }

  test("RulesBankTest - createScore should create correct score using rank column ") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val df = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", 1),
      ("C1", "P2", "Pr1", "0.5", "1", "G1", 2),
      ("C1", "P3", "Pr1", "0.9", "2", "G1", 3),
      ("C1", "P3", "Pr2", "0.8", "1", "G2", 2),
      ("C1", "P4", "Pr2", "0.6", "1", "G2", 3),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", 1)
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "Group", "OfferPosition")


    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", 1, "1.00000000"),
      ("C1", "P2", "Pr1", "0.5", "1", "G1", 2, "0.50000000"),
      ("C1", "P3", "Pr1", "0.9", "2", "G1", 3, "0.33333333"),
      ("C1", "P3", "Pr2", "0.8", "1", "G2", 2, "0.50000000"),
      ("C1", "P4", "Pr2", "0.6", "1", "G2", 3, "0.33333333"),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", 1, "1.00000000")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "Group", "OfferPosition", "NewScore")

    val createScoreConfig = ConfigFactory.parseString(
      s"""
         |{
            "rankingColumn": "OfferPosition",
            "outputColumn": "NewScore",
            "roundValue": 8,
            "scoreLength": 8
          }
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).createScore(df, createScoreConfig)
      .head

    assertDataFrame(actualDF, expectedDF)

  }

  test("RulesBankTest - createOfferRelevance should create correct relevance ") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val df = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", 1, "1.00000000"),
      ("C1", "P2", "Pr1", "0.5", "1", "G1", 2, "0.50000000"),
      ("C1", "P3", "Pr1", "0.9", "2", "G1", 3, "0.33333333"),
      ("C1", "P3", "Pr2", "0.8", "1", "G2", 2, "0.50000000"),
      ("C1", "P4", "Pr2", "0.6", "1", "G2", 3, "0.33333333"),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", 1, "1.00000000")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "Group", "OfferPosition", "NewScore")


    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", 1, "1.00000000", "1.00000000"),
      ("C1", "P2", "Pr1", "0.5", "1", "G1", 2, "0.50000000", "1.00000000"),
      ("C1", "P3", "Pr1", "0.9", "2", "G1", 3, "0.33333333", "1.00000000"),
      ("C1", "P3", "Pr2", "0.8", "1", "G2", 2, "0.50000000", "1.00000000"),
      ("C1", "P4", "Pr2", "0.6", "1", "G2", 3, "0.33333333", "1.00000000"),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", 1, "1.00000000", "1.00000000")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "Group", "OfferPosition",
      "NewScore", "OfferRelevance")


    val createOfferRelevanceConfig = ConfigFactory.parseString(
      s"""
         |{
         | "partitionCol": ["customer", "group", "promotion"],
         | "productRelevance": "NewScore",
         | "offerRelevance": "OfferRelevance"
         |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .createOfferRelevance(df, createOfferRelevanceConfig).head

    assertDataFrame(actualDF, expectedDF)

  }

  test("RulesBankTest - Apply Exclusion - should return a DataFrame based on the apt filter" +
    "conditions passed through the config") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val config = ConfigFactory.parseString(
      """{
        | exclusionRulesList: [
        |   {
        |     "col": "Introstoreshelf",
        |     "values": ["F", "B", "G", "N"],
        |     "condition": "=",
        |     "substring_length": "1"
        |   },
        |   {
        |     "col": "Introstoreshelf",
        |     "values": ["N78A"],
        |     "condition": "!=",
        |     "substring_length": "4"
        |   },
        |   {
        |     "col": "Introstoreshelf",
        |     "values": ["N81AF", "N53AA", "N53AC", "N53AE", "FQ1234"],
        |     "condition": "=",
        |     "substring_length": ""
        |   },
        |   {
        |     "col": "Introstoreshelf",
        |     "values": ["N57", "N58"],
        |     "condition": "!=",
        |     "substring_length": "3"
        |   },
        |   {
        |     "col": "Discount",
        |     "values": [3],
        |     "condition": ">",
        |     "substring_length": ""
        |   }
        | ]
        |}""".stripMargin)

    val inputDF = Seq(
      ("FQ1234", 10),
      ("BQ12345", 30),
      ("GQ12345", 10),
      ("NQ12345", 10),
      ("CC", 10),
      ("MC", 10),
      ("FA12345", 10),
      ("BA12345", 30),
      ("GAAA12345", 10),
      ("NZZAA12345", 10),
      ("FZZAA12345", 1),
      ("BZA564", 30),
      ("GZA564", 10),
      ("N78AQ", 10),
      ("N81AF", 10),
      ("N53AA", 10),
      ("N53AC", 10),
      ("N57AE", 10),
      ("N58EL", 10),
      ("N513EL", 10)
    ) toDF("Introstoreshelf", "Discount")

    val actualDataFrame = RulesBank(applicationConfig, sparkSession).applyExclusion(inputDF, config)
      .head

    val expectedDataFrame = Seq(
      ("FQ1234", 10),
      ("N81AF", 10),
      ("N53AA", 10),
      ("N53AC", 10)
    ) toDF("Introstoreshelf", "Discount")

    assertDataFrame(actualDataFrame, expectedDataFrame)
  }

  test("RulesBankTest - Apply Ranging - RP - With Feature DataFrame and With Customer Ranging") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val featureDF = Seq(
      ("Rob", "bat", "S3"),
      ("Rob", "ball", "S2"),
      ("Billy", "bat", "S1"),
      ("Billy", "ball", "S2"),
      ("Billy", "ball", "S3")
    ).toDF("Customer", "Product", "Store")

    val allocationDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "bat", "S1", "Pr2"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Billy", "ball", "S3", "Pr3")
    ).toDF("Customer", "Product", "Store", "Promo")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(allocationDF, explodedDF, Some(featureDF), config).head

    val expectedDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "ball", "S3", "Pr3"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "bat", "S1", "Pr2")
    ).toDF("Customer", "Product", "Store", "Promo")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Ranging - RP - With Feature DataFrame and " +
    "With Customer Ranging with No Allocation Level") {

    val applicationConfig = ConfigFactory.parseFile(new File("src/test/resources/AllocationLevelEmptyApplication.conf"))
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val featureDF = Seq(
      ("Rob", "bat", "S3"),
      ("Rob", "ball", "S2"),
      ("Billy", "bat", "S1"),
      ("Billy", "ball", "S2"),
      ("Billy", "ball", "S3")
    ).toDF("Customer", "Product", "Store")

    val allocationDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "bat", "S1", "Pr2"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Billy", "ball", "S3", "Pr3")
    ).toDF("Customer", "Product", "Store", "Promo")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(allocationDF, explodedDF, Some(featureDF), config).head

    val expectedDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "bat", "S1", "Pr2")
    ).toDF("Customer", "Product", "Store", "Promo")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Ranging - RP - With Feature DataFrame and Without Customer Ranging") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val featureDF = Seq(
      ("bat", "S3"),
      ("ball", "S1"),
      ("bat", "S1"),
      ("ball", "S2"),
      ("ball", "S3")
    ).toDF("Product", "Store")

    val allocationDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "bat", "S1", "Pr2"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Billy", "ball", "S3", "Pr3")
    ).toDF("Customer", "Product", "Store", "Promo")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(allocationDF, explodedDF, Some(featureDF), config).head

    val expectedDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "bat", "S1", "Pr2"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Billy", "ball", "S3", "Pr3")
    ).toDF("Customer", "Product", "Store", "Promo")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Ranging - RP - Without Feature DataFrame") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val allocationDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "bat", "S1", "Pr2"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Billy", "ball", "S3", "Pr3")
    ).toDF("Customer", "Product", "Store", "Promo")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(allocationDF, explodedDF, None, config).head

    val expectedDF = Seq(
      ("Rob", "bat", "S3", "Pr1"),
      ("Billy", "bat", "S1", "Pr2"),
      ("Rob", "ball", "S2", "Pr2"),
      ("Billy", "ball", "S2", "Pr1"),
      ("Billy", "ball", "S3", "Pr3")
    ).toDF("Customer", "Product", "Store", "Promo")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Product Store Ranging - Non RP - With Feature DataFrame and With Customer Ranging") {

    val applicationConfig = ConfigFactory.parseFile(new File("src/test/resources/AllocationLevelEmptyApplication.conf"))
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val featureDF = Seq(
      ("Rob", "bat", "S3"),
      ("Rob", "ball", "S1"),
      ("Billy", "bat", "S1"),
      ("Billy", "ball", "S2"),
      ("Billy", "ball", "S3")
    ).toDF("Customer", "Product", "Store")

    val scoreDF = Seq(
      ("Rob", "bat", 0.02),
      ("Billy", "ball", 0.02),
      ("Billy", "bat", 0.01),
      ("Billy", "ball", 0.02)
    ).toDF("Customer", "Product", "Score")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "non-rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(scoreDF, explodedDF, Some(featureDF), config).head

    val expectedDF = Seq(
      ("Rob", "bat", 0.02, "S3"),
      ("Billy", "bat", 0.01, "S1"),
      ("Billy", "ball", 0.02, "S1")
    ).toDF("Customer", "Product", "Score", "Store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Product Store Ranging - Non RP - With Feature DataFrame and Without Customer Ranging") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val featureDF = Seq(
      ("bat", "S3"),
      ("ball", "S1"),
      ("bat", "S1"),
      ("ball", "S2"),
      ("ball", "S3")
    ).toDF("Product", "Store")

    val scoreDF = Seq(
      ("Rob", "bat", 0.02),
      ("Billy", "ball", 0.02),
      ("Billy", "bat", 0.01),
      ("Billy", "ball", 0.02)
    ).toDF("Customer", "Product", "Score")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "non-rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(scoreDF, explodedDF, Some(featureDF), config).head

    val expectedDF = Seq(
      ("Rob", "bat", 0.02, "S3"),
      ("Billy", "ball", 0.02, "S3"),
      ("Billy", "ball", 0.02, "S2"),
      ("Billy", "bat", 0.01, "S3"),
      ("Billy", "bat", 0.01, "S1"),
      ("Billy", "ball", 0.02, "S1")
    ).toDF("Customer", "Product", "Score", "Store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Product Store Ranging - Non RP - Without Feature DataFrame") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val scoreDF = Seq(
      ("Rob", "bat", 0.02, "S2"),
      ("Rob", "ball", 0.02, "S1"),
      ("Billy", "ball", 0.02, "S2"),
      ("Billy", "bat", 0.01, "S4"),
      ("Billy", "ball", 0.02, "S3")
    ).toDF("Customer", "Product", "Score", "Store")

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("Customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "propositionType": "non-rp",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val explodedDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRanging(scoreDF, explodedDF, None, config).head

    val expectedDF = Seq(
      ("Rob", "bat", 0.02, "S2"),
      ("Billy", "ball", 0.02, "S3"),
      ("Billy", "ball", 0.02, "S2")
    ).toDF("Customer", "Product", "Score", "Store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Implement Special Category Limit should return limit " +
    "applied to special category products - Substring Match - Customer required") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val specialCategoryConfig = ConfigFactory.parseString(
      """{
        | "productIdentifierColumnName": "product",
        | "isCustomerRequired": true,
        | "substringLength" : 2,
        | "productIdentifiers": ["ba"],
        | "recommendedValue": 2
        |}
      """.stripMargin)
    val inputDF = Seq(
      ("Rob", "bat", 0.04, "Store", "1"),
      ("Rob", "bat", 0.02, "Store", "1"),
      ("Rob", "bat", 0.03, "Store", "1"),
      ("Billy", "ball", 0.01, "Store", "1"),
      ("Billy", "ball", 0.02, "Store", "1"),
      ("Billy", "ball", 0.03, "Store", "1"),
      ("Morty", "badminton", 0.01, "Store", "1")
    ).toDF("Customer", "Product", "Score", "Store", "Type")

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applySpecialCategoryCapping(inputDF, specialCategoryConfig).head
    val expectedDF = Seq(
      ("Rob", "bat", 0.04, "Store", "1"),
      ("Rob", "bat", 0.03, "Store", "1"),
      ("Billy", "ball", 0.02, "Store", "1"),
      ("Billy", "ball", 0.03, "Store", "1"),
      ("Morty", "badminton", 0.01, "Store", "1")
    ).toDF("Customer", "Product", "Score", "Store", "Type")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Implement Special Category Limit should return limit " +
    "applied to special category products - Full Match") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val specialCategoryConfig = ConfigFactory.parseString(
      """{
        | "productIdentifierColumnName": "product",
        | "isCustomerRequired": true,
        | "productIdentifiers": ["bat"],
        | "recommendedValue": 2
        |}
      """.stripMargin)
    val inputDF = Seq(
      ("Rob", "bat", 0.04, "Store", "1"),
      ("Rob", "bat", 0.02, "Store", "1"),
      ("Rob", "bat", 0.03, "Store", "1"),
      ("Billy", "ball", 0.01, "Store", "1"),
      ("Billy", "ball", 0.02, "Store", "1"),
      ("Billy", "ball", 0.03, "Store", "1"),
      ("Morty", "badminton", 0.01, "Store", "1")
    ).toDF("Customer", "Product", "Score", "Store", "Type")

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applySpecialCategoryCapping(inputDF, specialCategoryConfig).head
    val expectedDF = Seq(
      ("Rob", "bat", 0.04, "Store", "1"),
      ("Rob", "bat", 0.03, "Store", "1"),
      ("Billy", "ball", 0.02, "Store", "1"),
      ("Billy", "ball", 0.03, "Store", "1"),
      ("Billy", "ball", 0.01, "Store", "1"),
      ("Morty", "badminton", 0.01, "Store", "1")
    ).toDF("Customer", "Product", "Score", "Store", "Type")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Implement Special Category Limit should return limit " +
    "applied to special category products - Substring Match - Customer Not required") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val specialCategoryConfig = ConfigFactory.parseString(
      """{
        | "productIdentifierColumnName": "product",
        | "isCustomerRequired": false,
        | "substringLength" : 2,
        | "productIdentifiers": ["ba"],
        | "recommendedValue": 2
        |}
      """.stripMargin)
    val inputDF = Seq(
      ("Rob", "bat", 0.04, "Store", "1"),
      ("Rob", "bat", 0.02, "Store", "1"),
      ("Rob", "bat", 0.03, "Store", "1"),
      ("Billy", "ball", 0.01, "Store", "1"),
      ("Billy", "ball", 0.02, "Store", "1"),
      ("Billy", "ball", 0.03, "Store", "1"),
      ("Morty", "badminton", 0.01, "Store", "1")
    ).toDF("Customer", "Product", "Score", "Store", "Type")

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applySpecialCategoryCapping(inputDF, specialCategoryConfig).head

    val expectedDF = Seq(
      ("Rob", "bat", 0.04, "Store", "1"),
      ("Rob", "bat", 0.03, "Store", "1")
    ).toDF("Customer", "Product", "Score", "Store", "Type")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Required Diversity - should return top 2 promotions per product_subgroup_1 - " +
    "Customer required") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val diversityRulesConfig = ConfigFactory.parseString(
      """
        |{
        |  "isCustomerRequired": true,
        |  "diversityRules": [
        |   {
        |     "diversityColumn": "Promotion",
        |     "diversityCount": 2
        |   },
        |   {
        |     "diversityColumn": "Group",
        |     "diversityCount": 1
        |   }
        |  ]
        |}
      """.stripMargin)
    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", "S1"),
      ("C1", "P2", "Pr1", "0.5", "1", "G1", "S1"),
      ("C1", "P3", "Pr1", "0.9", "1", "G1", "S1"),
      ("C1", "P3", "Pr2", "0.8", "1", "G2", "S1"),
      ("C1", "P4", "Pr2", "0.6", "1", "G2", "S1"),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", "S1")
    ).toDF("Customer", "Product", "Promotion", "Score", "Type", "Group", "Store")

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRequiredDiversity(inputDF, diversityRulesConfig).head

    val expectedDF = Seq(
      ("C1", "P3", "Pr1", "0.9", "1", "G1", "S1"),
      ("C1", "P5", "Pr2", "0.9", "1", "G2", "S1")
    ).toDF("Customer", "Product", "Promotion", "Score", "Type", "Group", "Store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Apply Required Diversity - should return top 2 promotions per product_subgroup_1 - " +
    "Customer not required") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val diversityRulesConfig = ConfigFactory.parseString(
      """
        |{
        |  "isCustomerRequired": false,
        |  "diversityRules": [
        |   {
        |     "diversityColumn": "Promotion",
        |     "diversityCount": 2
        |   },
        |   {
        |     "diversityColumn": "Group",
        |     "diversityCount": 1
        |   }
        |  ]
        |}
      """.stripMargin)
    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "G1", "S1"),
      ("C2", "P2", "Pr1", "0.5", "1", "G1", "S1"),
      ("C3", "P3", "Pr1", "0.9", "1", "G1", "S1"),
      ("C4", "P3", "Pr2", "0.8", "1", "G2", "S1"),
      ("C5", "P4", "Pr2", "0.6", "1", "G2", "S1"),
      ("C6", "P5", "Pr2", "0.9", "1", "G2", "S1")
    ).toDF("Customer", "Product", "Promotion", "Score", "Type", "Group", "Store")

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .applyRequiredDiversity(inputDF, diversityRulesConfig).head

    val expectedDF = Seq(
      ("C3", "P3", "Pr1", "0.9", "1", "G1", "S1"),
      ("C6", "P5", "Pr2", "0.9", "1", "G2", "S1")
    ).toDF("Customer", "Product", "Promotion", "Score", "Type", "Group", "Store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Sensitivity Exclusion with substring and single rule") {
    val sensitivityConfig = ConfigFactory.parseString(
      """
  {
   |"isPetGroup" {
   |    "feature" : {
   |    "input" : {
   |        "type": "table.hive",
   |        "option": {
   |        "path": "f1",
   |        "columnNames": ["customer", "product_subgroup", "baskets_1w4w"]
   |        },
   |        "rename": {
   |            "product" : "product_subgroup"
   |        }
   |    },
   |    },
   |
   |
   |    "sensitivityLevel" : "product_subgroup",
   |    "sensitivityBucketGrain": "baskets_1w4w",
   |    "dimensionFilter": {
   |        "value": [
   |            "G2"
   |        ],
   |        "substringLength": 2
   |    },
   |    "sensitivityExclusionCriteria": " > 1",
   |
   |    "joinColumn" : ["customer", "product_subgroup"]
   |    }
   |}
  """.stripMargin)

    val featureWriteConfig = ConfigFactory.parseString(
      """
        |{
        |         "type": "table.hive",
        |         "option": {
        |           "path": "f1"
        |         }
        |       }
      """.stripMargin)

    val productDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val productRowList = List(
      Row("C1", "G34565"),
      Row("C1", "G2367"),
      Row("C2", "G254"),
      Row("C2", "G284"),
      Row("C3", "G398")
    )
    val productRowRDD = sc.parallelize(productRowList)

    val productDF = sparkSession.createDataFrame(productRowRDD, productDFSchema)

    val featureDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("baskets_1w4w", IntegerType)
      )
    )

    val featureRowList = List(
      Row("C1", "G34565", 1),
      Row("C1", "G2367", 2),
      Row("C2", "G254", 3),
      Row("C2", "G284", 0),
      Row("C3", "G398", 3)
    )
    val featureRowRDD = sc.parallelize(featureRowList)

    val featureDF: DataFrame = sparkSession.createDataFrame(featureRowRDD, featureDFSchema)
    DataFrameReadWriteFormat(featureWriteConfig).writeDataFrame(featureDF)

    val outputDF = RulesBank(applicationConfig, sparkSession)
      .applySensitivityExclusion(productDF, sensitivityConfig).head

    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val expectedRowList = List(
      Row("C1", "G34565"),
      Row("C1", "G2367"),
      Row("C2", "G254"),
      Row("C3", "G398")
    )
    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)

    assertDataFrame(outputDF, expectedDF)
  }

  test("RulesBankTest - Sensitivity Exclusion with no substring comparison and single rule") {
    val sensitivityConfig = ConfigFactory.parseString(
      """
        |{
        |"isPetGroup" {
        |    "feature" : {
        |    "input" : {
        |        "type": "table.hive",
        |        "option": {
        |        "path": "f2"
        |        },
        |        "rename": {
        |            "product" : "product_subgroup"
        |        }
        |    },
        |    },
        |    "dimensionFilter": {
        |        "value": [
        |            "G3"
        |        ]
        |    },
        |    "sensitivityLevel" : "product_subgroup",
        |    "sensitivityBucketGrain": "baskets_1w4w",
        |    "sensitivityExclusionCriteria": ">0",
        |    "joinColumn" : ["customer", "product_subgroup"]
        |    }
        |
        |}
      """.stripMargin)

    val featureWriteConfig = ConfigFactory.parseString(
      """
        |{
        |         "type": "table.hive",
        |         "option": {
        |           "path": "f2"
        |         }
        |       }
      """.stripMargin)

    val productDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val productRowList = List(
      Row("C1", "G3"),
      Row("C1", "G2367"),
      Row("C2", "G354"),
      Row("C2", "G384"),
      Row("C3", "G3")
    )
    val productRowRDD = sc.parallelize(productRowList)

    val productDF = sparkSession.createDataFrame(productRowRDD, productDFSchema)

    val featureDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("baskets_1w4w", IntegerType)
      )
    )

    val featureRowList = List(
      Row("C1", "G3", 1),
      Row("C1", "G2367", 1),
      Row("C2", "G354", 2),
      Row("C2", "G384", 0),
      Row("C3", "G3", 0)
    )
    val featureRowRDD = sc.parallelize(featureRowList)

    val featureDF = sparkSession.createDataFrame(featureRowRDD, featureDFSchema)
    DataFrameReadWriteFormat(featureWriteConfig).writeDataFrame(featureDF)

    val outputDF = RulesBank(applicationConfig, sparkSession)
      .applySensitivityExclusion(productDF, sensitivityConfig).head

    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val expectedRowList = List(
      Row("C1", "G3"),
      Row("C1", "G2367"),
      Row("C2", "G354"),
      Row("C2", "G384")
    )
    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)

    assertDataFrame(outputDF, expectedDF)
  }

  test("RulesBankTest - Sensitivity Exclusion with multiple rules") {
    val sensitivityConfig = ConfigFactory.parseString(
      """
         {
   |
   |"isPetGroup" {
   |    "feature" : {
   |    "input" : {
   |        "type": "table.hive",
   |        "option": {
   |        "path": "f3"
   |        },
   |        "rename": {
   |            "product" : "product_subgroup"
   |        }
   |    }
   |    },
   |    "dimensionFilter": {
   |        "value": [
   |            "G3"
   |        ]
   |    },
   |    "sensitivityLevel" : "product_subgroup",
   |    "sensitivityBucketGrain": "baskets_1w4w",
   |    "sensitivityExclusionCriteria": " > 0"
   |    "joinColumn" : ["customer", "product_subgroup"]
   |    },
   |"isBabyGroup" {
   |    "feature" : {
   |    "input" : {
   |        "type": "table.hive",
   |        "option": {
   |        "path": "f3"
   |        },
   |        "rename": {
   |            "product" : "product_subgroup"
   |        }
   |    },
   |    },
   |    "dimensionFilter": {
   |        "value": [
   |            "N34"
   |        ],
   |        "substringLength": 3
   |    },
   |
   |    "sensitivityLevel" : "product_subgroup",
   |    "sensitivityBucketGrain": "baskets_1w4w",
   |    "sensitivityExclusionCriteria": " > 1",
   |    "joinColumn" : ["customer", "product_subgroup"]
   |    }
   |
   |}
        """.stripMargin)

    val featureWriteConfig = ConfigFactory.parseString(
      """
        |{
        |         "type": "table.hive",
        |         "option": {
        |           "path": "f3"
        |         }
        |       }
      """.stripMargin)

    val productDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val productRowList = List(
      Row("C1", "G3"),
      Row("C1", "G2367"),
      Row("C2", "G354"),
      Row("C2", "G384"),
      Row("C3", "G3"),
      Row("C2", "N34567"),
      Row("C2", "N387"),
      Row("C5", "N3476")
    )
    val productRowRDD = sc.parallelize(productRowList)

    val productDF = sparkSession.createDataFrame(productRowRDD, productDFSchema)

    val featureDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("baskets_1w4w", IntegerType)
      )
    )

    val featureRowList = List(
      Row("C1", "G3", 1),
      Row("C1", "G2367", 1),
      Row("C2", "G354", 2),
      Row("C2", "G384", 0),
      Row("C3", "G3", 0),
      Row("C2", "N34567", 1),
      Row("C2", "N387", 2),
      Row("C5", "N3476", 5)
    )
    val featureRowRDD = sc.parallelize(featureRowList)

    val featureDF = sparkSession.createDataFrame(featureRowRDD, featureDFSchema)
    DataFrameReadWriteFormat(featureWriteConfig).writeDataFrame(featureDF)

    val outputDF = RulesBank(applicationConfig, sparkSession)
      .applySensitivityExclusion(productDF, sensitivityConfig).head

    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val expectedRowList = List(
      Row("C1", "G3"),
      Row("C1", "G2367"),
      Row("C2", "G354"),
      Row("C2", "G384"),
      Row("C2", "N387"),
      Row("C5", "N3476")
    )
    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)

    assertDataFrame(outputDF, expectedDF)
  }

  test("RulesBankTest - Sensitivity Exclusion with substring length does not match value length") {
    val sensitivityConfig = ConfigFactory.parseString(
      """
        |{
        |"isPetGroup" {
        |    "feature" : {
        |    "input" : {
        |        "type": "table.hive",
        |        "option": {
        |        "path": "f4"
        |        },
        |        "rename": {
        |            "product" : "product_subgroup"
        |        }
        |    }
        |    }
        |    "dimensionFilter": {
        |        "value": [
        |            "G3"
        |        ],
        |        "substringLength": 5
        |    },
        |    "sensitivityLevel" : "product_subgroup",
        |    "sensitivityBucketGrain": "baskets_1w4w",
        |    "sensitivityExclusionCriteria": " > 0"
        |    "joinColumn" : ["customer", "product_subgroup"]
        |    }
        |}
      """.stripMargin)

    val featureWriteConfig = ConfigFactory.parseString(
      """
        |{
        |         "type": "table.hive",
        |         "option": {
        |           "path": "f4"
        |         }
        |       }
      """.stripMargin)

    val productDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product_subgroup", StringType)
      )
    )

    val productRowList = List(
      Row("C1", "G3"),
      Row("C1", "G2367"),
      Row("C2", "G354"),
      Row("C2", "G384"),
      Row("C3", "G3")
    )
    val productRowRDD = sc.parallelize(productRowList)

    val productDF = sparkSession.createDataFrame(productRowRDD, productDFSchema)

    val featureDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("baskets_1w4w", IntegerType)
      )
    )

    val featureRowList = List(
      Row("C1", "G3", 1),
      Row("C1", "G2367", 1),
      Row("C2", "G354", 2),
      Row("C2", "G384", 0),
      Row("C3", "G3", 0)
    )
    val featureRowRDD = sc.parallelize(featureRowList)

    val featureDF = sparkSession.createDataFrame(featureRowRDD, featureDFSchema)
    DataFrameReadWriteFormat(featureWriteConfig).writeDataFrame(featureDF)

    val output = intercept[IllegalArgumentException] {
      RulesBank(applicationConfig, sparkSession)
        .applySensitivityExclusion(productDF, sensitivityConfig).head
    }
    assert(output.getMessage.contains("Values in value list does not match substring length"))

  }

  test("RulesBankTest - Explode Range Hierarchy") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val customerDF = Seq(
      ("Rob", "S2", "S3", "S4", null),
      ("Billy", "S1", "S2", "S3", "S4")
    ).toDF("customer", "PreferredStore1", "PreferredStore2", "PreferredStore3", "PreferredStore4")

    val config = ConfigFactory.parseString(
      """
        |{
        | "preferredColumnNames": ["PreferredStore1", "PreferredStore2", "PreferredStore3"],
        | "rangeRankOutputColumnName": "rangeRank",
        | "hierarchy": "Store"
        |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .explodeRangeHierarchy(customerDF, config).head

    val expectedDF = Seq(
      ("Rob", 0, "S2"),
      ("Rob", 1, "S3"),
      ("Rob", 2, "S4"),
      ("Billy", 0, "S1"),
      ("Billy", 1, "S2"),
      ("Billy", 2, "S3")
    ).toDF("customer", "rangeRank", "Store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Ranging Generic DF - Range Hierarchy on Store") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val genericDF = Seq(
      ("P1", "Pr1", "0.7", "S1"),
      ("P1", "Pr1", "0.6", "S2"),
      ("P3", "Pr2", "0.9", "S1")
    ).toDF("Product", "Promotion", "rank", "Store")

    val customerWhoNeedInfillingDF = Seq(
      ("C1"),
      ("C2")
    ).toDF("customer")

    val explodedRangeHierarchyCstDF = Seq(
      ("C1", "S1", 0),
      ("C1", "S2", 1),
      ("C1", "S3", 2),
      ("C2", "S1", 0),
      ("C2", "S2", 1),
      ("C3", "S2", 0),
      ("C4", "S1", 0),
      ("C4", "S2", 1),
      ("C4", "S3", 2),
      ("C5", "S1", 0),
      ("C6", "S1", 0)
    ).toDF("customer", "Store", "rangeRank")

    val rangingConfig = ConfigFactory.parseString(
      """
        |{
        |"rangeRankOutputColumnName": "rangeRank",
        |}
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .infilling(genericDF, customerWhoNeedInfillingDF, explodedRangeHierarchyCstDF, rangingConfig)
      .head

    val expectedDF = Seq(
      ("P3", "Pr2", "0.9", "S1", "C2", 0),
      ("P1", "Pr1", "0.6", "S2", "C1", 1),
      ("P1", "Pr1", "0.6", "S2", "C2", 1),
      ("P1", "Pr1", "0.7", "S1", "C2", 0),
      ("P3", "Pr2", "0.9", "S1", "C1", 0),
      ("P1", "Pr1", "0.7", "S1", "C1", 0)
    ).toDF("Product", "Promotion", "rank", "Store", "customer", "rangeRank")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Ranging Generic DF - Without Range Hierarchy") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val applicationConfig = ConfigFactory.parseFile(new File("src/test/resources/AllocationLevelEmptyApplication.conf"))

    val genericDF = Seq(
      ("P1", "Pr1", "0.7", "S1"),
      ("P2", "Pr1", "0.6", "S2"),
      ("P2", "Pr1", "0.5", "S1")
    ).toDF("product", "promotion", "rank", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C3"),
      ("C4")
    ).toDF("customer")

    val explodedRangeHierarchyCstDF = Seq(
      ("C1", "S1", 0),
      ("C1", "S2", 1),
      ("C1", "S3", 2),
      ("C2", "S1", 0),
      ("C2", "S2", 1),
      ("C3", "S2", 0),
      ("C4", "S1", 0),
      ("C4", "S2", 1),
      ("C4", "S3", 2),
      ("C5", "S1", 0),
      ("C6", "S1", 0)
    ).toDF("customer", "store", "rangeRank")

    val rangingConfig = ConfigFactory.parseString(
      """
        |{
        |"rangeRankOutputColumnName": "rangeRank",
        |}
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .infilling(genericDF, customerWhoNeedInfillingDF, explodedRangeHierarchyCstDF, rangingConfig)
      .head

    val expectedDF = Seq(
      ("C3", "P1", "Pr1", "0.7", "S1", 3),
      ("C3", "P2", "Pr1", "0.6", "S2", 3),
      ("C3", "P2", "Pr1", "0.5", "S1", 3),
      ("C4", "P1", "Pr1", "0.7", "S1", 3),
      ("C4", "P2", "Pr1", "0.6", "S2", 3),
      ("C4", "P2", "Pr1", "0.5", "S1", 3)
    ).toDF("customer", "product", "promotion", "rank", "store", "type")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Infill Popular Promotions - should return infilled DF - Promotion Infilling") {

    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val rpDF = Seq(
      ("P1", "Pr1", "1", "C1", "S1"),
      ("P2", "Pr1", "1", "C1", "S1"),
      ("P3", "Pr2", "1", "C2", "S1"),
      ("P4", "Pr2", "1", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    val infilledDF = Seq(
      ("P4", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C1"),
      ("C2")
    ).toDF("customer")

    val infillingConfig = ConfigFactory.parseString(
      """
        |{
        | "infillingType": "promotion"
        |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .promotionFilteringOnScoreType(rpDF, infilledDF, customerWhoNeedInfillingDF, infillingConfig)
      .head

    val expectedDF = Seq(
      ("P1", "Pr1", "3", "C2", "S1"),
      ("P3", "Pr2", "1", "C2", "S1"),
      ("P4", "Pr2", "1", "C2", "S1"),
      ("P1", "Pr1", "1", "C1", "S1"),
      ("P2", "Pr1", "1", "C1", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Infill Popular Promotions - should return infilled DF - Product Infilling") {

    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val rpDF = Seq(
      ("P1", "Pr1", "1", "C1", "S1"),
      ("P2", "Pr1", "1", "C1", "S1"),
      ("P3", "Pr2", "1", "C2", "S1"),
      ("P4", "Pr2", "1", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    val infilledDF = Seq(
      ("P4", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C1"),
      ("C2")
    ).toDF("customer")

    val infillingConfig = ConfigFactory.parseString(
      """
        |{
        | "infillingType": "product"
        |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .promotionFilteringOnScoreType(rpDF, infilledDF, customerWhoNeedInfillingDF, infillingConfig)
      .head

    val expectedDF = Seq(
      ("P4", "Pr2", "1", "C2", "S1"),
      ("P1", "Pr1", "1", "C1", "S1"),
      ("P3", "Pr2", "1", "C2", "S1"),
      ("P2", "Pr1", "1", "C1", "S1"),
      ("P4", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Infill Popular Promotions - should return infilled DF - Invalid Infilling Type") {

    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val rpDF = Seq(
      ("P1", "Pr1", "1", "C1", "S1"),
      ("P2", "Pr1", "1", "C1", "S1"),
      ("P3", "Pr2", "1", "C2", "S1"),
      ("P4", "Pr2", "1", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    val infilledDF = Seq(
      ("P4", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C1", "S1"),
      ("P1", "Pr1", "3", "C2", "S1")
    ).toDF("product", "promotion", "type", "customer", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C1"),
      ("C2")
    ).toDF("customer")

    val infillingConfig = ConfigFactory.parseString(
      """
        |{
        | "infillingType": "invalid"
        |}
      """.stripMargin)

    val actualMessage = intercept[IllegalArgumentException] {
      RulesBank(applicationConfig, sparkSession)
        .promotionFilteringOnScoreType(rpDF, infilledDF, customerWhoNeedInfillingDF, infillingConfig)
        .head
    }.getMessage

    val expectedMessage = "RulesBank method promotionFilteringOnScoreType only supports Promotion and " +
      "Product as InfillingType and got - invalid"

    assert(actualMessage === expectedMessage)
  }

  test("RulesBankTest - Generate Generic Promotions should run successfully using features") {

    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))

    val featureWriteConfig = ConfigFactory.parseString(
      """
        |{
        |    "type": "table.hive",
        |    "option": {
        |       "path": "feature"
        |    },
        |    rename: {
        |       "baskets_1w4w": "score"
        |    }
        |}
      """.stripMargin)

    val featureDFSchema = StructType(
      Array(
        StructField("product", StringType),
        StructField("baskets_1w4w", DoubleType)
      )
    )

    val featureRowList = List(
      Row("P1", 5.0),
      Row("P2", 2.0),
      Row("P3", 8.0),
      Row("P9", 8.0),
      Row("P4", 6.0),
      Row("P5", 7.0)
    )

    val featureRowRDD = sc.parallelize(featureRowList)
    val featureDF = sparkSession.createDataFrame(featureRowRDD, featureDFSchema)

    val promoDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("product", StringType)
      )
    )

    val promoRowList = List(
      Row("Pr1", "P1"),
      Row("Pr1", "P2"),
      Row("Pr1", "P3"),
      Row("Pr2", "P4"),
      Row("Pr3", "P5")
    )

    val promoRowRDD = sc.parallelize(promoRowList)
    val promoDF = sparkSession.createDataFrame(promoRowRDD, promoDFSchema)

    DataFrameReadWriteFormat(featureWriteConfig).writeDataFrame(featureDF)

    val expectedDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("product", StringType),
        StructField("type", IntegerType),
        StructField("score", StringType)
      )
    )

    val expectedRowList = List(
      Row("Pr1", "P1", 3, "0.20000000"),
      Row("Pr1", "P2", 3, "0.16666667"),
      Row("Pr1", "P3", 3, "1.00000000"),
      Row("Pr2", "P4", 3, "0.25000000"),
      Row("Pr3", "P5", 3, "0.33333333")
    )

    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)
    val pppDF = sparkSession.table("feature")
    val output = RulesBank(applicationConfig, sparkSession)
      .getPopularPromotions(promoDF, pppDF).head
    assertDataFrame(output, expectedDF)

  }

  test("RulesBankTest - Generate Generic Promotions should run successfully using scores when bannerRanging") {

    val featureWriteConfig = ConfigFactory.parseString(
      """
        |{
        |    "type": "table.hive",
        |    "option": {
        |       "path": "ppp"
        |    }
        |}
      """.stripMargin)

    val featureDFSchema = StructType(
      Array(
        StructField("product", StringType),
        StructField("score", DoubleType),
        StructField("banner", StringType)
      )
    )

    val featureRowList = List(
      Row("P1", 0.5, "B1"),
      Row("P1", 0.7, "B2"),
      Row("P2", 0.2, "B2"),
      Row("P3", 0.8, "B1"),
      Row("P9", 0.8, "B2"),
      Row("P4", 0.6, "B2"),
      Row("P5", 0.7, "B1")
    )

    val scoreRowRDD = sc.parallelize(featureRowList)
    val scoreDF = sparkSession.createDataFrame(scoreRowRDD, featureDFSchema)

    DataFrameReadWriteFormat(featureWriteConfig).writeDataFrame(scoreDF)

    val promoDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("product", StringType),
        StructField("banner", StringType)
      )
    )

    val promoRowList = List(
      Row("Pr1", "P1", "B1"),
      Row("Pr1", "P2", "B2"),
      Row("Pr1", "P3", "B1"),
      Row("Pr2", "P4", "B2"),
      Row("Pr3", "P5", "B1")
    )

    val promoRowRDD = sc.parallelize(promoRowList)
    val promoDF = sparkSession.createDataFrame(promoRowRDD, promoDFSchema)

    val expectedDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("product", StringType),
        StructField("banner", StringType),
        StructField("type", IntegerType),
        StructField("score", StringType)
      )
    )

    val expectedRowList = List(
      Row("Pr1", "P1", "B1", 3, "0.33333333"),
      Row("Pr1", "P2", "B2", 3, "0.25000000"),
      Row("Pr1", "P3", "B1", 3, "1.00000000"),
      Row("Pr2", "P4", "B2", 3, "0.33333333"),
      Row("Pr3", "P5", "B1", 3, "0.50000000")
    )

    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)
    val pppDF = sparkSession.table("ppp")

    val output = RulesBank(applicationConfig, sparkSession)
      .getPopularPromotions(promoDF, pppDF)
      .head
    assertDataFrame(output, expectedDF)
  }

  test("RulesBankTest - CappingPopularPromotion should be able to cap successfully") {
    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))

    val popularPromotionDFSchema = List(
      ("promotion", StringType), ("product", StringType), ("banner", StringType),
      ("productRank", IntegerType), ("score", StringType)
    )

    val popularPromotionRowList = List(
      Row("Pr1", "P1", "B1", 3, "0.33333333"),
      Row("Pr1", "P2", "B2", 4, "0.25000000"),
      Row("Pr1", "P3", "B1", 1, "1.00000000"),
      Row("Pr2", "P4", "B2", 3, "0.40000000"),
      Row("Pr3", "P5", "B1", 2, "0.33333333"),
      Row("Pr3", "P6", "B1", 2, "0.50000000")
    )

    val popularPromotionDF = createDF(popularPromotionDFSchema, popularPromotionRowList)

    val expectedDFSchema = List(
      ("promotion", StringType), ("product", StringType), ("banner", StringType), ("productRank", IntegerType),
      ("score", StringType)
    )

    val expectedRowList = List(
      Row("Pr1", "P3", "B1", 1, "1.00000000"),
      Row("Pr3", "P5", "B1", 2, "0.33333333"),
      Row("Pr3", "P6", "B1", 2, "0.50000000")
    )

    val expectedDF = createDF(expectedDFSchema, expectedRowList)

    val capConfig = ConfigFactory.parseString(
      """
        {
          "offerLimit": 1,
          "alcoholicLimit": 1,
          "rankColumnName": "productRank"
        }
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .capping(popularPromotionDF, capConfig)
      .head
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - CappingPopularPromotion should be able to cap successfully - Minimum Offers") {
    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))

    val popularPromotionDFSchema = List(
      ("promotion", StringType), ("product", StringType), ("customer", StringType),
      ("productRank", IntegerType), ("score", StringType)
    )

    val popularPromotionRowList = List(
      Row("Pr1", "P1", "C1", 3, "0.33333333"),
      Row("Pr1", "P2", "C2", 4, "0.25000000"),
      Row("Pr1", "P3", "C1", 1, "1.00000000"),
      Row("Pr2", "P4", "C2", 3, "0.40000000"),
      Row("Pr3", "P5", "C1", 2, "0.33333333"),
      Row("Pr3", "P6", "C3", 2, "0.50000000")
    )

    val popularPromotionDF = createDF(popularPromotionDFSchema, popularPromotionRowList)

    val expectedDFSchema = List(
      ("promotion", StringType), ("product", StringType), ("customer", StringType), ("productRank", IntegerType),
      ("score", StringType)
    )

    val expectedRowList = List(
      Row("Pr1", "P3", "C1", 1, "1.00000000"),
      Row("Pr3", "P5", "C1", 2, "0.33333333"),
      Row("Pr3", "P6", "C3", 2, "0.50000000")
    )

    val expectedDF = createDF(expectedDFSchema, expectedRowList)

    val capConfig = ConfigFactory.parseString(
      """
        {
          "offerLimit": 1,
          "alcoholicLimit": 1,
          "minimumOffers": 2,
          "rankColumnName": "productRank"
        }
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .capping(popularPromotionDF, capConfig)
      .head
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - CappingPopularPromotion should be able to cap successfully per store - Minimum Offers") {

    val popularPromotionDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("product", StringType),
        StructField("store", StringType),
        StructField("customer", StringType),
        StructField("productRank", IntegerType),
        StructField("score", StringType)
      )
    )

    val popularPromotionRowList = List(
      Row("Pr1", "P1", "S1", "C1", 3, "0.33333333"),
      Row("Pr1", "P2", "S2", "C2", 4, "0.25000000"),
      Row("Pr5", "P3", "S1", "C1", 1, "1.00000000"),
      Row("Pr2", "P4", "S2", "C1", 3, "0.40000000"),
      Row("Pr3", "P5", "S2", "C2", 2, "0.33333333"),
      Row("Pr3", "P6", "S1", "C3", 2, "0.50000000"),
      Row("Pr4", "P7", "S1", "C4", 2, "0.70000000")
    )

    val popularPromotionRowRDD = sc.parallelize(popularPromotionRowList)
    val popularPromotionDF = sparkSession.createDataFrame(popularPromotionRowRDD, popularPromotionDFSchema)

    val expectedDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("product", StringType),
        StructField("store", StringType),
        StructField("customer", StringType),
        StructField("productRank", IntegerType),
        StructField("score", StringType)
      )
    )

    val expectedRowList = List(
      Row("Pr3", "P5", "S2", "C2", 2, "0.33333333"),
      Row("Pr5", "P3", "S1", "C1", 1, "1.00000000"),
      Row("Pr4", "P7", "S1", "C4", 2, "0.70000000"),
      Row("Pr3", "P6", "S1", "C3", 2, "0.50000000")
    )

    val expectedRowRDD = sc.parallelize(expectedRowList)
    val expectedDF = sparkSession.createDataFrame(expectedRowRDD, expectedDFSchema)
    val capConfig = ConfigFactory.parseString(
      """
        {
          "offerLimit": 1,
          "alcoholicLimit": 1
          "minimumOffers": 2
          "rankColumnName": "productRank"
        }
      """.stripMargin)
    val outputDF = RulesBank(applicationConfig, sparkSession)
      .capping(popularPromotionDF, capConfig)
      .head

    assertDataFrame(outputDF, expectedDF)

  }

  test("RulesBankTest - customerBifurcation should be able to successfully bifurcate customers") {
    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))
    val allocationDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("promotion", StringType),
        StructField("product", StringType)
      )
    )

    val allocationRowList = List(
      Row("C1", "Pr1", "P1"),
      Row("C1", "Pr1", "P2"),
      Row("C1", "Pr2", "P3"),
      Row("C1", "Pr3", "P4"),
      Row("C2", "Pr4", "P5"),
      Row("C2", "Pr5", "P6"),
      Row("C3", "Pr5", "P7"),
      Row("C4", "Pr1", "P1"),
      Row("C4", "Pr1", "P2"),
      Row("C4", "Pr2", "P3"),
      Row("C4", "Pr3", "P4"),
      Row("C4", "Pr4", "P5")
    )

    // c1 -> 3, c2 -> 2, c3 -> 1, c4 -> 4
    val allocationRowRDD = sc.parallelize(allocationRowList)
    val allocationDF = sparkSession.createDataFrame(allocationRowRDD, allocationDFSchema)

    val scoreDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("score", StringType)
      )
    )

    val scoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7")
    )

    val scoreRowRDD = sc.parallelize(scoreRowList)
    val scoreDF = sparkSession.createDataFrame(scoreRowRDD, scoreDFSchema)


    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType)
      )
    )
    val expectedRowList1 = List(Row("C1"), Row("C4"))

    val expectedRowRDD1 = sc.parallelize(expectedRowList1)
    val expectedDF1 = sparkSession.createDataFrame(expectedRowRDD1, expectedDFSchema)

    val expectedRowList2 = List(
      Row("C2"), Row("C3"))

    val expectedRowRDD2 = sc.parallelize(expectedRowList2)
    val expectedDF2 = sparkSession.createDataFrame(expectedRowRDD2, expectedDFSchema)

    val expectedRowList3 = List(Row("C5"))

    val expectedRowRDD3 = sc.parallelize(expectedRowList3)
    val expectedDF3 = sparkSession.createDataFrame(expectedRowRDD3, expectedDFSchema)

    val customerBifurcationConfig = ConfigFactory.parseString(
      """
        {
          "offerLimit": 3
        }
      """.stripMargin)

    val customerRowList = List(
      Row("C1", "s1"),
      Row("C1", "s2"),
      Row("C1", "s3"),
      Row("C2", "s2"),
      Row("C3", "s3"),
      Row("C4", "s4"),
      Row("C5", "s5"))
    val customerRowRDD = sc.parallelize(customerRowList)
    val custDF = sparkSession.createDataFrame(customerRowRDD, expectedDFSchema)


    val outputDFList = RulesBank(applicationConfig, sparkSession)
      .customerBifurcation(allocationDF, scoreDF, scoreDF, custDF, customerBifurcationConfig)

    assertDataFrame(expectedDF1, outputDFList.head)
    assertDataFrame(expectedDF2, outputDFList(1))
    assertDataFrame(expectedDF3, outputDFList(2))
  }

  test("RulesBankTest - customerBifurcation should be able to successfully bifurcate customers under store") {

    val allocationDFSchema =
      List(("customer", StringType), ("promotion", StringType), ("product", StringType), ("store", StringType))

    val allocationRowList = List(
      Row("C1", "Pr1", "P1", "s1"),
      Row("C1", "Pr1", "P2", "s1"),
      Row("C1", "Pr2", "P3", "s1"),
      Row("C1", "Pr3", "P4", "s2"),
      Row("C2", "Pr4", "P5", "s3"),
      Row("C2", "Pr5", "P6", "s3"),
      Row("C3", "Pr5", "P7", "s3"),
      Row("C4", "Pr1", "P1", "s4"),
      Row("C4", "Pr1", "P2", "s4"),
      Row("C4", "Pr2", "P3", "s4"),
      Row("C4", "Pr3", "P4", "s5"),
      Row("C4", "Pr4", "P5", "s5")
    )

    // c1 -> 3, c2 -> 2, c3 -> 1, c4 -> 4
    val allocationDF = createDF(allocationDFSchema, allocationRowList)

    val promoDFSchema = List(("promotion", StringType), ("store", StringType))

    val promoRowList = List(
      Row("Pr1", "s1"),
      Row("Pr3", "s2"),
      Row("Pr4", "s3"),
      Row("Pr5", "s3"),
      Row("Pr1", "s4"),
      Row("Pr2", "s4"),
      Row("Pr3", "s5"),
      Row("Pr4", "s5")
    )

    val promoDF = createDF(promoDFSchema, promoRowList)

    val scoreDFSchema = List(("customer", StringType), ("product", StringType), ("score", StringType))

    val scoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7")
    )

    val scoreDF = createDF(scoreDFSchema, scoreRowList)

    val expectedDFSchema = List(("customer", StringType), ("store", StringType))

    val expectedDF1 = createDF(expectedDFSchema,
      List(Row("C1", "s1"), Row("C2", "s3"), Row("C4", "s4"), Row("C4", "s5")))

    val expectedDF2 = createDF(expectedDFSchema, List(Row("C3", "s3"), Row("C1", "s2")))

    val expectedRowList3 = List(
      Row("C1", "s3"), Row("C2", "s2"), Row("C5", "s5"))

    val expectedDF3 = createDF(expectedDFSchema, expectedRowList3)

    val customerBifurcationConfig = ConfigFactory.parseString(
      """
        {
          "offerLimit": 2
        }
      """.stripMargin)
    val customerRowList = List(
      Row("C1", "s1"),
      Row("C1", "s2"),
      Row("C1", "s3"),
      Row("C2", "s2"),
      Row("C3", "s3"),
      Row("C4", "s4"),
      Row("C5", "s5"))
    val custDF = createDF(expectedDFSchema, customerRowList)
    val outputDFList = RulesBank(applicationConfig, sparkSession)
      .customerBifurcation(allocationDF, scoreDF, promoDF, custDF, customerBifurcationConfig)
    assertDataFrame(expectedDF1, outputDFList.head)
    assertDataFrame(expectedDF2, outputDFList(1))
    assertDataFrame(expectedDF3, outputDFList(2))
  }

  test("RulesBankTest - customerBifurcation should be able to successfully bifurcate customers on banner") {
    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelBannerApplication.conf"))
    val allocationDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("promotion", StringType),
        StructField("product", StringType),
        StructField("banner", StringType)
      )
    )

    val allocationRowList = List(
      Row("C1", "Pr1", "P1", "B1"),
      Row("C1", "Pr1", "P2", "B1"),
      Row("C1", "Pr2", "P3", "B2"),
      Row("C1", "Pr3", "P4", "B2"),
      Row("C2", "Pr4", "P5", "B1"),
      Row("C2", "Pr5", "P6", "B2"),
      Row("C3", "Pr5", "P7", "B1"),
      Row("C4", "Pr1", "P1", "B1"),
      Row("C4", "Pr1", "P2", "B2"),
      Row("C4", "Pr2", "P3", "B2"),
      Row("C4", "Pr3", "P4", "B2"),
      Row("C4", "Pr4", "P5", "B2")
    )

    // c1 -> 3, c2 -> 2, c3 -> 1, c4 -> 4
    val allocationRowRDD = sc.parallelize(allocationRowList)
    val allocationDF = sparkSession.createDataFrame(allocationRowRDD, allocationDFSchema)

    val scoreDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("score", StringType)
      )
    )

    val scoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7")
    )

    val scoreRowRDD = sc.parallelize(scoreRowList)
    val scoreDF = sparkSession.createDataFrame(scoreRowRDD, scoreDFSchema)


    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("banner", StringType)
      )
    )
    val expectedRowList1 = List(Row("C1", "B2"), Row("C4", "B2"))

    val expectedRowRDD1 = sc.parallelize(expectedRowList1)
    val expectedDF1 = sparkSession.createDataFrame(expectedRowRDD1, expectedDFSchema)

    val expectedRowList2 = List(
      Row("C2", "B1"),
      Row("C2", "B2"),
      Row("C1", "B1"),
      Row("C3", "B1"),
      Row("C4", "B1"))

    val expectedRowRDD2 = sc.parallelize(expectedRowList2)
    val expectedDF2 = sparkSession.createDataFrame(expectedRowRDD2, expectedDFSchema)

    val expectedRowList3 = List(
      Row("C3", "B2"),
      Row("C5", "B1"),
      Row("C5", "B2")
    )

    val expectedRowRDD3 = sc.parallelize(expectedRowList3)
    val expectedDF3 = sparkSession.createDataFrame(expectedRowRDD3, expectedDFSchema)

    val customerBifurcationConfig = ConfigFactory.parseString(
      """
        {
          "offerLimit": 2
        }
      """.stripMargin)

    val customerRowList = List(
      Row("C1", "s1"),
      Row("C1", "s2"),
      Row("C1", "s3"),
      Row("C2", "s2"),
      Row("C3", "s3"),
      Row("C4", "s4"),
      Row("C5", "s5"))
    val customerRowRDD = sc.parallelize(customerRowList)
    val custDF = sparkSession.createDataFrame(customerRowRDD, expectedDFSchema)

    val promoRowList = List(
      Row("P1", "B1"),
      Row("P1", "B2"),
      Row("P2", "B2"),
      Row("P2", "B2"),
      Row("P6", "B2"),
      Row("P6", "B2"))

    val promoDFSchema = StructType(
      Array(
        StructField("promotion", StringType),
        StructField("banner", StringType)
      )
    )
    val promoRowRDD = sc.parallelize(promoRowList)
    val promoDF = sparkSession.createDataFrame(promoRowRDD, promoDFSchema)



    val outputDFList = RulesBank(applicationConfig, sparkSession)
      .customerBifurcation(allocationDF, scoreDF, promoDF, custDF, customerBifurcationConfig)

    assertDataFrame(expectedDF1, outputDFList.head)
    assertDataFrame(expectedDF2, outputDFList(1))
    assertDataFrame(expectedDF3, outputDFList(2))
  }

  test("RulesBankTest - Multiple Campaign Email - Multiple rules") {

    val mechanicRulesConfig = ConfigFactory.parseString("""{
      "multipleCampaignRules": [
        {
          "mechanicCodesList": ["7", "8", "9", "10", "11", "12", "13", "14", "15"],
          "maxProductCount": 2
        },
        {
          "mechanicCodesList": ["1", "2", "3", "4", "5", "6", "16", "17", "27"],
          "maxProductCount": 1
        }
      ]
    }""".stripMargin)

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val inputDF = Seq(
      ("C1", "7", "P1"),
      ("C1", "7", "P2"),
      ("C1", "7", "P1"),
      ("C2", "7", "P3"),
      ("C2", "7", "P4"),
      ("C2", "7", "P5"),
      ("C3", "1", "P1"),
      ("C4", "33", "P6")
    ).toDF("Customer", "MechanicCode", "Product")

    val actualDF = RulesBank(applicationConfig, sparkSession).multipleCampaignEmail(inputDF, mechanicRulesConfig).head

    val expectedDF = Seq(
      ("C1", "7", "P1"),
      ("C1", "7", "P2"),
      ("C1", "7", "P1"),
      ("C2", "7", "P3"),
      ("C2", "7", "P4"),
      ("C2", "7", "P5"),
      ("C4", "33", "P6")
    ).toDF("Customer", "MechanicCode", "Product")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Multiple Campaign Email - Empty config") {

    val mechanicRulesConfig = ConfigFactory.parseString("""{
      "multipleCampaignRules": []
    }""".stripMargin)

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val inputDF = Seq(
      ("C1", "7", "P1"),
      ("C1", "7", "P2"),
      ("C1", "7", "P1"),
      ("C2", "7", "P3"),
      ("C2", "7", "P4"),
      ("C2", "7", "P5"),
      ("C3", "1", "P1"),
      ("C4", "33", "P6")
    ).toDF("Customer", "MechanicCode", "Product")

    val actualDF = RulesBank(applicationConfig, sparkSession).multipleCampaignEmail(inputDF, mechanicRulesConfig).head

    val expectedDF = inputDF

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - Transform DF function test") {

        val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val inputDF = Seq(
      ("C1", "7", "P1"),
      ("C1", "7", "P2"),
      ("C1", "7", "P1"),
      ("C2", "7", "P3"),
      ("C2", "7", "P4"),
      ("C2", "7", "P5"),
      ("C3", "1", "P1"),
      ("C4", "33", "P6")
    ).toDF("Customer", "MechanicCode", "Product")

    val actualDF = RulesBank(applicationConfig, sparkSession).getIdentityDF(inputDF).head

    val expectedDF = inputDF

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - nonRPCustomerBifurcation should be able to successfully bifurcate customers") {
    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelEmptyApplication.conf"))
    val allocationDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType)
      )
    )

    val allocationRowList = List(
      Row("C1", "P2"),
      Row("C1", "P1"),
      Row("C1", "P3"),
      Row("C1", "P4"),
      Row("C2", "P5"),
      Row("C2", "P6"),
      Row("C3", "P7"),
      Row("C4", "P1"),
      Row("C4", "P2"),
      Row("C4", "P3"),
      Row("C4", "P4"),
      Row("C4", "P5")
    )

    // c1 -> 3, c2 -> 2, c3 -> 1, c4 -> 4
    val allocationRowRDD = sc.parallelize(allocationRowList)
    val allocationDF = sparkSession.createDataFrame(allocationRowRDD, allocationDFSchema)

    val scoreDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("score", StringType)
      )
    )

    val scoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7")
    )

    val scoreRowRDD = sc.parallelize(scoreRowList)
    val scoreDF = sparkSession.createDataFrame(scoreRowRDD, scoreDFSchema)

    val rawScoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7"),
      Row("C6", "p6", "0.7")
    )

    val rawScoreRowRDD = sc.parallelize(rawScoreRowList)
    val rawScoresDF = sparkSession.createDataFrame(rawScoreRowRDD, scoreDFSchema)

    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType)
      )
    )
    val expectedRowList1 = List(Row("C1"), Row("C4"))

    val expectedRowRDD1 = sc.parallelize(expectedRowList1)
    val expectedDF1 = sparkSession.createDataFrame(expectedRowRDD1, expectedDFSchema)

    val expectedRowList2 = List(
      Row("C2"), Row("C3"))

    val expectedRowRDD2 = sc.parallelize(expectedRowList2)
    val expectedDF2 = sparkSession.createDataFrame(expectedRowRDD2, expectedDFSchema)

    val expectedRowList3 = List(Row("C5"), Row("C6"))

    val expectedRowRDD3 = sc.parallelize(expectedRowList3)
    val expectedDF3 = sparkSession.createDataFrame(expectedRowRDD3, expectedDFSchema)

    val customerBifurcationConfig = ConfigFactory.parseString(
      """
        {
          "limit": 3
        }
      """.stripMargin)

    val customerRowList = List(
      Row("C1", "s1"),
      Row("C1", "s2"),
      Row("C1", "s3"),
      Row("C2", "s2"),
      Row("C3", "s3"),
      Row("C4", "s4"),
      Row("C5", "s5"))
    val customerRowRDD = sc.parallelize(customerRowList)
    val custDF = sparkSession.createDataFrame(customerRowRDD, expectedDFSchema)


    val outputDFList = RulesBank(applicationConfig, sparkSession)
      .nonRPCustomerBifurcation(allocationDF, rawScoresDF, scoreDF, custDF, customerBifurcationConfig)
    assertDataFrame(expectedDF1, outputDFList.head)
    assertDataFrame(expectedDF2, outputDFList(1))
    assertDataFrame(expectedDF3, outputDFList(2))
  }

  test("RulesBankTest - nonRPCustomerBifurcation should be able to successfully bifurcate customers banner-wise") {
    val applicationConfig = ConfigFactory.parseFile(
      new File("src/test/resources/AllocationLevelBannerApplication.conf"))
    val allocationDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("banner", StringType)
      )
    )

    val allocationRowList = List(
      Row("C1", "P2", "B1"),
      Row("C1", "P1", "B1"),
      Row("C1", "P3", "B2"),
      Row("C1", "P4", "B2"),
      Row("C2", "P5", "B1"),
      Row("C2", "P5", "B3"),
      Row("C2", "P1", "B3"),
      Row("C2", "P6", "B2"),
      Row("C3", "P7", "B1"),
      Row("C3", "P6", "B1"),
      Row("C3", "P8", "B1"),
      Row("C4", "P1", "B1"),
      Row("C4", "P2", "B1"),
      Row("C4", "P3", "B2"),
      Row("C4", "P4", "B2"),
      Row("C4", "P5", "B2")
    )

    // c1 -> 3, c2 -> 2, c3 -> 1, c4 -> 4
    val allocationRowRDD = sc.parallelize(allocationRowList)
    val allocationDF = sparkSession.createDataFrame(allocationRowRDD, allocationDFSchema)

    val scoreDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("score", StringType),
        StructField("banner", StringType)

      )
    )

    val scoreRowList = List(
      Row("C1", "P1", "0.1", "B1"),
      Row("C1", "P1", "0.1", "B2"),
      Row("C1", "P1", "0.1", "B3"),
      Row("C1", "P2", "0.2", "B1"),
      Row("C1", "P2", "0.2", "B2"),
      Row("C1", "P2", "0.2", "B3"),
      Row("C2", "p1", "0.3", "B1"),
      Row("C2", "p1", "0.3", "B2"),
      Row("C2", "p1", "0.3", "B3"),
      Row("C3", "p1", "0.5", "B1"),
      Row("C4", "p6", "0.7", "B2"),
      Row("C5", "p6", "0.7", "B3")
    )

    val scoreRowRDD = sc.parallelize(scoreRowList)
    val scoreDF = sparkSession.createDataFrame(scoreRowRDD, scoreDFSchema)

    val rawScoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7"),
      Row("C6", "p6", "0.7")
    )
    val rawScoreDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("product", StringType),
        StructField("score", StringType)

      )
    )
    val rawScoreRowRDD = sc.parallelize(rawScoreRowList)
    val rawScoresDF = sparkSession.createDataFrame(rawScoreRowRDD, rawScoreDFSchema)

    val expectedDFSchema = StructType(
      Array(
        StructField("customer", StringType),
        StructField("banner", StringType)
      )
    )
    val expectedRowList1 = List(
      Row("C1", "B2"),
      Row("C4", "B2"),
      Row("C1", "B1"),
      Row("C2", "B3"),
      Row("C3", "B1"),
      Row("C4", "B1")
    )

    val expectedRowRDD1 = sc.parallelize(expectedRowList1)
    val expectedDF1 = sparkSession.createDataFrame(expectedRowRDD1, expectedDFSchema)

    val expectedRowList2 = List(
      Row("C2", "B1"),
      Row("C2", "B2")
    )

    val expectedRowRDD2 = sc.parallelize(expectedRowList2)
    val expectedDF2 = sparkSession.createDataFrame(expectedRowRDD2, expectedDFSchema)

    val expectedRowList3 = List(
      Row("C6", "B3"),
      Row("C3", "B2"),
      Row("C1", "B3"),
      Row("C4", "B3"),
      Row("C6", "B1"),
      Row("C5", "B3"),
      Row("C6", "B2"),
      Row("C5", "B1"),
      Row("C5", "B2"),
      Row("C3", "B3"))

    val expectedRowRDD3 = sc.parallelize(expectedRowList3)
    val expectedDF3 = sparkSession.createDataFrame(expectedRowRDD3, expectedDFSchema)

    val customerBifurcationConfig = ConfigFactory.parseString(
      """
        {
          "limit": 2
        }
      """.stripMargin)

    val customerRowList = List(
      Row("C1", "s1"),
      Row("C1", "s2"),
      Row("C1", "s3"),
      Row("C2", "s2"),
      Row("C3", "s3"),
      Row("C4", "s4"),
      Row("C5", "s5"))
    val customerRowRDD = sc.parallelize(customerRowList)
    val custDF = sparkSession.createDataFrame(customerRowRDD, expectedDFSchema)


    val outputDFList = RulesBank(applicationConfig, sparkSession)
      .nonRPCustomerBifurcation(allocationDF, rawScoresDF, scoreDF, custDF, customerBifurcationConfig)
    assertDataFrame(expectedDF1, outputDFList.head)
    assertDataFrame(expectedDF2, outputDFList(1))
    assertDataFrame(expectedDF3, outputDFList(2))
  }

  test("RulesBankTest - nonRPCustomerBifurcation should be able to successfully bifurcate customers store-wise") {

    val allocationDFSchema =
      List(("customer", StringType), ("product", StringType), ("store", StringType))

    val allocationRowList = List(
      Row("C1", "P1", "s1"),
      Row("C1", "P2", "s1"),
      Row("C1", "P3", "s1"),
      Row("C1", "P4", "s2"),
      Row("C2", "P5", "s3"),
      Row("C2", "P6", "s3"),
      Row("C3", "P7", "s3"),
      Row("C4", "P1", "s4"),
      Row("C4", "P2", "s4"),
      Row("C4", "P3", "s4"),
      Row("C4", "P4", "s5"),
      Row("C4", "P5", "s5")
    )

    val allocationDF = createDF(allocationDFSchema, allocationRowList)

    val scoreDFSchema = List(("customer", StringType), ("product", StringType), ("score", StringType))

    val scoreRowList = List(
      Row("C1", "P1", "0.1"),
      Row("C1", "P2", "0.2"),
      Row("C2", "p1", "0.3"),
      Row("C3", "p1", "0.5"),
      Row("C4", "p6", "0.7"),
      Row("C5", "p6", "0.7")
    )

    val scoreDF = createDF(scoreDFSchema, scoreRowList)

    val expectedDFSchema = List(("customer", StringType), ("store", StringType))

    val expectedDF1 = createDF(expectedDFSchema,
      List(Row("C1", "s1"), Row("C2", "s3"), Row("C4", "s4"), Row("C4", "s5")))

    val expectedDF2 = createDF(expectedDFSchema, List(Row("C3", "s3"), Row("C1", "s2")))

    val expectedRowList3 = List(
      Row("C1", "s3"), Row("C2", "s2"), Row("C5", "s5"))

    val expectedDF3 = createDF(expectedDFSchema, expectedRowList3)

    val customerBifurcationConfig = ConfigFactory.parseString(
      """
        {
          "limit": 2
        }
      """.stripMargin)
    val customerRowList = List(
      Row("C1", "s1"),
      Row("C1", "s2"),
      Row("C1", "s3"),
      Row("C2", "s2"),
      Row("C3", "s3"),
      Row("C4", "s4"),
      Row("C5", "s5"))
    val custDF = createDF(expectedDFSchema, customerRowList)
    val outputDFList = RulesBank(applicationConfig, sparkSession)
      .nonRPCustomerBifurcation(allocationDF, scoreDF, scoreDF, custDF, customerBifurcationConfig)
    assertDataFrame(expectedDF1, outputDFList.head)
    assertDataFrame(expectedDF2, outputDFList(1))
    assertDataFrame(expectedDF3, outputDFList(2))
  }

  test("RulesBankTest - nonRPInfilling Popular Products - should return infilled DF - Products Infilling") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val applicationConfig = ConfigFactory.parseFile(new File("src/test/resources/AllocationLevelEmptyApplication.conf"))

    val genericDF = Seq(
      ("P1", "0.7", "S1"),
      ("P2", "0.6", "S2"),
      ("P2", "0.5", "S1")
    ).toDF("product", "rank", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C3"),
      ("C4")
    ).toDF("customer")

    val explodedRangeHierarchyCstDF = Seq(
      ("C1", "S1", 0),
      ("C1", "S2", 1),
      ("C1", "S3", 2),
      ("C2", "S1", 0),
      ("C2", "S2", 1),
      ("C3", "S2", 0),
      ("C4", "S1", 0),
      ("C4", "S2", 1),
      ("C4", "S3", 2),
      ("C5", "S1", 0),
      ("C6", "S1", 0)
    ).toDF("customer", "store", "rangeRank")

    val rangingConfig = ConfigFactory.parseString(
      """
        |{
        |"rangeRankOutputColumnName": "rangeRank",
        |}
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .nonRPInfilling(genericDF, customerWhoNeedInfillingDF, explodedRangeHierarchyCstDF, rangingConfig)
      .head

    val expectedDF = Seq(
      ("C3", "P1", "0.7", "S1", 3),
      ("C3", "P2", "0.6", "S2", 3),
      ("C3", "P2", "0.5", "S1", 3),
      ("C4", "P1", "0.7", "S1", 3),
      ("C4", "P2", "0.6", "S2", 3),
      ("C4", "P2", "0.5", "S1", 3)
    ).toDF("customer", "product", "rank", "store", "type")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - nonRPInfilling Popular Products - should return infilled DF - Products Infilling banner wise") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))

    val genericDF = Seq(
      ("P1", "0.7", "B1", "S1"),
      ("P1", "0.7", "B2", "S2"),
      ("P1", "0.7", "B3", "S3"),
      ("P2", "0.6", "B1", "S4"),
      ("P2", "0.6", "B2", "S3"),
      ("P3", "0.6", "B3", "S3"),
      ("P4", "0.5", "B3", "S3")
    ).toDF("product", "rank", "banner", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C3", "B1"),
      ("C3", "B2"),
      ("C3", "B3"),
      ("C4", "B1")
    ).toDF("customer", "banner")

    val explodedRangeHierarchyCstDF = Seq(
      ("C1", "S1", 0),
      ("C1", "S2", 1),
      ("C1", "S3", 2),
      ("C2", "S1", 0),
      ("C2", "S2", 1),
      ("C3", "S2", 0),
      ("C4", "S1", 0),
      ("C4", "S2", 1),
      ("C4", "S3", 2),
      ("C5", "S1", 0),
      ("C6", "S1", 0)
    ).toDF("customer", "store", "rangeRank")

    val rangingConfig = ConfigFactory.parseString(
      """
        |{
        |"rangeRankOutputColumnName": "rangeRank",
        |}
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .nonRPInfilling(genericDF, customerWhoNeedInfillingDF, explodedRangeHierarchyCstDF, rangingConfig)
      .head
    val expectedDF = Seq(
      ("B1", "C3", "P2", "0.6", "S4", 3),
      ("B1", "C3", "P1", "0.7", "S1", 3),
      ("B2", "C3", "P2", "0.6", "S3", 3),
      ("B2", "C3", "P1", "0.7", "S2", 3),
      ("B3", "C3", "P4", "0.5", "S3", 3),
      ("B3", "C3", "P3", "0.6", "S3", 3),
      ("B3", "C3", "P1", "0.7", "S3", 3),
      ("B1", "C4", "P2", "0.6", "S4", 3),
      ("B1", "C4", "P1", "0.7", "S1", 3)
    ).toDF("banner", "customer", "product", "rank", "store", "type")
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - nonRPInfilling Popular Products - should return infilled DF - Products Infilling Store wise") {

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val applicationConfig = ConfigFactory.parseFile(new File("src/test/resources/application.conf"))

    val genericDF = Seq(
      ("P1", "0.7", "S1"),
      ("P2", "0.6", "S2"),
      ("P3", "0.5", "S1")
    ).toDF("product", "rank", "store")

    val customerWhoNeedInfillingDF = Seq(
      ("C3", "S1"),
      ("C4", "S2")
    ).toDF("customer", "store")

    val explodedRangeHierarchyCstDF = Seq(
      ("C1", "S1", 0),
      ("C1", "S2", 1),
      ("C1", "S3", 2),
      ("C2", "S1", 0),
      ("C2", "S2", 1),
      ("C3", "S2", 0),
      ("C4", "S1", 0),
      ("C4", "S2", 1),
      ("C4", "S3", 2),
      ("C5", "S1", 0),
      ("C6", "S1", 0)
    ).toDF("customer", "store", "rangeRank")

    val rangingConfig = ConfigFactory.parseString(
      """
        |{
        |"rangeRankOutputColumnName": "rangeRank",
        |}
      """.stripMargin)
    val actualDF = RulesBank(applicationConfig, sparkSession)
      .nonRPInfilling(genericDF, customerWhoNeedInfillingDF, explodedRangeHierarchyCstDF, rangingConfig)
      .head
    val expectedDF = Seq(
      ("P1", "0.7", "S1", "C4", 0, 3),
      ("P2", "0.6", "S2", "C4", 1, 3),
      ("P2", "0.6", "S2", "C3", 0, 3),
      ("P3", "0.5", "S1", "C4", 0, 3)
    ).toDF("product", "rank", "store", "customer", "rangeRank", "type")

    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - getBestPromotionForAProduct - should return best promotion for a product") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))

    val promotionDF = Seq(
      ("P1", "Pr1", "B1", "S1", 10),
      ("P1", "Pr1", "B1", "S2", 10),
      ("P1", "Pr2", "B1", "S3", 10),
      ("P1", "Pr2", "B3", "S4", 10),
      ("P2", "Pr1", "B1", "S4", 1),
      ("P2", "Pr1", "B1", "S3", 2),
      ("P2", "Pr2", "B1", "S5", 3),
      ("P3", "Pr3", "B3", "S3", 4),
      ("P4", "Pr1", "B3", "S3", 5)
    ).toDF("product", "promotion", "banner", "store", "discount")

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .getBestPromotionForAProduct(promotionDF)
      .head
    val expectedDF = Seq(
      ("P1", "B3", "Pr2", "S4", 10),
      ("P2", "B1", "Pr1", "S3", 2),
      ("P3", "B3", "Pr3", "S3", 4),
      ("P1", "B1", "Pr1", "S2", 10),
      ("P4", "B3", "Pr1", "S3", 5)).
      toDF("product", "banner", "promotion", "store", "discount")
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - rankPromotions - should return ranked promotion with maximum product score") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._

    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))

    val promotionDF = Seq(
      ("P1", "Pr1", "B1", "S1", 10),
      ("P2", "Pr1", "B1", "S1", 9),
      ("P3", "Pr1", "B1", "S1", 11),
      ("P1", "Pr2", "B1", "S1", 4)
    ).toDF("product", "promotion", "banner", "store", "relevance")

    val rankingConfig = ConfigFactory.parseString(
      """
        |{
        |"relevanceColumnName": "relevance",
        |"isCustomerRequired": false
        |}
      """.stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession)
      .rankPromotions(promotionDF, rankingConfig)
      .head
    val expectedDF = Seq(
      ("P3", "Pr1", "B1", "S1", 11, 11, 1),
      ("P1", "Pr1", "B1", "S1", 10, 11, 1),
      ("P2", "Pr1", "B1", "S1", 9, 11, 1),
      ("P1", "Pr2", "B1", "S1", 4, 4, 2)).
      toDF("product", "promotion", "banner", "store", "relevance", "offerrelevance",
        "promotionrank")
    assertDataFrame(actualDF, expectedDF)
  }

  test("RulesBankTest - randomShuffle should return correct positions of column with random after start ") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))


    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")

    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "6"),
      ("C1", "P5", "Pr2", "0.9", "1", "5"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "6"),
      ("C2", "P4", "Pr2", "0.6", "1", "4"),
      ("C2", "P5", "Pr2", "0.9", "1", "5")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")

    val expectedDFF = expectedDF.withColumn("rank", col("rank").cast(IntegerType))

    val config = ConfigFactory.parseString(
      """{
        | rankingColumn: "rank",
        | startPosition: "4"
        |}""".stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).randomShuffle(inputDF, config)
      .head
    assert(actualDF.count()===expectedDF.count())
    assertDataFrame(actualDF.limit(3), expectedDFF.limit(3))

  }

  test("RulesBankTest - get entity for reading some data from table") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))


    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")
    inputDF.createOrReplaceTempView("input_table")


    val expectedDF = Seq(
      ("C1", "P1", "1", "0.7", "1"),
      ("C1", "P2", "2", "0.5", "1"),
      ("C1", "P3", "3", "0.9", "1"),
      ("C1", "P3", "4", "0.8", "1"),
      ("C1", "P4", "5", "0.6", "1"),
      ("C1", "P5", "6", "0.9", "1")
    ).toDF("Customer", "Product", "OfferRank", "Score", "type")


    val config = ConfigFactory.parseString(
      """{
        |      "type": "table.hive",
        |      "option": {
        |        "path": "input_table",
        |        "columnNames": ["Customer", "Product", "OfferRank", "Score", "type"]
        |      },
        |      "toLowerCase": true,
        |      "rename":{
        |        "rank":"OfferRank"
        |      },
        |      "cast": {
        |        "score": ["String"],
        |        "type": ["String"]
        |      },
        |      "literal": {
        |        "type": 1
        |      },
        |                  "filter_list": [
        |              {
        |                "left_column":"Customer",
        |                "operator":"=",
        |                "value": "C1"
        |              }
        |            ]
        |}""".stripMargin)

    val actualDF = RulesBank(applicationConfig, sparkSession).getEntity(config)
      .head
    assertDataFrame(actualDF, expectedDF)

  }

  test("RulesBankTest - get identity dataframe") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))


    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")


    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")



    val actualDF = RulesBank(applicationConfig, sparkSession).getIdentityDF(inputDF)
      .head
    assertDataFrame(actualDF, expectedDF)

  }

  test("RulesBankTest - get dummy dataframe") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))


    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")


    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")



    val actualDF = RulesBank(applicationConfig, sparkSession).dummy("dummy", inputDF)
      .head
    assertDataFrame(actualDF, expectedDF)

  }

  test("RulesBankTest - union dataframe") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))


    val XDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")

    val YDF = Seq(
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")


    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")



    val actualDF = RulesBank(applicationConfig, sparkSession).unionDataFrame(XDF, YDF)
      .head

    val XDFF = XDF.withColumn("rank", col("rank").cast(DoubleType))
    val expectedDFF = XDFF
    val actualDFF =
      try {
        RulesBank(applicationConfig, sparkSession).unionDataFrame(XDFF, YDF)
          .head}
      catch {
        case x: IllegalStateException => XDFF
      }


    assertDataFrame(actualDF, expectedDF)
    assertDataFrame(actualDFF, expectedDFF)



  }

  test("RulesBankTest - writeOutput test") {
    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._


    val applicationConfig = ConfigFactory.
      parseFile(new File("src/test/resources/AllocationLevelBannerApplication.conf"))


    val inputDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")
    inputDF.createOrReplaceTempView("input_table")


    val expectedDF = Seq(
      ("C1", "P1", "Pr1", "0.7", "1", "1"),
      ("C1", "P2", "Pr1", "0.5", "1", "2"),
      ("C1", "P3", "Pr1", "0.9", "2", "3"),
      ("C1", "P3", "Pr2", "0.8", "1", "4"),
      ("C1", "P4", "Pr2", "0.6", "1", "5"),
      ("C1", "P5", "Pr2", "0.9", "1", "6"),
      ("C2", "P1", "Pr1", "0.7", "1", "1"),
      ("C2", "P2", "Pr1", "0.5", "1", "2"),
      ("C2", "P3", "Pr1", "0.9", "2", "3"),
      ("C2", "P3", "Pr2", "0.8", "1", "4"),
      ("C2", "P4", "Pr2", "0.6", "1", "5"),
      ("C2", "P5", "Pr2", "0.9", "1", "6")
    ).toDF("Customer", "Product", "Promotion", "Score", "ScoreType", "rank")

    val config = ConfigFactory.parseString(
      """{
        |type: "table.hive",
        |            option: {
        |              path: "testwrite",
        |              header: true,
        |              saveMode: "overwrite",
        |            }
        |}""".stripMargin)

    val writeDF = RulesBank(applicationConfig, sparkSession).writeOutput(inputDF, config)
      .head

    writeDF.count()

    val actualDF = RulesBank(applicationConfig, sparkSession).getEntity(config).head

    assertDataFrame(actualDF, expectedDF)

  }

  def createDF(schema: List[(String, DataType)], rows: List[Row]): DataFrame = {
    val _rows = sc.parallelize(rows)
    val _schema = StructType(
      schema.map { case (name, datatype) => StructField(name, datatype) }
    )
    sparkSession.createDataFrame(_rows, _schema)

  }

  override def afterAll(): Unit = {
    val toBeDeletedTableNames = List("t1", "f1", "f2", "f3", "f4", "feature", "ppp", "testwrite")
    toBeDeletedTableNames.foreach { tableName =>
      // scalastyle:off
      println(s"Deleting table $tableName")
      // scalastyle:on
      sparkSession.sql(s"DROP TABLE IF EXISTS $tableName")
    }
      new File("metastore_db/db.lck").delete()
      new File("metastore_db/dbex.lck").delete()
    super.afterAll()
  }

}
