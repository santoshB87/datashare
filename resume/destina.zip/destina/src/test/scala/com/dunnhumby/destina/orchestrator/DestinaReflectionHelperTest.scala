package com.dunnhumby.destina.orchestrator
// scalastyle:off
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SQLContext
import org.scalatest.FunSuite

import com.dunnhumby.core.unittest.sharedcontext.SharedSparkSession
import com.dunnhumby.destina.configuration.DestinaGlobalConfiguration
import com.dunnhumby.destina.RulesBank

class DestinaReflectionHelperTest extends FunSuite with SharedSparkSession{

  test("dummy") {

    val applicationConfig = ConfigFactory.load("application.conf")
    val destinaGlobalConfiguration = new DestinaGlobalConfiguration(applicationConfig)

    val rulesBankObject = RulesBank(applicationConfig, sparkSession)

    val sqlC: SQLContext = sqlContext
    import sqlC.implicits._
    val df = Seq(
      ("aq8", "bat", "Store1", "Banner1"),
      ("pq4", "ball", "Store2", "Banner2"),
      ("de7", "bag", "Store3", "Banner3")
    ).toDF("Promotion", "Product", "Store", "Banner")

    val allocationState = AllocationState(rulesBankObject, "dummy", Map("str" -> "", "df" -> df))
    val output = DestinaReflectionHelper.getExecutableMethod(allocationState)
  }
}
