package com.dunnhumby.destina.postallocation
//scalastyle:off
import java.io.File

import com.typesafe.config.{Config, ConfigFactory, ConfigValueFactory}
import org.apache.hadoop.fs.FileSystem
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfterEach, FunSuite}

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.core.unittest.FileOperations
import com.dunnhumby.core.unittest.dataframe.DataFrameUtility._
import com.dunnhumby.core.unittest.sharedcontext.SharedSparkSession
import com.dunnhumby.destina.configuration.PostAllocationGlobalConfiguration

class PostAllocationHelperTest extends FunSuite with SharedSparkSession with BeforeAndAfterEach {

  Logger.getLogger("org").setLevel(Level.ERROR)
  val postAllocationConfig: Config = ConfigFactory
    .load("com/dunnhumby/destina/postallocation/postAllocationTest.conf")
  val applicationConfig: Config = ConfigFactory
    .load("com/dunnhumby/destina/postallocation/postAllocationGlobalConfig.conf")
  val postAllocationGlobalConfiguration: PostAllocationGlobalConfiguration = new PostAllocationGlobalConfiguration(
    applicationConfig)
  var fs: FileSystem = _

  override def beforeEach(): Unit = {
    super.beforeEach()
//    new File("metastore_db/db.lck").delete()
//    new File("metastore_db/dbex.lck").delete()
//    FileOperations.removeParentFolder("metastore_db/db.lck")
  }

  override def beforeAll(): Unit = {
    super.beforeAll()
    sqlContext.setConf("spark.sql.shuffle.partitions", "1")
    val metaNames = List("event", "tranche", "variation")
    metaNames.foreach{metaName =>
      val metaCSVPath = s"/com/dunnhumby/destina/postallocation/meta/$metaName/read/${metaName}Test.csv"
      val metaCSVReadConfig = ConfigFactory.parseString(
        s"""
           |{
           |  "type": "file.csv",
           |  "option": {
           |    "path": $metaCSVPath,
           |    "header": true,
           |    "resource": true
           |    "inferSchema": false
           |  }
           |}
      """.stripMargin)
      val csvReadDF = DataFrameReadWriteFormat(metaCSVReadConfig).readDataFrame(sqlContext)

      val configPath = "/com/dunnhumby/destina/postallocation/meta/metaWriteTest.json"
      val configResource = getClass.getResource(configPath).getFile
      val configFile = new File(configResource)
      val config = ConfigFactory.parseFile(configFile)

      val modifiedConfig = config.withValue("option.path",
        ConfigValueFactory.fromAnyRef(config.getString("option.path").replace("{metaName}", metaName)))

      DataFrameReadWriteFormat(modifiedConfig).writeDataFrame(csvReadDF)
      csvReadDF.createTempView(s"${metaName}_table_final")
      fs = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    }

    val allocationDF = sparkSession.read.option("header", "true")
      .csv("src/test/resources/com/dunnhumby/destina/allocationTest.csv")
    allocationDF.write.saveAsTable("default.allocation_output")

    val webIdentityDF = sparkSession.read.option("header", "true")
      .csv("src/test/resources/com/dunnhumby/destina/postallocation/uuiddata/web_identity_dim_c.csv")
    val identitySourceMapFctDF = sparkSession.read.option("header", "true")
      .csv("src/test/resources/com/dunnhumby/destina/postallocation/uuiddata/identity_source_map_fct.csv")
    val cardDimDF = sparkSession.read.option("header", "true")
      .csv("src/test/resources/com/dunnhumby/destina/postallocation/uuiddata/card_dim_c.csv")
    val hshdSegmentDF = sparkSession.read.option("header", "true")
      .csv("src/test/resources/com/dunnhumby/destina/postallocation/uuiddata/hshd_first_last_seg.csv")


    webIdentityDF.write.saveAsTable("default.web_identity_dim_c")
    identitySourceMapFctDF.write.saveAsTable("default.identity_source_map_fct")
    cardDimDF.write.saveAsTable("default.card_dim_c")
    hshdSegmentDF.write.saveAsTable("default.hshd_first_last_seg")

  }

  test("PostAllocationTest - Update Event ID - Fresh Deployment") {

    val postAllocationConfig: Config = ConfigFactory.load("com/dunnhumby/destina/postallocation/" +
      "postAllocationFreshDeploymentTest.conf")
    val postAllocationObject = PostAllocationHelper(sparkSession, applicationConfig, "rp", "20191114121212", fs)

    val metaCatalogueConfig = postAllocationConfig.getConfig("rp.metaCatalogue")
    val (actualEventID, actualTrancheId, actualVariationID) = postAllocationObject
      .updateEventID(metaCatalogueConfig)

    val (expectedEventID, expectedVariationId, expectedTrancheId) = ("1", "1", "1")
    assert(expectedEventID === actualEventID)
    assert(expectedVariationId === actualVariationID)
    assert(expectedTrancheId === actualTrancheId)
  }

  test("PostAllocationTest - Update Event ID - All tables exist") {

    val postAllocationConfig: Config = ConfigFactory
      .load("com/dunnhumby/destina/postallocation/postAllocationFreshDeploymentTest.conf")

    val postAllocationObject = PostAllocationHelper(sparkSession, applicationConfig, "rp", "20191114121212", fs)
    val postAllocationObjectNew = PostAllocationHelper(sparkSession, applicationConfig, "rp", "20191122121212", fs)

    val metaCatalogueConfig = postAllocationConfig.getConfig("rp.metaCatalogue")
    postAllocationObject.updateEventID(metaCatalogueConfig)
    val (actualEventID, actualTrancheId, actualVariationId) = postAllocationObjectNew.updateEventID(metaCatalogueConfig)

    val (expectedEventID, expectedTrancheId, expectedVariationId) = ("3", "1", "1")
    assert(expectedEventID === actualEventID)
    assert(expectedVariationId === actualVariationId)
    assert(expectedTrancheId === actualTrancheId)
  }

  test("PostAllocationTest - Control Group") {
    val allTable = List("control_group", "target_group", "program_control_group")
    allTable.foreach{ tableName =>
      sparkSession.sql(s"DROP TABLE IF EXISTS $tableName")
    }
    val eventID = "1"
    val runDate = "20191114151617"
    val propositionNameColumnName = postAllocationGlobalConfiguration.propositionNameColumnName
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val postAllocationObject = PostAllocationHelper(sparkSession, applicationConfig, "rp", runDate, fs)

    val allocationDF = DataFrameReadWriteFormat(postAllocationConfig.getConfig("rp.control.files.allocation"))
      .readDataFrame(sqlContext)

    postAllocationObject.applyControl(allocationDF,
      postAllocationConfig, eventID
    )

    val controlFilesConfig = postAllocationConfig.getConfig("rp.control.files")
    val targetGroupConfig = controlFilesConfig.getConfig("targetGroup")
    val controlGroupConfig = controlFilesConfig.getConfig("controlGroup")
    val programControlGroupConfig = controlFilesConfig.getConfig("programControlGroup")

    val extraPath = s"proposition_name=rp/" + s"event_id=$eventID/" + s"/run_time=$runDate"

    val basePathPcg = programControlGroupConfig.getString("writeConfig.option.path") + extraPath
    val basePathCg = controlGroupConfig.getString("writeConfig.option.path") + extraPath
    val basePathTg = targetGroupConfig.getString("writeConfig.option.path") + extraPath

    val actualControlDF = DataFrameReadWriteFormat(controlGroupConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(basePathCg))).readDataFrame(sparkSession.sqlContext)
    val actualTargetDF = DataFrameReadWriteFormat(targetGroupConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(basePathTg))).readDataFrame(sparkSession.sqlContext)
    val actualProgramControlDF = DataFrameReadWriteFormat(programControlGroupConfig.getConfig("writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(basePathPcg))).readDataFrame(sparkSession.sqlContext)

    val expectedControlDF = sparkSession.read.parquet("src/test/resources/com/dunnhumby/destina/" +
      "postallocation/group/controlgroup/expectedOutput/" + extraPath)
      .drop(propositionNameColumnName, {eventIdColumnName}, runDateColumnName)
    val expectedTargetDF = sparkSession.read.parquet("src/test/resources/com/dunnhumby/destina/" +
      "postallocation/group/targetgroup/expectedOutput/" + extraPath)
      .drop(propositionNameColumnName, {eventIdColumnName}, runDateColumnName)
    val expectedProgramControlDF = sparkSession.read.parquet("src/test/resources/com/dunnhumby/destina/" +
      "postallocation/group/programcontrolgroup/expectedOutput/" + extraPath)
      .drop(propositionNameColumnName, {eventIdColumnName}, runDateColumnName)

    assertDataFrame(actualControlDF, expectedControlDF)
    assertDataFrame(actualTargetDF, expectedTargetDF)
    assertDataFrame(actualProgramControlDF, expectedProgramControlDF)

  }

  test("PostAllocationTest - Send Files") {

    val eventID = "1"
    val runDate = "20191115102030"
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val typeName = postAllocationGlobalConfiguration.typeName
    val controlTypeName = postAllocationGlobalConfiguration.controlTypeName
    val targetTypeName = postAllocationGlobalConfiguration.targetTypeName
    val postAllocationObject = PostAllocationHelper(sparkSession, applicationConfig, "rp", runDate, fs)

    val postAllocationSendConfig: Config = ConfigFactory
      .load("com/dunnhumby/destina/postallocation/postAllocationTestSend.conf")

    val propositionConfig = postAllocationSendConfig.getConfig("rp")

    val allocationWarehouseTableName = postAllocationSendConfig.getString("rp.allocationWarehouse.readConfig.option.path")
    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    val allocationDF = DataFrameReadWriteFormat(postAllocationSendConfig.getConfig("rp.allocationWarehouse.readConfig"))
      .readDataFrame(sqlContext)

    val controlDFMap= postAllocationObject.applyControl(allocationDF,
      postAllocationSendConfig, eventID
    )
    postAllocationObject.generateSendControlFiles(allocationDF, controlDFMap,
      propositionConfig,
      eventID,
      runDate)

    val controlPathSuffix = s"/$eventIdColumnName=$eventID" + s"/$typeName=$controlTypeName" +
      s"/$runDateColumnName=$runDate"

    val targetPathSuffix = s"/$eventIdColumnName=$eventID" + s"/$typeName=$targetTypeName" +
      s"/$runDateColumnName=$runDate"

    val controlPath = propositionConfig.getString("allocationWarehouse.writeConfig.option.path") + controlPathSuffix
    val targetPath = propositionConfig.getString("allocationWarehouse.writeConfig.option.path") + targetPathSuffix

    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    val actualControlDF = DataFrameReadWriteFormat(propositionConfig.getConfig("allocationWarehouse.writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(controlPath))).readDataFrame(sparkSession.sqlContext)

    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    val actualTargetDF = DataFrameReadWriteFormat(propositionConfig.getConfig("allocationWarehouse.writeConfig")
      .withValue("option.path", ConfigValueFactory.fromAnyRef(targetPath))).readDataFrame(sparkSession.sqlContext)

    scala.util.control.Exception.ignoring(classOf[org.apache.spark.sql.AnalysisException]) {
      sparkSession.sql(s"msck repair table $allocationWarehouseTableName").count()
    }
    sparkSession.sql(s"refresh table $allocationWarehouseTableName").count()

    val expectedControlDF = sparkSession.read
      .parquet("src/test/resources/com/dunnhumby/destina/postallocation/recommendation/read/expectedOutput/" +
        controlPathSuffix).drop(runDateColumnName)

    val expectedTargetDF = sparkSession.read
      .parquet("src/test/resources/com/dunnhumby/destina/postallocation/recommendation/read/expectedOutput/" +
        targetPathSuffix).drop(runDateColumnName)

    assertDataFrame(actualControlDF.drop("run_time").distinct(), expectedControlDF.distinct())
    assertDataFrame(actualTargetDF.drop("run_time").distinct(), expectedTargetDF.distinct())
  }

  test("PostAllocationTest - Generate Final Formatted Files") {
    val eventID = "1"
    val runDate = "20191031121212"
    val propositionName = "rp"
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val propositionNameColumnName = postAllocationGlobalConfiguration.propositionNameColumnName

    val postAllocationObject = PostAllocationHelper(sparkSession, applicationConfig, propositionName, runDate, fs)

    val postAllocationConfig: Config = ConfigFactory
      .load("com/dunnhumby/destina/postallocation/postAllocationFinalFilesTest.conf")

    val propositionConfig = postAllocationConfig.getConfig(propositionName)

    val allocationOutputTable = propositionConfig.getString("allocationOutputTable")
    val allocationOutputDF = sparkSession.read.table(allocationOutputTable)

    val allocDF = allocationOutputDF
      .where(col(runDateColumnName) === runDate)

    val actualControlDF = sparkSession.read.parquet("src/test/resources/com/dunnhumby/destina/" +
      "postallocation/group/controlgroup/expectedOutput")
      .drop(propositionNameColumnName, {eventIdColumnName}, runDateColumnName)

    val actualTargetDF = sparkSession.read.parquet("src/test/resources/com/dunnhumby/destina/" +
      "postallocation/group/targetgroup/expectedOutput")
      .drop(propositionNameColumnName, {eventIdColumnName}, runDateColumnName)

    val controlDFMap = Map(
      "controlGroupDF" -> actualControlDF,
      "targetGroupDF" -> actualTargetDF
    )
    postAllocationObject.generateSendControlFiles(allocDF, controlDFMap,
      propositionConfig,
      eventID,
      runDate)

    postAllocationObject.generateFinalFormattedFiles(postAllocationConfig, propositionName, "1", "1", "0")
    val actualEventOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/actualOutput/axway/20191031121212/event_speoff_20191031121212.csv"
    val expectedEventOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/expectedOutput/axway/20191031121212/event_speoff_20191031121212.csv"

    val actualEventOutput = sparkSession.read.option("header", "true").csv(actualEventOutputPath)
    val expectedEventOutput = sparkSession.read.option("header", "true").csv(expectedEventOutputPath)

    assertDataFrame(actualEventOutput, expectedEventOutput)

    val actualTrancheOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/actualOutput/axway/20191031121212/tranche_speoff_20191031121212.csv"
    val expectedTrancheOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/expectedOutput/axway/20191031121212/tranche_speoff_20191031121212.csv"

    val actualTrancheOutput = sparkSession.read.option("header", "true").csv(actualTrancheOutputPath)
    val expectedTrancheOutput = sparkSession.read.option("header", "true").csv(expectedTrancheOutputPath)

    assertDataFrame(actualTrancheOutput, expectedTrancheOutput)

    val actualVariationOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/actualOutput/axway/20191031121212/variation_speoff_20191031121212.csv"
    val expectedVariationOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/expectedOutput/axway/20191031121212/variation_speoff_20191031121212.csv"

    val actualVariationOutput = sparkSession.read.option("header", "true").csv(actualVariationOutputPath)
    val expectedVariationOutput = sparkSession.read.option("header", "true").csv(expectedVariationOutputPath)

    assertDataFrame(actualVariationOutput, expectedVariationOutput)

    val actualRecommendationOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/actualOutput/axway/20191031121212/speoff_1_0_20191031121212.csv"
    val expectedRecommendationOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/expectedOutput/axway/20191031121212/speoff_1_0_20191031121212.csv"

    val actualRecommendationOutput = sparkSession.read.option("header", "true").csv(actualRecommendationOutputPath)
    val expectedRecommendationOutput = sparkSession.read.option("header", "true").csv(expectedRecommendationOutputPath)

    assertDataFrame(actualRecommendationOutput, expectedRecommendationOutput)

    val actualRecommendationZippedOutputPath1 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplit/actualOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_BANNER2_1.csv.gz"
    val actualRecommendationZippedOutputPath2 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplit/actualOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_BANNER2_2.csv.gz"
    val expectedRecommendationZippedOutputPath1 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplit/expectedOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_BANNER2_1.csv.gz"
    val expectedRecommendationZippedOutputPath2 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplit/expectedOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_BANNER2_2.csv.gz"

    val actualRecommendationZippedOutput1 = sparkSession.read.option("header", "false").csv(actualRecommendationZippedOutputPath1)
    val actualRecommendationZippedOutput2 = sparkSession.read.option("header", "false").csv(actualRecommendationZippedOutputPath2)
    val expectedRecommendationZippedOutput1 = sparkSession.read.option("header", "false").csv(expectedRecommendationZippedOutputPath1)
    val expectedRecommendationZippedOutput2 = sparkSession.read.option("header", "false").csv(expectedRecommendationZippedOutputPath2)

    assertDataFrame(actualRecommendationZippedOutput1.union(actualRecommendationZippedOutput2),
      expectedRecommendationZippedOutput1.union(expectedRecommendationZippedOutput2))

    val actualRecommendationClientOutputPath1 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitOne/actualOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_1.csv.gz"
    val actualRecommendationClientOutputPath2 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitOne/actualOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_2.csv.gz"
    val expectedRecommendationClientOutputPath1 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitOne/expectedOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_1.csv.gz"
    val expectedRecommendationClientOutputPath2 = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitOne/expectedOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_2.csv.gz"

    val actualRecommendationClientOutput1 = sparkSession.read.option("header", "false").csv(actualRecommendationClientOutputPath1)
    val actualRecommendationClientOutput2 = sparkSession.read.option("header", "false").csv(actualRecommendationClientOutputPath2)
    val expectedRecommendationClientOutput1 = sparkSession.read.option("header", "false").csv(expectedRecommendationClientOutputPath1)
    val expectedRecommendationClientOutput2 = sparkSession.read.option("header", "false").csv(expectedRecommendationClientOutputPath2)

    assertDataFrame(actualRecommendationClientOutput1.union(actualRecommendationClientOutput2),
      expectedRecommendationClientOutput1.union(expectedRecommendationClientOutput2))

    val actualRecommendationSplitTwoOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitTwo/actualOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_BANNER2.csv.gz"
    val expectedRecommendationSplitTwoOutputPath = "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitTwo/expectedOutput/cj/20191031121212/speoff_extra_1_1_20191031121212_BANNER2.csv.gz"

    val actualRecommendationSplitTwoOutput = sparkSession.read.option("header", "false").csv(actualRecommendationSplitTwoOutputPath)
    val expectedRecommendationSplitTwoOutput = sparkSession.read.option("header", "false").csv(expectedRecommendationSplitTwoOutputPath)

    assertDataFrame(actualRecommendationSplitTwoOutput, expectedRecommendationSplitTwoOutput)

  }

  test("PostAllocationTest - Generate Final Group Formatted Files") {
    val eventID = "1"
    val runDate = "20191115121212"
    val propositionName = "rp"
    val eventIdColumnName = postAllocationGlobalConfiguration.eventIdColumnName
    val runDateColumnName = postAllocationGlobalConfiguration.runDateColumnName
    val propositionNameColumnName = postAllocationGlobalConfiguration.propositionNameColumnName

    val postAllocationObject = PostAllocationHelper(sparkSession, applicationConfig, propositionName, runDate, FileSystem.get(sparkSession.sparkContext.hadoopConfiguration))
    import org.apache.spark.sql.functions.lit

    def readCsv(x:String):DataFrame = {sparkSession.read.option("header", "true").csv(x).withColumn(runDateColumnName,lit(runDate))}

    val variationPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/data/variationTest.csv"
    val targetPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/data/targetgroup/"
    val controlPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/data/controlgroup/"
    val programControlPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/data/programcontrolgroup/"

    readCsv(variationPath).createOrReplaceTempView("variation_dummy")
    readCsv(targetPath).createOrReplaceTempView("target_group_g")
    readCsv(controlPath).createOrReplaceTempView("control_group_g")
    readCsv(programControlPath).createOrReplaceTempView("program_control_group_g")

    val postAllocationConfig: Config = ConfigFactory
      .load("com/dunnhumby/destina/postallocation/postAllocationFinalGroupFilesTest.conf")

    val propositionConfig = postAllocationConfig.getConfig(propositionName)

   val  columnNamesList= List("customer", "Banner", "product", "score", "type", "subgroup",
    "Promotion", "Store", "OfferType", "PromotionStartDatetime", "PromotionEndDatetime", "Sponsored", "StoreRegion"
)
    postAllocationObject.generateFinalFormattedFiles(postAllocationConfig, propositionName, "1", "1", "0")

    val actualControlPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/actual/controlgroup/20191115121212/control_1_0_20191115121212.csv"
    val actualControlOutput = sparkSession.read.option("header", "true").csv(actualControlPath)
    val expectedControlExpectedDF = readCsv(controlPath).select(columnNamesList.map(col): _*)


    assertDataFrame(actualControlOutput, expectedControlExpectedDF)

    val actualTargetPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/actual/targetgroup/20191115121212/target_1_1_20191115121212.csv"
    val actualTargetOutput = sparkSession.read.option("header", "true").csv(actualTargetPath)
    val expectedTargetExpectedDF = readCsv(targetPath).select(columnNamesList.map(col): _*)


    assertDataFrame(actualTargetOutput, expectedTargetExpectedDF)

    val actualProgramControlPath = "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/actual/programcontrolgroup/20191115121212/programControl_1_2_20191115121212.csv"
    val actualProgramControlOutput = sparkSession.read.option("header", "true").csv(actualProgramControlPath)
    val expectedProgramControlExpectedDF = readCsv(programControlPath).select(columnNamesList.map(col): _*)


    assertDataFrame(actualProgramControlOutput, expectedProgramControlExpectedDF)

  }


  override def afterAll(): Unit = {

    val filesToBeDeletedPaths = List(
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/event/read/temp/eventTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/tranche/read/temp/trancheTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/variation/read/temp/variationTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/event/read/fresh/eventTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/event/read/fresh/eventTestSend",
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/tranche/read/fresh/trancheTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/meta/variation/read/fresh/variationTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/group/controlgroup/actualOutput/controlTest/",
      "src/test/resources/com/dunnhumby/destina/postallocation/group/targetgroup/actualOutput/targetTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/group/programcontrolgroup/actualOutput/" +
        "programcontrolTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/recommendation/write/recommendationTest",
      "src/test/resources/com/dunnhumby/destina/postallocation/finaldata/actualOutput/axway/",
      "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplit/actualOutput/cj/",
      "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitOne/actualOutput/cj/",
      "src/test/resources/com/dunnhumby/destina/postallocation/finaldataSplitTwo/actualOutput/cj/",
      "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/actual/controlgroup/",
      "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/actual/programcontrolgroup/",
      "src/test/resources/com/dunnhumby/destina/postallocation/controlgroupsendfile/actual/targetgroup/"
    )

    filesToBeDeletedPaths.foreach(FileOperations.removeParentFolder)

    val tablesToBeDeleted = List("event_table", "tranche_table", "variation_table",
      "control_group", "target_group", "program_control_group", "default.allocation_output", "default.web_identity_dim_c",
      "default.identity_source_map_fct", "default.card_dim_c", "default.hshd_first_last_seg")

    tablesToBeDeleted.foreach{ tableName =>
      sparkSession.sql(s"DROP TABLE IF EXISTS $tableName")
    }
    FileOperations.removeParentFolder("metastore_db/db.lck")
    super.afterAll()
  }
}
