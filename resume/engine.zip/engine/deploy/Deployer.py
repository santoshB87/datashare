import json
import os
import tarfile

import paramiko


class Deployer:

    tar_command = " tar -C "
    tar_options = " -xvzf "
    remove_command = "rm -rf "

    def __init__(self, host_type, client_name, environment_name,config_file):
        self.config = json.load(
            open(config_file))
        self.__ssh = self.__create_ssh_client__(self.config[host_type + "Node"], 22, self.config[host_type + "User"],
                                                os.environ[
                                                    client_name + "_" + environment_name + "_" + "pwd"])
        self.__sftp = self.__create_sftp_client__(self.config[host_type + "Node"], 22, self.config[host_type + "User"],
                                                  os.environ[
                                                      client_name + "_" + environment_name + "_" + "pwd"])

    def __create_sftp_client__(self, server, port, user, password):
        transport = paramiko.Transport((server, port))
        transport.connect(username=user, password=password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        return sftp

    def __create_ssh_client__(self, server, port, user, password):
        print "Paramiko ssh client"
        print "Server ",
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        print "server: {server}".format(server=server)
        print "user: {user}".format(user=user)
        ssh.connect(server, port, user, password);
        return ssh

    def sftp_file(self, file, targetDir):
        print(file + " TO : ")
        print(targetDir)
        self.__sftp.put(file, targetDir)

    def __create_tar__(self, localpath):
        tar_path = os.path.abspath(localpath)
        tar_name = os.path.basename(localpath)
        tar = tarfile.open(tar_name + ".tar.gz", "w:gz")
        os.path.dirname(localpath)
        tar.add(tar_path, arcname=tar_name)
        tar.close();
        return tar

    def execute_ssh_command(self, command):
        stdin, stdout, stderr = self.__ssh.exec_command(command)
        exit_status = stdout.channel.recv_exit_status()  # Blocking call
        if exit_status == 0:
            print(self.secure_print(command + " Command Executed successfully"))
        else:
            print(self.secure_print(command + " In Error"), exit_status)
            raise Exception("DEPLOYMENT FAILED!! " + str(stdout.readlines()) + str(stderr.readlines()))

    def sftp_directory(self, localpath, remotepath):
        tar = self.__create_tar__(localpath)
        print("Created Tar with name and local location: " + tar.name)
        self.execute_ssh_command("mkdir -p "+remotepath)
        self.sftp_file(tar.name, remotepath + os.path.basename(tar.name))
        print("Sftp-ed Tar with name and local location: " + tar.name)
        print("to Remote location: " + remotepath)
        os.remove(tar.name);
        print("Untarring on to the remote location: ")
        self.execute_ssh_command(
            self.tar_command + remotepath + self.tar_options + remotepath + os.path.basename(tar.name))
        self.execute_ssh_command(self.remove_command + remotepath + os.path.sep + os.path.basename(tar.name))
        print("Untarring and tar removal complete complete")

    def get_client(self, type):
        if (type == "ssh"):
            return self.__ssh
        elif (type == "sftp"):
            return self.__sftp

    def close_client(self, type):
        if (type == "ssh"):
            return self.__ssh.close()
        elif (type == "sftp"):
            return self.__sftp.close()

    def __del__(self):
        self.__sftp.close();
        self.__ssh.close();

    def deployDict(self, deployDict, type):
        for key, value in deployDict.iteritems():
            if (type == "dir"):
                self.sftp_directory(key, value)
            elif (type == 'file'):
                self.sftp_file(key, value)

    def deploy(self,obj,type):
        for dict in obj:
            dep = {dict["localPath"]: dict["remotePath"]}
            self.deployDict(dep,type)

    def closeAll(self):
        self.__sftp.close();
        self.__ssh.close();

    def secure_print(self, command_string):
        for pwd in [os.environ[os.environ["client_name"] + "_" + os.environ["environment_name"] + "_" + "pwd"],
                    os.environ[os.environ["client_name"] + "_" + "oracle" + "_" + "pwd"]]:
            if pwd in command_string:
                command_string = command_string.replace(pwd, "XXXXXX")
        return command_string
