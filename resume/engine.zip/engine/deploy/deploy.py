import json
import os
import re
from Deployer import Deployer

def sub_placeholders(config_file):
    file = open('deploy/deploy_template.json')
    string = file.read()
    mapping = get_mapping(config_file)
    obj = json.loads(re.sub(r'\$\[([^\]]*)\]', lambda x: mapping.get(x.group(1)), string))
    return obj

def get_mapping(config_file):
    return json.load(open(config_file))

def setup_oracle_wallet(deployer):
    server_pwd = os.environ[
        os.environ["client_name"] + "_" + os.environ["environment_name"] + "_" + "pwd"]
    oracle_pwd = os.environ[
        os.environ["client_name"] + "_" + "oracle" + "_" + "pwd"]
    engine_path = deployer.config["enginePath"]
    deployer.execute_ssh_command("dos2unix %s/oracle_wallet_setup.sh" % engine_path)
    deployer.execute_ssh_command("sh " + engine_path + "/oracle_wallet_setup.sh " + server_pwd +
                                 deployer.config["oracleDbAlias"] + " " +
                                 deployer.config["oracleDbUser"] + " " +
                                 oracle_pwd)

def execute_node_specific_commands(node, deployer):
    if(node == "server"):
        setup_oracle_wallet(deployer)


def deploy(node,deploy_config,config_file):
    deployer = Deployer(node, os.environ["client_name"], os.environ["environment_name"], config_file)
    deployer.deploy(deploy_config[node]["directories"], "dir")
    deployer.deploy(deploy_config[node]["files"], "file")
    for cmd in deploy_config[node]["commands"]:
        deployer.execute_ssh_command(cmd["command"])
    execute_node_specific_commands(node,deployer)
    deployer.closeAll()

def main():
    #Preparing the Configuration
    config_file = "./fs/programs/pyspark" + os.path.sep + os.environ['client_name'] + os.path.sep + os.environ[
        'environment_name'] + "_config.json"
    if (os.path.isfile(config_file)):
        deploy_config = sub_placeholders(config_file)
    else:
        raise Exception("Config File: " + config_file + "\n Does NOT EXIST!!, Please make sure that"
                        +"this file is present. For you reference please refer tesco_ie "
                        +"config files, present in the code base.")
    # Deploying to Server and Airflow
    for node in ["server"]:
        deploy(node,deploy_config,config_file)

if __name__ == "__main__": main()

