#!/bin/bash
echo "Deploying for client " $client_name " on " $environment_name
export no_proxy="localhost,127.0.0.1,dunnhumby.co.uk,dunnhumby.com"
#TODO: move below package install into docker image
yum -y install gettext
envsubst < ./fs/programs/pyspark/${client_name}/${environment_name}_config.json > ./fs/programs/pyspark/${client_name}/${environment_name}_config_temp.json
mv -f ./fs/programs/pyspark/${client_name}/${environment_name}_config_temp.json ./fs/programs/pyspark/${client_name}/${environment_name}_config.json
python ./deploy/deploy.py
