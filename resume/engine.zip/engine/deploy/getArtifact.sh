#!/bin/sh
export JOB_ID=$1
export no_proxy="localhost,127.0.0.1,dunnhumby.co.uk,dunnhumby.com"

if [ ! -z "$JOB_ID" ]
then
 echo $JOB_ID is the Job to be downloaded
 curl --verbose -k --header "PRIVATE-TOKEN: ${gitlab_api_token}" --output artifacts.zip https://dhgitlab.dunnhumby.co.uk/api/v4/projects/2102/jobs/${job_id}/artifacts
else
 echo SCHEDULED PIPELINE : DOWNLOADING LATEST ARTIFACT of ${CI_COMMIT_REF_NAME}
 curl -k --verbose --header "PRIVATE-TOKEN: ${gitlab_api_token}" --output artifacts.zip "https://dhgitlab.dunnhumby.co.uk/api/v4/projects/2102/jobs/artifacts/${CI_COMMIT_REF_NAME}/download?job=build_master"
fi

RC=$(unzip -qt artifacts.zip | echo $?)

if [ $RC == 0 ]
then
 unzip -o artifacts.zip
else
 echo "INVALID ZIP FILE!! EXITING DEPLOYMENT!!"
 unzip -t artifacts.zip
 exit $RC
fi