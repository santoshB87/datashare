import sys
from ape.airflow_interface import call_ape

def main(argv):
    job_type = argv[1]
    engine_path = argv[2]
    job_options = argv[3]

    sys.path.append(engine_path)


    call_ape(job_type, engine_path, job_options)
if __name__ == "__main__":
    main(sys.argv)