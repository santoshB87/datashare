import logging

logger = logging.getLogger(__name__)

# set up basic stream handler for logger
sh = logging.StreamHandler()
fmt = logging.Formatter('%(levelname)s - %(message)s')
sh.setLevel(logging.INFO)
sh.setFormatter(fmt)
logger.setLevel(logging.INFO)
logger.addHandler(sh)
