import os
import sys
import logging
import traceback
from ape.jobfactory2 import create_job2
from ape.errors import JobException

logger = logging.getLogger(__name__)


def call_ape(job_class,
             engine_path,
             job_options_string,
             config_file_name='config.json',
             feature_spec_config='feature_specs.json'):

    logger.info('')

    config_file_path = os.path.join(engine_path, config_file_name)
    feature_spec_config_file_path = os.path.join(engine_path, feature_spec_config)

    logger.info('Config file: {0}'.format(config_file_path))
    logger.info('feature spec Config file: {0}'.format(feature_spec_config_file_path))

    if not os.path.isfile(config_file_path):
        raise JobException('config file does not exist: {0}'.format(config_file_path))

    if not os.path.isfile(feature_spec_config_file_path):
        raise JobException('feature spec config file does not exist: {0}'.format(feature_spec_config_file_path))

    logger.info('*** Running job ***')
    try:
        job = create_job2(job_class=job_class, config_path=",".join([config_file_path, feature_spec_config_file_path]), options=job_options_string)
        job.run_job()
        job.clean_up()
        logger.info('*** Successfully completed job ***')
    except JobException as err:
        logger.error(err.message)
        logger.debug(traceback.print_exc())
        sys.exit(2)
    except Exception as err:
        logger.error('Unhandled exception: {0}'.format(str(err)), exc_info=1)
        sys.exit(2)