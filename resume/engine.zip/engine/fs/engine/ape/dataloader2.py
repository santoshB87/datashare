import logging
import re
import sh
import time
import traceback
import cmath as math
import os
import sys
import stat
import datetime
from pyhive.hive import connect
from pyhive.exc import Error

__author__ = 'michaela'

LOAD_DIM_ACTIVE_TODAY = 100
LOAD_DIM_CHANGES = 101
LOAD_DIM_BY_MODIFIED = 102

STAGE_SQOOP_STAGED = 200
STAGE_LOAD_WH = 201

TABLE_TYPE_FACT = "FACT"
TABLE_TYPE_DIM = "DIM"
TABLE_TYPE_FULL = "FULL"


class HiveConnection(object):

    def __init__(self, hive_connection, yarn_queue):
        self.conn = hive_connection
        self.active_cursor = None
        self.yarn_queue = yarn_queue

    def cursor(self):
        if self.active_cursor is None:
            self.active_cursor = self.conn.cursor()
        try:
            self.active_cursor.execute("set mapreduce.job.queuename=%s" % self.yarn_queue)
        except:
            # in case cursor has been closed
            self.active_cursor = self.conn.cursor()
            self.active_cursor.execute("set  mapreduce.job.queuename=%s" % self.yarn_queue)
        return self.active_cursor

    def close(self):
        if self.active_cursor is not None:
            self.active_cursor.close()
            self.active_cursor = None

        self.conn.close()


class SqoopDataLoader2:

    def __init__(self, config, market, app_log, db_schema=None, is_json_config=False, script_path='', load_date=None):
        """
        :param config: The response from the config framework url
        :param market: the market we are importing into in hadoop
        :param app_log: a defined logger
        :param db_schema: the destination schema in hive
        :param is_json_config: set if the config file is a json file
        :param script_path: path to the script
        :param load_date: date
        :return: DataLoader Object
        """
        self.script_path=script_path
        self.market = market
        self.dest_table_name = ''
        self.dest_stage_table_name = ''
        self.hive_connection = None
        self.applog = app_log
        self.configOptions = self.buildConfigDict(config, is_json_config)
        self.column_list_create = ''
        self.column_list_load = ''
        self.column_list_sqoop_map = ''
        self.column_list_sqooped = ''
        self.src_table = None
        self.date_partition_col = 'sqoop_load_date'
        self.sqoop_load_date_name = 'sqoop_load_date'
        self.sqoop_options_str = ' import '
        self.sqoop_cmd = self.configOptions['sqoop.cmd']
        self.sqoop_script_filename = 'sqoop_run_'+str(os.getppid())+'.sh' # final sqoop script for running defined job
        self.sqoop_exec_list = [self.sqoop_cmd,'import'] # not used as sqoop sets too many env variables

        if 'debug' in self.configOptions and self.configOptions['debug'].lower() == 'true':
            self.applog.setLevel(logging.DEBUG)

        if db_schema is None:
            self.db_schema = self.configOptions['sqoop.hadoop']['jdbc']['database']
        else:
            self.db_schema = db_schema

        self.db_schema_stage = self.db_schema + '_raw'

        host = str(self.configOptions['sqoop.hadoop']['jdbc']['host'])
        port = int(self.configOptions['sqoop.hadoop']['jdbc']['port'])
        database = str(self.configOptions['sqoop.hadoop']['jdbc']['database'])
        self.applog.info('Establishing connection. host:{host} port:{port} database:{database}'.format(host=host, port=port, database=database))
        tmp_con = connect(host=str(self.configOptions['sqoop.hadoop']['jdbc']['host']),
                          port=int(self.configOptions['sqoop.hadoop']['jdbc']['port']),
                          database=str(self.configOptions['sqoop.hadoop']['jdbc']['database']))

        self.hive_connection = HiveConnection(tmp_con, self.configOptions['sqoop.hadoop']['request_pool'])

        if not isinstance(load_date, str):
            self.sqoop_load_date = self._getHiveCurrentTimestamp()
        else:
            self.sqoop_load_date = load_date

    def _getDestinationTableName(self, table_type, load_stage):
        """
        Return the name of the table to load the stagged data into depending on
        the type of table we are processing

        :param load_stage: what stage of the process sqoop_stagged or hive load
        :param table_type: what table is being processed DIM or FACT
        :return: string
        """
        table_name = None

        if table_type == TABLE_TYPE_DIM:
            if load_stage == STAGE_SQOOP_STAGED:
                table_name = self.db_schema_stage + '.' + self.dest_table_name
            elif load_stage == STAGE_LOAD_WH:
                table_name = self.db_schema + '.' + self.dest_table_name

        elif table_type in (TABLE_TYPE_FACT,TABLE_TYPE_FULL):
            table_name = self.db_schema + '.' + self.dest_table_name
        else:
            raise Exception("Invalid Table type. Should be either %s or %s "%(TABLE_TYPE_DIM,TABLE_TYPE_FACT))

        return table_name

    def _configData2Dict(self,src_dic,atext,at_end = False):

        '''
        Split a piece of text with format [text].[text].[.] to a dict with each
        text as a key to other dict or a list
        :param atext:
        :return:  dict
        '''
        out_dict = src_dic
        last_str_done = at_end
        if not re.search('^oraoop|^mapreduce|^hadoop_opts',atext):
            components = atext.split('=')[0].split('.')
        else:
            components = [atext.split('=')[0]]

        #print "Printing: ",components, atext
        current_comp = 1
        for component in components:
            num_items = len(components)
            if current_comp == num_items and last_str_done == False:
                # we are at the end of the list
                #print component
                #key = component.split('=')[0].replace(' ','')
                key = component
                tmp_val = atext.split('=')[1:]
                if len(tmp_val) > 1:
                    # join them back together as they make up the value for the dict key
                    tmp_val = '='.join(tmp_val)
                else:
                    tmp_val = tmp_val[0]

                value = tmp_val.replace('\n','').lstrip(' ').rstrip(' ')
                if isinstance(out_dict,list):
                    col_name = ''
                    if re.search('^[0-9]+_',key):
                        col_name = "_".join(key.split('_')[1:]).replace(' ','').replace('\n','')
                    else:
                        col_name = key.replace(' ','').replace('\n','')
                    out_dict.append({col_name:value})
                else:
                    out_dict[key.replace(' ','').replace('\n','')] = value

                #print "Result",out_dict
                last_str_done = True
            else:
                if last_str_done == False:
                    if not component in out_dict:
                        if component == 'columns':
                            out_dict[component],last_str_done = self._configData2Dict([],'.'.join(atext.split('.')[1:]),last_str_done)
                        else:
                            out_dict[component],last_str_done = self._configData2Dict({},'.'.join(atext.split('.')[1:]),last_str_done)
                    else:
                        out_dict[component],last_str_done = self._configData2Dict(out_dict[component],'.'.join(atext.split('.')[1:]),last_str_done)

                    #print component,out_dict[component]

            current_comp += 1

        return out_dict, last_str_done


    def _getHiveCurrentTimestamp(self):
        """
        Helper function to run the now() function on the database so all
        datetimes used in the load process are consistent
        :return: datetime
        """
        database_time = None
        query_cur = self.hive_connection.cursor()
        query = "SELECT from_unixtime(unix_timestamp())"
        self.applog.info("Get Hive Timestamp : " + query)
        query_cur.execute(query)
        data  = query_cur.fetchall()
        if data != None:
            if isinstance(data[0][0],unicode):
                database_time = datetime.datetime.strptime(data[0][0],'%Y-%m-%d %H:%M:%S')
            else:
                database_time = data[0][0]
        return database_time

    def _parseConfigByRex(self,configData):
        '''
            converts the data from the configuration framwork to a collection of dictionaries
            for handling the data import

        :return: config dict
        '''

        # prepare sqoop options dict
        result = {'sqoop.oracle':{
                    'options':{'export':{}},
                    'tables':{}
                },
                'sqoop.hadoop':{}
        }

        result['sqoop.oracle']['options'] = {'export':{'env':{}  }}
        result['sqoop.oracle']['tables'] = {}
        for key,val in configData.items():

            # test for all export options
            if re.search('^sqoop\.oracle\.option\.export.+',key):
                if '.env.' in key: # test for environmental variables to set
                    result['sqoop.oracle']['options']['export']['env']['.'.join(key.split('.')[6:]).upper()] = val
                else:
                    result['sqoop.oracle']['options']['export']['.'.join(key.split('.')[5:])] = val

            # test for all table options
            elif re.search('^sqoop\.oracle\.tables\.([a-z0-9_\-]+)\.([a-z0-9_\-]+)\.*([a-z0-9_\-]*)$',key):
                reObj = re.search('^sqoop\.oracle\.tables\.([a-z0-9_\-]+)\.([a-z0-9_\-]+)\.*([a-z0-9_\-]*)$',key)

                if reObj.group(3) == '' or reObj.group(3) == None:
                    # this is no a column key
                    if not result['sqoop.oracle']['tables'].has_key(reObj.group(1)):
                        result['sqoop.oracle']['tables'][reObj.group(1)] = {}

                    result['sqoop.oracle']['tables'][reObj.group(1)][reObj.group(2)] = val
                elif reObj.group(3) != '':
                    # capture columns
                    if not result['sqoop.oracle']['tables'].has_key(reObj.group(1)):
                        result['sqoop.oracle']['tables'][reObj.group(1)] = {}
                    if not result['sqoop.oracle']['tables'][reObj.group(1)].has_key(reObj.group(2)):
                        result['sqoop.oracle']['tables'][reObj.group(1)][reObj.group(2)] = {}

                    result['sqoop.oracle']['tables'][reObj.group(1)][reObj.group(2)][reObj.group(3)] = val
                else:
                    raise SystemExit('No config keys for tables to be exported')

        return result

    def _get_fis_week_id(self,adate):
        query_cur = self.hive_connection.cursor()
        query = """
                    SELECT fis_week_id
                    FROM %(db_schema)s.date_dim
                    WHERE date_short_name = '%(date_short)s'
                """%({'db_schema':self.db_schema,'date_short':adate})
        self.applog.debug(query)
        query_cur.execute(query)
        data = query_cur.fetchall()
        if data != None:
            self.applog.info("Setting fis_week_id to %s"%(data[0][0]))
            return str(data[0][0])
        else:
            return ''

    def _has_date_dim(self, date_dim_table):
        query_cur = self.hive_connection.cursor()
        query = "select 1 from %(date_dim_table)s LIMIT 1"%({'date_dim_table':date_dim_table})
        self.applog.debug(query)
        try:
            query_cur.execute(query)
            return True
        except:
            self.applog.info("Table %s doesn't exist or connection error"%(date_dim_table))
            return False

    def _getLastLoadDate(self):

        query_cur = self.hive_connection.cursor()
        if not 'modified_date_col' in  self.src_table:
            self.src_table['modified_date_col'] = 'modified_dttm'

        query = """
            SELECT MAX(%(modified_date_col)s), MAX(%(load_date)s)
            FROM %(base_table)s
        """%({
            'base_table' : self.db_schema + '.' + self.dest_table_name,
            'modified_date_col' : self.src_table['modified_date_col'],
            'load_date' : 'sqoop_load_date'
        })
        self.applog.debug(query)
        query_cur.execute(query)
        data  = query_cur.fetchall()
        if data != None:
            if isinstance(data[0][0],str):
                start_delta = datetime.datetime.strptime(data[0][0],'%Y-%m-%d %H:%M:%S.%f')
            else:
                start_delta = data[0][0]

            if isinstance(data[0][1],str):
                sqoop_load_date = datetime.datetime.strptime(data[0][1],'%Y-%m-%d %H:%M:%S.%f')
            else:
                sqoop_load_date = data[0][1]
        else:
            raise Exception("Error. Can't calculate start delta for data load. Is 'sqoop_load_date' column missing? ")

        return (start_delta,sqoop_load_date)

    def _mergeChangedRecordToDestinationTable(self,drop_old=False):
        '''
        method to pull the staged records from the sqoop process and update the destination table.

        :return: Boolean
        '''
        try:

            column_list_load = self.column_list_load
            query_cur = self.hive_connection.cursor()
            # create new base table with only unchnaged records
            query = """DROP TABLE IF EXISTS %(base_table_new)s"""%({
                'base_table_new':self.db_schema + '.' + self.dest_table_name + '_new'
            })
            self.applog.debug(query)
            query_cur.execute(query)

            query = """CREATE TABLE %(base_table_new)s LIKE %(base_table)s """%({
                'base_table_new':self.db_schema + '.' + self.dest_table_name + '_new',
                'base_table':self.db_schema + '.' + self.dest_table_name,
            })
            self.applog.debug(query)
            query_cur.execute(query)

            if not 'modified_date_col' in  self.src_table:
                self.src_table['modified_date_col'] = 'modified_dttm'

            if not 'unique_column' in self.src_table:
                self.src_table['unique_column'] = self.src_table['split-by']

            # Create reconsiled view

            query_cur.execute("DROP VIEW IF EXISTS %(reconcile_view)s"%({'reconcile_view':self.db_schema_stage + '.reconcile_view'}))
            query = """
                CREATE VIEW %(reconcile_view)s AS
                SELECT t1.* FROM
                (SELECT %(column_list)s FROM %(base_table)s
                    UNION ALL
                    SELECT %(column_list)s,'%(sqoop_load_date)s' FROM %(base_table_changes)s ) t1
                JOIN
                    (SELECT %(unique_column)s, max(%(modified_date_col)s) max_modified FROM
                        (SELECT %(column_list)s FROM %(base_table)s
                        UNION ALL
                        SELECT %(column_list)s,'%(sqoop_load_date)s' FROM %(base_table_changes)s) t2
                    GROUP BY %(unique_column)s) s
                ON t1.%(unique_column)s = s.%(unique_column)s AND t1.%(modified_date_col)s = s.max_modified
            """%({
                'reconcile_view': self.db_schema_stage + '.reconcile_view',
                'unique_column':self.src_table['unique_column'],
                'base_table':self.db_schema + '.' + self.dest_table_name,
                'base_table_changes':self.db_schema_stage + '.' + self.dest_table_name,
                'modified_date_col':self.src_table['modified_date_col'],
                'column_list':column_list_load,
                'sqoop_load_date':self.sqoop_load_date
            })
            self.applog.info(query)
            query_cur.execute(query)

            # do record counts
            query = """SELECT COUNT(*) as old_record_count FROM %(base_table)s"""%({'base_table':self.db_schema + '.' + self.dest_table_name,})
            self.applog.debug(query)
            cnt_query_cur = self.hive_connection.cursor()
            cnt_query_cur.execute(query)
            record_count  = cnt_query_cur.fetchall()
            self.applog.info("%d records in current base table."%(record_count[0][0]))

            query = """SELECT COUNT(*) as new_record_count FROM %(reconcile_view)s"""%({'reconcile_view':self.db_schema_stage + '.reconcile_view',})
            self.applog.debug(query)
            cnt_query_cur.execute(query)
            record_count  = cnt_query_cur.fetchall()
            self.applog.info("%d records in new reconciled base table."%(record_count[0][0]))

            # materialise the reconciled view as new base table
            query = """INSERT INTO TABLE %(base_table_new)s SELECT * FROM %(reconcile_view)s"""%(
                {
                   'base_table_new':self.db_schema + '.' + self.dest_table_name + '_new',
                    'reconcile_view':self.db_schema_stage + '.reconcile_view',
                }
            )
            self.applog.debug(query)
            query_cur.execute(query)

            # drop current base table
            query = """
                DROP TABLE IF EXISTS %(base_table)s"""%({
                            'base_table':self.db_schema + '.' + self.dest_table_name
                })
            self.applog.info(query)
            query_cur.execute(query)

            # drop the view
            query = """
                DROP VIEW IF EXISTS %(reconcile_view)s
            """%({'reconcile_view':self.db_schema_stage + '.reconcile_view'})
            self.applog.info(query)
            query_cur.execute(query)

            # copy data back to base table.
            # we have to do this because I can't get rename to work correctly in cloudera 5.4.0 on test cluster

            query = """CREATE TABLE %(base_table)s LIKE %(base_table_new)s """%({
                'base_table_new':self.db_schema + '.' + self.dest_table_name + '_new',
                'base_table':self.db_schema + '.' + self.dest_table_name,
            })
            self.applog.info(query)
            query_cur.execute(query)

            query = """INSERT INTO TABLE %(base_table)s SELECT * FROM %(base_table_new)s"""%(
                {
                   'base_table_new':self.db_schema + '.' + self.dest_table_name + '_new',
                    'base_table':self.db_schema + '.' + self.dest_table_name,
                }
            )
            self.applog.info(query)
            query_cur.execute(query)

            # drop materialised view table
            query = """
                DROP TABLE IF EXISTS %(base_table_new)s"""%({
                            'base_table_new':self.db_schema + '.' + self.dest_table_name + '_new',
                })
            self.applog.info(query)
            query_cur.execute(query)

        except:
            self.applog.error(" mergeChangedRecordToDestinationTable Failed. ")
            self.applog.error('-'*60)
            error_str = traceback.format_exc()
            self.applog.error(error_str)
            self.applog.error('-'*60)
            raise(Exception("Table merge failed"))

    def _purgeData(self):
        pass

    def _generatePartitionDates(self,start_date,stop_date,increment):
        '''
        Given a start date,end date and daily increment, it return a list of dicts keyed by the end date
        with a list having a start and end date with the set increment of days apart.
        :param start_date: datetime value for start date
        :param stop_date: datetime value for end date
        :param increment: number of day increments to use in calculation
        :return: a list of date start/stop dicts convering the days passed in.
        '''
        date_list = []
        day_apart  = stop_date - start_date

        increment -= 1

        if day_apart.days < 1:
            date_list.append({start_date.strftime("%Y-%m-%d"):[start_date.strftime("%Y-%m-%d"),stop_date.strftime("%Y-%m-%d")]})
        else: # more days apart

            if increment > 0:
                loop_max = math.ceil(day_apart.days / increment)
            else:
                loop_max = day_apart.days

            loop_counter = 0
            while loop_counter <= loop_max:
                if start_date <= stop_date:
                    tmp_time_delta = datetime.timedelta(increment)
                    start_date_str = start_date.strftime("%Y-%m-%d")
                    end_date_str = (start_date + tmp_time_delta).strftime("%Y-%m-%d")
                    tmp_dict = {end_date_str:[start_date_str,end_date_str]}
                    date_list.append(tmp_dict)
                    start_date += tmp_time_delta + datetime.timedelta(1)
                    tmp_dict = {}
                loop_counter += 1

        return date_list

    def _createCurrentDimensionTable(self,src_table,table=None,create_query_partition='',load_query_partition=''):
        '''
        private method for creating a current data dimension table for an history dimension table

        :param src_table: Stage table to load from. All loads are assumed to be in [market]_ssewh_raw schema
        :param table: history table to use. current table will be named with _C replacing _H
        :param create_query_partition: string used in create query to define partitions Default None
        :param load_query_partition: string used in load query to define partitions. Default None
        :return: None
        '''

        target_table = self._getDestinationTableName(TABLE_TYPE_DIM,STAGE_LOAD_WH)

        try:
            query_cur = self.hive_connection.cursor()
            # create table
            query = """
                    CREATE TABLE IF NOT EXISTS %(table_name)s
                    (
                      %(column_def)s
                    )
                    %(partitions)s
                    STORED AS PARQUET
            """%({
                'table_name':target_table,
                'partitions':create_query_partition,
                'column_def': self.column_list_create
            })

            self.applog.info("Creating table %s"%(target_table))
            self.applog.info(query)
            query_cur.execute(query)

            # load data
            query="""
                INSERT OVERWRITE TABLE %(table_name)s
                %(partitions)s
                SELECT %(column_def)s
                FROM %(src_table_name)s
                WHERE %(sqoop_load_date_col)s = '%(sqoop_load_date)s'
            """%({
                'column_def':self.column_list_load,
                'table_name':target_table,
                'src_table_name': src_table,
                'partitions': load_query_partition,
                'sqoop_load_date_col': self.sqoop_load_date_name,
                'sqoop_load_date': self.sqoop_load_date.strftime("%Y-%m-%d"),
            })

            self.applog.info("Creating table")
            self.applog.info(query)
            query_cur.execute(query)
            query = "analyze table {table} {partition} compute statistics".format(
                table=target_table,
                partition=load_query_partition
            )
            self.applog.info(query)
            query_cur.execute(query)

        except Error, e:
            raise e


    def _checkForNewDataLoads(self):
        """
        Simple method used for full loads to check if there is any new data since the last load.
        this is done by comparing the number of load_ids and their record counts or the detect a
        recent modified_dttm. If either test fails or returns no changes, no new data is loaded.

        :return: Boolean on successful query or None on exception
        """
        query_load_ids = "Select %(load_id_col)s, count(*) from %(table_name)s group by %(load_id_col)s"
        query_data_changed = "Select max(%(modified_col)s) from %(table_name)s"

        try: # check hive
            query_cur = self.hive_connection.cursor()
            self.applog.info(query_load_ids)
            query_cur.execute(query_load_ids)
        except:
            return None

        try: # check cmd
            query_cur = self.hive_connection.cursor()
            self.applog.info(query_load_ids)
            query_cur.execute(query_load_ids)
        except:
            return None

    def setLoadPhase(self,in_loading_phase = False):
        self.load_data = in_loading_phase

    def buildConfigDict(self,configData,isJsonObj = False):
        #return self._parseConfigByRex(configData)
        res = {}
        if isJsonObj == False:
            for key,val in configData.items():
                data = key + ' = ' + val
                res = self._configData2Dict(res,data)[0]
        else:
            res = configData
        # prepare sqoop options dict
        result = {'sqoop.oracle':{
                'options':{'export':{}},
                'tables':{}
            },
            'sqoop.hadoop': {}
        }
        # extract table options
        #print res['sqoop']['cmd']
        for key, val in res['sqoop']['oracle']['option'].iteritems():
            # add key to dict
            result['sqoop.oracle']['options'][key] = val
        result['sqoop.oracle']['tables'] = res['sqoop']['oracle']['tables']
        result['sqoop.hadoop'] = res['sqoop']['hadoop']
        result['sqoop.cmd'] = res['sqoop']['cmd']


        return result

    def prepareLoad(self,table,table_type,load_date=False):


        # for fact tables check for date_dim
        if table_type == TABLE_TYPE_FACT:
            date_dim_table = self.db_schema + '.date_dim'
            if not self._has_date_dim(date_dim_table):
                raise Exception("Please load date_dim table first")

        # set mapreduce queue
        self.sqoop_options_str += '-D mapreduce.job.queuename={0} \\\n'.format(
            self.configOptions['sqoop.hadoop']['request_pool'])

        # build options
        # add jar files and wallet config
        for key in self.configOptions['sqoop.oracle']['options']['export'].keys():
            val = self.configOptions['sqoop.oracle']['options']['export'][key]
            if key in ('files','libjars'): # only one '-'
                self.sqoop_options_str += '-%s %s \\\n'%(key.replace('.','-'),val)
                self.sqoop_exec_list.append("-%s "%key.replace('.','-'))
                self.sqoop_exec_list.append(val)

        # added java class options
        self.src_table = self.configOptions['sqoop.oracle']['tables'][table]
        if not self.src_table.has_key('table_suffix') or self.src_table['table_suffix'].replace('"','') == '':
            self.src_table['table_suffix'] = ''
        else: # add _ if not first character
            if self.src_table['table_suffix'].find('_') <> 0: # check for _ is not first character
                self.src_table['table_suffix']  = '_' + self.src_table['table_suffix']

        if 'rename_table' in self.src_table:
            self.dest_table_name = self.src_table['rename_table'].lower() + self.src_table['table_suffix']
        else:
            try:
                self.dest_table_name = self.src_table['source_table'].split('.')[1].lower() + self.src_table['table_suffix']
            except:
                self.dest_table_name = self.src_table['source_table'].replace('.','_').lower() + self.src_table['table_suffix']

        if table_type == TABLE_TYPE_DIM:
            # load to intermidate stagging table
            self.dest_stage_table_name = self.dest_table_name + '_stage'
        elif table_type in (TABLE_TYPE_FACT,TABLE_TYPE_FULL):
            self.dest_stage_table_name = self.dest_table_name
        else:
            raise Exception("Selected Table type not supportted")

        for key in self.configOptions['sqoop.oracle']['options']['export'].keys():
            if not key in ('env','files','libjars'):
                val = self.configOptions['sqoop.oracle']['options']['export'][key]
                if 'mapreduce.' in key: # setup mapreduce options
                    self.sqoop_options_str += '-D%s=%s \\\n'%(key,val)
                    self.sqoop_exec_list.append('-D%s='%(key))
                    self.sqoop_exec_list.append(val)
                elif 'oraoop.' in key: # set oracle specific options
                    self.sqoop_options_str += '-D%s=%s \\\n'%(key,val)
                    self.sqoop_exec_list.append('-D%s='%(key))
                    self.sqoop_exec_list.append(val)


         # increase mappers if table config has it
        if self.src_table.has_key('mappers') and self.src_table['mappers'] <> '':
            self.configOptions['sqoop.oracle']['options']['export']['mappers'] = self.src_table['mappers']

        # add sqoop specific options
        for key in self.configOptions['sqoop.oracle']['options']['export'].keys():
            val = self.configOptions['sqoop.oracle']['options']['export'][key]
            if not key in ('env','files','libjars') and key.find('mapreduce') < 0 and key.find('oraoop') < 0:
                if key == 'mappers': # replace actual sqoop option string
                    key = 'm'

                if val in ('""',''," ",None): # if no value just add key
                    self.sqoop_options_str += '--%s \\\n'%(key.replace('.','-'))
                    self.sqoop_exec_list.append('--%s'%(key.replace('.','-')))
                else:
                    self.sqoop_options_str += '--%s %s \\\n'%(key.replace('.','-'),val)
                    self.sqoop_exec_list.append('--%s'%(key.replace('.','-')))
                    self.sqoop_exec_list.append(val)

        #self.sqoop_options_str += '--target-dir %s \\\n'%(self.src_table['target-dir'])
        #self.sqoop_exec_list.append('--target-dir')
        #self.sqoop_exec_list.append(self.src_table['target-dir'])

        self.sqoop_options_str += '--split-by %s \\\n'%(self.src_table['split-by'])
        self.sqoop_exec_list.append('--split-by')
        self.sqoop_exec_list.append(self.src_table['split-by'])

        # test for column mapping in config. fail if none
        if not self.src_table.has_key('columns'):
            raise Exception("No columns defined in config. This a requirement!!")

        # append load_date column
        self.src_table['columns'].append({self.sqoop_load_date_name:'String'})

        for col_item in self.src_table['columns']:
            for key,key_val in col_item.items():
                self.column_list_create +=  "%s %s , \n"%(key,key_val)
                self.column_list_load += "%s , \n"%(key)
                if key != self.sqoop_load_date_name : # don't add to sqoop c
                    self.column_list_sqoop_map += "%s=%s,"%(key,key_val.split('(')[0].lower())
                    self.column_list_sqooped += "%s, \n"%(key)

        self.column_list_load = self.column_list_load.strip(", \n")
        self.column_list_create = self.column_list_create.strip(", \n")
        self.column_list_sqooped = self.column_list_sqooped.strip(", \n")

        self.sqoop_options_str += '--table %s \\\n'%(self.src_table['source_table'])
        self.sqoop_options_str += '--columns "%s" \\\n' % (self.column_list_load.replace('\n', '').replace(self.sqoop_load_date_name, '').strip(' ,  ,'))
        self.sqoop_options_str += '--map-column-hive %s \\\n'%(self.column_list_sqoop_map.strip(','))
        
        self.sqoop_options_str += '--create-hcatalog-table \\\n'
        self.sqoop_options_str += '--hcatalog-database %s_ssewh_raw \\\n'%(self.market)


        self.sqoop_options_str += '--hcatalog-table %s \\\n'%(self.dest_stage_table_name)
        self.sqoop_options_str += "--hcatalog-storage-stanza 'STORED AS SEQUENCEFILE' \\\n"
        #self.sqoop_options_str += "--null-string '\\N' \\\n"
        #self.sqoop_options_str += "--null-non-string '\\N' \\\n"


        #self.column_list = self.column_list.strip(", \ \n") # remove trailing escape character

        # drop the stage table if it exists. Only run in prepare phase
        if load_date == False:
            query_cur = self.hive_connection.cursor()
            query  = """
                DROP TABLE IF EXISTS %(stage_table)s
            """%({'stage_table':self.market + '_ssewh_raw.' + self.dest_stage_table_name})
            self.applog.info("Dropping staged table in schema %s"%(self.market + '_ssewh_raw'))
            self.applog.info(query)
            query_cur.execute(query)


    def runScript(self, scriptfile):
        """
        a wrapper script to run the generated schell script for a sqoop job
        :param scriptfile: full path to script file
        :return:
        """
        try:
            script = sh.Command(scriptfile)
            script()
        except Exception:
            _, ex, traceback = sys.exc_info()
            self.applog.error("Sqoop job failed with error %s"%(ex.stderr))
            raise ex


    def generateJobScript(self,dim_load_date=None,table_type='Dim',query_where=None):
        '''

        :param load_type: Set to number of days if we are doing a delta load or 0 for full dump.
                          Full only works for Dim tables
        :param table_type: fact (Fact) table or Dimension (Dim)
        :param query_where: where condition to use in extract
        :return:
        '''

        query = ""
        sqoop_cmp_fp = None

        if query_where != None and query_where != '':
            query = query_where

            # set the sqoop load date to run date
            if 'run_date' in self.src_table['load_options']:
                dim_load_date  =  self.src_table['load_options']['run_date']
            elif 'run_date' in self.src_table:
                dim_load_date  = self.src_table['load_options']['run_date']
            elif 'run_date' in self.configOptions:
                dim_load_date  = self.configOptions['run_date']
            else:
                dim_load_date = datetime.datetime.now().strftime('%Y-%m-%d')

            self.sqoop_load_date = datetime.datetime.strptime(dim_load_date,"%Y-%m-%d")
        else:
            if table_type in ('Dim','DIM','dim'):
                if dim_load_date == None: # pull full dump
                    query = ""
                else: # pull changes at dim_load_date
                    if dim_load_date == LOAD_DIM_CHANGES:
                        load_dates = self._getLastLoadDate()
                        dim_load_date = load_dates[0]
                        sqoop_load_date = load_dates[1]
                        self.applog.info("Last Sqoop load date is : %s"%(sqoop_load_date.isoformat()))
                        self.applog.info("Last Max record modified date is : %s"%(dim_load_date.isoformat()))
                        if not 'modified_date_col' in  self.src_table and not 'modified_date_col' in  self.src_table['load_options']:
                            self.src_table['modified_date_col'] = 'modified_dttm'
                        query = "%(modified_date_column)s > TO_DATE('%(test_date)s', 'YYYY-MM-DD HH24:MI:SS') "%({'modified_date_column':self.src_table['modified_date_col'],'test_date':dim_load_date.strftime('%Y-%m-%d %H:%M:%S')})
                    elif dim_load_date == LOAD_DIM_BY_MODIFIED:
                        if 'modified_date_col' in  self.src_table['load_options']:
                            self.src_table['modified_date_col'] = str(self.src_table['load_options']['modified_date_col'])
                        if not 'modified_date_col' in  self.src_table:
                            self.src_table['modified_date_col'] = 'modified_dttm'

                        # use run_date as reference
                        if 'run_date' in self.src_table['load_options']:
                            dim_load_date  =  self.src_table['load_options']['run_date']
                        elif 'run_date' in self.src_table:
                            dim_load_date  = self.src_table['load_options']['run_date']
                        elif 'run_date' in self.configOptions:
                            dim_load_date  = self.configOptions['run_date']
                        else:
                            dim_load_date = datetime.datetime.now().strftime('%Y-%m-%d')

                        query = "%(modified_date_column)s <= TO_DATE('%(test_date)s', 'YYYY-MM-DD') "%({'modified_date_column':self.src_table['modified_date_col'],'test_date':dim_load_date})
                    elif dim_load_date == LOAD_DIM_ACTIVE_TODAY:

                        # use run_date as reference
                        if 'run_date' in self.src_table['load_options']:
                            dim_load_date  = self.src_table['load_options']['run_date']
                        elif 'run_date' in self.src_table:
                            dim_load_date  = self.src_table['run_date']
                        elif 'run_date' in self.configOptions:
                            dim_load_date  = self.configOptions['run_date']
                        else:
                            dim_load_date = datetime.datetime.now().strftime('%Y-%m-%d')

                        query = "valid_from_dttm <= TO_DATE('%(test_date)s', 'YYYY-MM-DD') AND valid_to_dttm > TO_DATE('%(test_date)s', 'YYYY-MM-DD') "%({'test_date':dim_load_date})
                    elif isinstance(dim_load_date,datetime.datetime):
                        # pull active data for given data
                        query = "valid_from_dttm <= TO_DATE('%(test_date)s', 'YYYY-MM-DD') and valid_to_dttm > TO_DATE('%(test_date)s', 'YYYY-MM-DD') "%({'test_date':dim_load_date.strftime('%Y-%m-%d')})
                    else:
                        raise Exception("No Dimension extract condition defined.()")

                # overwrite the sqoop load date
                self.sqoop_load_date = datetime.datetime.strptime(dim_load_date,"%Y-%m-%d")

            elif table_type in ('Fact','FACT','fact'):
                if 'modified_date_col' in  self.src_table['load_options']:
                    self.src_table['modified_date_col'] =  self.src_table['load_options']['modified_date_col']

                if not 'modified_date_col' in  self.src_table:
                    self.src_table['modified_date_col'] = 'date_id'

                query = "%(modified_date_column)s  <= TO_DATE('%(end_date)s', 'YYYY-MM-DD') and %(modified_date_column)s  >= TO_DATE('%(start_date)s', 'YYYY-MM-DD') "%({'modified_date_column':self.src_table['modified_date_col']
                                                                                                                                                                        ,'start_date':dim_load_date[0].strftime('%Y-%m-%d')
                                                                                                                                                                        ,'end_date':dim_load_date[1].strftime('%Y-%m-%d')
                                                                                                                                                                        })
            elif table_type in ('FULL','Full','full'): # no table type selected so it's your funeral.
                query = ""

            else:
                Exception("Load type is incorrect. You can't do a full load on a fact table")

        if query != "":
            self.sqoop_options_str += '--where "%s" \\\n'%(query)
        #self.sqoop_options_str += '--query "%s" \n'%(query)
        #self.sqoop_exec_list.append('--query')
        #self.sqoop_exec_list.append(query)

        #self.applog.info(self.sqoop_cmd + ' ' + self.sqoop_options_str.replace('\\',''))
        #self.applog.info(self.sqoop_cmd + self.sqoop_options_str)

        try:
            # generate sqoop script
            self.applog.info("Opening sqoop script for write : " + self.script_path + '/' + self.sqoop_script_filename)
            sqoop_cmp_fp = open(self.script_path + '/' + self.sqoop_script_filename,"w")
            sqoop_cmp_fp.write("#!/bin/bash\n\n")

            # set environmental variables
            for key in self.configOptions['sqoop.oracle']['options']['export'].keys():
                val = self.configOptions['sqoop.oracle']['options']['export'][key]
                if key == 'env': # set environmental variables if any
                    # make sure tns_admin comes first. THIS IS A HACK. env should really be a list instead of a dict
                    for key,val in self.configOptions['sqoop.oracle']['options']['export']['env'].items():
                        if key == "tns_admin":
                            sqoop_cmp_fp.write("export %s=%s\n"%(key.upper(),val))
                            break;

                    # now do the other keys
                    for key,val in self.configOptions['sqoop.oracle']['options']['export']['env'].items():
                        sqoop_cmp_fp.write("export %s=%s\n"%(key.upper(),val))


            sqoop_cmp_fp.write(self.sqoop_cmd + self.sqoop_options_str)
            sqoop_cmp_fp.close()
            os.chmod(self.script_path + '/' + self.sqoop_script_filename,stat.S_IRWXU)

        except Exception, e:

            if sqoop_cmp_fp != None:
                sqoop_cmp_fp.close()

            self.applog.error(" generateJobScript Failed. ")
            self.applog.error('-'*60)
            error_str = traceback.format_exc()
            self.applog.error(error_str)
            self.applog.error('-'*60)

        return self.script_path + '/' + self.sqoop_script_filename
        #print self.sqoop_exec_list

    def cleanUp(self):
        pass

    def LoadHiveTable(self, partition_values=None, create_current_dim=False, load_partition_sdate=None, load_partition_edate=None, load_partition_inc=None, load_partition_col=None, dim_load_date=None, table_type=None):
        '''
        Second phase of Sqoop data load into hive. This method is responsible for loading
        as table stagged in the [market]_ssewh_raw scheme into the required table and schema
        the stagged table is dropped afterwards.

        :param partition_values : list of partition value for a partitioned destination table
        :param create_current_dim : True|False create an _C dimension table only works for tables ending in _H
        :param load_partition_sdate : first date in partition list
        :param load_partition_edate : last date in partition list
        :param load_partition_inc : number of days to increment partition days by.
        :param dim_load_date : date to load changes from the CDM for
        :param table_type : what type of table is being loaded (dim | fact)

        :return: None
        '''

        insert_type='OVERWRITE'
        #if dim_load_date == None:
        #    insert_type='OVERWRITE'
        #else:
        #    insert_type='INTO'

        if load_partition_sdate != None:
            if not isinstance(load_partition_sdate,datetime.datetime) and isinstance(load_partition_sdate,str):
                load_partition_sdate = datetime.datetime.strptime(load_partition_sdate,"%Y-%m-%d")

            if load_partition_col == None:
                if self.dest_table_name.lower() in ('prsn_pref_seg', 'hshd_pref_Seg','max_trans_date_dim', 'prsn_pricesense_seg'):
                    load_partition_col = "'%s'"%(load_partition_sdate.strftime("%Y-%m-%d 00:00:00"))
                else:
                    load_partition_col = "'%s'"%(self.sqoop_load_date.strftime("%Y-%m-%d 00:00:00"))
            else:
                self.date_partition_col = load_partition_col

        if load_partition_edate != None:
            if not isinstance(load_partition_edate,datetime.datetime) and isinstance(load_partition_edate,str):
                load_partition_edate = datetime.datetime.strptime(load_partition_edate,"%Y-%m-%d")

        start_time = time.time()
        load_partition_ranges = None
        tmp_cur = self.hive_connection.cursor()

        query = "select count(*) as num_row from %s"%(self.market + '_ssewh_raw.' + self.dest_stage_table_name)
        self.applog.debug(query)
        tmp_cur.execute(query)
        record_count  = tmp_cur.fetchall()
        staged_records = record_count[0][0]
        self.applog.info("%d records imported from CDM for table %s. Preparing to Load Hive DW"%(staged_records,self.market + '_ssewh_raw.' + self.dest_stage_table_name))
        if record_count[0][0] <= 0:
            # no data to load so return None
            self.applog.info("No Data was staged. Exiting.")
            # remove stage tavble if one exists
            query = "DROP TABLE IF EXISTS %s"%(self.market + '_ssewh_raw.' + self.dest_stage_table_name)
            self.applog.debug(query)
            tmp_cur.execute(query)

            # this is now done after creating the table. Table is only created if
            # its a full table load.
            #return None


        if not self.src_table.has_key('columns'):
            raise SystemExit("No columns defined in config. This a requirement!!")


        exclude_col = [self.date_partition_col]
        # build partition list
        load_query_partition = ''
        create_query_partition = ''
        has_partitions = False

        add_to_create_cols = False

        # create partition query strings
        if self.src_table.has_key('partition') and self.src_table['partition'].replace('"','') != '':
            exclude_col = [col.lower() for col in exclude_col]
            has_partitions = True
            if load_partition_col != None and self.date_partition_col in self.src_table['partition'].split(','):
                raise SystemExit("Can't use %s as a partition col with --partition-* options"%(self.date_partition_col))

            if partition_values != None:
                partition_col = self.src_table['partition'].split(',')
                if len(partition_col) == len(partition_values):
                    #add partition columns and value
                    for i,val in enumerate(partition_col):
                        load_query_partition += '%s="%s",'%(val.lower(),partition_values[i])

                        # find the partition col datatype
                        data_type = ''
                        col_found = False
                        for col_map in self.src_table['columns']:
                            for col_name, data_type in col_map.items():
                                if col_name.find(val.lower()) >= 0:
                                    exclude_col.append(col_name.lower())
                                    col_found = True

                            if col_found == True:
                                break

                        if data_type == '': # set default if column not in list
                            data_type  = 'String'

                        create_query_partition += '%s %s,'%(val.lower(),data_type)

                    load_query_partition = load_query_partition.strip(',')
                    create_query_partition = create_query_partition.strip(',')
                else:
                    raise Exception("Parition columns and values don't match")
            else:
                raise Exception("No  partition values supplied for partition cols %s"%(self.src_table['partition']))
        exclude_col = [col.lower() for col in exclude_col]


        column_list_tmp = []
        column_list_load_tmp = []
        for acol_create in self.column_list_create.split(", \n"):
            acol = acol_create.split(' ')[0].lower()
            if not acol.lower() in ",".join(exclude_col):
                column_list_tmp.append(acol_create.lower())

        for acol in self.column_list_load.split(", \n"):
            if not acol.lower().replace(" ","") in ",".join(exclude_col):
                column_list_load_tmp.append(acol.replace(' ','').replace(',','').lower())

        # remove trailing escape character
        column_list = ", \n".join(column_list_tmp)
        column_list_load = ", \n".join(column_list_load_tmp)


        # add load date partition if required
        if load_partition_sdate != None and load_partition_edate != None and load_partition_inc != None:
            has_partitions = True
            if load_partition_col == None:
                raise SystemExit("Date Partition column name not given.!!!")

            load_partition_ranges = self._generatePartitionDates(load_partition_sdate,load_partition_edate,load_partition_inc)
            if self.src_table.has_key('partition'):
                # add the 'load_date' column to list of partitions
                if not self.date_partition_col in self.src_table['partition'].split(','):
                    self.src_table['partition'] = self.date_partition_col + ',' + self.src_table['partition']
                    create_query_partition = self.date_partition_col + ' String,' + create_query_partition
            else:
                # create partition key
                self.src_table['partition'] = self.date_partition_col
                create_query_partition = self.date_partition_col + ' String'

        create_query_partition = create_query_partition.strip(',')

        fis_week_id_col = '\n'
        fis_week_id_col_create = '\n'
        fis_week_id_val = '\n'
        use_fis_week = False
        if table_type == TABLE_TYPE_FACT:
            # add fis_week_id for transaction_item_fact
            if self.dest_table_name.lower().find('transaction_item_fct') >= 0:
                fis_week_id_col_create = ',fis_week_id string'
                fis_week_id_col = ', fis_week_id '
                fis_week_id_val = ",'" + self._get_fis_week_id(load_partition_sdate.strftime("%Y-%m-%d")) + "'"
                use_fis_week = True


        try:
            table_name = self._getDestinationTableName(table_type, STAGE_SQOOP_STAGED)

            if has_partitions == True:
                create_query_partition = 'PARTITIONED BY ('+create_query_partition+')'
            else:
                create_query_partition = ''

            if dim_load_date != LOAD_DIM_CHANGES:

                query_cur = self.hive_connection.cursor()

                if table_type == TABLE_TYPE_FULL:
                    # for full table laods, drop the current warehouse table
                    query  = "DROP TABLE IF EXISTS %s"%(table_name)
                    self.applog.info("FULL data load so dropping existing table %s"%(table_name))
                    self.applog.debug(query)
                    query_cur.execute(query)

                #
                # HACK Alert
                # only create the table if we are doing a full load or we staged some data to load
                # ideally this should be done somewhere above this point. Code need some modularisation
                if table_type == TABLE_TYPE_FULL or staged_records > 0:
                    # create table
                    query = """
                            CREATE TABLE IF NOT EXISTS %(table_name)s
                            (
                              %(column_def)s
                              %(fis_week_id_col)s
                            )
                            %(partitions)s
                            STORED AS PARQUET
                    """%({
                        'table_name':table_name,
                        'partitions': create_query_partition,
                        'column_def': column_list,
                        'fis_week_id_col':fis_week_id_col_create
                    })

                    self.applog.info("Creating table %s"%(self.db_schema + '.' + self.src_table['source_table'].split('.')[1]))
                    self.applog.debug(query)
                    query_cur.execute(query)

                # HACK Alert
                # only create the table if we are doing a full load or we staged some data to load
                # ideally this should be done somewhere above this point. Code need some modularisation
                if staged_records <= 0:
                    self.applog.info("No data to load. Stopping load process")
                    return None

                if table_type == TABLE_TYPE_FACT:
                    # add sqoop date if not partitioned by it
                    if not self.sqoop_load_date_name in load_query_partition:
                        sqoop_load_date_value = ", '%s'"%(self.sqoop_load_date)
                    else:
                        sqoop_load_date_value = "\n"
                else:
                    sqoop_load_date_value = "\n"


                # load data
                if load_partition_ranges == None:
                    if has_partitions == True:
                        load_query_partition = 'PARTITION ('+load_query_partition+')'
                    else:
                        load_query_partition = ''
                    query="""
                        INSERT %(insert_type)s TABLE %(table_name)s
                        %(partitions)s
                        SELECT %(sqooped_column_def)s
                        %(sqoop_load_date_value)s
                        %{fis_week_id_val}s
                        FROM %(market)s_ssewh_raw.%(src_table_name)s
                    """%({
                        'insert_type':insert_type,
                        'column_def':column_list_load,
                        'sqooped_column_def':self.column_list_sqooped.replace("%s,"%(self.date_partition_col),''),
                        'table_name': table_name,
                        'src_table_name':self.dest_stage_table_name,
                        'partitions': load_query_partition,
                        'market':self.market,
                        'sqoop_load_date':self.sqoop_load_date,
                        'sqoop_load_date_value':sqoop_load_date_value,
                        'fis_week_id_col':fis_week_id_col,
                        'fis_week_id_val':fis_week_id_val

                    })

                    self.applog.info("Loading data into table")
                    self.applog.info(query)
                    query_cur.execute(query)
                    query = "analyze table {table} {partition} compute statistics".format(
                        table=table_name,
                        partition=load_query_partition
                    )
                    self.applog.info(query)
                    query_cur.execute(query)
                else:
                    for arange in load_partition_ranges:
                        loop_load_query_partition  = ''
                        for rkey,rval in arange.items():
                            #if not self.date_partition_col in self.src_table['partition'].split(','):
                            loop_load_query_partition = '%s="%s",'%(self.date_partition_col,rkey) + load_query_partition
                            loop_load_query_partition = loop_load_query_partition.strip(',')
                            loop_load_query_partition = 'PARTITION (' + loop_load_query_partition +')'
                            query="""
                                INSERT %(insert_type)s TABLE %(table_name)s
                                %(partitions)s
                                SELECT %(sqooped_column_def)s
                                %(sqoop_load_date_value)s
                                %(fis_week_id_val)s
                                FROM %(market)s_ssewh_raw.%(src_table_name)s
                                WHERE %(date_partition_col)s between "%(date_range1)s" and "%(date_range2)s"
                            """%({
                                'insert_type':insert_type,
                                'column_def':column_list_load,
                                'sqooped_column_def':self.column_list_sqooped.replace("%s,"%(self.date_partition_col),''),
                                'table_name': table_name,
                                'src_table_name':self.dest_stage_table_name,
                                'partitions': loop_load_query_partition,
                                'market':self.market,
                                'date_partition_col': load_partition_col,
                                'date_range1': rval[0] + " 00:00:00",
                                'date_range2': rval[1] + " 23:59:59",
                                'sqoop_load_date':self.sqoop_load_date,
                                'sqoop_load_date_value':sqoop_load_date_value,
                                'fis_week_id_col':fis_week_id_col,
                                'fis_week_id_val': (use_fis_week and (",'" + self._get_fis_week_id(rval[0]) + "'") or fis_week_id_val)
                            })

                            self.applog.info("Loading data into table")
                            self.applog.info(query)
                            query_cur.execute(query)
                            query = "analyze table {table} {partition} compute statistics".format(
                                table=table_name,
                                partition=loop_load_query_partition
                            )
                            self.applog.info(query)
                            query_cur.execute(query)

            else: # we are loading chances so no partition management.
                pass
                #self._mergeChangedRecordToDestinationTable()

            # create the current dimension table for an _H if we have been instructed to and if the table is truely a
            # history table.
            if create_current_dim == True and table_type == TABLE_TYPE_DIM:
                # load Current dim table if required
                src_table  = table_name
                self._createCurrentDimensionTable(src_table)

            # now drop staged table
            query_cur = self.hive_connection.cursor()
            query  = """
                DROP TABLE IF EXISTS %(stage_table)s
            """%({'stage_table':self.market + '_ssewh_raw.' + self.dest_stage_table_name})
            self.applog.info("Dropping staged table in schema %s"%(self.market + '_ssewh_raw'))
            self.applog.debug(query)
            query_cur.execute(query)

            self.applog.info("Load complete. Time taken %d seconds"%(time.time() - start_time))

        except Error, e:
            self.hive_connection.close()
            _, ex, traceback = sys.exc_info()
            self.applog.error("Sqoop job failed with error %s"%(ex))
            raise ex
