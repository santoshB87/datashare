from ape.job2 import Job2
from ape.errors import JobException
from dataloader2 import *
from engineconfig import load_json_configs
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class SqoopDataLoaderJob2(Job2):

    # Job parent class sets up self.properties and logger
    def __init__(self):
        super(SqoopDataLoaderJob2, self).__init__()
        self.partition_val = None
        self.config_file = None
        self.dim_load_date = None
        self.partition_start_date = None
        self.partition_end_date = None
        self.partition_date_col = None
        self.partition_inc = 1
        self.load_data = False
        self.run_date = None
        self.days_offset = None
        self.dim_load_date_active = False
        self.dim_load_date_active_now = False
        self.dim_load_date_modified_dttm = False
        self.dim_load_date_delta = False
        self.debug = False
        self.create_dim_current = False
        self.script_path = ''
        self.query_where = None
        self.configDic = None
        self.load_stage = None

    def prepare(self, config, options):
        super(SqoopDataLoaderJob2, self).prepare(config, options)
        self.config_file = config

        # load the json config
        config_cache, options = load_json_configs(config, options, logger)
        self.configDic = config_cache.get('SqoopOracleTableAndColumnMetadata2', True)
        market = config_cache.get('SSEHiveDatabasePrefix')

        if 'debug' in options and options['debug'].lower() == 'true':
            logger.setLevel(logging.DEBUG)

        # set the data load stage. Can be used to load already staged data
        if 'load_stage' in options:
            if options['load_stage'].lower() == 'false':
                self.load_stage = False
            else:
                self.load_stage = True
        else:
            self.load_stage = False

        src_table = None
        # append the options to the config object for the table
        # being processed. options key will be name of table to run
        if options is not None:
                src_table = options['src_table']

                request_pool = str(config_cache.get('SSERequestPool'))
                if 'SSERequestPool' in options:
                    request_pool = options['SSERequestPool']
                if not request_pool:
                    raise JobException("Error, config key 'SSERequestPool' is required")
                else:
                    self.configDic['sqoop']['hadoop']['request_pool'] = request_pool
                    options['request_pool'] = request_pool

                logger.info("Processing table %s"%(src_table))
                if not options in (None,'',{},[]):
                    # overwrite any table specific options if any
                    if 'load_options' not in self.configDic['sqoop']['oracle']['tables'][src_table]:
                        logger.info("Adding table load options.")
                        self.configDic['sqoop']['oracle']['tables'][src_table]['load_options'] = options
                    else:
                        for key,val in options:
                            if key in self.configDic['sqoop']['oracle']['tables'][src_table]['load_options']:
                                logger.info("Overwriting table load options key %s from %s => %s"%(
                                            key
                                            ,str(self.configDic['sqoop']['oracle']['tables'][src_table]['load_options'][key])
                                            ,str(val) )
                                        )
                            else:
                                logger.info("Adding table load options key %s => %s"%(
                                            key
                                            ,str(val) )
                                        )
                            if isinstance(val,unicode):
                                val = str(val)
                            self.configDic['sqoop']['oracle']['tables'][src_table]['load_options'][key] = val

        try:
            # apply the config
            job_config = self.configDic['sqoop']['oracle']['tables'][src_table]['load_options']
            self.market = market
            self.src_table = src_table.lower()
            self.table_type  = ('table_type' in job_config and job_config['table_type'].upper()) or 'FULL'
            self.script_path = ('script_path' in job_config and job_config['script_path']) or '/tmp'
            self.partition_date_col = ('partition_date_col' in job_config and job_config['partition_date_col']) or None
            self.partition_inc = ('partition_inc' in job_config and job_config['partition_inc']) or None
            self.dim_load_date_active_now = ('dim_load_date_active_now' in job_config and job_config['dim_load_date_active_now']) or False
            self.dim_load_date_modified_dttm = ('dim_load_date_modified_dttm' in job_config and job_config['dim_load_date_modified_dttm']) or False
            self.dim_load_date_active = ('dim_load_date_active' in job_config) and job_config['dim_load_date_active']
            self.create_dim_current = ('create_dim_current' in job_config) and (job_config['create_dim_current'] in (True,"True","1"))
            run_date = ('run_date' in job_config and str(job_config['run_date']) ) or str(config_cache.get('run_date'))
            self.query_where = ('query_where' in  job_config and job_config['query_where']) or None

            if 'rename_table' in job_config:
                logger.info('14')
                self.configDic['sqoop']['oracle']['tables'][src_table]['rename_table'] = job_config['rename_table']

        except (TypeError,KeyError),e:
            raise JobException("Required config item missing. \n %s"%(e))

        if self.table_type not in ('FULL','Full','full'):
            if run_date and (not run_date is None) and (run_date != 'None'):
                logger.info("Using run_date : '%s'"%(run_date))
                self.run_date = datetime.strptime(run_date,"%Y-%m-%d")
                self.configDic['sqoop']['oracle']['tables'][src_table]['load_options']['run_date'] = run_date
                self.configDic['run_date'] = run_date
            else:
                err_msg = "Error run_date is required. run_date can be passed via job_options"
                logger.error(err_msg)
                raise JobException(err_msg)

        # parse for run_date in query
        if self.query_where:

            config_keys = config_cache.get_keys()
            parsed_query = self.query_where

            for akey in config_keys:
                pattern = '#{{%s}}#'%(akey)
                logger.debug("Regex Pattern: " + pattern)
                if re.search(pattern,parsed_query,re.IGNORECASE):
                    val = config_cache.get(akey)
                    logger.debug("Replacing key: %s in where clause with %s"%(akey,val))
                    parsed_query = re.sub(pattern,val,parsed_query,flags=re.I)

            for akey,val in job_config.items():
                pattern = '#{{%s}}#'%(akey)
                logger.debug("Regex Pattern: " + pattern)
                if re.search(pattern,parsed_query,re.IGNORECASE):
                    logger.debug("Replacing key: %s in where clause with %s"%(akey,val))
                    parsed_query = re.sub(pattern,val,parsed_query,flags=re.I)

            logger.debug("Old: %s"%(self.query_where))
            self.query_where = parsed_query
            logger.debug("New: %s"%(self.query_where))

        if self.table_type == 'DIM':
            if self.dim_load_date_active_now in (True,"True",1):
                self.dim_load_date = LOAD_DIM_ACTIVE_TODAY

            elif self.dim_load_date_modified_dttm in (True,"True",1):
                self.dim_load_date = LOAD_DIM_BY_MODIFIED

            elif self.dim_load_date_delta == True:
                self.dim_load_date = LOAD_DIM_CHANGES
                raise JobException("This feature is deprecated. Do not use!")
            else:
                self.dim_load_date = None

            if isinstance(self.dim_load_date_active, str):
                self.dim_load_date = datetime.strptime(self.dim_load_date_active,"%Y-%m-%d")
                self.partition_start_date = self.dim_load_date_active
                self.partition_end_date = self.dim_load_date_active
                self.partition_inc = 1
            else:
                self.partition_start_date = self.run_date.strftime("%Y-%m-%d")
                self.partition_end_date = self.run_date.strftime("%Y-%m-%d")
                self.partition_inc = 1
        else:
            try:
                if self.table_type == 'FACT':
                    self.days_offset = timedelta(int(job_config['number_of_days']))
                    self.partition_date_col = (('partition_date_col' in job_config) and job_config['partition_date_col']) or 'DATE_ID'
                else:
                    # full data pull
                    self.days_offset = timedelta(0)
                    self.run_date = datetime.now()
                    self.partition_date_col = None

            except (KeyError,Exception), e:
                raise JobException("partition_start_date,partition_end_date and partition_inc(increment in days) are required for FACT table loads . \n %s"%(e))

            self.partition_start_date = self.run_date - self.days_offset
            self.partition_end_date = self.run_date
            self.partition_inc = (('partition_inc' in job_config) and int(job_config['partition_inc'])) or 1 # 1 day increments if none set
            self.dim_load_date = (self.partition_start_date,self.partition_end_date)

    def run_job(self):
        try:

            sqoopJob = SqoopDataLoader2(self.configDic, self.market, logger, None, True, self.script_path, self.dim_load_date)
            sqoopJob.prepareLoad(self.src_table,self.table_type,self.load_stage)

            logger.info("Starting Phase 1: Sqoop data from source")
            sqoop_script_filename = None

             # First phase, Pull CDM data with sqoop script.
            if not self.load_stage:
                sqoop_script_filename = sqoopJob.generateJobScript(self.dim_load_date,self.table_type,self.query_where)
                sqoopJob.runScript(sqoop_script_filename)
            else:
                logger.info("load_stage set. skipping sqoop phase")

            # phase 2 load the data to the hive/impala warehouse
            logger.info("Starting Phase 2: Move data from staging area")
            sqoopJob.LoadHiveTable(self.partition_val, self.create_dim_current,
                                   self.partition_start_date,
                                   self.partition_end_date,
                                   self.partition_inc, self.partition_date_col,
                                   self.dim_load_date,
                                   self.table_type)

            # delete script file if exits
            if sqoop_script_filename != None:
                os.unlink(sqoop_script_filename)

        except Exception:
            _, ex, traceback = sys.exc_info()
            raise JobException(ex), None, traceback

        finally:
            # nothing
            pass

    def clean_up(self):
        pass