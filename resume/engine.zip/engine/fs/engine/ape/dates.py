import logging
from datetime import datetime, timedelta

from ape.hiveserver2.hs2session import HiveServer2Session
from ape.errors import JobException

logger = logging.getLogger(__name__)


def date_dim_available(impala_session, date_dim_name='date_dim'):
    impala_session.execute_statements('show tables')
    for row in impala_session.result_set:
        if row[0].lower() == date_dim_name:
            return True
    else:
        return False


def get_run_date(impala_session, requested_date_string, date_dim_loaded):
    # parse an incoming string into a date, allowing 'yesterday', 'last week' or a yyyy-mm-dd literal
    if requested_date_string == 'today':
        run_date = datetime.now()
        logger.info('"today" specified as run_date, setting to: {0}'.format(run_date.strftime("%Y-%m-%d")))
    elif requested_date_string == 'yesterday':
        run_date = (datetime.now() - timedelta(hours=24))
        logger.info('"yesterday" specified as run_date, setting to: {0}'.format(run_date.strftime("%Y-%m-%d")))
    elif requested_date_string == 'last week':
        if date_dim_loaded:
            logger.info('"last week" specified as run_date, finding last day of most recent fis_week:')
            query = """
                select to_date(fis_week_end_date)
                from date_dim
                where  fis_week_end_date < '{0}'
                order by fis_week_id desc limit 1
                """.format(datetime.now().strftime("%Y-%m-%d"))
            impala_session.execute_statements(query)
            run_date = datetime.strptime(str(impala_session.result_set[0][0]), '%Y-%m-%d')
            logger.info('Setting run_date to: {0}'.format(run_date.strftime("%Y-%m-%d")))
        else:
            logger.warning('"last week" specified as run_date but cannot find date dim, will not create run_date')
            run_date = None
    else:
        try:
            run_date = datetime.strptime(requested_date_string, '%Y-%m-%d')
            logger.info('Setting run_date to {0}'.format(run_date.strftime("%Y-%m-%d")))
        except ValueError:
            raise JobException('Cannot parse run date {0}, not valid YYYY-MM-DD string'.format(requested_date_string))
    return run_date


def offset_run_date(run_date, offset):
    # take a given date and offset it by a number of days
    try:
        offset = int(offset)
    except ValueError:
        raise JobException('Date offset of "{0}" cannot be converted to integer'.format(str(offset)))
    if offset < 0:
        raise JobException('Date offset cannot be negative')
    elif offset > 0:
        new_run_date = run_date - timedelta(days=offset)
        logger.info('Offsetting run date by {0} days, new value: {1}'.format(offset, new_run_date.strftime("%Y-%m-%d")))
        return new_run_date
    else:
        return run_date


def get_period_codes(impala_session, period_code_type, run_date, date_dim_loaded, number_of_periods=208):
    # find the most recent instance of a level in the date dimension, relative to run_date

    period_code_dict = dict()

    if period_code_type:
        if date_dim_loaded:
            logger.info('period_code_type of "{0}" specified, generating period_code values'.format(period_code_type))
            query = """
                select distinct {0}
                from date_dim
                where date_short_name <= '{1}'
                order by {0} desc limit {2}
                """.format(period_code_type, run_date.strftime('%Y-%m-%d'), number_of_periods)
            impala_session.execute_statements(query)

            for i, row in enumerate(impala_session.result_set, start=1):
                period_code_dict['period_code_{0}'.format(i)] = str(row[0])
            # include for backwards compatibility - older scripts written when we just had period_code
            period_code_dict['period_code'] = period_code_dict['period_code_1']
        else:
            logger.warning('period_code_type of {0} specified but cannot find date dim, will not create period_code(s)'
                           .format(period_code_type))
    return period_code_dict


def get_fis_weeks(impala_session, run_date, date_dim_loaded, number_of_weeks=208):
    # generate a dictionary of legacy ape date variables for backwards compatibility

    fis_week_dict = dict()

    if date_dim_loaded:

        logger.info('Querying date_dim to find fis week values')
        query = """
            select distinct fis_week_id, to_date(fis_week_start_date), to_date(fis_week_end_date)
            from date_dim
            where  date_short_name <= '{0}'
            order by fis_week_id desc limit {1}
            """.format(run_date.strftime('%Y-%m-%d'), number_of_weeks)
        impala_session.execute_statements(query)

        for i, row in enumerate(impala_session.result_set, start=1):

            fis_week_id = str(row[0])
            fis_week_start_date = datetime.strptime(str(row[1]).split(' ')[0], '%Y-%m-%d')
            fis_week_end_date = datetime.strptime(str(row[2]).split(' ')[0], '%Y-%m-%d')

            fis_week_dict['latest_fis_week_{0}'.format(i)] = fis_week_id
            fis_week_dict['start_fis_week_yyyy-mm-dd_{0}'.format(i)] = fis_week_start_date.strftime('%Y-%m-%d')
            fis_week_dict['start_fis_week_dd-mmm-yy_{0}'.format(i)] = fis_week_start_date.strftime('%d-%b-%Y')
            fis_week_dict['end_fis_week_yyyy-mm-dd_{0}'.format(i)] = fis_week_end_date.strftime('%Y-%m-%d')
            fis_week_dict['end_fis_week_dd-mmm-yy_{0}'.format(i)] = fis_week_end_date.strftime('%d-%b-%Y')

        fis_week_dict['ape_today_yyyy-mm-dd'] = run_date.strftime('%Y-%m-%d')
        fis_week_dict['ape_today_yyyymmdd'] = run_date.strftime('%Y%m%d')

    else:
        logger.warning('Cannot find date dim, will not create ape fis_week_* variables')
    return fis_week_dict


def generate_dates(requested_date, offset, period_code_type, impala_host, impala_port, request_pool, database_prefix):
    # connect to warehouse and get date variables into dictionary
    db = '{0}_ssewh'.format(database_prefix)
    with HiveServer2Session(host=impala_host, port=impala_port, database=db, request_pool=request_pool,
                            engine='impala', query_output='result_set', silent=True) as impala_session:
        date_dict = dict()
        date_dim_loaded = date_dim_available(impala_session)
        run_date = get_run_date(impala_session, requested_date, date_dim_loaded)

        if run_date:
            run_date = offset_run_date(run_date, offset)
            date_dict['run_date'] = run_date.strftime('%Y-%m-%d')

        date_dict.update(get_period_codes(impala_session, period_code_type, run_date, date_dim_loaded))

        date_dict.update(get_fis_weeks(impala_session, run_date, date_dim_loaded))

    return date_dict
