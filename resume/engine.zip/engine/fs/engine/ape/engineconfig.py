import sqlite3
import json
import os
import logging
import datetime
from sys import platform as _platform

logger = logging.getLogger(__name__)

class EngineConfig:
    """
    this class reads a json config file and caches it in a sqlite database
    for fast reads.
    :param json_file_path:
    :return: None
    """

    def __init__(self,json_file_path,market = None,debug=False):

        self.jsonObj = None

        # setup sql cache
        self.market = market
        self.jsonObj = None
        if debug:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.INFO)

        self.jsonfile_timestamp = os.stat(json_file_path).st_mtime
        self.json_file_last_updated =  datetime.datetime.fromtimestamp(self.jsonfile_timestamp)

        # test platform
        if _platform == "linux" or _platform == "linux2":
            os.pathsep = '/'
        elif _platform == "darwin":
            os.pathsep = '/'
        else: # assum windows
            os.pathsep = '\\'
        if self.market != None:
            #self.dbname = self.market + '.' + json_file_path.split(os.pathsep)[-1:][0].split('.')[0] + '.db'
            self.dbname = self.market + '.' + json_file_path.split(".json")[0] + '.db'
        else:
            self.dbname = json_file_path.split(".json")[0] + '.db'

        self.sqlitedb = sqlite3.connect(self.dbname)
        self.sqlitedb.isolation_level = 'EXCLUSIVE'
        self.config_table = 'config_cache'
        query = """
                CREATE TABLE IF NOT EXISTS %(table_name)s (
                    config_key varchar(200) PRIMARY KEY,
                    config_data blob,
                    modified  TIMESTAMP
                )
        """%({'table_name':self.config_table})
        self.sqlitedb.execute('BEGIN EXCLUSIVE')
        self.sqlitedb.execute(query);
        self.sqlitedb.commit()

        last_record_timestamp = None
        time_delta = None

        # check for changed config file
        query_cur = self.sqlitedb.cursor()
        query = "SELECT max(modified) from %(table_name)s"%({
            'table_name':self.config_table
        })
        query_cur.execute(query)
        data = query_cur.fetchone()
        #if data is not None:
        #    if data[0] is not None:
        #        last_record_timestamp = datetime.datetime.fromtimestamp(data[0])
        #        time_delta = self.json_file_last_updated - last_record_timestamp
        #
        #    logger.debug("last Record Timestamp %s"%(str(last_record_timestamp)))
        #    logger.debug("config file last updated %s"%(str(self.json_file_last_updated)))
        #    logger.debug("Time diff %s"%(str(time_delta)))
        #    if last_record_timestamp is None or (time_delta is not None and time_delta.seconds > 1):
        #        # the json config has chnaged, update records
        #        # get config data as json object

        with open(json_file_path,'r') as  fp:
            # read whole file:
            self.jsonObj = json.load(fp)


    def enable_debug(self):
        logger.setLevel(logging.DEBUG)

    def populate(self):
        """
        Load the data in the json object into the SQlite database
        :return:
        """

        #if self.jsonObj != None:
        #    for key,value in self.jsonObj.items():
        #        data_blob = base64.b64encode(cPickle.dumps(value,-1))
        #
        #        query = """REPLACE INTO %(table_name)s (config_key,config_data,modified)
        #                   VALUES ('%(config_col)s','%(config_blob)s',%(file_lastupdated)s)
        #                """%({
        #                    'table_name':self.config_table,
        #                    'config_col':str(key),
        #                    'config_blob':data_blob,
        #                    'file_lastupdated':self.jsonfile_timestamp
        #
        #                })
        #        self.sqlitedb.execute('BEGIN EXCLUSIVE')
        #        self.sqlitedb.execute(query);
        #        self.sqlitedb.commit()
        #else:
        #    logger.info("Config will be loaded from cache")
        pass



    def get_keys(self):
        """
        Return a lis of all config keys
        @return: list
        """
        #query = """
        #        SELECT config_key
        #        FROM %(table_name)s
        #"""%({ 'table_name':self.config_table })
        #
        #dataObj = []
        #quer_cur = self.sqlitedb.cursor()
        #quer_cur.execute(query)
        #try:
        #    for akey in quer_cur:
        #        dataObj.append(str(akey[0]))
        #except Exception, e:
        #    logger.debug(e)
        #    dataObj = []
        #
        #return dataObj

        return self.jsonObj.keys()

    def get(self,key,as_json_obj = False):
        """
        retrive some config data based on a key
        :param key: string name of key
        :return: config data related to the key
        """

        result = None
        #query = """
        #        SELECT config_data
        #        FROM %(table_name)s
        #        WHERE config_key = '%(config_key)s'
        #"""%({
        #    'table_name':self.config_table,
        #    'config_key':str(key)
        #})
        #logger.debug(query)
        #quer_cur = self.sqlitedb.cursor()
        #quer_cur.execute(query)
        #try:
        #    dataObj = cPickle.loads(base64.b64decode(quer_cur.fetchone()[0]))
        #except Exception, e:
        #    logger.debug(e)
        #    dataObj = ''

        # try and dump the data as a json string. If it fails, return
        # the same data as is.
        try:
            if as_json_obj == False:
                result = str(self.jsonObj[key])
            else:
                result = self.jsonObj[key]
        except:
            result = None

        return result


def load_json_configs(config,options,logger = None):
        '''
        A job helper function for loading two json string as
        python json objects. The two json objects are returned
        unmodified. It also makes use of the ConfigCache class.

        :param config: the config json string
        :param options: extra options in the form of a json string
        :param logger: a configured logger to use. Its optional
        :return: turple (EngineConfig,json)
        '''

        try:
            conf = EngineConfig(config)
            conf.populate()

        except Exception:
            raise Exception("Failed to load config %s"%(config))

        try:
            # get extra options
            fp = open(options,'r')
            conf_options = fp.read()
            fp.close()

        except Exception:
            conf_options = options
            logger.info("options processed as string")

        try:
            options_json = json.loads(conf_options)
            if logger != None:
                logger.info("Additional options:")
                for key,value in options_json.items():
                    logger.info("key: %s => %s"%(str(key),str(value)))
        except Exception, e:
            logger.info(e)
            options_json = None
            if logger != None:
                logger.info("No additional options specified")

        return conf, options_json
