import logging

logger = logging.getLogger(__name__)


class JobException(Exception):

    def __init__(self, *args, **kwargs):
        super(JobException, self).__init__(*args, **kwargs)
