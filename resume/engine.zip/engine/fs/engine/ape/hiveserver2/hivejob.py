from ape.hiveserver2.hs2session import HiveServer2Session
from ape.hiveserver2.hs2job import HS2Job


class HiveJob(HS2Job):

    def __init__(self):
        super(HiveJob, self).__init__()

    def run_job(self):

        host = str(self.properties.get_mandatory_value('HiveServerNodeName'))
        port = int(self.properties.get_mandatory_value('HivePortNumber') or 0)
        self.properties.error_on_failed_mandatory_gets()

        with HiveServer2Session(host=host,
                                port=port,
                                engine='hive',
                                verbose=False,
                                query_output='log',
                                request_pool=self.request_pool) as session:
            session.execute_statements(self.script)
