import os
import logging
from ape.job import Job
from ape.script import Script
from ape.errors import JobException

logger = logging.getLogger(__name__)


class HS2Job(Job):

    # Job parent class sets up self.properties
    def __init__(self):
        super(HS2Job, self).__init__()
        self.script = []
        self.substitution_prefix = '#{{'
        self.substitution_suffix = '}}#'
        self.request_pool = None

    def prepare(self, config, config_markup, options):
        super(HS2Job, self).prepare(config, config_markup, options)

        # get request pool / yarn queue
        if 'SSERequestPool' in self.properties:
            self.request_pool = self.properties['SSERequestPool']
        else:
            logger.warning('No "SSERequestPool" parameter found - will not set request pool/queue')
            self.request_pool = None

        # check that mandatory properties are present and assign to local vars
        try:
            hql_file_name = str(self.properties['hql_file_name'])
            program_path = str(self.properties['program_path'])
        except KeyError as err:
            raise JobException('Required key not found in properties: {0}'.format(err.message))

        full_program_path = os.path.join(program_path, hql_file_name)
        logger.info('Executing HQL script: {0}'.format(full_program_path))

        self.script = Script(
                path=full_program_path,
                subs_dict=self.properties,
                prefix=self.substitution_prefix,
                suffix=self.substitution_suffix)

    def run_job(self):
        raise JobException("Abstract Method")

    def clean_up(self):
        super(HS2Job, self).clean_up()
