from __future__ import print_function
import logging
from ape.retrying import retry
from socket import timeout as SocketTimeoutException
from ape.errors import JobException
from thrift.transport.TTransport import TTransportException

logger = logging.getLogger(__name__)


class HiveServer2Session:
    """wraps the hs2 connection and cursor objects, providing a method to
    execute a list of statements and if required retrieve results"""

    def __init__(self,
                 host,
                 port,
                 engine,
                 database='default',
                 delimiter=',',
                 noheader=False,
                 verbose=False,
                 silent=False,
                 stmnt_prefix='> ',
                 indent_length=7,
                 query_output='print',
                 request_pool=None,
                 timeout=6000
                 ):
        self.host = host
        self.port = port
        self.engine = engine
        self.database = database
        self.delimiter = delimiter
        self.noheader = noheader
        self.verbose = verbose
        self.stmnt_prefix = stmnt_prefix
        self.indent_length = indent_length
        self.query_output = query_output
        self.request_pool = request_pool
        self.timeout = timeout
        self.connection = None
        self.cursor = None
        self.result_set = None
        if silent:
            self.log = logger.debug
        else:
            self.log = logger.info
        self.open_session()

    def __enter__(self):
        if not self.connection:
            self.open_session()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close_session()

    def __call__(self, query):
        self.execute_statements(query)

    def _get_connection(self):
        # newer versions of impala.dbapi support hive, until then use pyhive.hive API
        connect_args = {
            'host': self.host,
            'port': self.port,
            'database': self.database}
        if self.engine.lower() == 'impala':
            logger.info('Impala engine specified, using implala.dbapi interface')
            from impala.dbapi import connect
            from impala.error import Error as HS2Error
            connect_args['use_kerberos'] = True
            connect_args['timeout'] = self.timeout
        elif self.engine.lower() == 'hive':
            logger.info('Hive engine specified, using pyhive.hive interface')
            from pyhive.hive import connect
            from pyhive.exc import Error as HS2Error
        else:
            raise ValueError('Invalid engine value: {0}'.format(self.engine))
        self.HS2Error = HS2Error
        return connect(**connect_args)

    def _initialise_cursor(self):
        if self.engine.lower() == "impala":
            self._execute_statement('set sync_ddl = True')
            if self.request_pool:
                self._execute_statement('set request_pool = "{0}"'.format(self.request_pool))
        elif self.engine.lower() == 'hive':
            if self.request_pool:
                # note - hive requires no quotes around queue name or whitespace around equals
                self._execute_statement('set mapreduce.job.queuename={0}'.format(self.request_pool))

    def _close_cursor_operation(self):
        if hasattr(self.cursor, 'close_operation'):
            self.cursor.close_operation()
        else:
            self.cursor.close()

    def _cancel_cursor_operation(self):
        if hasattr(self.cursor, 'cancel_operation'):
            self.cursor.cancel_operation()
        else:
            self.cursor.close()

    def _execute_statement(self, statement):
        self.log(self.stmnt_prefix + statement.replace('\n', '\n' + ' ' * self.indent_length + self.stmnt_prefix))
        try:
            self.cursor.execute(statement)
        except self.HS2Error as err:
            try:
                error_message = ' '.join(err.args)
            except TypeError:
                error_message = str(err.args)
            raise JobException('Statement failed: {0}'.format(error_message))
        except KeyboardInterrupt:
            if self.cursor:
                self._cancel_cursor_operation()
            raise JobException('Process interrupted by user')

    def _has_result_set(self):
        if hasattr(self.cursor, 'has_result_set'):
            return self.cursor.has_result_set is True
        elif hasattr(self.cursor, 'description'):
            return self.cursor.description is not None
        else:
            return False

    def _get_result_set(self):

        if self.query_output.lower() == 'result_set':
            query_output_function = logger.debug
        elif self.query_output.lower() == 'log':
            query_output_function = logger.info
        elif self.query_output.lower() == 'print':
            query_output_function = print
        else:
            raise ValueError('invalid query_output value: {0}'.format(str(self.query_output)))

        if self._has_result_set():
            if self.query_output.lower() == 'result_set':
                logger.debug('Retrieving cursor result set into {0}.result_set'.format(__name__))
                self.result_set = self.cursor.fetchall()
            else:
                if not self.noheader:
                    query_output_function(self.delimiter.join([str(i[0]) for i in self.cursor.description]))
                for row in self.cursor:
                    query_output_function(self.delimiter.join(map(str, row)))
        else:
            self.result_set = None
            query_output_function('Ok')

    @retry(stop_max_attempt_number=100, wait_exponential_multiplier=1000, wait_exponential_max=10000)
    # retry up to 100 times, wait 2^x * 1000 milliseconds between each retry, up to 10 seconds, then 10 seconds after
    def open_session(self):
        try:
            self.log('Connecting to HiveServer2 at {0}:{1}'.format(self.host, self.port))
            self.connection = self._get_connection()
            self.cursor = self.connection.cursor()
            self.log('Connection successful')
        except TTransportException as err:
            logger.warning('Connection attempt failed, retrying')
            raise JobException('Connection attempt failed: {0}, no more retries'.format(err.message))
        except SocketTimeoutException:
            logger.warning('Connection attempt failed, retrying')
            raise JobException('Connection attempts timed out, no more retries')
        else:
            self._initialise_cursor()

    def close_session(self):
        self.result_set = None
        try:
            self.connection.close()
        finally:
            pass

    def execute_statements(self, statement_list):
        if not self.connection:
            raise JobException('No connection to HiveServer2 at {0}:{1}'.format(self.host, self.port))
        # if a single string is passed in convert it to a single element list to stop the for-loop iterating over
        # individual chars in the string
        if type(statement_list) in(str, unicode):
            logger.debug('Converting string statement to list: "{0}"'.format(statement_list))
            statement_list = [statement_list]
        for statement in statement_list:
            self._execute_statement(statement)
            self._get_result_set()
            if self.verbose and hasattr(self.cursor, 'get_profile'):
                self.log(self.cursor.get_profile().replace('\n', '\n' + ' ' * self.indent_length))
            self._close_cursor_operation()
