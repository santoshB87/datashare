import os
import logging
import readline

logger = logging.getLogger(__name__)


class Completer:
    """provide a completer function for readline"""

    def __init__(self, words):
        self.words = words

    def complete(self, text, state):
        result = [x + " " for x in self.words if x.startswith(text)] + [None]
        return result[state]


class InteractivePrompt:
    """create an iterable interactive prompt with tab completion and history"""

    def __init__(self, prompt, history_file_name):
        self.history_file = os.path.join(os.path.expanduser('~'), history_file_name)
        self.prompt = prompt
        self.indent = len(prompt)

        vocab = ['select', 'from', 'where', 'group by', 'order by', 'having',
                 'create', 'drop', 'alter',
                 'insert', 'into', 'overwrite',
                 'table', 'view', 'database',
                 'invalidate metadata', 'compute', 'incremental', 'stats',
                 'partition', 'use', 'set', 'show', 'describe', 'formatted']

        completer = Completer(vocab)
        readline.parse_and_bind("tab: complete")
        readline.set_completer(completer.complete)

    def __enter__(self):
        return self.generate_statements()

    def __exit__(self, exc_type, exc_value, traceback):
        self.write_history()

    def read_history(self):
        if os.path.exists(self.history_file):
            logger.debug('Reading readline history from %s' % self.history_file)
            readline.read_history_file(self.history_file)

    def write_history(self):
        logger.debug('Writing readline history to %s' % self.history_file)
        readline.write_history_file(self.history_file)

    def generate_statements(self):
        """yield complete statements to calling code, as delimited by semicolon,
        exit on either interrupt or the command 'quit;' """
        self.read_history()
        while True:
            try:
                hql_string = raw_input(self.prompt + ' > ')
                while not hql_string.strip().endswith(';'):
                    hql_string += '\n' + raw_input('.' * self.indent + ' > ')
                if hql_string.strip().lower() == 'quit;':
                    break
                yield hql_string.rstrip(';')
            except KeyboardInterrupt:
                break
        return
