import os
from properties import Properties
from ape.errors import JobException


class Job2(object):
    SQOOP_JOB_CLASS = "SqoopDataLoaderJob2"
    HIVE_JOB_CLASS = "HiveHQLJob2"
    SPARK_JOB_CLASS = "PySparkJob2"
    PMML_RUNNER_JOB_CLASS = "PMMLRunnerJob2"

    def __init__(self):
        self.properties = Properties()
        self.job_properties = Properties()

    def prepare(self, config, options):
        self.properties.append_from_path(path=config.split(",")[0])
        self.properties.append_from_string(options)
        self.job_properties.append_from_string(options)
        self.config_path = config
        self.properties['program_path'] = os.path.abspath(os.path.join(os.path.dirname(self.config_path.split(",")[0]), '..'))

    def run_job(self):
        raise JobException("Abstract Method")

    def clean_up(self):
        self.properties.clear()

    def _get_abs_script_path(self, script):
        if os.path.isabs(script):
            s = script
        else:
            s = os.path.join(self.properties.get('program_path'), script)
        if not os.path.exists(s):
            raise JobException("Script '{0}' not found".format(s))
        return s
