import logging

#from ape.hiveserver2.hivejob import HiveJob
from ape.dataloaderjob2 import SqoopDataLoaderJob2
from ape.errors import JobException
from ape.job2 import Job2
from ape.pmml.pmmljob2 import PMMLRunnerJob2
from ape.pysparkjob2 import PySparkJob2


logger = logging.getLogger(__name__)


def create_job2(job_class, config_path, options):

    if job_class == Job2.SQOOP_JOB_CLASS:
        logger.info('Setting Job class to SqoopDataLoaderJob2')
        return_class = SqoopDataLoaderJob2()
    #Not planning on running any hive jobs at the time of writing. COuld change in the future so just commenting
    # this out for now rather than removing it - Jamie Thomson, 2017-04-20
    #elif job_class == Job2.HIVE_JOB_CLASS:
    #    logger.info('Setting Job class to HiveJob')
    #    return_class = HiveJob()
    elif job_class == Job2.PMML_RUNNER_JOB_CLASS:
        logger.info('Setting Job class to PMMLRunnerJob')
        return_class = PMMLRunnerJob2()
    elif job_class == Job2.SPARK_JOB_CLASS:
        logger.info('Setting Job class to PySparkJob')
        return_class = PySparkJob2()
    else:
        raise JobException("Class Not Supported: {0}".format(job_class))

    logger.debug('class from jobfactory: {0}'.format(type(return_class)))

    return_class.prepare(config_path, options)
    return return_class
