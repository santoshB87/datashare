import logging
from pyhive.hive import connect

__author__ = 'rudraps'
logger = logging.getLogger(__name__)



class HiveServer(object):
    def __init__(self, host, port, db, queue=None):
        self.host = host
        self.port = int(port)
        self.db = db
        self.yarn_queue = queue
        self.connection = None
        self.active_cursor = None

    def connect(self):
        logger.info("Connecting to hive server (%s:%s/%s)" % (self.host, self.port, self.db))
        self.connection = connect(host=self.host, port=self.port, database=self.db)

    def cursor(self):
        if self.active_cursor is None:
            self.active_cursor = self.connection.cursor()

        try:
            self.active_cursor.execute("set mapreduce.job.queuename=%s" % self.yarn_queue)
        except:
            # in case cursor has been closed
            self.active_cursor = self.connection.cursor()
            self.active_cursor.execute("set  mapreduce.job.queuename=%s" % self.yarn_queue)

        return self.active_cursor

    def close(self):
        logger.info("Closing connection to hive server (%s:%s/%s)" % (self.host, self.port, self.db))
        if self.active_cursor is not None:
            self.active_cursor.close()
            self.active_cursor = None

        self.connection.close()
