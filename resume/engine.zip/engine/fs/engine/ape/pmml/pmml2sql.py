import json
import datetime
import logging
from lxml import etree

__author__ = 'charleba'

logger = logging.getLogger(__name__)


class pmml2sql(object):

    def __init__(self, model_name, file_path, db_schema, impala,run_on_impala):
        self.impala_conn = impala
        self.model_name = model_name
        self.model = model_name
        self.configObj  = json.load(open(file_path.split('.')[:-1] + '.json'))
        self.run_on_impala = run_on_impala
        self.impala_conn = impala
        self.impala_pool='default'
        self.run_timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        self.db_schema = db_schema
        self.xml_namespace = self.configObj['pmml_namespace']


        if self.configObj.has_key('Output'):
            self.dest_table_name = "".join(self.model.split('.')[-1:]) + '_' + self.configObj['Output']['destDatasetName'] + "." + '_'.join(self.model.split('.')[:-1])
        else:
            raise SystemExit("Output JSON object not specified")
            #self.dest_table_name = self.db_schema.split('_')[0] + "_POB.POB" + "_" + '_'.join(self.model.split('.')[:-1])

    def run_scoring(self):
        pass

    def _runImpalaQuery(self,query,force_run=False):
        """
         Execute Query on Impala Database if we have a connection

        :param query:
        :return:
        """
        logger.info(query)
        logger.info("Running Query on Impala")
        if (self.impala_conn <> None and (force_run == True or self.run_on_impala == True)):
            try:
                 cursr = self.impala_conn.cursor()
                 cursr.execute("SET REQUEST_POOL='%s'"%(self.impala_pool))
                 cursr.execute(query)
            except Exception ,e:
                logger.error("Failed to create table. Exception was %s"%(e))
                raise e

    def _writeScriptFile(self,filename,query):
        """
            Write a give HQL script to the specified file

        :param filename: full path and file name of were to write too
        :param query: query string to write
        :return: None
        """
        logger.info("start query script file")
        logger.info(query)
        fp = open(filename,"w")
        fp.write(query)
        fp.close()
        logger.info("written query to HQL file: %s"%(filename))

    def clearHistory(self,run_on_impala=False,historyScriptFile=None):
        """
        drops the oldest X tables created for this mode
        :return: None
        """

        # if no history use 10 as default
        if not self.configObj.has_key('history'):
            self.configObj['history'] = 10

        queries = ""
        drop_list = []
        # get similar destination tables
        table_cur = self.impala_conn.cursor()
        find_query = "SHOW TABLES IN %s"%(self.dest_table_name.split('.')[0])
        logger.info(find_query)
        table_cur.execute(find_query)

        for table_name in table_cur:
            #print table_name[0]
            if table_name[0].find(self.dest_table_name.split('.')[1]) == 0 and table_name[0].find('_latest') < 0:
                drop_list.append(table_name[0])
        if len(drop_list) > 0:
            drop_list.sort(reverse=True)
            drop_list = drop_list[int(self.configObj['history']):]
            logger.info("Building table history script file")
            for table_name in drop_list:
                if table_name.find('_latest') < 0:
                    query="DROP TABLE IF EXISTS %s.%s;"%(self.dest_table_name.split('.')[0],table_name)
                    queries += query + '\n'
                    self._runImpalaQuery(query,run_on_impala);

        if run_on_impala == False and historyScriptFile != None:
            self._writeScriptFile(historyScriptFile,queries)

#class ScoreModelPMML(pmml2sql):
#
#   def __init__(self, model_name, file_path, db_schema, impala,run_on_impala):
#        super(scoreModel, self).__init__(model_name, file_path, db_schema, impala,run_on_impala)
#
#    def createImpalaTable(self):
#        pass

class regression2sql(pmml2sql):

    def __init__(self, config,model_name=None, file_path=None, db_schema=None, impala=None, run_on_impala=True):

        model_name = config['model_name']
        file_path = config['pmml_file']

        super(pmml2sql, self).__init__(model_name, file_path, db_schema, impala,run_on_impala)
        self.pmmlObj = etree.parse(file_path)
        self.table_col = []
        self.table_create_col = []
        self.score_coeff = []
        self.null_values = {}
        self.model_constant = None

        self.historyScriptFile = file_path + '/hql/' + self.model.split('.')[0] + '.' + self.model.split('.')[2] + \
                                '.history.' + self.run_timestamp + '.hql' # clear old table

        self.scoringScriptFile = file_path + '/hql/' + self.model.split('.')[0] + '.' + self.model.split('.')[2] + \
                                '.algorithm.' + self.run_timestamp + '.hql' # prepare table

        self.pobScriptFile = file_path + '/hql/' + self.model.split('.')[0] + '.' + self.model.split('.')[2] + \
                                '.' + self.dest_table_name.split('.')[1] + '.' + self.run_timestamp + '.hql' # target table creation HQL file

        self.allocationScriptFile = file_path + '/hql/' + self.model.split('.')[0] + '.' + self.model.split('.')[2] + \
                                '.allocation.' + self.run_timestamp + '.hql' # final views HQL

        self.script_list_file =  file_path + '/hql/' + model_name.split('.')[0] + '.' + model_name.split('.')[2] + '.hqlScripts.txt'

    def _generateWhereSQL(self):
        """
            Generate the where string based on the json config

        returns a where string with all the required filters.
        :return: string
        """
        where_str = ""
        if self.configObj.has_key('predicates'):
                first = 0
                for akey in self.configObj['predicates']:

                    if (first > 0):
                        where_str += """ AND %(column)s = "%(value)s"\n """%(akey)
                    else:
                        where_str += """ %(column)s = "%(value)s"\n """%(akey)
                    first = 1
        else:
            where_str = "TRUE"

        return where_str

    def _generateScoreSQL(self):
        """
            Generate the scoring SQL calculation for the query string

        returns the calculations of the score as a string
        :return: string
        """
        score_calc = self.model_constant
        for score_coeff in self.score_coeff:
                for key,val in score_coeff.items():
                    if key <> 'exponent':
                        score_calc += " + COALESCE ( %(colname)s , %(null_val)s) * ( %(coeff)s ) \n"%({'colname':key,'coeff':val,'null_val':self.null_values[key]})

        return "CAST(\n" + score_calc + "\n as DECIMAL(38,10)  )"

    def _clearHistory(self):
        """
        drops the oldest X tables created for this mode
        :return: None
        """

        # if no history use 10 as default
        if not self.configObj.has_key('history'):
            self.configObj['history'] = 10

        queries = ""
        drop_list = []
        # get similar destination tables
        table_cur = self.impala_conn.cursor()
        find_query = "SHOW TABLES IN %s"%(self.dest_table_name.split('.')[0])
        logger.info(find_query)
        table_cur.execute(find_query)

        for table_name in table_cur:
            #print table_name[0]
            if table_name[0].find(self.dest_table_name.split('.')[1]) == 0 and table_name[0].find('_latest') < 0:
                drop_list.append(table_name[0])
        if len(drop_list) > 0:
            drop_list.sort(reverse=True)
            drop_list = drop_list[int(self.configObj['history']):]
            logger.info("Building table history script file")
            for table_name in drop_list:
                if table_name.find('_latest') < 0:
                    query="DROP TABLE IF EXISTS %s.%s;"%(self.dest_table_name.split('.')[0],table_name)
                    queries += query + '\n'

                    if self.run_on_impala:
                        self._runImpalaQuery(query)

        if not self.run_on_impala:
            self._writeScriptFile(self.historyScriptFile,queries)

    def prepareTables(self):

        # apply history filter
        self._clearHistory()

        # get the requried fields and constants from the model
        scoring_model = self.pmmlObj.find('{%(xml_namespace)s}RegressionModel/'%({'xml_namespace':self.xml_namespace}))
        model_schema = self.pmmlObj.find('{%(xml_namespace)s}RegressionModel/{%(xml_namespace)s}MiningSchema'%({'xml_namespace':self.xml_namespace}))
        model_fields = self.pmmlObj.findall('{%(xml_namespace)s}RegressionModel/{%(xml_namespace)s}MiningSchema/{%(xml_namespace)s}MiningField'%({'xml_namespace':self.xml_namespace}))
        model_output_fields = self.pmmlObj.findall('{%(xml_namespace)s}RegressionModel/{%(xml_namespace)s}Output/{%(xml_namespace)s}OutputField'%({'xml_namespace':self.xml_namespace}))
        model_fields_coeffs = self.pmmlObj.findall('{%(xml_namespace)s}RegressionModel/{%(xml_namespace)s}RegressionTable/{%(xml_namespace)s}NumericPredictor'%({'xml_namespace':self.xml_namespace}))

        if scoring_model in ([],False,None):
            raise Exception("regression2sql can only handle Linear RegressionModels")


        tmp = self.pmmlObj.find('{%(xml_namespace)s}RegressionModel/{%(xml_namespace)s}RegressionTable'%({'xml_namespace':self.xml_namespace}))
        if tmp <> None:
            self.model_constant = tmp.get('intercept')
        else:
            raise Exception("No Regression Model constant found")

        # if OutputField element defined in PMML, use them for table column 
        if model_output_fields not in ([],False,None):
            for acol in model_output_fields:
                if acol.get('name') != 'score':
                    if acol.get('dataType') in ('double','float'):
                        data_type = 'decimal(38,10) '
                    else:
                        data_type = acol.get('dataType')
                        
                    self.table_create_col.append(acol.get('name') + ' ' + data_type )
                    self.table_col.append(acol.get('name') )
        else: # use predicted MiningField elements. This is not ideal
            for acol in model_fields:
                if acol.get('usageType') == 'predicted' and acol.get('name') != 'score':
                    self.table_col.append(acol.get('name'))
                    self.table_create_col.append(acol.get('name') + ' String')

        # handle replacement values for NULL values in MiningFields
        for acol in model_fields:
            if acol.get('missingValueReplacement') != None:
                self.null_values[acol.get('name')] = acol.get('missingValueReplacement')
            else:
                self.null_values[acol.get('name')] = 0

        # collect coefficients
        for afield in model_fields_coeffs:
            self.score_coeff.append(
                    {afield.get('name'):afield.get('coefficient'),
                     'exponent':afield.get('exponent')})

            # handle replacement values for NULL values in NumericPredictor
            if afield.get('missingValueReplacement') != None:
                self.null_values[afield.get('name')] = afield.get('missingValueReplacement')
            else:
                if not self.null_values.has_key(afield.get('name')):
                    self.null_values[afield.get('name')] = 0


        # set the table name based on the JSON config file. If not present, use detault POB
        col_build_str = ""
        if self.configObj.has_key('Output'):

            # check columns in json file match model if not raise exception
            if self.configObj['Output'].has_key('Columns'):
                for key,val in self.configObj['Output']['Columns'].items():
                    found = -1
                    found = self.table_col.index(key)
                    if found > -1:
                        col_build_str += " %(col_name)s    %(col_type)s   comment 'predicted model column', \n"%({'col_name':key,'col_type':val})
            else:
                for key in self.table_create_col:
                    col_build_str += " %(col_name)s   comment 'predicted model column', \n"%({'col_name':key})
                    #col_build_str += " %(col_name)s    %(col_type)s   comment 'predicted model column', \n"%({'col_name':key,'col_type':'String'})

            # build the required tables create statement
            query = """
                create table if not exists %(db_table_name)s
                        (
                          %(col_list)s
                           score                            DECIMAL(38,10)   comment "the calculated score",
                           created_dttm                     timestamp        comment "the date and time when the record was last created"
                        ) partitioned by (market string ,proposition string, model string)
                        STORED AS PARQUET;
            """%({
                    'db_table_name':self.dest_table_name + '_' + self.run_timestamp,
                    'col_list':col_build_str,
                })
        else:
            raise SystemExit("Output JSON object not specified")
            #for key in self.table_col:
            #        col_build_str += " %(col_name)s    %(col_type)s   comment 'predicted model column', \n"%({'col_name':key,'col_type':'String'})
            #
            #query = """
            #    create table if not exists %(db_table_name)s
            #            (
            #              %(col_list)s
            #               score                            decimal(38,10)   comment "the calculated score",
            #               created_dttm                     timestamp        comment "the date and time when the record was last created"
            #            ) partitioned by (market string ,proposition string, model string)
            #            STORED AS PARQUET;
            #"""%({
            #        'db_table_name':self.dest_table_name + '_' + self.run_timestamp ,
            #        'col_list':col_build_str,
            #    })

        #print query
        self._writeScriptFile(self.scoringScriptFile,query)

        # create table
        self._runImpalaQuery(query)

    def generateScores(self):
        # calculate the scores and load the table
        #print self.dest_table_name
        query = """
            INSERT OVERWRITE TABLE %(dest_db_table)s partition(market="%(market)s", proposition="%(proposition)s",model="%(model)s")
            SELECT
            %(col_list)s
            %(score_calc)s as score
            , now() as created_dttm
            FROM %(source_table)s
            WHERE %(where_clause)s;

            COMPUTE STATS %(dest_db_table)s;
        """%({
            'dest_db_table':self.dest_table_name + '_' + self.run_timestamp,
            'market':self.model.split('.')[2],
            'proposition':self.model.split('.')[0],
            'model':self.model.split('.')[1],
            'col_list':",".join(self.table_col)+',',
            'score_calc':self._generateScoreSQL(),
            'source_table':self.db_schema +'.'+ self.configObj['sourceDatasetName'],
            'where_clause':self._generateWhereSQL(),
        })

        #print query
        self._writeScriptFile(self.pobScriptFile,query)

        try:
            self._runImpalaQuery(query)
        except Exception ,e:
            self.impala_conn.cursor().execute("DROP TABLE IF EXISTS %s"%(self.dest_table_name + '_' + self.run_timestamp))
            logger.error("Failed to create table. Exception was %s"%(e))
            raise e

    def generateViews(self):
        query = """
            DROP VIEW IF EXISTS %(veiw_name1)s;
            DROP VIEW IF EXISTS %(veiw_name2)s;
            DROP VIEW IF EXISTS %(veiw_name3)s;
            DROP VIEW IF EXISTS %(veiw_name4)s;
            CREATE VIEW %(veiw_name1)s AS SELECT * FROM %(latest_table)s WHERE market='%(market)s' AND proposition='%(proposition)s' AND score IS NOT NULL;
            CREATE VIEW %(veiw_name2)s AS SELECT * FROM %(veiw_name1)s;
            CREATE VIEW %(veiw_name3)s AS SELECT * FROM %(latest_table)s WHERE score IS NOT NULL;
            CREATE VIEW %(veiw_name4)s AS SELECT * FROM %(veiw_name3)s;
        """%({
            'table_name':self.dest_table_name,
        'veiw_name1':self.dest_table_name + '_latest',
        'veiw_name2':self.dest_table_name.split('.')[0] + '.' + self.model.split('.')[0] + '_latest',
        'veiw_name3':self.dest_table_name.split('.')[0] + '.POB_' + self.model.split('.')[0] + '_' + self.model.split('.')[1] + '_' + self.model.split('.')[2] + '_latest',
        'veiw_name4':self.dest_table_name.split('.')[0] + '.POB_' + self.model.split('.')[0] + '_' + self.model.split('.')[2] + '_latest',
        'latest_table':self.dest_table_name + '_' + self.run_timestamp,
        'market':self.model.split('.')[2],
        'proposition':self.model.split('.')[0],
        'model':self.model.split('.')[1]
        })
        self._writeScriptFile(self.allocationScriptFile,query)

    def run_scoring(self):
        self.prepareTables();
        self.generateScores()
        self.generateViews()

        # generate HQL script list file
        fp = open(self.script_list_file,"w")
        file1 = ''.join(self.scoringScriptFile.split('/')[-1:])
        file2 = ''.join(self.pobScriptFile.split('/')[-1:])
        file3 = ''.join(self.allocationScriptFile.split('/')[-1:])
        file4 = ''.join(self.historyScriptFile.split('/')[-1:]) # table retention hql script filename

        fp.write("%s %s %s %s"%(file1,file2,file3,file4))
        fp.close()