import re
import os
import csv
import datetime
import json
from impala.dbapi import connect
from lxml import etree
from schemas import LinerRegressionSchema

__author__ = 'charleba'


NULL_VALUE = '\\N'

PAAR_TRANSFORM1 = re.compile(r"\s*=\s*([0-9\.-]+).+\+\(\(\(log\((.*)\)\)\*\*[1-2]+\)\*([0-9\.-]+)\)\+\(\(\(log\((.*)\)\)\*\*[1-2]+\)\*([0-9\.-]+)\)",re.I)
PAAR_TRANSFORM2 = re.compile(r"\s*=\s*log\((.*)\)",re.I)
PAAR_TRANSFORM3 = re.compile(r"\s*=\s(.*)",re.I)
PAAR_FEAT_ADJUST = re.compile(r"if\s+([0-9a-zA-Z_]+)\s*([<|>|=|!]+)([0-9]+)\s+[a-zA-Z]+\s(.*)\s*=([0-9\.]+)",re.I)


class PMMLGenerator(object):

    def __init__(self,model_config,logger):
        '''

        :param model_config: a json object with config options.
        :return: None
        '''
        self.applog = logger
        self.headers = None
        self.names = ['model','fieldName','not_used1','prod_code','type','coefficient','dataType','not_used3','missingReplace','var_adjust','transform']
        self.config = model_config
        self.xml_root = None
        self.xml_header = None
        self.xml_datadic = None
        self.xml_mineschema = None
        self.xml_localtrans = None
        self.xml_regresstable = None
        self.pmml_outfile = None
        self.regresstable_mtrx = {}
        self.mapping_dict = {}


        if 'namespace' not in self.config:
            raise Exception("Config key error 'namespace' the xml schema namespace is required")

        if 'model_metadata_store' not in self.config:
            raise Exception("Config key error 'model_metadata_store' the source of the model definition CSV file is missing")

        if 'feature_table_name_matrix' not in self.config:
            raise Exception("Config key error 'feature_table_name_matrix' the features to table field_name mapping is missing")

        if 'output_pmml_path' not in self.config:
            self.config['output_pmml_path'] = '/tmp'

        if 'headers' not in self.config:
            self.applog.info("no 'headers' key, assuming no headers")
        else:
            self.headers = True


        if 'model_type' not in self.config:
            raise Exception("Config key error 'model_type' the Model type definition is missing (e.g. linearRegression)")
        else:
            if self.config['model_type'] != 'linearRegression':
                raise Exception("Model error. Only linearRegression models are support")

        if 'variable_to_features' not in self.config:
            raise Exception("Config key error 'variable_to_features'. Can't map PAAR variables to SSE feature ")

        impala_host = self.config['impala_host']
        impala_port = self.config['impala_port']
        self.impala_con = connect(host = impala_host
                ,port = impala_port
                ,use_kerberos = True
                ,database = self.config['model_schema']
            )

        self.__initialiseFile()

    def __initialiseFile(self):
        self.xml_root = etree.fromstring(LinerRegressionSchema)
        self.xml_header = self.xml_root.findall("{%(name_space)s}Header"%{'name_space': self.config['namespace']})[0]
        self.xml_datadic = self.xml_root.findall("{%(name_space)s}DataDictionary"%{'name_space': self.config['namespace']})[0]
        self.xml_mineschema = self.xml_root.findall("{%(name_space)s}RegressionModel/{%(name_space)s}MiningSchema"%{'name_space': self.config['namespace']})[0]
        self.xml_localtrans = self.xml_root.findall("{%(name_space)s}RegressionModel/{%(name_space)s}LocalTransformations"%{'name_space': self.config['namespace']})[0]
        self.xml_regresstable = self.xml_root.findall("{%(name_space)s}RegressionModel/{%(name_space)s}RegressionTable"%{'name_space': self.config['namespace']})[0]

        cust =  self.create_dataField('cust_code','string',nullVal='\\N')
        self.xml_datadic.insert(1,cust)
        prod = self.create_dataField('prod_code','string',nullVal='\\N')
        self.xml_datadic.insert(2,prod)

        try:
            self.external_value_list = json.loads(self.config['feature_table_name_matrix'])
        except:
            # not a json str so must be a json file
            self.external_value_list = json.load(open(self.config['feature_table_name_matrix']))

        try:
            mapping = json.loads(open(self.config['variable_to_features']))
        except:
            # not a json str so must be a csv file
            mapping = self.read_csv_all(open(self.config['variable_to_features']),['variable','feature_name'],True)

        for aline in mapping:
            self.mapping_dict[aline['variable']] = aline['feature_name']

        # set time and date xml is generated
        tmp = etree.Element('Timestamp')
        tmp.text = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.xml_header.append(tmp)

    def get_feat_name_from_matrix(self,sas_variable):
        if sas_variable in self.mapping_dict:
            return self.mapping_dict[sas_variable]
        else:
            return sas_variable


    def map_variable_to_table_field_list(self,base_prod_code,prod_code,variable_name):
        value = None
        field_name = ''
        tmp_var_name =  variable_name
        variable_name = self.get_feat_name_from_matrix(variable_name)
        #if base_prod_code == '0002002323010012':
        #    print tmp_var_name,variable_name

        if base_prod_code in self.external_value_list:
            for variable_name1,field_name in self.external_value_list[base_prod_code].items():
                #if base_prod_code == '0002002323010012':
                #    print tmp_var_name,prod_code,variable_name,variable_name1,field_name
                if variable_name1.split('_')[-1:][0] == prod_code and "_".join(variable_name1.split('_')[:-1]) == variable_name:
                    #value = field_name
                    return field_name

        if value == None: # For testing. this should actually throw an error as all variables should be supplied
            value = variable_name

        return value


    def read_hadoop_db(self):
        tmp_dict = {}
        query_cur = self.impala_con.cursor()
        query = """
                    SELECT *
                    FROM %(category_model_db_schema)s.%(category_model_db_table)s
                    WHERE base_prod_code='%(base_prod_code)s'
                  """%({
                'category_model_db_schema':self.config['category_models_db_schema'],
                'category_model_db_table':self.config['category_models_db_table'],
                'base_prod_code':self.config['category_prod_code'],
        })
        self.applog.info("Getting category model details")
        self.applog.debug(query)
        query_cur.execute(query)
        result_list = []
        data = query_cur.fetchall()
        for rec in data:
            for i,val in enumerate(self.names):
                tmp_dict[self.names[i]] = rec[i]
            result_list.append(tmp_dict)
            tmp_dict = {}

        return result_list

    def read_csv_all(self,fp,names,skip_header=True):
        tmp_dict = {}
        with fp:
            if skip_header == True:
                fp.readline()

            reader = csv.reader(fp)
            for aline in reader:
                #print aline
                #aline = aline.encode('utf-8')
                tmp_dict={}
                for i,val in enumerate(names):
                    tmp_dict[names[i]] = aline[i]
                yield tmp_dict

    def read_csv(self,fp,names,skip_header=True):
        tmp_dict = {}
        with fp:
            if skip_header == True:
                fp.readline()

            reader = csv.reader(fp)
            for aline in reader:
                if aline[0] == self.config['category_prod_code']:
                    tmp_dict={}
                    for i,val in enumerate(names):
                        tmp_dict[names[i]] = aline[i]
                    yield tmp_dict

    def create_dataField(self,name,dateType,nullVal='\\N'):

        obj = etree.Element('DataField')
        if dateType.lower() == 'string':
            obj.set('optype','categorical')
        else:
            obj.set('optype','continuous')

        obj.set('name',name)
        obj.set('dataType',dateType)

        nullv = etree.Element('Value')
        nullv.set('property','missing')
        nullv.set('value',nullVal)
        obj.append(nullv)

        return obj

    def create_derivedField(self,name,dateType,op=None,params=None):
        opType="continuous"
        #params = param.split(',')

        obj = etree.Element('DerivedField')
        if dateType.lower() == 'string':
            obj.set('optype','categorical')
        else:
            obj.set('optype','continuous')

        obj.set('name',name)
        obj.set('dataType',dateType)
        if op != None and params != None:
            obj.append(self.create_function(params,op))

        return obj


    def create_miningField(self,name,missingval,treat_invalid='asMissing',usageType='active'):

        if missingval in ('','nan',None):
            missingval = '0'

        obj = etree.Element('MiningField')
        obj.set('usageType',usageType)
        obj.set('missingValueReplacement',missingval)
        obj.set('invalidValueTreatment',treat_invalid)
        obj.set('name',name)
        return obj


    def create_numericPredictor(self,name,coeff):
        obj = etree.Element('NumericPredictor')
        obj.set('exponent',"1")
        obj.set('coefficient',coeff)
        obj.set('name',name)

        return obj

    def create_function(self,params,op="+"):
        obj = etree.Element('Apply')
        obj.set('function',op)
        for param in params:
            if param not in ('',None):
                if re.search('^[0-9\.\-]+$',str(param)):
                    val = etree.Element('Constant')
                    val.set('dataType','double')
                    val.text = str(param)
                else:
                    val = etree.Element('FieldRef')
                    val.set('field',param)

            obj.append(val)
        return obj

    def __complex_transform1(self,base_param,data):

        result = []
        param_name_base = "_".join(base_param.split('_')[:-1])

        # build log variable
        obj = self.create_function([base_param],'ln')
        try:
            counter = int(base_param.split('_')[-1:][0])
        except:
            counter = 0

        tmp = self.create_derivedField(param_name_base+'_'+str(counter+1),'double')
        tmp.append(obj)
        result.append(tmp)

        # build squared
        param = param_name_base+'_'+str(counter+1)
        obj = self.create_function([param,2],'pow')
        tmp = self.create_derivedField(param_name_base+'_'+str(counter+2),'double')
        tmp.append(obj)
        result.append(tmp)

        param = param_name_base+'_'+str(counter+1)
        obj = self.create_function([param,1],'pow')
        tmp = self.create_derivedField(param_name_base+'_'+str(counter+3),'double')
        tmp.append(obj)
        result.append(tmp)

        # multiple
        param = param_name_base+'_'+str(counter+2)
        obj = self.create_function([param,data.group(3)],'*')
        tmp = self.create_derivedField(param_name_base+'_'+str(counter+4),'double')
        tmp.append(obj)
        result.append(tmp)

        param = param_name_base+'_'+str(counter+3)
        obj = self.create_function([param,data.group(5)],'*')
        tmp = self.create_derivedField(param_name_base+'_'+str(counter+5),'double')
        tmp.append(obj)
        result.append(tmp)

        # add them all together
        param = param_name_base+'_'+str(counter+4)
        obj = self.create_function([param,data.group(1)],'+')
        tmp = self.create_derivedField(param_name_base+'_'+str(counter+6),'double')
        tmp.append(obj)
        result.append(tmp)

        param = param_name_base+'_'+str(counter+6)
        param2 = param_name_base+'_'+str(counter+5)
        obj = self.create_function([param,param2],'+')
        tmp = self.create_derivedField(param_name_base+'_'+str(counter+7),'double')
        tmp.append(obj)
        result.append(tmp)

        return (param_name_base+'_'+str(counter+7),result)


    def __complex_transform2(self,base_param,data):
        result = []
        # build log variable
        obj = self.create_function([base_param],'ln')
        param_name_base = "_".join(base_param.split('_')[:-1])
        try:
            counter = int(base_param.split('_')[-1:][0])
        except:
            counter = 0

        tmp = self.create_derivedField(param_name_base+'_'+str(counter+1),'double')
        tmp.append(obj)
        result.append(tmp)

        return param_name_base+'_'+str(counter+1),result

    def create_feature_transform_field(self,base_param,data):
        if len(data.groups()) == 5:
            # most complex of the transforms
            field_name,obj = self.__complex_transform1(base_param,data)
        else:
            field_name,obj = self.__complex_transform2(base_param,data)

        return field_name,obj

    def create_adjusted_feature_field(self,base_param,data):
        ops = {
            '=':'equal',
            '!=':'notEqual',
            '<>':'notEqual',
            '>':'greaterThan',
            '<':'lessThan',
            '>=':'greaterOrEqual',
            '<=':'lessOrEqual',
            '+':'+',
            '*':'*',
            '-':'-',
        }
        op = ops[data.group(2)]
        param = [base_param,data.group(3)]
        obj = self.create_function(param,op)
        func_if = self.create_function([],'if')
        func_if.append(obj)
        obj_tmp = etree.Element('Constant')
        obj_tmp.set('dataType','double')
        obj_tmp.text = data.group(5)
        func_if.append(obj_tmp)
        obj_tmp = etree.Element('FieldRef')
        obj_tmp.set('field',base_param)
        func_if.append(obj_tmp)
        field_name = data.group(2)
        feat_final = self.create_derivedField(base_param +'_'+ base_param+'_1','double')
        feat_final.append(func_if)
        return base_param +'_'+ base_param+'_1',feat_final

    def process_model_file(self):
        '''
        reads the model description CSV file / DB table and create the XML objects
        :return:
        '''
        if 'model_metadata_store' in  self.config and self.config['model_metadata_store'] == 'csv':
            paar_variable_csv = open(self.config['category_batch_model_csv_filename'])
            csv_reader = self.read_csv(open(self.config['category_batch_model_csv_filename']),self.names,self.headers)
        elif 'category_models_db_schema' in self.config and 'category_models_db_table' in self.config:
            csv_reader = self.read_hadoop_db()
        else:
            raise Exception("Error config key model_metadata_store is missing")


        current_outfile_name = None
        outfile_fp = None
        datafield_counter = 3
        miningfield_counter = 0
        for arecord in csv_reader:
            #arecord = arecord.apply(lambda col: str(col))
            if arecord['type'].lower() != 'intercept' and arecord['fieldName'].lower() != 'intercept':
                rec_prod_code = arecord['prod_code']#arecord['fieldName'].split('_')[1]
                arecord['fieldName'] = self.map_variable_to_table_field_list(arecord['model'],rec_prod_code,arecord['fieldName'])

            if current_outfile_name == None or current_outfile_name <> arecord['model']:
                datafield_counter = 3
                current_outfile_name = arecord['model']
                if outfile_fp:

                    xml_string = etree.tostring(self.xml_root).replace('><','>\n\t<')
                    xml_string = etree.tostring(etree.XML(xml_string),pretty_print=True)

                    try:
                        outfile_fp.write(xml_string)
                        outfile_fp.close()
                    except IOError:
                        pass

                #else:
                    #if 'delete_old' in self.config:
                    #    outfile_fp = open(os.path.join(self.config['out_path'],str(current_outfile_name) + '.pmml'),"w+")
                    #else:
                outfile_fp = open(os.path.join(self.config['output_pmml_path'],str(current_outfile_name) + '.pmml'),"w+")
                try:
                    self.xml_root.parse(outfile_fp)
                except:
                    # assume file is empty so create new object
                    self.__initialiseFile()

            #if  arecord['model'] == '1001111010012':
            #    print arecord['var_adjust']
            #    print arecord['transform']

            if arecord['type'].lower() == 'datafield' or (arecord['type'].lower() == 'derivedfield' and PAAR_TRANSFORM3.search(arecord['transform']) and not PAAR_TRANSFORM2.search(arecord['transform']) and not PAAR_TRANSFORM1.search(arecord['transform'])):
                obj = self.create_dataField(arecord['fieldName'],arecord['dataType'])
                self.xml_datadic.insert(datafield_counter,obj)
                datafield_counter += 1

            elif arecord['type'].lower() == 'derivedfield':

                # add the datefield
                obj = self.create_dataField(arecord['fieldName'],arecord['dataType'])
                self.xml_datadic.insert(datafield_counter,obj)
                datafield_counter += 1

                # check if this is a complex field
                if PAAR_FEAT_ADJUST.search(arecord['var_adjust']):
                    regx_groups = PAAR_FEAT_ADJUST.search(arecord['var_adjust'])
                    new_field_name,obj = self.create_adjusted_feature_field(arecord['fieldName'],regx_groups)
                    self.xml_localtrans.append(obj)
                else:
                    new_field_name = arecord['fieldName']

                if PAAR_TRANSFORM1.search(arecord['transform']):
                    regx_groups = PAAR_TRANSFORM1.search(arecord['transform'])
                elif PAAR_TRANSFORM2.search(arecord['transform']):
                    regx_groups = PAAR_TRANSFORM2.search(arecord['transform'])
                #elif PAAR_TRANSFORM3.match(arecord['transform']):
                #    regx_groups = PAAR_TRANSFORM3.match(arecord['transform'])
                else:
                    print arecord
                    raise Exception("Error Derived fields must have a transformation defined")

                new_field_name,obj = self.create_feature_transform_field(new_field_name,regx_groups)
                for elm in obj:
                    self.xml_localtrans.append(elm)

                # store new name of regressions field
                self.regresstable_mtrx[arecord['fieldName']] = new_field_name


            elif arecord['type'].lower() == 'intercept' or arecord['fieldName'].lower() == 'intercept':
                self.xml_regresstable.set('intercept',arecord['coefficient'])

            if arecord['type'].lower() != 'intercept' and arecord['fieldName'].lower() != 'intercept':
                # Add minining field
                obj = self.create_miningField(arecord['fieldName'],arecord['missingReplace'])
                if obj != None:
                    self.xml_mineschema.insert(miningfield_counter,obj)
                    miningfield_counter += 1

                if arecord['coefficient'].lower() not in ('',0,'nan'):
                    # this is an active field so add to regression table
                    if arecord['fieldName'] in self.regresstable_mtrx:
                        field_name = self.regresstable_mtrx[arecord['fieldName']]
                    else:
                        field_name = arecord['fieldName']

                    obj = self.create_numericPredictor(field_name,arecord['coefficient'])
                    self.xml_regresstable.append(obj)

        xml_string = etree.tostring(self.xml_root).replace('><','>\n\t<')
        xml_string = etree.tostring(etree.XML(xml_string),pretty_print=True)
        outfile_fp.write(xml_string)
        outfile_fp.close()


    def build_model_schema(self):
        '''

        :return:
        '''
        pass

    def write_pmml_string(self,toFile=False):
        '''

        :param toFile:
        :return: the xml as a string or a full pmml file path
        '''