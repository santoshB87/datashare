import os
import re
import sys
import logging
from ape.job2 import Job2
from ape.errors import JobException
from ape.engineconfig import load_json_configs
from hiveserver2 import HiveServer
from pmmlrunner import PMMLRunner

__author__ = 'rudraps'
logger = logging.getLogger(__name__)


class PMMLRunnerJob2(Job2):

    # Job parent class sets up self.properties
    def __init__(self):
        """
        Class constructor
        :return: None
        """
        super(PMMLRunnerJob2, self).__init__()
        self.configDic = None
        self.config_cache = None
        self.dest_table = None
        self.cursor = None

    def getValueFromJsonConfig(self, key, json_config):
        """
        :param key:  dictionary key, which value is needed
        :param json_config: dictionary, which prepared from config.json
        :return: value of the lookup key
        """
        value = None
        try:
            value = json_config.get(key)
            if not value and str(value).strip().capitalize() == 'None':
                raise Exception("%s is defined with invalid value in config.json file" % key)
        except Exception as key_error:
            raise Exception("%s is not defined in config.json file" % key)
        return value

    def getValue(self, key, json_option, json_config):
        """
        :param key: dictionary key, which value is needed
        :param json_option: dictionary, which passed as parameter
        :param json_config: dictionary, which prepared from config.json
        :return: value of the lookup key
        """

        value = None
        try:
            if key in json_option:
                value = json_option.get(key)
                if not value:
                    value = self.getValueFromJsonConfig(key, json_config)
            else:
                value = self.getValueFromJsonConfig(key, json_config)
        except Exception as key_error:
            raise Exception("%s is not defined!" % key)

        return value

    def prepare(self, config, options):
        super(PMMLRunnerJob2, self).prepare(config, options)

        # load the json config
        self.config_cache, self.configDic = load_json_configs(config, options, logger)
        market = self.config_cache.get('ClientShortName')
        self.configDic['market'] = market
        if 'debug' in self.configDic and self.configDic['debug'].lower() == 'true':
            logger.setLevel(logging.DEBUG)
        self.configDic['hive_host'] = str(self.config_cache.get('HiveServerNodeName'))
        self.configDic['hive_port'] = int(self.config_cache.get('HivePortNumber'))
        self.configDic['engine_path'] = self.getValue('engine_path', self.configDic, self.config_cache)
        self.configDic['HdfsRootPath'] = self.getValue('HdfsRootPath', self.configDic, self.config_cache)
        self.configDic['ProductAttributeMappings'] = self.config_cache.get('ProductAttributeMappings', True)
        self.configDic['ScoringBaseRetentionHistory'] = self.getValue('ScoringBaseRetentionHistory',
                                                                      self.configDic, self.config_cache)
        self.configDic['SSERequestPool'] = self.getValue('SSERequestPool', self.configDic, self.config_cache)

        if self.configDic['SSERequestPool'] is None:
            logger.warning('No "SSERequestPool" found in config, will set to "default"')
            self.configDic['SSERequestPool'] = 'default'

        # prepare hdfs source path
        if 'sourcePath' not in self.configDic:
            if self.configDic['HdfsRootPath']:
                self.configDic['sourcePath'] = os.path.join(self.configDic['HdfsRootPath'], os.path.join('sse', 'hive'))
            else:
                raise JobException("HdfsRootPath key missing in options")
        logger.debug("Setting sourcePath => %s" % self.configDic['sourcePath'])

        # prepare hdfs destination path
        if 'destPath' not in self.configDic:
            # generate destPath keys from HdfsRootPath
            if self.configDic['HdfsRootPath']:
                self.configDic['destPath'] = os.path.join(self.configDic['HdfsRootPath'], os.path.join('pob', 'hive'))
            else:
                raise JobException("HdfsRootPath key missing in options")
        logger.debug("Setting destPath => %s" % (self.configDic['destPath']))

        logger.info("configDict :%s" % self.configDic)
        # check for required keys
        if 'pmml_file' not in self.configDic:
            raise JobException("pmml_file key missing in options")
        else:
            # setup full path of file
            self.configDic['pmml_file'] = os.path.join(self.configDic['engine_path'], '../programs/model/' +
                                                       self.configDic['pmml_file'])

    def run_job(self):
        try:
            logger.info("Setting pmml scoring job")
            scoring_run = PMMLRunner(self.configDic)
            self.dest_table = scoring_run.run_scoring()
            logger.info("Scoring ran successfully (Model:%s, Destination Table :%s.%s)" % (
                self.configDic['model_name'], self.configDic['destination_schema'], self.dest_table))
        except Exception:
            _, ex, traceback = sys.exc_info()
            logger.error("Scoring run Failed with error %s" % str(ex))
            raise JobException(ex), None, traceback

    def _clear_history(self):
        """
        drops the old X tables which are created for scoring
        :return: None
        """

        # connect to hive server
        hs = HiveServer(host=self.configDic['hive_host'], port=self.configDic['hive_port'],
                        db=self.configDic['destination_schema'], queue=self.configDic['SSERequestPool'])
        hs.connect()
        self.cursor = hs.cursor()

        # get old scoring tables tables
        find_query = "SHOW TABLES IN %s" % (self.configDic['destination_schema'])
        self.cursor.execute(find_query)
        tbls = [item[0] for item in self.cursor.fetchall()]
        pattern = re.compile(r"^(%s)_[0-9]{14}$" % self.configDic['model_name'], re.IGNORECASE)
        drop_list = filter(lambda x: pattern.match(x), tbls)
        logger.info('ScoringBaseRetentionHistory Table list :%s' % drop_list)

        # drop old scoring tables
        if len(drop_list) > 0:
            drop_list.sort(reverse=True)
            drop_list = drop_list[int(self.configDic['ScoringBaseRetentionHistory']):]
            for table_name in drop_list:
                if table_name.find('_latest') < 0:
                    query = "DROP TABLE IF EXISTS %s.%s" % (self.configDic['destination_schema'], table_name)
                    self.cursor.execute(query)
                    logger.info("Drop table %s.%s" % (self.configDic['destination_schema'], table_name))

        # close hive server connection
        hs.close()

    def clean_up(self):
        # clean up old model hive tables
        if 'ScoringBaseRetentionHistory' in self.configDic:
            self._clear_history()
