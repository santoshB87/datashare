import os
import sh
import logging
from lxml import etree
from datetime import datetime
from hiveserver2 import HiveServer

__author__ = 'rudraps'
logger = logging.getLogger(__name__)


class PMMLRunner:
    """
    Run PMML model to predict score from provided input feature data sets.
    """

    def __init__(self, config):
        """
        Class constructor
        :return: None
        :param config: dictionary
        """
        self.config = config
        self.model_name = config['model_name']
        self.pmml_file = config['pmml_file']
        self.pmml_java_app = None
        self.pmml_namespace = None
        self.source_schema = config['source_schema'].lower()
        self.source_table = config['source_table'].lower()
        self.in_path = None
        self.dest_schema = config['destination_schema'].lower()
        self.dest_dataset_name = None
        self.dest_dataset_name_txt = None
        self.out_path = None
        self.score_col_name = None

    @staticmethod
    def parse_pmm_file(pmml_file, name_space=None):
        """
        Return a list of field names from the DataDictionary section of the pmml file
        or it fails with an exception.
        :param pmm_file: String :PMML file
        :name_space: String :PMML Name Space
        :return: list
        """
        columns = []
        col_def = []
        score_col_name = None
        score_col_type = None
        xml_obj = etree.parse(pmml_file)
        data_fields = xml_obj.findall(
            "{%(name_space)s}DataDictionary/{%(name_space)s}DataField"%{'name_space':name_space})
        output_fields = xml_obj.findall(
            "{%(name_space)s}MiningModel/{%(name_space)s}Output/{%(name_space)s}OutputField"%{'name_space':name_space})

        # Process 'DataField' of pmml file
        if data_fields not in ([], False, None):
            for col in data_fields:
                if col.get('is_predicted') == 'yes':
                    score_col_name = col.get('name').strip()
                    score_col_type = col.get('dataType').strip()
                    col_def.append("%(col)s  %(type)s \n" % ({'col': score_col_name, 'type': score_col_type}))
                else:
                    columns.append(col.get('name'))
                    if col.get('dataType').strip():
                        if col.get('dataType').lower() == 'integer':
                            col_def.append("%(col)s  %(type)s \n" % ({'col': col.get('name'),
                                                                      'type': 'int'}))
                        else:
                            col_def.append("%(col)s  %(type)s \n" % ({'col': col.get('name'),
                                                                      'type': col.get('dataType')}))
                    else:
                        col_def.append("%(col)s  %(type)s \n" % ({'col': col.get('name'), 'type': 'string'}))

            # Raise exception, if PMML file does not have score column
            if score_col_name == None:
                raise Exception("Score column is missing in PMML DataDictionary")
        else:
            raise Exception("DataDictionary in PMML file are required.")

        # process OutputField
        if output_fields not in ([],False,None):
            for col in output_fields:
                try:
                    if col.get('dataType'):
                        if col.get('dataType').lower() == 'integer':
                            col_def.append("%(col)s  %(type)s \n" % ({'col': col.get('name'),
                                                                      'type': 'int'}))
                        else:
                            col_def.append("%(col)s  %(type)s \n" % ({'col': col.get('name'),
                                                                      'type': col.get('dataType')}))
                    else:
                        col_def.append("%(col)s  %(type)s \n"%({'col':col.get('name'),'type':'string'}))
                except :
                    raise Exception("OutputField must have a name and a dataType attribute")

        return columns,col_def,score_col_name

    def run_scoring(self):
        logger.info("Validating PMML Model '%s' (%s)" % (self.model_name, self.pmml_file))
        if self.pmml_file and self.pmml_file.split('.')[-1] == 'pmml':
            pass
        elif self.pmml_file and self.pmml_file.split('.')[-1] == 'json':
            raise Exception("CMP-DataPipe-Line-Framework does not support data science model as Json file, yet!")
        else:
            raise Exception("Data science model is not a valid PMML file!")

        """
        Reason for hard coding PMML jar file 'cascading-pmml-scoring-1.2.2-job.jar' is,
        currently there is no plan for changing PMML model execution system.
        """
        if 'pmml_jar' not in self.config:
            self.pmml_jar = 'cascading-pmml-scoring-1.2.2-job.jar'
        else:
            self.pmml_jar = self.config['pmml_jar']

        """
        "ape/pmml/jars" is hard coded, as it has been decided to include in deployment tool.
        """
        self.pmml_java_app = os.path.join(self.config["engine_path"], "ape/pmml/jars", self.pmml_jar)
        logger.info("Validating PMML application (%s)" % self.pmml_java_app)
        if not os.path.exists(self.pmml_java_app):
            raise Exception("PMML Model Runner Java application is missing!")

        if not 'with_header' in self.config:
            self.config['with_header'] = 'False'

        if 'sourcePath' in self.config and self.config["sourcePath"]:
            self.in_path = os.path.join(self.config["sourcePath"], self.source_schema,
                                        self.source_table, "*")
        else:
            raise Exception("Key sourcePath is missing in config dict!, Could not generate in_path")
        logger.info("PMML model input path :%s" % self.in_path)
        self.config['in_path'] = self.in_path

        self.dest_dataset_name = self.model_name + "_" + datetime.now().strftime('%Y%m%d%H%M%S')
        self.dest_dataset_name_txt = self.model_name + "_" + datetime.now().strftime('%Y%m%d%H%M%S') + "_txt"
        if 'destPath' in self.config and self.config["destPath"]:
            self.out_path = os.path.join(self.config["destPath"], self.dest_schema,
                                         self.dest_dataset_name_txt )
        else:
            raise Exception("Key destPath is missing in config dict!, Could not generate out_path")
        logger.info("PMML model text output path :%s" % self.out_path)
        self.config['out_path'] = self.out_path

        if 'pmml_namespace' not in self.config:
           self.pmml_namespace = "http://www.dmg.org/PMML-4_1"

        # get input fields from file:
        logger.info("Parsing PMML file for features definitions")
        columns,col_type,self.score_col_name = PMMLRunner.parse_pmm_file(self.pmml_file, self.pmml_namespace)
        self.config['column_headers'] = ",".join(columns)
        self.config['column_def'] = ",".join(col_type)
        logger.debug("column_headers :%s" % self.config['column_headers'])
        logger.debug("column_def :%s " % self.config['column_def'])

        # Prepare a dictionary variable with required keys for run command
        run_cmd = {}
        run_cmd['column-headers'] = ('column_headers' in self.config) and self.config['column_headers']
        run_cmd['in-path'] = self.in_path
        run_cmd['out-path'] = self.out_path
        run_cmd['market'] = ('market' in self.config) and self.config['market']
        run_cmd['pmml'] = self.pmml_file
        run_cmd['with-header'] = ('with_header' in self.config) and self.config['with_header']
        run_cmd['model'] = self.model_name
        run_cmd['yarn-resource-pool-name'] = self.config['SSERequestPool']

        try:
            arg = ['jar', self.pmml_java_app]
            for key, val in run_cmd.items():
                if not val in (False, 'False'):
                    arg.append("--" + key)
                    arg.append(val)

            logger.info("Running PMML model (hadoop %s)" % arg)
            scoring_run = sh.Command("/usr/bin/hadoop")
            scoring_run(arg)
            logger.info("PMML model execution :Success")
        except Exception as ex:
            logger.error("PMML Job failed")
            # delete destination path on HDFS
            try:
                run_cmd = sh.Command("/usr/bin/hdfs")
                run_cmd("dfs","-rm","-r", self.config['out_path'])
            except Exception as e:
                logger.warning("Can not clean hdfs out_path (%s)" % e)

            raise Exception("PMML model execution failed with error %s" % ex)

        # connect to hive server
        hs = HiveServer(host=self.config['hive_host'], port=self.config['hive_port'],
                        db=self.config['source_schema'], queue=self.config['SSERequestPool'])
        hs.connect()
        cursor = hs.cursor()

        # scoring is done. now create tables and views
        logger.info("Creating scoring text table (%s.%s)" % (self.dest_schema, self.dest_dataset_name_txt))
        cursor.execute('set sync_ddl = True')
        cursor.execute("set request_pool='%s'"%(self.config['SSERequestPool']))
        query = """
                CREATE TABLE %(text_table_name)s
                  (
                    %(table_def)s
                  )
                row format delimited fields terminated by ','
                stored as textfile
                """%({
                'text_table_name':self.dest_schema + '.' + self.dest_dataset_name_txt,
                'table_def':self.config['column_def']
                })
        logger.info(query)
        cursor.execute(query)

        logger.info("Creating scoring parquet table (%s.%s)" % (self.dest_schema, self.dest_dataset_name))
        query = """
                CREATE TABLE IF NOT EXISTS %(parq_table_name)s
                  (
                  %(table_def)s
                  )
                stored as parquet
                """ % ({
                'parq_table_name':self.dest_schema + '.' + self.dest_dataset_name,
                'table_def':self.config['column_def']
                })
        logger.info(query)
        cursor.execute(query)

        logger.info("Loading data into scoring parquet table")
        query = """
                INSERT OVERWRITE TABLE %(parq_table_name)s
                SELECT *
                FROM %(text_table_name)s
                """ % ({
                'parq_table_name':self.dest_schema + '.' + self.dest_dataset_name,
                'text_table_name': self.dest_schema + '.' + self.dest_dataset_name_txt
                })
        logger.info(query)
        cursor.execute(query)
        
        logger.info("Dropping scoring text table")
        query = "DROP TABLE IF EXISTS %s.%s" % (self.dest_schema, self.dest_dataset_name_txt)
        logger.debug(query)
        cursor.execute(query)

        if 'no_views' not in self.config or not self.config['no_views']:
            # create the views -> Hive.Schema.View-1 : [<Proposition>_<model>]_latest
            proposition_scoring_table = '%s.%s' % (self.dest_schema, self.dest_dataset_name)
            proposition_scoring_view = '%s.%s_latest' % (self.dest_schema, self.model_name.lower())
            logger.info("Creating view '%s' for %s" % (proposition_scoring_view, proposition_scoring_table))
            query = "DROP VIEW IF EXISTS %s" %(proposition_scoring_view)
            logger.debug(query)
            cursor.execute(query)
            query = """
                    CREATE VIEW %(table_latest_name)s AS 
                      SELECT * FROM %(table_name)s 
                        WHERE %(score_field)s IS NOT NULL
                    """ % ({
                    'table_latest_name':proposition_scoring_view,
                    'table_name': proposition_scoring_table,
                    'score_field':self.score_col_name
                    })
            logger.info(query)
            cursor.execute(query)

        hs.close()
        return self.dest_dataset_name
