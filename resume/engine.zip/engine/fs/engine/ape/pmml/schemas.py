LinerRegressionSchema = """
<PMML version="4.1"
  xmlns="http://www.dmg.org/PMML-4_1"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<Annotation>This model is used by the Hadoop Scoring Engine.
  <Extension name="author">Ape2 PMML Generator</Extension>
</Annotation>
<Header copyright="Copyright (c) 2015 DunnHumby" description="">
  <Extension name="user" value="user" extender="PMML"/>
  <Application name="SSE Scoring" version="1.0"/>
</Header>
   <DataDictionary>
    <Annotation>All columns in the source data set. include predicted column with attribute is_predicted</Annotation>
    <DataField name="score" optype="continuous" dataType="double" is_predicted="yes"/>
   </DataDictionary>
   <RegressionModel functionName="regression" algorithmName="Linear Regression" modelType="linearRegression">
     <Annotation>Combines view Name of all base features views and valid dates.</Annotation>
     <MiningSchema>
       <MiningField name="score" usageType="predicted"/>
     </MiningSchema>
      <LocalTransformations>
      </LocalTransformations>
     <RegressionTable intercept="">
     </RegressionTable>
   </RegressionModel>
</PMML>
"""