import csv
import logging
import simplejson as json
from collections import MutableMapping
from ape.errors import JobException
from simplejson import JSONDecodeError

logger = logging.getLogger(__name__)


class Properties(MutableMapping):
    """
    subclass MutableMapping abstract base class, adding methods to:
        load from a csv or json file
        load from a json formatted string
        retrieve an optional key
        retrieve a mandatory key

    also override __setitem__,  __getitem__ and __delitem__ to make dict case insensitive
    and log when we're overwriting an existing key
    this means we also need to maintain a case_sensitive_store if we want to preserve case
    information when dumping to file or appending into dict/Properties object
    """

    default_markup = 'json'
    default_delimiter = ','

    def __init__(self, path=None, markup=default_markup, delimiter=default_delimiter,
                 in_string=None, *args, **kwargs):

        self.store = dict()
        self.case_sensitive_store = dict()
        self.update(*args, **kwargs)

        self.path = path
        self.markup = markup
        self.delimiter = delimiter
        self.in_string = in_string
        self.failed_gets = 0

        if self.path and self.markup and self.delimiter:
            self.append_from_path(path=path, markup=markup, delimiter=delimiter)
        if self.in_string:
            self.append_from_string(self.in_string)

    def __getitem__(self, key):
        return self.store[self.__keytransform__(key)]

    def __setitem__(self, key, value):
        # report on any existing keys being overwritten
        if self.__keytransform__(key) in self:
            logger.info(
                'Property {0} overridden.  Old value: {1}, New value: {2}'.format(key, self[key], value))
        self.store[self.__keytransform__(key)] = value
        # also maintain a version of store where keys are not transformed, to be used when dumping to file
        # and when we want to append Properties into a dict or other Properties object while maintaining case
        self.case_sensitive_store[key] = value

    def __delitem__(self, key):
        del self.store[self.__keytransform__(key)]

    def __iter__(self):
        return iter(self.store)

    def __len__(self):
        return len(self.store)

    def __getnesteditem__(self, keys):
        return reduce(lambda d, k: d[k], keys, self)

    @staticmethod
    def __keytransform__(key):
        return key.lower()

    @staticmethod
    def __join_keys__(keys):
        return ','.join(['{' + key + '}' for key in keys])

    def append_from_path(self, path, markup=default_markup, delimiter=default_delimiter):
        self.path = path
        self.markup = markup
        self.delimiter = delimiter
        # update self with contents of path
        try:
            with open(path, 'r') as f:
                if markup.lower() == 'json':
                    self.update(json.load(f))
                elif markup.lower() == 'csv':
                    self.update({row[0]: row[1] for row in csv.reader(f, delimiter=delimiter) if len(row) > 1})
                else:
                    raise JobException('Unrecognised properties file markup {0}'.format(markup))
        except (OSError, IOError) as err:
            raise JobException('Unable to open file {0} for read: {1}'.format(path, err.message))
        except JSONDecodeError as err:
            raise JobException('Failed to parse file {0} as JSON: {1} '.format(path, err.message))

    def append_from_string(self, in_string):
        logger.debug('Attempting to parse input string "{0}" into dictionary of key/value pairs'
                     .format(in_string))
        try:
            self.update(json.loads(in_string))
        except (ValueError, JSONDecodeError):
            raise JobException('Failed to parse string "{0}" as JSON'.format(in_string))

    def append_from_dict(self, in_dict):
        try:
            self.update(in_dict)
        except Exception as err:
            raise JobException('Failed to add contents of dictionary to properties. Error: {0}'.format(err))

    def write_to_file(self, path, markup='json'):
        # export contents of case_sensitive_store into either csv or json file
        try:
            with open(path, 'w') as f:
                if markup.lower() == 'csv':
                    writer = csv.writer(f)
                    for row in self.case_sensitive_store.items():
                        writer.writerow(row)
                elif markup.lower() == 'json':
                    json.dump(dict(self.case_sensitive_store), f)
        except (OSError, IOError) as err:
            raise JobException('Unable to open file {0} for write: {1}'.format(path, err.message))

    def get_optional_value(self, *keys):
        try:
            return self.__getnesteditem__(keys)
        except (KeyError, TypeError):
            logger.info('Optional key not found: {0}'.format(self.__join_keys__(keys)))
            return None

    def get_mandatory_value(self, *keys):
        try:
            return self.__getnesteditem__(keys)
        except (KeyError, TypeError):
            logger.error('Required key not found: {0}'.format(self.__join_keys__(keys)))
            self.failed_gets += 1
            return None

    def error_on_failed_mandatory_gets(self):
        if self.failed_gets != 0:
            raise JobException('One or more mandatory keys not found in properties')

    def dump_to_string(self):
        return json.dumps(self.case_sensitive_store)