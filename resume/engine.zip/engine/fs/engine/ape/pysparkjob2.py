import logging
import re
import sys

from ape.errors import JobException
from ape.job2 import Job2
from sh import yarn
from os.path import join
import getpass

logger = logging.getLogger(__name__)


class PySparkJob2(Job2):
    def __init__(self):
        super(PySparkJob2, self).__init__()
        self.yarn_queue = None
        self.pyspark_script_name = None
        self.executor_memory = None
        self.driver_memory = None
        self.yarn_master = None
        self.yarn_deploy_mode = None
        self.spark_process = None
        self.jobchain_id = None
        self.job_id = None
        self.in_exception = False
        self.pyfiles = None
        self.pyjars = None
        self.spark_yarn_executor_memoryOverhead = None
        self.spark_yarn_driver_memoryOverhead = None
        self.spark_driver_args = None
        self.spark_dynamicallocation_maxexecutors = None
        self.spark_dynamicallocation_minexecutors = None
        self.spark_sql_broadcastTimeout = None
        self.spark_network_timeout = None
        self.spark_sql_shuffle_partitions = None
        self.spark_executor_cores = None
        self.driver_class_path = None
        self.spark_yarn_appMasterEnv_PYSPARK_PYTHON=None
        self.spark_yarn_appMasterEnv_PYSPARK_DRIVER_PYTHON=None

    def prepare(self, config, options):
        super(PySparkJob2, self).prepare(config, options)

        self.yarn_queue = self.properties.get_mandatory_value('SSERequestPool')
        self.pyspark_script_name = self.properties.get_mandatory_value('pyspark_script_name')
        self.properties.error_on_failed_mandatory_gets()
        self.driver_class_path=self.properties.get("driver_class_path",None)
        self.executor_memory = self.properties.get('executor_memory', None)
        self.driver_memory = self.properties.get('driver_memory', None)
        self.yarn_master = self.properties.get('yarn_master', 'yarn')
        self.yarn_deploy_mode = self.properties.get('yarn_deploy_mode', 'cluster')

        self.pyfiles = self.properties.get('py-files')
        self.pmml_path = self.properties.get('pmml_path', None)
        self.pyjars = self.properties.get('py-jars')
        self.spark_yarn_executor_memoryOverhead = self.properties.get('spark_yarn_executor_memoryOverhead', '4096')
        self.spark_yarn_driver_memoryOverhead = self.properties.get('spark_yarn_driver_memoryOverhead', '4096')
        self.spark_dynamicallocation_maxexecutors = self.properties.get('spark_dynamicAllocation_maxExecutors', None)
        self.spark_dynamicallocation_minexecutors = self.properties.get('spark_dynamicAllocation_minExecutors', None)
        self.spark_sql_broadcastTimeout = self.properties.get('spark_sql_broadcastTimeout', None)
        self.spark_network_timeout = self.properties.get('spark_network_timeout', None)
        self.spark_executor_heartbeatInterval =  self.properties.get('spark_executor_heartbeatInterval', None)
        self.spark_yarn_maxAppAttempts = self.properties.get('spark_yarn_maxAppAttempts', None)
        self.spark_ui_view_acls = self.properties.get('spark_ui_view_acls', None)
        self.spark_sql_shuffle_partitions = self.properties.get('spark_sql_shuffle_partitions', None)
        self.executor_cores = self.properties.get('executor_cores', None)
        self.spark_driver_args = self.properties.get('spark_driver_args')
        self.spark_acls_enable = self.properties.get('spark_acls_enable', None)
        self.num_executors = self.properties.get('num_executors')
        self.driver_cores = self.properties.get('driver_cores')
        self.spark_sql_autoBroadcastJoinThreshold = self.properties.get('spark_sql_autoBroadcastJoinThreshold')

        self.spark_yarn_appMasterEnv_PYSPARK_PYTHON=self.properties.get('appMasterEnv_PYSPARK_PYTHON')
        self.spark_yarn_appMasterEnv_PYSPARK_DRIVER_PYTHON=self.properties.get('appMasterEnv_PYSPARK_DRIVER_PYTHON')

    def run_job(self):

        from sh import spark2_submit as ss
        ss = ss.bake('--master', self.yarn_master)
        ss = ss.bake('--deploy-mode', self.yarn_deploy_mode)
        ss = ss.bake('--queue', self.yarn_queue)
        ss = ss.bake('--supervise')
        ss = ss.bake('--name', self._get_yarn_job_name())
        username = getpass.getuser()
        ss = ss.bake('--principal', ('{username}@DUNNHUMBY.CO.UK').format(username=username))
        ss = ss.bake('--keytab', ('/home/{username}/{username}.keytab').format(username=username))





        # The following assignment was added to enable the pyspark job upload the PMML file to HDFS
        # First, we check if there's even a PMML associated with this pyspark job.
        # This change was made by Milan.
        full_pmml_path = join(self.properties['program_path'], self.pmml_path) if self.pmml_path else None
        files = ','.join([self.config_path, full_pmml_path]) if self.pmml_path else self.config_path

        ss = ss.bake('--files', files)
        ss = ss.bake('--conf', 'spark.yarn.maxAppAttempts=1')
        ss = ss.bake('--conf', 'spark.hive.warehouse.data.skiptrash=true')
        ss = ss.bake('--conf', 'hive.warehouse.data.skiptrash=true')

        ss = ss.bake('--conf', 'spark.yarn.executor.memoryOverhead={0}'.format(self.spark_yarn_executor_memoryOverhead))
        ss = ss.bake('--conf', 'spark.yarn.driver.memoryOverhead={0}'.format(self.spark_yarn_driver_memoryOverhead))

        if self.executor_cores is not None:
            ss = ss.bake('--executor-cores', self.executor_cores)
        if self.executor_memory is not None:
            ss = ss.bake('--executor-memory', self.executor_memory)
        if self.driver_memory is not None:
            ss = ss.bake('--driver-memory', self.driver_memory)
        if self.num_executors is not None:
            ss = ss.bake('--num-executors', self.num_executors)
        if self.driver_class_path is not None:
            ss = ss.bake('--driver-class-path', self.driver_class_path)

        if self.spark_dynamicallocation_maxexecutors is not None:
            ss = ss.bake('--conf', 'spark.dynamicAllocation.maxExecutors={0}'.format(self.spark_dynamicallocation_maxexecutors))
        if self.spark_sql_broadcastTimeout is not None:
            ss = ss.bake('--conf', 'spark.sql.broadcastTimeout={0}'.format(self.spark_sql_broadcastTimeout))
        if self.spark_network_timeout is not None:
            ss = ss.bake('--conf', 'spark.network.timeout={0}'.format(self.spark_network_timeout))
        if self.spark_sql_shuffle_partitions is not None:
            ss = ss.bake('--conf', 'spark.sql.shuffle.partitions={0}'.format(self.spark_sql_shuffle_partitions))
        if self.driver_cores is not None:
            ss = ss.bake('--conf', 'spark.driver.cores={0}'.format(self.driver_cores))
        if self.spark_sql_autoBroadcastJoinThreshold is not None:
            ss = ss.bake('--conf', 'spark.sql.autoBroadcastJoinThreshold={0}'.format(self.spark_sql_autoBroadcastJoinThreshold))

        if self.spark_dynamicallocation_minexecutors is not None:
            ss = ss.bake('--conf', 'spark.dynamicAllocation.minExecutors={0}'.format(self.spark_dynamicallocation_minexecutors))
        if self.spark_executor_heartbeatInterval is not None:
            ss = ss.bake('--conf', 'spark.executor.heartbeatInterval={0}'.format(self.spark_executor_heartbeatInterval))
        if self.spark_yarn_maxAppAttempts is not None:
            ss = ss.bake('--conf', 'spark.yarn.maxAppAttempts={0}'.format(self.spark_yarn_maxAppAttempts))
        if self.spark_ui_view_acls is not None:
            ss = ss.bake('--conf', 'spark.ui.view.acls={0}'.format(self.spark_ui_view_acls))
        if self.spark_acls_enable is not None:
            ss = ss.bake('--conf', 'spark.acls.enable={0}'.format(self.spark_acls_enable))
        if self.spark_yarn_appMasterEnv_PYSPARK_PYTHON is not None:
            ss = ss.bake('--conf', 'spark.yarn.appMasterEnv.PYSPARK_PYTHON={0}'.format(self.spark_yarn_appMasterEnv_PYSPARK_PYTHON))
        if self.spark_yarn_appMasterEnv_PYSPARK_DRIVER_PYTHON is not None:
            ss = ss.bake('--conf', 'spark.yarn.appMasterEnv.PYSPARK_DRIVER_PYTHON={0}'.format(self.spark_yarn_appMasterEnv_PYSPARK_DRIVER_PYTHON))


        if self.pyjars:
            jars = [self._get_abs_script_path(script=jar) for jar in self.pyjars.split(',')]
            full_path_jars = ','.join(jars)
            ss = ss.bake('--jars', full_path_jars)

        if self.pyfiles:
            files = [self._get_abs_script_path(script=file) for file in self.pyfiles.split(',')]
            full_path_files= ','.join(files)
            ss = ss.bake('--py-files', full_path_files)
        logger.info('baked spark-submit: {0}'.format(ss))
        try:
            if self.spark_driver_args is None:
                self.spark_process = ss(self._get_abs_script_path(script=self.pyspark_script_name),
                                        self._dump_job_options_to_string(), _ok_code=[0, 1])
            else:
                self.spark_process = ss(self._get_abs_script_path(script=self.pyspark_script_name),
                                        self.spark_driver_args, self._dump_job_options_to_string(), _ok_code=[0, 1])
        except Exception as err:
            logger.error('Unhandled exception in run_job: {0}'.format(str(err)), exc_info=1)
            sys.exit(2)

        finally:
            if not self._process_suceeded():
                self.in_exception = True

    def clean_up(self):
        super(PySparkJob2, self).clean_up()

        logger.info('spark-submit command executed:')
        logger.info(self.spark_process.ran)

        logger.info('spark-submit stderr:')
        logger.info(self.spark_process.stderr)

        application_id = self._get_yarn_application_id()
        if application_id:
            yarn_log = self._get_yarn_logs(application_id)
            logger.info('yarn stdout:')
            logger.info(yarn_log.stdout)
            logger.info('yarn stderr:')
            logger.info(yarn_log.stderr)

        if self.in_exception:
            logger.info('self.in_exception:')
            logger.info(self.in_exception)
            raise JobException("Spark process failed, please consult Yarn logs")

    def _process_suceeded(self):
        logger.info("self.spark_process.exit_code is {}".format(self.spark_process.exit_code))
        if self.spark_process.exit_code == 0:
            return True
        return False

    def _get_yarn_application_id(self):
        p = re.compile('Submitted application (application_\d*_\d*)')
        m = p.search(self.spark_process.stderr)
        if m:
            return m.group(1)
        return None

    @staticmethod
    def _get_yarn_logs(application_id):
        return yarn('logs', '-applicationId', application_id)

    def _get_yarn_job_name(self):
        return self.pyspark_script_name

    def _dump_job_options_to_string(self):
        return self.job_properties.dump_to_string()
