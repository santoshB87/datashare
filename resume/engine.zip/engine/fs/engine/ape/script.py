import os
import re
import logging
from ape.properties import Properties
from ape.errors import JobException

logger = logging.getLogger(__name__)


class Script(list):
    """subclass list object, adding methods to read string from file, substitute any variables in that
    string with key/value pairs in a dict, report on any unsubstituted vars and split the string into
    a list of statements"""

    def __init__(self, path=None, subs_dict=None, prefix='', suffix=''):
        super(Script, self).__init__()
        self.subs_dict = Properties()
        self.script_string = ''
        self.prefix = prefix
        self.suffix = suffix
        self.recursive_substitute_limit = 10
        self.re_pattern = re.compile(re.escape(prefix) + '(.[^#{}]+?)' + re.escape(suffix), re.IGNORECASE)

        if path:
            self.read_from_file(path)
        if subs_dict:
            self.subs_dict.update(subs_dict)

        if self.subs_dict and self.script_string:
            self.substitute_variables()
            self.check_for_unsubstituted()
            self.split_statements()

    def read_from_file(self, path):
        if not os.path.exists(path):
            raise JobException('File not found: {0}'.format(path))
        with open(path) as f:
            self.script_string = f.read()

    def split_statements(self, comment='--', separator=';'):
        if not self.script_string:
            raise JobException('No script string to operate on')
        cleaned = os.linesep.join([l for l in self.script_string.splitlines() if l and not l.startswith(comment)])
        for s in [s.strip() for s in cleaned.split(separator) if s and not s.isspace()]:
            self.append(s)

    def get_delimited_vars(self):
        seq = self.re_pattern.findall(self.script_string)
        seen = set()
        seen_add = seen.add
        return [x for x in seq if not (x in seen or seen_add(x))]

    def substitute_variables(self, count=0):
        if count >= self.recursive_substitute_limit:
            raise JobException('Script variable substitution has looped {0} times, aborting'.format(count))
        if not self.script_string:
            raise JobException('No script string to operate on')
        if not self.subs_dict:
            raise JobException('No substitution dictionary provided')
        start_string = self.script_string
        for key in self.get_delimited_vars():
            replacement = self.subs_dict.get_optional_value(*key.replace(' ', '').split(','))
            if replacement is not None:
                logger.info('Substituting {0}: {1}'.format(key, replacement))
                self.script_string = self.script_string.replace(self.prefix + key + self.suffix, str(replacement))
        # recursively call self until no further substitutions occur
        if start_string != self.script_string:
            self.substitute_variables(count + 1)

    def check_for_unsubstituted(self):
        if self.get_delimited_vars():
            unsubstituted_string = ' '.join(self.get_delimited_vars())
            raise JobException('Unsubstituted variables in script: {0}'.format(unsubstituted_string))
