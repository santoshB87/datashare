#!/dhcommon/dhpython/python/bin/python2.7
import argparse
import logging
import os
import sys

from ape.errors import JobException
from ape.hiveserver2.hs2session import HiveServer2Session
from ape.interactive import InteractivePrompt
from ape.properties import Properties
from ape.script import Script

logger = logging.getLogger('ape')


def get_args(argv):
    parser = argparse.ArgumentParser(description='apeline.py')
    group1 = parser.add_mutually_exclusive_group()
    group2 = parser.add_mutually_exclusive_group()
    group1.add_argument('--file',
                        help='HQL file to be executed')
    group1.add_argument('--query',
                        help='HQL statement(s) to be executed')
    parser.add_argument('--config_file',
                        help='JSON formatted file of key:value substitutions')
    parser.add_argument('--config_string',
                        help='JSON formatted string of key:value substitutions')
    parser.add_argument('--subs_prefix',
                        help='substitution prefix',
                        default='#{{')
    parser.add_argument('--subs_suffix',
                        help='substitution suffix',
                        default='}}#')
    parser.add_argument('--host',
                        help='the HiveServer2 host to connect to',
                        required=True)
    parser.add_argument('--port',
                        help='the port to use on the HS2 host  (default: 21050)',
                        default=21050,
                        type=int)
    parser.add_argument('--engine',
                        help='the sql execution engine to use on the HS2 host (default: impala)',
                        default='impala')
    parser.add_argument('--queue',
                        help='impala or YARN resource pool',
                        default='default')
    parser.add_argument('--delim',
                        help='field delimiter for query results (default: ,)',
                        default=',')
    parser.add_argument('--noheader',
                        help='do not print column headers',
                        action='store_true',
                        default=False)
    group2.add_argument('--verbose',
                        help='print impala execution summary to log after executing each statement',
                        action='store_true',
                        default=False)
    group2.add_argument('--silent',
                        help='only print errors to stderr and query results to stdout, all other output suppressed',
                        action='store_true',
                        default=False)
    return parser.parse_args(argv)


def main(argv):
    args = get_args(argv)
    if args.silent:
        logger.setLevel(logging.ERROR)
    session = HiveServer2Session(
        host=args.host,
        port=args.port,
        engine=args.engine,
        verbose=args.verbose,
        delimiter=args.delim,
        noheader=args.noheader,
        request_pool=args.queue)
    if args.file:
        logger.info('Executing statements in {0}'.format(os.path.abspath(args.file)))
        script = Script(path=args.file, prefix=args.subs_prefix, suffix=args.subs_suffix)
        subs_dict = Properties()
        if args.config_file:
            logger.info('Reading substitution values from {0}'.format(os.path.abspath(args.config_file)))
            subs_dict.append_from_path(path=args.config_file, markup='json')
        if args.config_string:
            logger.info('Reading substitution values from command line')
            subs_dict.append_from_string(in_string=args.config_string)
        if len(subs_dict):
            logger.info('Substituting variables in script before execution')
            script.subs_dict = subs_dict
            script.substitute_variables()
            script.check_for_unsubstituted()
        script.split_statements()
        session.execute_statements(script)
    elif args.query:
        logger.info('Executing statements specified on command line')
        session.execute_statements(str(args.query))
    else:
        with InteractivePrompt(
            prompt='{0}:{1}'.format(args.host, args.port),
            history_file_name='.apeline_history'
        ) as prompt:
            for query in prompt:
                try:
                    session.execute_statements(str(query))
                except JobException as err:
                    logger.error(err.message)
                    pass
    session.close_session()


if __name__ == '__main__':
    try:
        main(sys.argv[1:])
    except JobException as err:
        logger.error(err.message)
        sys.exit(2)
    except (SystemExit, KeyboardInterrupt) as err:
        logger.info('Exiting: {0}'.format(err.message))
        sys.exit(err)
    except Exception as err:
        logger.error('Unhandled exception: {0}'.format(err.message), exc_info=1)
        sys.exit(2)

