from json import load
from pyhive.hive import connect
from os.path import join, pardir, dirname
import sys

def create_hive_table_from_csv():
    confs, request_pool = _read_configs()
    cursor = get_hive_connection(**confs)
    load_csv_to_hive(cursor, request_pool)

def _read_configs():
    CONFIG_PATH = _get_paths('config')
    with open(CONFIG_PATH, 'r') as fh:
        config_dict = load(fh)
        config_dict = config_dict.get("SqoopOracleTableAndColumnMetadata2").get("sqoop").get("hadoop").get("jdbc")
        # sse_request_pool = config_dict.get('SSERequestPool')
        sse_request_pool = 'root.sse'
        hive_host = config_dict.get("host")
        hive_port = int(config_dict.get("port"))
        database = config_dict.get("database")
        confs = dict(host=hive_host, port=hive_port, database=database)
    return confs, sse_request_pool


def get_hive_connection(host, port, database):
    return connect(host, port, database).cursor()

def _get_paths(which_path):
    CONFIG_PATH = join(dirname(__file__), 'config.json')
    edge_node_file_path = join(dirname(__file__), pardir, 'lookup_files/new_id_app_fox.csv')
    hive_table_name = 'cust_lookup'
    if which_path == 'config':
        return CONFIG_PATH
    elif which_path == 'files':
        return edge_node_file_path, hive_table_name
    else:
        return -1


def load_csv_to_hive(cursor, request_pool):
    request_pool = request_pool
    edge_node_file_path, hive_table_name = _get_paths('files')
    create_query = """
                        CREATE TABLE IF NOT EXISTS {hive_table_name}(phonenumber INT,
                                                               dib_cust_code STRING,
                                                               new_id INT)
                        STORED AS PARQUET
                   """.format(**locals())
    sys.stdout.write(create_query)
    sys.stdout.flush()
    cursor.execute(create_query)

    load_query = """
                        SET MAPREDUCE.JOB.QUEUE.NAME= '{request_pool}';
                        LOAD DATA LOCAL INPATH {edge_node_file_path} INTO TABLE {hive_table_name}
                   """.format(**locals())
    sys.stdout.write(load_query)
    sys.stdout.flush()
    cursor.execute(load_query)



if __name__=='__main__':
    create_hive_table_from_csv()
