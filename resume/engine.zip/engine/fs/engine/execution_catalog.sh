#!/bin/bash

# Common section
. engine/sys/common.sh

# Fact load section
if [ "#{{job.exec.case}}#" = "LOAD_FCT" ]; then

  # Check if APE dates loaded and can be used
  if [ "#{{sys.ape.date.loaded}}#" = "false" ]; then
    echo "ERROR: APE date variables are not set, but will be used in the execution_catalog."
    exit 1
  fi

  # Clear out the target raw data directory, otherwise sqoop will complain that the directory already exists
  tryToExecute /usr/bin/hadoop fs -rm -f -r -skipTrash "#{{table.tgt.path}}#/#{{table.tgt.name}}#_#{{LATEST_FIS_WEEK_1}}#"

  # Specify Djava.security.egd option to prevent connection reset errors when several sqoop jobs are run at exactly the same time (java.sql.SQLRecoverableException: IO Error: Connection reset)
  tryToExecute export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
  tryToExecute /usr/bin/sqoop import -D mapred.task.timeout=0 -D mapred.child.java.opts="\-Djava.security.egd=file:/dev/../dev/urandom" --verbose --connect #{{sys.exadata.jdbc}}# --query "select * from #{{table.src.name}}# where date_id between to_date('#{{START_FIS_WEEK_YYYY-MM-DD_1}}#', 'YYYY-MM-DD') and to_date('#{{END_FIS_WEEK_YYYY-MM-DD_1}}#', 'YYYY-MM-DD') and \$CONDITIONS" --username $SQOOP_CONNECTION_USR --password $SQOOP_CONNECTION_PSW -m #{{sys.scoop.fct.mappers}}# --direct --fields-terminated-by '\001' --null-string '\\N' --null-non-string '\\N' --target-dir "#{{table.tgt.path}}#/#{{table.tgt.name}}#_#{{LATEST_FIS_WEEK_1}}#" --split-by #{{etl.split.column}}# --fetch-size #{{sys.scoop.fct.fetchsize}}#

  # 26FEB2015 - Eoin has changed the default umask for HDFS from 002 to 022 due to issues seen elsewhere. We have agreed to temporarily add a chmod here. Otherwise, the "load data inpath ..." step fails.
  tryToExecute /usr/bin/hadoop fs -chmod g+w "#{{table.tgt.path}}#/#{{table.tgt.name}}#_#{{LATEST_FIS_WEEK_1}}#"

  # Run the script that defines the structure of the wh_raw table (if not already defined)
  tryToExecute runHQL beeline -f #{{job2.hql.name}}#

  # Load the data from the raw text files into the wh_raw table
  tryToExecute runHQL beeline "use #{{table.tgt.schema}}#;\nalter table #{{table.tgt.name}}# drop if exists partition (fis_week_id=#{{LATEST_FIS_WEEK_1}}#);"
  tryToExecute /usr/bin/hadoop fs -rm -f -r -skipTrash "#{{sys.client.path}}##{{sys.env}}#/sse/hive/#{{SSEHiveDatabasePrefix}}#_ssewh_raw/#{{table.tgt.name}}#/fis_week_id=#{{LATEST_FIS_WEEK_1}}#"
  tryToExecute runHQL beeline "use #{{table.tgt.schema}}#;\nalter table #{{table.tgt.name}}# add partition (fis_week_id=#{{LATEST_FIS_WEEK_1}}#);"
  tryToExecute runHQL beeline "load data inpath '#{{table.tgt.path}}#/#{{table.tgt.name}}#_#{{LATEST_FIS_WEEK_1}}#' into table #{{table.tgt.schema}}#.#{{table.tgt.name}}# partition(fis_week_id=#{{LATEST_FIS_WEEK_1}}#);"

  # Impala will not be able to read the wh_raw table that has just been loaded by beeline (hive) unless we invalidate the metadata first
  tryToExecute engine/sys/impyla_client.py --host #{{sys.hiveserver.proxy}}# --port #{{sys.hiveserver.proxy.impala.port}}# --query "invalidate metadata #{{table.tgt.schema}}#.#{{table.tgt.name}}#;"

  # Load the table from the wh_raw area into the warehouse (wh) stored as the target format (currently parquet)
  tryToExecute engine/sys/impyla_client.py --host #{{sys.hiveserver.proxy}}# --port #{{sys.hiveserver.proxy.impala.port}}# --file #{{job1.hql.name}}#
fi
##
#

# Dim load section
if [ "#{{job.exec.case}}#" = "LOAD_DIM" ]; then
  # Optional where condition that can be used in the Sqoop query to subset data
  SQOOP_LOAD_DIM_OPT_WHERE="#{{sqoop.load_dim.opt_where}}#"
  OPT_KEY_NAME=sqoop.load_dim.opt_where
  if [ "${SQOOP_LOAD_DIM_OPT_WHERE}" = "#{{${OPT_KEY_NAME}}}#" ]; then
    SQOOP_LOAD_DIM_OPT_WHERE=
  fi

  # Check if APE dates loaded and can be used
  if [ "#{{sys.ape.date.loaded}}#" = "false" ] && [ "#{{sys.dim.sqoop.opt_where.datevarused}}#" = "true" ]; then
    echo "ERROR: APE date variables are not set, but will be used in the execution_catalog."
    exit 1
  fi

  # Clear out the target raw data directory, otherwise sqoop will complain that the directory already exists
  tryToExecute /usr/bin/hadoop fs -rm -f -r -skipTrash "#{{table.tgt.path}}#/#{{table.tgt.name}}#"

  # Specify Djava.security.egd option to prevent connection reset errors when several sqoop jobs are run at exactly the same time (java.sql.SQLRecoverableException: IO Error: Connection reset)
  tryToExecute export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
  tryToExecute /usr/bin/sqoop import -D mapred.task.timeout=0 -D mapred.child.java.opts="\-Djava.security.egd=file:/dev/../dev/urandom" --verbose --connect #{{sys.exadata.jdbc}}# --query "select * from #{{table.src.name}}# where $SQOOP_LOAD_DIM_OPT_WHERE \$CONDITIONS" --username $SQOOP_CONNECTION_USR --password $SQOOP_CONNECTION_PSW -m #{{sys.scoop.dim.mappers}}# --direct --fields-terminated-by '\001' --null-string '\\N' --null-non-string '\\N' --target-dir "#{{table.tgt.path}}#/#{{table.tgt.name}}#" --split-by #{{etl.split.column}}# --fetch-size #{{sys.scoop.dim.fetchsize}}#

  # 26FEB2015 - Eoin has changed the default umask for HDFS from 002 to 022 due to issues seen elsewhere. We have agreed to temporarily add a chmod here. Otherwise, the "load data inpath ..." step fails.
  tryToExecute /usr/bin/hadoop fs -chmod g+w "#{{table.tgt.path}}#/#{{table.tgt.name}}#"

  # Run the script that defines the structure of the wh_raw table (if not already defined)
  tryToExecute runHQL beeline -f #{{job2.hql.name}}#

  # Load the data from the raw text files into the wh_raw table
  tryToExecute runHQL beeline "use #{{table.tgt.schema}}#;\nalter table #{{table.tgt.name}}# drop if exists partition (hive_load_date=#{{APE_TODAY_YYYYMMDD}}#);"
  tryToExecute /usr/bin/hadoop fs -rm -f -r -skipTrash "#{{sys.client.path}}##{{sys.env}}#/sse/hive/#{{SSEHiveDatabasePrefix}}#_ssewh_raw/#{{table.tgt.name}}#/hive_load_date=#{{APE_TODAY_YYYYMMDD}}#"
  tryToExecute runHQL beeline "use #{{table.tgt.schema}}#;\nalter table #{{table.tgt.name}}# add partition (hive_load_date=#{{APE_TODAY_YYYYMMDD}}#);"
  tryToExecute runHQL beeline "load data inpath '#{{table.tgt.path}}#/#{{table.tgt.name}}#' into table #{{table.tgt.schema}}#.#{{table.tgt.name}}# partition(hive_load_date=#{{APE_TODAY_YYYYMMDD}}#);"

  # Impala will not be able to read the wh_raw table that has just been loaded by beeline (hive) unless we invalidate the metadata first
  tryToExecute engine/sys/impyla_client.py --host #{{sys.hiveserver.proxy}}# --port #{{sys.hiveserver.proxy.impala.port}}# --query "invalidate metadata #{{table.tgt.schema}}#.#{{table.tgt.name}}#;"

  # Load the table from the wh_raw area into the warehouse (wh) stored as the target format (currently parquet)
  tryToExecute engine/sys/impyla_client.py --host #{{sys.hiveserver.proxy}}# --port #{{sys.hiveserver.proxy.impala.port}}# --file #{{job1.hql.name}}#
fi
##
#

# Hive code execution section
if [ "#{{job.exec.case}}#" = "RUN_HIVE" ]; then
  tryToExecute runHQL hive -f #{{job1.hql.name}}#
fi
##
#

# Beeline code execution section
if [ "#{{job.exec.case}}#" = "RUN_BEELINE" ]; then
  tryToExecute runHQL beeline -f #{{job1.hql.name}}#
fi
##
#

# Impala execution section
if [ "#{{job.exec.case}}#" = "RUN_IMPALA" ]; then
  tryToExecute engine/sys/impyla_client.py --host #{{sys.hiveserver.proxy}}# --port #{{sys.hiveserver.proxy.impala.port}}# --file #{{job1.hql.name}}#
fi
##
#

# Beetamer execution section
if [ "#{{job.exec.case}}#" = "RUN_BT" ]; then
  tryToExecute runHQL bt -f #{{job1.hql.name}}#
fi
##
#