#!/bin/bash

user=$(whoami)
walletUserPassword=$1
dbAlias=$2
dbUser=$3
dbPass=$4

export ORACLE_HOME="/oracle/product/11.2.0/client_1"
paths=("$HOME/bin" "/sbin" "/usr/bin" "/usr/sbin" "$ORACLE_HOME/bin")
for i in "${paths[@]}"
do
        if [[ $PATH == *"$i"* ]]
                then
                        :
                else
                        export PATH="$PATH:$i"
        fi
done

export TNS_ADMIN="$HOME/tns_admin"
mkdir -p $TNS_ADMIN
echo "# sqlnet.ora Network Configuration File

SQLNET.AUTHENTICATION_SERVICES= (NTS)

NAMES.DIRECTORY_PATH= (LDAP, TNSNAMES, EZCONNECT)

SQLNET.EXPIRE_TIME = 2


WALLET_LOCATION =
   (SOURCE =
     (METHOD = FILE)
     (METHOD_DATA =
       (DIRECTORY = $HOME/.oracle_wallet)
     )
   )

SQLNET.WALLET_OVERRIDE = TRUE" > "$TNS_ADMIN/sqlnet.ora"

ldlibpaths=("/oracle/product/11.2.0/client_1/lib")
for i in "${ldlibpaths[@]}"
do
        if [[ $LD_LIBRARY_PATH == *"$i"* ]]
                then
                        :
                else
                        export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$i"
        fi
done

if [[ $(tnsping $dbAlias) == *"OK"* ]]
	then
		tnsping $dbAlias | egrep "DESCRIPTION" |  sed "s/Attempting to contact /$dbAlias=/" > "$TNS_ADMIN/tnsnames.ora"
	else
		echo "tnsping failed"
		exit
fi
orapki wallet create -wallet $HOME/.oracle_wallet -auto_login -pwd $walletUserPassword

if [[ $(echo $walletUserPassword | mkstore -wrl $HOME/.oracle_wallet -listCredential) ==  *$dbAlias* ]]
        then
                echo $walletUserPassword | mkstore -wrl $HOME/.oracle_wallet -deleteCredential $dbAlias
fi

echo $walletUserPassword | mkstore -wrl $HOME/.oracle_wallet -createCredential $dbAlias $dbUser $dbPass

if [[ $(echo "exit" | sqlplus /@$dbAlias) == *"Connected to:"* ]]
        then
                echo "connected"
fi