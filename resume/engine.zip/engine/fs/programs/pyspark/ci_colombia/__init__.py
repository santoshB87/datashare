"""
ci_colombia CMP Entities
"""
import logging

database = 'ci_colombia_media_mart'

logger = logging.getLogger(__name__)
