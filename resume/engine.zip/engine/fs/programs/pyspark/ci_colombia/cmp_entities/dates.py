""""
ci colombia Dates
"""
import logging

import dunnhumby
from ci_colombia import database

logger = logging.getLogger(__name__)


class Dates(dunnhumby.cmp_entities.dates.Dates):
    """
    Inherits the base CMP Customer class and implements the get_data() method'
    """

    def __init__(self):
        """
        Define the Dates schema and column or columns that uniquely define a Date
        """
        super(Dates, self).__init__()

        self.get_data()

    @property
    def database(self):
        """
        returns database instance from init.py
        :return: database
        """
        return database
