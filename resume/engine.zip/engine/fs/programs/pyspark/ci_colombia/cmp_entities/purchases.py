"""
ci_colombia Purchases
"""

from dunnhumby.cmp_entities.purchases import Purchases as PurchasesBase


class Purchases(PurchasesBase):
    """
    ci_colombia Purchases
    """

    def __init__(self, config):
        """
        get purchases data
        :param config:
        """
        super(Purchases, self).__init__(config=config)
        self.get_data()
