"""CI Colombia features module"""
import logging

logger = logging.getLogger(__name__)
