""""
client Customers
"""
import logging
import pyspark.sql.types as pt
import dunnhumby
from client import custom_fact_dim_databases, mm_database
import os

logger = logging.getLogger(__name__)


class Customers(dunnhumby.cmp_entities.customers.Customers):

    """
    Inherits the base CMP Customer class and implements the get_data() method'
    """

    def __init__(self, config):
        """
        Define the Customers schema and column or columns that uniquely define a Customer
        """
        super(Customers, self).__init__()

        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Customer', pt.StringType(), True))
        required_schema.add(pt.StructField('FulfillmentStore', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore1', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore2', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore3', pt.StringType(), True))

        self.required_schema = required_schema
        if "filters" in config:
            filter_config = config["filters"]
            if "customers" in filter_config:
                customers_config = filter_config["customers"]
            else:
                customers_config = {}
        else:
            customers_config = {}

        self.get_data(config_dict=customers_config)

    @property
    def database(self):
        return custom_fact_dim_databases.get("Customers", mm_database)
