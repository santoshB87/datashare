"""
client Transactions
"""
from dunnhumby.cmp_entities.transactions import Transactions as baseTransactions
from client import custom_fact_dim_databases, mm_database

class Transactions(baseTransactions):
    """
    Inherits the Base CMP Transactions entity class and overrides the get_data method
    """

    def __init__(self, config):
        """
        Define the Transactions schema and column or columns that uniquely define a Transaction
        """
        super(Transactions, self).__init__()

        if "filters" in config:
            filter_config = config["filters"]
            if "transactions" in filter_config:
                transactions_config = filter_config["transactions"]
            else:
                transactions_config = {}
        else:
            transactions_config = {}

        self.get_data(config_dict=transactions_config)
        self.get_most_recent_transaction_date()


    @property
    def database(self):
        return custom_fact_dim_databases.get("Transactions", mm_database)
