"""
Purchase/denorm table generator
"""


import logging
import time
from datetime import datetime as dt, timedelta as td
from client.cmp_features.purchasing_feature_generator import PurchasingFeatureGenerator
from dunnhumby import contexts
from pyspark.sql import functions as pf, types as pt

logger = logging.getLogger(__name__)


class DenormPurchasesGenerator(object):
    """
    Tesco UK purchase/denorm table generator
    """

    def __init__(self, config, run_date, feature_specs):
        """
        Constructor of PurchasesGenerator
        :param config: client config
        :param run_date: datetime.date: run_date can be either current date i.e today or any
        specific past date for which purchase/denorm table generated.
        """
        super(DenormPurchasesGenerator, self).__init__()
        self.sqlContext = contexts.sql_context()

        self.config = config
        self.features_specs = feature_specs
        db_name = self.config["mm_database"]
        table_name = self.config["SSEHiveTransactionTab"]
        self.date_info = self.sqlContext.sql("show partitions {0}.{1}".format(db_name, table_name)).sort(pf.col('partition').desc()).collect()[0][0].split("=")[-1]
        # sql_statement = "select max(date_id) as max_date from {}.{}".format(db_name, table_name)
        # date_output = self.sqlContext.sql(sql_statement).collect()
        # self.date_info = [row["max_date"] for row in date_output][0]
        self.refresh_purchases=self.config.get("refresh_purchases_denorm", False)
        self.end_date = dt.strptime(run_date, "%Y-%m-%d").date() if run_date and run_date != "None" else dt.strptime(self.date_info, "%Y-%m-%d").date()
        self.start_date = self.end_date - td(
            days=(self.config.get("SSEFeatureDataPurgeRetentionWeekNum", 60) * 7) - 1)
        self.purchasing_feature_gen = PurchasingFeatureGenerator(
            config=self.config, feature_specs=self.features_specs, cadence_attribute="date_short_name", run_date=self.end_date, refresh_denorm=self.refresh_purchases)

    def generate_and_write_purchases(self, clean_run=None):
        """
        Call & execute all required section for creation of purchase/denrom table
        :param clean_run: boolean: Argument clean_run (when True) activate clean slate run, i.e.
        process will remove all old data in purchase/denorm table and provide refresh/clean run.
        :return: boolean: True/False
        """
        st_time = time.time()
        logger.info("Creating purchase/denom table for date range %s to %s", self.start_date,
                    self.end_date)
        logger.info("Calling pre_run method of PurchasingFeatureGenerator, ignore extra logging")
        # - PRE RUN SECTION -
        self.purchasing_feature_gen.since_date = self.start_date
        self.purchasing_feature_gen.cadence = self.end_date
        pre_res = self.purchasing_feature_gen.pre_run(clean_run=clean_run)
        pre_msg = "succeeded" if pre_res else "failed"
        pre_time = time.time()
        logger.info("Pre run section executed in %d secs - %s", int(pre_time - st_time), pre_msg)
        if not pre_res:
            logger.error("Insufficient information or incomplete setup to run feature generator")
            raise Exception("Error in pre run section, please check log for more details")
        # - DENORMALIZATION SECTION -
        denormalization_res = self.purchasing_feature_gen.denormalization_section()
        denormalization_section_res = all(item.result for item in denormalization_res)
        denormalization_msg = "succeeded" if denormalization_section_res else "failed"
        ed_time = time.time()
        print "--------------- Denormalization Run Result -------"
        if "denormalization_res" in locals() or "denormalization_res" in globals():
            for item in denormalization_res:
                print item.date_id, item.result, item.time_taken
        print "--------------------------------------------------"
        print "--------------- Dates Details --------------------"
        print "Start date - {0}".format(self.start_date)
        print "End date - {0}".format(self.end_date)
        print "--------------------------------------------------"
        print "--------------- Run Timing -----------------------"
        print "Total Run - {0} secs".format(int(ed_time - st_time))
        print "Pre Run Section - {0} secs - {1}".format(int(pre_time - st_time), pre_msg)
        print "Denormalization Section - {0} secs - {1}".format(int(ed_time - pre_time),
                                                                denormalization_msg)
        print "--------------------------------------------------"
        if not denormalization_section_res:
            raise Exception("Error in denormalization section, please check log for more details")
        return denormalization_section_res
