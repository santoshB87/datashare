import logging

from dunnhumby import contexts

logger = logging.getLogger(__name__)


def create_combined_view(write_database):
    sqlContext = contexts.sql_context()

    drop_view_sttmt = "drop view if exists {write_database}.feat_prod_ps_combined_current".format(write_database=write_database)
    logger.info(drop_view_sttmt)
    sqlContext.sql(drop_view_sttmt)

    create_view_sttmt = """
        create view
           {write_database}.feat_prod_ps_combined_current
        as select
           t1.tpnb                                                                                   as tpnb
         , t1.tpnb_desc                                                                              as tpnb_desc
         , coalesce(cast(t2.global_popularity_composite as string), '0')                             as pen_global_visits
         , coalesce(cast(t3.global_popularity_composite as string), '0')                             as pen_global_visits_online_instore
         , coalesce(cast(t4.global_popularity_composite / t4.global_prod_weeks_sold as string), '0') as pen_global_visits_online_4w
         , coalesce(cast(t5.global_popularity_composite / t5.global_prod_weeks_sold as string), '0') as pen_global_visits_online_instore_4w
         , coalesce(cast(t6.trial_rate as string),'0')                                               as trial_rate
        from
        (
        select distinct tpnb,tpnb_desc from
           (
              select tpnb ,tpnb_desc from {write_database}.feat_prod_ps_trial_rate_current
              union all
              select tpnb ,tpnb_desc from {write_database}.feat_prod_popularity_onl_91d_current
              union all
              select tpnb ,tpnb_desc from {write_database}.feat_prod_popularity_onl_sto_91d_current
              union all
              select tpnb ,tpnb_desc from {write_database}.feat_prod_popularity_onl_28d_current
              union all
              select tpnb ,tpnb_desc from {write_database}.feat_prod_popularity_onl_sto_28d_current
           ) as t7
        ) as t1
        left outer join
           {write_database}.feat_prod_popularity_onl_91d_current t2
           on t1.tpnb = t2.tpnb
        left outer join
           {write_database}.feat_prod_popularity_onl_sto_91d_current t3
           on t1.tpnb = t3.tpnb
        left outer join
           {write_database}.feat_prod_popularity_onl_28d_current t4
           on t1.tpnb = t4.tpnb
        left outer join
           {write_database}.feat_prod_popularity_onl_sto_28d_current t5
           on t1.tpnb = t5.tpnb
        left outer join
           {write_database}.feat_prod_ps_trial_rate_current t6
           on t1.tpnb = t6.tpnb
        where
            t2.global_popularity_composite is not null
        and t1.tpnb <> 'DEFAULT_HIERARCHY'
        and t1.tpnb_desc <> 'DEFAULT_HIERARCHY'""".format(write_database=write_database)
    logger.info(create_view_sttmt)
    sqlContext.sql(create_view_sttmt)
