import logging
from datetime import date, timedelta

from dunnhumby import contexts
from pyspark.sql.functions import lit, sum, avg, datediff, countDistinct, col, date_add
from pyspark.sql.types import IntegerType

logger = logging.getLogger(__name__)

def calculate_popularity(trial_period, media_mart_database, write_database, channel, weight_itm, weight_bsk, min_visits, run_date = date.today()):
    sqlContext = contexts.sql_context()

    max_date = \
        sqlContext.sql("show partitions {media_mart}.transactions".format(media_mart=media_mart_database)). \
        orderBy(col("partition").desc()).take(1)[0][0].split("=")[-1]

    logger.info("run_date set to : {run_date}".format(run_date=run_date))
    logger.info("max_transaction_date is : {max_date}".format(max_date=max_date))

    # Read dates data
    date_table = '{media_mart}.dates'.format(media_mart=media_mart_database)
    all_dates = sqlContext.table(date_table).select('date_id', 'fis_week_id')

    # Filter out all dates falling on or later than the run_date
    past_dates = all_dates.filter(all_dates.date_id.cast("date") <= lit(max_date).cast("date"))

    past_dates.persist()
    past_dates.count()

    # Limit dates to trial_period and tag dates with week numbers
    past_dates = past_dates.withColumn("days_from_run_date",  datediff(date_add(lit(max_date).cast("date"), 1), past_dates.date_id))
    past_dates = past_dates.filter(past_dates.days_from_run_date<=trial_period)
    past_dates_with_week_numbers = past_dates.withColumn("week_num", (1 + ((past_dates.days_from_run_date - 1) / 7)).cast(IntegerType()))

    # Read de-normalised transactions
    purchases_table = '{media_mart}.transactions'.format(media_mart=media_mart_database)

    purchases = sqlContext.table(purchases_table).select('date_id','customer','product','store','channel','basket','quantity')\
        .withColumn('date', col("date_id")).drop("date_id")

    # Filter purchases to required channels
    purchases = purchases.where(purchases.channel.isin(channel))

    # Tag transactions with week numbers
    transactions_with_week_numbers = purchases.join(past_dates_with_week_numbers.select('date_id','week_num'), purchases.date.cast('date') == past_dates_with_week_numbers.date_id.cast('date'), "inner")
    transactions_with_week_numbers = transactions_with_week_numbers.select('basket', 'quantity', 'store', 'product', 'week_num')

    # Calculate product level aggregations
    product_level_aggregations = transactions_with_week_numbers.groupby('product').agg(countDistinct('basket').alias('prod_visits'),
                                                                                       countDistinct('week_num').alias('prod_weeks_sold'),
                                                                                       sum('quantity').alias('prod_items'))

    # Calculate store level aggregations
    store_level_aggregations = transactions_with_week_numbers.groupby('store').agg(countDistinct('basket').alias('tot_visits'),
                                                                                   sum('quantity').alias('tot_items'))

    # Associate product and store aggregations and calculate ratios
    distinct_product_store_pairs = transactions_with_week_numbers.select('product','store').distinct()
    store_popularity_metrics = distinct_product_store_pairs.join(store_level_aggregations, 'store', 'inner')

    # Sum up store level aggregations to product level
    product_popularity_metrics = store_popularity_metrics.groupby('product').agg(sum('tot_visits').alias('tot_visits'), sum('tot_items').alias('tot_items'))

    # Drop products with visits lower than the minimum threshold
    product_popularity_metrics = product_popularity_metrics.filter(product_popularity_metrics['tot_visits'] > min_visits)

    product_popularity_metrics = product_popularity_metrics.join(product_level_aggregations,'product','inner')

    product_popularity_metrics = product_popularity_metrics.withColumn("global_basket_popularity",col('prod_visits')/col('tot_visits'))
    product_popularity_metrics = product_popularity_metrics.withColumn("global_item_popularity",col('prod_items')/col('tot_items'))

    product_popularity_metrics.persist()

    # Calculate Means Ratio
    means_ratio = product_popularity_metrics.select(lit(avg(product_popularity_metrics.global_basket_popularity) / avg(
        product_popularity_metrics.global_item_popularity)).alias('means_ratio')).collect()[0][0]

    # Calculate global_item_popularity_scaled and prodcomppop_sr_1w13w_ratcnt
    product_popularity_metrics = product_popularity_metrics.withColumn('means_ratio',lit(means_ratio))
    product_popularity_metrics = product_popularity_metrics.withColumn('global_item_popularity_scaled',lit(product_popularity_metrics.global_item_popularity * means_ratio))
    product_popularity_metrics = product_popularity_metrics.withColumn('prodcomppop_sr_1w13w_ratcnt', lit((product_popularity_metrics.global_basket_popularity * weight_bsk) + (product_popularity_metrics.global_item_popularity * means_ratio * weight_itm)))

    # Add product description
    tesco_uk_products_with_descriptions = sqlContext.table('{media_mart}.products'.format(media_mart=media_mart_database)).select('Product', 'ProductDescription').withColumnRenamed('Product','product')
    product_popularity_metrics_with_description = product_popularity_metrics.join(tesco_uk_products_with_descriptions, 'product', "inner")

    # Rename, add and subset columns to comply with output schema
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumnRenamed(
        'ProductDescription', 'prod_group_desc')
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumnRenamed(
        'prod_visits', 'global_prod_visits')
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumnRenamed(
        'prod_items', 'global_prod_items')
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumnRenamed(
        'prod_weeks_sold', 'global_prod_weeks_sold')
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumnRenamed(
        'global_basket_popularity', 'prodbskpop_sr_1w13w_ratcnt')
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumnRenamed(
        'global_item_popularity', 'prodpurchpop_sr_1w13w_ratcnt')
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.withColumn( "run_date",lit(str(run_date)))

    select_columns = ['product', 'prod_group_desc', 'global_prod_visits', 'global_prod_items', 'global_prod_weeks_sold', 'tot_visits', 'tot_items',
                      'prodbskpop_sr_1w13w_ratcnt', 'prodpurchpop_sr_1w13w_ratcnt', 'means_ratio', 'global_item_popularity_scaled', 'prodcomppop_sr_1w13w_ratcnt',
                      'run_date']
    product_popularity_metrics_with_description = product_popularity_metrics_with_description.select(select_columns)


    # Insert results into hive table
    feat_prod_popularity_table = "_".join(['feat_prod_popularity',"_".join(channel),str(trial_period) + 'd'])

    # create table if not exists tuk_sseft.feat_prod_ps_trial_rate
    create_table_sttmt = """
    create table if not exists {write_database}.{feat_prod_popularity_table}
    (
       product string
     , prod_group_desc string
     , global_prod_visits double
     , global_prod_items double
     , global_prod_weeks_sold int
     , tot_visits double
     , tot_items double
     , prodbskpop_sr_1w13w_ratcnt double
     , prodpurchpop_sr_1w13w_ratcnt double
     , means_ratio double
     , global_item_popularity_scaled decimal(38,10)
     , prodcomppop_sr_1w13w_ratcnt decimal(38,10)
    )
    partitioned by
       (run_date string)  
    stored as
       parquet
    """.format(write_database=write_database, feat_prod_popularity_table = feat_prod_popularity_table)
    logger.info(create_table_sttmt)
    sqlContext.sql(create_table_sttmt)

    # Insert trial_rates into run_date partition
    logger.info('SET hive.exec.dynamic.partition = True')
    sqlContext.sql('SET hive.exec.dynamic.partition = True')
    logger.info('set hive.exec.dynamic.partition.mode=nonstrict')
    sqlContext.sql('set hive.exec.dynamic.partition.mode=nonstrict')

    # Drop partition if exists
    drop_partition_sttmt = "ALTER TABLE {write_database}.{feat_prod_popularity_table} DROP IF EXISTS PARTITION(run_date='{run_date}')".format(write_database=write_database,run_date=str(run_date),feat_prod_popularity_table=feat_prod_popularity_table)
    logger.info(drop_partition_sttmt)
    sqlContext.sql(drop_partition_sttmt)
    product_popularity_metrics_with_description.write.mode("overwrite").format("parquet").insertInto(
        "{write_database}.{feat_prod_popularity_table}".format(write_database=write_database,
                                                                      feat_prod_popularity_table=feat_prod_popularity_table))

    # Drop and Re-Create current view of trial rates
    feat_prod_popularity_view = feat_prod_popularity_table + '_' + 'current'
    drop_view_sttmt = "drop view if exists {write_database}.{feat_prod_popularity_view}".format(write_database=write_database,feat_prod_popularity_view=feat_prod_popularity_view)
    logger.info(drop_view_sttmt)
    sqlContext.sql(drop_view_sttmt)

    create_view_sttmt = """
    create view
       {write_database}.{feat_prod_popularity_view}
    as select
       product as TPNB
     , prod_group_desc                 as TPNB_DESC
     , prodcomppop_sr_1w13w_ratcnt     as GLOBAL_POPULARITY_COMPOSITE
     , global_prod_weeks_sold          as global_prod_weeks_sold
    from
       {write_database}.{feat_prod_popularity_table} 
    where
        run_date = '{run_date}'
    """.format(write_database=write_database,feat_prod_popularity_view=feat_prod_popularity_view,feat_prod_popularity_table=feat_prod_popularity_table,run_date=run_date)
    logger.info(create_view_sttmt)
    sqlContext.sql(create_view_sttmt)
