"""
Trial Rate
"""

import logging
logger = logging.getLogger(__name__)

from datetime import timedelta, date

from dunnhumby import contexts
from pyspark.sql.functions import rank, when, lit, min, max, count, countDistinct, sum, col, broadcast
from pyspark.sql.types import *
from pyspark.sql.window import Window


def create_and_write_trial_rates(media_mart_database, write_database, pre,trial,min_hshd,channel_id,run_date = date.today()):
    sqlContext = contexts.sql_context()

    max_date = \
    sqlContext.sql("show partitions {media_mart}.transactions".format(media_mart=media_mart_database)). \
        orderBy(col("partition").desc()).take(1)[0][0].split("=")[-1]

    logger.info("run_date set to : {run_date}".format(run_date=run_date))
    logger.info("max_transaction_date is : {max_date}".format(max_date=max_date))

    # Read purchase data from de-normalised purchases table
    purchases_table = '{media_mart}.transactions'.format(media_mart=media_mart_database)
    purchases = sqlContext.table(purchases_table).select('date_id','customer','product','store','channel').withColumn('date',col("date_id")).drop("date_id")


    # Create dataframe of dates and fis_week_ids with associated 'trial'/'pre' tags
    date_table = '{media_mart}.dates'.format(media_mart=media_mart_database)
    all_dates = sqlContext.table(date_table).select('date_id', 'fis_week_id')

    # Filter out all dates in the future

    past_dates = all_dates.filter(all_dates.date_id.cast("date") <= lit(max_date).cast("date"))

    # Associate period tags with dates
    ranked_dates = past_dates.withColumn("rank", rank().over(Window.orderBy(past_dates.date_id.desc()))).limit(pre)
    past_dates_with_tags = ranked_dates.select(ranked_dates.date_id, ranked_dates.fis_week_id, ranked_dates.rank).withColumn('period', when(
        ranked_dates.rank <= trial, lit('tgt')).otherwise(lit('pre'))).drop('rank')

    past_dates_with_tags.persist()
    past_dates_with_tags.count()

    # Limit purchases to the trial+pre period window
    min_date = past_dates_with_tags.agg(min('date_id'))
    max_date = past_dates_with_tags.agg(max('date_id'))
    purchases = purchases.where((purchases.date.cast("date") >= min_date.collect()[0][0]) & (purchases.date.cast("date") <= max_date.collect()[0][0]))

    # Filter out purchases where either product or customer is null
    purchases = purchases.filter(purchases.customer.isNotNull())
    purchases = purchases.filter(purchases.product.isNotNull())

    # Separate pre and trial period transactions
    pre_period_dates = past_dates_with_tags.filter(past_dates_with_tags.period == 'pre')
    tgt_period_dates = past_dates_with_tags.filter(past_dates_with_tags.period == 'tgt')

    purchases_in_tgt_period = purchases.join(broadcast(tgt_period_dates), (purchases.date.cast('date') == tgt_period_dates.date_id.cast('date')), "inner").drop(tgt_period_dates.date_id)
    purchases_in_pre_period = purchases.join(broadcast(pre_period_dates), (purchases.date.cast('date') == pre_period_dates.date_id.cast('date')), "inner").drop(pre_period_dates.date_id)

    # Filter to transactions of required channels only
    purchases_in_tgt_period = purchases_in_tgt_period.where(purchases_in_tgt_period.channel == channel_id)
    purchases_in_pre_period = purchases_in_pre_period.where(purchases_in_pre_period.channel == channel_id)

    # For each product calculate number of customers that bought it in the trial period and not in the pre period
    distinct_product_customer_pairs_in_tgt_period = purchases_in_tgt_period.select('product', 'customer').distinct()

    product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period = distinct_product_customer_pairs_in_tgt_period.join(
        purchases_in_pre_period, (
            (distinct_product_customer_pairs_in_tgt_period.product == purchases_in_pre_period.product) & (
                distinct_product_customer_pairs_in_tgt_period.customer == purchases_in_pre_period.customer)),
        'left')

    product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period = product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period.filter(product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period.period.isNull())

    distinct_product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period = product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period.select(
        distinct_product_customer_pairs_in_tgt_period.product,
        distinct_product_customer_pairs_in_tgt_period.customer).distinct()

    count_of_customers_that_bought_the_product_only_in_trial_period = distinct_product_customer_pairs_in_tgt_period_that_didnt_exist_in_the_pre_period.groupby(
        'product').agg(count('customer').alias('hshd_count'))

    # With each product-store pair in tgt period associate count of customers that shopped in the store
    distinct_product_store_pairs_in_tgt_period = purchases_in_tgt_period.select('store', 'product').distinct()
    count_of_distinct_customers_that_shopped_in_a_store = purchases_in_tgt_period.groupby('store').agg(countDistinct('customer').alias('hshd_count'))

    # Roll up the customer counts to product level
    distinct_product_store_pairs_in_tgt_period_with_customer_counts = distinct_product_store_pairs_in_tgt_period.join(count_of_distinct_customers_that_shopped_in_a_store, 'store', 'inner')
    products_in_tgt_period_with_customer_counts = distinct_product_store_pairs_in_tgt_period_with_customer_counts.groupby('product').agg(sum('hshd_count').alias('households'))

    # Associate both the counts and derive trial_rate
    associated_counts = count_of_customers_that_bought_the_product_only_in_trial_period.join(products_in_tgt_period_with_customer_counts, 'product', "inner")
    associated_counts = associated_counts.withColumn('trial_rate',associated_counts['hshd_count']/associated_counts['households'])

    # Add product description
    tesco_uk_products_with_descriptions = sqlContext.table('{media_mart}.products'.format(media_mart=media_mart_database)).select('Product', 'ProductDescription').withColumnRenamed('Product','product')
    associated_counts_with_description = associated_counts.join(tesco_uk_products_with_descriptions, 'product', "inner")

    # Drop products with households lower than the minimum threshold
    associated_counts_with_description = associated_counts_with_description.where(associated_counts_with_description['households'] > min_hshd)

    # Rename, add and subset columns to comply with output schema
    associated_counts_with_description = associated_counts_with_description.withColumnRenamed('product', 'TPNB')
    associated_counts_with_description = associated_counts_with_description.withColumnRenamed('ProductDescription', 'TPNB_DESC')
    associated_counts_with_description = associated_counts_with_description.withColumnRenamed('trial_rate', 'TRIAL_RATE')
    associated_counts_with_description = associated_counts_with_description.withColumn( "run_date",lit(str(run_date)))
    associated_counts_with_description = associated_counts_with_description.select( 'TPNB', 'TPNB_DESC','TRIAL_RATE','run_date')

    # create table if not exists tuk_sseft.feat_prod_ps_trial_rate
    create_table_sttmt = """
    create table if not exists {write_database}.feat_prod_ps_trial_rate
    (
       TPNB string
     , TPNB_DESC string
     , TRIAL_RATE string
    )
    partitioned by
       (run_date string)  
    stored as
       parquet
    """.format(write_database=write_database)
    logger.info(create_table_sttmt)
    sqlContext.sql(create_table_sttmt)

    # Insert trial_rates into run_date partition
    logger.info('SET hive.exec.dynamic.partition = True')
    sqlContext.sql('SET hive.exec.dynamic.partition = True')
    logger.info('set hive.exec.dynamic.partition.mode=nonstrict')
    sqlContext.sql('set hive.exec.dynamic.partition.mode=nonstrict')
    # Drop partition if exists
    drop_partition_sttmt = "ALTER TABLE {write_database}.feat_prod_ps_trial_rate DROP IF EXISTS PARTITION(run_date='{run_date}')".format(write_database=write_database,run_date=str(run_date))
    logger.info(drop_partition_sttmt)
    sqlContext.sql(drop_partition_sttmt)
    associated_counts_with_description.write.mode("overwrite").format("parquet").insertInto("{write_database}.feat_prod_ps_trial_rate".format(write_database=write_database))

    # Drop and Re-Create current view of trial rates
    drop_view_sttmt = "drop view if exists {write_database}.feat_prod_ps_trial_rate_current".format(write_database=write_database)
    logger.info(drop_view_sttmt)
    sqlContext.sql(drop_view_sttmt)

    create_view_sttmt = """
    create view
       {write_database}.feat_prod_ps_trial_rate_current
    as select
       TPNB
     , TPNB_DESC
     , TRIAL_RATE
    from
       {write_database}.feat_prod_ps_trial_rate 
    where
        run_date = '{run_date}'
    """.format(write_database=write_database,run_date=run_date)
    logger.info(create_view_sttmt)
    sqlContext.sql(create_view_sttmt)
