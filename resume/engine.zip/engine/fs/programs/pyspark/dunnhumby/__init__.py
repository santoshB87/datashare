'''
init.py
'''
import logging
logger = logging.getLogger(__name__)

import cmp_entities
import cmp_features
import cmp_allocation
import dunnhumby.cmp_allocation.allocation

import dunnhumby.cmp_entities.base
import dunnhumby.cmp_entities.customers
import dunnhumby.cmp_entities.products
import dunnhumby.cmp_entities.stores
import dunnhumby.cmp_entities.dates
import dunnhumby.cmp_entities.transactions
import dunnhumby.cmp_entities.channels
import dunnhumby.cmp_features.purchasingfeaturegenerator
import dunnhumby.cmp_features.featureswriter
import dunnhumby.cmp_features.featuregeneratorbase
import dunnhumby.cmp_features.purchasingfeaturecoordinator
import dunnhumby.cmp_features.featurescoordinatorbase