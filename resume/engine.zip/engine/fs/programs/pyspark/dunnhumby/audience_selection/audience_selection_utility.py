import logging

logger = logging.getLogger(__name__)


def execute_query(pg_conn, db_name, query_type, query_stmt):
    """

    :param db_name:
    :param query_type:
    :param query_stmt:
    :return:
    """
    return_val = None
    cur = pg_conn.cursor()
    search_path = 'set search_path = "{db}"'.format(db=db_name)
    cur.execute(search_path)
    cur.execute(query_stmt)
    if query_type == "dml":
        return_val = cur.fetchall()
    pg_conn.commit()
    return return_val


def add_summary_stats(pg_conn, summarydata, queryinfo, cadence_week, stage=False):
    current_date, totalcustcount, totalprodcount, fcpdistinctprodcount, fcpdistinctcustcount = summarydata
    db_name, tab_name, mapping = queryinfo
    tab = tab_name + ("_staging" if stage else "")
    tab_header = "CREATE TABLE IF NOT EXISTS {db}.{tab}".format(db=db_name, tab=tab)
    tab_col_lst = ",".join([" ".join(filter(None, (item[1], item[2], item[3])))
                            for item in mapping[tab_name]])
    tab_create_ddl = tab_header + " (" + tab_col_lst + ")"
    logger.debug("Create statement for table %s - %s", tab_name, tab_create_ddl)
    execute_query(pg_conn, db_name=db_name, query_type="ddl", query_stmt=tab_create_ddl)
    insert_query = "insert into {db}.{table} values ('{current_date}', '{cadenceweek}', {totalcustcount}," \
                   " {totalprodcount}, {fcpdistinctprodcount}, {fcpdistinctcustcount})" \
        .format(db=db_name, table=tab_name, cadenceweek=cadence_week, current_date=current_date,
                totalcustcount=totalcustcount, totalprodcount=totalprodcount,
                fcpdistinctcustcount=fcpdistinctcustcount, fcpdistinctprodcount=fcpdistinctprodcount)
    logger.debug("Insert query for table %s - %s", tab_name, insert_query)
    execute_query(pg_conn, db_name=db_name, query_type="ddl",
                       query_stmt=insert_query)
    pg_conn.commit()
    return True