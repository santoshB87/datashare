'''
init.py
'''
__version__ = ''
__build__ = ''
__branch__ = ''
__projectid__ = ''
__projectname__ = ''
__projectnamespace__ = ''
__projecturl__ = ''
__builduserid__ = ''
__builduseremail__ = ''

import logging

# set up basic logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)
