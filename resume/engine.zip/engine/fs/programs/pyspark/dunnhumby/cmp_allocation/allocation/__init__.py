'''
"""Dunnhumby Personalisation Allocation Algorithms"""
'''
import logging
import sys

# Set default logging handler to avoid "No handler found" warnings.
try:  # Python 2.7+
    from logging import NullHandler
except ImportError:
    class NullHandler(logging.Handler):
        def emit(self, record):
            pass

logger = logging.getLogger(__name__)
logger.addHandler(NullHandler())

sys.path.append('tools-latest.egg')
