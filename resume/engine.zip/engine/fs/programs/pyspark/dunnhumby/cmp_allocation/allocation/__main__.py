import argparse
import datetime
import logging
import os
import sys
import traceback
import tools.configs as cfg
import notification as notify
import output_to_linux as linux_out
import prepare_unica as unica_prep
import submit_spark_drivers as submit
import util as util
from . import logger
from spark_submit import SparkApplicationError, SparkSubmitError

# pylint: disable=line-too-long
# pylint: disable=relative-import
def main(alg, config_file, metadata_only):
    '''
    # Load config file into Conf object
    :param alg:
    :param config_file:
    :param metadata_only:
    :return:
    '''

    if not os.path.exists(config_file):
        raise RuntimeError('Config file {0} not found'.format(config_file))
    if os.path.basename(config_file) != "config.json":
        raise RuntimeError('Config file must be named "config.json"!')
    conf = cfg.Config(logger=logger)
    conf.add_source_file(path=config_file)

    # Client config
    client_name = conf.get_item(keys='client_name', mandatory=True)
    client_short_name = conf.get_item(keys='ClientShortName', mandatory=True)

    # YARN\Spark configuration
    egg_files = conf.get_item(keys='egg_files', mandatory=True)
    jar_files = conf.get_item(keys='jar_files', mandatory=True)
    yarn_queue = conf.get_item(keys='yarn_queue', mandatory=True)
    executor_memory = conf.get_item(keys=(alg, 'executor_memory'), mandatory=False, default=None)
    driver_memory = conf.get_item(keys=(alg, 'driver_memory'), mandatory=False, default=None)

    # HDFS/WebHDFS details
    hdfs_output_path = conf.get_item(keys=(alg, 'hdfs_output_path'), mandatory=True)
    hdfs_name_nodes = conf.get_item(keys='hdfs_name_nodes', mandatory=True)
    webhdfs_root = conf.get_item(keys='webhdfs_root', mandatory=True)

    # timezone of timestamps for output files
    timezone = conf.get_item(keys=(alg, 'timezone'), mandatory=True)

    # event, variations and tranche configuration/metadata
    event_id = conf.get_item(keys=(alg, 'event', 'event_id'), mandatory=True)
    increment_event_ids = conf.get_item(keys=(alg, 'increment_event_ids'), mandatory=False, default=False)
    derive_event_dates = conf.get_item(keys=(alg, 'derive_event_dates'), mandatory=False, default=False)
    event_id_hdfs_path = conf.get_item(keys=(alg, 'event_id_hdfs_path'), mandatory=False, default=None)
    event_id_after_increment = None

    event = conf.get_item(keys=(alg, 'event'), mandatory=True)
    variation = conf.get_item(keys=(alg, 'variation'), mandatory=True)

    # final output configuration - whether we take controls and what files are sent where
    control_rules = conf.get_item(keys=(alg, 'control_rules'), mandatory=False, default=None)
    linux_outputs = conf.get_item(keys=(alg, 'linux_outputs'), mandatory=False, default=dict())
    send_to_unica_exadata = conf.get_item(keys=(alg, 'send_to_unica'), mandatory=False, default=dict())

    conf.error_on_mandatory_exceptions()

    # date time stamp in YYYYMMDDhhmmss format used to label all files generated during this allocation run
    allocation_start_dttm_datetime = util.get_time_zoned_dttm(timezone)
    allocation_start_dttm = allocation_start_dttm_datetime.strftime('%Y%m%d%H%M%S')

    # NameNodes may be in HA (active/standby) configuration - poke them until we find an active one and return the URL
    webhdfs_url = util.get_active_namenode_webhdfs_root(
        namenode_list=hdfs_name_nodes,
        webhdfs_root=webhdfs_root,
        logger=logger
    )

    # capture event_id hard coded in config - if we're incrementing the event IDs then the ID hard coded in config
    # is only used to label the directory we keep the event's control and target population files - incrementing this
    # ID will cause control and target populations to be regenerated during allocation
    control_event_id = event_id

    if increment_event_ids:

        # increment event_id and start and end dates, return as tuple and update lookup file on hdfs
        updated_event_id, event_start_date, event_end_date = submit.update_event_id(
            algorithm=alg,
            yarn_queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            config_file=conf.file_name,
            py_files=egg_files,
            jar_files=jar_files,
            derive_event_dates=derive_event_dates,
            event_id_hdfs_path=event_id_hdfs_path
        )

        # update event IDs and dates in event dict - update_event_id will return dates as datetime objects
        event_id_after_increment = updated_event_id
        # event['event_id'] = event_id
        # event['start_date'] = event_start_date
        # event['end_date'] = event_end_date

    else:
        # otherwise convert string dates from yyyy/mm/dd to yyyy-mm-ddThh:mm:ss datetime formats
        in_format = '%Y/%m/%d'
        out_format = '%Y/%m/%d'

        start_dt = datetime.datetime.strptime(event['start_date'], in_format)
        start_dttm = datetime.datetime(start_dt.year, start_dt.month, start_dt.day, 0, 0, 0)
        start_dttm_string = start_dttm.strftime(out_format)
        event['start_date'] = start_dttm_string

        end_dt = datetime.datetime.strptime(event['end_date'], in_format)
        end_dttm = datetime.datetime(end_dt.year, end_dt.month, end_dt.day, 23, 59, 59)
        end_dttm_string = end_dttm.strftime(out_format)
        event['end_date'] = end_dttm_string

    # get list of allocatable variations and raise error if we do not have one each of CONTROL and CHAMPION variations
    # also capture ID and weighting of control variations
    variation_list, control_variation_id, control_weight = get_variations(variation)

    # loop over each variations and spark submit the run_allocation spark driver for each, writing results to HDFS
    # all customers will be allocated to each allocatable variations at this stage, and no file will be created for
    # the control variation
    # allocated_variation_files will be dict with variations ID as key, path to results as value, ie:
    #  {
    #       1: "/hdfs/path/variation_1_result_file",
    #       2: "/hdfs/path/variation_2_result_file",
    #       ...,
    #       n: "/hdfs/path/variation_n_result_file"
    # }
    if not metadata_only:
        allocated_variation_files = submit.allocate_variations(
            client=client_name.lower(),
            variation_list=variation_list,
            algorithm=alg,
            event_id=event_id,
            dttm=allocation_start_dttm,
            hdfs_output_path=hdfs_output_path,
            yarn_queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            config_file=conf.file_name,
            py_files=egg_files,
            jar_files=jar_files,
        )

        logger.info("Allocated variation files: {0}".format(allocated_variation_files))

        if control_rules is not None:

            control_conf = cfg.Config(logger=logger)
            control_conf.add_dict(control_rules)
            control_hdfs_path = control_conf.get_item(keys='hdfs_path', mandatory=True)
            control_conf.error_on_mandatory_exceptions()

            # spark submit the update_control spark driver, adding any new customers identified in this allocation to
            # the event's static target, control and program control populations
            submit.update_control(
                algorithm=alg,
                dttm=allocation_start_dttm,
                allocated_files=allocated_variation_files,
                hdfs_output_path=hdfs_output_path,
                hdfs_control=control_hdfs_path,
                event_id=control_event_id,
                yarn_queue=yarn_queue,
                executor_memory=executor_memory,
                driver_memory=driver_memory,
                config_file=conf.file_name,
                py_files=egg_files,
                jar_files=jar_files,
            )

            # spark submit the send_control_files spark driver, creating a control variation file and allocating each
            # target customer to one of the allocated variations in accordance with the variations weights
            # send_files will be another dict, in the same format as allocated_variation_files, ie:
            #  {
            #       0: "/hdfs/path/variation_1_result_file.controlled",
            #       1: "/hdfs/path/variation_2_result_file.controlled",
            #       2: "/hdfs/path/variation_2_result_file.controlled",
            #       ...,
            #       n: "/hdfs/path/variation_n_result_file.controlled"
            # }
            send_files = submit.generate_send_files(
                algorithm=alg,
                dttm=allocation_start_dttm,
                allocated_files=allocated_variation_files,
                hdfs_output_path=hdfs_output_path,
                event_id=event_id,
                control_variation_id=control_variation_id,
                yarn_queue=yarn_queue,
                executor_memory=executor_memory,
                driver_memory=driver_memory,
                config_file=conf.file_name,
                py_files=egg_files,
                jar_files=jar_files
            )
        else:
            # if we do not maintain controls then just send all files output from allocate_variations step
            send_files = allocated_variation_files

    # loop over all the destinations we want to use SSH/webHDFS to transfer metadata and/or results to
    if(linux_outputs is not None):
        for output_name, output_dict in linux_outputs.items():

            logger.info('Outputting Allocation results to destination "{0}"'.format(output_name))

            # create a Config object just for the destination we're processing
            output_conf = cfg.Config(logger=logger)
            output_conf.add_dict(output_dict)

            host = output_conf.get_item(keys='host', mandatory=True)
            path = output_conf.get_item(keys='path', mandatory=True)
            buffer_path = output_conf.get_item(keys='buffer', mandatory=False, default=None)
            overall_dot_complete = output_conf.get_item(keys='overall_dot_complete', mandatory=False, default=False)
            dot_completes_with_stats = output_conf.get_item(keys='dot_completes_with_stats', mandatory=False, default=False)

            output_conf.error_on_mandatory_exceptions()

            metadata_file_types = ['event', 'variation', 'tranche']
            time_format = {'event': allocation_start_dttm_datetime.strftime('%d%b%Y:%H:%M:%S'), 'variation': allocation_start_dttm,
                    'tranche': allocation_start_dttm}
            for file_type in metadata_file_types:

                if output_conf.get_item(keys=file_type, default=None) is not None:

                    logger.info('Creating {0} metadata file'.format(file_type))

                    # retrieve config for format and destination of metadata file
                    file_columns = output_conf.get_item(keys=(file_type, 'columns'), mandatory=False, default=None)
                    nesting_level = output_conf.get_item(keys=(file_type, 'nesting_level'), mandatory=False, default=None)
                    headers = output_conf.get_item(keys=(file_type, 'headers'), mandatory=False, default=None)
                    gzipped = output_conf.get_item(keys=(file_type, 'gzipped'), mandatory=False, default=None)
                    dot_complete = output_conf.get_item(keys=(file_type, 'dot_complete'), mandatory=False, default=None)
                    filename_template = output_conf.get_item(keys=(file_type, 'filename_template'), mandatory=True)
                    date_format = output_conf.get_item(keys=(file_type, 'date_format'), mandatory=False, default=None)
                    output_conf.error_on_mandatory_exceptions()

                    # note - using conf, not output_conf, to retrieve actual data to write to metadata file
                    file_data = conf.get_item(keys=(alg, file_type))

                    # note - some clients want a single target variation ID, stored at event level, used in some file names
                    tgt_var = conf.get_item(keys=(alg, 'event', 'variation_id'), mandatory=False, default=None)

                    file_name = linux_out.derive_filename(
                        pattern=filename_template,
                        client=client_short_name,
                        algorithm=alg,
                        file_type=file_type,
                        event_id=event_id,
                        datetime_stamp=allocation_start_dttm,
                        variation_id=tgt_var,
                        n=None
                    )

                    logger.info('Derived filename "{0}"'.format(file_name))

                    # write metadata file on destination system through an SFTP connection
                    linux_out.output_metadata(
                        hostname=host,
                        remote_path=path,
                        remote_buffer=buffer_path,
                        file_name=file_name,
                        column_list=file_columns,
                        headers=headers,
                        data_dict=file_data,
                        data_dict_nesting_level=nesting_level,
                        timestamp=time_format[file_type],
                        event_id=event_id,
                        gzip_file=gzipped,
                        drop_dot_complete=dot_complete,
                        dot_complete_with_stats=dot_completes_with_stats,
                        date_format=date_format
                    )

            if not metadata_only and output_conf.get_item(keys='recommendations', default=None) is not None:

                dot_complete = output_conf.get_item(keys=('recommendations', 'dot_complete'))
                recommendations_filename_template = output_conf.get_item(keys=('recommendations', 'filename_template'))

                # spark submit a script to save the send files formatted as required by receiving systems (for example, RTE
                # requires allocation results to be formatted as gzipped CSV files, split into 200 smaller files)
                formatted_files = submit.format_output(
                    algorithm=alg,
                    send_files=send_files,
                    yarn_queue=yarn_queue,
                    executor_memory=executor_memory,
                    driver_memory=driver_memory,
                    config_file=conf.file_name,
                    py_files=egg_files,
                    jar_files=jar_files,
                    output_name=output_name
                )
                logger.info('Formatted send files: {0}'.format(formatted_files))

                # transfer recommendation to destination system by SSHing onto it and then pulling data down over webHDFS
                linux_out.transfer_results(
                    formatted_files,
                    webhdfs_root=webhdfs_url,
                    destination_hostname=host,
                    destination_path=path,
                    destination_buffer=buffer_path,
                    drop_dot_complete=dot_complete,
                    dot_complete_with_stats=dot_completes_with_stats,
                    algorithm=alg,
                    client=client_short_name,
                    dttm_stamp=allocation_start_dttm,
                    event_id=event_id,
                    filename_pattern=recommendations_filename_template
                )

            if overall_dot_complete:
                linux_out.drop_overall_dot_complete(
                    host=host[0],
                    path=path[0],
                    algorithm=alg,
                    timestamp=allocation_start_dttm,
                    stats=dot_completes_with_stats
                )

    if(send_to_unica_exadata):

        contact_control = conf.get_item(keys=(alg, 'contact_control'), mandatory=True)
        output_allocation_table = conf.get_item(keys=(alg, 'output_allocation_table'), mandatory=True)
        output_event_table = conf.get_item(keys=(alg, 'output_event_table'), mandatory=True)
        output_variation_table = conf.get_item(keys=(alg, 'output_variation_table'), mandatory=True)
        output_unica_url = conf.get_item(keys=(alg, 'output_unica_url'), mandatory=True)
        jdbc_properties = conf.get_item(keys=(alg, 'jdbc_properties'), mandatory=True)
        output_host = conf.get_item(keys=(alg, 'output_host'), mandatory=True)
        output_path = conf.get_item(keys=(alg, 'output_path'), mandatory=True)
        hdfs_namenodes = conf.get_item(keys = 'hdfs_name_nodes', mandatory=True)
        hdfs_url = conf.get_item(keys='hdfs_url', mandatory=True)
        sender=conf.get_item(keys=(alg, 'send_broken_links_report_by_email_properties', 'sender'),
                      mandatory=True)
        receiver=conf.get_item(keys=(alg, 'send_broken_links_report_by_email_properties', 'receiver'),
                      mandatory=True)
        subject=conf.get_item(keys=(alg, 'send_broken_links_report_by_email_properties', 'subject'),
                      mandatory=True)
        message=conf.get_item(keys=(alg, 'send_broken_links_report_by_email_properties', 'message'),
                      mandatory=True)
        attached_file=conf.get_item(keys=(alg, 'send_broken_links_report_by_email_properties', 'attached_file'),
                      mandatory=True)
        conf.error_on_mandatory_exceptions()

        
        # drop and create tables in Oracle
        unica_prep.prepare_exadata_table(
            connection=''.join(
                ['/'.join([jdbc_properties['user'], jdbc_properties['password']]), output_unica_url]),
            allocation_table=output_allocation_table,
            event_table=output_event_table,
            variation_table=output_variation_table
        )


        formatted_files = submit.format_output(
            algorithm=alg,
            send_files=send_files,
            yarn_queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            config_file=conf.file_name,
            py_files=egg_files,
            jar_files=jar_files,
            output_name=None
        )

        # generate the dot complete files
        unica_prep.unica_dot_complete(
            algorithm=alg,
            hostname=output_host,
            output_path=output_path,
            variation_dict=variation,
            contact_control=contact_control,
            event_id=event_id_after_increment if event_id_after_increment else event_id,
            dttm=allocation_start_dttm
        )

        # Send Broken Link Report by email
        notify.send_csv_via_mail(
            sender=sender,
            receiver=receiver,
            email_attach_file_path=attached_file,
            subject=subject,
            message=message,
            hdfs_namenodes=hdfs_namenodes,
            hdfs_url=hdfs_url
         )


def get_args(argv):
    """Parse command line arguments passed to allocation application"""
    parser = argparse.ArgumentParser(description='Personalisation Allocation', prog='allocation')
    parser.add_argument('--algorithm',
                        required=True,
                        help='Personalisation algorithm to execute')
    parser.add_argument('--client-name',
                        default="Unknown",
                        help='Client name - used in status notifications')
    parser.add_argument('--chat-url',
                        default=None,
                        help='Chat Server Webhook URL to post status notifications to')
    parser.add_argument('--config-file',
                        default='config.json',
                        help='Config file to run against (file basename must be "config.json" - only change path')
    parser.add_argument('--log-file',
                        default=None,
                        help='File to log results to (if unspecified will write to stderr)')
    parser.add_argument('--verbose',
                        action='store_true',
                        default=False,
                        help='Print additional debug info')
    parser.add_argument('--metadata-only',
                        action='store_true',
                        default=False,
                        help='Output metadata only, not recommendations')
    return parser.parse_args(argv)


def configure_logger(log_file, verbose):
    """Add file or stream handler to package logger and set message level"""
    if log_file:
        log_handler = logging.FileHandler(filename=log_file)
    else:
        log_handler = logging.StreamHandler()
    log_format = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
    log_handler.setFormatter(log_format)
    logger.addHandler(log_handler)
    if verbose:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)


def get_variations(variation_dict):
    """Return a list of each non-control variation's ID and description, and count the CONTROL and CHAMPION variations.
    Args:
        variation_dict: Dict containing the "variation" key from the algorithm's config file
    Returns:
        List of Tuples: [(var1_id, var1_description), (var2_id, var2_description), ...]
        ID of Control variation
        Weighting of Control variation
    """
    control_count = 0
    champion_count = 0
    challenger_count = 0
    allocatable_variations = list()
    control_variation_id = None
    control_weight = None

    logger.info('Event Variations found in config file:')
    for variation_id in sorted([variation_id for variation_id in variation_dict.keys() if variation_id.isdecimal()]):
        variation_description = variation_dict[variation_id]['variation_description']
        variation_type = variation_dict[variation_id]['variation_type']
        variation_weight = variation_dict[variation_id]['weighting']
        do_not_allocate = variation_dict[variation_id].get('do_not_allocate', 'false') == 'true'
        logger.info('    ID: {0}, Type {1}, Description: {2}'.
                    format(variation_id, variation_type, variation_description))
        if variation_type == "CONTROL":
            control_variation_id = variation_id
            control_weight = variation_weight
            control_count += 1
        else:
            if not do_not_allocate:
                allocatable_variations.append((variation_id, variation_description))
            if variation_type == "CHAMPION":
                champion_count += 1
            elif variation_type == "CHALLENGER":
                challenger_count += 1
    if control_count != 1:
        raise RuntimeError('A single variation of type "CONTROL" is required - found {0}'.format(control_count))
    if champion_count != 1:
        raise RuntimeError('A single variation of type "CHAMPION" is required - found {0}'.format(champion_count))
    return allocatable_variations, control_variation_id, control_weight

if __name__ == '__main__':
    args = None
    err = None
    err_str = None
    tracking_url = None
    status = "Unknown"
    start_time = datetime.datetime.today()

    try:
        args = get_args(argv=sys.argv[1:])
        configure_logger(args.log_file, args.verbose)
        main(alg=args.algorithm, config_file=args.config_file, metadata_only=args.metadata_only)
        status = 'Complete'
    except SparkApplicationError as err:
        status = 'Failed'
        tracking_url = err.application_url
        err_str = err.error
    except SparkSubmitError as err:
        status = 'Failed'
        tracking_url = None
        err_str = err.message
    except Exception as err:  # sokay, we're re-raising below, just want to nab the traceback for chat message
        status = 'Failed'
        tracking_url = None
        _, _, ex_traceback = sys.exc_info()
        tb_lines = traceback.format_exception(err.__class__, err, ex_traceback)
        err_str = "\n".join(tb_lines)
    finally:
        end_time = datetime.datetime.today()
        try:
            algorithm = args.algorithm
        except (NameError, AttributeError):
            algorithm = "Unknown"
        try:
            client_name = args.client_name
        except (NameError, AttributeError):
            client_name = "Unknown"
        try:
            chat_url = args.chat_url
        except (NameError, AttributeError):
            chat_url = None

        if chat_url:
            notify.post_status_to_chat(
                algorithm=algorithm,
                client_name=client_name,
                status=status,
                error_message=err_str,
                tracking_url=tracking_url,
                webhook_url=chat_url,
                start_time=start_time,
                end_time=end_time
            )
        if err:
            try:
                print err
            except:
                raise
