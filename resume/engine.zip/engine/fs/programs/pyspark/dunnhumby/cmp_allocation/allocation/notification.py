import json
import logging
import os
import smtplib
import tools.requests as requests
import util as util
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from os.path import basename
from tools.hdfs.ext.kerberos import KerberosClient

logger = logging.getLogger(__name__)

# pylint: disable=line-too-long
# pylint: disable=bad-continuation
# pylint: disable=too-many-arguments
# pylint: disable=too-many-locals
# pylint: disable=logging-format-interpolation

def send_csv_via_mail(sender,
                      receiver,
                      email_attach_file_path,
                      subject,
                      message,
                      hdfs_namenodes=None,
                      hdfs_url=None):
    '''

    :param sender:
    :param receiver:
    :param email_attach_file_path:
    :param subject:
    :param message:
    :param hdfs_namenodes:
    :param hdfs_url:
    :return:
    '''

    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(receiver)

    # Create the body of the message (a plain-text and an HTML version).
    text = message  ##"Please find attached the latest product report.\nfrom dunnhumby"

    # Attach parts into message container.
    # According to RFC 2046, the last part of a multipart message, in this case
    # the HTML message, is best and preferred.
    msg.attach(MIMEText(text))

    if not hdfs_namenodes and not hdfs_url:
        if not email_attach_file_path:
            raise RuntimeError("Must specify the file full path ")

        logger.info('Attach file {0} to the email'.format(email_attach_file_path))
        for f in email_attach_file_path or []:
            with open(f, "rb") as fil:
                part = MIMEApplication(
                    fil.read(),
                    Name=basename(f)
                )
                part['Content-Disposition'] = 'attachment; filename="%s"' % basename(f)
                msg.attach(part)
    else:
        hdfs_active_url = util.get_active_namenode_webhdfs_root(namenode_list=hdfs_namenodes,
                                                                webhdfs_root=os.path.join(hdfs_url, 'webhdfs/v1'),
                                                                logger=logger
                                                                )
        logger.info('Attach file {0} to the email'.format(email_attach_file_path))
        client = KerberosClient(hdfs_active_url.replace('webhdfs/v1', ''))
        with client.read(email_attach_file_path) as reader:
            part = MIMEApplication(
                reader.read(),
                Name='Broken_link_report.csv'
            )
            part['Content-Disposition'] = 'attachment; filename="%s"' % 'Broken_link_report.csv'
            msg.attach(part)

    # Send the message via local SMTP server.
    s = smtplib.SMTP('localhost')
    # sendmail function takes 3 arguments: sender's address, recipient's address
    # and message to send - here it is sent as one string.
    s.sendmail(sender, receiver, msg.as_string())
    s.quit()


def post_status_to_chat(
        client_name,
        algorithm,
        status,
        webhook_url,
        start_time,
        end_time,
        error_message=None,
        tracking_url=None,
        username='SSE Allocation',
        gitlab_url='https://dhgitlab.dunnhumby.co.uk/sse/allocation',
        icon_url='https://lh6.ggpht.com/4-qiKOOWpQtl_iyvoc8acHGuWu1OxO8G2-vS2Vi2FN9TQXcrtRhEzfdRMQYY7-JAsQ=w300',
        ):
    '''

    :param client_name:
    :param algorithm:
    :param status:
    :param webhook_url:
    :param start_time:
    :param end_time:
    :param error_message:
    :param tracking_url:
    :param username:
    :param gitlab_url:
    :param icon_url:
    :return:
    '''

    green = '#008000'
    red = '#FF0000'

    if status.lower() == 'complete':
        color = green
    elif status.lower() == 'failed':
        color = red
    else:
        raise RuntimeError('Status of {0} not recognised'.format(status))

    title = "{market} {algorithm} Allocation: {status}".format(
        market=client_name,
        algorithm=algorithm.upper(),
        status=status.title())
    if tracking_url:
        title_link = tracking_url
    else:
        title_link = ""

    duration_delta = end_time - start_time
    duration_fmt = "{days} days {hours}h:{minutes}m:{seconds}s"
    d = {"days": duration_delta.days}
    d["hours"], rem = divmod(duration_delta.seconds, 3600)
    d["minutes"], d["seconds"] = divmod(rem, 60)
    duration_str = duration_fmt.format(**d)

    payload = {
        'username': username,
        'icon_url': icon_url,
        "attachments": [
            {
                "fallback": title,
                "color": color,
                "author_name": "SSE Allocation",
                "author_icon": "https://gitlab.com/gitlab-com/gitlab-artwork/raw/master/logo/logo.png",
                "author_link": gitlab_url,
                "title": title,
                "title_link": title_link,
                "fields": [
                    {
                        "short": True,
                        "title": "Start Time",
                        "value": start_time.strftime('%H:%M:%S, %e %b %Y')
                    },
                    {
                        "short": True,
                        "title": "End Time",
                        "value": end_time.strftime('%H:%M:%S, %e %b %Y')
                    },
                    {
                        "short": True,
                        "title": "Duration",
                        "value": duration_str
                    }
                ]
            }
        ]
    }

    if error_message:
        msg = "Error Message:\n{0}\n".format(error_message)
        payload['attachments'][0]['text'] = msg

    response = requests.post(
        url=webhook_url,
        data=json.dumps(payload),
        allow_redirects=False
        )

    logger.debug('chat server response:\n{0}\n{1}'.format(response.status_code, response.text))
