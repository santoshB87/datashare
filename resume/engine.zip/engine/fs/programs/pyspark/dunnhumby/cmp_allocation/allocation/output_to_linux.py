import csv
import datetime
import getpass
import json
import logging
import os
import re
from gzip import GzipFile
import ssh_client as ssh
import util as util

# pylint: disable=line-too-long
# pylint: disable=too-many-arguments
# pylint: disable=too-many-locals
# pylint: disable=logging-format-interpolation

logger = logging.getLogger(__name__)
username = getpass.getuser()
private_key_file = os.path.expanduser('~/.ssh/id_rsa')


def transfer_results(
        send_files,
        webhdfs_root,
        destination_hostname,
        destination_path,
        destination_buffer,
        filename_pattern,
        algorithm,
        client,
        event_id,
        dttm_stamp,
        drop_dot_complete,
        dot_complete_with_stats
):
    '''

    :param send_files:
    :param webhdfs_root:
    :param destination_hostname:
    :param destination_path:
    :param destination_buffer:
    :param filename_pattern:
    :param algorithm:
    :param client:
    :param event_id:
    :param dttm_stamp:
    :param drop_dot_complete:
    :param dot_complete_with_stats:
    :return:
    '''
    """Command to trigger the transfer of files from HDFS to a remote location.  Files will be written to the
    destination, named using a provided filename patter.  For example, if we have

    - webhdfs_root/usuals_5_1_201601010101.fmtted/
        - part-00001
        - part-00002
        - part-00003
        - part-00004

    and a filename pattern:

        "usuals_{evt}_{var}_{dttm}{n}.csv"

    on hdfs, we will then create - note {n} includes the underscore, so if we want to we can set it to "" without
    leaving a trailing underscore in the filename:

    - remote_path/
        -  usuals_5_1_201601010101_00001.csv
        -  usuals_5_1_201601010101_00002.csv
        -  usuals_5_1_201601010101_00003.csv
        -  usuals_5_1_201601010101_00004.csv

    on the remote host.  If remote_buffer is specified we will first write to this directory and then move the files to
    remote_path, otherwise we will write directly to remote_path

    if we detect that there is only a single part file, eg:

    - webhdfs_root/usuals_5_1_201601010101.fmtted/ - part-00000.gz

    we will set {n} to an empty string, creating:

    - remote_path/usuals_5_1_201601010101.csv.gz

    We will also conditionally (if output_dot_complete = True) drop files

        -  usuals_5_1_201601010101_00001.csv.gz.complete
        -  usuals_5_1_201601010101_00002.csv.gz.complete
        -  usuals_5_1_201601010101_00003.csv.gz.complete
        -  usuals_5_1_201601010101_00004.csv.gz.complete

    once each file is transferred (and moved if we're using destination_buffer)

    Args:
        send_files: dict of files to transfer (ie {"1": "/tmp/allocation/usuals_5_1_20160930212004.csv"})
        webhdfs_root: url path to webhdfs service (ie "http://gb-slo-svb-0018.dunnhumby.co.uk:50070/webhdfs/v1")
        destination_hostname: the host of the server to connected to
        destination_path: path where HDFS files needs to be transfer to (the remote server path)
        destination_buffer: if not None, files will be transferred here and then moved to destination_path
        filename_pattern:
        algorithm:
        client:
        event_id:
        dttm_stamp:
        drop_dot_complete: Boolean - if true also drop a .complete file for each data file transferred
        dot_complete_with_stats: Boolean - if true write file name, number of rows and size in bytes into complete file
    """

    # note, on HDFS each file is actually a folder containing multiple files
    for variation_id, folder_name in send_files.items():

        # concatenate folder path and webhdfs root to get full webhdfs path, ie:
        # http://gb-slo-svb-0018.dunnhumby.co.uk:50070/webhdfs/v1/tmp/allocation/usuals_5_2_20161003222612.fmtted
        webhdfs_folder = webhdfs_root + folder_name

        # call webhdfs LISTSTATUS from the destination over ssh to get a list of the part-files in this hdfs path
        logger.info("Creating a list of the individual hdfs files to be transferred at {0}".format(webhdfs_folder))
        webhdfs_list_cmd = 'curl --negotiate -u : ' + os.path.join(webhdfs_folder, '?op=LISTSTATUS')
        logger.debug('webhdfs list command: {0}'.format(webhdfs_list_cmd))

        for ssh_destination in range(0, len(destination_hostname)):

            ssh_client = ssh.get_ssh_client(hostname=destination_hostname[ssh_destination], username=username,
                                            key_filename=private_key_file)
            util.get_kerberos_ticket(ssh_client)

            stdin, stdout, stderr = ssh_client.exec_command(webhdfs_list_cmd)
            stdin.close()
            webhdfs_list_sddout = stdout.read()
            logger.debug('webhdfs list stdout: {0}'.format(webhdfs_list_sddout))

            if "<title>Error 404 NOT_FOUND</title>" in webhdfs_list_sddout:
                raise RuntimeError('WebHDFS file "{0}" not found'.format(webhdfs_folder))
            elif "<title>Error 401 Authentication required</title>" in webhdfs_list_sddout:
                raise RuntimeError("WebHDFS authentication failed - check Kerberos ticket cache on {0}"
                                   .format(destination_hostname))
            try:
                hdfs_inventory = json.loads(webhdfs_list_sddout)
            except ValueError:
                raise RuntimeError("Response from call to WebHDFS cannot be parsed as json: {0}"
                                   .format(webhdfs_list_sddout))

            hdfs_filename_list = [i_line['pathSuffix'] for i_line in hdfs_inventory['FileStatuses']['FileStatus'] if
                                  not i_line['pathSuffix'].startswith('_') and i_line['type'].upper() == "FILE"]

            number_of_files = len(hdfs_filename_list)
            logger.info("{0} part file{1} to transfer".format(number_of_files, "s" if number_of_files > 1 else ""))

            if destination_buffer:
                write_path = destination_buffer
            else:
                write_path = destination_path[ssh_destination]

            if ssh_client.open_sftp().stat(write_path):
                logger.info("Remote location {0} exists, transfer will proceed".format(write_path))

                if not os.path.basename(webhdfs_folder):
                    raise RuntimeError("The {0} should not end in '/' ".format(webhdfs_folder))

                logger.info("Transferring the files from {0} to remote server {1}".format(webhdfs_folder, write_path))

                for hdfs_file_name in hdfs_filename_list:

                    # hdfs file names expected to be in form part-00001 or part-00001.gz if zipped
                    split_file_name = re.split('[-.]', hdfs_file_name)
                    file_number = split_file_name[1]

                    # check if we need to append .gz to filename
                    if len(split_file_name) > 2:
                        ext = '.' + split_file_name[2]
                    else:
                        ext = ''

                    if number_of_files == 1:
                        n = ""
                    else:
                        n = "_{0}".format(file_number)

                    output_file_name = derive_filename(
                        algorithm=algorithm,
                        client=client,
                        datetime_stamp=dttm_stamp,
                        event_id=event_id,
                        variation_id=variation_id,
                        file_type=None,
                        pattern=filename_pattern,
                        n=n
                    ) + ext
                    abs_output_file_name = os.path.join(write_path, output_file_name)
                    logger.info('Downloading {0} as {1}'.format(hdfs_file_name, abs_output_file_name))

                    std_in, std_out, std_err = ssh_client.exec_command(
                        'curl  -L  --negotiate -u : {0} -o {1}'.format(
                            os.path.join(webhdfs_folder, hdfs_file_name, '?op=OPEN'),
                            abs_output_file_name
                        )
                    )
                    std_out.readlines()

                    if destination_buffer:
                        move_path = os.path.join(destination_path, output_file_name)
                        ssh.move_file(ssh_client=ssh_client, filename=abs_output_file_name, destination=move_path)

                    if drop_dot_complete:
                        dot_complete_filename = os.path.join(destination_path[ssh_destination], output_file_name)
                        logger.info('Writing .complete file for "{0}"'.format(output_file_name))
                        ssh.create_complete_file(
                            ssh_client=ssh_client, path=dot_complete_filename, stats=dot_complete_with_stats)
            else:
                raise IOError("Location {0} does not exist".format(write_path))

        ssh_client.close()


def output_metadata(
        hostname,
        remote_path,
        remote_buffer,
        file_name,
        column_list,
        headers,
        data_dict,
        data_dict_nesting_level,
        timestamp,
        event_id,
        gzip_file,
        drop_dot_complete,
        dot_complete_with_stats,
        date_format
):
    '''

    :param hostname:
    :param remote_path:
    :param remote_buffer:
    :param file_name:
    :param column_list:
    :param headers:
    :param data_dict:
    :param data_dict_nesting_level:
    :param timestamp:
    :param event_id:
    :param gzip_file:
    :param drop_dot_complete:
    :param dot_complete_with_stats:
    :param date_format:
    :return:
    '''
    """Write a metadata file over an sftp connection"""

    rows = list()  # list of dicts to write to CSV with csv.DictWriter

    # if nesting level = 0 we expect a dict of columns, creating a single row output CSV
    if data_dict_nesting_level == 0:
        data_dict['event_id'] = event_id  # add event ID to dict - some clients want it in metadata other than event
        data_dict['algorithm_run_dttm'] = timestamp  # add timestamp - some clients want run dttm in metadata
        rows.append(_prepare_row(data_dict, column_list, date_format))
    # if nesting level = 1 we expect a dict with dicts nested within it, one for each row of output CSV
    elif data_dict_nesting_level == 1:
        for d in data_dict.values():
            d['algorithm_run_dttm'] = timestamp
            d['event_id'] = event_id
            rows.append(_prepare_row(d, column_list, date_format))

    logger.debug('data dict for {0}:\n{1}'.format(file_name, data_dict))
    logger.debug('rows object {0}'.format(rows))

    # decide if we want file to have a .gz suffix
    if gzip_file:
        file_name += '.gz'

    for ssh_destination in range(0, len(hostname)):

        ssh_client = ssh.get_ssh_client(hostname=hostname[ssh_destination], username=username,
                                        key_filename=private_key_file)
        # decide if we're writing directly to remote_path or to a temporary buffer before moving it later
        if remote_buffer:
            write_directory = remote_buffer
        else:
            write_directory = remote_path[ssh_destination]
        write_path = os.path.join(write_directory, file_name)

        _write_metadata_file(
            ssh_client=ssh_client,
            gzip_file=gzip_file,
            file_name=write_path,
            data=rows,
            columns=column_list,
            headers=headers
        )

        if remote_buffer:
            final_path = os.path.join(remote_path, file_name)
            ssh.move_file(ssh_client=ssh_client, filename=write_path, destination=final_path)
        else:
            final_path = write_path

        if drop_dot_complete:
            ssh.create_complete_file(ssh_client=ssh_client, path=final_path, stats=dot_complete_with_stats)


def derive_filename(pattern, client, file_type, algorithm, event_id, variation_id, datetime_stamp, n):
    '''

    :param pattern:
    :param client:
    :param file_type:
    :param algorithm:
    :param event_id:
    :param variation_id:
    :param datetime_stamp:
    :param n:
    :return:
    '''
    subs_dict = dict()
    if '{client}' in pattern:
        subs_dict['client'] = client
    if '{type}' in pattern:
        subs_dict['type'] = file_type
    if '{alg}' in pattern:
        subs_dict['alg'] = algorithm
    if '{evt}' in pattern:
        subs_dict['evt'] = event_id
    if '{var}' in pattern:
        subs_dict['var'] = variation_id
    if '{dttm}' in pattern:
        subs_dict['dttm'] = datetime_stamp
    if '{n}' in pattern:
        subs_dict['n'] = n
    return pattern.format(**subs_dict)


def drop_overall_dot_complete(host, path, algorithm, timestamp, stats):
    '''

    :param host:
    :param path:
    :param algorithm:
    :param timestamp:
    :param stats:
    :return:
    '''
    file_name = "_".join([algorithm, timestamp])
    full_path = os.path.join(path, file_name)
    ssh_client = ssh.get_ssh_client(hostname=host, username=username, key_filename=private_key_file)
    ssh.create_complete_file(ssh_client=ssh_client, path=full_path, stats=stats)


def _write_metadata_file(ssh_client, gzip_file, file_name, data, columns, headers):
    '''

    :param ssh_client:
    :param gzip_file:
    :param file_name:
    :param data:
    :param columns:
    :param headers:
    :return:
    '''
    """Write a dict of dicts to CSV over a paramiko.SSHClient connection

    ssh_client: paramiko SSHClient object connected to destination server
    file_name: fully qualified name of CSV to create
    data: List of Dicts to be written through a csv.DictWriter
    columns: List of columns to be written to the CSV
    """
    logger.debug("_write_metadata_file - filename: {0}, data {1}".format(file_name, data))
    with _get_filehandle(ssh_client, file_name, gzip_file) as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        if headers:
            writer.writeheader()
        for row in data:
            writer.writerow(row)
    logger.info('Writing metadata file "{0}"'.format(file_name))


def _get_filehandle(ssh_client, filename, gzip_file):
    '''

    :param ssh_client:
    :param filename:
    :param gzip_file:
    :return:
    '''
    logger.debug("_get_filehandle filename:" + str(filename))
    sftp_client = ssh.get_sftp_client(ssh_client)
    handle = sftp_client.open(filename=filename, mode='w')
    if gzip_file:
        handle = GzipFile(fileobj=handle, mode='w')
    return handle


def _prepare_row(in_dict, keys, date_format):
    '''

    :param in_dict:
    :param keys:
    :param date_format:
    :return:
    '''
    """Remove all keys in in_dict that do not appear in keys, string format any dates and return resulting Dict"""
    d = dict()
    for key, value in in_dict.items():
        if key in keys:
            if isinstance(value, datetime.datetime):
                formatted_value = value.strftime(date_format)
            else:
                formatted_value = str(value)
            d[key] = formatted_value
    return d


def transfer_results_without_filename_change(folder_name,
        webhdfs_root,
        destination_hostname,
        destination_path
):
    """

    :param send_files:
    :param webhdfs_root:
    :param destination_hostname:
    :param destination_path:
    :return:
    """
    """Command to trigger the transfer of files from HDFS to a remote location.  Files will be written to the
    destination, 

    once each file is transferred (and moved if we're using destination_buffer)

    Args:
        send_files: dict of files to transfer (ie {"1": "/tmp/allocation/usuals_5_1_20160930212004.csv"})
        webhdfs_root: url path to webhdfs service (ie "http://gb-slo-svb-0018.dunnhumby.co.uk:50070/webhdfs/v1")
        destination_hostname: the host of the server to connected to
        destination_path: path where HDFS files needs to be transfer to (the remote server path)
    """



    # concatenate folder path and webhdfs root to get full webhdfs path, ie:
    # http://gb-slo-svb-0018.dunnhumby.co.uk:50070/webhdfs/v1/tmp/allocation/usuals_5_2_20161003222612.fmtted
    webhdfs_folder = webhdfs_root + folder_name

    # call webhdfs LISTSTATUS from the destination over ssh to get a list of the part-files in this hdfs path
    logger.info("Creating a list of the individual hdfs files to be transferred at {0}".format(webhdfs_folder))
    webhdfs_list_cmd = 'curl --negotiate -u : ' + os.path.join(webhdfs_folder, '?op=LISTSTATUS')
    logger.debug('webhdfs list command: {0}'.format(webhdfs_list_cmd))

    for ssh_destination in range(0, len(destination_hostname)):

        ssh_client = ssh.get_ssh_client(hostname=destination_hostname[ssh_destination], username=username,
                                        key_filename=private_key_file)
        util.get_kerberos_ticket(ssh_client)

        stdin, stdout, stderr = ssh_client.exec_command(webhdfs_list_cmd)
        stdin.close()
        webhdfs_list_sddout = stdout.read()
        logger.debug('webhdfs list stdout: {0}'.format(webhdfs_list_sddout))

        if "<title>Error 404 NOT_FOUND</title>" in webhdfs_list_sddout:
            raise RuntimeError('WebHDFS file "{0}" not found'.format(webhdfs_folder))
        elif "<title>Error 401 Authentication required</title>" in webhdfs_list_sddout:
            raise RuntimeError("WebHDFS authentication failed - check Kerberos ticket cache on {0}"
                               .format(destination_hostname[ssh_destination]))
        try:
            hdfs_inventory = json.loads(webhdfs_list_sddout)
        except ValueError:
            raise RuntimeError("Response from call to WebHDFS cannot be parsed as json: {0}"
                               .format(webhdfs_list_sddout))

        hdfs_filename_list = [i_line['pathSuffix'] for i_line in hdfs_inventory['FileStatuses']['FileStatus'] if
                              not i_line['pathSuffix'].startswith('_') and i_line['type'].upper() == "FILE"]

        number_of_files = len(hdfs_filename_list)
        logger.info("{0} part file{1} to transfer".format(number_of_files, "s" if number_of_files > 1 else ""))

        write_path = destination_path[ssh_destination]

        if ssh_client.open_sftp().stat(write_path):
            logger.info("Remote location {0} exists, transfer will proceed".format(write_path))

            if not os.path.basename(webhdfs_folder):
                raise RuntimeError("The {0} should not end in '/' ".format(webhdfs_folder))

            logger.info("Transferring the files from {0} to remote server {1}".format(webhdfs_folder, write_path))

            for hdfs_file_name in hdfs_filename_list:

                output_file_name = hdfs_file_name

                abs_output_file_name = os.path.join(write_path, output_file_name)
                logger.info('Downloading {0} as {1}'.format(hdfs_file_name, abs_output_file_name))

                std_in, std_out, std_err = ssh_client.exec_command(
                    'curl  -L  --negotiate -u : {0} -o {1}'.format(
                        os.path.join(webhdfs_folder, hdfs_file_name, '?op=OPEN'),
                        abs_output_file_name
                    )
                )
                std_out.readlines()
        else:
            raise IOError("Location {0} does not exist".format(write_path))

        ssh_client.close()

