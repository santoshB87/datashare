import getpass
import logging
import os
from datetime import datetime
import ssh_client as ssh
import util as util
# from cx_Oracle import DatabaseError

logger = logging.getLogger(__name__)

# pylint: disable=line-too-long
# pylint: disable=superfluous-parens
# pylint: disable=logging-format-interpolation

def unica_dot_complete(algorithm,
                       hostname,
                       output_path,
                       variation_dict,
                       contact_control,
                       event_id,
                       dttm):
    '''

    :param algorithm:
    :param hostname:
    :param output_path:
    :param variation_dict:
    :param contact_control:
    :param event_id:
    :param dttm:
    :return:
    '''
    logger.info('Writing .complete to {0}:{1}'.format(hostname, output_path))

    day_of_week = datetime.strptime(dttm, '%Y%m%d%H%M%S').strftime('%a')
    datestamp = datetime.strptime(dttm, '%Y%m%d%H%M%S').strftime('%y%m%d%H%M%S')

    username = getpass.getuser()
    private_key_file = os.path.expanduser('~/.ssh/id_rsa')
    ssh_client = ssh.get_ssh_client(hostname=hostname, username=username, key_filename=private_key_file)
    sftp_client = ssh.get_sftp_client(ssh_client=ssh_client)

    if contact_control:
        variation_list = sorted(
            [variation_id for variation_id in variation_dict.keys() if variation_id.isdecimal()])
    else:
        variation_list = sorted(
            [variation_id for variation_id in variation_dict.keys() if variation_id.isdecimal() and variation_id != 0])

    for variation in variation_list:
        variation_id = int(variation) + 1
        file_prefix = '_'.join([algorithm, str(event_id), str(variation_id), datestamp, day_of_week]).lower()
        dot_complete_full_filename = os.path.join(output_path, file_prefix)
        print(dot_complete_full_filename)
        ssh.create_complete_file(ssh_client=ssh_client, path=dot_complete_full_filename, suffix='.complete')

    for file_type in ['event', 'variation']:
        file_prefix = '_'.join([file_type, algorithm, datestamp])
        dot_complete_full_filename = os.path.join(output_path, file_prefix)
        print(dot_complete_full_filename)
        ssh.create_complete_file(ssh_client=ssh_client, path=dot_complete_full_filename, suffix='.csv.complete')


def prepare_exadata_table(connection, allocation_table, event_table, variation_table):
    '''

    :param connection:
    :param allocation_table:
    :param event_table:
    :param variation_table:
    :return:
    '''
    _drop_create_exadata_table(
        connection=connection,
        exadeta_table=allocation_table,
        create_sql_statement="CREATE TABLE {}("
                             "EVENT_ID NUMBER   (8),"
                             "VARIATION_ID NUMBER   (8),"
                             "DOTCOM_CUSTOMER_ID VARCHAR2 (20  CHAR),"
                             "OFFER_POSITION  NUMBER   (8),"
                             "AW_FAV_PRODUCT_IMAGE VARCHAR2 (50  CHAR),"
                             "FAV_PRODUCT_IMAGE VARCHAR2 (200 CHAR),"
                             "OFFER_URL VARCHAR2 (9   CHAR),"
                             "AW_FAV_PRODUCT_DESCRIPTION VARCHAR2 (50  CHAR),"
                             "FAV_PRODUCT_DESCRIPTION VARCHAR2 (200 CHAR),"
                             "TPNB  NUMBER   (8),"
                             "RELEVANCY_SCORE NUMBER   (15,9),"
                             "LOAD_DATE_YMD  NUMBER   (8))"
                             "PARTITION BY LIST (VARIATION_ID)"
                             "(PARTITION VARIATION_ID_1 VALUES(1),"
                             "PARTITION VARIATION_ID_2 VALUES(2),"
                             "PARTITION VARIATION_ID_3 VALUES(3))".format(allocation_table))

    _drop_create_exadata_table(
        connection=connection,
        exadeta_table=event_table,
        create_sql_statement='CREATE TABLE {0}('
                             'EVENT_ID NUMBER(8),'
                             'SERVICE_ID NUMBER(8),'
                             'VARIATION_COUNT NUMBER(8),'
                             'LAST_ALLOCATED_VARIATION NUMBER(8),'
                             'RANDOMIZED NUMBER(8),'
                             'ACTIVE NUMBER(8),'
                             'START_DATE DATE,'
                             'END_DATE DATE,'
                             'CONTROL_GROUP NUMBER(8),'
                             'SERVICE_DESCRIPTION VARCHAR2(30 CHAR),'
                             'SERVICE_PREFIX_CODE  VARCHAR2(8 CHAR),'
                             'SERVICE_LVL_CONT_PCT NUMBER(8),'
                             'PROGRAM_LVL_CONT_HH_DIGITS NUMBER(8))'.format(event_table))

    _drop_create_exadata_table(
        connection=connection,
        exadeta_table=variation_table,
        create_sql_statement="create table {0}("
                             "event_id NUMBER(8),"
                             "service_id NUMBER(8),"
                             "variation_id NUMBER(8),"
                             "variation_description VARCHAR2(30 CHAR))".format(variation_table))


def _drop_create_exadata_table(connection,
                               exadeta_table,
                               create_sql_statement,
                               ):
    '''

    :param connection:
    :param exadeta_table:
    :param create_sql_statement:
    :return:
    '''
    # logger.info("Drop  table {0}".format(exadeta_table))
    # try:
    #     util.execute_oracle_sql(
    #         connection=connection,
    #         sql_query='DROP TABLE {0}'.format(exadeta_table))
    # except DatabaseError as err:
    #     if err.message == "ORA-00942: table or view does not exist":
    #         pass
    #
    # util.execute_oracle_sql(
    #     connection=connection,
    #     sql_query=create_sql_statement
    # )

    logger.info("Create table {0}".format(exadeta_table))
