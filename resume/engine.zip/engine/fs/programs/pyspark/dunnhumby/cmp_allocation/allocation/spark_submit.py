import abc
import ast
import logging
import os
import re

logger = logging.getLogger(__name__)


class SparkApplicationError(Exception):
    def __init__(self, application_id, application_url, error):
        message = "Spark application {id} failed, error message: {err}".format(
            id=application_id, err=error)
        self.application_id = application_id
        self.application_url = application_url
        self.error = error
        super(SparkApplicationError, self).__init__(message)


class SparkSubmitError(Exception):
    def __init__(self, error):
        self.error = error
        message = "spark-submit statement failed, error message: {err}".format(err=error)
        super(SparkSubmitError, self).__init__(message)


def submit(queue, driver_script, application_name=None, arguments=None, master='yarn', deploy_mode='cluster',
           driver_memory=None, executor_memory=None, conf=None, files=None, py_files=None, jar_files=None,
           logging_pattern="INFO spark_drivers", args_prefix="Allocation Return Values:"):
    """Submit a spark driver program via the 'spark-submit' shell script:

    http://spark.apache.org/docs/latest/submitting-applications.html

    pulls spark application logs down from cluster manager raises exceptions if either the spark-submit shell script
    or the spark application itself fails

    Args:
        queue: str
            Queue to submit the spark application to - eg "root.sse"
        driver_script: str
            Name of the script to submit
        application_name: str, optional
            Name of spark application once submitted, if None will default to driver script filename
        arguments: list, optional
            List of arguments to pass to the driver script - will be placed on cmd line in position specified in list
        master:, str, optional, defaults to 'yarn'
            Master URL for the spark cluster
        deploy_mode:, str, optional, defaults to 'cluster'
            Deployment mode for spark application - 'client' or 'cluster'
        driver_memory: string, optional
            Memory to request from cluster manager for application driver process, if None will use cluster default
        executor_memory: string, optional
            Memory to request from cluster manager for application executor processs, if None will use cluster default
        conf: list, optional
            List of additional config settings, in key=value fmt, eg ["spark.some.conf=123", "spark.another.conf=456"]
        files: list, optional
            List of files to copy to the driver processes working directory
        py_files: list, optional
            List of files to copy to the driver processes working directory and add to it's python path
        jar_files: list, optional
            List of files to copy to the driver processes working directory and add to it's class path
        logging_pattern: string, optional
            String used to identify the start of driver program logging when parsing the application log
        args_prefix: string, optional
            String used to identity a special line output to driver logs - everything to the right of this string will
            be literally evaluated and returned as "output_args"

    Returns:
        Dict: {
                "application_id: spark application ID parsed from spark-submit log, None if application not started,
                "tracking_url": spark tracking URL parsed from spark-submit log, None if application not started,
                "driver_output": spark driver log, None if application not started,
                "output_args": arguments parsed from driver log, None if application not started or no args found
            }

    Raises:
        SparkSubmitError: An error occurred attempting to spark-submit the spark driver program
        SparkApplicationError: An error occurred while our spark driver program was executing
    """
    spark_process = SparkSubmit(queue, application_name, master, deploy_mode, driver_memory,
                                executor_memory, conf, files, py_files, jar_files)
    logger.info('### spark-submitting script {script} ###'.format(script=driver_script))
    spark_process.submit_driver(driver_script, arguments)
    logger.info('### spark-submit command executed:  ###')
    logger.info(spark_process.get_spark_submit_cmd())
    logger.info('### spark-submit stderr ###')
    for row in spark_process.spark_submit_stderr_iter():
        logger.info(row)
    logger.info('### end of spark-submit stderr ###')
    spark_log = spark_process.get_application_log()
    if spark_log:
        driver_log = spark_log.get_driver_log(start_pattern=logging_pattern)
        logger.info('### Driver program stdout ###\n{0}\n'.format(driver_log))
        logger.info('### End of driver program stdout ###')
    if spark_process.exit_code != 0:
        if spark_log:
            raise SparkApplicationError(
                application_id=spark_process.application_id,
                application_url=spark_process.tracking_url,
                error=spark_log.get_error_message())
        else:
            raise SparkSubmitError(error=spark_process.get_error_message())
    return {
        "application_id": spark_process.application_id,
        "tracking_url": spark_process.tracking_url,
        "driver_output": spark_log.get_driver_log(start_pattern=logging_pattern),
        "output_args": spark_log.get_output_args(args_prefix=args_prefix)
    }


def get_cluster_log(master, application_id):
    """"Class factory - instantiates and returns a ClusterLog object of the appropriate subclass"""
    if master.lower() == "yarn":
        return YarnLog(application_id=application_id)
    else:
        raise NotImplementedError('Concrete ClusterLogs class not implemented for "{0}" master'.format(master))


class ClusterLogs:
    """Abstract Base Class defining the ClusterLog interface"""
    __metaclass__ = abc.ABCMeta

    def __init__(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def stderr(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def stdout(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def get_driver_log(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def get_error_message(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def get_output_args(self, *args, **kwargs):
        pass


class YarnLog(ClusterLogs):
    """
    ClusterLog Yarn cluster manager specific implementation
    imports the 'yarn' shell script with the sh module and uses it to retrieve the logs of a given yarn application ID,
    parsing it for:
        - the portion of the log starting with a given string, which should be the spark driver's stdout/stderr
        - any error message/traceback output by the spark diver program
        - a line in the log starting with a specified string, which will be ast.literal evaluated and returned, allowing
        us to pass values back from the spark-submitted script into the submitting context - this is a bad hack
    """

    def __init__(self, application_id):
        """Class constructor - will import yarn from sh and then use it to retrieve the log for a given application

        Args:
            application_id:  ID of application to retrieve logs for
        """
        super(YarnLog, self).__init__()
        self.application_id = application_id
        try:
            from sh import yarn
        except ImportError:
            raise RuntimeError('Unable to find yarn shell script in path: {path}'.format(path=os.environ['path']))
        yarn = yarn.bake('logs')
        yarn = yarn.bake('-applicationId')
        self.log = yarn(application_id)

    def stderr(self):
        """Returns stderr of retrieved log"""
        return self.log.stderr

    def stdout(self):
        """Returns stdout of retrieved log"""
        return self.log.stdout

    def get_driver_log(self, start_pattern):
        """Parses stdout of retrieved log for section starting with magic string, hopefully containing our driver log"""
        # regex should match section of log starting with the first line that starts "YY/MM/DD HH:MM:SS {start_pattern}"
        # all the way up to two consecutive new line characters or the end of the file, whichever comes first
        regex = r"(^\d{2}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} " + start_pattern + r".*?)(\n{4,}|\Z)"
        if self.log:
            matches = re.findall(regex, self.stdout(), re.DOTALL | re.MULTILINE)
            if matches:
                return matches[0][0]
        return None

    def get_error_message(self):
        """Parses stdout for any error/traceback messages"""
        if self.log:
            # regex should match either start of Python Traceback or syntax error, up to the end of the file
            regex = r"(^  File \".*?\", line \d+.*?\Z)|(^Traceback \(most recent call last\):.*?)(\n{4,}|\Z)"
            matches = re.findall(regex, self.stdout(), re.DOTALL | re.MULTILINE)
            if matches:
                for m in matches[0][:-1]:
                    if m:
                        return m
        return None

    def get_output_args(self, args_prefix):
        """Parses stdout for line starting with magic string, hopefully containing something we can literal_eval"""
        p = re.compile("{0} (.*)".format(args_prefix))
        m = p.search(self.stdout())
        if m:
            try:
                return ast.literal_eval(m.group(1))
            except (ValueError, SyntaxError):
                return m.group(1)
        return None


class SparkSubmit(object):
    """
    Class wrapping the spark-submit shell script to allow the submission of a driver script and the retrieval of its
    application ID, tracker URL and logs
    """
    def __init__(self, queue, application_name, master, deploy_mode, driver_memory,
                 executor_memory, conf, files, py_files, jar_files):
        """
        Class Constructor - args are passed to the spark-submit shell script and are documented at
        https://spark.apache.org/docs/1.6.1/submitting-applications.html

        Args:
            queue: Name of queue to submit application to
            application_name: Application name
            master: Master URL for the cluster
            deploy_mode: Deploy mode for application - cluster or client
            driver_memory: Amount of memory to allocate to driver process
            executor_memory: Amount of memory to allocate to each executor process
            conf: List of arbitrary spark config values, eg ['conf1=foo', 'conf2=bar']
            files: List of files to copy to driver program working directory
            py_files: List of files to copy to driver program working directory and add to python search path
            jar_files: List of files to copy to driver program working directory and add to java class path

        Raises:
            RuntimeError: An error occurred trying to import spark_submit from sh
        """
        super(SparkSubmit, self).__init__()
        self.queue = queue
        self.application_name = application_name
        self.master = master
        self.deploy_mode = deploy_mode
        self.executor_memory = executor_memory
        self.driver_memory = driver_memory
        self.conf = conf
        self.files = files
        self.py_files = py_files
        self.jar_files = jar_files
        self.application_id = None
        self.tracking_url = None
        self.exit_code = None
        self.__process = None
        try:
            from sh import spark_submit as ss
        except ImportError:
            raise RuntimeError(
                'Unable to find spark-submit shell script in path: {path}'.format(path=os.environ['path']))
        self.__ss = ss

    def __sub_func(self):
        """Construct a spark-submit command, baking in all provided parameters"""
        ss = self.__ss.bake('--master', self.master)
        ss = ss.bake('--deploy-mode', self.deploy_mode)
        ss = ss.bake('--queue', self.queue)
        ss = ss.bake('--supervise')
        if self.application_name is not None:
            ss = ss.bake('--name', self.application_name)
        if self.driver_memory is not None:
            ss = ss.bake('--driver-memory', self.driver_memory)
        if self.executor_memory is not None:
            ss = ss.bake('--executor-memory', self.executor_memory)
        if self.conf is not None:
            if not isinstance(self.conf, list):
                self.conf = [self.conf]
            for conf_item in self.conf:
                ss = ss.bake('--conf', conf_item)
        if self.files is not None:
            if not isinstance(self.files, list):
                self.files = [self.files]
            cs_files = ",".join(self.files)
            ss = ss.bake('--files', cs_files)
        if self.py_files is not None:
            if not isinstance(self.py_files, list):
                self.py_files = [self.py_files]
            cs_py_files = ",".join(self.py_files)
            ss = ss.bake('--py-files', cs_py_files)
        if self.jar_files is not None:
            if not isinstance(self.jar_files, list):
                self.jar_files = [self.jar_files]
            cs_jar_files = ",".join(self.jar_files)
            ss = ss.bake('--jars', cs_jar_files)
        return ss

    def submit_driver(self, driver_script, arguments=None):
        """Spark-submit a driver program, with cmd line args if specified, and capture app's ID, URL and exit code
        Args:
            driver_script: driver program to submit
            arguments: set of args to pass to the driver program - will be available as sys.argv in driver
        """
        if arguments and not isinstance(arguments, list):
            arguments = [arguments]
        self.__process = self.__sub_func()(driver_script, *arguments, _ok_code=[0, 1])
        self.exit_code = self.__process.exit_code
        self.application_id = self.__get_app_id()
        self.tracking_url = self.__get_app_url()

    def get_spark_submit_cmd(self):
        """Return the spark-submit command as executed"""
        if self.__process is not None:
            return self.__process.ran
        return None

    def spark_submit_stderr_iter(self):
        """Iterator returning spark-submit std err line by line, skipping any repeated lines"""
        if self.__process is not None:
            for row in self.__strip_stderr(self.__process.stderr):
                yield row

    def get_error_message(self):
        """Search for common error strings in spark-submit stderr"""
        if self.__process is not None:
            for row in self.__strip_stderr(self.__process.stderr):
                if row.startswith("Error:") \
                        or row.startswith('Caused by:') \
                        or row.startswith('Exception in thread "main"'):
                    return row

    def get_application_log(self):
        """Return a ClusterLog object of type appropriate for the master"""
        if self.application_id is not None:
            return get_cluster_log(self.master, self.application_id)
        return None

    def __get_app_id(self):
        """Return the spark application ID, parsed out of spark-submit stderr"""
        if self.__process is not None:
            p = re.compile('Submitted application (application_\d*_\d*)')
            m = p.search(self.__process.stderr)
            if m:
                return m.group(1)
        return None

    def __get_app_url(self):
        """Return the spark tracking URL, parsed out of spark-submit stderr"""
        if self.__process is not None:
            p = re.compile('tracking URL: (http://.*)')
            m = p.search(self.__process.stderr)
            if m:
                return m.group(1)
        return None

    @staticmethod
    def __strip_stderr(stream):
        """Generator to return each line of spark-submit stderr that is not a repeated application status"""
        previous_status = ""
        p = re.compile('Application report for application_\d*_\d* \(state: (.*)\)')
        for line in stream.splitlines(True):
            m = p.search(line)
            if m:
                if m.group(1) != previous_status:
                    yield line.rstrip()
                previous_status = m.group(1)
            else:
                yield line.rstrip()
