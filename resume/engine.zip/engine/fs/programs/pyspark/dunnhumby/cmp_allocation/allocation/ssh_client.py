"""Collection of functions to return paramiko client objects and run commands over ssh"""
import logging
import os
import paramiko
import socket

logger = logging.getLogger(__name__)


def get_ssh_client(hostname, **ssh_kwargs):
    """
    Create a ssh client connection

    Args:
        hostname: the host of the server to connected to
        **ssh_kwargs:  other arguments for shh connection if needed like username, password..etc
    Return:
        paramiko.SSHClient object
    """
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        logger.debug('get_ssh_client kwargs: {0}'.format(ssh_kwargs.__repr__()))
        ssh_client.connect(hostname=hostname, **ssh_kwargs)
    except IOError as err:
        raise RuntimeError('{0}: {1}'.format(err.strerror, err.filename))
    except socket.gaierror as err:
        raise RuntimeError('{0}: {1}'.format(err.strerror, hostname))
    except paramiko.AuthenticationException as err:
        raise RuntimeError('Failed to connect to {0}: {1}'.format(hostname, err.message))
    logger.info('SSH connection to {0}@{1}:{2} established'.format(
        ssh_client.get_transport().get_username(),
        hostname,
        ssh_client.get_transport().sock.getpeername()[1]
    ))
    return ssh_client


def get_sftp_client(ssh_client):
    """Return a paramiko.SFTPClient object"""
    return ssh_client.open_sftp()


def exec_ssh_command(ssh_client, command, buffsize=1024):
    """
    Wrap paramiko exec_command function in some error trapping and logging

    Args:
        ssh_client: paramiko.SSHClient object connected to remote host
        command: command to execute on remote host
        buffsize: number of bytes of stdout and stderr to retrieve (default 1k)
    """
    logger.debug('SSH command: "{0}"'.format(command))
    channel = ssh_client.get_transport().open_session()
    channel.exec_command(command)
    stdout = channel.recv(buffsize)
    if stdout:
        logger.debug("stdout: {0}".format(stdout))
    stderr = channel.recv_stderr(buffsize)
    if stderr:
        logger.debug("stderr: {0}".format(stderr))
    exit_status = channel.recv_exit_status()
    channel.close()
    if exit_status != 0:
        raise RuntimeError("SSH command failed, exit status: {0}".format(exit_status))
    return stdout


def move_file(ssh_client, filename, destination):
    """Execute a mv command over a SSH connection"""
    logger.info('Moving file {0} to {1}'.format(filename, destination))
    exec_ssh_command(ssh_client, 'mv {0} {1}'.format(filename, destination))


def get_row_count(ssh_client, filename):
    """Run bash wc -l against a remote file and parse out the row count """
    return exec_ssh_command(ssh_client, "wc -l {0}".format(filename)).split()[0]


def get_file_size(sftp_client, filename):
    return sftp_client.open(filename).stat().st_size


def create_complete_file(path, ssh_client, suffix='.complete', stats=False):
    sftp_client = get_sftp_client(ssh_client)
    if stats:
        name = os.path.basename(path)
        size = get_file_size(sftp_client, path)
        rows = get_row_count(ssh_client, path)
        body = ','.join(map(str, [name, size, rows]))
    else:
        body = ''
    complete_file = path + suffix
    logger.info("Writing complete file {0}".format(complete_file))
    with sftp_client.open(complete_file, 'w') as f:
        f.write(body)

