import datetime
import logging
import os
import tools.configs as cfg
import spark_submit as ss
import util as util

logger = logging.getLogger(__name__)

spark_conf = [
    'spark.yarn.maxAppAttempts=1',
    'spark.sql.parquet.compression.codec=snappy',
    'spark.sql.parquet.binaryAsString=true',
    'spark.yarn.driver.memoryOverhead=4096',
    'spark.yarn.executor.memoryOverhead=4096',
    'spark.executor.heartbeatInterval=20s',
    'spark.network.timeout=800s',
    'spark.executor.cores=7',
    'spark.sql.broadcastTimeout=1200',
    'spark.ui.view.acls=*',
    'spark.dynamicAllocation.maxExecutors=25'

]


def allocate_variations(variation_list, client, algorithm, event_id, dttm, hdfs_output_path, yarn_queue,
                        executor_memory, driver_memory, config_file, py_files, jar_files):
    """Spark-submit a script to allocate each variation in variation_list.

    Args:
        variation_list: list of tuples in form [(var1_id, var1_description), (var2_id, var2_description), ...]
        client: client shortname (ie tesco_uk) - will be used to load appropriate Allocation subclass
        algorithm: algorithm to use to allocate
        event_id: event ID to be used when naming output files
        dttm: string formatted datetime stamp to be used when naming output files
        hdfs_output_path: path on HDFS to write output files into
        yarn_queue: Yarn queue to submit spark job to
        executor_memory: Memory per spark executor
        driver_memory: Memory for spark driver
        config_file: Config file to be passed to spark driver program though --files parameter
        py_files: List of local .zip, .egg, or .py files to place on the driver PYTHONPATH
        jar_files: List of local jars to include on the driver and executor classpaths
    Return: Dict
        {
            variation_id_1: hdfs_path_to_variation_1_allocation_results,
            variation_id_2: hdfs_path_to_variation_2_allocation_results,
            ...
            variation_id_n: hdfs_path_to_variation__n_allocation_results
        }
    """
    allocated_files = dict()
    for variation in variation_list:
        variation_id = variation[0]
        variation_description = variation[1]
        run_prefix = '_'.join(map(str, [algorithm, event_id, variation_id, dttm])).lower()
        full_hdfs_output_path = os.path.join(hdfs_output_path, run_prefix)

        spark_app_name = " ".join([algorithm, 'allocation', variation_description]).title()
        logger.info('spark-submitting algorithm: "{0}", variation: "{1}", ID: "{2}"'
                    .format(algorithm.title(), variation_description.title(), variation_id))

        full_config = cfg.Config().add_source_file(config_file)
        set_spark_conf = full_config.get_item(
            keys="set_spark_conf", mandatory=False)

        if set_spark_conf:
            new_spark_conf = full_config.get_item(
            keys="spark_conf", mandatory=False)

	    global spark_conf

            spark_conf = spark_conf + new_spark_conf

        ss.submit(
            driver_script='spark_drivers/run_allocation.py',
            arguments=[client, algorithm, variation_id, full_hdfs_output_path],
            application_name=spark_app_name,
            queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            files=config_file,
            py_files=py_files,
            jar_files=jar_files,
            conf=spark_conf
        )
        allocated_files[variation_id] = full_hdfs_output_path
    return allocated_files


def format_output(algorithm, send_files,  yarn_queue, executor_memory, driver_memory,
                  config_file, py_files, jar_files,  output_name):


    if not isinstance(py_files, list):
        py_files = [py_files]
    spark_app_name = " ".join([algorithm, "Format Outputs"]).title()
    if(algorithm != 'soema'):

        comma_separated_file_names = ','.join(send_files.values())
        logger.info('Formatting files for transfer to destination system: {0}'.format(comma_separated_file_names))
        ss.submit(
                driver_script='spark_drivers/format_results.py',
                arguments=[algorithm, output_name, comma_separated_file_names],
                application_name=spark_app_name,
                queue=yarn_queue,
                executor_memory=executor_memory,
                driver_memory=driver_memory,
                files=config_file,
                py_files=py_files,
                jar_files=jar_files,
                conf=spark_conf)
        out_files = dict()
        for k, v in send_files.items():
            out_files[k] = v + '.' + str(output_name)
        return out_files

    else :
        comma_separated_file_names = ','.join(send_files)
        logger.info('Comma separated file names : {comma_separated_file_names}'.format(comma_separated_file_names = comma_separated_file_names))
        ss.submit(
            driver_script='spark_drivers/format_results_unica.py',
            arguments=[algorithm, output_name, comma_separated_file_names],
            application_name=spark_app_name,
            queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            files=config_file,
            py_files=py_files,
            jar_files=jar_files,
            conf=spark_conf)
        return send_files





def generate_send_files(algorithm, dttm, allocated_files, hdfs_output_path, event_id, control_variation_id,
                       yarn_queue, executor_memory, driver_memory, config_file, py_files, jar_files):

    """Spark submit a script to allocate all customers to a single variation, according to the variation weight,
    and then build a control variation and as  many target variations as there are non-control variations.

    Control variation will contain all customers in the event's control population, and the results from whatever
    variation they were assigned to.

    Each target variation will contain all the customer in the event's target population that were assigned to that
    variation.

    Args:
        algorithm: algorithm used to allocate
        event_id: event ID to be used when naming output files
        control_variation_id: id of event's control variation
        send_file_suffix: suffix to add to send files to ensure they do not clash with raw allocation outputs
        dttm: string formatted datetime stamp to be used when naming output files
        allocated_files: dict containing all variations' results, with variation ID as key
        hdfs_output_path: path on HDFS to write output files into
        yarn_queue: Yarn queue to submit spark job to
        executor_memory: Memory per spark executor
        driver_memory: Memory for spark driver
        config_file: Config file to be passed to spark driver program though --files parameter
        py_files: Comma-separated list of local .zip, .egg, or .py files to place on the driver PYTHONPATH
        jar_files: Comma-separated list of local jars to include on the driver and executor classpaths
    Return: Dict
        {
            variation_id_0: hdfs_path_to_variation_1_allocation_results,
            variation_id_1: hdfs_path_to_variation_2_allocation_results,
            ...
            variation_id_n: hdfs_path_to_variation__n_allocation_results
        }
    """
    logger.info('Create send files ')
    if not isinstance(py_files, list):
        py_files = [py_files]
    py_files.append(config_file)
    spark_app_name = " ".join([algorithm, "Generate Send Files"]).title()
    ss.submit(
        driver_script='spark_drivers/send_control_files.py',
        arguments=[
            algorithm,
            dttm,
            allocated_files.__repr__(),
            config_file
        ],
        application_name=spark_app_name,
        queue=yarn_queue,
        executor_memory=executor_memory,
        driver_memory=driver_memory,
        files=config_file,
        py_files=py_files,
        jar_files=jar_files,
        conf=[
            'spark.yarn.maxAppAttempts=1',
            'spark.sql.parquet.compression.codec=snappy',
            'spark.sql.parquet.binaryAsString=true',
            'spark.yarn.driver.memoryOverhead=4096',
            'spark.yarn.executor.memoryOverhead=4096'
        ]
    )
    send_files = [
        os.path.join(hdfs_output_path, '_'.join(
            map(str, [algorithm, event_id, 'send', control_file, dttm]))) for control_file in ['target', 'control']
    ]
    logger.info('Send Files: {0}'.format(send_files))
    return send_files


def transfer_to_unica(algorithm, send_files, yarn_queue, executor_memory,
                      driver_memory, config_file, py_files, jar_files):
    comma_separated_file_names = ','.join(send_files.keys())
    logger.info('Transferring files to Unica (via Exadata): {0}'.format(comma_separated_file_names))
    if not isinstance(py_files, list):
        py_files = [py_files]
    spark_app_name = " ".join([algorithm, "Transfer To Unica"]).title()
    ss.submit(
            driver_script='spark_drivers/transfer_to_unica.py',
            arguments=[algorithm, comma_separated_file_names],
            application_name=spark_app_name,
            queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            files=config_file,
            py_files=py_files,
            jar_files=jar_files,
            conf=spark_conf
        )


def update_control(algorithm, dttm, allocated_files, hdfs_output_path, yarn_queue, hdfs_control, event_id,
                   executor_memory, driver_memory, config_file, py_files, jar_files):
    """Return a list of HDFS CONTROL files
    Args:
        algorithm: algorithm to use to allocate
        event_id: event ID to be used when naming output files
        dttm: string formatted datetime stamp to be used when naming output files
        allocated_files: the RP output list of files
        control_weight: weight of the control populaton to be taken
        hdfs_output_path: path on HDFS to write output files into
        hdfs_control: path on HDFS to write CONTROL files
        yarn_queue: Yarn queue to submit spark job to
        executor_memory: Memory per spark executor
        driver_memory: Memory for spark driver
        config_file: Config file to be passed to spark driver program though --files parameter
        py_files: Comma-separated list of local .zip, .egg, or .py files to place on the driver PYTHONPATH
        jar_files: Comma-separated list of local jars to include on the driver and executor classpaths
        customer_key: column containing customer identifier
        webhdfs_active_url: URL of currently active webHDFS NameNode
    Returns:
          List of files: [hdfs_output_path/algorithm_hdfs_control_path_event_id/file_prefix[0]_dttm,
                          hdfs_output_path/algorithm_hdfs_control_path_event_id/file_prefix[1]_dttm, ...]
      """

    conf = cfg.Config(logger=logger)
    conf.add_source_file(path=config_file)
    hdfs_nnodes = conf.get_item(keys='hdfs_name_nodes', mandatory=True)
    web_root = conf.get_item(keys='webhdfs_root', mandatory=True)
    logger.info('Updating {0} control files based on allocation outputs'.format(algorithm))
    full_hdfs_control_path = os.path.join(hdfs_output_path, '_'.join(map(str, [algorithm, hdfs_control, event_id])))
    file_prefix = [
        "CONTROL_GROUP",
        "TARGET_GROUP",
        "PROGRAM_CONTROL_GROUP",
        "last_run_dttm"]
    control_files = [
        os.path.join(hdfs_output_path, file_name) for file_name in ['_'.join([f, dttm]) for f in file_prefix]]
    webhdfs_active_url = util.get_active_namenode_webhdfs_root(
        namenode_list=hdfs_nnodes,
        webhdfs_root=web_root,
        logger=logger
    )
    hdfs_url = webhdfs_active_url.replace('webhdfs/v1', '')
    if not isinstance(py_files, list):
        py_files = [py_files]
    py_files.append(config_file)
    spark_app_name = " ".join([algorithm, "Control Update"]).title()
    ss.submit(
        driver_script='spark_drivers/update_control.py',
        arguments=[
            algorithm,
            dttm,
            full_hdfs_control_path,
            allocated_files.__repr__(),
            file_prefix.__repr__(),
            hdfs_url,
            config_file
        ],
        application_name=spark_app_name,
        queue=yarn_queue,
        executor_memory=executor_memory,
        driver_memory=driver_memory,
        files=config_file,
        py_files=py_files,
        jar_files=jar_files,
        conf=[
            'spark.yarn.maxAppAttempts=1',
            'spark.sql.parquet.compression.codec=snappy',
            'spark.sql.parquet.binaryAsString=true',
            'spark.yarn.driver.memoryOverhead=4096',
            'spark.yarn.executor.memoryOverhead=4096'
        ]
    )
    return control_files



def update_event_id(algorithm,  yarn_queue, executor_memory, driver_memory, config_file,
                    py_files, jar_files, derive_event_dates, event_id_hdfs_path):

    spark_app_name = " ".join([algorithm, "Event ID Update"]).title()
    if not isinstance(py_files, list):
        py_files = [py_files]
    spark_job = ss.submit(
            driver_script='spark_drivers/update_event_id.py',
            arguments=[algorithm, derive_event_dates, event_id_hdfs_path],
            application_name=spark_app_name,
            queue=yarn_queue,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            files=config_file,
            py_files=py_files,
            jar_files=jar_files,
            conf=spark_conf
        )
    date_fmt = '%d%b%Y:%H:%M:%S'
    event_id = spark_job['output_args']['event_id']
    event_start_date = datetime.datetime.strptime(spark_job['output_args']['start_date'], date_fmt)
    event_end_date = datetime.datetime.strptime(spark_job['output_args']['end_date'], date_fmt)
    return event_id, event_start_date, event_end_date
