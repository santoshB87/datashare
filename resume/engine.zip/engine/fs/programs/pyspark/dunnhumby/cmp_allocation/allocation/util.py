"""Misc helper functions for allocation package"""
import logging
import datetime
import pytz

logger = logging.getLogger(__name__)


def get_time_zoned_dttm(zone, dttm=None):
    """Return the current dttm in a specified timezone"""
    if zone not in pytz.all_timezones:
        raise RuntimeError("Timezone '{0}' not recognised, please select one from pytz.all_timezones")
    if not dttm:
        dttm = datetime.datetime.now(pytz.utc)
    return dttm.astimezone(pytz.timezone(zone))


# def get_active_namenode_webhdfs_root(namenode_list, webhdfs_root, logger):
#     """Get the active webhdfs root. The HDFS` NameNodes change periodically and there is only one NameNode in an 'Active'
#     Role Type, the others being  in a 'Standbay' state. Therefore the 'Active' NameNode is needed in order to transfer
#     files from HDFS to a remote location.
#     The webhdfs_root is based on : "http://activeNameNode.dunnhumby.co.uk:50070/webhdfs/v1"
#     Args:
#         namenode_list : the list of HDFS` NameNodes(ie "gbslobd1r01s01")
#         webhdfs_root: url path to webhdfs service (ie "http://activeNameNode.dunnhumby.co.uk:50070/webhdfs/v1")
#         logger: logger object for debug messages
#     """
#
#     if isinstance(namenode_list, list) is not True:
#         raise RuntimeError("Must specify HDFS NameNodes as a list instance")
#
#     auth = requests_kerberos.HTTPKerberosAuth()
#     for namenode in namenode_list:
#         logger.debug('trying namenode {0}'.format(namenode))
#         webhdfs_namenode_root = webhdfs_root.replace('activeNameNode', namenode)
#         url = os.path.join(webhdfs_namenode_root, '?op=LISTSTATUS')
#         logger.debug('url: {0}'.format(url))
#
#         try:
#             request_output = requests.get(url, auth=auth)
#             status_code = request_output.status_code
#             response = request_output.text
#             logger.debug('response - {0}: {1}'.format(status_code, response))
#         except requests.exceptions.ConnectionError as err:
#             status_code = None
#             logger.debug('connection failed: {0}'.format(err.message))
#
#         if status_code == 200:
#             logger.debug('namenode service active, returning {0}'.format(webhdfs_namenode_root))
#             return webhdfs_namenode_root
#     raise RuntimeError('No active namenodes found in list {0}'.format(namenode_list.__repr__()))
#

# def get_kerberos_ticket(ssh_client, kerberos_realm='DUNNHUMBY.CO.UK'):
#     """run kinit over ssh connection, using keytab, to ensure up to date tgt is in place"""
#     uid = ssh_client.get_transport().get_username()
#     kinit_cmd = 'kinit {0}@{1} -k -t ~/{0}.keytab'.format(uid, kerberos_realm)
#     logger.debug('kinit cmd: {0}'.format(kinit_cmd))
#     std_out = ssh_client.exec_command(kinit_cmd)[1]
#     if std_out.channel.recv_exit_status() != 0:
#         # don't raise an exception here - tgt may be in place regardless, and if not we'll get an exception soon enough
#         logger.warning('kinit failed, ensure ~/username.keytab exists on the destination machine: '
#                        'https://dhgitlab.dunnhumby.co.uk/sse/ssewiki/wikis/Keytab-creation')
