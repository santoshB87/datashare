import logging

logger = logging.getLogger(__name__)

__available_propositions__ = [
    ('meijer', 'relevant_promotions_rte', 'RPAllocation'),
    ('meijer', 'usuals_rte', 'UsualsAllocation'),
    ('meijer', 'complements_rte', 'ComplementsAllocation'),
]

def get_allocation_object(client, proposition, variation, config_file):
    class_name = None
    for clt, prp, cls in __available_propositions__:
        if clt == client and prp == proposition:
            class_name = cls
    if not class_name:
        raise RuntimeError('No implementation found for {0}, {1}'.format(client, proposition))
    class_import_path = [client, 'cmp_allocation', 'propositions', proposition, class_name]
    module = ".".join(class_import_path[:-1])
    m = __import__(module)
    for comp in class_import_path[1:]:
        m = getattr(m, comp)
    allocation = m(config_file=config_file, algorithm=proposition, variation=variation)
    return allocation
