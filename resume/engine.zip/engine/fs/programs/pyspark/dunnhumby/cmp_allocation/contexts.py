"""
Module to hold SparkContext and HiveContext for application
"""
import logging
import pyspark

# pylint: disable=global-statement
logger = logging.getLogger(__name__)

_sc = None
_sql_context = None


def sc(spark_conf=pyspark.SparkConf()):
    '''

    :param spark_conf:
    :return:
    '''
    global _sc
    if _sc is None:
        logger.debug('No SparkContext set - getOrCreating a new one')
        spark_conf.set("spark.sql.parquet.binaryAsString", "true")
        _sc = pyspark.SparkContext.getOrCreate(spark_conf)
        # reduce the logging output of the spark context - otherwise it's incredibly verbose
        spark_logger = _sc._jvm.org.apache.log4j
        spark_logger.LogManager.getLogger("org").setLevel(spark_logger.Level.ERROR)
        spark_logger.LogManager.getLogger("akka").setLevel(spark_logger.Level.ERROR)
    return _sc


def set_sc(spark_context):
    '''

    :param spark_context:
    :return:
    '''
    global _sc
    _sc = spark_context


def sql_context():
    '''

    :return:
    '''
    global _sql_context
    if _sql_context is None:
        logger.debug('No sqlContext set - creating a new HiveContext')
        _sql_context = pyspark.HiveContext(sc())
    return _sql_context


def set_sql_context(sql_context):
    '''

    :param sql_context:
    :return:
    '''
    global _sql_context
    _sql_context = sql_context
