import logging
import os

import pyspark.sql.functions as func
from pyspark.sql.types import StructType, StructField, StringType

from dunnhumby.cmp_allocation import spark_tools
# pylint: disable=logging-not-lazy
# pylint: disable=bad-continuation
# pylint: disable=line-too-long
# pylint: disable=logging-format-interpolation
logger = logging.getLogger(__name__)


def allocate_groups(
        input_df,
        hive_context,
        fs_client,
        customer_key,
        file_format,
        file_save_mode,
        control_directory,
        control_weight,
        algorithm_run_timestamp
):
    """ Function to create or update event control files on HDFS

        Args:
            input_df: data frame of all allocated variation results for event
            hive_context: JVM Scala HiveContext
            fs_client: a file system object that implements the api defined in dunnhumby.file_system.FSClient
            customer_key: customer column name
            control_directory: directory we expect this event's control population to be stored in - if it doesn't
                exist we assume we are generating controls from scratch and will create it
            control_weight: used to split customers into control and target populations in ratio control_weight: 100
            file_format: specifies the underlying output data source: json, parquet
            file_save_mode: specifies the behavior of the save operation when data already exists
                                  append: Append contents of this DataFrame to existing data.
                                  overwrite: Overwrite existing data.
                                  ignore: Silently ignore this operation if data already exists.
                                  error (default case): Throw an exception if data already exists.
            algorithm_run_timestamp: the run timestamp
    """

    spark_tools.check_columns(input_df, customer_key)

    # prefixes of our control file names
    ctl_prefix = 'CONTROL_GROUP'
    tgt_prefix = 'TARGET_GROUP'
    pgm_prefix = 'PROGRAM_CONTROL_GROUP'
    dttm_prefix ='last_run_dttm'

    # fully qualified paths to our control files, less the datetime stamp suffixes
    control_root = os.path.join(control_directory, ctl_prefix)
    target_root = os.path.join(control_directory, tgt_prefix)
    pgm_root = os.path.join(control_directory, pgm_prefix)

    # fully qualified path to our last run dttm file - this one does not have a dttm suffix
    dttm_path = os.path.join(control_directory, dttm_prefix)

    logger.info('Printing path', control_directory)

    error_flag = False
    missing_files = list()

    if not fs_client.directory_exists(control_directory):
        logger.info(
            'Did not find existing control directory \'{0}\'. New directory will be created and entire customer '
            'population randomised between target, control and program control'
            .format(control_directory)
        )

        # create empty dataframes to hold previous control customer IDs - this will cause all customers to be treated as
        # new and re-randomised
        schema = StructType([StructField(customer_key, StringType(), False)])
        empty_row = []
        old_control_customers = hive_context.createDataFrame(empty_row, schema)
        old_target_customers = hive_context.createDataFrame(empty_row, schema)
        old_pgm_control_customers = hive_context.createDataFrame(empty_row, schema)
        known_customers = hive_context.createDataFrame(empty_row, schema)
        known_customers = known_customers.withColumnRenamed(customer_key,"customer_key")

    else:
        logger.info('Existing control directory found \'{0}\'.  Will randomise new customers only between target, '
                    'control and program control'.format(
            control_directory))
        if fs_client.directory_exists(dttm_path):

            logger.info('Reading last run dttm from: {0}'.format(dttm_path))
            last_run_df = hive_context.read.text(dttm_path)
            last_run_dttm = str(last_run_df.collect()[0][0])
            logger.info('Last run dttm: {0}'.format(last_run_dttm))

            # check that ctl, tgt and pgm ctl files exist in the control directory with the latest dttm suffix
            old_control_path = '_'.join([control_root, last_run_dttm])
            if not fs_client.directory_exists(os.path.dirname(old_control_path)):
                error_flag = True
                missing_files.append(old_control_path)
            else:
                logger.info('Previous control population: \'{0}\''.format(old_control_path))

            old_target_path = '_'.join([target_root, last_run_dttm])
            if not fs_client.directory_exists(old_target_path):
                error_flag = True
                missing_files.append(old_target_path)
            else:
                logger.info('Previous target population: \'{0}\''.format(old_target_path))

            old_pgm_path = '_'.join([pgm_root, last_run_dttm])
            if not fs_client.directory_exists(old_pgm_path):
                error_flag = True
                missing_files.append(old_pgm_path)
            else:
                logger.info('Previous program control population: \'{0}\''.format(old_pgm_path))

            old_control_customers = hive_context.read.parquet(old_control_path)
            old_target_customers = hive_context.read.parquet(old_target_path)
            old_pgm_control_customers = hive_context.read.parquet(old_pgm_path)

            # identify all customers in the previous run's control files - these customers will remain in the same
            # groups and will not be rerandomised
            known_customers = spark_tools.union_all(
                [old_control_customers,
                 old_target_customers,
                 old_pgm_control_customers]
            ).withColumnRenamed(customer_key, 'customer_key')

        else:
            old_control_customers = None
            old_target_customers = None
            old_pgm_control_customers = None
            known_customers = None
            error_flag = True
            missing_files.append(dttm_path)

    if error_flag:
        raise RuntimeError('Unable to find expected HDFS file(s) {0} '.format(missing_files))

    logger.info('Generating new target, control and program control populations')

    # identify new customers - those that appear in input DF but not in known_customers (note - if we have not found
    # a previous run for this event ID then we assume we want to rerandomise entire population and known_customers
    # will be empty
    new_customers = input_df.select(customer_key) \
        .distinct() \
        .join(known_customers,
              input_df[customer_key] == known_customers['customer_key'],
              'left_outer') \
        .filter("customer_key is null") \
        .drop("customer_key")

    updated_pgm_control_customers = old_pgm_control_customers.unionAll(
        new_customers.where(func.regexp_extract(func.col(customer_key), '([^.]99$)', 1).alias(customer_key) != ''))
    updated_pgm_path = '_'.join([pgm_root, algorithm_run_timestamp])
    logger.info('Creating new program control dataset (customer IDs ending in 99): {0}'.format(updated_pgm_path))
    spark_tools.write_to_hdfs(
        input_df=updated_pgm_control_customers,
        hdfs_path=updated_pgm_path,
        partition_column='customer',
        file_saveMode=file_save_mode,
        file_format=file_format
    )

    logger.info('Randomly assigning remaining customers to control/target populations in ratio {0}:100'
                .format(control_weight))
    split_data = new_customers.subtract(old_pgm_control_customers)
    weight_split = [float(control_weight), 100.0]
    customer_split = split_data.randomSplit(weight_split, seed=123)
    new_control_customers = customer_split[0]
    new_target_customers = customer_split[1]

    updated_control_customers = spark_tools.union_all([old_control_customers, new_control_customers])
    updated_control_path = '_'.join((control_root, algorithm_run_timestamp))
    logger.info('Creating new control dataset: {0}'.format(updated_control_path))
    spark_tools.write_to_hdfs(
        input_df=updated_control_customers,
        hdfs_path=updated_control_path,
        partition_column='customer',
        file_saveMode=file_save_mode,
        file_format=file_format
    )

    updated_target_customers = spark_tools.union_all([old_target_customers, new_target_customers])
    updated_target_path = '_'.join([target_root, algorithm_run_timestamp])
    logger.info('Creating new target dataset: {0}'.format(updated_target_path))
    spark_tools.write_to_hdfs(
        input_df=updated_target_customers,
        hdfs_path=updated_target_path,
        partition_column='customer',
        file_saveMode=file_save_mode,
        file_format=file_format
    )

    logger.info('Updating {0} with current dttm {1}'.format(dttm_path, algorithm_run_timestamp))
    current_dttm_df = hive_context.createDataFrame([(algorithm_run_timestamp,)])
    spark_tools.write_to_hdfs(
        input_df=current_dttm_df,
        hdfs_path=dttm_path,
        number_of_files=1,
        file_saveMode='overwrite',
        file_format='text',
    )


def allocate_variations(variations, population_group_hdfs, hive_context):
    logger.info('Allocate variations for {0}'.format(population_group_hdfs))

    customer_group_df = hive_context.read.parquet(population_group_hdfs)
    # variation type list of all digital variation ids without CONTROL type
    variation_ids = [variation_id for variation_id in variations.keys() if
                     (variation_id.isdecimal()) & (variation_id != '0')]
    # create a list of tuples  containing the variation id and associated weight
    variation_id_plus_weight = []
    [variation_id_plus_weight.append((variation_id, float(variations[variation_id]['weighting']))) for variation_id in
     variation_ids]

    weights_split = ([variations_weights[1] for variations_weights in variation_id_plus_weight])
    variation_split = customer_group_df.randomSplit(weights_split, seed=123)

    for index, var in enumerate(variation_id_plus_weight):
        variation_split[index] = variation_split[index].withColumn('variation_id', func.lit(var[0]))

    return spark_tools.unionAll(*variation_split)



def generate_send_data(input_df,
                       control_population_df,
                       customer_key):
    '''
    # join between rp and control df
    :param input_df:
    :param control_population_df:
    :param customer_key:
    :return:
    '''

    if customer_key not in input_df.columns:
        raise RuntimeError("Customer  key column '{0}' not found in input dataframe columns: {1}"
                           .format(customer_key, ', '.join(input_df.columns)))

    control_population_df = control_population_df.select(func.col(customer_key).alias('customer_key'),
                                                         func.col('variation_id').alias('var_id'))

    return spark_tools.dropAll(input_df.join(control_population_df,
                                                       (input_df[customer_key] == control_population_df['customer_key']) &
                                                       (input_df['variation_id'] == control_population_df['var_id']),
                                         'inner'),
                                         *['customer_key', 'var_id'])
