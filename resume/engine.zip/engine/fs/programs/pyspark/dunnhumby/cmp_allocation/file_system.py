"""
File system client classes defining a standard API onto our underlying file system
"""
__author__ = "Mike Allman"

import abc
import logging
import subprocess

logger = logging.getLogger(__name__)

HDFS_CLIENT = 'hdfs'
DUMMY_CLIENT = 'dummy'
GCP_CLIENT = 'gcp'  # not implemented - just here to demonstrate intention of this module


def get_client(client_type):
    """
    Object factory to return the required client type
    """
    if client_type == DUMMY_CLIENT:
        return DummyClient()
    elif client_type == HDFS_CLIENT:
        return HDFSClient()
    else:
        raise NotImplementedError('FileSystem class not implemented for %s' % client_type)


class FSClient(object):
    """
    Abstract base class defining standard set of file system client methods
    """
    __metaclass__ = abc.ABCMeta

    def __init__(self):
        """
        validate the command/api we're using to interact with the file system
        """
        super(FSClient, self).__init__()

    @abc.abstractmethod
    def file_exists(self, path):
        """
        take a file path and return True if it exists, False if not
        """
        pass

    @abc.abstractmethod
    def create_file(self, path):
        """
        take a file path and create a zero size file
        raise exception if file already exists
        """
        pass

    @abc.abstractmethod
    def delete_file(self, path, force):
        """
        take a file path and delete it
        ignore file does not exist errors if force=True
        """
        pass

    @abc.abstractmethod
    def directory_exists(self, path):
        """
        take a directory path and return True if it exists, False if not
        """
        pass

    @abc.abstractmethod
    def create_directory(self, path, create_parents):
        """
        take a directory path and create it
        include parents if create_parents=True
        error if directory already exists
        """
        pass

    @abc.abstractmethod
    def delete_directory(self, path, force, recursive):
        """
        take a directory path and delete it
        if recursive=True delete subdirectories too
        if force=True delete even if directories are not empty
        """
        pass


class DummyClient(FSClient):
    """
    Dummy fs client to use when unit testing classes that don't have a fs dependency
    """
    def __init__(self):
        super(DummyClient, self).__init__()
        logger.warning('Instantiating a DUMMY file system client - all methods will just return True')

    def file_exists(self, path):
        super(DummyClient, self).file_exists(path)
        logger.warning('Dummy file_exists method - will just return True')
        return True

    def create_file(self, path):
        super(DummyClient, self).create_file(path)
        logger.warning('Dummy create_file method - will just return True')
        return True

    def delete_file(self, path, force):
        super(DummyClient, self).delete_file(path, force)
        logger.warning('Dummy delete_file method - will just return True')
        return True

    def directory_exists(self, path):
        logger.warning('Dummy directory_exists method - will just return True')
        super(DummyClient, self).directory_exists(path)
        return True

    def create_directory(self, path, create_parents):
        logger.warning('Dummy directory_exists method - will just return True')
        super(DummyClient, self).create_directory(path, create_parents)
        return True

    def delete_directory(self, path, force, recursive):
        logger.warning('Dummy delete_directory method - will just return True')
        super(DummyClient, self).delete_directory(path, force, recursive)
        return True


class HDFSClient(FSClient):
    """
    Class to expose a small subset of the hadoop fs commands
    """
    @staticmethod
    def run_cmd(args, raise_on_error=True):
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logger.debug('subprocess cmd: %s' % ' '.join(args))
        stdout, stderr = p.communicate()
        logger.debug('subprocess stdout: %s' % stdout)
        logger.debug('subprocess stderr: %s' % stderr)
        rc = p.returncode
        logger.debug('subprocess returncode: %s' % rc)
        if rc != 0:
            if raise_on_error:
                raise RuntimeError(stderr)
            else:
                return False
        return True

    def __init__(self):
        super(HDFSClient, self).__init__()
        # check we have a hadoop shell command available to us - if not, flip desk
        try:
            p = subprocess.Popen(['hadoop', 'version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except OSError:
            raise RuntimeError('Unable to initialise HDFSFileSystemClient - hadoop shell command not available on OS')
        stdout, stderr = p.communicate()
        logger.debug(stdout)

    def file_exists(self, path):
        args = ['hadoop', 'fs', '-test', '-f', path]
        return self.run_cmd(args, False)

    def create_file(self, path):
        args = ['hadoop', 'fs', '-touchz', path]
        return self.run_cmd(args)

    def delete_file(self, path, force):
        args = ['hadoop', 'fs', '-rm']
        if force:
            args.append('-f')
        args.append(path)
        return self.run_cmd(args)

    def directory_exists(self, path):
        args = ['hadoop', 'fs', '-test', '-d', path]
        return self.run_cmd(args, False)

    def create_directory(self, path, create_parents):
        args = ['hadoop', 'fs', '-mkdir']
        if create_parents:
            args.append('-p')
        args.append(path)
        return self.run_cmd(args)

    def delete_directory(self, path, force, recursive):
        args = ['hadoop', 'fs']
        if recursive:
            args.append('-rm')
            if force:
                args.append('-f')
        else:
            args.append('-rmdir')
            if force:
                logger.warning('force option select on non-recursive delete_directory - will be ignored')
        args.append(path)
        return self.run_cmd(args)
