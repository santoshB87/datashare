import abc
import logging
import operator
import smtplib
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from os.path import basename

import tools.configs as config
import tools.six as six
from dunnhumby import contexts
from dunnhumby.cmp_allocation import spark_tools
from pyspark.sql import Window
from pyspark.sql import functions as F
# noinspection PyUnresolvedReferences
from pyspark.sql.functions import col, lit, when, rand, round, when, \
    dense_rank, udf, row_number, count

logger = logging.getLogger(__name__)


class Allocation(object):
    """
    Allocation base class, provides generic allocation functionality to be extended by algorithm specific subclasses

    methods:
        __init__
        prepare
        end_prepare
        get_scores
        apply_exclusions
        apply_conditional_inclusions
        apply_sensitive_products_exclusion
        apply_required_diversity
        generate_offer_position
        cap_and_infill_recommendations
        random_shuffle
        create_relevancy_score
        write_results_to_hdfs
    abstract methods:
        allocate
    """
    __metaclass__ = abc.ABCMeta

    def __init__(self, config_file, algorithm, variation):
        """
        Class constructor
        """
        self.sc = contexts.sc()
        self.sqlContext = contexts.sql_context()

        self.df = None
        self.category_wise_distri_df = None
        self.infilling_df = None
        self.customers_scored_but_havenot_promoted_product = None
        self.max_offer_cap_df = None
        self.generic_df = None
        self.generic_df_cust = None
        self.cfg = None
        self.get_scores_rules = None
        self.exclusions_rules = None
        self.conditional_inclusions_rules = None
        self.sensitivity_rules = None
        self.required_diversity_rules = None
        self.offer_position_rules = None
        self.allocation_rules = None
        self.random_shuffle_rules = None
        self.relevancy_score_rules = None
        self.customer_final =None
        self.algorithm = algorithm
        self.customer_final =None
        self.algorithm = algorithm
        self.customer_key = None
        self.offer_cap = None
        self.score_column = None
        self.score_type_column = None

        # read entire config file into Config object and then retrieve key for algorithm/variation ID being allocated
        full_config = config.Config().add_source_file(config_file)
        variation_config_dict = full_config.get_item(
            keys=[algorithm, 'variation', variation], mandatory=True)
        full_config.error_on_mandatory_exceptions()
        self.quality_check_rules = full_config.get_item(
            keys=[algorithm, 'quality_check_rules'], mandatory=True)
        self.banner_rules = full_config.get_item(
            keys=[algorithm, 'banner_rules'], mandatory=True)
        self.send_from = full_config.get_item(
            keys=(algorithm, 'notification_outputs', 'sender'), mandatory=True)
        self.send_to = full_config.get_item(
            keys=(algorithm, 'notification_outputs', 'receiver'),
            mandatory=True)
        self.file_path = full_config.get_item(
            keys=(algorithm, 'notification_outputs', 'email_attach_file_path'),
            mandatory=False)
        self.subject = full_config.get_item(
            keys=(algorithm, 'notification_outputs', 'subject'), mandatory=True)
        self.message = full_config.get_item(
            keys=(algorithm, 'notification_outputs', 'message'), mandatory=True)
        self.nfs_file_output_path = full_config.get_item(
            keys=(algorithm, 'quality_check_rules', 'nfs_file_output_path'),
            mandatory=True)
        self.entity_data = full_config.get_item(
            keys=[algorithm, 'entity_data'], mandatory=True)
        self.detailed_quality_check = full_config.get_item(
            keys=[algorithm, 'detailed_quality_check'], mandatory=False)

        # initialise another config object with our variation config dict
        self.cfg = config.Config().add_dict(variation_config_dict)

        # set all our config objects
        self._set_config()

        # error if any mandatory keys were not found
        self.cfg.error_on_mandatory_exceptions()

        # set cfg to None to clear up memory
        self.cfg = None
        self.before_exclusion_cnt = 0
        self.after_exclusion_cnt = 0
        self.after_exclusion_distinct_cnt = 0
        self.before_exclusion_distinct_cnt = 0

    def _set_config(self):
        # retrieve keys mandatory for all allocation types
        self.get_scores_rules = self.cfg.get_item(keys='input_scores',
                                                  mandatory=True)
        self.exclusions_rules = self.cfg.get_item(keys='exclusions',
                                                  mandatory=True)
        self.conditional_inclusions_rules = self.cfg.get_item(
            keys='conditional_inclusions', mandatory=True)
        self.sensitivity_rules = self.cfg.get_item(keys='sensitivity_rules',
                                                   mandatory=True)
        self.required_diversity_rules = self.cfg.get_item(
            keys='required_diversity_rules', mandatory=True)
        self.offer_position_rules = self.cfg.get_item(
            keys='offer_position_rules', mandatory=True)
        self.allocation_rules = self.cfg.get_item(keys='allocation_rules',
                                                  mandatory=True)
        self.random_shuffle_rules = self.cfg.get_item(
            keys='random_shuffle_rules', mandatory=True)
        self.relevancy_score_rules = self.cfg.get_item(
            keys='relevancy_score_rules', mandatory=True)

    def get_entity(self, **kwargs):
        """
        Populate the all enities data

        """
        database_prefix = self.entity_data['database_prefix']
        store_module = self.entity_data['store_module']
        product_module = self.entity_data['product_module']
        customer_module = self.entity_data['customer_module']

        store_module = __import__(store_module, fromlist=['Stores'])
        product_module = __import__(product_module, fromlist=['Products'])
        customer_module = __import__(customer_module, fromlist=['Customers'])

        # refering store entity
        self.store_class = getattr(store_module, "Stores")
        self.store_df = self.store_class().data

        # refering product entity
        self.product_class = getattr(product_module, "Products")
        self.product_df = self.product_class().data

        # refering customer entity
        self.customer_class = getattr(customer_module, "Customers")
        if 'arg_rawpath' in kwargs:
            config.update({'Sseraw_dataHdfsRootPath': kwargs['arg_rawpath']})
        self.customer_df = self.customer_class().data

    def get_scores(self):
        """Populates self.df as the union of of one or more hive tables.  Configured by the self.get_scores_rules dict,
        which should be constructed like:

        {
            "customer_key": "customer_column",
            "score_column: "score",
            "score_type_column": "type",
            "rename_columns": [
                "col1",
                "col2",
                ...
            ],
            "groups":[
                {
                    "type": 1,
                    "score_db": "db_name",
                    "proposition": "proposition_name",
                    "model": "model_name",
                    "dttm": "latest",
                    "select_list": [
                        "col1",
                        "col2",
                        ...
                    ]
                },
                {
                    "type": 2,
                    "score_db": "db_name",
                    "proposition": "proposition_name",
                    "model": "model_name",
                    "dttm": "latest",
                    "select_list": [
                        "col1",
                        "col2",
                        ...
                    ]
                }
            ]
        }

        Each table specified in the "groups" key will be read in, selecting the columns in the "select_list".  These
        columns will then be renamed, using the "rename_columns" list (this is positional) and the tables will be
        unioned together.

        Additionally, a "score_type_column" column will be created, taking the value of the "type"
        field, and the instance attributes customer_key, score_column and score_type_column will be set
        """
        required_keys = [
            'customer_key',
            'score_column',
            'score_type_column',
            'rename_columns',
            'groups'
        ]
        missing_keys = [key for key in required_keys if
                        key not in self.get_scores_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from get_scores_rules object: {0}'.format(
                    missing_keys))

        customer_key = self.get_scores_rules['customer_key']
        score_column = self.get_scores_rules['score_column']
        score_type_column = self.get_scores_rules['score_type_column']
        rename_columns = self.get_scores_rules['rename_columns']
        groups = self.get_scores_rules['groups']

        df_list = []
        for group in groups:

            required_group_keys = [
                'type',
                'score_db',
                'proposition',
                'model',
                'dttm',
                'select_list'
            ]

            missing_group_keys = [key for key in required_group_keys if
                                  key not in group.keys()]
            if len(missing_keys) > 0:
                raise RuntimeError(
                    'Required keys missing from get scores group object: {0}'.format(
                        missing_group_keys))

            type_value = group['type']
            score_db = group['score_db']
            proposition = group['proposition']
            model = group['model']
            dttm = group['dttm']
            select_list = group['select_list']

            table = score_db + '.' + '_'.join(
                map(str, [proposition, model, dttm]))
            logger.info('Reading scores from Hive table: {0}'.format(table))
            scores_df = self.sqlContext.table(table)
            scores_df = scores_df.filter(scores_df.customer != 'UNKNOWN_DIMENSION')
            # check if select_columns exist in dataframe
            spark_tools.check_columns(df=scores_df, column_list=select_list)
            logger.info('Keeping only these columns: {0}'.format(
                ', '.join(select_list)))
            scores_df = scores_df.select(select_list)

            scores_df = spark_tools.rename_df_columns(
                input_df=scores_df,
                select_columns=select_list,
                rename_columns=rename_columns
            )
            logger.info('New schema:\n{0}'.format(scores_df.schema))

            scores_df = scores_df.withColumn(score_type_column, lit(type_value))
            df_list.append(scores_df)

        self.scores_df = spark_tools.union_all(df_list)

        score_store_key = self.get_scores_rules.get('score_store_key')
        if score_store_key is not None:
            self.scores_df = self.scores_df.repartition(800, "product",
                                                        "store")  # Need to check the column name either it is store or Store
        else:
            self.scores_df = self.scores_df.repartition(800, "product")

        # check the customer, score and score type cols are in our final df, and if so set the object attributes
        spark_tools.check_columns(self.scores_df, [customer_key, score_column,
                                                   score_type_column])
        self.customer_key = customer_key
        self.score_column = score_column
        self.score_type_column = score_type_column
        self.customer_base = self.customer_df.count()
        self.customer_scoring = self.scores_df.select(
            self.customer_key).distinct().count()

        logger.info("Total distinct customers in customer base: {0}".format(self.customer_base))
        logger.info("Distinct active customers in the scoring table: {0}".format(self.customer_scoring))

    def apply_exclusions(self, exclusion_df, show_counts=False):
        """ Apply exclusions to exclusion_df/generic_df, configured by self.exclusions_rules list, which should look like:

        [
            {
                "column": "col1",
                "description": "exclusion rule 1",
                "values": "false"
            },
            {
                "column": "col2",
                "description": "exclusion rule 2",
                "keep_list": true,
                "values": [
                    "11",
                    "12",
                    "13"
                ]
            }
        ]

        Each element of the list should be a dict, with the following keys (some optional)
            column: column to apply the exclusion to
            values: list of values to exclude (ie: where column not in *values)
            description: optional, will be printed to log if set
            substring_length: optional, column will be substring if set (ie: where substr(column, 1, N) not in *values)
            keep_list: optional, if set to "true" inverts logic (ie where column in *values)

        If self.exclusions_rules is None or zero length no exclusions will be applied.

        Args:
            show_counts - if True print before and after counts - WILL HAMMER PERFORMANCE, ONLY ENABLE FOR DEBUGGING
        """

        if self.exclusions_rules is None or len(self.exclusions_rules) == 0:
            logger.info('No exclusions to apply')
            return exclusion_df

        logger.info('Applying exclusions:')
        if show_counts:
            logger.warning(
                'show_counts set to True - this will severely impact performance!')

        # check all columns in exclusion list exist in our input dataframe
        columns = [exclusion['column'] for exclusion in self.exclusions_rules]

        spark_tools.check_columns(column_list=columns, df=exclusion_df)

        logger.info('Number of distinct cutomer before exclusion {cnt}:'.format(
            cnt=self.before_exclusion_distinct_cnt))

        for exclusion_number, exclusion in enumerate(self.exclusions_rules,
                                                     start=1):
            logger.info('Exclusion {0} of {1}: {2}'.format(
                exclusion_number,
                len(self.exclusions_rules),
                exclusion.get('description', 'no description').title())
            )
            values = exclusion['values']
            if isinstance(values, six.string_types):
                values = [values]
            column = exclusion['column']
            substring_length = exclusion.get('substring_length', False)
            # str() around the get() in case we've got a boolean in the json instead of a string
            keep_list = str(
                exclusion.get('keep_list', 'false')).lower() == 'true'

            if keep_list:
                exclude_msg = 'Keeping only'
            else:
                exclude_msg = 'Excluding all'
            if substring_length:
                substr_msg = '{0}.substr(1, {1})'.format(column,
                                                         substring_length)
            else:
                substr_msg = column
            logger.info('{0} rows where {1} is in list {2}'.format(exclude_msg,
                                                                   substr_msg,
                                                                   values.__repr__()))

            if substring_length:
                try:
                    substring_length = int(substring_length)
                except ValueError:
                    raise ValueError(
                        'substring_length value of \'{0}\' not castable to int'.format(
                            substring_length))
                for value in values:
                    if len(value) != substring_length:
                        logger.warning(
                            'Value of \'{0}\' does not match substring_length of \'{1}\''
                                .format(value, substring_length))
                compare_column = col(column).substr(1, substring_length)

            else:
                compare_column = col(column)

            if show_counts:
                count = exclusion_df.count()
                logger.info('Before count: {0}'.format(count))
                self.before_exclusion_cnt = count
            if keep_list:
                exclusion_df = exclusion_df.where(compare_column.isin(*values))
            else:
                exclusion_df = exclusion_df.where(~compare_column.isin(*values))
            if show_counts:
                count = exclusion_df.count()
                logger.info('After count: {0}'.format(exclusion_df.count()))
                self.after_exclusion_cnt = count

        return exclusion_df

    def apply_conditional_inclusions(self, df, show_counts=False):
        """ Apply conditional inclusions to self.df/generic_df based on self.conditional_inclusions_rules, which should look like

        [
            {
                "column": "col1",
                "description": "keep col1 > 0",
                "condition": "gt",
                "value": "0"
            },
            {
                "column": "col2",
                "description": "keep col2 <= 10",
                "condition": "le",
                "value": "10"
            },
        ]

        Each element of list should be a dict containing the following keys:
            column: column to apply the exclusion to
            condition: comparison operator to apply (eg: "gt", "le", "ne" etc..., )
            value: value to compare column to
            description: optional, will be printed to log if set

        If self.conditional_inclusions_rules is None or zero length no inclusions will be applied.

        Args:
            show_counts - if True print before and after counts - WILL HAMMER PERFORMANCE, ONLY ENABLE FOR DEBUGGING
        """
        if self.conditional_inclusions_rules is None or len(
                self.conditional_inclusions_rules) == 0:
            logger.info('No conditional inclusions to apply')
            return df

        logger.info('Applying conditional inclusions')
        if show_counts:
            logger.warning(
                'Show_counts set to True - this will severely impact performance!')

        # check all columns in exclusion list exist in our input dataframe
        columns = [exclusion['column'] for exclusion in
                   self.conditional_inclusions_rules]
        spark_tools.check_columns(column_list=columns, df=self.df)

        for n, excl in enumerate(self.conditional_inclusions_rules):
            column = excl['column']
            condition = excl['condition']
            value = excl['value']
            description = excl.get('description', 'no description')
            logger.info('Inclusion {0} of {1}: {2}'.format(n + 1, len(
                self.conditional_inclusions_rules), description))
            logger.info(
                'Keep only rows where {0} {1} {2}'.format(column, condition,
                                                          value))

            try:
                value = int(value)
            except ValueError:
                raise RuntimeError(
                    'Include_value of "%s" cannot be cast to integer' % value)
            if condition == 'lt':
                comparison_operator = operator.lt
            elif condition == 'le':
                comparison_operator = operator.le
            elif condition == 'eq':
                comparison_operator = operator.eq
            elif condition == 'ne':
                comparison_operator = operator.ne
            elif condition == 'ge':
                comparison_operator = operator.ge
            elif condition == 'gt':
                comparison_operator = operator.gt
            else:
                raise RuntimeError('Condition "%s" not recognised' % condition)

            if show_counts:
                logger.info('Before count: {0}'.format(self.df.count()))

            logger.info(
                'Applying ranging: keeping rows where {0} {1} {2}'.format(
                    column, condition, value))
            self.df = self.df.filter(
                comparison_operator(self.df[column], value))

            if show_counts:
                logger.info('After count: {0}'.format(self.df.count()))
        return df

    def apply_sensitive_products_exclusion(self):

        """Apply sensitivity exclusions to self.df
        If self.sensitivity_rules is None no sensitivity exclusions will be applied. configured by self.sensitivity_rules list, which should look like:

                         "sensitivity_rules": {
                    "SSEHiveDatabasePrefix": "cno",
                    "database": "pob",
                    "rules": {
                    "petFood": {
                        "product_attribute" : "InstoreSubAisle",
                      "dimension_grain": {
                        "customer": "customer",
                        "product": "instoreshelf",
                        "channel": "all",
                        "store": "all",
                        "cadenceattribute": "fis_week_id"
                      },
                      "dimension_filters": {
                        "product":{
                          "value" :["00029","00025","00026"]
                        }

                      },
                  "join_entity" :{
                    "database_prefix": "cno",
                    "entity_module": "coop_no.cmp_entities.products",
                    "entity_class": "Products",
                   "required_columns" :["InstoreSubAisle","Product"],
                        "score_column" : "product",
                        "entity_column" : "Product"
                        },

                        "join_conditions": {
                            "customer": "customer",
                            "product": "InstoreSubAisle"
                        },
                  "sensitivity_check_feature": "baskets_1w13w",
                  "sensitivity_exclusion_criteria": " > 0"
                }
                }
                },


        Each element is the form of dict.

        SSEHiveDatabasePrefix  - contain the databae prefix as per the markert.
        database  - database name
        rules  - contain nested disct and every key of this dict also a nested dict which specify the complete rule on diffrent category. eg. IsBabyproduct, Petproduct
        product_attribute - specify the attribute name in which rule need to apply
        dimension_grain - a nested dict, which contain the grain information on which view is created
        dimension_filters - cntain the values, which items needs to filter
        join_entity - If product_attribute is not in self.df then to get that attribute an entity needs to join.
        join_conditions - speciy the join condition
        sensitivity_check_feature - specify the feature grain - eg- baskets1w4w
        sensitivity_exclusion_criteria -specify the condition
        """

        if self.sensitivity_rules is None:
            logger.info('No sensitivity exclusions to apply')
            return self.df
        else:
            logger.info('Applying sensitivity exclusions')

            SSEHiveDatabasePrefix = self.sensitivity_rules[
                'SSEHiveDatabasePrefix']
            database = self.sensitivity_rules['database']

        for sensitivity_rule in self.sensitivity_rules["rules"]:
            logger.info("Applying sensitivity rule {rule_name}".format(
                rule_name=sensitivity_rule))
            dimension_grain = self.sensitivity_rules["rules"][sensitivity_rule][
                'dimension_grain']
            product_attribute = \
                self.sensitivity_rules["rules"][sensitivity_rule][
                    'product_attribute']

            join_conditions = self.sensitivity_rules['rules'][sensitivity_rule]['join_conditions']
            dimensions_to_select = join_conditions.keys()


            if isinstance(dimension_grain,dict):

                view_name = 'v_'
                for key in sorted(dimension_grain.keys()): view_name += key + dimension_grain[key] + '_'
                view_name += 'current'

                sensitivity_check_feature = self.sensitivity_rules['rules'][sensitivity_rule]['sensitivity_check_feature']
                logger.info('Looking for sensitivity_check_feature {sensitivity_check_feature} in {view_name}'.format(sensitivity_check_feature=sensitivity_check_feature,view_name=SSEHiveDatabasePrefix + '_' + database + '.' + view_name))

                feature_to_select = ''
                for key in sorted(dimension_grain.keys()):
                    if key != 'cadenceattribute':
                        feature_to_select += key + dimension_grain[key] + '_'
                feature_to_select = feature_to_select + sensitivity_check_feature.lower()

                logger.info('Selecting the following columns from feature view : {columns}' .format(columns=dimensions_to_select + [feature_to_select]))
                feature_df = self.sqlContext.table(SSEHiveDatabasePrefix + '_' + database + '.' + view_name).select(dimensions_to_select + [feature_to_select])


            else:
                view_name = dimension_grain

                latest_cadence = self.sqlContext.sql(
                    "select max({cadence}) from {prefix}_ssework.feature_run_log where lower(tab_name)='{prefix}_{database}.{feature_table}'".format(prefix=SSEHiveDatabasePrefix, database=database,feature_table=view_name,cadence = 'cadence_week')).collect()[0].asDict().values()[0]

                logger.info(
                    'Latest features created on fis_week_id ={latest_cadence}'.format(
                        latest_cadence=latest_cadence))

                feature_to_select =self.sensitivity_rules['rules'][sensitivity_rule]['sensitivity_check_feature']

                logger.info('Selecting the following columns from feature view {table} : {columns}' .format(table = view_name , columns=dimensions_to_select + [feature_to_select]))

                feature_df = self.sqlContext.table(SSEHiveDatabasePrefix + '_' + database + '.' + view_name).select(dimensions_to_select + [feature_to_select,'cadence_week'])

                feature_df = feature_df.where( feature_df['cadence_week'] == '{latest_cadence}'.format(latest_cadence=latest_cadence))
                feature_df = feature_df.drop(feature_df['cadence_week'])

            dimension_filters = \
                self.sensitivity_rules['rules'][sensitivity_rule][
                    'dimension_filters']

            for dimension_filter in dimension_filters:
                substring_length = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'dimension_filters'][
                        dimension_filter] \
                        .get('substring_length', False)
                value = self.sensitivity_rules['rules'][sensitivity_rule][
                    'dimension_filters'][dimension_filter] \
                    .get('value', False)

                if substring_length:
                    try:
                        substring_length = int(substring_length)
                    except ValueError:
                        raise ValueError(
                            'substring_length value of \'{0}\' not castable to int'.format(
                                substring_length))
                    for value in value:
                        if len(value) != substring_length:
                            logger.warning(
                                'Value of \'{0}\' does not match substring_length of \'{1}\''
                                    .format(value, substring_length))

                    logger.info("### Applying condition on {filter}".format(
                        filter=dimension_filter))
                    feature_df = feature_df.where(
                        feature_df[dimension_filter].substr(1,
                                                            substring_length).isin(
                            value))

                else:
                    feature_df = feature_df.where(
                        feature_df[dimension_filter].isin(value))
                    feature_df.show()

            sensitivity_exclusion_criteria = \
                self.sensitivity_rules['rules'][sensitivity_rule][
                    'sensitivity_exclusion_criteria']
            feature_df = feature_df.where(
                feature_to_select + sensitivity_exclusion_criteria)

            """
            if join_conditions["product"] not in self.df.columns:
                database_prefix = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'join_entity']["database_prefix"]
                entity_module = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'join_entity']["entity_module"]
                entity_class = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'join_entity']["entity_class"]
                required_columns = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'join_entity']["required_columns"]
                score_column = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'join_entity']["score_column"]
                entity_column = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'join_entity']["entity_column"]
                configs = {
                    'SSEHiveDatabasePrefix': '{0}'.format(database_prefix)}
                module = __import__(entity_module, fromlist=[entity_class])
                entity_class = getattr(module, entity_class)
                entity_df = entity_class(config=configs).data
                entity_df = entity_df.select(required_columns)
                entity_join_cond = [
                    entity_df[entity_column] == self.df[score_column]]

                self.df = self.df.join(entity_df, entity_join_cond,
                                       'left_outer').drop(
                    entity_df[entity_column])
            """
            # Joining with filtered feature set
            join_expression = []
            drop_columns = []
            for condition in join_conditions:
                drop_columns.append(feature_df[condition])
                join_expression.append(
                    self.df[join_conditions[condition]] == feature_df[
                        condition])

            logger.info('Join expression {join_expression}'.format(
                join_expression=join_expression))
            self.df = self.df.join(feature_df, join_expression,
                                   'left_outer')

            for column in drop_columns:
                self.df = self.df.drop(column)

            for dimension_filter in dimension_filters:

                value = self.sensitivity_rules['rules'][sensitivity_rule]['dimension_filters'][dimension_filter].get('value',False)

                if substring_length:
                    self.df = self.df.withColumn('drop_these', F.when(((self.df[product_attribute].substr(1,substring_length).isin(value)) & (self.df[feature_to_select].isNull())), 'Y').otherwise('N'))

                else:
                    self.df = self.df.withColumn('drop_these', F.when(((self.df[product_attribute].isin(value)) & (self.df[feature_to_select].isNull())), 'Y').otherwise('N'))

            # Filtering out insensitive allocations and removing drop_these column
            self.df = self.df.filter(self.df['drop_these'] != 'Y').drop(
                self.df['drop_these'])
            self.df = self.df.drop(self.df[feature_to_select])
        return self.df

    def apply_required_diversity(self, df, level=None):
        """Apply required diversity rules to self.df/generic_df, based on self.required_diversity_rules, which should be a list
        of dicts indicating column and diversity count, eg:

        [
            {"column":"promo", "count": 1},
            {"column":"product_subgroup", "count": 2}
        ],

        For each column in the list:
            rank self.df/generic_df by ascending self.score_type_column, descending self.score_column, partitioned by
            self.customer_key  and column specified, and keep only the top N ranked recommendation in each partition.
            Note that by convention it is assumed that score_types are ranked in ascending order, so that type 1
            recommendations will always take precedence over type 2 and so on.

            So, in the example above, keep only a single recommendation per promo, and the top two ranked
            recommendations per product_subgroup

        If self.required_diversity_rules is None or zero length no required diversity rules will be applied.
        """
        if self.required_diversity_rules is None or len(
                self.required_diversity_rules) == 0:
            logger.info('No required diversity rules to apply')
            return df

        if not isinstance(self.required_diversity_rules, list):
            raise ValueError(
                'required_diversity_rules is not a list: {0}'.format(
                    self.required_diversity_rules))

        check_columns = list()
        for d in self.required_diversity_rules:
            if not isinstance(d, dict):
                raise ValueError(
                    'Each element in required_diversity_rules should be a dict: {0}'.format(
                        d))
            required_keys = ['column', 'count']
            missing_keys = [key for key in required_keys if key not in d.keys()]
            if len(missing_keys) > 0:
                raise RuntimeError(
                    'Required keys missing from element of required_diversity_rules object: {0}'
                        .format(missing_keys))
            check_columns.append(d['column'])
        spark_tools.check_columns(df, check_columns)

        for diversity_rule in self.required_diversity_rules:

            diversity_column = diversity_rule['column']
            diversity_count = diversity_rule['count']

            logger.info(
                'Applying required diversity rule: keeping only top {0} ranked recommendation(s) for each {1}'
                    .format(diversity_count, diversity_column))

            # try to come up with a unique column name for the ranking column so we don't overwrite anything
            for i in range(0, 32):
                rank_col = 'req_div_rank_col' + str(i)
                if rank_col not in df.columns:
                    break
                rank_col = None
            if rank_col is None:
                raise RuntimeError(
                    'Unable to come up with a name for the required diversity ranking column not in input_df.columns:'
                        .format(df.columns)
                )

            order_by_columns = [df[self.score_type_column].asc(),
                                df[self.score_column].desc()]
            window_spec = Window.partitionBy(
                *[df[column] for column in
                  [self.customer_key, diversity_column, level] if
                  column]).orderBy(
                order_by_columns)
            df = df.withColumn(rank_col, row_number().over(window_spec))
            df = df.filter(df[rank_col] <= lit(diversity_count)).drop(
                df[rank_col])
        return df

    def generate_offer_position(self, df, level=None):
        """If required, apply preferred diversity rules to self_df/generic and create an offer position column, based on config
        in self.offer_position_rules dict, which should look like:

        {
            "preferred_diversity_column": "product_group",
            "preferred_diversity_count": "10",
            "offer_position_column_name": "offer_position"
        }

        The dict should contain keys:
            preferred_diversity_column: optional - column containing column to apply preferred diversity on
            preferred_diversity_count: optional - maximum number of rows to apply preferred diversity to
            offer_position_column_name: name of column to create holding offer position

        If preferred diversity is not required will rank by self.score_type_column (asc), self.score_column (desc) and
        create offer position as row number.

        If preferred diversity IS required dataframe will be re-sorted such that the first *preferred_diversity_count*
        recommendations for each customer have distinct values of preferred_diversity_column - duplicates will not be
        excluded, just moved down the offer position order.
        """

        required_keys = [
            'preferred_diversity_column',
            'preferred_diversity_count',
            'offer_position_column_name'
        ]
        missing_keys = [key for key in required_keys if
                        key not in self.offer_position_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from offer_position_rules object: {0}'.format(
                    missing_keys))

        pref_diversity_column = self.offer_position_rules[
            'preferred_diversity_column']
        pref_diversity_count = self.offer_position_rules[
            'preferred_diversity_count']
        offer_pos_col_name = self.offer_position_rules[
            'offer_position_column_name']

        if pref_diversity_column:
            spark_tools.check_columns(df, pref_diversity_column)

        initial_df = df

        order_by_columns = [col(self.score_type_column).asc(),
                            col(self.score_column).desc()]

        if pref_diversity_column is None:  # just rank by type(if provided) and score)
            # initial_df = initial_df.repartition(1050,self.customer_key)
            ws = Window.partitionBy(
                *[col(column) for column in [self.customer_key, level] if
                  column]).orderBy(
                order_by_columns)
            df = initial_df.withColumn(offer_pos_col_name,
                                       row_number().over(ws))

        else:  # apply diversity
            if pref_diversity_count is None:
                raise RuntimeError(
                    'If diversity column is specified, diversity count must also be set')

            # rank1 = 1 indicates top ranked recommendation for each value of pref_diversity_column
            ws = Window.partitionBy(col(self.customer_key),
                                    col(pref_diversity_column)).orderBy(
                order_by_columns)
            initial_df = initial_df.withColumn('pref_div_rank1',
                                               row_number().over(ws))

            # rank within each value of rank1 for each cust - we're only interested where rank1 = 1 though
            ws = Window.partitionBy(
                *[col[column] for column in
                  [self.customer_key, 'pref_div_rank1', level] if
                  column]).orderBy(
                order_by_columns)
            initial_df = initial_df.withColumn('pref_div_rank2',
                                               row_number().over(ws))

            # flag rows where rank1 = 1 and rank2 <= pref_diversity_count - these are to be prioritised
            initial_df = initial_df.withColumn(
                'pref_div_priority',
                when(
                    (col('pref_div_rank1') == lit(1)) & (
                        col('pref_div_rank2') <= lit(pref_diversity_count)),
                    lit(1)
                ).otherwise(
                    lit(2)
                )
            ).drop('pref_div_rank1').drop('pref_div_rank2')

            # create offer position column, prioritising recommendations where pref_div_priority = 1
            order_by_columns = [
                col('pref_div_priority').asc(),
                col(self.score_type_column).asc(),
                col(self.score_column).desc()
            ]

            ws = Window.partitionBy(
                *[col[column] for column in [self.customer_key, level] if
                  column]).orderBy(
                order_by_columns)
            df = initial_df.withColumn(offer_pos_col_name,
                                       row_number().over(ws)).drop(
                'pref_div_priority')
        return df


    def random_shuffle(self):
        """Randomise the order of recommendations for each customer in self.df, based on rules in
        self.random_shuffle_rules dict, eg:

        {
           "ranking_column": "offer_position",
           "start_position": 2
        }

        Keys are:
            customer_key: customer identifier
            ranking_column: column to randomise - will be overwritten with a random rank
            start_position: all rows with ranking_column value less than this will not be randomised

        If self.random_shuffle_rules is None no shuffling will occur.
        """
        if self.random_shuffle_rules is None:
            logger.debug(
                'Random shuffle step skipped because random_shuffle_rules key is Null')
            return

        required_keys = [
            'ranking_column',
            'start_position'
        ]
        missing_keys = [key for key in required_keys if
                        key not in self.random_shuffle_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from random_shuffle_rules object: {0}'.format(
                    missing_keys))

        ranking_column = self.random_shuffle_rules['ranking_column']
        start_position = self.random_shuffle_rules['start_position']

        spark_tools.check_columns(self.df, ranking_column)

        logger.info(
            'Randomising the order of recommendations in position {0} and upwards'.format(
                start_position))

        window_spec = Window.partitionBy(self.customer_key).orderBy(
            col('random_shuffle').asc())
        df_with_shuffle_col = self.df.withColumn(
            'random_shuffle',
            when(
                col(ranking_column) < start_position, col(ranking_column)
            ).otherwise(
                start_position + rand(seed=123)
            )
        )
        self.df = df_with_shuffle_col.withColumn(
            ranking_column,
            row_number().over(window_spec)
        ).drop('random_shuffle')


    def create_relevancy_score(self, df):
        """Create a relevancy score column on self.df/self.generic_df, based on rules in self.relevancy_score_rules, eg:

        {
            "ranking_column": "offer_position"
            "output_column": "relevancy_score"
        }
        Will create output_column as 1 / ranking_column
        """

        required_keys = ['ranking_column', 'output_column']
        missing_keys = [key for key in required_keys if
                        key not in self.relevancy_score_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from relevancy_score_rules object: {0}'.format(
                    missing_keys))
        ranking_column = self.relevancy_score_rules['ranking_column']
        output_column = self.relevancy_score_rules['output_column']
        spark_tools.check_columns(df, ranking_column)
        logger.info('Creating relevancy score column \'{0}\' as 1/{1}'.format(
            ranking_column, output_column))
        df = df.withColumn(output_column,
                           round((1 / df[ranking_column]), 4))

        convert_to_required_format = F.udf(lambda x: "{0:.8f}".format(x))
        df = df.withColumn(output_column,
                           convert_to_required_format(output_column))
        return df

    def write_results_to_hdfs(self, path):
        """Write self.df to specified HDFS path, as a parquet file with 200 partititons"""
        spark_tools.write_to_hdfs(input_df=self.df, hdfs_path=path)

    @abc.abstractmethod
    def quality_check(self):
        pass


    ## The method below has been commented because we would need an alternative solution for notifying from GCP.
    # def send_notification_mail(self, file_path):
    #
    #     assert isinstance(self.send_to, list)
    #     server = "mail.dunnhumby.com"
    #     msg = MIMEMultipart()
    #     msg['From'] = self.send_from
    #     msg['To'] = COMMASPACE.join(self.send_to)
    #     msg['Date'] = formatdate(localtime=True)
    #     msg['Subject'] = self.subject
    #     msg.attach(MIMEText(self.message, 'html'))
    #
    #     for f in file_path or []:
    #         with open(f, "rb") as fil:
    #             part = MIMEApplication(
    #                 fil.read(),
    #                 Name=basename(f)
    #             )
    #         # After the file is closed
    #         part[
    #             'Content-Disposition'] = 'attachment; filename="%s"' % basename(
    #             f)
    #         msg.attach(part)
    #
    #     smtp = smtplib.SMTP(server)
    #     smtp.sendmail(self.send_from, self.send_to, msg.as_string())
    #     smtp.close()

    @abc.abstractmethod
    def cap_and_infill_recommendations(self):
        pass

    @abc.abstractmethod
    def get_banners(self):
        pass

    @abc.abstractmethod
    def proposition_specific_qa(self, hdfs_file_output_path, column_list):
        pass

    def vip_customer(self, hdfs_file_output_path, vip_customer_seed_path):

        """
        this fuction is dependends on function --category_wise_distribution(
        self, allocation_attribute_value,hdfs_file_output_path)


        # getting all all level of data for VIP customer
        # VIP customer seed shuld be in csv format and over the hdfs
        # VIP seed will have only one column i.e. "customer"

        :param hdfs_file_output_path:
        :param vip_customer_seed_path:
        :return:
        """

        vip_customer_df = spark_tools.get_df_from_csv(self.sqlContext,
                                                      vip_customer_seed_path)
        # self.category_wise_distri_df -- data frame which is generated after
        #  joining self.df and product entity.

        vip_customer_df = self.category_wise_distri_df.join(vip_customer_df,
                                                            ["customer"],
                                                            "left_semi")
        vip_customer_df.coalesce(300)
        spark_tools.write_csv_to_hdfs(vip_customer_df,
                                      hdfs_file_output_path +
                                      "/VIP_customer")

    def detailed_qualitycheck(self):

        """
        Perform QA check and stores the files in all hierarchy level of
        allocated
        customers
        :param
        detailed_quality_check_rules: QA rules defined to create sign off csv files
        """

        if isinstance(self.detailed_quality_check, dict):

            hdfs_file_output_path = self.detailed_quality_check.get('hdfs_file_output_path')
            column_list = self.detailed_quality_check.get('column_list')
            vip_customer_seed = self.detailed_quality_check.get(
                'vip_customer_seed')
            vip_customer_seed_path = self.detailed_quality_check.get(
                'vip_customer_seed_path')

            logger.info("Detialed QA check  ON")
            logger.info("Total allocated volumn - {cnt}".format(
                cnt=self.customer_final))

            # checking the duplicates in allocated customers data frame

            #allocated_file_df = self.df.distinct().count()

            #if allocated_file_df == self.customer_final:
            #    logger.info("There are no duplicates in the allocation file ")
            #else:
            #    logger.info("There are duplicates in the allocation file ")

            self.proposition_specific_qa(hdfs_file_output_path, column_list)

            # logger.info("Number of disctint product in product entity {cnt}".format(cnt=self.product_df.select("Product").distinct().count()))
            # logger.info("Number of distinct custome in customer class {cnt}".format(cnt=self.customer_df.select("Customer").distinct().count()))
            # logger.info("Number of disticnt store in store entity {cnt}".format(cnt=self.store_df.select("Store").distinct().count()))

            # Getting stats over allocation output df
            # logger.info("Number of distinct Products in allocation output {cnt}".format(cnt=self.df.select("product").distinct().count()))

            # getting the Number of product allocated to number of customer
            num_product_per_num_of_customer = self.df.select("customer","product").distinct().groupBy("customer").count().withColumnRenamed("count","Product_count").groupBy("Product_count").count().withColumnRenamed("count","Customer_count").orderBy("count")

            num_product_per_num_of_customer.coalesce(100)
            spark_tools.write_csv_to_hdfs(num_product_per_num_of_customer,hdfs_file_output_path + "/num_product_per_num_of_customer")

            # getting all all level of data for VIP customer
            # VIP customer seed should be in csv format and over the hdfs
            # VIP seed will have only one column i.e. "customer"

            if vip_customer_seed:
                self.vip_customer(hdfs_file_output_path, vip_customer_seed_path)

            # allocated customers distribution on Banners

            customer_distribu_df = self.df.select("customer",
                                                  "Banner").distinct().groupBy(
                "Banner").count().withColumnRenamed("count", "Customer_count")

            customer_distribu_df.coalesce(100)
            spark_tools.write_csv_to_hdfs(customer_distribu_df,
                                          hdfs_file_output_path + "/customers_per_Banner")


    @abc.abstractmethod
    def allocate(self, path):
        """Abstract method - in child classes should call each method in turn to run the algorithm, eg:
        self.get_scores()
        self.get_banners()
        self.apply_exclusions()
        self.apply_conditional_inclusions()
        self.apply_sensitive_products_exclusion()
        self.apply_required_diversity()
        self.generate_offer_position()
        self.cap_and_infill_recommendations()
        self.write_results_to_hdfs(path)
        """
        pass
