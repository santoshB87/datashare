import logging
import sys
from dunnhumby.cmp_allocation.propositions import base
from dunnhumby.cmp_allocation import spark_tools

logger = logging.getLogger(__name__)


# pylint: disable=super-on-old-class
# pylint: disable=bad-continuation
# pylint: disable=line-too-long




class ComplementsAllocation(base.Allocation):
    """Complements Allocation class
    subclasses:
        Complements
    methods:
        __init__ (calls super().__init__())
        _set_config (calls super()._set_config())
        allocate
    """

    def __init__(self, config_file, algorithm, variation):
        super(ComplementsAllocation, self).__init__(config_file, algorithm, variation)


    def _set_config(self):
        self.get_scores_rules = self.cfg.get_item(keys='input_scores',
                                                  mandatory=True)
        self.allocation_rules = self.cfg.get_item(keys='allocation_rules',
                                                  mandatory=True)

    def get_banners(self):
        pass


    def proposition_specific_qa(self, hdfs_file_output_path, column_list):
        pass

    def quality_check(self):
        pass

    def get_scores(self):
        """Populates self.df after reading complements product data dumped as parquet file from the location 
        configured in hdfs_input_path.
        
        The input columns will be picked up from input_columns and will renamed using output_columns.
        """
        required_keys = [
            'hdfs_input_path',
            'input_columns',
            'rename_columns'
        ]

        missing_keys = [key for key in required_keys if
                        key not in self.get_scores_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from get_scores_rules object: {0}'.format(
                    missing_keys))

        hdfs_input_path = self.get_scores_rules['hdfs_input_path']
        input_columns = self.get_scores_rules['input_columns']
        rename_columns = self.get_scores_rules['rename_columns']

        logger.info('Reading scores from parquet files: {0}'.format(hdfs_input_path))
        scores_df = self.sqlContext.read.parquet(hdfs_input_path)

        # check if select_columns exist in dataframe
        spark_tools.check_columns(df=scores_df, column_list=input_columns)
        logger.info('Keeping only these columns: {0}'.format(
            ', '.join(input_columns)))
        scores_df = scores_df.select(input_columns)

        scores_df = spark_tools.rename_df_columns(
            input_df=scores_df,
            select_columns=input_columns,
            rename_columns=rename_columns
        )
        logger.info('New schema:\n{0}'.format(scores_df.schema))

        self.scores_df = scores_df


        logger.info("Total distinct products in product base: {0}".format(self.scores_df.select("Product").distinct().count()))


    def generate_offer_position(self, df, level=None):
        pass


    def cap_and_infill_recommendations(self):

        """cap recommendations in self.df at required number of complement products range that we need to keep, based on rules in
        self.allocation_rules dict, eg:

                "allocation_rules": {
          "ranking_column": "rank",
          "infill_type": null,
          "offer_cap": 10,
          "infill_cap": null,
          "minimum_offers": 10
        },
        """
        required_keys = [
            'ranking_column',
            'minimum_offers',
            'offer_cap'
        ]
        missing_keys = [key for key in required_keys if
                        key not in self.allocation_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError('Required keys missing from allocation_rules object: {0}'.format(missing_keys))

        ranking_column = self.allocation_rules['ranking_column']
        minimum_offers = self.allocation_rules['minimum_offers']
        offer_cap = self.allocation_rules['offer_cap']

        where_clause = '{ranking_column} <= {offer_cap}'.format(ranking_column=ranking_column, offer_cap=offer_cap)
        self.df = self.df.filter(where_clause)
        # Apply quality checks on the final allocation file being sent.
        # It performs checks like total promotions to total customer ratio,
        # percentage of customers allocated, dropped. Earlier this process was done manually so now this is automated.

        # persisting df for QA
        self.df = self.df.coalesce(400)
        self.df.persist()

        if self.df.count() == 0:
            sys.exit("Allocation file is empty. Terminating the application")


    def allocate(self, path):
        self.get_scores()
        self.df = self.scores_df
        self.cap_and_infill_recommendations()
        self.write_results_to_hdfs(path)

