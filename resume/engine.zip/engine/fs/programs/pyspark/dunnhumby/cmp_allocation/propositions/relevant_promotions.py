import logging
import sys

import pyspark.sql.types as pt
import tools.six as six
from dunnhumby.cmp_allocation import spark_tools
from dunnhumby.cmp_allocation.propositions import base
from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark import StorageLevel
# noinspection PyUnresolvedReferences
from pyspark.sql.functions import col, when, current_date, date_add, date_sub,\
    udf, max, lit, dense_rank, \
    countDistinct, row_number, format_string, count, min

logger = logging.getLogger(__name__)


class RPAllocation(base.Allocation):
    """Relevant Promotions Allocation class
    subclasses:
        Allocation
    methods:
        __init__ (calls super().__init__())
        _set_config (calls super()._set_config())
        boosting
        get_promos
        get_active_promotions
        join_promotions
        limit_alcoholic_drinks_recommendations
        allocate
    """

    def __init__(self, config_file, algorithm, variation):
        self.boosting_rules = None
        self.get_promo_rules = None
        self.join_promotions_rules = None
        self.alcohol_rules = None
        self.cap_df = []
        self.offer_relevance_required = None
        self.promo_df = None
        self.generic_table = None
        self.join_promo_df = None
        super(RPAllocation, self).__init__(config_file, algorithm, variation)

    def _set_config(self):
        self.boosting_rules = self.cfg.get_item(keys='boosting_rules',
                                                mandatory=True)
        self.get_promo_rules = self.cfg.get_item(keys='input_promos',
                                                 mandatory=True)
        self.join_promotions_rules = self.cfg.get_item(keys='promo_join_rules',
                                                       mandatory=True)
        self.alcohol_rules = self.cfg.get_item(keys='alcohol_rules',
                                               mandatory=True)
        self.offer_relevance_required = self.cfg.get_item(
            keys='offer_relevance_required', mandatory=False)
        self.generic_table = self.cfg.get_item(keys='generic_view',
                                               mandatory=False)
        super(RPAllocation, self)._set_config()

    def boosting(self):
        """Boost scores in self.df by left joining onto a table of boost values by a specified key and adding the boost
        value to the score, controlled by rules in self.boosting_rules, eg:

        {
            "boost_database": "db_name",
            "boost_table": "table_name",
            "boost_constant_key": "boost_value",
            "boost_product_id": "product_id",
            "score_product_id": "product_id"
        }

        This function is intended to be used to boost seasonal products at the appropriate time of year, for example
        in December the boost table could be populated with Christmas products.

        Keys are:
            boost_database: database containing table of boost values
            boost_table: table of boost values
            boost_constant_key: column containing boost value
            boost_product_id: column on boost table to joint to self.df
            score_product_id: column on self.df to join to boost values table

        If self.boosting_rules is None no boosting will be applied.
        """
        if self.boosting_rules is None:
            logger.info('No product boosting required, skipping step')
            return

        required_keys = ['boost_database', 'boost_table', 'boost_constant_key',
                         'boost_product_id', 'score_product_id']
        missing_keys = [key for key in required_keys if
                        key not in self.boosting_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from boosting_rules object'.format(
                    missing_keys))

        boost_database = self.boosting_rules['boost_database']
        boost_table = self.boosting_rules['boost_table']
        boost_constant_key = self.boosting_rules['boost_constant_key']
        boost_product_id = self.boosting_rules['boost_product_id']
        score_product_id = self.boosting_rules['score_product_id']

        logger.info('Boosting {0}'.format(boost_product_id))

        boosting_table = '.'.join([boost_database, boost_table])
        boosting_df = self.sqlContext.table(boosting_table)

        # Find if the joining key is the  same ; if True rename the boosting_key from the boosting df
        if score_product_id == boost_product_id:
            boosting_df = boosting_df.withColumnRenamed(boost_product_id,
                                                        'boost_key')
            self.df = self.df.join(boosting_df,
                                   self.df[score_product_id] == boosting_df[
                                       'boost_key'], 'leftouter')
        else:
            self.df = self.df.join(boosting_df,
                                   self.df[score_product_id] == boosting_df[
                                       boost_product_id], 'leftouter')
        self.df = self.df.na.fill({boost_constant_key: 0})

        self.df = self.df.withColumn(self.score_column,
                                     col(self.score_column) + col(
                                         boost_constant_key))
        self.df = spark_tools.dropAll(self.df, *boosting_df.columns)


    def get_promos(self):
        """populate self.promo_df with promotions data from a given hive db/table, keeping only promotions that are
        active today and for the next N days, as defined in self.get_promo_rules dict, eg:

        {
            "promo_module": "tesco_ie.cmp_entities.product_on_promotion_in_store",
            "promo_class": "ProductOnPromotionInStore",
            "columns": [
                "Promotion",
                "Product",
                "Store",
                "PromotionStartDatetime",
                "PromotionEndDatetime",
                "PromotionZone"
            ],
            "promo_active_days": 6
        }
        """
        required_keys = ["promo_module", "columns", "promo_active_days",
                         "database_prefix", "promo_class"]

        missing_keys = [key for key in required_keys if
                        key not in self.get_promo_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from input_promos object: {0}'.format(
                    missing_keys))

        promo_module = self.get_promo_rules['promo_module']
        columns = self.get_promo_rules['columns']
        keep_inactive_promos = self.get_promo_rules.get(
            'keep_inactive_promos') or False
        active_days = self.get_promo_rules['promo_active_days']
        active_days_offset = self.get_promo_rules.get('active_days_offset') or 0
        database_prefix = self.get_promo_rules['database_prefix']

        promo_class = self.get_promo_rules['promo_class']

        if isinstance(columns, six.string_types):
            columns = [columns]

        try:
            active_days = int(active_days)
        except ValueError:
            raise ValueError(
                'active_days value of {0} cannot be cast to int'.format(
                    active_days))

        logger.info(
            'Getting all promotions that are active today and that will remain active for at least another {0} days offset by {1}'.format(
                active_days, active_days_offset))

        module = __import__(promo_module, fromlist=[promo_class])
        promo_class = getattr(module, promo_class)
        self.promo_df = promo_class().data
        logger.info('QA : Number of Promotions in the Promo Entity : {0}'.format(self.promo_df.select(self.promo_df.Promotion).distinct().count()))
        self.promo_total = self.promo_df.select(
            self.promo_df.Promotion).distinct().count()

        spark_tools.check_columns(df=self.promo_df, column_list=columns)
        self.promo_df = self.promo_df.select(columns)

        if not keep_inactive_promos:
            #explicitly type casting so as to correct timestamp comparison.
            self.promo_df = self.promo_df.where(
                (self.promo_df['PromotionStartDatetime'] <= date_add(
                    current_date(), active_days_offset).cast(pt.TimestampType())) & (
                    self.promo_df['PromotionEndDatetime'] >= date_add(
                        current_date(), active_days).cast(pt.TimestampType())))

            logger.info(
                'QA :Number of Active Promotions in the Promo Entity : {0}'.format(self.promo_df.select(self.promo_df.Promotion).distinct().count()))
            self.promo_active = self.promo_df.select(
                self.promo_df.Promotion).distinct().count()

        else:
            logger.info(
                'Keep Inactive Promotions flagged. Skipping date filters.')
            self.promo_active = 0
        self.promo_df.persist()


    def get_best_promotion_for_a_product(self):
        discount = self.get_promo_rules['discount']
        allocation_key_attribute = self.allocation_rules[
            'allocation_key_attribute']
        if discount is None:
            # getting count of number of stores a promotion is active in per allocation_key_attribute
            promo_store_df = self.promo_df.select(
                *[key for key in
                  ['Promotion', allocation_key_attribute, 'Store'] if
                  key]).distinct().groupBy(
                *[key for key in ['Promotion', allocation_key_attribute] if
                  key]).count()

            self.promo_df = self.promo_df.join(promo_store_df,
                                               [key for key in ['Promotion',
                                                                allocation_key_attribute]
                                                if key])

            temp_df = self.promo_df.select(
                *[key for key in
                  ['Product', 'Promotion', 'count', allocation_key_attribute] if
                  key]).distinct()

            wc = Window.partitionBy(
                *[temp_df[key] for key in ['Product', allocation_key_attribute]
                  if key])

            temp_df = temp_df.withColumn("rank", row_number().over(wc)).orderBy(
                col('count').desc(),col('Promotion').desc()).where(
                'rank = 1').drop('rank').select(
                *[key for key in
                  ['Promotion', allocation_key_attribute, 'Product'] if key])

            self.promo_df = self.promo_df.join(temp_df,
                                               [key for key in ['Promotion',
                                                                allocation_key_attribute,
                                                                'Product'] if
                                                key], 'inner').drop('count')

        else:
            temp_df = self.promo_df.groupBy(['Product', 'Store']).agg(
                max('DiscountAmount').alias("DiscountAmount")).drop('Store')
            #making window so that a promotion having same maximum discount could pick only one using rank.
            wc = Window.partitionBy("Product", "Store").orderBy("Promotion")
            self.promo_df = self.promo_df.join(temp_df, ["Product", "DiscountAmount"]).\
                withColumn("rank", row_number().over(wc)).where('rank =1').drop('rank')
            self.promo_df = self.promo_df.withColumnRenamed("DiscountAmount", "Discount")
        # Convert the promo start date time and promo end date time into the required timestamp format
        out_format = '%Y/%m/%d %H:%M:%S'
        convert_to_required_time_stamp = udf(lambda x: x.strftime(out_format))
        self.promo_df = self.promo_df.withColumn('PromotionStartDatetime',
                                                 convert_to_required_time_stamp(
                                                     'PromotionStartDatetime'))
        self.promo_df = self.promo_df.withColumn('PromotionEndDatetime',
                                                 convert_to_required_time_stamp(
                                                     'PromotionEndDatetime'))

        self.promo_df = self.promo_df.withColumn('StoreRegion', lit(None).cast(
            pt.StringType()))
        # TODO Handle generic allocation_key_attribute - allocation_key_attribute can be any field in Product/Promotion/Store hierarchy
        if allocation_key_attribute != 'Banner':
            self.promo_df = self.promo_df.drop(self.promo_df['Banner'])
            self.promo_df = self.promo_df.withColumn('Banner', lit(None).cast(
                pt.StringType()))

        # TODO Get Min end_date and Max start date at Product, Allocation Key Attribute level
        self.promo_df = self.promo_df.dropDuplicates(
            [key for key in ['Product', allocation_key_attribute] if key])
        self.promo_df.persist()
        logger.info("QA : unique promotions after applying best promotions for product logic : {}".format(self.promo_df.select("Promotion").distinct().count()))


    def join_promotions(self):
        """join self.promo_df onto self.df, implicitly applying promotion store ranging if required, controlled by
        self.join_promotions_rules dict, eg:
        {
            "promo_store_key": "store",
            "promo_product_key": "product",
            "score_product_key": "product"
        }

        keys are:
            promo_store_key: store join key on self.promo_df
            score_store_key: store join key on self.df or None
            promo_product_key: product join key on self.promo_df
            score_product_key: product join key on self.df

        if score_store_key is specified join on both product and store, implicitly applying promo store ranging,
        otherwise drop store key from promo data, deduplicate and join on just product.
        """

        # TODO Store Ranging

        required_keys = ['promo_store_key', 'promo_product_key',
                         'score_product_key']
        missing_keys = [key for key in required_keys if
                        key not in self.join_promotions_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from promo_ranging object: {0}'.format(
                    missing_keys))

        promo_product_key = self.join_promotions_rules['promo_product_key']
        score_product_key = self.join_promotions_rules['score_product_key']

        spark_tools.check_columns(self.promo_df, [promo_product_key])
        spark_tools.check_columns(self.df, score_product_key)

        join_condition = self.df[score_product_key] == self.promo_df[
            promo_product_key]

        # self.df = self.promo_df.join(self.df, join_condition).drop(self.promo_df[promo_product_key])
        self.df = self.df.join(self.promo_df, join_condition).drop(
            self.promo_df[promo_product_key])

        self.df.persist()
        self.df.printSchema()
        self.join_promo_df = self.df

    def limit_alcoholic_drinks_recommendations(self, df, level=None):
        """If required, ensure we only make up to N alcoholic drinks recommendation per customer, controlled by
        self.alcohol_rules dict, eg:

        {
            "ranking_column": "score",
            "product_identifier_column": "product",
            "substring_length' : N
            "product_identifier_strings": ["W"],
            "drinks_recommended_value" 1
        }

        keys are:
            ranking_column: column by which recommendations are ranked
            product_identifier_column: column to match first N characters against list of chars to identify alcohol
                products
            product_identifier_column: list of characters used to identify alcohol products
            drinks_recommended_value: maximum number of alcohol product recommendations per customer

        if self.alcohol_rules is None method will do nothing.
        """
        if self.alcohol_rules is None:
            logger.info('No Alcohol rules to apply')
            return df

        required_keys = ['ranking_column', 'product_identifier_column',
                         'product_identifier_strings',
                         'drinks_recommended_value', "substring_length"]
        missing_keys = [key for key in required_keys if
                        key not in self.alcohol_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from alcohol_rules object'.format(
                    missing_keys))

        ranking_column = self.alcohol_rules['ranking_column']
        product_identifier_column = self.alcohol_rules[
            'product_identifier_column']
        product_identifier_strings = self.alcohol_rules[
            'product_identifier_strings']
        drinks_recommended_value = self.alcohol_rules[
            'drinks_recommended_value']
        substring_length = self.alcohol_rules['substring_length']

        check_cols = [product_identifier_column, ranking_column]
        spark_tools.check_columns(df, check_cols)

        if isinstance(product_identifier_strings, six.string_types):
            product_identifier_strings = [product_identifier_strings]

        try:
            drinks_recommended_value = int(drinks_recommended_value)
        except ValueError:
            raise ValueError(
                'drinks_recommended_value \'{0}\' cannot be cast to integer'.format(
                    drinks_recommended_value))

        df = df.withColumn('alcohol_drink_flag',
                           when(col(product_identifier_column).substr(1,
                                                                      substring_length).isin(
                               *product_identifier_strings),
                               1).otherwise(0))

        window_spec = Window.partitionBy(
            *[df[column] for column in
              [self.customer_key, 'alcohol_drink_flag', level] if
              column]).orderBy(
            df[self.score_type_column].asc(), df[ranking_column].desc())

        logger.info(
            'Keep the top {0} alcoholic drink recommendation with the highest {1}.'.format(
                drinks_recommended_value,
                ranking_column))
        df = df.withColumn('rank_alcohol', row_number().over(window_spec)).where(
            (col('alcohol_drink_flag') == 0) | (
                (col('rank_alcohol') <= '{0}'.format(
                    drinks_recommended_value)) & (
                    col('alcohol_drink_flag') == 1))).drop(
            'alcohol_drink_flag').drop('rank_alcohol')
        return df

    def create_offer_relevancy_score(self, df, level=None):
        """ Add offer_relevancy score as the max value of the prod-relevancy-score
        i.e. max(score) of all the products falling under that offer """

        if self.offer_relevance_required:
            w = Window.partitionBy(
                *[column for column in [self.customer_key, level, 'Promotion']
                  if column]).orderBy(
                col("relevance").desc())
            df = df.withColumn("offerrelevance", max(df['relevance']).over(w))
        else:
            df = df.withColumn('offerrelevance', lit(0).cast(pt.IntegerType()))

        return df

    def roll_up_relevance_scores(self, df, roll_up_to, level=None):
        """
        create column with rolled up product relevance scores
        :param df: dataframe with relevance scores
        :param roll_up_to: level to roll up relevance scores to
        :param level: additional group by clauses
        :return: df with an additional column containing rolled up scores
        """
        w = Window.partitionBy(
            *[column for column in [self.customer_key, roll_up_to, level] if
              column]).orderBy(
            col("relevance").desc())
        df = df.withColumn("%s_relevance" % roll_up_to,
                           max(df['relevance']).over(w))
        return df

    def get_banners(self):

        """
        Banner rule is to include the Banner in the dataframe and apply the filter if needed.
        join the Promo and score df.

        Create a banner column on self.df/self.promo_df, based on rules in self.banner_rules, eg:

        "banner_rules":{
                "database_prefix": "cascod",
                "banner_filter" : null,
                "store_module" : "ci_colombia.cmp_entities.stores",
                "proposition" : "usuals",
                          },
        """

        if self.banner_rules is None or len(self.banner_rules) == 0:
            logger.info('No Banner rule to apply')
            self.promo_df = self.promo_df.withColumn('Banner', lit(None).cast(
                pt.StringType()))
            self.promo_df = self.promo_df.withColumn('StoreRegion',
                                                     lit(None).cast(
                                                         pt.StringType()))
            # self.promo_df = self.promo_df.withColumn("Store", lit(None).cast(
            #     pt.StringType()))
            return

        logger.info('Applying Banner rules')
        required_keys = ['banner_filter']
        missing_keys = [key for key in required_keys if
                        key not in self.banner_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from banner object: {0}'.format(
                    missing_keys))

        banner_filter = self.banner_rules['banner_filter']

        if banner_filter is None:

            self.store_df = self.store_df.select(col('Store'), col('Banner'),
                                                 col('StoreRegion'))

        else:
            logger.info(
                'Filtering promotions to following banners : {banner_filter}'.format(
                    banner_filter=banner_filter))

            self.store_df = self.store_df[
                self.store_df.Banner.isin(banner_filter)].select(col('Store'),
                                                                 col('Banner'),
                                                                 col(
                                                                     'StoreRegion'))

        self.promo_df = self.promo_df.join(self.store_df, ["Store"], 'inner')
        self.promo_df = self.promo_df.dropDuplicates()
        # logger.info('df count after removing store and adding Banner {cnt}'.format(cnt=self.promo_df.count()))
        # self.promo_df.printSchema()
        #
        # self.promo_df.groupBy("Banner").agg(countDistinct("Promotion")).alias("count").show()
        self.promo_df.drop(col('count'))

    def quality_check(self, quality_check_rules):

        """Perform various QA checks on the final allocation file being sent
        :param
        quality_check_rules: QA rules defined to create sign off csv files
        """

        logger.info("Starting quality checks")
        sign_off_files = quality_check_rules.get('sign_off_files')
        vip_customers_list = quality_check_rules.get('vip_customers')

        frequency_distribution_of_number_of_promos_allocated_each_customer = quality_check_rules.get(
            'frequency_distribution_of_number_of_promos_allocated_each_customer')
        hdfs_file_output_path = quality_check_rules.get('hdfs_file_output_path')
        allocation_key = self.allocation_rules.get('allocation_key')

        if sign_off_files:
            customer_promo_ratio_df = self.df.groupBy(
                self.customer_key).count().withColumnRenamed('count',
                                                             'promocount').distinct().groupBy(
                'promocount').count().orderBy('promocount')
            spark_tools.write_csv_to_hdfs(input_df=customer_promo_ratio_df,
                                          hdfs_path=hdfs_file_output_path + "/customer_promo")

            spark_tools.write_csv_to_nfs(input_df=customer_promo_ratio_df,
                                         nfs_path=self.nfs_file_output_path + "/customer_promo/")

            promotion_count_df = self.df.groupBy('Promotion').count().orderBy(
                'count')
            spark_tools.write_csv_to_hdfs(input_df=promotion_count_df,
                                          hdfs_path=hdfs_file_output_path + "/promo_count")

            Banner_count_df = self.df.groupBy("Banner").agg(
                {"Promotion": "count"}).distinct()
            spark_tools.write_csv_to_hdfs(input_df=Banner_count_df,
                                          hdfs_path=hdfs_file_output_path + "/Banner_count")

        if frequency_distribution_of_number_of_promos_allocated_each_customer:
            number_of_promos_allocated_df = self.df.groupBy(
                self.customer_key).count().select(
                col("count").alias("number_of_promos_alloted"))
            frequency_df = number_of_promos_allocated_df.groupBy(
                number_of_promos_allocated_df.number_of_promos_alloted).count().select(
                col("number_of_promos_alloted"),
                col("count").alias("frequency"))
            frequency_df = frequency_df.sort(
                frequency_df.number_of_promos_alloted.desc())
            spark_tools.write_csv_to_hdfs(input_df=frequency_df,
                                          hdfs_path=hdfs_file_output_path + "/frequency_distribution_of_number_of_promos_allocated_each_customer")

        if vip_customers_list is not None:
            vip_customers_list_df = self.df.filter(
                self.df[self.customer_key].isin(vip_customers_list)).groupBy(
                self.customer_key).count()
            spark_tools.write_csv_to_hdfs(input_df=vip_customers_list_df,
                                          hdfs_path=hdfs_file_output_path + "/vip_customers")

        if allocation_key:
            allocation_key_attribute = self.allocation_rules[
                'allocation_key_attribute']
            allcation_key_df = self.df.groupBy(allocation_key_attribute).agg(
                countDistinct("Promotion"))
            spark_tools.write_csv_to_hdfs(input_df=allcation_key_df,
                                          hdfs_path=hdfs_file_output_path + "/allocation_key")

    def create_table_sting(self, tabrows, tableheader, captiontext):

        tab_row = "<table border = 1 align = 'center'><caption><center><font size = '6'><b><i>" + captiontext + "</i></b><br/><br/></font></center></caption>"

        for eachheader in tableheader:
            tab_row = tab_row + "<th> &nbsp;&nbsp;<b>" + str(
                eachheader) + "</b>&nbsp;&nbsp;</th>"

        for foreachrow in tabrows:
            stri = "<tr>"
            tab_row = tab_row + stri
            for iter, foreach in enumerate(foreachrow):
                tab_row = tab_row + "<td> &nbsp;&nbsp;" + str(
                    foreach) + "&nbsp;&nbsp;</td>"
            tab_row = tab_row + "</tr>"
        return (tab_row + "</table>")

    def get_generic_df(self):

        """
        "generic_view":
             {
            "feature_db": "cno_pob",
            "feature_view": "v_cadenceattributefis_week_id_channelall_customerall_productproduct_storeall_current",
            "select_column" : ["channelall_customerall_productproduct_storeall_baskets_1w4w","product"],
            "Promotion_Directly_allocate_To_Customer": false,
            "offer_cap":50,
            "allocation_key_attribute": "Banner",
            "database_prefix": "cno",
            "product_module": "coop_no.cmp_entities.products",
            "product_class" : "Products",
            "product_columns" : ["Product","InstoreSubAisle"],
            "rename_columns" : ["product","InstoreSubAisle"],
"allocation_key_filter":true
            }

        :return: self.generic_df

        """
        if not self.allocation_rules['generic_infilling_required']:
            logger.info('No Generic Infilling Required')
            return

        required_generic_table_keys = ['feature_db', 'feature_view',
                                       'select_column', 'sensitive_attribute',
                                       'sensitive_attribute_values',
                                       'Promotion_Directly_allocate_To_Customer',
                                       'offer_cap', 'allocation_key_attribute',
                                       'allocation_value_attribute']

        missing_group_keys = [key for key in required_generic_table_keys if
                              key not in required_generic_table_keys]
        if len(missing_group_keys) > 0:
            raise RuntimeError(
                'Required keys missing from generic_table object: {0}'.format(
                    missing_group_keys))

        feature_view = self.generic_table.get('feature_view')
        feature_db = self.generic_table['feature_db']
        select_column = self.generic_table['select_column']
        Promotion_Directly_allocate_To_Customer = self.generic_table[
            'Promotion_Directly_allocate_To_Customer']
        offer_cap = self.generic_table['offer_cap']
        allocation_key_attribute = self.generic_table[
            'allocation_key_attribute']
        allocation_value_attribute = self.generic_table[
            'allocation_value_attribute']
        allocation_key_filter = self.generic_table['allocation_key_filter']
        product_module = self.generic_table['product_module']
        product_class = self.generic_table['product_class']
        database_prefix = self.generic_table['database_prefix']
        product_columns = self.generic_table['product_columns']
        rename_columns = self.generic_table['rename_columns']

        configs = {'SSEHiveDatabasePrefix': '{0}'.format(database_prefix)}
        module = __import__(product_module, fromlist=[product_class])
        product_class = getattr(module, product_class)
        product_df = product_class(config=configs).data

        self.offer_cap = offer_cap

        product_df = product_df.select(product_columns)

        product_df = spark_tools.rename_df_columns(input_df=product_df,
                                                   select_columns=product_columns,
                                                   rename_columns=rename_columns)

        for field in product_df.schema.fields:
            product_df = product_df.withColumn(field.name, F.coalesce(
                product_df[field.name], lit(
                    0 - row_number().over(
                        Window.orderBy(product_df[field.name])))))

        #latest_cadence add here
        table = feature_db + '.' + feature_view
        logger.info('Reading table form view: {0}'.format(table))
        self.generic_df = self.sqlContext.table(table).select(select_column)

        # logger.info("Number of records in self.generic_df {cnt}".format(
        #     cnt=self.generic_df.count()))

        # ranking the products on popularity
        # TODO replace index reference to feature column with named reference

        self.generic_df = self.generic_df.withColumn("rank", dense_rank().over(
            Window.orderBy(
                self.generic_df[select_column[0]].desc()))).withColumnRenamed(
            select_column[0], 'baskets')

        # logger.info("Number of records in self.generic_df {cnt}".format(
        #     cnt=self.generic_df.count()))

        # joining the self.generic_df with promo_df based on product attribute
        # getting the promos from the promo entity.

        cond = self.generic_df['product'] == self.promo_df['Product']
        self.generic_df = self.generic_df.join(self.promo_df, cond,
                                               "inner").drop(
            self.promo_df['Product'])

        # getting all product attribute from product entity to so that it
        # would help while apply the business logic

        self.generic_df = self.generic_df.join(product_df, ["product"])

        # Applying exclusion rule to remove the blacklisted products/promotions
        self.generic_df = self.apply_exclusions(exclusion_df=self.generic_df)

        # Applying conditional inclusions rule -- Need to check the code of this rule as it is not applied to any market as now.
        self.generic_df = self.apply_conditional_inclusions(df=self.generic_df)

        # Needs to apply sensitive_products_exclusion rule however, as per discussion with PM, removing all the sensitive product as for generic#  product we have no records either customer baught that product in desired duration or not.

        if self.sensitivity_rules is None:
            logger.info(
                'No sensitivity exclusions to apply for generic recommandation')
        else:

            logger.info('Applying sensitivity exclusions')

            for sensitivity_rule in self.sensitivity_rules["rules"]:
                logger.info("Applying sensitivity rule {rule_name}".format(
                    rule_name=sensitivity_rule))
                product_attribute = \
                    self.sensitivity_rules["rules"][sensitivity_rule][
                        'product_attribute']

                dimension_filters = \
                    self.sensitivity_rules['rules'][sensitivity_rule][
                        'dimension_filters']

                for dimension_filter in dimension_filters:
                    substring_length = \
                        self.sensitivity_rules['rules'][sensitivity_rule][
                            'dimension_filters'][
                            dimension_filter].get('substring_length', False)
                    value = self.sensitivity_rules['rules'][sensitivity_rule][
                        'dimension_filters'][
                        dimension_filter].get('value', False)

                    if substring_length:
                        try:
                            substring_length = int(substring_length)
                        except ValueError:
                            raise ValueError(
                                'substring_length value of \'{0}\' not castable to int'.format(
                                    substring_length))
                        for value in value:
                            if len(value) != substring_length:
                                logger.warning(
                                    'Value of \'{0}\' does not match substring_length of \'{1}\''.format(
                                        value,
                                        substring_length))

                        logger.info("### Applying condition on {filter}".format(
                            filter=product_attribute))

                        self.generic_df = self.generic_df.filter(
                            ~self.generic_df[product_attribute].substr(1,
                                                                       substring_length).isin(
                                value))

                    else:
                        self.generic_df = self.generic_df.filter(
                            ~self.generic_df[product_attribute].isin(
                                value))

        # getting score based on ranking
        self.generic_df = self.generic_df.withColumn('score',
                                                     format_string("%.8f",
                                                                   lit(
                                                                       -999999999 + self.generic_df.rank).cast(
                                                                       pt.DoubleType())))

        # adding customer id column with value "0000" for unknown customer
        self.generic_df = self.generic_df.withColumn('customer',
                                                     lit("0000").cast(
                                                         pt.StringType()))
        self.generic_df = self.generic_df.withColumn("type", lit(3))
        # Applying required_diversity &  alcoholic_drinks_recommendations rule
        self.generic_df = self.apply_required_diversity(df=self.generic_df,
                                                        level=
                                                        self.allocation_rules[
                                                            'allocation_key_attribute'])
        self.generic_df = self.limit_alcoholic_drinks_recommendations(
            df=self.generic_df, level=self.allocation_rules[
                'allocation_key_attribute'])
        self.generic_df = self.generic_df.drop('type')
        self.generic_df = self.generic_df.drop('customer')

        # Promotion need to allocate to customer directly - like allocate 50
        # promotions per customer

        if Promotion_Directly_allocate_To_Customer:
            df2 = self.generic_df.select([allocation_value_attribute])
            df2 = df2.dropDuplicates()
            df2 = df2.withColumn("promotion_rank", row_number().over(
                Window.orderBy(df2[allocation_value_attribute])))
            self.generic_df = self.generic_df.join(df2,
                                                   [allocation_value_attribute],
                                                   "inner")

        else:
            # Promotion need to allocate to key attribute indrectly to customer
            # like -allocate 50 promotions per Banner to customer

            if allocation_key_filter:
                # removing those allocation keys which have not required number of promos

                cap_df = self.generic_df.select(allocation_key_attribute,
                                                allocation_value_attribute)
                cap_df = cap_df.dropDuplicates()
                cap_df = cap_df.groupBy(cap_df[allocation_key_attribute]).agg(
                    countDistinct(allocation_value_attribute)).alias("count")
                logger.info(
                    "Number of {allocation_value_attribute} per {allocation_key_attribute}".format(
                        allocation_key_attribute=allocation_key_attribute,
                        allocation_value_attribute=allocation_value_attribute))

                cap_df = cap_df.where(cap_df[
                                          'count(%s)' % allocation_value_attribute] >= self.offer_cap)
                cap_df = cap_df.select(allocation_key_attribute)
                self.cap_df = cap_df.rdd.keys().collect()
                logger.info("Cap_df - {cap_df}".format(cap_df=self.cap_df))
                self.generic_df = self.generic_df.where(
                    self.generic_df[allocation_key_attribute].isin(self.cap_df))

            # self.generic_df = self.generic_df.withColumn("Promotion_rank",dense_rank().over(Window.partitionBy(self.generic_df[allocation_key_attribute]).orderBy(self.generic_df['rank'].asc(),self.generic_df["Promotion"].asc())))

            w = Window.partitionBy("Promotion")
            self.generic_df = self.generic_df.withColumn("product_rank", min(
                self.generic_df['rank']).over(w))

            # self.generic_df = self.generic_df.withColumn("promotion_rank",
            # dense_rank().over(Window.partitionBy(allocation_key_attribute).orderBy(self.generic_df['product_rank'].asc())))

            self.generic_df = self.generic_df.withColumn("promotion_rank",
                                                         dense_rank().over(
                                                             Window.partitionBy(
                                                                 allocation_key_attribute).orderBy(
                                                                 self.generic_df[
                                                                     'product_rank'].asc(),
                                                                 self.generic_df[
                                                                     "Promotion"].desc())))

            self.generic_df = self.generic_df.drop(self.generic_df.product_rank)

            # if there is no required_diversity_rule then we are applying the
            # filter of max_cap so that the size of generic_df can be smaller,
            # if the required_diversity rule will be true then after applying
            # this rule generic_df will be smaller by that.


            if self.required_diversity_rules is None or len(
                    self.required_diversity_rules) == 0:
                self.generic_df = self.generic_df.where(
                    self.generic_df["promotion_rank"] <= self.offer_cap)

        # logger.info("Number of records before filtering {cnt}".format(
        #     cnt=self.generic_df.count()))
        self.generic_df_cust = self.generic_df.where(
            self.generic_df["promotion_rank"] <= (self.offer_cap))

        rename_columns.remove('product')
        self.generic_df = self.generic_df.select(
            [key for key in
             ["Product", "Promotion", allocation_key_attribute, "rank",
              "PromotionStartDatetime", "PromotionEndDatetime"] + rename_columns
             if key])

        # adding customer id column with value "0000" for unknown customer
        self.generic_df_cust = self.generic_df_cust.withColumn('customer',
                                                               lit("0000").cast(
                                                                   pt.StringType()))
        self.generic_df_cust = self.generic_df_cust.withColumn("type", lit(3))

        self.generic_df_cust = self.generate_offer_position(
            df=self.generic_df_cust,
            level=self.allocation_rules['allocation_key_attribute'])
        self.generic_df_cust = self.create_relevancy_score(
            df=self.generic_df_cust)
        self.generic_df_cust = self.create_offer_relevancy_score(
            df=self.generic_df_cust, level=self.allocation_rules[
                'allocation_key_attribute'])

        # logger.info(
        #     "Number of records in generic customer dataframe {cnt}".format(
        #         cnt=self.generic_df_cust.count()))

        self.generic_df_cust = self.generic_df_cust.drop(
            self.generic_df_cust.rank)

        # Don't allocate an allocation_value more than once

        """
        ## Commented because of Norway changes - As currently it is not 
        ##impacting shoprite market. If in future Infilling and this feature  
        ##will be required for other market, then at that time we have to 
        #make it configured 

        self.generic_df_cust = self.generic_df_cust.withColumn(
            "%s_rank" % allocation_value_attribute,
            row_number().over(Window.partitionBy(*[key for key in
                                                   ["customer",
                                                    allocation_key_attribute,
                                                    allocation_value_attribute]
                                                   if key]).orderBy(
                self.generic_df_cust['baskets'].asc())))
        self.generic_df_cust = self.generic_df_cust.where(
            self.generic_df_cust[
                "%s_rank" % allocation_value_attribute] == 1).drop(
            self.generic_df_cust["%s_rank" % allocation_value_attribute])

        """

        self.generic_df_cust = self.generic_df_cust.drop(
            self.generic_df_cust.baskets)

        self.generic_df.persist()
        self.generic_df_cust.persist()
        #self.generic_df.show(5)

        # logger.info("Number of records in generic_df_cust {cnt}".format(cnt=
        #                                                                 self.generic_df_cust.count()))

    def infilling(self):

        """
        infill recommendations in self.df at required number for each customer, optionally infilling with infill type
        offers and optionally removing all customers with less than the minimum number of offers, based on rules in
        self.allocation_rules dict, eg:

        The dict should contain keys:
            ranking_column
            infill_type - may be None to disable infilling with second offer type
            infill_cap
            minimum_offers - may be None to disable applying minimum recommendations threshold
            allocation_key - it will be true if allocate the promotion to category directly not drectly to customer
            allocation_key_attribute - attribute to which promotion/product need to allocate
            generic_infilling_required - will be true if generic infilling is required

        """
        if not self.allocation_rules['generic_infilling_required']:
            logger.info('No Generic Infilling Required')
            return

        allocation_value_attribute = self.allocation_rules[
            'allocation_value_attribute']
        allocation_key_attribute = self.allocation_rules[
            'allocation_key_attribute']

        if allocation_key_attribute:
            logger.info(
                "Allocation key is {att}".format(att=allocation_key_attribute))

        # Separating Customer-allocation_key_attribute combinations which require infilling from those that don't
        keep = self.df.groupBy(
            *[self.df[key] for key in ['customer', allocation_key_attribute] if
              key]).agg(
            countDistinct(allocation_value_attribute).alias(
                "count_distinct_%s" % allocation_value_attribute))
        cond = [key for key in ['customer', allocation_key_attribute] if key]
        self.df = self.df.join(keep, cond, "inner")
        self.df.persist(StorageLevel.MEMORY_AND_DISK)
        self.max_offer_cap_df = self.df.where(
            self.df[
                "count_distinct_%s" % allocation_value_attribute] >= self.offer_cap)
        self.infilling_df = self.df.where(self.df[
                                              "count_distinct_%s" % allocation_value_attribute] < self.offer_cap)
        all_customers = self.scores_df.select('customer').drop_duplicates()

        self.number_of_customers_scored = all_customers.count()
        self.number_of_customers_allocated_less_than_offer_cap = self.infilling_df.select(
            [self.infilling_df[column] for column in
             ['customer', allocation_key_attribute] if
             column]).distinct().count()
        self.number_of_customers_allocated_more_than_offer_cap = self.max_offer_cap_df.select(
            [self.infilling_df[column] for column in
             ['customer', allocation_key_attribute] if
             column]).distinct().count()
        logger.info("Number of customers scored {cnt}".format(
            cnt=self.number_of_customers_scored))
        logger.info(
            "Number of customer-{key} allocated more than offer cap  {cnt}".format(
                key=allocation_key_attribute,
                cnt=self.number_of_customers_allocated_more_than_offer_cap))
        logger.info(
            "Number of customer-{key} allocated less than offer cap {cnt}".format(
                key=allocation_key_attribute,
                cnt=self.number_of_customers_allocated_less_than_offer_cap))

        # dropping count columns
        self.max_offer_cap_df = self.max_offer_cap_df.drop(
            self.max_offer_cap_df[
                "count_distinct_%s" % allocation_value_attribute])
        self.infilling_df = self.infilling_df.drop(
            self.infilling_df["count_distinct_%s" % allocation_value_attribute])

        # Creating relevance scores for customers that don't require infilling
        if self.number_of_customers_allocated_more_than_offer_cap > 0:
            self.max_offer_cap_df = self.max_offer_cap_df.repartition(
                *[key for key in [1050, 'customer', allocation_key_attribute,
                                  allocation_value_attribute] if key])
            self.max_offer_cap_df = self.generate_offer_position(
                df=self.max_offer_cap_df, level=self.allocation_rules[
                    'allocation_key_attribute'])
            self.max_offer_cap_df = self.create_relevancy_score(
                df=self.max_offer_cap_df)
            self.max_offer_cap_df = self.create_offer_relevancy_score(
                df=self.max_offer_cap_df,
                level=self.allocation_rules[
                    'allocation_key_attribute'])
            self.max_offer_cap_df.persist(StorageLevel.MEMORY_AND_DISK)

        # infilling the infilling_df with self.generic_df

        if (
                    self.number_of_customers_allocated_less_than_offer_cap > 0) and allocation_key_attribute:
            eligible_allocation_keys = self.generic_df.select(
                allocation_key_attribute).distinct()
            logger.info('Allocation keys :')


            # removing those allocation keys which do not have required number of promos
            logger.info(
                "Keeping only those {allocation_key}s which which can be infilled".format(
                    allocation_key=allocation_key_attribute))
            self.infilling_df = self.infilling_df.where(
                self.infilling_df[allocation_key_attribute].isin(
                    eligible_allocation_keys.rdd.keys().collect()))

            # Mapping all customers against all eligible allocation keys
            all_customers = all_customers.join(eligible_allocation_keys)

        customer_that_dont_need_infilling = self.max_offer_cap_df.select(
            [column for column in ['customer', allocation_key_attribute] if
             column]).distinct()
        customer_that_dont_need_infilling = customer_that_dont_need_infilling.withColumn(
            'need_infilling', F.lit(0))
        cond = [key for key in ['customer', allocation_key_attribute] if key]
        all_customers = all_customers.join(customer_that_dont_need_infilling,
                                           cond, 'left')
        all_customers = all_customers.na.fill(1, 'need_infilling')
        all_customers_that_need_infilling = all_customers.where(
            all_customers['need_infilling'] == 1).drop(
            'need_infilling')

        if allocation_key_attribute:
            generic_allocations_for_those_who_need_it = all_customers_that_need_infilling.join(
                self.generic_df,
                allocation_key_attribute)
        else:
            generic_allocations_for_those_who_need_it = all_customers_that_need_infilling.join(
                self.generic_df)

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
            'type',
            F.lit(3))
        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
            'Sponsored',
            F.lit(0))

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumnRenamed(
            'Product', 'product')

        if self.number_of_customers_allocated_less_than_offer_cap > 0:
            # Ensure consistent score for each customer-product pair
            customer_product_relevancy_scores = self.infilling_df.select(
                'customer', 'product',
                'score').drop_duplicates(
                ['customer', 'product'])
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.join(
                customer_product_relevancy_scores, ['customer', 'product'],
                'left')
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
                "score",
                when(
                    generic_allocations_for_those_who_need_it[
                        "score"].isNull(),
                    format_string(
                        "%.8f",
                        lit(
                            -999999999 + generic_allocations_for_those_who_need_it.rank).cast(
                            pt.DoubleType()))).otherwise(
                    generic_allocations_for_those_who_need_it[
                        "score"]))
        else:
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
                "score",
                format_string(
                    "%.8f",
                    lit(
                        -999999999 + generic_allocations_for_those_who_need_it.rank).cast(
                        pt.DoubleType())))

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.drop(
            generic_allocations_for_those_who_need_it['rank'])

        # ensuring only one generic allocation per customer-allocation_key_attribute(if any)-allocation_value_attribute

        """

        ## Commented because of Norway changes - As currently it is not 
        ##impacting shoprite market. If in future Infilling and this feature  
        ##will be required for other market, then at that time we have to 
        #make it configured 

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
            "allocation_rank", row_number().over(Window.partitionBy(
                *[key for key in ["customer", allocation_key_attribute, allocation_value_attribute] if key]).orderBy(
                generic_allocations_for_those_who_need_it['score'].asc())))

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.where(
            generic_allocations_for_those_who_need_it['allocation_rank'] == 1).drop(
            generic_allocations_for_those_who_need_it["allocation_rank"])

        """

        # Setting all missing columns from generic allocations dataframe to null before union
        missing_columns = [field_name for field_name in [field.name for field in
                                                         self.infilling_df.schema.fields]
                           if field_name not in [field.name for field in
                                                 generic_allocations_for_those_who_need_it.schema.fields]]

        logger.info(
            'The following columns are present in infilling and absent in generic allocations df :%s' % missing_columns)

        for column in missing_columns:
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
                column,
                F.lit(
                    None))

        # Re-order columns in generic allocations dataframe to match the order in infilling df
        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.select(
            self.infilling_df.schema.names)

        # Append generic allocations to relevant allocations
        # self.infilling_df = self.infilling_df.unionAll(generic_allocations_for_those_who_need_it)

        self.infilling_df = \
            generic_allocations_for_those_who_need_it.unionAll(
                self.infilling_df)

        # Choose only one allocation per customer,allocation_key_attribute,product
        self.infilling_df = self.infilling_df.withColumn("Promotion_rank",
                                                         row_number().over(
                                                             Window.partitionBy(
                                                                 *[key for key
                                                                   in
                                                                   ["customer",
                                                                    allocation_key_attribute,
                                                                    "product"]
                                                                   if
                                                                   key]).orderBy(
                                                                 self.infilling_df[
                                                                     'type'].asc())))
        self.infilling_df = self.infilling_df.where(
            self.infilling_df['Promotion_rank'] == 1).drop(
            self.infilling_df["Promotion_rank"])

        # If an allocation_value has been allocated as relevant don't allocate it again as generic
        self.infilling_df = self.infilling_df.withColumn(
            "%s_rank" % allocation_value_attribute, dense_rank().over(
                Window.partitionBy(
                    *[key for key in ["customer", allocation_key_attribute,
                                      allocation_value_attribute] if
                      key]).orderBy(
                    self.infilling_df['type'].asc())))
        self.infilling_df = self.infilling_df.where(
            self.infilling_df[
                "%s_rank" % allocation_value_attribute] == 1).drop(
            self.infilling_df["%s_rank" % allocation_value_attribute])

        self.infilling_df = self.apply_required_diversity(df=self.infilling_df,
                                                          level=
                                                          self.allocation_rules[
                                                              'allocation_key_attribute'])
        self.infilling_df = self.limit_alcoholic_drinks_recommendations(
            df=self.infilling_df,
            level=self.allocation_rules[
                'allocation_key_attribute'])
        self.infilling_df = self.generate_offer_position(df=self.infilling_df,
                                                         level=
                                                         self.allocation_rules[
                                                             'allocation_key_attribute'])
        self.infilling_df = self.create_relevancy_score(df=self.infilling_df)
        self.infilling_df = self.create_offer_relevancy_score(
            df=self.infilling_df,
            level=self.allocation_rules['allocation_key_attribute'])

        self.infilling_df.persist(StorageLevel.MEMORY_AND_DISK)

        # logger.info("Infilling done! Number of count in infilling df {cnt}".format(cnt=self.infilling_df.count()))

    def cap_and_infill_recommendations(self):
        pass

    def capping_recommendations(self):

        """cap recommendations in self.df at required number for each customer, optionally infilling with infill type
        offers and optionally removing all customers with less than the minimum number of offers, based on rules in
        self.allocation_rules dict, eg:

                "allocation_rules":
                {
                    "ranking_column":"offer_position",
                    "type_column": "type",
                    "offer_type":1,
                    "infill_type":null,
                    "infill_cap":null,
                    "minimum_offers":15,
                    "allocation_key": true,
                    "allocation_key_attribute":"Banner",
                    "allocation_value_attribute":"Promotion",
                    "generic_infilling_required": true
                },
        """
        required_keys = ['ranking_column', 'type_column', 'offer_type',
                         'infill_type', 'infill_cap', 'minimum_offers',
                         'allocation_key', 'generic_infilling_required']
        missing_keys = [key for key in required_keys if
                        key not in self.allocation_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from allocation_rules object: {0}'.format(
                    missing_keys))

        ranking_column = self.allocation_rules['ranking_column']
        type_column = self.allocation_rules['type_column']
        offer_cap = self.allocation_rules['offer_cap']
        minimum_offers = self.allocation_rules['minimum_offers']
        allocation_key_attribute = self.allocation_rules[
            'allocation_key_attribute']
        allocation_value_attribute = self.allocation_rules[
            'allocation_value_attribute']
        generic_infilling_required = self.allocation_rules.get(
            'generic_infilling_required')
        check_column_list = [self.customer_key, ranking_column, type_column]
        self.offer_cap = offer_cap

        if generic_infilling_required:

            # logger.info(
            #     "Number of distinct customer before allocation {cnt}".format(
            #         cnt=self.df.select("customer").distinct().count()))

            if self.number_of_customers_allocated_more_than_offer_cap > 0:
                logger.info("Starting capping over max_offer_cap_df")
                self.max_offer_cap_df = self.roll_up_relevance_scores(
                    self.max_offer_cap_df, allocation_value_attribute,
                    allocation_key_attribute)
                self.max_offer_cap_df = self.max_offer_cap_df.withColumn(
                    "%s_rank" % allocation_value_attribute,
                    dense_rank().over(
                        Window.partitionBy(*[key for key in
                                             ['customer',
                                              allocation_key_attribute]
                                             if key]).orderBy(
                            self.max_offer_cap_df[
                                "%s_relevance" % allocation_value_attribute].desc(),
                            self.max_offer_cap_df[
                                allocation_value_attribute].asc())))
                self.max_offer_cap_df = self.max_offer_cap_df.filter(
                    self.max_offer_cap_df[
                        "%s_rank" % allocation_value_attribute] <= self.offer_cap)

            logger.info("Starting capping of infilling df")
            self.infilling_df = self.roll_up_relevance_scores(self.infilling_df,
                                                              allocation_value_attribute,
                                                              allocation_key_attribute)
            self.infilling_df = self.infilling_df.withColumn(
                "%s_rank" % allocation_value_attribute, dense_rank().over(
                    Window.partitionBy(
                        *[key for key in ['customer', allocation_key_attribute]
                          if key]).orderBy(
                        self.infilling_df[
                            "%s_relevance" % allocation_value_attribute].desc(),
                        self.infilling_df[allocation_value_attribute].asc())))
            self.infilling_df = self.infilling_df.filter(
                self.infilling_df[
                    "%s_rank" % allocation_value_attribute] <= self.offer_cap)

            self.infilling_df = self.infilling_df.drop(
                self.infilling_df["%s_rank" % allocation_value_attribute])

            if self.number_of_customers_allocated_more_than_offer_cap > 0:
                logger.info(
                    "Unioning allocations with infilling with allocations without infilling")
                self.max_offer_cap_df = self.max_offer_cap_df.select(
                    self.infilling_df.columns)
                self.df = self.infilling_df.unionAll(self.max_offer_cap_df)
            else:
                self.df = self.infilling_df
            # Code below has been removed as it is no further required as per new logic
            # logger.info("Unioning with unknown customer allocations")
            # self.generic_df_cust = self.generic_df_cust.withColumnRenamed(
            #     'Product', 'product')
            # for needed_column in self.infilling_df.columns:
            #     if not (needed_column in self.generic_df_cust.columns):
            #         self.generic_df_cust = self.generic_df_cust.withColumn(
            #             needed_column,
            #             lit(None).cast(pt.StringType()))
            # self.generic_df_cust = self.generic_df_cust.select(
            #     self.infilling_df.columns)
            #
            # self.df = self.df.unionAll(self.generic_df_cust)
            self.df = self.df.coalesce(400)
            self.df.persist()
            #self.df.show(2)

        else:

            """
            # Generic infilling is not required.
            """
            self.df = self.generate_offer_position(df=self.df,
                                                   level=self.allocation_rules[
                                                       'allocation_key_attribute'])
            self.df = self.create_relevancy_score(df=self.df)
            self.df = self.create_offer_relevancy_score(df=self.df,
                                                        level=
                                                        self.allocation_rules[
                                                            'allocation_key_attribute'])
            spark_tools.check_columns(self.df, check_column_list)

            level = [key for key in
                     [allocation_key_attribute, self.customer_key] if key]
            keep = self.df.groupBy(*level).agg(
                F.count(allocation_value_attribute).alias("count"))
            self.df = self.df.join(keep, level)

            self.df = self.roll_up_relevance_scores(self.df,
                                                    allocation_value_attribute,
                                                    allocation_key_attribute)
            self.df = self.df.withColumn("%s_rank" % allocation_value_attribute,
                                         dense_rank().over(
                                             Window.partitionBy(
                                                 *[key for key in ['customer',
                                                                   allocation_key_attribute]
                                                   if key]).orderBy(
                                                 self.df[
                                                     "%s_relevance" % allocation_value_attribute].desc(),
                                                 self.df[
                                                     allocation_value_attribute].asc())))
            self.df = self.df.filter(
                self.df[
                    "%s_rank" % allocation_value_attribute] <= self.offer_cap)
            logger.info("Number of customers before capping {cnt}".format(
                cnt=self.df.select('customer').distinct().count()))

            if minimum_offers:
                self.df = self.df.filter((self.df["count"] >= minimum_offers))

            # persisting df for QA
            self.df = self.df.coalesce(400)
            self.df.persist()

        if self.df.count() == 0:
            sys.exit("Allocation file is empty. Terminating the application")

        self.customer_final = self.df.select(
            self.customer_key).distinct().count()

        logger.info(
            "QA : Final allocated customer volume(with minimum offer restrictions): {0}".format(
                self.customer_final))

    def rp_allocation(self):

        """
        getting score and applying the business rule
        output - will have self.df after the execution.

        """
        # self.score_manual()
        self.get_scores()
        self.df = self.scores_df
        self.boosting()
        self.join_promotions()
        self.df = self.apply_exclusions(exclusion_df=self.df)
        self.df = self.apply_conditional_inclusions(df=self.df)
        self.df = self.apply_sensitive_products_exclusion()
        self.df = self.apply_required_diversity(df=self.df,
                                                level=self.allocation_rules[
                                                    'allocation_key_attribute'])
        self.df = self.limit_alcoholic_drinks_recommendations(df=self.df,
                                                              level=
                                                              self.allocation_rules[
                                                                  'allocation_key_attribute'])

    def send_rp_notification(self):
        self.cust_rows = [("Total Customer Base", self.customer_base),
                          ("Active Scoring Customers", self.customer_scoring),
                          (
                              "Final Allocated volume (with minimum offer restriction)",
                              self.customer_final)]
        self.cust_headers = ["", " Customer Count"]
        self.cust_caption = "Overall Allocation KPIs"

        self.promo_rows = [("Total Promo in Promo Entity", self.promo_total),
                           ("Total Active Promo", self.promo_active)]
        self.promo_headers = ["", " Count "]
        self.promo_caption = "Promo KPIs"

        self.cust_table = self.create_table_sting(self.cust_rows,
                                                  self.cust_headers,
                                                  self.cust_caption)
        self.promo_table = self.create_table_sting(self.promo_rows,
                                                   self.promo_headers,
                                                   self.promo_caption)

        self.message = self.message + self.cust_table + self.promo_table
        self.send_notification_mail(
            file_path=[self.file_path + "//customer_promo/part-00000"])

    def proposition_specific_qa(self, hdfs_file_output_path, column_list):

        """
        logging and storing the data-frame for detailed QA, based on proposition

        """
        #column_list = self.detailed_quality_check.get('column_list')
        starting_date_Promotion = self.df.agg({"PromotionStartDatetime": "min"})
        end_date_Promotion = self.df.agg({"PromotionEndDatetime": "max"})

        logger.info("Earliest starting date of promotion:")
        #starting_date_Promotion.show()

        logger.info("Latest end date of promotion:")
        #end_date_Promotion.show()

        logger.info(
            "Number of distinct promotions in product_on_promotion_in_store entity {cnt}".format(
                cnt=self.promo_total))
        # logger.info(
        #     "Number of distinct Products after joining scoring and get_best_promotion_for_a_product's data frame {cnt}".format(
        #         cnt=self.join_promo_df.select("product").distinct().count()))
        # logger.info(
        #     "Number of distinct Promotions after joining scoring and get_best_promotion_for_a_product's dataframe {cnt}".format(
        #         cnt=self.join_promo_df.select("Promotion").distinct().count()))

        # getting stats over allocation output df
        # logger.info(
        #     "Number of distinct Promotions in allocation output {cnt}".format(
        #         cnt=self.df.select("Promotion").distinct().count()))

        # getting the Number of promotion allocated to number of customer in allocated file

        num_promotion_per_num_of_customer = self.df.select("customer",
                                                           "Promotion").distinct().groupBy(
            "customer").count().withColumnRenamed("count",
                                                  "Promotioncount").groupBy(
            "Promotioncount").count().withColumnRenamed("count",
                                                        "Customer_count").orderBy(
            "Customer_count")
        num_promotion_per_num_of_customer.coalesce(100)
        spark_tools.write_csv_to_hdfs(num_promotion_per_num_of_customer,
                                      hdfs_file_output_path + "/num_promotion_per_num_of_customer")

        # Banner level distribution on product_on_promotion_in_store
        # entity

        Banner_distribu_promo_df = self.promo_df.select("Banner",
                                                        "Promotion").distinct().groupBy(
            "Banner").count().withColumnRenamed("count",
                                                "Promotion_count_on_Banner")
        Banner_distribu_promo_df.coalesce(100)
        spark_tools.write_csv_to_hdfs(Banner_distribu_promo_df,
                                      hdfs_file_output_path + "/Banner_on_promo_entity")
        logger.info(
            "Distinct active customers in the scoring table: {0}".format(
                self.scores_df.select(self.customer_key).distinct().count()))

        # calculating Number of Promotion/product allocated on each level of product

        product_df = self.product_df.select(column_list)

        self.category_wise_distri_df = self.df.join(product_df, [product_df['Product'] == self.df['product']], "inner").drop(self.product_df['Product'])

        cnt = self.category_wise_distri_df.count()

        for foreach in column_list:
            if self.category_wise_distri_df.where(
                    col(foreach).isNull()).count() != cnt:
                sample_df = self.category_wise_distri_df.select(foreach,
                                                                foreach + "Description").distinct()

                category_df = self.category_wise_distri_df.select("Promotion",
                                                                  foreach).distinct().groupBy(
                    foreach).count().withColumnRenamed("count",
                                                       "Promotion_count").join(
                    sample_df, [foreach]).select("Promotion_count", foreach,
                                                 foreach + "Description")

                logger.info(
                    "Storing the category distribution of Promotion on level "
                    "{level}".format(
                        level=foreach))

                category_df.coalesce(300)
                spark_tools.write_csv_to_hdfs(category_df,
                                              hdfs_file_output_path + "/" + foreach)

        # Banner level distribution on allocated volume

        Banner_distribu_df = self.df.select("Banner", "Promotion").distinct(

        ).groupBy(
            "Banner").count().withColumnRenamed("count",
                                                "Promotion_count_on_Banner")
        Banner_distribu_df.coalesce(100)
        spark_tools.write_csv_to_hdfs(Banner_distribu_df,
                                      hdfs_file_output_path + "/Banner_on_allocated_volumn")

    def allocate(self, path):
        self.get_entity()
        self.get_promos()
        self.get_banners()
        self.get_best_promotion_for_a_product()
        self.rp_allocation()
        self.get_generic_df()
        self.infilling()
        self.capping_recommendations()
        self.quality_check(quality_check_rules=self.quality_check_rules)
        self.write_results_to_hdfs(path)
