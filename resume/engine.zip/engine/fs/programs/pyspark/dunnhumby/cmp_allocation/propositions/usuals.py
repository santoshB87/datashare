import logging
import abc
import sys
# noinspection PyUnresolvedReferences
# from pyspark.sql.functions import col #, lit, rowNumber, when, rand, round, exp
from dunnhumby.cmp_allocation.propositions import base
from dunnhumby.cmp_allocation import spark_tools
import pyspark.sql.types as pt
from pyspark.sql.functions import col, lit
#from dunnhumby.cmp_allocation.allocation import notification as notify

logger = logging.getLogger(__name__)


# pylint: disable=line-too-long
# pylint: disable=too-many-locals
# pylint: disable=super-on-old-class
class UsualsAllocation(base.Allocation):
    """Usuals Allocation class
    subclasses:
        Allocation
    methods:
        __init__ (calls super().__init__())
        prepare (calls super().prepare() and super().end_prepare()
        create_usuals_flag
        allocate
    """

    def __init__(self, config_file, algorithm, variation):
        self.usuals_flag_rules = None
        super(UsualsAllocation, self).__init__(config_file, algorithm, variation)

    def _set_config(self):
        self.usuals_flag_rules = self.cfg.get_item(keys='usuals_flag_rules', mandatory=False)
        super(UsualsAllocation, self)._set_config()

    @abc.abstractmethod
    def create_usuals_flag(self):
        pass

    @abc.abstractmethod
    def column_sponsored_addition(self):
        pass

    def get_banners(self):

        """

        Banner rule is to include the Banner in the dataframe and apply thefilter if needed.

        For Usuals and HYF - use the feature view on basket grain and check customer baught the
        product either in 26 week. And call this rule after getting relevancy score for HYF and
        Usuals proposition.

        Create a banner column on self.df/self.promo_df, based on rules in self.banner_rules, eg:

        "banner_rules":{
                "database_prefix": "cascod",
                "banner_filter" : null,
                "store_module" : "ci_colombia.cmp_entities.stores",
                "proposition" : "usuals",
                "view_name" : "v_cadenceattributefis_week_id_channelall_customercustomer_productproduct_storebanner_current",
                "feature" :  "channelall_customercustomer_productproduct_storebanner_baskets_1w26w",
                "condition" : ">= 0"
                          },
        """

        if self.banner_rules is None or len(self.banner_rules) == 0:
            logger.info('No Banner rule to apply')
            self.df = self.df.withColumn('Banner', lit(None).cast(
                pt.StringType()))
            self.df = self.df.withColumn('StoreRegion', lit(None).cast(
                pt.StringType()))
            self.df = self.df.withColumn("Store", lit(None).cast(
                pt.StringType()))
            return

        logger.info('Applying Banner rules')
        required_keys = [
            'database_prefix',
            'banner_filter',
            'store_module',
            'proposition',
            'view_name',
            'feature',
            'condition'
        ]
        missing_keys = [key for key in required_keys if
                        key not in self.banner_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from banner object: {0}'.format(
                    missing_keys))

        database_prefix = self.banner_rules['database_prefix']
        store_module = self.banner_rules['store_module']
        view_name = self.banner_rules['view_name']
        feature = self.banner_rules['feature']
        banner_condition = self.banner_rules['condition']
        store_module = __import__(store_module, fromlist=['Stores'])
        self.store_class = getattr(store_module, "Stores")
        #config = {'SSEHiveDatabasePrefix': '{0}'.format(database_prefix)}
        self.store_df = self.store_class().data

        logger.info('Looking for banner_feature in view {view_name}'. \
                    format(view_name=database_prefix + '_pob.' + view_name))

        feature_df = self.sqlContext.table(database_prefix + '_pob.' + view_name).select(
            [feature, "customer", "product", "store"])

        filter_expression = '{column} {condition}'.format(column=feature, condition=banner_condition)

        feature_df = feature_df.where(filter_expression)
        feature_df = feature_df.drop(feature)

        self.df = self.df.join(feature_df, ["customer", "product"])

        self.df = self.df.withColumnRenamed("store", "Banner")
        self.df = self.df.withColumn('StoreRegion', lit(None).cast(pt.StringType())).withColumn("Store", lit(None).cast(
            pt.StringType())).dropDuplicates()

        logger.info('Number of distinct customer after banner rule : {cnt}'.format(
            cnt=self.df.select(self.customer_key).distinct().count()))

    def quality_check(self, quality_check_rules):
        """
        Perform various QA checks on the final allocation file being sent
        :param
        quality_check_rules: QA rules defined to create sign off csv files
        """
        msg = ""
        excluded_customers = ""
        customers_in_customer_base = ""
        logger.info("Starting quality checks")
        sign_off_files = quality_check_rules.get('sign_off_files')
        vip_customers_list = quality_check_rules.get('vip_customers')
        hdfs_file_output_path = quality_check_rules.get('hdfs_file_output_path')
        logger.info("Final allocated customer volume(without minimum offer restrictions): {0}"
                    .format(self.df.select(self.customer_key).distinct().count()))

        customer_module = self.get_scores_rules['customer_module']
        customer_class = self.get_scores_rules['customer_class']
        database_prefix = self.get_scores_rules['database_prefix']

        #configs = {'SSEHiveDatabasePrefix': '{0}'.format(database_prefix)}
        module = __import__(customer_module, fromlist=[customer_class])
        customer_class = getattr(module, customer_class)
        customer_df = customer_class().data

        df2 = self.df.join(self.df.groupBy(self.customer_key).count(), self.customer_key).cache()

        if vip_customers_list :
            vip_customer_df = self.df.filter(col("customer").isin(vip_customers_list)).select(self.select_columns)
            spark_tools.write_csv_to_nfs(input_df=vip_customer_df,
                                         nfs_path=self.nfs_file_output_path + "/vip_customers/")

        if sign_off_files:
            customer_usuals_df = self.df.groupBy('customer').count().withColumnRenamed('count',
                                                                                       'Allocated_products_count') \
                .groupBy('Allocated_products_count').count().withColumnRenamed('count',
                                                                               'Allocated_customers_count').orderBy(
                'Allocated_products_count')

            # spark_tools.write_csv_to_hdfs(input_df=customer_usuals_df,
            #                              hdfs_path=hdfs_file_output_path + "/customer_ususal")

            spark_tools.write_csv_to_nfs(input_df=customer_usuals_df,
                                         nfs_path=self.nfs_file_output_path + "/customer_usuals/")

        # customers_in_customer_base = "<table border ='1' align = 'center'>" \
        #                              " <tr> <th colspan='2'><center>Customer Base</center></th></tr>" \
        #                              "<tr id = 'row1' bgcolor ='#B3B0AF'>" \
        #                              "<td> &nbsp;&nbsp;<b>Total distinct customers in customer base</b>&nbsp;&nbsp;</td>" \
        #                              "<td> {0}" \
        #                              "</td>" \
        #                              "</table>" \
        #                              " <br/><br/>".format(customer_df.count())
        #
        # msg = "<table border ='1' align = 'center'>" \
        #       " <tr> <th colspan='2'><center>Overall Details</center></th></tr>" \
        #       "<tr id = 'row1' bgcolor ='#B3B0AF'>" \
        #       "<td> &nbsp;&nbsp;</td>" \
        #       "<td><b>&nbsp;&nbsp;Customers count&nbsp; &nbsp;</b>" \
        #       "</td>" \
        #       "</tr>" \
        #       " <tr id = 'row2'>" \
        #       "<td>" \
        #       " &nbsp;Final allocated customer volume (without minimum product restrictions): &nbsp;" \
        #       " </td>" \
        #       " <td>{0} &nbsp; </td>" \
        #       " </tr> <tr id 'row3'>" \
        #       "<td>&nbsp;Final allocated customer volume(with minimum product restrictions)&nbsp;</td>" \
        #       "<td>{1} </td>" \
        #       "" \
        #       " </tr>" \
        #       "</table> <br/> <br/> <br/>" \
        #       " <br/><br/>".format(self.df.select(self.customer_key).distinct().count(),
        #                            self.df.join(self.df.groupBy(self.customer_key).count(),
        #                                         self.customer_key).filter('count >=4').select(
        #                                self.customer_key).distinct().count())
        #
        # exclusion_msg = "<table border ='1' align = 'center'>" \
        #                 " <tr> <th colspan='2'><center>Overall Details</center></th></tr>" \
        #                 "<tr id = 'row1' bgcolor ='#B3B0AF'>" \
        #                 "<td> &nbsp;&nbsp;</td>" \
        #                 "<td><b>&nbsp;&nbsp;Customers count&nbsp; &nbsp;</b>" \
        #                 "</td>" \
        #                 "</tr>" \
        #                 " <tr id = 'row2'>" \
        #                 "<td>" \
        #                 " &nbsp;Allocated customer volume before exclusion: &nbsp;" \
        #                 " </td>" \
        #                 " <td>{0} &nbsp; </td>" \
        #                 " </tr> <tr id 'row3'>" \
        #                 "<td>&nbsp;Allocated customer volume after  exclusion &nbsp;</td>" \
        #                 "<td>{1} </td>" \
        #                 "" \
        #                 " </tr>" \
        #                 "</table> <br/> <br/> <br/>" \
        #                 " <br/><br/>".format(self.before_exclusion_distinct_cnt, self.after_exclusion_distinct_cnt)
        #
        # # msg = " Total allocated customers are : {0}".\
        # #    format(self.df.select(self.customer_key).distinct().count())
        #
        # excluded_customers = "<table border ='1' align = 'center'><tr>" \
        #                      "<th colspan='2'><b>Customer excluded due to minimum product restrictions</b></th></tr>" \
        #                      "<tr id = 'row1' bgcolor ='#B3B0AF'>" \
        #                      "<td><b> Product Count</b></td>" \
        #                      "<td><b>&nbsp;&nbsp;Customers count&nbsp; &nbsp;</b>" \
        #                      "</td>" \
        #                      "</tr>" \
        #                      " <tr id = 'row2'>" \
        #                      "<td>" \
        #                      "<center> 1</center> &nbsp;" \
        #                      " </td>" \
        #                      " <td><center>{0} </center> </td>" \
        #                      " </tr> <tr id 'row3'>" \
        #                      "<td> <center>2</center> </td>" \
        #                      "<td><center>{1}</center> </td>" \
        #                      "" \
        #                      " </tr> <tr><td><center> 3</center> </td><td><center>{2}</center></td></tr>" \
        #                      "</table> <br/> <br/> <br/>" \
        #                      " Thanks!<br/><br/>".format(
        #     df2.filter('count = 1').select(self.customer_key).distinct().count(),
        #     df2.filter('count = 2').select(self.customer_key).distinct().count(),
        #     df2.filter('count = 3').select(self.customer_key).distinct().count())
        #
        # self.message = self.message + customers_in_customer_base + exclusion_msg + msg + excluded_customers
        #
        # self.send_notification_mail(file_path=[self.file_path + "/customer_ususal/part-00000"])
        #
        # logger.info("##Notification Messgae sent###")
        pass

    def cap_and_infill_recommendations(self):

        """cap recommendations in self.df at required number for each customer, optionally infilling with infill type
        offers and optionally removing all customers with less than the minimum number of offers, based on rules in
        self.allocation_rules dict, eg:

                "allocation_rules":
                {
                    "ranking_column":"offer_position",
                    "type_column": "type",
                    "offer_type":1,
                    "infill_type":null,
                    "infill_cap":null,
                    "minimum_offers":15,
                    "allocation_key": true,
                },
        """
        required_keys = [
            'ranking_column',
            'type_column',
            'offer_type',
            'infill_type',
            'infill_cap',
            'minimum_offers',
        ]
        missing_keys = [key for key in required_keys if
                        key not in self.allocation_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError('Required keys missing from allocation_rules object: {0}'.format(missing_keys))

        ranking_column = self.allocation_rules['ranking_column']
        type_column = self.allocation_rules['type_column']
        offer_type = self.allocation_rules['offer_type']
        infill_type = self.allocation_rules['infill_type']
        infill_cap = self.allocation_rules['infill_cap']
        offer_cap = self.allocation_rules['offer_cap']
        minimum_offers = self.allocation_rules['minimum_offers']
        check_column_list = [self.customer_key, ranking_column, type_column]
        spark_tools.check_columns(self.df, check_column_list)
        self.offer_cap = offer_cap

        where_clause = '{type_col} = {offer_type} and {ranking_column} <= {offer_cap}'.format(type_col=type_column,
                                                                                              offer_type=offer_type,
                                                                                              ranking_column=ranking_column,
                                                                                              offer_cap=self.offer_cap)

        if infill_type:
            if infill_cap is None:
                raise RuntimeError('If infill_type is specified must also specify infill_cap')
            if infill_cap > self.offer_cap:
                logger.warning('infill_cap of {0} greater than offer_cap of {1}, setting to {1}'.format(infill_cap,
                                                                                                        self.offer_cap))
                infill_cap = self.offer_cap
            where_clause += ' or ({type_col} = {infill_type} and {ranking_column} <= {infill_cap})'.format(
                type_col=type_column, infill_type=infill_type, ranking_column=ranking_column, infill_cap=infill_cap)

        if self.offer_cap :
            self.df = self.df.filter(where_clause)

        # Apply quality checks on the final allocation file being sent.
        # It performs checks like total promotions to total customer ratio,
        # percentage of customers allocated, dropped. Earlier this process was done manually so now this is automated.

        # persisting df for QA
        self.df = self.df.coalesce(400)
        self.df.persist()
        self.quality_check(quality_check_rules=self.quality_check_rules)

        if minimum_offers:
            keep = self.df.groupBy(self.customer_key).count()
            self.df = self.df.join(keep, self.customer_key).filter('count >={0}'.format(minimum_offers))

        if self.df.count() == 0:
            sys.exit("Allocation file is empty. Terminating the application")
        self.customer_final = self.df.select(
            self.customer_key).distinct().count()
        logger.info("Final allocated customer volume(with minimum offer restrictions): {0}".format(self.customer_final))

    def proposition_specific_qa(self, hdfs_file_output_path, column_list):

        """
        logging and storing the data-frame for detailed QA, based on proposition

        """

        # getting the Number of promotion allocated to number of customer in allocated file
        #column_list = self.detailed_quality_check.get('column_list')

        num_product_per_num_of_customer = self.df.select("customer","product").distinct().groupBy("customer").count().withColumnRenamed("count","Productcount").groupBy("Productcount").count().withColumnRenamed("count","Customer_count").orderBy("Customer_count")
        num_product_per_num_of_customer.coalesce(100)
        spark_tools.write_csv_to_hdfs(num_product_per_num_of_customer,hdfs_file_output_path + "/num_product_per_num_of_customer")

        # Banner level distribution

        Banner_distribu_product_df = self.df.select("Banner","product").distinct().groupBy("Banner").count().withColumnRenamed("count","product_count_on_Banner")
        Banner_distribu_product_df.coalesce(100)
        spark_tools.write_csv_to_hdfs(Banner_distribu_product_df,hdfs_file_output_path + "/Banner_distribu_product_df")

        # calculating Number of Promotion/product allocated on each level of product

        product_df = self.product_df.select(column_list)
        logger.info("prod df and self df")
        product_df.printSchema()
        self.df.printSchema()
        self.category_wise_distri_df = self.df.join(product_df, [product_df['Product'] == self.df['product']], "inner").drop(self.product_df['Product'])

        #column_list = ['product', 'Subgroup', 'Group', 'Section']

        cnt = self.category_wise_distri_df.count()
        if 'Product' in column_list:
            column_list.remove('Product')

        for foreach in [x for x in column_list if 'Description' not in x]:
            if self.category_wise_distri_df.where(col(foreach).isNull()).count() != cnt:

                sample_df = self.category_wise_distri_df.select(foreach, foreach + "Description").distinct()
                logger.info("category and sample df")
                self.category_wise_distri_df.printSchema()
                sample_df.printSchema()
                category_df = self.category_wise_distri_df.select("product", foreach).distinct().groupBy(foreach).count().withColumnRenamed("count","product_count").join(sample_df, [foreach]).select("product_count", foreach, foreach + "Description")

                logger.info("Storing the category distribution of product on level {level}".format(level=foreach))

                category_df.coalesce(300)
                spark_tools.write_csv_to_hdfs(category_df,hdfs_file_output_path + "/" + foreach)

        # Banner level distribution on allocated volume

        Banner_distribu_df = self.df.select("Banner", "product").distinct().groupBy("Banner").count().withColumnRenamed("count","product_count_on_Banner")
        Banner_distribu_df.coalesce(100)
        spark_tools.write_csv_to_hdfs(Banner_distribu_df,hdfs_file_output_path + "/Banner_on_allocated_volumn")

    def allocate(self, path):
        self.get_entity()
        self.get_scores()
        self.df = self.scores_df
        self.column_department_addition()
        self.get_banners()
        self.df = self.apply_exclusions(show_counts=True, exclusion_df=self.df)
        self.df = self.apply_conditional_inclusions(df=self.df)
        self.apply_sensitive_products_exclusion()
        self.df = self.apply_required_diversity(df=self.df)
        self.create_usuals_flag()
        self.df = self.generate_offer_position(df=self.df)
        self.df = self.create_relevancy_score(df=self.df)
        self.cap_and_infill_recommendations()
        self.column_sponsored_addition()
        self.write_results_to_hdfs(path)
