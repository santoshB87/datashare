import logging
import sys

from dunnhumby.cmp_allocation import contexts, spark_tools
from tools.configs import Config

# set up basic logging
logger = logging.getLogger('spark_drivers.{0}'.format(__file__))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)

spark_context = contexts.sc()
hive_context = contexts.sql_context()

def format_results(algorithm, config_file, output_name, comma_separated_file_names) :
    input_files = comma_separated_file_names.split(',')

    # load config object from file
    conf = Config(logger=logger)
    conf.add_source_file(path=config_file)

    logger.debug('Input files list: {0}'.format(input_files))

    key_root = (algorithm, 'linux_outputs', output_name, 'recommendations')

    number_of_files = conf.get_item(keys=key_root + ('number_of_files',), mandatory=True)
    partition_column = conf.get_item(keys=key_root + ('partition_column',), mandatory=True)
    columns = conf.get_item(keys=key_root + ('columns',), mandatory=True)
    sort_columns = conf.get_item(keys=key_root + ('sort_columns',), mandatory=True)
    add_columns = conf.get_item(keys=key_root + ('add_columns',), mandatory=False, default=None)
    write_mode = conf.get_item(keys=key_root + ('write_mode',), mandatory=True)
    file_format = conf.get_item(keys=key_root + ('file_format',), mandatory=True)
    file_option_codec = conf.get_item(keys=key_root + ('file_option_codec',), mandatory=True)
    header = conf.get_item(keys=key_root + ('headers',), mandatory=True)

    conf.error_on_mandatory_exceptions()

    for infile in input_files:
        outfile = infile + '.' + output_name
        logger.info('Formatting file {0} for output, creating {1}'.format(infile, outfile))
        df = hive_context.read.parquet(infile)

        spark_tools.write_formatted_results_to_hdfs(
            spark_context=spark_context,
            input_df=df,
            hdfs_path=outfile,
            number_of_files=number_of_files,
            partition_column=partition_column,
            select_columns=columns,
            add_columns=add_columns,
            sort_columns=sort_columns,
            write_mode=write_mode,
            file_format=file_format,
            file_option_codec=file_option_codec,
            header=header
        )
