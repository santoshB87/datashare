import sys
import ast
import logging
from dunnhumby.cmp_allocation import contexts, spark_tools
from tools.configs import Config
# set up basic logging

import pyspark.sql.functions as func


logger = logging.getLogger('spark_drivers.{0}'.format(__file__))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)
spark_context = contexts.sc()
hive_context = contexts.sql_context()

def format_results_unica(algorithm, config_file, output_name, comma_separated_file_names) :
    # parse command line args
    files = comma_separated_file_names.split(',')
    # load config object from file
    conf = Config(logger=logger)
    conf.add_source_file(path=config_file)
    logger.debug('Input files list: {0}'.format(files))


    # get algorithm specific config
    jdbc_driver_name = conf.get_item(keys=(algorithm, 'jdbc_driver_name'), mandatory=True)
    output_unica_url = conf.get_item(keys=(algorithm, 'output_unica_url'), mandatory=True)
    output_partition_column=conf.get_item(keys=(algorithm, 'output_partition_column'), mandatory=True)
    output_select_columns=conf.get_item(keys=(algorithm, 'output_select_columns'), mandatory=True)
    output_rename_columns=conf.get_item(keys=(algorithm, 'output_rename_columns'), mandatory=True)
    output_write_mode=conf.get_item(keys=(algorithm, 'output_write_mode'), mandatory=True)
    jdbc_properties=conf.get_item(keys=(algorithm, 'jdbc_properties'), mandatory=True)
    output_date_key=conf.get_item(keys=(algorithm, 'output_date_key'), mandatory=True)
    output_load_date_format=conf.get_item(keys=(algorithm, 'output_load_date_format'), mandatory=True)
    output_allocation_table=conf.get_item(keys=(algorithm, 'output_allocation_table'), mandatory=True)
    output_event_table=conf.get_item(keys=(algorithm, 'output_event_table'), mandatory=True)
    output_variation_table=conf.get_item(keys=(algorithm, 'output_variation_table'), mandatory=True)
    soema_event_id_hdf_path=conf.get_item(keys=(algorithm, 'event_id_hdfs_path'), mandatory=True)
    event_metadata=conf.get_item(keys=(algorithm, 'event'), mandatory=True)
    variation_metadata=conf.get_item(keys=(algorithm, 'variation'), mandatory=True)

    # get variation specific config
    dotcome_id_lookup=conf.get_item(keys=(algorithm, 'dotcome_id_lookup'), mandatory=True)
    customer_key=conf.get_item(keys=(algorithm, 'customer_key'), mandatory=True)
    dotcom_key=conf.get_item(keys=(algorithm,'dotcome_id_lookup', 'dotcome_key'), mandatory=True)
    mechanic_code_key=conf.get_item(keys=(algorithm, 'mechanic_code_key'), mandatory=True)
    promo_key=conf.get_item(keys=(algorithm, 'promo_key'), mandatory=True)
    store_ranging_key=conf.get_item(keys=(algorithm, 'store_ranging_key'), mandatory=True)
    output_file_format=conf.get_item(keys=(algorithm, 'output_file_format'), mandatory=True)
    broken_links_report_path=conf.get_item(keys=(algorithm, 'broken_links_report_path'), mandatory=True)

    conf.error_on_mandatory_exceptions()
    event_id_df = hive_context.read.parquet(soema_event_id_hdf_path)
    most_recent_event_lookup = ast.literal_eval(event_id_df.orderBy(func.col('event_id').desc()).toJSON().first())
    ## empty list
    df_list = []
    for infile in files:
        # Read recommendations from HDFS
        df = hive_context.read.parquet(infile)

        # Expand to dotcom customer level
        df = spark_tools.expand_to_doctcom(input_df=df, hive_context=hive_context,
                                     dotcom_id_lookup_dimention=dotcome_id_lookup, customer_key=customer_key,
                                     dotcom_key=dotcom_key)

        # Add '.pnj' to HOPOS_ID (mechanic code)
        df = spark_tools.update_df_attribute_content(input_df=df,
                                              attribute=mechanic_code_key,
                                              update_to=func.concat(func.col(mechanic_code_key), func.lit('.png'))
                                              )

        # Add current timestamp in a 'yyyyMMdd' format (needed in exadata table)
        df = spark_tools.add_load_time(
            input_df=df,
            date_format=output_load_date_format,
            date_key=output_date_key
        )

        # Increment variation by 1  and add the most recent event id to allocation output. This is only for UK
        df = spark_tools.update_variation_event_allocation_output(
            input_df=df,
            file_name=infile,
            variation_metadata=variation_metadata,
            event_id=most_recent_event_lookup['event_id']
        )

        # crate a list of data frames that will be used in generate_broken_links_report (at the moment only
        # target recommendations are used)
        if 'target' in infile.lower():
            df_list.append(df)

        # Rename columns to match the exadata table columns
        df = spark_tools.generate_allocation_output_for_unica(
            input_df=df,
            select_columns=output_select_columns,
            rename_columns=output_rename_columns
        )


        # Insert into exadata table using
        spark_tools.write_formatted_results_to_jdbc(
            input_df=df,
            url=''.join([jdbc_driver_name, output_unica_url]),
            partition_column=output_partition_column,
            where=output_allocation_table,
            write_mode=output_write_mode,
            properties=jdbc_properties
        )

    # Generate the schema and the metadata of the event
    event_output, event_schema = spark_tools.exadata_event_output(
        event_dict=event_metadata,
        event_id=most_recent_event_lookup['event_id'],
        start_date=most_recent_event_lookup['start_date'],
        end_date=most_recent_event_lookup['end_date']
    )

    #Insert event metadata into exadata event table
    spark_tools.write_formatted_results_to_jdbc(
        input_df=spark_tools.create_data_frame(
            hive_context=hive_context,
            list_of_tuples=event_output,
            schema=event_schema
        ),
        url=''.join([jdbc_driver_name, output_unica_url]),
        where=output_event_table,
        write_mode=output_write_mode,
        properties=jdbc_properties
    )

    # Generate the schema and the metadata of the variation
    variation_output, variation_schema = spark_tools.exadata_variation_output(
        variation_dict=variation_metadata,
        event_id=most_recent_event_lookup['event_id'],
        service_id=event_metadata['service_id']
    )

    # Insert variation metadata into exadata variation table table
    spark_tools.write_formatted_results_to_jdbc(
        input_df=spark_tools.create_data_frame(
            hive_context=hive_context,
            list_of_tuples=variation_output,
            schema=variation_schema
        ),
        url=''.join([jdbc_driver_name, output_unica_url]),
        where=output_variation_table,
        write_mode=output_write_mode,
        properties=jdbc_properties
    )

    spark_tools.generate_broken_links_report(input_df=spark_tools.unionAll(*df_list),
                                         promo_key=promo_key,
                                         store_key=store_ranging_key,
                                         file_path=broken_links_report_path,
                                         file_mode='overwrite',
                                         file_format=output_file_format,
                                         header_flag='true'
                                         )



