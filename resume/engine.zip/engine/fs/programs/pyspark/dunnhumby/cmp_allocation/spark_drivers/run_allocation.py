import logging
import sys
import os

from dunnhumby.cmp_allocation import allocation_factory

# set up basic logging
logger = logging.getLogger('spark_drivers.{0}'.format(__file__))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)


def allocate_variations(client, variation_list, algorithm, event_id, dttm, hdfs_output_path, config_file):
    """
    Args:
            variation_list: list of tuples in form [(var1_id, var1_description), (var2_id, var2_description), ...]
            client: client shortname (ie tesco_uk) - will be used to load appropriate Allocation subclass
            algorithm: algorithm to use to allocate
            event_id: event ID to be used when naming output files
            dttm: string formatted datetime stamp to be used when naming output files
            hdfs_output_path: path on HDFS to write output files into
            config_file: Config file to be passed to spark driver program though --files parameter

        Return: Dict
            {
                variation_id_1: hdfs_path_to_variation_1_allocation_results,
                variation_id_2: hdfs_path_to_variation_2_allocation_results,
                ...
                variation_id_n: hdfs_path_to_variation__n_allocation_results
            }
        """

    allocated_files = dict()
    for variation in variation_list:
        variation_id = variation[0]
        variation_description = variation[1]  # (remove)
        run_prefix = '_'.join(map(str, [algorithm, event_id, variation_id, dttm])).lower()
        full_hdfs_output_path = os.path.join(hdfs_output_path, run_prefix)

        logger.info('algorithm: ' + algorithm)

        allocation = allocation_factory.get_allocation_object(
            client=client,
            proposition=algorithm,
            variation=variation_id,
            config_file=config_file
        )
        allocation.allocate(full_hdfs_output_path)
        allocated_files[variation_id] = full_hdfs_output_path

    return allocated_files
