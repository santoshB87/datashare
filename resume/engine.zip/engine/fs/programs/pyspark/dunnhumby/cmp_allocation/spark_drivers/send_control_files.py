import ast
import logging
import os
import sys
import pyspark.sql.functions as func

from dunnhumby.cmp_allocation import contexts, spark_tools, customer_control
from tools.configs import Config

# set up basic logging
logger = logging.getLogger('spark_drivers.{0}'.format(__file__))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)

spark_context = contexts.sc()
hive_context = contexts.sql_context()

def generate_send_files(algorithm, dttm, allocated_files, hdfs_output_path, event_id, control_variation_id,
                config_file) :

    conf = Config(logger=logger)
    conf.add_source_file(path=config_file)

    control_variation  = conf.get_item(keys=(algorithm, 'variations', '0'), mandatory=True)
    hdfs_output_path  = conf.get_item(keys=(algorithm, 'hdfs_output_path'), mandatory=True)
    hdfs_control_path = conf.get_item(keys=(algorithm, 'hdfs_control_path'), mandatory=True)
    event_id  = conf.get_item(keys=(algorithm, 'event', 'event_id'), mandatory=True)
    variations = conf.get_item(keys=(algorithm, 'variation'), mandatory=True)
    customer_key  = conf.get_item(keys=(algorithm, 'customer_key'), mandatory=True)

    # Name of the target file (customers that are in the TARGET GROUP) created on HDFS
    hdfs_target_group_file = os.path.join(hdfs_output_path,
                                      '_'.join(
                                          map(str, [algorithm, hdfs_control_path, event_id])),
                                      '_'.join(map(str, ['TARGET_GROUP', dttm])))

    #  Name of the send target file (recommendations of customers from TARGET GROUP ) created on HDFS
    send_target_file = os.path.join(hdfs_output_path,
                                '_'.join(map(str, [algorithm, event_id, 'send_target', str(dttm)])))

    # Name of the control file (customers that are in the TARGET GROUP) created on HDFS
    hdfs_control_group_file = os.path.join(hdfs_output_path,
                                       '_'.join(
                                           map(str, [algorithm, hdfs_control_path, event_id])),
                                       '_'.join(map(str, ['CONTROL_GROUP', str(dttm)])))

    #  Name of the send control file (recommendations of customers from TARGET GROUP ) created on HDFS
    send_control_files = os.path.join(hdfs_output_path,
                                  '_'.join(map(str, [algorithm, event_id, 'send_control', str(dttm)])))

    allocated_df = [hive_context.read.parquet(allocated_files.values()[0])
                    .withColumn('variation_id', func.lit(allocated_files.keys()[0]))]

    df = spark_tools.unionAll(*allocated_df)

    logger.debug('Writing send parquet file {0} '.format(send_target_file))

    spark_tools.write_to_hdfs(input_df=customer_control.generate_send_data(input_df=df,
                                          control_population_df=customer_control.allocate_variations(
                                              variations=variations,
                                              population_group_hdfs=hdfs_target_group_file,
                                              hive_context=hive_context
                                              ),
                                          customer_key=customer_key),
              file_saveMode='overwrite',
              file_format='parquet',
              hdfs_path=send_target_file
              )

    logger.debug('Writing send parquet file {0} '.format(send_control_files))
    spark_tools.write_to_hdfs(input_df=customer_control.generate_send_data(input_df=df,
                                          control_population_df=customer_control.allocate_variations(
                                              variations=variations,
                                              population_group_hdfs=hdfs_control_group_file,
                                              hive_context=hive_context
                                              ),
                                          customer_key=customer_key),
              file_saveMode='overwrite',
              file_format='parquet',
              hdfs_path=send_control_files
              )

    send_files = [
        os.path.join(hdfs_output_path, '_'.join(
            map(str, [algorithm, event_id, 'send', control_file, dttm]))) for control_file in ['target', 'control']
    ]
    logger.info('Send Files: {0}'.format(send_files))
    return send_files
