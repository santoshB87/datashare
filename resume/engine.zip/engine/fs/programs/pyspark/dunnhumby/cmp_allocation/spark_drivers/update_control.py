import ast
import logging
import sys
import os
import tools.configs as cfg
from dunnhumby.cmp_allocation import contexts, file_system, customer_control
from dunnhumby.cmp_allocation.allocation import util as util

# set up basic logging
logger = logging.getLogger('spark_drivers.{0}'.format(__file__))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)

spark_context = contexts.sc()
hive_context = contexts.sql_context()
fs_client = file_system.get_client(file_system.HDFS_CLIENT)


def update_control(algorithm, dttm, allocated_files, hdfs_output_path, hdfs_control, event_id, config_file) :
    conf = cfg.Config(logger=logger)
    conf.add_source_file(path=config_file)

    hdfs_nnodes = conf.get_item(keys='hdfs_name_nodes', mandatory=True)
    web_root = conf.get_item(keys='webhdfs_root', mandatory=True)
    logger.info('Updating {0} control files based on allocation outputs'.format(algorithm))
    full_hdfs_control_path = os.path.join(hdfs_output_path, '_'.join(map(str, [algorithm, hdfs_control, event_id])))
    file_prefix = [
        "CONTROL_GROUP",
        "TARGET_GROUP",
        "PROGRAM_CONTROL_GROUP",
        "last_run_dttm"]
    control_files = [
        os.path.join(hdfs_output_path, file_name) for file_name in ['_'.join([f, dttm]) for f in file_prefix]]

    webhdfs_active_url = util.get_active_namenode_webhdfs_root(
        namenode_list=hdfs_nnodes,
        webhdfs_root=web_root,
        logger=logger
    )
    hdfs_url = webhdfs_active_url.replace('webhdfs/v1', '')

    control_variation = conf.get_item(keys=(algorithm, 'variation', '0'), mandatory=True)
    event_id = conf.get_item(keys=(algorithm, 'event', 'event_id'), mandatory=True)
    hdfs_control_path = os.path.join(full_hdfs_control_path, file_prefix[0])
    hdfs_target_path = os.path.join(full_hdfs_control_path, file_prefix[1])
    hdfs_program_control_path =  os.path.join(full_hdfs_control_path, file_prefix[2])
    control_weighting = control_variation['weighting']
    hdfs_last_run_dttm_path = os.path.join(full_hdfs_control_path, file_prefix[3])

    df = hive_context.read.parquet(*[allocated_files.values()[0]])
    customer_control.allocate_groups(input_df=df,
                                hive_context=hive_context,
                                fs_client = fs_client,
                                customer_key='customer',
                                file_format='parquet',
                                file_save_mode='overwrite',
                                control_directory=full_hdfs_control_path,
                                control_weight=control_weighting,
                                algorithm_run_timestamp=dttm)


    return control_files
