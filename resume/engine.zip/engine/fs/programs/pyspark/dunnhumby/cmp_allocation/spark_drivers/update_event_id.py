"""Check event ID control file and if current date is after end date of most recent event
 increment event ID by 1, derive new start and end dates and add this new event to the file
if derive_event_dates = "weekly"
    Start date: the Monday of the current week
    End date: the Sunday of the current week
if derive_event_dates = "daily"
    Start date: curent date
    End date: current date
Returns: Dict (by writing dict as literal to logger, to be parsed out by spark-submitting application)
    {event_id:,  start_date:, end_date}
"""
import ast
import datetime
import logging
import sys
from pyspark.sql import functions as func
from dunnhumby.cmp_allocation import contexts, spark_tools

# set up basic logging
logger = logging.getLogger('spark_drivers.{0}'.format(__file__))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    datefmt='%y/%m/%d %H:%M:%S'
)

spark_context = contexts.sc()
hive_context = contexts.sql_context()


def update_event(algorithm, config_file, derive_event_dates, event_id_hdfs_path) :

    # string format to use when reading and writing event start and end dates
    #date_fmt = '%Y/%m/%d'
    date_fmt = '%d%b%Y:%H:%M:%S'

    if derive_event_dates.lower() not in ["weekly", "daily"]:
        raise RuntimeError(
            'derive_event_dates value of {0} not valid, allowed value are "weekly" and "daily"'
            .format(derive_event_dates)
        )

    event_ctl_df = hive_context.read.parquet(event_id_hdfs_path)
    event_ctl_df.persist()
    event_ctl_tuples = event_ctl_df.orderBy(func.col('event_id').desc()).toJSON()

    schema = ['event_id', 'start_date', 'end_date']
    current_event = ast.literal_eval(event_ctl_tuples.first())

    current_date = datetime.datetime.today()
    current_event_id = current_event['event_id']
    current_event_start_date = datetime.datetime.strptime(str(current_event['start_date']), date_fmt)
    current_event_end_date = datetime.datetime.strptime(str(current_event['end_date']), date_fmt)

    # today's date is after the end date of the most recent event in our control file
    if current_date > current_event_end_date:

        # update event IDs and start and end dates
        event_id = current_event_id + 1
        if derive_event_dates.lower() == 'weekly':

            start_of_week = (current_date - datetime.timedelta(days=current_date.weekday()))
            end_of_week = start_of_week + datetime.timedelta(days=6)

            start_date = datetime.datetime(start_of_week.year, start_of_week.month, start_of_week.day, 0, 0, 0)
            end_date = datetime.datetime(end_of_week.year, end_of_week.month, end_of_week.day, 23, 59, 59)

        else:  # derive_event_dates.lower() == 'daily'
            start_date = datetime.datetime(current_date.year, current_date.month, current_date.day, 0, 0, 0)
            end_date = datetime.datetime(current_date.year, current_date.month, current_date.day, 23, 59, 59)

        # write new event back into our control file
        new_row = [
            (
                event_id,
                start_date.strftime(date_fmt),
                end_date.strftime(date_fmt)
            )
        ]
        new_df = hive_context.createDataFrame(new_row, schema)
        updated_event_ctl_df = event_ctl_df.select(schema).unionAll(new_df.select(schema))

        spark_tools.write_to_hdfs(
            input_df=updated_event_ctl_df,
            file_saveMode='overwrite',
            file_format='parquet',
            hdfs_path=event_id_hdfs_path,
            partition_column=None,
            number_of_files=1
        )

    else:
        event_id = current_event_id
        start_date = current_event_start_date
        end_date = current_event_end_date


    return_values_dict = {
        "event_id": event_id,
        "start_date": start_date.strftime(date_fmt),
        "end_date": end_date.strftime(date_fmt)
    }

    logger.info("Allocation Return Values: {0}".format(return_values_dict))
    event_start_date = datetime.datetime.strptime(return_values_dict['start_date'], date_fmt)
    event_end_date = datetime.datetime.strptime(return_values_dict['end_date'], date_fmt)
    return event_id, event_start_date, event_end_date
