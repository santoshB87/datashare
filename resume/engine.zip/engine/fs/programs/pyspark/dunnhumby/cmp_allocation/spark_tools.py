'''
spark_tools.py
'''
import tools.six as six
import logging
from functools import reduce
from pyspark.sql import DataFrame, Window
import pyspark.sql.functions as func
import datetime

logger = logging.getLogger(__name__)


# pylint: disable=bad-continuation
# pylint: disable=line-too-long, logging-format-interpolation

def quiet_logs(sc):
    """org and akka loggers are very verbose - set both to error"""
    logger = sc._jvm.org.apache.log4j
    logger.LogManager.getLogger("org").setLevel(logger.Level.ERROR)
    logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)


def get_df_from_csv(hive_context, file_name):
    return hive_context.read \
        .format("com.databricks.spark.csv") \
        .option("header", "true") \
        .option("nullValue", "true") \
        .load(file_name)


def get_df_from_csv_excluding_header(hive_context, file_name):
    df = hive_context.textFile(file_name).map(lambda line: line.split(","))
    data = df.first()
    df = df.filter(lambda x: x != data)
    return df


def union_all(dfs):
    """
        Args:
            dfs:  requires list of data frames to be joined
        Return
            One data frame of multiple data frames content
    """
    return reduce(DataFrame.unionAll, dfs)


def write_formatted_results_to_hdfs(spark_context,
                                    input_df,
                                    hdfs_path,
                                    number_of_files,
                                    partition_column,
                                    select_columns,
                                    sort_columns,
                                    write_mode,
                                    file_format,
                                    file_option_codec,
                                    add_columns=None,
                                    header='false'):
    '''

    :param spark_context:
    :param input_df:
    :param hdfs_path:
    :param number_of_files:
    :param partition_column:
    :param select_columns:
    :param sort_columns:
    :param write_mode:
    :param file_format:
    :param file_option_codec:
    :param add_columns:
    :param header:
    :return:
    '''

    logger.debug('creating file: {0}'.format(hdfs_path))
    logger.debug('number of files: {0}'.format(number_of_files))
    logger.debug('partition column: {0}'.format(partition_column))
    logger.debug('select columns: {0}'.format(select_columns))
    logger.debug('sort columns: {0}'.format(sort_columns))
    logger.debug('write mode: {0}'.format(write_mode))
    logger.debug('file format: {0}'.format(file_format))
    logger.debug('file option codec: {0}'.format(file_option_codec))

    # add any additional columns required - just supports constant values for now
    if add_columns:
        for c in add_columns:
            input_df = input_df.withColumn(c['name'], func.lit(c['value']))

    logger.debug(
        'output df schema:\n{0}'.format(input_df.select(select_columns).schema))

    # convert header to string repr if passed in as bool - the java class we use to create CSVs gets stroppy otherwise
    if isinstance(header, bool):
        header = header.__repr__().lower()

    file_options = dict()
    file_options['header'] = header
    if file_option_codec is not None:
        file_options['codec'] = file_option_codec

    # inspect spark version to determine available dataframe methods - sortWithinPartitions introduced and repartition
    # had partitioning columns added in spark 1.6.0
    if tuple(map(int, spark_context.version.split('.')[0:2])) >= (1, 6):
        logger.debug(
            'spark >= 1.6, repartitioning by {0} and sorting by {1}'.format(
                partition_column, sort_columns))

        input_df \
            .select(select_columns) \
            .repartition(number_of_files, partition_column) \
            .sortWithinPartitions(sort_columns).drop('offer_position') \
            .write.mode(write_mode) \
            .format(file_format) \
            .options(**file_options) \
            .save(hdfs_path)
    else:
        logger.debug('spark < 1.6, just repartitioning into {0} files'.format(
            number_of_files))
        input_df \
            .select(select_columns) \
            .repartition(number_of_files) \
            .write.mode(write_mode) \
            .format(file_format) \
            .options(**file_options) \
            .save(hdfs_path)
    logger.debug('file created')


def write_to_hdfs(input_df,
                  hdfs_path,
                  file_format='parquet',
                  file_saveMode='overwrite',
                  partition_column=None,
                  number_of_files=200):
    '''

    :param input_df:
    :param hdfs_path:
    :param file_format:
    :param file_saveMode:
    :param partition_column:
    :param number_of_files:
    :return:
    '''
    logger.info("Write {0} file {1} to HDFS".format(file_format, hdfs_path))
    if not partition_column:
        return input_df.coalesce(number_of_files) \
            .write.mode(file_saveMode) \
            .format(file_format) \
            .save(hdfs_path)
    else:
        return input_df.repartition(number_of_files, partition_column) \
            .write.mode(file_saveMode) \
            .format(file_format) \
            .save(hdfs_path)


def write_csv_to_hdfs(input_df,
                      hdfs_path,
                      file_format='com.databricks.spark.csv',
                      file_saveMode='overwrite',
                      number_of_files=1):
    '''

    :param input_df:
    :param hdfs_path:
    :param file_format:
    :param file_saveMode:
    :param number_of_files:
    :return:
    '''

    return input_df.repartition(number_of_files) \
        .write.mode(file_saveMode) \
        .format(file_format) \
        .option("header", "true") \
        .save(hdfs_path)


def write_csv_to_nfs(input_df,
                     nfs_path,
                     file_format='com.databricks.spark.csv',
                     file_saveMode='overwrite',
                     number_of_files=1):
    '''

    :param input_df:
    :param nfs_path:
    :param file_format:
    :param file_saveMode:
    :param number_of_files:
    :return:
    '''

    return input_df.repartition(number_of_files) \
        .write.mode(file_saveMode) \
        .format(file_format) \
        .option("header", "true") \
        .save(nfs_path)


def dropAll(df, *cols):
    """
        Args:
            dfs:  requires list of data frames to be joined
        Return
            One data frame of multiple data frames content
    """
    return reduce(DataFrame.drop, cols, df)


def write_formatted_results_to_jdbc(input_df,
                                    url,
                                    where,
                                    write_mode,
                                    properties,
                                    partition_column=None
                                    ):
    """ Write the content of a dataframe a external database table via JDBC.
           Args:
                input_df:  df
                url:  a JDBC URL
                jdbc_table: name of table
                partition_column: the column used to partition
                write_mode: specifies the behavior of the save operation when data already exists: append, overwrite, ignore, error
                properties: JDBC database connection arguments, a list of arbitrary string tag/value. Normally at least a user and password property should be included
    """

    logger.debug('Statement: {0}'.format(where))
    logger.debug('partition column: {0}'.format(partition_column))
    logger.debug('write mode: {0}'.format(write_mode))

    logger.info("Load results to exadata table:{0}".format(where))

    if partition_column is None:
        input_df.write.jdbc(url,
                            where,
                            properties=properties,
                            mode=write_mode,
                            )
    else:
        input_df.repartition(partition_column) \
            .write.jdbc(url,
                        where,
                        properties=properties,
                        mode=write_mode,
                        )
    logger.info('Table {0} updated'.format((where)))


def read_from_jdbc(hive_context,
                   url,
                   where,
                   properties,
                   jdbc_table=None,
                   partition_column=None,
                   ):
    """ Reads the content of a table from Oracle and store it as a DataFrame
           Args:
                hive_context:  a variant of Spark SQL
                url:  a JDBC URL
                jdbc_table: name of table
                partition_column: the column used to partition
                where  :  a list expressions suitable for inclusion in WHERE clauses; each one defines one partition of the DataFrame.
                properties: JDBC database connection arguments, a list of arbitrary string tag/value. Normally at least a user and password property should be included
           Return
               A data frame
    """
    return hive_context.read \
        .jdbc(url,
              where,
              properties=properties,
              columns=partition_column,
              table=jdbc_table)


def check_columns(df, column_list):
    """Check all columns in column list exist in input dataframe, pass silently, raise RuntimeError if any missing"""
    if isinstance(column_list, six.string_types):
        column_list = [column_list]
    cols_in_err = False
    missing_cols = list()
    for column in column_list:
        if column not in df.columns:
            missing_cols.append(column)
            cols_in_err = True
    if cols_in_err:
        raise RuntimeError(
            'The following columns were not found in the input dataframe: {0}'
            .format(', '.join(missing_cols)))


def update_df_attribute_content(input_df,
                                attribute,
                                update_to):
    """Update a dataframe column
     Args:
        input_df: the updated dataframe
        attribute: dataframe`s column name that will be updated
        update_to: the new value that will be update to

    """
    logger.info('Update {0}  to {1}'.format(attribute, update_to))
    if attribute not in input_df.columns:
        raise RuntimeError(
            "Attribute  '{0}' not found in input dataframe columns: {1}"
            .format(attribute, ', '.join(input_df.columns)))

    return input_df.withColumn(attribute, update_to)


def rename_df_columns(input_df,
                      select_columns,
                      rename_columns):
    """Rename DF columns         Args:
            input_df: recommendation DF
            select_columns: columns name selected to to be renamed
            rename_columns: the name of the new columns (the name of columns renamed to)
    """
    if isinstance(select_columns, six.string_types):
        select_columns = [select_columns]

    if isinstance(rename_columns, six.string_types):
        rename_columns = [rename_columns]

    if len(select_columns) != len(rename_columns):
        raise RuntimeError(
            "The number of column from both lists must be the same; select columns : {0} and rename columns : {1} ".format(
                select_columns, rename_columns))

    for col_name in select_columns:
        if col_name not in input_df.columns:
            raise RuntimeError(
                "Column '{0}' not found in input dataframe columns: {1}"
                .format(col_name, ', '.join(input_df.columns)))

    mapping_columns = dict(zip(select_columns, rename_columns))
    return input_df.select([func.col(c).alias(mapping_columns.get(c, c)) for c in select_columns])


def expand_to_doctcom(hive_context, dotcom_id_lookup_dimention, customer_key, dotcom_key, input_df):
    """Expand to dotcom customer level
           Args:
                  input_df: score DF
                  customer_key: customer column name
                  hive_context: a variant of Spark SQL
                  dotcom_id_lookup_dimention:  dictionary containing details of  all the dotcom ids of all emailable
                                               house holds such as HDFS path, dotcome column name , house hold column name
                  dotcom_key: dotcom column name
    """
    logger.info("Expand to dotcom customer level")

    if customer_key not in input_df.columns:
        raise RuntimeError("Customer  key column '{0}' not found in input dataframe columns: {1}"
                           .format(customer_key, ', '.join(input_df.columns)))

    dotcom_id_lookup_df = get_df_from_csv(hive_context=hive_context,
                                                  file_name=dotcom_id_lookup_dimention['hdfs_path'])

    if dotcom_id_lookup_dimention['hsds_key'] not in dotcom_id_lookup_df.columns:
        raise RuntimeError("House hold code column '{0}' not found in input dataframe columns: {1}"
                           .format(dotcom_id_lookup_dimention['hsds_key'], ', '.join(dotcom_id_lookup_df.columns)))

    if dotcom_id_lookup_dimention['dotcome_key'] not in dotcom_id_lookup_df.columns:
        raise RuntimeError("Dotcom ID  key column '{0}' not found in input dataframe columns: {1}"
                           .format(dotcom_id_lookup_dimention['dotcome_key'], ', '.join(dotcom_id_lookup_df.columns)))

    return dropAll(input_df.join(dotcom_id_lookup_df,
                                         input_df[customer_key] == dotcom_id_lookup_df[dotcom_id_lookup_dimention['hsds_key']],
                                         'inner') \
                           .withColumnRenamed(dotcom_id_lookup_dimention['dotcome_key'], dotcom_key),
                           *[col for col in dotcom_id_lookup_df.columns if col != dotcom_id_lookup_dimention['dotcome_key']])



def add_load_time(input_df,
                  date_format,
                  date_key):
    """ Add the current date to a DF  in the format specified by the {date_format}
        Args:
            input_df: allocation/scores DF
            date_format: date format; A pattern could be for instance dd.MM.yyyy and could return a string like 18.03.1993.
            date_key: date column name
    """
    logger.info("Add load date time in the format : {0}".format(date_format))
    return input_df.withColumn(date_key, func.date_format(func.current_date(), date_format))


def generate_allocation_output_for_unica(input_df,
                                         select_columns,
                                         rename_columns):
    """Rename allocation output columns to match Unica/exadata tables. The DF columns has to have the same name as the exadata table inserted into
        Args:
            input_df: the allocation DF
            select_columns: the allocation columns name selected to produce the final output
            rename_columns: the  Unica/exadata table columns name; the name of the new columns
    """

    logger.info("Generate allocations output to match exadata table")

    if isinstance(select_columns, list) is not True or not select_columns:
        raise RuntimeError("Select columns must be specified as a list of objects ")

    if isinstance(rename_columns, list) is not True or not rename_columns:
        raise RuntimeError("Rename columns must be specified as a list of objects ")

    if len(select_columns) != len(rename_columns):
        raise RuntimeError(
            "The number of column from both lists must be the same; select columns : {0} and rename columns : {1} ".format(
                select_columns, rename_columns))

    for col_name in select_columns:
        if col_name not in input_df.columns:
            raise RuntimeError("Column '{0}' not found in input dataframe columns: {1}"
                               .format(col_name, ', '.join(input_df.columns)))

    mapping_columns = dict(zip(select_columns, rename_columns))
    return input_df.select([func.col(c).alias(mapping_columns.get(c, c)) for c in select_columns])


def update_variation_event_allocation_output(input_df,
                                             file_name,
                                             variation_metadata,
                                             event_id):
    """ Increment variation by 1  and add the most recent event id to allocation output.
        Args:
           input_df: allocation/scores DF
           event_id: the most recent event lookup
    """

    logger.info("Increment variation by 1  and add the most recent event id to allocation output  ")

    if not event_id:
        raise RuntimeError("NO event id; the most recent event needs to be specify ")

    if isinstance(event_id, int) is not True:
        raise RuntimeError("Most recent event lookup must be int ")

    variation_desc = [(variation_id, variation_metadata[variation_id]['variation_description'])for variation_id in variation_metadata.keys() if variation_id.isdecimal()]

    if 'control' in file_name:
        variation = [variation_id for variation_id, desc in variation_desc if 'control' in desc.lower()]
    else:
        variation = [variation_id for variation_id, desc in variation_desc if 'target' in desc.lower()]

    return input_df.withColumn('variation_id', func.lit(int(variation[0]) + 1)) \
        .withColumn('event_id', func.lit(event_id))


def exadata_event_output(event_dict, event_id, start_date, end_date):
    """Take the event metadata template pulled from json config file and prepare for insertiong into newly created tables:

    Args:
        event_dict: the raw event template pulled from json config file
        start_date: the string formatted timestamp to add as  most recent start date from even lookup
        end_date: the string formatted timestamp to add as  most recent  end date from even lookup

    Returns:
        List of tuple representing metadata and the column_list representing the schema of the DF
    """

    logger.info("Prepare the event output metadata for insertion")
    column_list = ["event_id",
                   "service_id",
                   "variation_count",
                   "last_allocated_variation",
                   "randomized",
                   "active",
                   "start_date",
                   "end_date",
                   "control_group",
                   "service_description",
                   "service_prefix_code",
                   "service_lvl_cont_pct",
                   "program_lvl_cont_hh_digits"
                   ]
    # add runtime timestamp to event dict and append it into a list
    output_event_list = list()
    event_dict['event_id'] = event_id
    event_dict['start_date'] = datetime.datetime.strptime(start_date, '%d%b%Y:%H:%M:%S')
    event_dict['end_date'] = datetime.datetime.strptime(end_date, '%d%b%Y:%H:%M:%S')
    output_variations_tuple = tuple(
        [value.encode('latin-1') if isinstance(value, unicode) else value for key, value in sorted(event_dict.items())
         if key in column_list])
    output_event_list.append(output_variations_tuple)
    return output_event_list, sorted(column_list)

def exadata_variation_output(variation_dict, event_id, service_id):
    """Take the variation metadata template pulled from json config file and prepare for write to CSV

    Args:
        variation_dict: the raw variation template pulled from json config file
        event_id: string to populate the event_id field
        service_id: string to populate the service_id field
    Returns:
         List of tuple representing metadata and the column_list representing the schema of the DF
    """

    logger.info("Prepare the variation output metadata for insertion")
    output_variations_list = list()

    column_list = [
        "event_id",
        "service_id",
        "variation_id",
        "variation_description"
    ]

    for variation_id in sorted([variation_id for variation_id in variation_dict.keys() if variation_id.isdecimal()]):
        row = dict()
        row['event_id'] = event_id
        row['service_id'] = service_id
        row['variation_id'] = int(variation_id) + 1
        row['variation_description'] = variation_dict[variation_id]['variation_description']
        output_variations_tuple = tuple([value for key, value in sorted(row.items()) if key in column_list])
        output_variations_list.append(output_variations_tuple)

    return output_variations_list, sorted(column_list)

def create_data_frame(hive_context,
                      list_of_tuples,
                      schema):

    return hive_context.createDataFrame(list_of_tuples,schema)


def generate_broken_links_report(input_df,
                                 promo_key,
                                 store_key,
                                 file_path,
                                 file_mode,
                                 file_format,
                                 header_flag):

    """Generate Broken Links Report
        Output a unique list of offers from the recommendations, inluding :
            i. Offer ID
            ii. Test URL ('http://www.tesco.com/groceries/SpecialOffers/SpecialOfferDetail/Default.aspx?promoId=' concatenated with the OFFER_URL).
            iii. Product description
            iv. The store with the highest number of dotcom customers  recommended the product and promotion
            v. The number of dotcom customers  recommended that product and promotion in the chosen store
        Args:
            input_df: the data frame input
            promo_key: the name of promo attribute/column
            store_key: the name of store attribute/column
            file_path: the HDFS location where the file will be saved
            file_mode:
            file_format:
            header_flag: True if file needs headers False otherwise
    """
    logger.info("Generate Broken Links Report")
    check_columns(df=input_df,
                          column_list=[promo_key, store_key])

    # count offers per store
    offer_store = input_df.groupBy([promo_key, store_key]).count() \
        .withColumnRenamed(promo_key, 'promo_key') \
        .withColumnRenamed('count', 'count_offer_store')

    ws = Window.partitionBy(['promo_key']) \
        .orderBy(offer_store['count_offer_store'].desc())

    # pick the offer in the store with the highest count
    offer_store = offer_store.withColumn("rank_store", func.rowNumber().over(ws)) \
        .where("rank_store  = 1")

    # count products per offer
    offer_prod = input_df.groupBy([promo_key, 'image_description']).count() \
        .withColumnRenamed('count', 'count_offer_prod_dotcome')

    ws = Window.partitionBy([promo_key, 'image_description']) \
        .orderBy(offer_prod['count_offer_prod_dotcome'].desc())

    # pick the offer with the biggest number of products
    offer_prod = offer_prod.withColumn("rank_offer", func.rowNumber().over(ws)) \
        .where("rank_offer = 1")

    report_df = offer_store.join(offer_prod,
                                 func.col(promo_key) == func.col('promo_key'),
                                 'inner')

    # create the test url
    report_df = report_df.withColumn('test_url', func.concat(
        func.lit('http://www.tesco.com/groceries/SpecialOffers/SpecialOfferDetail/Default.aspx?promoId='),
        func.col(promo_key)))

    # rename columns to match the headers from the broken link report
    select_columns = [promo_key, 'test_url', 'image_description', 'FulfillmentStore', 'count_offer_prod_dotcome']
    rename_select = ['offer_url', 'test_url', 'product', 'store_number', 'count']

    report_df = rename_df_columns(input_df=report_df,
                                              select_columns=select_columns,
                                              rename_columns=rename_select)

    report_df.repartition(1) \
        .write.mode(file_mode) \
        .format(file_format) \
        .options(header=header_flag) \
        .save(file_path)


def unionAll(*dfs):
    """
        Args:
            dfs:  requires list of data frames to be joined
        Return
            One data frame of multiple data frames content
    """
    return reduce(DataFrame.unionAll,dfs)
