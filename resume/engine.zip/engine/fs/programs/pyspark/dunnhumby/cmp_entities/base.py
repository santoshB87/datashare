'''
Base class for entities
'''
import abc
import logging
import six

from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import StructType, StructField, BooleanType
import pyspark.sql.functions as F

from dunnhumby import contexts

logger = logging.getLogger(__name__)


class CMPEntity(object):
    """
    Base CMP Entity Class
    """
    __metaclass__ = abc.ABCMeta

    # pylint: disable=logging-not-lazy
    # pylint: disable=bad-continuation
    # pylint: disable=line-too-long
    # pylint: disable=no-self-use

    def __init__(self):
        super(CMPEntity, self).__init__()
        self.__required_schema = None
        self.__df = None
        self.__unique_columns = list()
        self.__sc = contexts.sc()
        self.sqlContext = contexts.sql_context()
        self.__one_to_manys = None

    @abc.abstractproperty
    def database(self):
        "media mart database name"
        pass

    @abc.abstractproperty
    def table(self):
        "media mart table name"
        pass

    @property
    def required_schema(self):
        """
        required schema of this CMP Entity - setter will raise exception if not a pyspark StructType.

        A client-agnostic schema is defined for each entity. All client-specific implementations must adhere to this
        schema. This is a critical tenet of the solution, all clients must implement the same schema for each entity. Doing
        so allows us to write client-agnostic code that consumes those entities. Python does not have a way to prevent
        a function from being overwritten (see https://stackoverflow.com/questions/2425656/how-to-prevent-a-function-from-being-overridden-in-python)
        thus we rely on the discipline of our developers to adhere to and uphold this tenet.
        """
        return self.__required_schema

    @required_schema.setter
    def required_schema(self, value):
        '''

        :param value:
        :return:
        '''
        if not isinstance(value, StructType):
            raise TypeError('Required schema must be a pyspark StructType object, %s passed to setter' % type(value))
        logger.debug('Setting required schema to: \n%s' % value)
        self.__required_schema = value

    @property
    def unique_columns(self):
        '''
        define columns that uniquely define this CMP Entity. Setter will raise an exception if not in required schema
        '''
        return self.__unique_columns

    @unique_columns.setter
    def unique_columns(self, value):

        # convert value to list if only a single column specified
        if isinstance(value, six.string_types):
            value = [value]

        # get distinct set of all columns specified
        column_set = set()
        for element in value:
            if isinstance(element, six.string_types):
                column_set.add(element)
            else:
                for sub_element in element:
                    column_set.add(sub_element)

        # check all columns exist in input
        bad_cols = column_set - set(self.required_schema.names)
        if bad_cols:
            raise ValueError(
                'The following columns specified in the unique_columns list were not found in the required_schema: %s'
                % ','.join(list(bad_cols))
            )
        logger.debug('Setting unique columns to: %s' % value)
        self.__unique_columns = value

    @property
    def one_to_manys(self):
        '''
        one_to_many property of this CMP Entity - setter will raise exception if conditions not met
        '''
        return self.__one_to_manys

    @one_to_manys.setter
    def one_to_manys(self, value):
        '''
        :param value:
        '''
        if value is not None:
            if not isinstance(value, list):
                raise ValueError("Value attempting to be assigned to one_to_manys is not a list")
            if not self._check_if_each_element_of_the_one_to_many_list_is_a_tuple(one_to_manys=value):
                raise ValueError("Value attempting to be assigned to one_to_manys is not a list of tuples")
            if not self._check_if_each_tuple_has_exactly_two_elements(one_to_manys=value):
                raise ValueError("Value attempting to be assigned to one_to_manys contains tuples whose length is not 2")
            if not self._check_if_one_to_manys_value_has_non_existent_column(value, self.required_schema):
                raise ValueError('The columns specified in the one_to_manys list were not found in the required_schema')

        self.__one_to_manys = value

    @property
    def data(self):
        '''

        :return :df
        '''
        if self.__df is None:
            raise ValueError("Object data property has been accessed prior to calling get_data() or get_data does not set data property")
        return self.__df

    @data.setter
    def data(self, value):
        '''

        :param value:
        :return:
        '''
        self.validate(value=value)
        self.__df = value

    def validate(self, value):
        '''

        :param value:
        :return:
        '''
        if not isinstance(value, DataFrame):
            raise TypeError(
                "df must be a pyspark DataFrame object, %s passed to setter" % type(value))
        if not value.schema == self.required_schema:
            raise ValueError(
                "df schema:\n%s \ndoes not match required schema:\n%s" % (
                value.schema, self.required_schema))
        if not self._uniqueness_rules_met(df=value):
            raise ValueError(
                'Incoming dataframe does not meet uniqueness rules defined in unique_columns')
        if self.one_to_manys is not None:
            if not self._one_to_many_rules_met(self.one_to_manys, df=value):
                raise ValueError('Incoming dataframe does not meet referential integrity rules '
                                 'defined in one_to_manys')

    @property
    def count(self):
        '''

        :return :count
        '''
        return self.__df.count

    def get_data(self, config_dict=None):

        df = self.sqlContext.table('.'.join([self.database, self.table]))

        if "stores_closed_flag" in df.columns:
            self.required_schema.add(StructField("stores_closed_flag", BooleanType(), True))

        if not bool(config_dict):
            df = df.select([field.name for field in self.required_schema.fields])
        else:
            filter_condition = config_dict["filter_condition"]
            df = df.filter(filter_condition).select([field.name for field in self.required_schema.fields])


        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            df = df.withColumn(field.name, df[field.name].cast(field.dataType))

        # self.df is a property - validation of its schema and column uniqueness is handled in
        # the setter method
        self.data = df

    def _uniqueness_rules_met(self, df):
        '''

        :param df:
        :return:
        '''
        tests_passed = True
        for column_set in self.unique_columns:
            if df.count() != df.select(column_set).distinct().count():
                logger.error('Dataframe is not unique by: %s' % column_set)
                tests_passed = False
            else:
                logger.info('Dataframe is unique by: %s' % column_set)
        return tests_passed

    def _check_if_each_element_of_the_one_to_many_list_is_a_tuple(self, one_to_manys):
        '''

        :param one_to_manys:
        :return:
        '''
        for element in one_to_manys:
            if not isinstance(element, tuple):
                return False
        return True

    def _check_if_each_tuple_has_exactly_two_elements(self, one_to_manys):
        '''

        :param one_to_manys:
        :return:
        '''
        for element in one_to_manys:
            if len(element) != 2:
                return False
        return True

    def _one_to_many_rules_met(self, one_to_manys, df):
        '''

        :param one_to_manys:
        :param df:
        :return:
        '''
        for one_to_many in one_to_manys:
            groupedby_df = df.groupBy('{subcategory}'.format(subcategory=one_to_many[1])). \
                agg(F.countDistinct('{category}'.format(category=one_to_many[0])))
            df_to_test_one_to_many_relationship = \
                groupedby_df.filter(groupedby_df['count(DISTINCT {category})'.format(category=one_to_many[0])] > 1)
            if df_to_test_one_to_many_relationship.count() > 0:
                logger.error("One-to-many {one_to_many} has been violated".format(one_to_many=one_to_many))
                return False
        logger.info('Dataframe meets all one to many rules defined in {0}'.format(one_to_manys))
        return True

    def _check_if_one_to_manys_value_has_non_existent_column(self, one_to_manys, required_schema):
        '''

        :param one_to_manys:
        :param required_schema:
        :return:
        '''
        fields_not_found = []
        for x in one_to_manys:
            for field in x:
                if field not in required_schema.names:
                    fields_not_found.append(field)
        if not fields_not_found:
            return True
        logger.error('The following fields were not found in the specified schema {0}'.format(fields_not_found))
        return False

