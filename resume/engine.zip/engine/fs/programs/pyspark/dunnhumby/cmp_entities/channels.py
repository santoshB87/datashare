'''
Base class for channel entity
'''


import pyspark.sql.types as pt

import dunnhumby


class Channels(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Channel entity class
    """

    # pylint: disable=super-on-old-class
    # pylint: disable=too-few-public-methods

    def __init__(self):
        """
        Define the Channels schema and column or columns that uniquely define a Channel
        """
        super(Channels, self).__init__()

        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Channel', pt.StringType(), True))
        required_schema.add(pt.StructField('ChannelDescription', pt.StringType(), True))

        self.required_schema = required_schema
        # self.get_data()

    @property
    def table(self):
        return 'channels'
