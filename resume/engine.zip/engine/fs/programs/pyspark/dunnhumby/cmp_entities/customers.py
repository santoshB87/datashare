

import pyspark.sql.types as pt

import dunnhumby


class Customers(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Customers entity class
    """

    # pylint: disable=super-on-old-class
    # pylint: disable=too-few-public-methods
    # pylint: disable=no-self-use

    def __init__(self):
        """
        Define the Customers schema and column or columns that uniquely define a Customer
        """
        super(Customers, self).__init__()

        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Customer', pt.StringType(), True))
        required_schema.add(pt.StructField('FulfillmentStore', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore1', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore2', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore3', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerGender', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerAge', pt.IntegerType(), True))
        required_schema.add(pt.StructField('CustomerSloyaltyHigh', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerSloyaltyHighDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerSloyaltyLow', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerSloyaltyLowDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerRegion', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerFamilyCustomPanelName', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerLifeStage', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerLifeStageDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerPriceSensitivity', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerPriceSensitivityDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerLifeStyle', pt.StringType(), True))
        required_schema.add(pt.StructField('CustomerLifeStyleDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('IsBlacklisted', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsEmailable', pt.BooleanType(), True))

        required_schema.add(pt.StructField('IsMailable', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsScottish', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsBabyCompliant', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsBabyAddrSupress_', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsBereaved', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsDiabetic', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsHalal', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsKosher', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsTeetotal', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsAddrSuppress', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsVegetarian', pt.BooleanType(), True))

        self.required_schema = required_schema
        # self.get_data()

    @property
    def table(self):
        return 'customers'