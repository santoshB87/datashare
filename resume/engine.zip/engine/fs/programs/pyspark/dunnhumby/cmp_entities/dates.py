'''
Base class of Dates Entity
'''
import pyspark.sql.types as pt

import dunnhumby


class Dates(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Dates entity class
    """

    # pylint: disable=pointless-string-statement
    # pylint: disable=too-few-public-methods
    # pylint: disable=line-too-long
    # pylint: disable=super-on-old-class
    def __init__(self):
        """
        Define the Dates schema and column or columns that uniquely define a Date
        """
        super(Dates, self).__init__()

        '''
        The author thought long and hard about what the field names should be. In the end it was decided to adhere to
         field names that are already defined in CDM. No advantage was discerned to be gained by deviating from
         those conventions. To put it another way, someone has clearly put a lot of thought into the names of those fields,
         why bother changing them given that the concept of a date dimension is by its very nature client agnostic.
        '''
        required_schema = pt.StructType()
        required_schema.add(pt.StructField("date_id", pt.DateType(), True))
        required_schema.add(pt.StructField("date_name", pt.StringType(), True))
        required_schema.add(pt.StructField("date_short_name", pt.StringType(), True))
        required_schema.add(pt.StructField("day_of_week_name", pt.StringType(), True))
        required_schema.add(pt.StructField("fis_week_id", pt.StringType(), True))
        required_schema.add(pt.StructField("fis_day_of_week_num", pt.StringType(), True))

        self.required_schema = required_schema

        # self.get_data()


    @property
    def table(self):
        return 'dates'
