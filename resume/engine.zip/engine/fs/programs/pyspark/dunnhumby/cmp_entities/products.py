"""
Base CMP Products entity class
"""
import pyspark.sql.types as pt
import pyspark.sql.functions as F
import dunnhumby


class Products(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Products entity class
    """
    # pylint: disable=super-on-old-class

    def __init__(self):
        """
        Define the products schema and column or columns that uniquely define a Product
        """
        super(Products, self).__init__()

        # Subgroup/Group/Division represent the attributes that collectively
        # define what becomes known as the "product hierarchy". That said, we
        # don't explcitly define hierarchies, we only define attributes of a
        # Product from which hierarchies can be formed later.
        # The challenge we have is what to call these attributes that will
        # form "the product hierarchy". Everyone  in dunnhumby refers to
        # these things differently so defining names of these things that are
        # client-agnostic yet still unambiguous is pretty much an exercise in
        # futility. The names used here are the result of a Yammer
        # conversation in February 2017:
        # https://www.yammer.com/dunnhumby.com/#/Threads/show?threadId=837437758
        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Product', pt.StringType(), True))
        required_schema.add(pt.StructField('ProductDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Subgroup', pt.StringType(), True))
        required_schema.add(pt.StructField('SubgroupDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Group', pt.StringType(), True))
        required_schema.add(pt.StructField('GroupDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Section', pt.StringType(), True))
        required_schema.add(pt.StructField('SectionDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Department', pt.StringType(), True))
        required_schema.add(pt.StructField('DepartmentDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Division', pt.StringType(), True))
        required_schema.add(pt.StructField('DivisionDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('ProductHiearchyType', pt.StringType(), True))
        required_schema.add(pt.StructField('ProductBrand', pt.StringType(), True))
        required_schema.add(pt.StructField('ProductSupplier', pt.StringType(), True))
        required_schema.add(pt.StructField('IsAlcohol', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsFuel', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsBaby', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsPet', pt.BooleanType(), True))
        required_schema.add(pt.StructField('IsSoldbyWeight', pt.BooleanType(), True))
        required_schema.add(pt.StructField('ProductImage', pt.StringType(), True))
        required_schema.add(pt.StructField('IsNew', pt.BooleanType(), True))
        required_schema.add(pt.StructField('NewProductLaunchDateTime', pt.TimestampType(), True))


        self.required_schema = required_schema
        # self.get_data()

    @property
    def table(self):
        return 'products'
