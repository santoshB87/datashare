'''
Base class for Promotions entity
'''
import logging
import pyspark.sql.types as pt
import dunnhumby
logger = logging.getLogger(__name__)

class Promotions(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Promotions entity class
    """
    # pylint: disable=broad-except
    # pylint: disable=missing-final-newline
    # pylint: disable=line-too-long
    # pylint: disable=super-on-old-class
    # pylint: disable=logging-format-interpolation
    def __init__(self):
        """
        Define the Promotions schema and column or columns
        that uniquely define 'Promotions'.
        """
        super(Promotions, self).__init__()

        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Promotion', pt.StringType(), True))
        required_schema.add(pt.StructField('PromotionDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Product', pt.StringType(), True))
        required_schema.add(pt.StructField('Store', pt.StringType(), True))
        required_schema.add(pt.StructField('Channel', pt.StringType(), True))
        required_schema.add(pt.StructField('MechanicCode', pt.StringType(), True))
        required_schema.add(pt.StructField('PromotionType', pt.StringType(), True))
        required_schema.add(pt.StructField('PromotionStartDatetime', pt.TimestampType(), True))
        required_schema.add(pt.StructField('PromotionEndDatetime', pt.TimestampType(), True))
        required_schema.add(pt.StructField('fis_week_id', pt.IntegerType(), True))
        required_schema.add(pt.StructField('PricePromoAmt', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('PricePrePromoAmt', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('DiscountAmount', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('DiscountPercent', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('Sponsored', pt.IntegerType(), True))

        self.required_schema = required_schema
        # self.get_data()

    @property
    def table(self):
        return 'promotions'