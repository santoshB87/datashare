"""
Base class for Purchases Entity
"""


import logging
from os import path
from pyspark.sql import types as pt, functions as pf
from dunnhumby.cmp_entities.base import CMPEntity
from dunnhumby.cmp_features.purchasing_feature_util import match_table_structure, Col_tuple


logger = logging.getLogger(__name__)


class Purchases(CMPEntity):
    """
    Base CMP Purchases entity class
    Client class inheriting this should override specific variable & method if required.
    """

    def __init__(self, config):
        """
        Define the Purchases entity schema and other required variable.
        :param config: config info from config.json
        """
        self.config = config
        super(Purchases, self).__init__()
        required_schema = pt.StructType()
        required_schema.add(pt.StructField("Basket", pt.StringType(), True))
        if self.config.get("SSEFeaturePacFlag", "False").lower() == "true":
            for item in self.config["SSEProductHierarchy"]:
                required_schema.add(pt.StructField(item, pt.StringType(), True))
        else:
            for item in self.config["SSEProductHierarchy"]:
                if item not in self.config.get("SSEFeaturePacColumns", []):
                    required_schema.add(pt.StructField(item, pt.StringType(), True))
        required_schema.add(pt.StructField("Customer", pt.StringType(), True))
        required_schema.add(pt.StructField("Store", pt.StringType(), True))
        required_schema.add(pt.StructField("Banner", pt.StringType(), True))
        required_schema.add(pt.StructField("FulfillmentStore", pt.StringType(), True))
        required_schema.add(pt.StructField("PreferredStore1", pt.StringType(), True))
        required_schema.add(pt.StructField("PreferredStore2", pt.StringType(), True))
        required_schema.add(pt.StructField("PreferredStore3", pt.StringType(), True))
        required_schema.add(pt.StructField("Channel", pt.StringType(), True))
        required_schema.add(pt.StructField("Quantity", pt.DecimalType(24, 2), True))
        required_schema.add(pt.StructField("NetSpendAmount", pt.DecimalType(38, 2), True))
        required_schema.add(pt.StructField("SpendAmount", pt.DecimalType(38, 2), True))
        required_schema.add(pt.StructField("DiscountAmount", pt.DecimalType(38, 2), True))
        required_schema.add(pt.StructField("fis_week_id", pt.StringType(), True))
        required_schema.add(pt.StructField("date_id", pt.DateType(), True))
        self.required_schema = required_schema
        self.unique_columns = []
        self.one_to_manys = None
        self.table_name = self.config["SSEHiveWorkdb"] + "." + self.config["SSEHivePurchaseTab"]
        self._table_path = path.join(self.config["SSEHiveWarehousePath"],
                                     self.config["SSEHiveWorkdb"],
                                     self.config["SSEHivePurchaseTab"])
        self._partition_cols = ["fis_week_id", "date_id"]
        self.__partition_info = None
        self.table_structural_change_flag = self.fix_table_structure()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def fix_table_structure(self):
        """
        Check purchase table structure and refresh it based on anomaly in table schema
        :return: True/False: Boolean
        """
        # Create purchase table if not exists
        if self.config["SSEHivePurchaseTab"].lower() not in [item.name.lower() for item in
                                                             self.sqlContext.catalog.listTables(
                                                                 dbName=self.config["SSEHiveWorkdb"]) if
                                                             item.tableType == "MANAGED"]:

            logger.info("Creating missing purchase table %s", self.table_name)
            self.sqlContext.sql(self.table_ddl())
            return True
        logger.info("purchase table %s exists, checking for structural changes", self.table_name)
        col_info = [Col_tuple(col_name=field.name.lower(),
                              data_type=field.dataType.simpleString().lower().replace("type", "").
                              replace("date", "string")) for field in self.required_schema.fields]
        if not match_table_structure(self.sqlContext, self.config["SSEHiveWorkdb"],
                                     self.config["SSEHivePurchaseTab"], col_info,
                                     self._partition_cols):
            logger.info("Existing table schema of %s doesn't match with declared schema, refresh "
                        "will be done", self.table_name)
            self.sqlContext.sql("DROP TABLE IF EXISTS {0}".format(self.table_name))
            self.sqlContext.sql(self.table_ddl())
            return True
        logger.info("No structural changes detected in purchase table %s", self.table_name)
        return False

    def table_ddl(self):
        """
        Returns hive table definition of purchases entity
        :return: purchase_ddl: String:
        """
        # Generate create statement
        # Table header
        create_header = "CREATE TABLE IF NOT EXISTS " + self.table_name
        # Column list
        col_lst = ["{colname} {datatype}".format(colname=field.name.lower(),
                                                 datatype=field.dataType.simpleString().lower().
                                                 replace("type", "").replace("date", "string"))
                   for field in self.required_schema.fields
                   if field.name not in self._partition_cols]
        create_col_lst = " (" + ", ".join(col_lst) + ") "
        # Table storage properties
        create_storage_prop = "PARTITIONED BY (" + \
                              ", ".join(["{col_name} string".format(col_name=item.lower())
                                         for item in self._partition_cols]) + \
                              ") STORED AS PARQUET" + \
                              ' TBLPROPERTIES ("parquet.compression"="gzip")'
        purchase_ddl = create_header + create_col_lst + create_storage_prop
        return purchase_ddl

    def get_data(self):
        """
        Create a spark dataframe on top of purchases entity/table.
        Note - This is read/return whole tables, doesn't leverage partition access, use with caution
        :return: None
        """
        # Read whole table
        purchases_df = self.sqlContext.table(self.table_name).select(self.required_schema.names)
        # Renaming & casting columns to comply with CMP Entity schema
        purchases_df = purchases_df.select(
            [pf.col(field.name).cast(field.dataType).alias(field.name)
             for field in self.required_schema.fields])
        self.data = purchases_df

    def get_partition(self, fis_week_id, date_id=None):
        """
        Return spark dataframe over a partition of purchases entity/table.
        Purchases entity/table is multilevel partitioned on fis_week_id and date_id.
        :param fis_week_id: String: data related to only that fis_week_id will be returned.
        :param date_id: String: if date (iso format) is specified, data related to only that date
        within the specified fis_week_id will be returned.
        :return: purchase_part_df: spark dataframe
        """
        if fis_week_id is None:
            raise ValueError("Caller must provide valid value for fis_week_id")
        partition_path = path.join(self._table_path, "fis_week_id={0}".format(fis_week_id))
        if date_id:
            partition_path = path.join(partition_path, "date_id={0}".format(date_id))
        # TODO: should we handle error while loading invalid partitions (like Py4JJavaError etc)
        purchases_part_df = self.sqlContext.read.format("parquet").option("compression", "gzip").\
            option("basePath", self._table_path).load(partition_path). \
            select(self.required_schema.names)
        # Renaming & casting columns to comply with CMP Entity schema
        purchases_part_df = purchases_part_df.select(
            [pf.col(field.name).cast(field.dataType).alias(field.name)
             for field in self.required_schema.fields])
        self.validate(purchases_part_df)
        return purchases_part_df

    def get_partition_info(self, refresh=False):
        """
        Fetches partition info of purchases entity/table
        :param refresh: invalidate last cached result and fetch partitions info again
        :return: list(): list of partition values
        """
        # table partition info, sample row - Row(result=fis_week_id=201701/date=2017-01-01')
        if self.__partition_info is None or refresh:
            part_info = self.sqlContext.sql("show partitions {tabname}".
                                            format(tabname=self.table_name)).collect()
            self.__partition_info = [tuple(map(lambda x: x.split("=")[1], row["partition"].split("/")))
                                     for row in part_info]
        return self.__partition_info

    def del_partition(self, **kwargs):
        """
        Safe delete partition from underlying hive table.
        :param kwargs: partition specification in key-val format where key will be partition column
        name and partition value (column value) would be val
        :return: None
        """
        partition_spec = []
        for key in kwargs:
            partition_spec.append("{colname}='{value}'".format(colname=key, value=kwargs[key]))
        if partition_spec:
            drop_stmt = "ALTER TABLE " + self.table_name + \
                        " DROP IF EXISTS PARTITION ({0})".format(",".join(partition_spec))
            self.sqlContext.sql(drop_stmt)

    def write_data(self, transactions_df, customers_df, products_df, stores_df):
        """
        Writes data into purchases entity's hive table
        :param transactions_df: dataframe containing transactions data
        :param customers_df: dataframe containing customers data
        :param products_df: dataframe containing products data
        :param stores_df: dataframe containing stores data
        :param channels_df: dataframe containing channels data
        :return: None
        """

        # Remove zero spend products
        zero_spend_prod = transactions_df.groupBy("Product").agg(pf.sum("NetSpendAmount").alias("Product_Sales")) \
            .where(pf.col("Product_Sales") == 0).select("Product")

        transactions_df = transactions_df.join(zero_spend_prod, "Product", "left_anti")

        # If there is skew on card_id then, it should be handled here by bifurcating into two jobs.

        transaction_columns = transactions_df.columns
        transaction_columns.sort()

        cust = customers_df.filter(customers_df["Customer"] != "").filter("Customer is not null").select("Customer")
        unknown_transaction = transactions_df.filter("Customer = '' or Customer is null")\
            .withColumn("Customer", pf.when(pf.trim(pf.col("Customer")) == '', None).otherwise(pf.col("Customer")))\
            .select(*transaction_columns)

        transactions_df_known_customers = transactions_df.join(cust, "Customer")
        transactions_df_known_customers = transactions_df_known_customers.select(*transaction_columns)

        transactions_df = unknown_transaction.union(transactions_df_known_customers)

        trans_cust_join = transactions_df["Customer"] == customers_df["Customer"]
        trans_prod_join = transactions_df["Product"] == products_df["Product"]
        trans_store_join = transactions_df["Store"] == stores_df["Store"]

        transactions_df = transactions_df.join(customers_df, trans_cust_join, "left_outer").drop(customers_df['Customer'])
        transactions_df = transactions_df.join(products_df, trans_prod_join).drop(products_df['Product'])
        transactions_df = transactions_df.join(stores_df, trans_store_join, "left_outer").drop(stores_df["Store"])
        purchase_df = transactions_df.select([pf.col(c).alias(c.lower()) for c in self.required_schema.names])

        repart_num = self.config.get("SSEFeaturePurchaseRePartitionNum", 125)
        purchase_df.repartition(repart_num).write.format("hive").option("compression", "gzip").\
            mode("append").insertInto(self.table_name)
