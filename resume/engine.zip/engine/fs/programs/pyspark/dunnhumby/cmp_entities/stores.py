'''
Base class for Stores Entity
'''

import pyspark.sql.types as pt
import pyspark.sql.functions as F

import dunnhumby


class Stores(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Stores entity class
    """

    # pylint: disable=no-self-use
    # pylint: disable=super-on-old-class
    # pylint: disable=no-self-argument

    def __init__(self):
        """
        Define the Stores schema and column or columns that uniquely define a Store
        """
        super(Stores, self).__init__()

        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Store', pt.StringType(), True))
        required_schema.add(pt.StructField('StoreDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('Banner', pt.StringType(), True))
        required_schema.add(pt.StructField('BannerDescription', pt.StringType(), True))
        required_schema.add(pt.StructField('StoreFormat', pt.StringType(), True))
        required_schema.add(pt.StructField('StoreRegion', pt.StringType(), True))
        required_schema.add(pt.StructField('StoreDivision', pt.StringType(), True))

        # required schema is a property - setter will raise exception if not a pyspark StructType
        self.required_schema = required_schema
        # self.get_data()

    @property
    def table(self):
        return 'stores'