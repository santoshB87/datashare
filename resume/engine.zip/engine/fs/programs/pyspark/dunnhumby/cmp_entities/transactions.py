'''
Base class of Transactions entity
'''

import pyspark.sql.types as pt
from pyspark.sql.dataframe import DataFrame
import dunnhumby
from pyspark.sql.types import StructField, StructType, DateType
import pyspark.sql.functions as F

import logging

logger = logging.getLogger(__name__)


class Transactions(dunnhumby.cmp_entities.base.CMPEntity):
    """
    Base CMP Transactions entity class
    """

    # pylint: disable=line-too-long
    # pylint: disable=super-on-old-class
    def __init__(self):
        """
        Define the Transactions schema
        """
        super(Transactions, self).__init__()
        self.__most_recent_transaction_date = None


        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Basket', pt.StringType(), True))
        required_schema.add(pt.StructField('DateTime', pt.TimestampType(), True))
        required_schema.add(pt.StructField('Product', pt.StringType(), True))
        required_schema.add(pt.StructField('Customer', pt.StringType(), True))
        required_schema.add(pt.StructField('Store', pt.StringType(), True))
        required_schema.add(pt.StructField('Channel', pt.StringType(), True))
        required_schema.add(pt.StructField('Quantity', pt.IntegerType(), True))
        required_schema.add(pt.StructField('SpendAmount', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('NetSpendAmount', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('DiscountAmount', pt.DecimalType(18, 2), True))
        required_schema.add(pt.StructField('fis_year_id', pt.IntegerType(), True))
        required_schema.add(pt.StructField('fis_week_id', pt.IntegerType(), True))
        required_schema.add(pt.StructField('date_id', pt.DateType(), True))

        self.required_schema = required_schema

        self.__partition_info = None

        # self.get_data()
        # self.get_most_recent_transaction_date()

    @property
    def table(self):
        return 'transactions'

    def get_most_recent_transaction_date(self):
        '''

        :return:
        '''
        self.most_recent_transaction_date = (self.data.agg(F.max("date_id").alias('max_date_id'))
                                             .withColumn('most_recent_transaction_date',F.col('max_date_id').cast(pt.DateType()))
                                             .drop('max_date_id'))

    @property
    def most_recent_transaction_date(self):
        '''

        :return:
        '''
        if self.__most_recent_transaction_date is None:
            raise ValueError("most_recent_transaction_date property has been accessed prior to calling get_most_recent_transaction_date() or get_most_recent_transaction_date does not set most_recent_transaction_date property")
        return self.__most_recent_transaction_date

    @most_recent_transaction_date.setter
    def most_recent_transaction_date(self, value):
        '''
        Even though, intuitively, the value to be returned should be a scalar value of type datetime.date in actual fact
        this shall return a Spark dataframe. The reason being that calculating the most recent transaction date is a
        computationally expensive operation that should only be done if the data is requested. By stipulating the value
        is a Spark dataframe we take advantage of Spark lazy evaluation i.e. data processing will only occur if and when
        the property is referenced.
        :param value:
        :return:
        '''
        if not isinstance(value, DataFrame):
            raise TypeError("df must be a pyspark DataFrame object, %s passed to setter" % type(value))
        most_recent_transaction_date_schema = StructType([StructField("most_recent_transaction_date", DateType(), True)])
        if not value.schema == most_recent_transaction_date_schema:
            raise ValueError(
                "df schema:\n%s \ndoes not match required schema:\n%s" % (value.schema, most_recent_transaction_date_schema))
        self.__most_recent_transaction_date = value

    def get_partition_info(self, refresh=False):
        """
        Fetches partitions info of transactions entity/table
        :param refresh: invalidate last cached result and fetch partitions info again
        :return: list(): list of partition values
        """
        # table partition info, sample row - Row(result=u'date_id=2017-12-01')
        if self.__partition_info is None or refresh:
            part_info = self.sqlContext.sql("show partitions {tabname}".
                                            format(tabname=".".join([self.database, self.table]))).collect()
            self.__partition_info = [row["partition"].split("=")[-1] for row in part_info]
        return self.__partition_info

    def get_partition(self, date_id):
        """
        Return spark dataframe over a partition of transactions entity/table this should be thread
        safe in case if different partitioned are read/accessed in parallel
        Note - Transactions entity/table is partitioned on fis_year_id, fis_week_id and date_id in EASL tables
        :param date_id: data related to only that fis_year_id, fis_week_id, date_id will be returned
        :return: transactions_part_df: Spark dataframe
        """
        if not date_id:
            raise ValueError("Caller must provide valid value for date_id")

        return self.data.where(F.col('date_id')==date_id)