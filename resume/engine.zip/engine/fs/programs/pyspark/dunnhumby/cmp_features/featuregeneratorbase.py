'''
Base class for feature generator
'''
import re
import datetime
import logging
import abc
from dunnhumby import contexts
from tools.dataframe_utilities import get_tally_of_duplicates, check_is_dataframe
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import IntegerType, ShortType, DateType, StringType
import pyspark.sql.functions as f

# pylint: disable=line-too-long

logger = logging.getLogger(__name__)


class CMPFeatureGenerator(object):
    """
    Base CMP Feature Generator class
    """
    __metaclass__ = abc.ABCMeta

    def __init__(self):
        '''
        init method
        '''
        super(CMPFeatureGenerator, self).__init__()
        self.__sc = contexts.sc()
        self.sqlContext = contexts.sql_context()
        self.__durations = None
        self.__rsd = None
        # The list of possible dimensions from which dimension_grain can be comprised
        self.__all_dimensions = ['Customer', 'Product', 'Store', 'Channel', 'Promotion']

    @property
    def rsd(self):
        """residual for approxDistinctCount operations"""
        return self.__rsd

    @rsd.setter
    def rsd(self, value):
        '''

        :param value:
        :return:
        '''
        if value is not None:
            if not isinstance(value, float):
                raise TypeError('rsd={rsd}. rsd must be of type float'.format(rsd=value))
            else:
                if value < 0.0:
                    raise ValueError(
                        'rsd={rsd}. rsd must be greater than or equal to 0.0'
                        .format(rsd=value))
        else:
            # None is a valid value for rsd
            pass
        self.__rsd = value

    @property
    def durations(self):
        '''
        list of durations over which to generate features
        :return:
        '''

        if self.__durations:
            return self.__durations
        return [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52), (1, 56),
                (50, 57), (53, 78), (53, 104), (101, 107), (153, 159),
                (205, 211)]

    @durations.setter
    def durations(self, value):
        '''

        :param value:
        :return:
        '''
        if value is not list:
            raise RuntimeError(
                "Value assigned to durations must be a list, not {durations_type}"
                .format(durations_type=type(value)))
        else:
            for duration in value:
                if not isinstance(duration, tuple):
                    raise RuntimeError(
                        "Each duration must be a tuple, not a {duration_type}"
                        .format(duration_type=type(duration)))
                else:
                    if len(duration) != 2:
                        raise RuntimeError("Each duration must be a tuple of length 2")
                    else:
                        for elem in duration:
                            if not isinstance(elem, int):
                                raise RuntimeError(
                                    "Start and end week of each duration must be an int")
                            else:
                                self.__durations = value

    @staticmethod
    def intersect(a, b):
        '''

        :param a:
        :param b:
        :return:
        '''
        return list(set(a) & set(b))

    @staticmethod
    def append_attribute_to_dimension_grain(entity, attribute, dimension_grain):
        '''

        :param entity:
        :param attribute:
        :param dimension_grain:
        :return:
        '''
        if attribute != "All{entity}".format(entity=entity):
            dimension_grain.append(attribute)

    @staticmethod
    def _add_recency_days_column(as_at, df):
        '''

        :param as_at:
        :param df:
        :return:
        '''
        df = df.withColumn("RecencyDays", f.datediff(f.lit(as_at), df.Date))
        return df

    @staticmethod
    def _get_week_number(as_at, df):
        '''

        :param as_at:
        :param df:
        :return:
        '''
        logger.info(
            'as_at: {as_at}. Features will be based on activity up to and including: {day_before_as_at}'
            .format(as_at=as_at, day_before_as_at=as_at - datetime.timedelta(days=1)))
        df = df.withColumn("week_number", (1 + ((df.RecencyDays - 1) / 7)).cast(IntegerType()))
        return df

    @staticmethod
    def _add_fields_week_number_and_recency_days(as_at, df):
        '''

        :param as_at:
        :param df:
        :return:
        '''
        df = CMPFeatureGenerator._add_recency_days_column(as_at, df)
        df = CMPFeatureGenerator._get_week_number(as_at, df)
        return df

    def join_supplementary_dataframes(self, main_df, supplementary_dfs, dimension_grain):
        '''

        :param main_df:
        :param supplementary_dfs:
        :param dimension_grain:
        :return:
        '''
        if not isinstance(main_df, DataFrame):
            raise TypeError("main_df must be a pyspark DataFrame object, %s passed" % type(main_df))
        if not isinstance(dimension_grain, set):
            raise TypeError(
                'Value supplied for dimension_grain must be a set. {dimension_grain} is not a set'
                .format(dimension_grain=dimension_grain))
        if not dimension_grain:
            raise ValueError('Value supplied for dimension_grain cannot be an empty set')
        for dimension in dimension_grain:
            if dimension not in self.__all_dimensions:
                raise ValueError('{dimension} is not a valid dimension. Valid dimensions are {valid_dimensions}'
                                 .format(dimension=dimension, valid_dimensions=self.__all_dimensions))
        if not isinstance(supplementary_dfs, list):
            raise TypeError("supplementary_dfs must be a list object, %s passed" % type(main_df))
        for df in supplementary_dfs:
            if not isinstance(df, DataFrame):
                raise TypeError(
                    "supplementary_dfs must be a list of dataframes, currently includes an object of type %s" % type(
                        df))
        if len(self.intersect([field.name for field in main_df.schema.fields], dimension_grain)) < len(dimension_grain):
            raise RuntimeError(
                'Main df with schema {schema} does not include all fields from dimension grain {dimension_grain}'
                .format(schema=main_df.schema, dimension_grain=dimension_grain))
        for supplementary_df in supplementary_dfs:
            supplementary_df_field_names = [field.name for field in supplementary_df.schema.fields]
            if not self.intersect(supplementary_df_field_names, dimension_grain):
                raise RuntimeError(
                    'Supplementary df with schema {schema} does not include any fields from dimension grain {dimension_grain}'
                    .format(schema=supplementary_df.schema, dimension_grain=dimension_grain))
            join_fields = self.intersect(supplementary_df_field_names, dimension_grain)
            tally_of_duplicates = get_tally_of_duplicates(supplementary_df, join_fields)
            if tally_of_duplicates > 0:
                raise RuntimeError(
                    'Supplementary df with schema {schema} is not unique over fields {join_fields}. {tally_of_duplicates} duplicate rows exist.'
                    .format(
                        schema=supplementary_df.schema, join_fields=join_fields,
                        tally_of_duplicates=tally_of_duplicates))
            main_df = main_df.join(supplementary_df, join_fields, 'outer')
        return main_df

    @staticmethod
    def _check_as_at_and_transactions_df_arguments(as_at, transactions_df):
        """
        Checks that certain conditions of the input data are met.

        The reason for checking that the Date field is of type DateType rather than TimestampType is because
        in February 2017 a problem was found where the exposure rate for HYF for Tesco was way down. The problem was
        eventually traced back to the fact that a change upstream meant that transaction date (transaction_dttm) had
        suddenly started coming through with time precision (i.e. not occurring at the stroke of midnight). This
        caused a join condition to filter out rows that were needed for HYF, and hence why exposure rates were down.
        The issue and the fix are documented at http://jira.dunnhumby.co.uk/browse/SCE-587.
        At the time of writing our features only need to know on which date a transaction occurred, not at what
        time of day, hence to prevent similar issues in the future let us mandate that a DateType is passed in,
        not a TimestampType.

        :param as_at:
        :param transactions_df:
        """
        check_is_dataframe(transactions_df)
        if not isinstance(as_at, datetime.date):
            raise TypeError('as_at is not of type datatime.date')
        date_column_exists = 'Date' in transactions_df.columns
        datetime_column_exists = 'DateTime' in transactions_df.columns
        if (date_column_exists) & (datetime_column_exists):
            raise RuntimeError(
                'purchases_df must contain either a column called Date or a column called DateTime, not both')
        else:
            if not (date_column_exists or datetime_column_exists):
                raise RuntimeError('purchases_df must contain either a column called Date or a column called DateTime')
            else:
                if date_column_exists:
                    date_field_datatype = \
                        [field.dataType for field in transactions_df.schema.fields if field.name == 'Date'][0]
                    if str(date_field_datatype) != 'DateType':
                        # I wanted to use
                        #   if not date_field_datatype is pyspark.sql.types.DateType:
                        # here but it threw 'NameError: global name 'pyspark' is not defined'
                        # and I couldn't figure out why so resorted to using a string compare instead.
                        # Doesn't feel very pythonic, but it works
                        raise TypeError(
                            'Date field is of type {date_field_datatype}, it should be of type DateType.'.format(
                                date_field_datatype=date_field_datatype))
                else:
                    # datetime_column_exists must be true at this point
                    datetime_field_datatype = \
                        [field.dataType for field in transactions_df.schema.fields if field.name == 'DateTime'][0]
                    if str(datetime_field_datatype) != 'TimestampType':
                        raise TypeError(
                            'DateTime field is of type {datetime_field_datatype}, it should be of type TimestampType.'
                            .format(datetime_field_datatype=datetime_field_datatype))

    @staticmethod
    def _get_feature_name(feature, start_week_number=None, end_week_number=None, feature_filter=None):
        '''

        :param feature:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name = '{feature}{feature_filter}'.format(
            feature=feature,
            feature_filter=('_' + (''.join(feature_filter))) if feature_filter else ''
        )
        if start_week_number and end_week_number:
            # The vast majority of calls to this function will specify a start_week_number & end_week_number
            # however we do, at the time of writing, have a situation (for an interim, internal, calculation  the result
            # of which will not be exposed to the consumer) where that isn't the case
            feature_name = '{feature_name}_{start_week_number}w{end_week_number}w'.format(
                feature_name=feature_name,
                start_week_number=start_week_number,
                end_week_number=end_week_number
            )
        return feature_name

    @staticmethod
    def _get_filters(df, start_week_number=None, end_week_number=None, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        filters = None
        if start_week_number and end_week_number:
            # The vast majority of calls to this function will specify a start_week_number &
            # end_week_number however we do, at the time of writing, have a situation (for an
            # interim, internal, calculation  the result of which will not be exposed to the
            # consumer) where that isn't the case
            filters = ((df.week_number >= start_week_number) & (df.week_number <= end_week_number))
        if feature_filter:
            for filter_feature_element in feature_filter:
                # PyLint might suggest changing the equality checks here to use "is".
                # DON'T DO IT. It will cause test failure
                if filters is not None:
                    filters = filters & (
                        df['Is{filter_feature_element}'.format(
                            filter_feature_element=filter_feature_element)] == True)
                else:
                    filters = (
                        df['Is{filter_feature_element}'.format(
                            filter_feature_element=filter_feature_element)] == True)
        return filters

    @staticmethod
    def _groupby_dimension_grain_and_derive_features(df, dimension_grain, expressions):
        """
        The code uses an asterix that causes a list to be evaluated as a list of arguments to the function.
        Without it it would pass a single argument, being the list itself.
        See this thread: https://mattermost.dunnhumby.com/default/pl/d5faeqt5mbyaubfb8qn7tsdmjh for details
        Someone (Mike Allman) told me that was is going on here is unpacking https://docs.python.org/2/tutorial/controlflow.html#unpacking-argument-lists
        """
        return df.groupBy(dimension_grain).agg(*expressions)

    @staticmethod
    def _check_feature_filters(feature_filters):
        """
        feature_filters is supposed to be a list of lists. For example, if the consumer wanted features that filtered
        transactions where:
          -IsFruit is true
          -IsFinestrange is true
          -IsFinestrange is true and IsFruit is true
        then feature_filters would need to be [['Fruit'], ['Finestrange'], ['Fruit', 'Finestrange']]

        (For those that don't know, TescoUK have a premium brand called "Finest Range")

        For convenience, if the filter is just a single column we also allow the consumer to specify just a string
        rather than a list. If only one set of filters is required they cna specify just a list rather than a list of
        lists.
        Thus the following are all acceptable:
          -'Fruit' (will be resolved to [['Fruit']])
          -['Fruit', 'Finestrange']  (will be resolved to [['Fruit', 'Finestrange']])

        Lastly, the filters in each list should appear in alphabetical order, so we sort them.
        Thus [['Fruit'], ['Fruit', 'Finestrange']] will be resolved to [['Fruit'], ['Finestrange', 'Fruit']]
        """
        err_msg = 'Each feature filter must be either a string or a list of strings. {feature_filter} is neither.'
        ret_value = feature_filters
        if feature_filters:
            if isinstance(feature_filters, str):
                ret_value = [[feature_filters]]
            elif isinstance(feature_filters, list):
                for idx in range(0, len(feature_filters)):
                    if isinstance(feature_filters[idx], str):
                        feature_filters[idx] = [feature_filters[idx]]
                    elif isinstance(feature_filters[idx], list):
                        for idx2 in range(0, len(feature_filters[idx])):
                            if not isinstance(feature_filters[idx][idx2], str):
                                raise RuntimeError(err_msg.format(
                                    feature_filter=feature_filters[idx][idx2]))
                        feature_filters[idx] = sorted(feature_filters[idx])
                    else:
                        raise RuntimeError(err_msg.format(feature_filter=feature_filters[idx]))
                ret_value = feature_filters
            else:
                raise RuntimeError(err_msg.format(feature_filter=feature_filters))
        return ret_value

    @staticmethod
    def check_time_of_day_attribute(timeofday_attribute):
        possible_timeofday_attribute_values = ['All', 'TimeOfDay', 'HourOfDay']
        if timeofday_attribute not in possible_timeofday_attribute_values:
            raise ValueError(
                'timeofday_attribute {timeofday_attribute} is not valid. It must be in {possible_timeofday_attribute_values}'.format(
                    timeofday_attribute=timeofday_attribute,
                    possible_timeofday_attribute_values=possible_timeofday_attribute_values
                )
            )

    @staticmethod
    def _check_feature_filter_elements_exist_in_df(df, feature_filter):
        """
        Checks that each element of feature_filter, with "Is" prefixed onto it does exist
        in the list of dataframe fields
        """
        if not isinstance(feature_filter, list):
            raise RuntimeError(
                'feature_filter must be of type list. {feature_filter} is of type {feature_filter_type}'.format(
                    feature_filter=feature_filter, feature_filter_type=type(feature_filter)))
        return len(
            list(
                set(['Is' + feature_filter_element for feature_filter_element in feature_filter]) &
                set([field.name for field in df.schema.fields])
            )) == len(feature_filter)

    @staticmethod
    def _get_expressions_using_sum(
            df, start_week_number, end_week_number, feature_filter=None, input_field=''):
        """Generate features between start_week_number/end_week_number, filtering
        input by feature_filter, summing up input_field.
        Name of the feature will be the same as input_field
        """
        feature_name, filters = CMPFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, input_field)
        return f.sum(
            f.when(
                filters,
                df[input_field]
            )
        ).alias(feature_name)

    @staticmethod
    def _get_integer_type_expressions_using_sum(
            df, start_week_number, end_week_number, feature_filter=None, input_field=''):
        """Generate features between start_week_number/end_week_number, filtering
        input by feature_filter, summing up input_field.
        Name of the feature will be the same as input_field
        """
        feature_name, filters = CMPFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, input_field)
        return f.sum(
            f.when(
                filters,
                df[input_field]
            )
        ).cast(IntegerType()).alias(feature_name)

    @staticmethod
    def _get_short_type_expressions_using_min(
            df, start_week_number, end_week_number, feature_filter=None, input_field=''):
        """Generate features between start_week_number/end_week_number, filtering
        input by feature_filter, summing up input_field.
        Name of the feature will be the same as input_field
        """
        feature_name, filters = CMPFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, input_field)
        return f.min(
            f.when(
                filters,
                df[input_field]
            )
        ).cast(ShortType()).alias(feature_name)

    @staticmethod
    def get_feature_name_and_filters(df, start_week_number, end_week_number, feature_filter, feature):
        feature_name = CMPFeatureGenerator._get_feature_name(
            feature, start_week_number, end_week_number, feature_filter)
        filters = CMPFeatureGenerator._get_filters(
            df, start_week_number, end_week_number, feature_filter)
        return feature_name, filters

    @staticmethod
    def _get_distinct_count_expressions(
            df, start_week_number, end_week_number, feature_filter=None, rsd=None, input_field=''):
        """
        countDistinct produces an accurate answer but approxCountDistinct is much much
        quicker. We allow the user to choose which to use by specifying the residual (rsd).
        If its 0.0 then use countDistinct, otherwise approxCountDistinct.
        """
        feature_name, filters = CMPFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter,
            '{input_field}Count'.format(input_field=input_field))
        if rsd == 0.0:
            expression = f.coalesce(
                f.countDistinct(
                    f.when(
                        filters,
                        df[input_field])
                ),
                f.lit(0)
            )
        else:
            expression = f.coalesce(
                f.approxCountDistinct(
                    f.when(
                        filters,
                        df[input_field]
                    ),
                    rsd=rsd
                ),
                f.lit(0)
            )
        return expression.alias(feature_name)

    @staticmethod
    def create_timeofday_dimension_if_required(df, dimension_grain, timeofday_attribute):
        """If dataframe has got a DateTime column then the features will be aggregated over
        TimeOfDay"""
        if 'DateTime' in df.columns:
            # Replace DateTime column with Date column, and add new column timeofday
            df = df.withColumn('Date', df.DateTime.cast(DateType()))
            df = df.withColumn('HourOfDay',
                               f.reverse(
                                   f.substring(
                                       f.reverse(
                                           f.concat(
                                               f.lit('0'),
                                               f.hour(df.DateTime)
                                           )
                                       ), 0, 2)))
            df = df.withColumn('MinuteOfHour',
                               f.reverse(
                                   f.substring(
                                       f.reverse(
                                           f.concat(
                                               f.lit('0'),
                                               f.minute(df.DateTime)
                                           )
                                       ), 0, 2)))
            df = df.withColumn('TimeOfDay',
                               f.concat(
                                   df.HourOfDay, f.lit(':'),
                                   df.MinuteOfHour
                               ).cast(StringType()))
            df = df.drop('DateTime').drop('MinuteOfHour')
            if timeofday_attribute == 'All':
                df = df.withColumn('AllTimeOfDay', f.lit('All'))
                timeofday_attribute = 'AllTimeOfDay'
            dimension_grain = dimension_grain + [timeofday_attribute]
        return df, dimension_grain, timeofday_attribute

    @staticmethod
    def _append_entity_attribute_description(description, entity, link_phrase, dimension_attribute_grain):
        if '{entity}Attribute'.format(entity=entity) in dimension_attribute_grain.keys():
            entity_attribute = dimension_attribute_grain['{entity}Attribute'.format(entity=entity)]
            if entity_attribute != "All":
                description = "{description} {link_phrase} {entity_attribute}". \
                    format(description=description, link_phrase=link_phrase, entity_attribute=entity_attribute)
        return description

    @staticmethod
    def _get_duration_constituents(feature_name):
        duration_part = re.search('\_\d*[d,w,m,y]\d*[d,w,m,y]', feature_name).group(0)
        duration_part_parts = duration_part.\
            replace('_', '').replace('d', ' ').replace('w', ' ').replace('m', ' ').replace('y', ' ').split(' ')
        duration_start = int(duration_part_parts[0])
        duration_end = int(duration_part_parts[1])
        duration_identifier = feature_name[-1:]
        duration_unit = 'day' if duration_identifier == 'd' \
            else 'week' if duration_identifier == 'w' \
            else 'month' if duration_identifier == 'm' \
            else 'year'
        if duration_start != 1:
            duration_start_unit = duration_unit + 's'
        else:
            duration_start_unit = duration_unit
        if duration_end != 1:
            duration_end_unit = duration_unit + 's'
        else:
            duration_end_unit = duration_unit
        return duration_start, duration_start_unit, duration_end, duration_end_unit

    @abc.abstractmethod
    def add_description_metadata(df, dimension_attribute_grain={}):
        """Subclasses must implement this as a @staticmethod"""
        pass
