"""
Features specification parser base class
"""


import logging

logger = logging.getLogger(__name__)


class FeaturesSpecificationParserBase(object):
    """
    Features specification parser base class
    """

    __basic_feature_spec_keys = ["name", "cadence_attribute", "is_active", "summary_on", "durations", "rsd",
                                 "dimension_attribute_grain", "base_features"]
    __dimension_attribute_keys = ["ProductAttribute", "CustomerAttribute", "StoreAttribute", "ChannelAttribute"]
    __additional_dimension_attr_keys = ["dimension", "attribute", "join_key"]

    def _parse_feature_specs(self, properties):
        """
        Parse feature specifications after loading client specific 'feature_spec.json' and returns a list of it after
        applying few transformations.
        :param properties: Feature Specifications loaded from 'feature_spec.json' file. (Type: List)
        :return: Feature Specifications. (Type: List)
        """
        features_specs = list()
        logger.info("Parsing Specifications...")
        for prop in properties:
            spec = dict()
            feature_spec_keys = list(set(self.__basic_feature_spec_keys + prop.keys()))
            for key in feature_spec_keys:
                spec[key] = getattr(self, '_get_'+key)(prop)
            features_specs.append(spec)
        logger.info("Feature specifications : " + str(features_specs))
        return features_specs

    def _get_name(self, prop):
        """
        Fetch 'name' attribute. If not present, this field's value will be discovered from 'dimension_attribute_grain'
        attribute. In case if 'dimension_attribute_grain' attribute is also not present or in correct format,
        then exception will be raised.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: String)
        """
        name = self._fetch(prop=prop, key="name", mandatory=False, default_value="")
        if not name:
            dimension_attribute_grain = self._fetch(prop=prop, key="dimension_attribute_grain",
                                                    mandatory=True, default_value={})
            if len(dimension_attribute_grain) == len(self.__dimension_attribute_keys):
                name = "_".join([dimension_attribute_grain.get(attr) for attr in self.__dimension_attribute_keys])
            else:
                self.__invalid_key_exception(key="dimension_attribute_grain", prop=prop)
        return name

    def _get_cadence_attribute(self, prop):
        """
        Fetch 'cadence_attribute' attribute. If not present, default value will be 'fis_week_id'.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: String)
        """
        return self._fetch(prop=prop, key="cadence_attribute", mandatory=False, default_value="fis_week_id")

    def _get_is_active(self, prop):
        """
        Fetch 'is_active' attribute. If not present, default value will be True.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: Boolean)
        """
        return self._fetch(prop=prop, key="is_active", mandatory=False, default_value=True)

    def _get_summary_on(self, prop):
        """
        Fetch 'summary_on' attribute. If not present, default value will be True.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: Boolean)
        """
        return self._fetch(prop=prop, key="summary_on", mandatory=False, default_value=True)

    def _get_durations(self, prop):
        """
        Fetch 'durations' attribute. If not present, default value will be an empty list.
        This is a (List of List) object in JSON, but this method will parse it into (List of Tuple) object.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Durations in List of Tuple kind of object. (Type: List)
        """
        durations = self._fetch(prop=prop, key="durations", mandatory=False, default_value=[])
        return [tuple(duration) for duration in durations]

    def _get_rsd(self, prop):
        """
        Fetch 'rsd' attribute. If not present, default value will be 0.
        Value fetched for given attribute from prop will be normalised on a scale of 0-100.
        For example, if input is 5, returned value will be 0.05.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Normalised value. (Type: Float)
        """
        rsd = self._fetch(prop=prop, key="rsd", mandatory=False, default_value=0)
        return rsd / 100.0

    def _get_dimension_attribute_grain(self, prop):
        """
        Fetch 'dimension_attribute_grain' attribute. If not present, this field's value will be discovered from 'name'
        attribute. In case if 'name' attribute is also not present or in correct format,
        then exception will be raised.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: Dictionary)
        """
        dimension_attribute_grain = self._fetch(prop=prop, key="dimension_attribute_grain",
                                                mandatory=False, default_value={})
        if not dimension_attribute_grain:
            name = self._fetch(prop=prop, key="name",
                               mandatory=True, default_value="")
            grains = name.split("_")
            if len(grains) == len(self.__dimension_attribute_keys):
                dimension_attribute_grain = dict(zip(self.__dimension_attribute_keys, grains))
            else:
                self.__invalid_key_exception(key="name", prop=prop)
        return dimension_attribute_grain

    def _get_base_features(self, prop):
        """
        Fetch 'base_features' attribute. If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        return self._fetch(prop=prop, key="base_features", mandatory=False, default_value=[])

    def _get_derived_features(self, prop):
        """
        Fetch 'derived_features' attribute. If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        return self._fetch(prop=prop, key="derived_features", mandatory=False, default_value=[])

    def _get_dependent_derived_features(self, prop):
        """
        Fetch 'dependent_derived_features' attribute. If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        return self._fetch(prop=prop, key="dependent_derived_features", mandatory=False, default_value=[])

    def _get_distinct_features(self, prop):
        """
        Fetch 'distinct_features' attribute. If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        return self._fetch(prop=prop, key="distinct_features", mandatory=False, default_value=[])

    def _get_additional_dimension_attribute(self, prop):
        """
        This method will check for 'additional_dimension_attribute' attribute in each specification and will validate
        if each dictionary in this list contains keys 'dimension' (Type: String), 'attribute' (Type: List)
        and 'join_key' (Type: List). If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        additional_dimension_attribute_list = self._fetch(prop=prop, key="additional_dimension_attribute",
                                                          mandatory=False, default_value=[])
        for each_attr in additional_dimension_attribute_list:
            keys_not_present = set(self.__additional_dimension_attr_keys) - set(each_attr.keys())
            invalid_keys = [key for key in ["attribute", "join_key"] if not isinstance(each_attr[key], list)]
            if any([keys_not_present, invalid_keys]):
                self.__invalid_key_exception(key="additional_dimension_attribute", prop=prop)
        return additional_dimension_attribute_list

    def _get_dimension_attribute_null_filter(self, prop):
        """
        Fetch 'dimension_attribute_null_filter' attribute. If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        return self._fetch(prop=prop, key="dimension_attribute_null_filter", mandatory=False, default_value=[])

    def _get_other_features(self, prop):
        """
        Fetch 'other_features' attribute. If not present, default value will be an empty list.
        :param prop: Feature Specification value. (Type: Dictionary)
        :return: Value fetched for given attribute from prop. (Type: List)
        """
        return self._fetch(prop=prop, key="other_features", mandatory=False, default_value=[])

    def _fetch(self, prop, key, mandatory=None, default_value=None):
        """

        :param prop: Feature Specification value. (Type: Dictionary)
        :param key: Attribute in Feature Specification value. (Type: String)
        :param mandatory: 'mandatory' field can be True/False.
               If True, exception will be raised for default value. (Type: Boolean)
        :param default_value: Default value if the key is not present. (Type: Object)
        :return: Value fetched for given attribute from prop. (Type: Object)
        """
        val = prop.get(key, default_value)
        if not val:
            self.__invalid_key_exception(key, prop, mandatory)
        return val

    def __invalid_key_exception(self, key, prop, mandatory=True):
        """
        Raise exception for invalid key-value pair if mandatory otherwise log a warning with a message.
        :param key: Attribute in Feature Specification value. (Type: String)
        :param prop: Feature Specification value. (Type: Dictionary)
        :param mandatory: 'mandatory' field can be True/False. If True, exception will be raised. (Type: Boolean)
        :return: Nothing is returned.
        """
        message = "Invalid key value pair. Key = {key}, Value = {value}".format(key=key, value=prop.get(key))
        if mandatory:
            raise Exception(message)
        logger.warn(message)
