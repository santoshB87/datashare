"""
Base CMP Features Coordinator
"""
import logging
import re
import datetime
from abc import ABCMeta
import dunnhumby.cmp_features.featuregeneratorbase as featuregeneratorbase
from dunnhumby import contexts

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class CMPFeaturesCoordinator(object):
    """
    Base CMP Features Coordinator
    """
    __metaclass__ = ABCMeta

    def __init__(self):
        super(CMPFeaturesCoordinator, self).__init__()
        self.__dimension_grain = None
        self.__features_specifications = None
        self.__features_generator = None
        self.__features_writer = None
        self.cadence_attribute = None
        self.run_date = None
        # The list of possible dimensions from which dimension_grain can be comprised
        self.__all_dimensions = ['Customer',
                                 'Product',
                                 'Store',
                                 'Channel',
                                 'Promotion',
                                 'Event',
                                 'MediaChannel']
        self.__sc = contexts.sc()
        self.sqlContext = contexts.sql_context()
        self.cls = self.get_cls()

    @property
    def client(self):
        """Client that current implementation is for"""
        return self.cls.__module__.split('.')[0]

    @classmethod
    def get_cls(cls):
        """get class"""
        return cls

    @property
    def features_generator(self):
        """
        :return:
        """
        if self.__features_generator is None:
            raise RuntimeError('features_generator has not been set')
        return self.__features_generator

    @features_generator.setter
    def features_generator(self, value):
        """
        A feature generator that will be used to generate features
        :param value:
        :return:
        """
        if not isinstance(value, featuregeneratorbase.CMPFeatureGenerator):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_features.featuregeneratorbase.CMPFeatureGenerator'))
        self.__features_generator = value

    @property
    def features_writer(self):
        """
        :return:
        """
        if self.__features_writer is None:
            raise RuntimeError('features_generator has not been set')
        return self.__features_writer

    @features_writer.setter
    def features_writer(self, value):
        """
        A feature writer that will be used to write features
        :param value:
        :return:
        """
        self.__features_writer = value

    @property
    def dimension_grain(self):
        """
        Dimension grain of the CMPFeaturesCoordinator. Defines which setter will raise
        exception if not a list and elements do not exist in __all_dimensions
        :return:
        """
        if self.__dimension_grain is None:
            raise RuntimeError('dimension_grain has not been set')
        return self.__dimension_grain

    @dimension_grain.setter
    def dimension_grain(self, value):
        """
        dimension_grain is the collection of dimensions for which the features are to
        be generated and written
        :param value: a list of dimensions
        :return:
        """
        if not isinstance(value, set):
            raise TypeError(
                'Value supplied for dimension_grain must be a set. {value} is not a set'
                .format(value=value))
        if not value:
            raise ValueError('Value supplied for dimension_grain cannot be an empty set')
        for dimension in value:
            if dimension not in self.__all_dimensions:
                raise ValueError(
                    '{dimension} is not a valid dimension. Valid dimensions are {valid_dimensions}'
                    .format(dimension=dimension, valid_dimensions=self.__all_dimensions))
        self.__dimension_grain = value

    @property
    def features_specifications(self):
        """

        :return:
        """
        return self.__features_specifications

    @features_specifications.setter
    def features_specifications(self, value):
        """
        Features specification is a list. Each element of the list is a
        dict that specifies, for each dimension in dimension_grain, which attribute
        the features must be aggregated to. This setter must check that each dimension
        in dimension_grain has an attribute specified.
        :param value:
        :return:
        """
        if not isinstance(value, list):
            raise TypeError(
                'Value to be assigned to property features_specifications must be a list. {value} is not a list'.format(
                    value=value))

        if not value:
            raise ValueError(
                'Value to be assigned to property features_specifications must be a list with length > 0')

        for feature_specification in value:
            if not isinstance(feature_specification, dict):
                raise TypeError('Every element of the list assigned to property features_specifications must be a dict')

            if 'is_active' not in feature_specification.keys():
                raise ValueError(
                    "Each dict of the list assigned to property features_specifications must have an is_active key'")

            if 'cadence_attribute' not in feature_specification.keys():
                raise ValueError(
                    "Each dict of the list assigned to property features_specifications must have a cadence_attribute key")

            if 'dimension_attribute_grain' not in feature_specification.keys():
                raise ValueError(
                    "Each dict of the list assigned to property features_specifications must have a dimension_attribute_grain key")

            if 'rsd' not in feature_specification.keys():
                raise ValueError(
                    "Each dict of the list assigned to property features_specifications must have a rsd key")

            if 'features' not in feature_specification.keys():
                raise ValueError(
                    "Each dict of the list assigned to property features_specifications must have a features key")

            if not isinstance(feature_specification['is_active'], bool):
                raise ValueError(
                    "Value of is_active key must be one of [True, False]")

            if feature_specification.get('cadence_attribute') not in ['fis_week_id', 'date_short_name']:
                raise ValueError(
                    "Value of cadence_attribute key must be one of ['fis_week_id','date_short_name']")

            if not isinstance(feature_specification.get('dimension_attribute_grain'), dict):
                raise TypeError(
                    'Value to be assigned to dimension_attribute_grain of a features_specification must be a dict')

            if not sorted(feature_specification['dimension_attribute_grain'].keys()) == sorted(
                    map(lambda dim: dim + 'Attribute', self.dimension_grain)):
                raise ValueError('An attribute must be supplied for each dimension in dimension_grain')

            if 'supplementary_dataframes' in feature_specification.keys():
                # supplementary_dataframes property did not exist when this class
                # was first delivered thus to maintain backward compatibility we
                # must allow feature_specifications that do not include it
                if not isinstance(feature_specification['supplementary_dataframes'], list):
                    raise TypeError(
                        'Value to be assigned to supplementary_dataframes of a feature specification must be a list')
                else:
                    for supplementary_dataframe in feature_specification['supplementary_dataframes']:
                        if not isinstance(supplementary_dataframe, dict):
                            raise TypeError(
                                'Every element of the list assigned to property supplementary_dataframes must be a dict')
                        else:
                            if 'entity' not in supplementary_dataframe.keys():
                                raise ValueError(
                                    'Each supplementary_dataframe dict must have a key called "entity"')
                            else:
                                if not isinstance(supplementary_dataframe['entity'], str):
                                    raise TypeError(
                                        'Each value given for entity key in a supplementary_dataframe dict must be a string')
                            if 'fields' not in supplementary_dataframe.keys():
                                raise ValueError(
                                    'Each supplementary_dataframe dict must have a key called "fields"')
                            else:
                                if (
                                        (not isinstance(supplementary_dataframe['fields'], list)) and
                                        (supplementary_dataframe['fields'] != '*')
                                ):
                                    raise ValueError(
                                        'Each value given for fields key in a supplementary_dataframe dict must be a list or *')
                                else:
                                    fields = supplementary_dataframe['fields']
                                    if isinstance(fields, list):
                                        if not fields:
                                            raise ValueError(
                                                'List of fields specified in a supplementary_dataframe dict must be non empty')
                                        else:
                                            if [field for field in fields if not isinstance(field, str)]:
                                                raise ValueError(
                                                    'Fields specified in a supplementary_dataframe dict must be strings')
                                            else:
                                                if len(fields) != len(set(fields)):
                                                    raise ValueError(
                                                        'Fields specified in a supplementary_dataframe dict must be unique')

        self.__features_specifications = value

    def _get_all_entity_attributes(self, entity):
        """
        Get list of entity attributes named in features_specifications
        :param entity:
        :return: list of attributes of that entity named in features_specifications
        """
        return set(
            [entity] +
            [feature_specification['dimension_attribute_grain']
             ['{entity}Attribute'.format(entity=entity)]
             for feature_specification in self.features_specifications
             if (feature_specification['cadence_attribute'] == self.cadence_attribute)
             and (feature_specification['dimension_attribute_grain']
                  ['{entity}Attribute'.format(entity=entity)] != 'All')]
        )

    @property
    def all_required_product_attributes(self):
        """List of all Product attributes required to satisfy all dimension
        grains in features_specifications
        for cadence_attribute"""
        if self.features_specifications:
            entity = 'Product'
            return self._get_all_entity_attributes(entity)

    @property
    def all_required_customer_attributes(self):
        """List of all Customer attributes required to satisfy all dimension
        grains in features_specifications for cadence_attribute"""
        if self.features_specifications:
            entity = 'Customer'
            return self._get_all_entity_attributes(entity)

    @property
    def all_required_store_attributes(self):
        """List of all Store attributes required to satisfy all dimension
        grains in features_specifications for cadence_attribute"""
        if self.features_specifications:
            entity = 'Store'
            return self._get_all_entity_attributes(entity)

    @property
    def all_required_channel_attributes(self):
        """List of all Channel attributes required to satisfy all dimension
        grains in features_specifications for cadence_attribute"""
        if self.features_specifications:
            entity = 'Channel'
            return self._get_all_entity_attributes(entity)

    @property
    def as_at(self):
        """as_at is day after the last day of the cadence"""
        all_dates = self.Dates.data
        return (
            all_dates.where(all_dates[self.cadence_attribute] == self.cadence)
            .select('date_id')
            .rdd
            .max()[0] + datetime.timedelta(days=1)
        )

    @property
    def cadence(self):
        """
        The value for cadence_attribute based on
        run_date
        :return:
        """
        all_dates = self.Dates.data
        all_dates.persist()
        if all_dates.count() == 0:
            raise RuntimeError('Dates entity returned 0 rows')
        if self.cadence_attribute == 'fis_week_id':
            # Cadence would be the latest concluded week
            # Cadence would be the latest week that is not the current week
            current_week = (
                all_dates.where(all_dates['date_id'] == self.run_date)
                .select('fis_week_id').rdd.max()[0])
            return (
                all_dates.where(all_dates['fis_week_id'] < current_week)
                .select('fis_week_id').rdd.max()[0])
        if self.cadence_attribute == 'date_short_name':
            # Cadence would be the latest concluded day
            # Cadence would be the latest day that is not today
            return (
                all_dates.where(all_dates['date_id'] < self.run_date)
                .select('date_short_name').rdd.max()[0])

    @property
    def pull_data_since_date(self):
        """
        all_features : Concatenated list of all features in
        features_specifications
        """

        all_features = []
        list(map(lambda x: all_features.extend((x['features'])),
                 self.features_specifications))

        # Scanning feature names to select the max week num
        r = re.compile("_[0-9]*w([0-9]*)w")
        # Due to supplementary_dataframes not all features will be of the form *_XwYw
        # thus in order to find out how
        # much data is required do not consider those that do not match that pattern
        all_features = [
            feature_name
            for feature_name in all_features
            if re.match('.*_[0-9]*w([0-9]*)w', feature_name)]
        pull_data_for_num_weeks = max(list(map(lambda x: int(r.findall(x)[0]), all_features)))

        pull_data_for_num_days = pull_data_for_num_weeks * 7 + 1
        return self.as_at - datetime.timedelta(days=pull_data_for_num_days)

    def get_supplementary_dataframes(self, specification, config):
        """
        Get list of dataframes as listed in features specification

        The supplementary_dataframes section of a features_specification specifies
        an entity that should be supplied to the feature generator as a
        supplementary_dataframe. Those entities are specified using singular names such
        as 'Customers' or 'Products', they will not bear a fully-qualified name tht
        includes the namespace and thus the
        client (e.g. client.cmp_entities.customers.Customers).
        This function verifies that each specified entity exists for the current client,
        instantiates it, and returns each entity dataframe in a list.
        At the time of writing it uses abstract syntax tree (ast) parsing to verify
        that the entity exists then getattr() to instantiate it.
        Lastly, the subset of fields specified (if indeed any ARE specified) for the
        supplementary dataframe are selected
        """
        supplementary_dataframes = []
        if 'supplementary_dataframes' in specification.keys():
            for supplementary_dataframe in specification['supplementary_dataframes']:
                entity = supplementary_dataframe['entity']
                fields = supplementary_dataframe['fields']
                # Assumption here is that entity 'Entity' can be imported from
                # client.cmp_entities.entity.Entity
                # This is a convention that I'm willing to enforce here
                file_ = entity.lower()
                module = '{client}.cmp_entities.{file_}'.format(client=self.client, file_=file_)
                logger.info(
                    'Importing module %s to get class %s.%s which provides a supplementary dataframe',
                    module,
                    module,
                    entity)
                class_ = getattr(
                    getattr(
                        getattr(
                            __import__(module),
                            'cmp_entities'
                        ),
                        file_
                    ),
                    entity
                )
                instance = class_(config)
                entity_df = getattr(instance, 'data')
                if isinstance(fields, list):
                    non_existent_fields = list(
                        set(fields) - set([field.name for field in entity_df.schema.fields]))
                    if non_existent_fields:
                        raise RuntimeError(
                            'Supplementary dataframe: Fields {non_existent_fields} do not exist in entity {entity}'
                            .format(
                                non_existent_fields=non_existent_fields,
                                entity=entity
                            )
                        )
                    entity_df.select(fields)
                logger.info(
                    'Instantiated supplementary dataframe %s.%s with fields %s',
                    module, entity, [field.name for field in entity_df.schema.fields])
                supplementary_dataframes.append(entity_df)
        return supplementary_dataframes

    def get_attributes_df(self, entity, entity_attribute):
        """Get entity identifier and an attribute of that entity"""
        if entity_attribute in [entity, 'All']:
            return None
        cmp_entity = getattr(self, entity)
        return cmp_entity.data.select([entity, entity_attribute])

    def Dates(self):
        """Dates entity"""
        pass

    def _select_and_write_features_and_create_view(
            self, features_df, features_writer, specification, database_name):
        """
        Select & write features then create a view over them
        :param features_df: dataframe of features
        :param features_writer: reference to an instance of FeaturesWriter
        :param specification: feature specification
        :param database_name: database name
        :return:
        """
        features_df = (features_df.select(
            list(self.dimension_grain) + specification['features']))
        features_writer.write(
            dimension_grain=self.dimension_grain,
            df=features_df,
            CadenceAttribute=self.cadence_attribute,
            Cadence=self.cadence,
            overwrite=True,
            **specification['dimension_attribute_grain'])
        logger.info('Features Written')
        features_writer.create_views(dimension_grain=self.dimension_grain,
                                        database_name=database_name,
                                        CadenceAttribute=self.cadence_attribute,
                                        Cadence=self.cadence,
                                        specification=specification)

    def _there_is_more_than_one_active_features_specification(self):
        """
        Returns true if there is more than one active features_specification
        Method named as though its going to be used in an if statements
        :return: bool
        """
        return True if len(
            [
                fs
                for fs in self.features_specifications
                if CMPFeaturesCoordinator._features_specification_is_active(fs)
            ]) > 1 else False

    @staticmethod
    def _features_specification_is_active(features_specification):
        return True if features_specification['is_active'] else False

    @staticmethod
    def _get_filtered_features_specifications(
            features_specifications,
            features_specifications_slices,
            features_specifications_slice,
            features_specifications_slice_element):
        if not 0 < features_specifications_slices <= len(features_specifications):
            raise RuntimeError(
                'features_specifications_slices ({features_specifications_slices}) must be greater than zero and less than or equal to the length of features_specifications ({len_features_specifications})'.format(
                    features_specifications_slices=features_specifications_slices,
                    len_features_specifications=len(features_specifications)
                )
            )
        if not 0 <= features_specifications_slice < features_specifications_slices:
            raise RuntimeError(
                'features_specifications_slice ({features_specifications_slice}) must be less than features_specifications_slices ({features_specifications_slices})'.format(
                    features_specifications_slice=features_specifications_slice,
                    features_specifications_slices=features_specifications_slices)
            )
        filtered_features_specifications = [
            elem for elem in features_specifications
            if features_specifications.index(elem) % features_specifications_slices
               == features_specifications_slice
        ]
        if features_specifications_slice_element >= len(filtered_features_specifications):
            raise RuntimeError(
                'features_specifications_slice_element ({features_specifications_slice_element}) must be less than the length of features_specifications after it has been filtered by features_specifications_slices & features_specifications_slice ({len_filtered_features_specifications})'.format(
                    features_specifications_slice_element=features_specifications_slice_element,
                    len_filtered_features_specifications=len(filtered_features_specifications))
            )
        if features_specifications_slice_element is not None:
            filtered_features_specifications = [filtered_features_specifications[features_specifications_slice_element]]
        if len(filtered_features_specifications) != len(features_specifications):
            logger.info('features_specifications has been filtered from %s elements to %s elements',
                        len(features_specifications),
                        len(filtered_features_specifications))
        return filtered_features_specifications
