'''
featurewriter.py
'''
from tools.dataframe_utilities import *
import logging
import tools.dataframe_utilities as df_util
import pyspark.sql.functions as F
import pyspark.sql.types as pt
from dunnhumby import contexts

# pylint: disable=line-too-long
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class FeaturesWriter(object):
    """
    Write input dataframe to a feature table, creating the table if it does not already exist
    """

    def __init__(self, database_name):
        """
        Constructor for FeaturesWriter
        """
        super(FeaturesWriter, self).__init__()
        self.__sc = contexts.sc()
        self.sqlContext = contexts.sql_context()
        self.database_name = database_name
        return

    def write(self, dimension_grain, df, CadenceAttribute, Cadence, file_format='PARQUET',
              overwrite=True, **kwargs):
        """
        Write a dataframe to a hive table, creating the database and table if they do not already exist
        :param database_name: Database to write the data into
        :param dimension_grain: Set of dimensions that define the grain of the dataframe and is used to determine the partitions of the table. The order of the elements in this list is significant becuse the order determines both the name of the table and the order of partitioning columns, thus the set elements must always be passed in the same order
        :param df: dataframe to be written
        :param CadenceAttribute: Cadence at which this data is calculated (e.g. weekly, daily)
        :param Cadence: The value of CadenceAttribute (e.g. 2017W01, 2017-01-01)
        :param file_format: format of the files to which the data is written
        :param kwargs: Values
        :return:
        """
        if not isinstance(dimension_grain, set):
            """columns must be unique so may as well insist on this being a set rather than a list."""
            raise TypeError('parameter dimension_grain must be a set')
        df_util.check_is_dataframe(df)
        df_util.check_columns(df, dimension_grain)
        df = self._cast_date_strings_as_string(df)
        self._create_database_if_not_exists(self.database_name)
        self._create_feature_table_if_not_exists(self.database_name, dimension_grain, file_format)
        self._alter_feature_table_for_required_columns(self.database_name, dimension_grain, df)
        self._insert_dataframe_to_feature_table(
            self.sqlContext, database_name=self.database_name, df=df,
            dimension_grain=dimension_grain, CadenceAttribute=CadenceAttribute,
            Cadence=Cadence, overwrite=overwrite, **kwargs)

    def __drop_and_recreate_view(self, database_name, view_name, select_columns,
                                 source_table, where_condition=None):
        """
        Drop and recreate a view using the specified select, from and where clauses

        :param database_name: db in which the view should be dropped and recreated
        :param view_name: name of view to drop and recreate
        :param select_columns: select clause to use when recreating view
        :param source_table: from clause to use when recreating view
        :param where_condition: where clause (if any) to use when recreating view - default None

        :return None
        """

        if where_condition is None:
            where_condition = ""

        drop_view_template = '''drop view if exists {database_name}.{view_name}'''

        create_view_template = '''create view {database_name}.{view_name} 
                                  as select {select_columns} 
                                  from {database_name}.{source_table} 
                                  {where_condition}'''

        drop_view_statment = drop_view_template.format(
            database_name=database_name,
            view_name=view_name
        )

        logger.info('Dropping view with statment: %s', drop_view_statment)
        self.sqlContext.sql(drop_view_statment)

        # create views with dimension grain prefixes on feature names
        create_view_statement = create_view_template.format(
            database_name=database_name,
            view_name=view_name,
            select_columns=select_columns,
            source_table=source_table,
            where_condition=where_condition
        )

        logger.info('Creating view with statement: %s', create_view_statement)
        self.sqlContext.sql(create_view_statement)

    def create_views(self, dimension_grain, database_name,
                     CadenceAttribute, Cadence, specification):
        """
        Create two views - one with the dimension grain prefixes added to all feature names
        (suitable for joining features) and one with the feature names are unprefixed (suitable
        for unioning features together)

        :param database_name: Database to write the View into
        :param CadenceAttribute: Cadence at which this data is calculated (e.g. weekly, daily)
        :param Cadence: The value of CadenceAttribute (e.g. 2017W01, 2017-01-01)
        :param specification: contains information related to dimension grains and features being
               calculated for that dimension
        :return:
        """

        # create the _cadence (ie *_201805) views, with and without feature name prefixes
        dimension_attribute_grain = specification['dimension_attribute_grain']
        feature_table_name = self._get_feature_table_name(dimension_grain)
        prefix = self._get_prefix(dimension_grain, dimension_attribute_grain)

        # where clause pointing to the dimension grain/cadence being processed in our features table
        feature_table_where_clause = self.__add_where_condition_in_create_view_statement(
            Cadence,
            dimension_attribute_grain
        )

        # drop and recreate view with dimension grain feature name prefixes
        view_name_prefixes = "v_" + 'CadenceAttribute' + CadenceAttribute + '_' + prefix
        view_name_prefixes_cadence = view_name_prefixes + str(Cadence)
        select_clause_prefixes = self.__add_columns_in_create_view_statement(
            dimension_grain,
            prefix,
            specification
        )

        self.__drop_and_recreate_view(
            database_name=database_name,
            view_name=view_name_prefixes_cadence,
            select_columns=select_clause_prefixes,
            source_table=feature_table_name,
            where_condition=feature_table_where_clause
        )

        # drop and recreate view without dimension grain feature name prefixes
        view_name_noprefixes = "v_" + 'CadenceAttribute' \
                               + CadenceAttribute + '_' + prefix + '_noprefixes'
        view_name_noprefixes_cadence = view_name_noprefixes + str(Cadence)
        select_clause_noprefixes = '*'

        self.__drop_and_recreate_view(
            database_name=database_name,
            view_name=view_name_noprefixes_cadence,
            select_columns=select_clause_noprefixes,
            source_table=feature_table_name,
            where_condition=feature_table_where_clause
        )

        # if cadence being processed is the current one drop and recreate the "_current" views
        if self._check_if_cadence_is_current(Cadence, database_name, feature_table_name):

            current_view_select_clause = '*'
            view_name_prefixes_current = view_name_prefixes + 'current'
            view_name_noprefixes_current = view_name_noprefixes + 'current'

            # drop and recreate "_current" view with dimension grain feature name prefixes
            self.__drop_and_recreate_view(
                database_name=database_name,
                view_name=view_name_prefixes_current,
                select_columns=current_view_select_clause,
                source_table=view_name_prefixes_cadence,
                where_condition=None
            )

            # drop and recreate "_current" view without dimension grain prefixes
            self.__drop_and_recreate_view(
                database_name=database_name,
                view_name=view_name_noprefixes_current,
                select_columns=current_view_select_clause,
                source_table=view_name_noprefixes_cadence,
                where_condition=None
            )

    @staticmethod
    def _cast_date_strings_as_string(df):
        '''

        :param df:
        :return:
        '''
        for field in [field for field in df.schema.fields if field.dataType is DateType()]:
            logger.info(
                'Casting date field {fieldname} as string because before Hive v1.2 date fields cannot be written to parquet. See HIVE-6384.'.format(
                    fieldname=field.name))
            df = df.withColumn(field.name, df[field.name].cast(StringType()))
        return df

    @staticmethod
    def _get_prefix(dimension_grain, dimension_attribute_grain):
        """

        :param dimension_grain:
        :param specification:
        :return:
        """
        prefix = ''
        for dimension in sorted(dimension_grain):
            prefix = prefix + '_' + dimension + dimension_attribute_grain[dimension + 'Attribute']
        prefix = prefix[1:] + '_'
        return prefix

    @staticmethod
    def __add_columns_in_create_view_statement(dimension_grain, prefix, specification):
        """

        :param database_name:
        :param view_name:
        :param specification:
        :return:
        """
        sql = ''
        # This loop iterates over the dimension_grain and Cadence to add all the dimension,dimensionAttribute and Cadence,CadenceAttribute to
        # the select clause in create view query
        for dimension in dimension_grain.union(['Cadence']):
            sql = sql + dimension.lower() + "," + dimension.lower() + 'attribute' + ","
        features_with_prefix = ",".join([x.lower() + " as " + prefix + x for x in specification['features']])
        sql += features_with_prefix
        return sql


    @staticmethod
    def __add_where_condition_in_create_view_statement(Cadence, dimension_attribute_grain):
        """

        :param specification:
        :return:
        """
        sql = "where "
        for key in dimension_attribute_grain:
            sql += key.lower() + "=" + "'{value}'".format(value=dimension_attribute_grain[key]) + ' and '
        sql += "cadence =" + "'{cadence}'".format(cadence=Cadence)
        return sql

    def _check_if_cadence_is_current(self, Cadence, database_name, feature_table_name):
        """
        Check if cadence is current i.e. current view should be dropped and recreated as current view has data for
        latest cadence
        :param Cadence:
        :return:
        """
        query = "select count(*) from {database_name}.{feature_table_name} " \
                "where cadence >'{cadence}'".format(database_name=database_name,
                                                    feature_table_name=feature_table_name,
                                                    cadence=Cadence)
        if self.sqlContext.sql(query).rdd.flatMap(list).first() == 0:
            return True
        else:
            return False

    def _alter_feature_table_for_required_columns(self, database_name, dimension_grain, df):
        """
        Alter the feature table so that it has all the required columns
        :return:
        """
        sql = self._get_alter_table_sql_statement(self.sqlContext, database_name, dimension_grain, df.schema.fields)
        if sql:
            logger.info('Altering table with SQL: {sql}'.format(sql=sql))
            self.sqlContext.sql(sql)

    @staticmethod
    def _insert_dataframe_to_feature_table(sqlContext, database_name, df, dimension_grain,
                                           CadenceAttribute, Cadence, overwrite, **kwargs):
        '''

        :param sqlContext:
        :param database_name:
        :param df:
        :param dimension_grain:
        :param CadenceAttribute:
        :param Cadence:
        :param kwargs:
        :return:
        '''
        if not isinstance(dimension_grain, set):
            raise TypeError('dimension_grain must be a set')
        if len(dimension_grain) == 0:
            raise RuntimeError('The table must have at least one dimension. Not a lot of point otherwise.')
        check_columns(df, dimension_grain)
        FeaturesWriter._check_value_has_been_supplied_for_each_partition_column(dimension_grain, **kwargs)
        feature_table_name = FeaturesWriter._get_feature_table_name(dimension_grain)
        table_field_names = FeaturesWriter._get_table_field_names(sqlContext, database_name,
                                                                  feature_table_name)
        # Adding created_at field to the dataframe - set to the current timestamp
        df = df.withColumn('created_at', F.lit(
            datetime.datetime.now().replace(microsecond=0))
                           .cast(pt.TimestampType()))
        sql = FeaturesWriter._get_insert_statement(database_name, df, dimension_grain, feature_table_name,
                                                   table_field_names, CadenceAttribute, Cadence, overwrite,
                                                   **kwargs)
        logger.info('insert statement: {insert_statement}'.format(insert_statement=sql))
        logger.info("dataframe about to be written has %s partitions",
                    df
                    .rdd.getNumPartitions())
        FeaturesWriter.write_the_partition(sqlContext, df, sql)

    @staticmethod
    def write_the_partition(sqlContext, df, sql):
        # Spark's registerTempTable() method essentially creates a table as a global variable. To avoid possible race conditions we are giving the table a (hopefully) unique name
        temporary_table_name = datetime.datetime.now().strftime('%Y_%m_%d_%H_%M_%S_%f')
        df.registerTempTable(temporary_table_name)
        sqlContext.sql(sql.format(df=temporary_table_name))

    @staticmethod
    def _get_alter_table_sql_statement(sqlContext, database_name, dimension_grain, required_fields):
        """
        Build an ALTER TABLE statement, respecting the ordinal position of fields that already exist in the table
        Have chosen to make this a static method so that it is easier to test
        :param sqlContext:
        :param database_name:
        :param dimension_grain:
        :param required_fields: List of StructFields that need to be in the table
        :return:
        """
        feature_table_name = FeaturesWriter._get_feature_table_name(dimension_grain)
        required_fields_that_do_not_already_exist_in_table = FeaturesWriter._get_fields_that_do_not_already_exist_in_table(
            sqlContext,
            database_name,
            feature_table_name,
            required_fields
        )
        if len(required_fields_that_do_not_already_exist_in_table) > 0:
            sql = FeaturesWriter._construct_alter_table_statement_from_column_list(
                feature_table_name,
                database_name,
                required_fields_that_do_not_already_exist_in_table
            )
        else:
            sql = None
        return sql

    @staticmethod
    def _construct_alter_table_statement_from_column_list(feature_table_name, database_name,
                                                          required_fields_that_do_not_already_exist_in_table):
        """
        Code herein exists in a dedicated method so that can be unit tested
        :param feature_table_name:
        :param database_name:
        :param required_fields_that_do_not_already_exist_in_table:
        :return:
        """
        sql = 'ALTER TABLE {database_name}.{feature_table_name} ADD COLUMNS ('.format(
            feature_table_name=feature_table_name, database_name=database_name)
        columns_sql = []
        for required_field in required_fields_that_do_not_already_exist_in_table:
            columns_sql.append(df_util.get_sql_column_definition_from_dataframe_field(required_field))
        sql = sql + ",".join(columns_sql)
        sql = sql + ')'
        return sql

    @staticmethod
    def _get_create_table_sql_statement(database_name, dimension_grain, file_format):
        """
        Construct the SQL that creates the feature table
        This is a static method because such methods are easier to test.
        :param feature_table_name:
        :param dimension_grain:
        :return:
        """
        feature_table_name = FeaturesWriter._get_feature_table_name(dimension_grain)
        if not isinstance(dimension_grain, set):
            raise TypeError('dimension_grain must be a set')
        if len(dimension_grain) == 0:
            raise RuntimeError('The table must have at least one dimension. Not a lot of point otherwise.')
        sql = 'CREATE EXTERNAL TABLE IF NOT EXISTS {database_name}.{feature_table_name} '.format(
            feature_table_name=feature_table_name, database_name=database_name)
        sql = sql + FeaturesWriter._get_columns_for_create_table_statement(dimension_grain)
        sql = sql + FeaturesWriter._get_partition_columns_for_create_table_statement(dimension_grain)
        sql = sql + ' STORED AS {file_format}'.format(file_format=file_format)
        return sql

    @staticmethod
    def _get_insert_statement(database_name, df, dimension_grain, feature_table_name, table_field_names,
                              CadenceAttribute, Cadence, overwrite=True, **kwargs):
        '''

        :param database_name:
        :param df:
        :param dimension_grain:
        :param feature_table_name:
        :param table_field_names:
        :param CadenceAttribute:
        :param Cadence:
        :param kwargs:
        :return:
        '''
        if not isinstance(overwrite, bool):
            raise TypeError('overwrite parameter must be of type bool')
        partition_spec = []
        partition_spec.append(
            "{partition_column}='{value}'".format(
                partition_column='CadenceAttribute',
                value=CadenceAttribute
            )
        )
        partition_spec.append("{partition_column}='{value}'".format(partition_column='Cadence', value=Cadence))
        partition_columns = [dimension + 'Attribute' for dimension in dimension_grain]
        for partition_column in partition_columns:
            partition_spec.append("{partition_column}='{value}'".format(
                partition_column=partition_column, value=kwargs[partition_column]
            )
            )
        sql = "INSERT {overwrite} TABLE {database_name}.{feature_table_name} PARTITION ({partition_spec})".format(
            overwrite=('OVERWRITE' if overwrite else 'INTO'),
            feature_table_name=feature_table_name,
            database_name=database_name,
            partition_spec=", ".join(partition_spec)
        )
        select_clause = []
        for dimension in dimension_grain:
            select_clause.append(dimension)

        for field in [tfield for tfield in table_field_names
                      if tfield not in partition_columns
                      and tfield not in [dimension.lower() for dimension in list(dimension_grain)]
                      and tfield not in [partition_column.lower() for partition_column in partition_columns]
                      and tfield not in ['cadenceattribute', 'cadence']
                      # Hive converts field names to lowercase don't forget]:
                      ]:
            if field in [df_field.name.lower() for df_field in df.schema.fields]:
                select_clause.append(field)
            else:
                select_clause.append('NULL as {field}'.format(field=field))
        sql = sql + ' SELECT ' + ", ".join(select_clause) + ' FROM {df}'
        return sql

    @staticmethod
    def _get_partition_columns_for_create_table_statement(dimension_grain):
        '''

        :param dimension_grain:
        :return:
        '''
        sql = ' PARTITIONED BY (CadenceAttribute STRING, Cadence STRING, '
        partition_columns_sql = []
        for dimension in dimension_grain:
            partition_columns_sql.append('{dimension}Attribute STRING'.format(dimension=dimension))
        sql = sql + (", ".join(partition_columns_sql))
        sql = sql + ')'
        return sql

    @staticmethod
    def _check_value_has_been_supplied_for_each_partition_column(dimension_grain, **kwargs):
        '''

        :param dimension_grain:
        :param kwargs:
        :return:
        '''
        partition_columns = [dimension + 'Attribute' for dimension in dimension_grain]
        for partition_column in partition_columns:
            if partition_column not in kwargs.keys():
                raise ValueError('{kwargs} must include an item with key {partition_column}'.format(
                    kwargs=kwargs, partition_column=partition_column
                )
                )
            else:
                if not isinstance(kwargs[partition_column], str):
                    raise TypeError('Value supplied for {partition_column} must be of type str'.format(
                        partition_column=partition_column
                    )
                    )

    def _create_database_if_not_exists(self, database_name):
        '''

        :param database_name:
        :return:
        '''
        sql = 'CREATE DATABASE IF NOT EXISTS {database_name}'.format(database_name=database_name)
        logger.info('Creating database with SQL: {sql}'.format(sql=sql))
        self.sqlContext.sql(sql)

    def _create_feature_table_if_not_exists(self, database_name, dimension_grain, file_format='PARQUET'):
        """
        Creates the table if it does not exist
        Created as an external table. This ensures that if a table gets deleted accidentally the underlying files will not.
        :return:
        """
        sql = self._get_create_table_sql_statement(database_name, dimension_grain, file_format)
        logger.info('Creating table with SQL: {sql}'.format(sql=sql))
        self.sqlContext.sql(sql)

    @staticmethod
    def _get_fields_that_do_not_already_exist_in_table(sqlContext, database_name, feature_table_name, required_fields):
        '''

        :param sqlContext:
        :param database_name:
        :param feature_table_name:
        :param required_fields:
        :return:
        '''
        field_names_already_existing_in_table = FeaturesWriter._get_table_field_names(sqlContext, database_name,
                                                                                      feature_table_name)
        # Converting field names to lowercase for comparison because Spark hive creates all objects and columns in
        # lowercase
        # More info at https://forums.databricks.com/answers/124/view.html
        return [required_field for required_field in required_fields if
                required_field.name.lower() not in [existing_field_name.lower() for existing_field_name in
                                                    field_names_already_existing_in_table]]

    @staticmethod
    def _get_table_field_names(sqlContext, database_name, table_name):
        '''

        :param sqlContext:
        :param database_name:
        :param table_name:
        :return:
        '''
        df = sqlContext.table('{database}.{table}'.format(database=database_name, table=table_name))
        return [field.name for field in df.schema.fields]

    @staticmethod
    def _get_columns_for_create_table_statement(dimension_grain):
        '''

        :param dimension_grain:
        :return:
        '''
        sql = '('
        columns_sql = []
        for dimension in dimension_grain:
            columns_sql.append('{dimension} STRING'.format(dimension=dimension))
        sql = sql + (", ".join(columns_sql))
        sql = sql + ', created_at TIMESTAMP'
        sql = sql + ')'
        return sql

    @staticmethod
    def _get_feature_table_name(dimension_grain):
        """table name will be determined by concatenating elements in a list.
        It is intended that that list will be the dimensions that the table is to be dimensioned by. For example,
        if the dimensionality of the table is ['Customer','Product'] the table name will have the words "Customer"
        and "Product" in it.
        Chosen to be a static method, basically so that it can be unit tested without having to create an instance of
          FeaturesWriter and thus having to create a sparkcontext
        """
        return "_".join(sorted(dimension_grain)) + '_features'
