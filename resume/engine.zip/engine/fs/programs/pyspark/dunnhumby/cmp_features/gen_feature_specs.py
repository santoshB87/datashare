import sys
import ast
import json
from copy import deepcopy
from collections import OrderedDict


class FeatureSpecsGenerator:
    """
    Feature Specification Generator Class
    """
    def __init__(self, product_hierarchy):
        """
        Constructor of Feature Specification Generator class
        Default values ->
        "is_active" : True
        "summary_on" : True
        "rsd" : 0
        "cadence_attribute" : "fis_week_id"
        "durations" : [(1,1),(1,4),(1,8),(1,13),(1,26),(1,52),(1,56)]
        "base_features" : ["Baskets", "BasketWeeks", "Discount", "MaximumPrice", "MinimumPrice",
            "MaximumNetPrice", "MinimumNetPrice", "Quantity", "QuantityPrefStore1", "QuantityPrefStore2",
            "QuantityPrefStore3", "QuantityFulfillmentStore", "GrossSpend", "NetSpend", "MaxPurchaseDate",
            "MinPurchaseDate", "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95",
            "StandardDeviationNetSpendPerWeek"]
        "derived_features" : ["BasketsFlag", "DiscountPerBasket", "DiscountPercent", "AveragePrice",
            "QuantityPerBasket", "NetSpendPerBasket", "AveragePurchaseCycle", "RecencyDays",
            "CyclesSinceLastPurchase"]
        :param product_hierarchy: Hierarchy using which feature specs will be created
        """
        self.is_active = True
        self.summary_on = True
        self.rsd = 0
        self.cadence_attribute = "fis_week_id"
        self.product_hierarchy = product_hierarchy
        self.base_features = [
            "Baskets",
            "BasketWeeks",
            "Discount",
            "MaximumPrice",
            "MinimumPrice",
            "MaximumNetPrice",
            "MinimumNetPrice",
            "Quantity",
            "QuantityPrefStore1",
            "QuantityPrefStore2",
            "QuantityPrefStore3",
            "QuantityFulfillmentStore",
            "GrossSpend",
            "NetSpend",
            "MaxPurchaseDate",
            "MinPurchaseDate",
            "RecencyWeightedBasketWeeks75",
            "RecencyWeightedBasketWeeks95",
            "StandardDeviationNetSpendPerWeek"
        ]
        self.derived_features = [
            "BasketsFlag",
            "DiscountPerBasket",
            "DiscountPercent",
            "AveragePrice",
            "QuantityPerBasket",
            "NetSpendPerBasket",
            "AveragePurchaseCycle",
            "RecencyDays",
            "CyclesSinceLastPurchase"
        ]
        self.durations = [
          [
            1,
            1
          ],
          [
            1,
            4
          ],
          [
            1,
            8
          ],
          [
            1,
            13
          ],
          [
            1,
            26
          ],
          [
            1,
            52
          ],
          [
            1,
            56
          ]
        ]
        self.levels = []

    def get_levels(self):
        """
        This method will generate different levels for features using product hierarchy.
        One extra hierarchy "All" will be added to product hierarchy.
        Each level will be made up of ["ProductAttribute", "CustomerAttribute", "StoreAttribute", "ChannelAttribute"],
        where "StoreAttribute" and "ChannelAttribute" will always be "All".
        For each hierarchy there will be two levels, one with "CustomerAttribute" as "All" and another as "Customer".
        For example, if one of the hierarchy is "Product",
        then levels would be:
        1. "Product_All_All_All"
        2. "Product_Customer_All_All"
        Each feature level consists of
        :return: List of feature levels
        """
        product_hierarchy = deepcopy(self.product_hierarchy)
        product_hierarchy.append("All")
        levels = list()
        [levels.append("_".join([str(key), "All", "All", "All"])) for key in product_hierarchy]
        [levels.append("_".join([str(key), "Customer", "All", "All"])) for key in product_hierarchy]
        self.levels = levels

    def start(self):
        """
        This is the starting point where complete set of feature specs will be generated using feature levels.
        For each feature level there will be an sequential index attached to have the output in dictionary format.
        :return: Feature Specification Dictionary
        """
        result = OrderedDict()
        count = 0
        for name in self.levels:
            result[str(count)] = self.generate(name)
            count = count + 1
        return result

    def generate(self, name):
        """
        This method will generate feature specification for the feature level feed.
        Along with default values, few extra specifications will be created depending upon the product hierarchy.
        Output feature spec will have keys :
        [
          "name",
          "cadence_attribute",
          "rsd",
          "is_active",
          "summary_on",
          "durations",
          "base_features",
          "derived_features",
          "distinct_features",
          "dimension_attribute_grain",
          "additional_dimension_attribute",
          "dimension_attribute_null_filter"
        ]
        Please note, "additional_dimension_attribute" and "dimension_attribute_null_filter" keys will be
        generated only if product hierarchy is not "All".

        :param name: Feature Level
        :return: Feature Spec Dictionary
        """
        product_level = str(name.split("_")[0])
        basic = OrderedDict()
        basic["name"] = str(name).lower()
        basic["cadence_attribute"] = self.cadence_attribute
        basic["rsd"] = self.rsd
        basic["is_active"] = self.is_active
        basic["summary_on"] = self.summary_on
        basic["durations"] = self.durations
        basic["base_features"] = self.base_features
        basic["derived_features"] = self.derived_features
        basic["distinct_features"] = self.__get_distinct_features(name, product_level)
        basic["dimension_attribute_grain"] = self.__get_dimension_attribute_grain(name)

        if product_level != "All":
            basic["additional_dimension_attribute"] = self.__get_additional_dimension_attribute(product_level)
            basic["dimension_attribute_null_filter"] = self.__get_dimension_attribute_null_filter(name)

        return basic

    def __get_dimension_attribute_grain(self, name):
        """
        Dimension Attributes key will be generated using feature level.
        For example, if feature level is "Department_Customer_All_All", output will be:
        {
          "ProductAttribute": "Department",
          "CustomerAttribute": "Customer",
          "StoreAttribute": "All",
          "ChannelAttribute": "All"
        }
        :param name: Feature Level
        :return: Dimension Attribute Grain key
        """
        grains = name.split("_")
        return {
            "ProductAttribute": str(grains[0]),
            "CustomerAttribute": str(grains[1]),
            "StoreAttribute": str(grains[2]),
            "ChannelAttribute": str(grains[3])
        }

    def __get_additional_dimension_attribute(self, product_level):
        """
        Additional Dimension Attributes key will be generated using product hierarchy and feature level.
        {
          "dimension": "Product",
          "join_key": [product_level]
          "attribute": List of product levels above the given product level in the product hierarchy
        }
        Please note, if product level is "All" or the highest level in product hierarchy,
        output will be an empty list.
        :param product_level: Product level in the feature level.
        :return: Additional Dimension Attribute key
        """
        if product_level in ['All', self.product_hierarchy[0]]:
            return []
        else:
            return [{
                "dimension": "Product",
                "join_key": [product_level],
                "attribute": self.product_hierarchy[:self.product_hierarchy.index(product_level)]
            }]

    def __get_dimension_attribute_null_filter(self, name):
        """
        Dimension Attribute Null Filter key will be generated using feature level.
        List of dimension attribute will be the output except attributes having values as "All".
        For example, if feature level is "Section_Customer_All_All", output will be ["Section", "Customer"]
        :param name: Feature Level
        :return: Dimension Attribute Null Filter key
        """
        grains = name.split("_")
        return [str(i) for i in grains if i != "All"]

    def __get_distinct_features(self, name, product_level):
        """
        Distinct Features key will be generated using feature level and product level.
        For example, product hierarchy is ["Division", "Department", "Section"] and given product level is "Department".
        and feature level is "Department_All_All_All", output will be ["SectionCount", "CustomerCount"]
        :param name: Feature Level
        :param product_level: Product level in product hierarchy
        :return: Distinct Features key
        """
        if product_level == "All":
            distinct_feature_level = deepcopy(self.product_hierarchy)
        else:
            distinct_feature_level = deepcopy(self.product_hierarchy[(self.product_hierarchy.index(product_level)+1):])
        if str(name.split("_")[1]) == "All":
            distinct_feature_level.append("Customer")
        return [str(i) + "Count" for i in distinct_feature_level]


if __name__ == '__main__':
    """
    Starting point of the script. It expects two arguments (one product hierarchy and another is 
    the output file path) and generates feature specifications JSON file.
    """
    product_hierarchy = ast.literal_eval(sys.argv[1])
    product_hierarchy = [str(product_level) for product_level in product_hierarchy]
    output_file_path = sys.argv[2]

    obj = FeatureSpecsGenerator(product_hierarchy)
    obj.get_levels()
    result = obj.start()
    with open(output_file_path, "w") as outfile:
        json.dump(result, outfile)
