"""
Purchasing feature generator base class
"""


import logging
import time
import re
from copy import deepcopy
from itertools import groupby
from abc import ABCMeta, abstractproperty
from datetime import datetime as dt, timedelta as td, date as d
# TODO: Once futures 3.2.0 package (Backport of the concurrent.futures package) is installed and
# available on BDA cluster, docker, CI-CD pipeline remove concurrent.futures from tools folder and
# setup.py and also modify below import statement
from tools.concurrent.futures import ThreadPoolExecutor
from pyspark import StorageLevel
from pyspark.sql import functions as pf, types as pt
from pyspark.sql.dataframe import DataFrame
from dunnhumby.cmp_features.purchasing_feature_util import EPOCH_DATE, Summary_info_tuple, \
    Aggregate_info_tuple, Merge_info_tuple, View_info_tuple, Sel_col_tuple, Agg_sel_col_tuple, \
    Statement_tuple, Denormalization_res_tuple, Exec_res_tuple, Date_tuple, Col_tuple, \
    match_table_structure
from dunnhumby import contexts


logger = logging.getLogger(__name__)


class PurchasingFeatureGeneratorBase(object):
    """
    Purchasing feature generator base class
    """
    __metaclass__ = ABCMeta
    PROCESS_TYPE_DAILY = ["date_short_name", "daily"]
    PROCESS_TYPE_WEEKLY = ["fis_week_id", "weekly"]

    def __init__(self, config, cadence_attribute, run_date):
        """
        Constructor of PurchasingFeatureGeneratorBase
        :param config: client config
        :param cadence_attribute: cadence attribute can be either fis_week_id or date_short_name
        for either week or daily feature calculation.
        :param run_date: run_date can be either current date i.e today or any specific past date
        for which feature will be calculated (should be object of datetime.date).
        """
        super(PurchasingFeatureGeneratorBase, self).__init__()
        self.__current_date = None
        self.__recent_trans_date = None
        self.__cadence = None
        self.__cadence_week = None
        self.__since_date = None
        self.__required_dates = None
        self.__refresh_dates = None
        self.__required_fis_weeks = None
        self.__completed_fis_weeks = None
        self.__run_epoch = None
        self.__features_specifications = None
        self.__feature_mapping = None
        self.__trans_part_info = None
        self.__purchases_part_info = None
        # Business holidays should be accommodated in self.__business_holidays variable,
        # further code expects this should be list dates in text & iso format.
        self.__business_holidays = config.get("business_holidays", [])
        self.__pc_identifier = {"product": "Product", "customer": "Customer"}
        self.__paar_flag = True if config.get("SSEFeaturePaarFlag", "False").lower() == "true" \
            else False
        self._log_tab = config["SSEHiveWorkdb"] + "." + config["SSEFeatureLogTab"]
        self._clean_run = True if config.get("SSEFeatureCleanRun", "False").lower() == "true" \
            else False
        self._bucketing_flag = True if config.get("SSEFeatureBucketingFlag",
                                                  "False").lower() == "true" else False
        self._pac_flag = True if config.get("SSEFeaturePacFlag", "False").lower() == "true" \
            else False
        if self._pac_flag:
            self._product_hierarchy = [item for item in config["SSEProductHierarchy"]]
        else:
            self._product_hierarchy = [item for item in config["SSEProductHierarchy"]
                                       if item not in config.get("SSEFeaturePacColumns", [])]
        self._refresh_denorm = True if config.get("refresh_purchases_features",
                                                  "False").lower() == "true" else False
        self._refresh_summary = True if config.get("refresh_summary_features",
                                                  "False").lower() == "true" else False
        self._customer_df = None
        self._products_df = None
        self._dates_df = None
        self._stores_df = None

        # CMP entity objects (over fact tables) & should be used for accessing metadata info and
        # get_partition function should be leveraged to read a single partition of tables, usual
        # access via .data will result in full scan of object/fact table
        self._transactions = None
        self._purchases = None
        self.config = config
        self.run_date = run_date
        self.cadence_attribute = cadence_attribute
        self.weeks_to_be_refreshed = config.get("weeks_to_be_refreshed", 2)
        self.durations = [tuple(item) for item in self.config["SSEFeatureDurations"]] \
            if self.config.get("SSEFeatureDurations", []) else [(1, 1), (1, 4), (1, 13), (1, 26),
                                                                (1, 52), (1, 56)]
        self.dimension_grain = ["Product", "Customer", "Store", "Channel"]
        self.sqlContext = contexts.sql_context()
        # Register UDFs in spark session.
        self.register_udfs()

    @property
    def features_specifications(self):
        """
        Return Features specification list, actual value is set in client class
        :return: features_specifications: list of feature configs
        """
        if self.__features_specifications is None:
            raise ValueError("features_specifications referenced/accessed before assignment")
        return self.__features_specifications

    @features_specifications.setter
    def features_specifications(self, features_specifications):
        """
        Setter method of feature specification
        :param value: Features specification list
        :return:
        """
        # if-none approach used to avoid changes to feature_specification variable at run time, it
        # should be set only at beginning and remain same throughout the execution.
        if self.__features_specifications is None:
            if not isinstance(features_specifications, list):
                raise TypeError("features_specifications value must be a list")
            for features_spec in features_specifications:
                if not isinstance(features_spec, dict):
                    raise TypeError("Element of features_specification value must be a dict")
            # TODO: More structural check on elements & Once we start deriving feature spec from
            # config more stringent check should be applied.
            self.__features_specifications = features_specifications
        return

    @property
    def feature_mapping(self):
        """
        Return Features mapping, which contains all required info to calculate and store feature (
        like hive/spark datatype, formula used for calculation of feature etc.)
        :return: feature_mapping: dict
        """
        if self.__feature_mapping is None:
            # feature mapping - describes calculation/formula used to calculate value of particular
            # feature metric, it should at least include below these elements
            # col_name - column name used to identify metric
            # data_type - datatype of metric in spark dataframe
            # hive_type - datatype of metric in hive
            # sum_cal - formula/metric for populating summary tables
            # Agg_cal - formula/metric for populating aggregation tables
            # And Optionally it can include these elements
            # sum_data_type - datatype of metric in spark dataframe for summary table
            # sum_hive_type - datatype of metric in hive for summary table
            # Agg_proj - select expression used to populating columns value in aggregation tables,
            # if present this expr will be used in outer sql instead of simple column name
            # condition - a boolean condition whether to include metric or not, when metric is
            # dependent on some other metrics which are in different tables (mostly this will be
            # used in merge)
            self.__feature_mapping = {
                # Base feature mapping
                "Baskets": {
                    "col_name": "Baskets",
                    "data_type": pt.StructField("Baskets", pt.LongType(), True),
                    "hive_type": "bigint",
                    "sum_cal": "COUNT(DISTINCT Basket)",
                    "Agg_cal": "SUM(Baskets)"
                },
                "BasketWeeks": {
                    "col_name": "BasketWeeks",
                    "data_type": pt.StructField("BasketWeeks", pt.IntegerType(), True),
                    "hive_type": "int",
                    "sum_cal": "(CASE WHEN COUNT(DISTINCT Basket) > 0 THEN 1 ELSE 0 END)",
                    "Agg_cal": "SUM(BasketWeeks)"
                },
                "Discount": {
                    "col_name": "Discount",
                    "data_type": pt.StructField("Discount", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "SUM(DiscountAmount)",
                    "Agg_cal": "SUM(Discount)"
                },
                "MaximumPrice": {
                    "col_name": "MaximumPrice",
                    "data_type": pt.StructField("MaximumPrice", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "MAX(SpendAmount / Quantity)",
                    "Agg_cal": "MAX(MaximumPrice)"
                },
                "MinimumPrice": {
                    "col_name": "MinimumPrice",
                    "data_type": pt.StructField("MinimumPrice", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "MIN(SpendAmount / Quantity)",
                    "Agg_cal": "MIN(MinimumPrice)"
                },
                "MaximumNetPrice": {
                    "col_name": "MaximumNetPrice",
                    "data_type": pt.StructField("MaximumNetPrice", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "MAX(NetSpendAmount / Quantity)",
                    "Agg_cal": "MAX(MaximumNetPrice)"
                },
                "MinimumNetPrice": {
                    "col_name": "MinimumNetPrice",
                    "data_type": pt.StructField("MinimumNetPrice", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "MIN(NetSpendAmount / Quantity)",
                    "Agg_cal": "MIN(MinimumNetPrice)"
                },
                "Quantity": {
                    "col_name": "Quantity",
                    "data_type": pt.StructField("Quantity", pt.DecimalType(24, 2), True),
                    "hive_type": "decimal(24, 2)",
                    "sum_cal": "SUM(Quantity)",
                    "Agg_cal": "SUM(Quantity)"
                },
                "QuantityPrefStore1": {
                    "col_name": "QuantityPrefStore1",
                    "data_type": pt.StructField("QuantityPrefStore1", pt.DecimalType(24, 2), True),
                    "hive_type": "decimal(24, 2)",
                    "sum_cal": "SUM(CASE WHEN Store = PreferredStore1 THEN Quantity ELSE NULL END)",
                    "Agg_cal": "SUM(QuantityPrefStore1)"
                },
                "QuantityPrefStore2": {
                    "col_name": "QuantityPrefStore2",
                    "data_type": pt.StructField("QuantityPrefStore2", pt.DecimalType(24, 2), True),
                    "hive_type": "decimal(24, 2)",
                    "sum_cal": "SUM(CASE WHEN Store = PreferredStore2 THEN Quantity ELSE NULL END)",
                    "Agg_cal": "SUM(QuantityPrefStore2)"
                },
                "QuantityPrefStore3": {
                    "col_name": "QuantityPrefStore3",
                    "data_type": pt.StructField("QuantityPrefStore3", pt.DecimalType(24, 2), True),
                    "hive_type": "decimal(24, 2)",
                    "sum_cal": "SUM(CASE WHEN Store = PreferredStore3 THEN Quantity ELSE NULL END)",
                    "Agg_cal": "SUM(QuantityPrefStore3)"
                },
                "QuantityFulfillmentStore": {
                    "col_name": "QuantityFulfillmentStore",
                    "data_type": pt.StructField("QuantityFulfillmentStore", pt.DecimalType(24, 2),
                                                True),
                    "hive_type": "decimal(24, 2)",
                    "sum_cal":
                        "SUM(CASE WHEN Store = FulfillmentStore THEN Quantity ELSE NULL END)",
                    "Agg_cal": "SUM(QuantityFulfillmentStore)"
                },
                "GrossSpend": {
                    "col_name": "GrossSpend",
                    "data_type": pt.StructField("GrossSpend", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "SUM(SpendAmount)",
                    "Agg_cal": "SUM(GrossSpend)"
                },
                "NetSpend": {
                    "col_name": "NetSpend",
                    "data_type": pt.StructField("NetSpend", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": "SUM(NetSpendAmount)",
                    "Agg_cal": "SUM(NetSpend)"
                },
                "MaxPurchaseDate": {
                    "col_name": "MaxPurchaseDate",
                    "data_type": pt.StructField("MaxPurchaseDate", pt.StringType(), True),
                    "sum_data_type": pt.StructField("MaxPurchaseDate", pt.IntegerType(), True),
                    "hive_type": "string",
                    "sum_hive_type": "int",
                    "sum_cal": "MAX(datediff(date_id, '" + EPOCH_DATE + "'))",
                    "Agg_cal": "MAX(MaxPurchaseDate)",
                    "Agg_proj": "date_add('" + EPOCH_DATE + "', MaxPurchaseDate_{0}w{1}w)"
                },
                "MinPurchaseDate": {
                    "col_name": "MinPurchaseDate",
                    "data_type": pt.StructField("MinPurchaseDate", pt.StringType(), True),
                    "sum_data_type": pt.StructField("MinPurchaseDate", pt.IntegerType(), True),
                    "hive_type": "string",
                    "sum_hive_type": "int",
                    "sum_cal": "MIN(datediff(date_id, '" + EPOCH_DATE + "'))",
                    "Agg_cal": "MIN(MinPurchaseDate)",
                    "Agg_proj": "date_add('" + EPOCH_DATE + "', MinPurchaseDate_{0}w{1}w)"
                },
                "RecencyWeightedBasketWeeks75": {
                    # this feature have special formula or need specific input column
                    "col_name": "RecencyWeightedBasketWeeks75",
                    "data_type": pt.StructField("RecencyWeightedBasketWeeks75",
                                                pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "SUM(Baskets * pow(0.75, fisweekdiff('" + str(self.cadence_week) +
                               "', fis_week_id) + 1))"
                },
                "RecencyWeightedBasketWeeks95": {
                    # this feature have special formula or need specific input column
                    "col_name": "RecencyWeightedBasketWeeks95",
                    "data_type": pt.StructField("RecencyWeightedBasketWeeks95",
                                                pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "SUM(Baskets * pow(0.95, fisweekdiff('" + str(self.cadence_week) +
                               "', fis_week_id) + 1))"
                },
                "StandardDeviationNetSpendPerWeek": {
                    # this feature have special formula or need specific input column
                    "col_name": "StandardDeviationNetSpendPerWeek",
                    "data_type": pt.StructField("StandardDeviationNetSpendPerWeek",
                                                pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "STDDEV(NetSpend)",
                    "condition": lambda x: True
                },
                # Derived feature mapping
                "BasketsFlag": {
                    "col_name": "BasketsFlag",
                    "data_type": pt.StructField("BasketsFlag", pt.BooleanType(), True),
                    "hive_type": "BOOLEAN",
                    "sum_cal": None,
                    "Agg_cal": "(CASE WHEN Baskets_{0}w{1}w > 0 THEN TRUE ELSE FALSE END)",
                    "Agg_proj": "(CASE WHEN Baskets_{0}w{1}w > 0 THEN TRUE ELSE FALSE END)"
                },
                "DiscountPerBasket": {
                    "col_name": "DiscountPerBasket",
                    "data_type": pt.StructField("DiscountPerBasket", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "(Discount_{0}w{1}w / Baskets_{0}w{1}w)",
                    "Agg_proj": "(Discount_{0}w{1}w / Baskets_{0}w{1}w)"
                },
                "DiscountPercent": {
                    "col_name": "DiscountPercent",
                    "data_type": pt.StructField("DiscountPercent", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "((Discount_{0}w{1}w / GrossSpend_{0}w{1}w) * 100)",
                    "Agg_proj": "((Discount_{0}w{1}w / GrossSpend_{0}w{1}w) * 100)"
                },
                "AveragePrice": {
                    "col_name": "AveragePrice",
                    "data_type": pt.StructField("AveragePrice", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "(GrossSpend_{0}w{1}w / Quantity_{0}w{1}w)",
                    "Agg_proj": "(GrossSpend_{0}w{1}w / Quantity_{0}w{1}w)"
                },
                "QuantityPerBasket": {
                    "col_name": "QuantityPerBasket",
                    "data_type": pt.StructField("QuantityPerBasket", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "(Quantity_{0}w{1}w / Baskets_{0}w{1}w)",
                    "Agg_proj": "(Quantity_{0}w{1}w / Baskets_{0}w{1}w)"
                },
                "NetSpendPerBasket": {
                    "col_name": "NetSpendPerBasket",
                    "data_type": pt.StructField("NetSpendPerBasket", pt.DecimalType(38, 2), True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "(NetSpend_{0}w{1}w / Baskets_{0}w{1}w)",
                    "Agg_proj": "(NetSpend_{0}w{1}w / Baskets_{0}w{1}w)"
                },
                "AveragePurchaseCycle": {
                    "col_name": "AveragePurchaseCycle",
                    "data_type": pt.StructField("AveragePurchaseCycle", pt.DecimalType(38, 2),
                                                True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "(datediff(MaxPurchaseDate_{0}w{1}w, MinPurchaseDate_{0}w{1}w) / "
                               "(Baskets_{0}w{1}w - 1))",
                    "Agg_proj": "((MaxPurchaseDate_{0}w{1}w - MinPurchaseDate_{0}w{1}w) / "
                                "(Baskets_{0}w{1}w - 1))"
                },
                "RecencyDays": {
                    "col_name": "RecencyDays",
                    "data_type": pt.StructField("RecencyDays", pt.IntegerType(), True),
                    "hive_type": "int",
                    "sum_cal": None,
                    "Agg_cal": "(datediff('" + (self.cadence + td(days=1)).isoformat() +
                               "', MaxPurchaseDate_{0}w{1}w))",
                    "Agg_proj": "(datediff('" + (self.cadence + td(days=1)).isoformat() + "', '" +
                                EPOCH_DATE + "') - MaxPurchaseDate_{0}w{1}w)"
                },
                "CyclesSinceLastPurchase": {
                    "col_name": "CyclesSinceLastPurchase",
                    "data_type": pt.StructField("CyclesSinceLastPurchase", pt.DecimalType(6, 2),
                                                True),
                    "hive_type": "decimal(6, 2)",
                    "sum_cal": None,
                    # Formula for CyclesSinceLastPurchase is "RecencyDays / AveragePurchaseCycle"
                    "Agg_cal": "((datediff('" + (self.cadence + td(days=1)).isoformat() +
                               "', MaxPurchaseDate_{0}w{1}w)) / "
                               "(datediff(MaxPurchaseDate_{0}w{1}w, MinPurchaseDate_{0}w{1}w) / "
                               "(Baskets_{0}w{1}w - 1)))",
                    "Agg_proj": "((datediff('" + (self.cadence + td(days=1)).isoformat() + "', '" +
                                EPOCH_DATE + "') - MaxPurchaseDate_{0}w{1}w) / "
                                "((MaxPurchaseDate_{0}w{1}w - MinPurchaseDate_{0}w{1}w) / "
                                "(Baskets_{0}w{1}w - 1)))"
                },
                # Dependent Derived features - these are supported only in merge section
                "BasketsDecay1w13wvs1w26w": {
                    "col_name": "BasketsDecay_1w13wvs1w26w",
                    "data_type": pt.StructField("BasketsDecay_1w13wvs1w26w", pt.DecimalType(38, 2),
                                                True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "Baskets_1w13w / Baskets_1w26w",
                    "condition": lambda x: True if (1, 13) in x and (1, 26) in x else False
                },
                "BasketsDecay1w13wvs1w52w": {
                    "col_name": "BasketsDecay_1w13wvs1w52w",
                    "data_type": pt.StructField("BasketsDecay_1w13wvs1w52w", pt.DecimalType(38, 2),
                                                True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "Baskets_1w13w / Baskets_1w52w",
                    "condition": lambda x: True if (1, 13) in x and (1, 52) in x else False
                },
                # Other feature mapping - these feature will be computed directly from purchase or
                # denorm table
                "StandardDeviationNetSpend": {
                    "col_name": "StandardDeviationNetSpend",
                    "data_type": pt.StructField("StandardDeviationNetSpend", pt.DecimalType(38, 2),
                                                True),
                    "hive_type": "decimal(38, 2)",
                    "sum_cal": None,
                    "Agg_cal": "STDDEV(NetSpendAmount)",
                    "Agg_proj": "StandardDeviationNetSpend",
                    "condition": lambda x: True if ((1, 52) in x and self.cadence_attribute.lower()
                                                    in self.PROCESS_TYPE_DAILY) else False
                },
                # Distinct feature mapping
                "CustomerCount": {
                    "col_name": "CustomerCount",
                    "data_type": pt.StructField("CustomerCount", pt.LongType(), True),
                    "hive_type": "bigint",
                    "sum_cal": None,
                    "Agg_cal": "CustomerCount"
                }
            }
            # Adding mapping for Distinct feature for product hierarchy to feature mapping
            for item in self.config["SSEProductHierarchy"]:
                temp = dict()
                temp["col_name"] = item + "Count"
                temp["data_type"] = pt.StructField(item + "Count", pt.LongType(), True)
                temp["hive_type"] = "bigint"
                temp["sum_cal"] = None
                temp["Agg_cal"] = item + "Count"
                self.__feature_mapping[item + "Count"] = temp
        return self.__feature_mapping

    @abstractproperty
    def purchases(self):
        """ Purchases entity - should be used for only metadata and write operation """
        pass

    @abstractproperty
    def transactions(self):
        """ Transactions entity - should be used for only metadata and partition read operation """
        pass

    @abstractproperty
    def customers_df(self):
        """
        customers_df - Customers entity's data (only required columns)
        Note - Also implement setter for customers_df in client class, else denormalization_section
        will error out with "AttributeError: can't set attribute"
        Minimum code implementation required -
        @customers_df.setter
        def customers_df(self, customers_df):
            self._customer_df = customers_df
        """
        pass

    @abstractproperty
    def products_df(self):
        """
        products_df - Products entity's data (only required columns)
        Note - Also implement setter for product_df in client class, else in denormalization_section
        code will error out with "AttributeError: can't set attribute"
        Minimum code implementation required -
        @products_df.setter
        def products_df(self, products_df):
            self._products_df = products_df
        """
        pass


    @abstractproperty
    def dates_df(self):
        """ dates_df - Dates dimensnion """
        pass

    @abstractproperty
    def stores_df(self):
        """ stores_df - Stores dimensnion """
        pass


    def register_supplementary_tables(self):
        """
        Client implementation will override this method to register supplementary table required to
        derive extra dimension attribute or any other supplementary column/information.
        :return: (True/False, tab_lst): (boolean, list() of supplementary table)
        """
        logger.info("Nothing to process for supplementary requirements")
        return True, []

    def delete_supplementary_tables(self, tab_lst):
        """
        Client implementation will override this method to delete supplementary table required to
        derive extra dimension attribute or any other supplementary column/information.
        :param tab_lst: list() of supplementary table
        :return: True/False: boolean
        """
        logger.info("Nothing to process/delete for supplementary requirements")
        return True

    @property
    def current_date(self):
        """
        Return current day (i.e day on which process/execution is started)
        :return: current_date: object of datetime.date
        """
        if self.__current_date is None:
            self.__current_date = dt.today().date()
        return self.__current_date

    @property
    def cadence(self):
        """
        cadence is calculated based on run_date, most_recent_transaction_date and cadence_attrtibute
        if cadence_attribute is fis_week_id, then cadence would be last day of latest completed
        fis_week, or if cadence_attribute is date_short_name, then cadence would be latest
        concluded day (based on data availability in transactions)
        :return: cadence: object of datetime.date
        """
        if self.__cadence is None:
            # if run_date is equal to current date then run_date - 1 will be consider, as we may
            # have data for current date in transactions, which isn't complete at moment.
            r_date = self.run_date - td(days=1) if self.run_date == self.current_date \
                else self.run_date
            cadence = r_date if r_date < self.recent_trans_date else self.recent_trans_date
            if self.cadence_attribute in ("date_short_name", "daily"):
                self.__cadence = cadence
            elif self.cadence_attribute in ("fis_week_id", "weekly"):
                self.__cadence = self.dates_df.filter(
                    self.dates_df.date_id.between((cadence - td(days=20)), cadence)
                    & self.dates_df.fis_day_of_week_num.isin([7])). \
                    select("date_id").agg(pf.max("date_id").alias("cadence")).first()["cadence"]
            else:
                raise ValueError("Invalid cadence_attribute {value}".
                                 format(value=self.cadence_attribute))
        return self.__cadence

    @cadence.setter
    def cadence(self, cadence):
        """
        Setter method of cadence - it set cadence based on user input
        Note - This have been introduced to support creation of denorm table independent/outside of
        feature job, it shouldn't be used in feature classes and feature job at all.
        Basic idea is denormalization_section method only require start and end date to determine
        date range for denorm table creation and this method will set value for start date which
        will be supplied by user.
        :param cadence: object of datetime.date
        :return: None
        """
        # if-none approach used to avoid changes to variable value at run time, it should be set
        # only at beginning and remain same throughout the execution.
        if self.__cadence is None:
            if not isinstance(cadence, d):
                raise TypeError("cadence (start date) value must be object of datetime.date")
            self.__cadence = cadence
        return

    @property
    def cadence_week(self):
        """
        Return corresponding fis week of cadence date
        :return: cadence_week: string: return fis_week_id of cadence_week date
        """
        if self.__cadence_week is None:
            fis_week = self.dates_df.filter(self.dates_df.date_id == self.cadence). \
                first()["fis_week_id"]
            self.__cadence_week = fis_week
        return str(self.__cadence_week)

    @property
    def since_date(self):
        """
        Calculate since_date based on longest feature duration
        :return: since_date: object of datetime.date
        """
        if self.__since_date is None:
            max_week = max([week for duration in self.durations for week in duration])
            since_date = self.cadence - td(days=(max_week * 7) - 1)
            self.__since_date = since_date
        return self.__since_date

    @since_date.setter
    def since_date(self, since_date):
        """
        Setter method of since_date - it set since_date based on user input
        Note - This have been introduced to support creation of denorm table independent/outside of
        feature job, it shouldn't be used in feature classes and feature job at all.
        Basic idea is denormalization_section method only require start and end date to determine
        date range for denorm table creation and this method will set value for end date which will
        be supplied by user.
        :param since_date: object of datetime.date
        :return: None
        """
        # if-none approach used to avoid changes to variable value at run time, it should be set
        # only at beginning and remain same throughout the execution.
        if self.__since_date is None:
            if not isinstance(since_date, d):
                raise TypeError("since_date (end date) value must be object of datetime.date")
            self.__since_date = since_date
        return

    @property
    def required_fis_weeks(self):
        """
        Generate list of required fis weeks for feature calculation
        :return: required_fis_weeks: list(): list of fis weeks (in string format)
        """
        if self.__required_fis_weeks is None:
            self.__required_fis_weeks = list(set([item.fis_week_id
                                                  for item in self.required_dates]))
        return self.__required_fis_weeks

    @property
    def required_dates(self):
        """
        Generate list of required dates for feature calculation
        :return: required_dates: list(Date_tuple()): list of fis weeks and date_id in iso format
        """
        if self.__required_dates is None:
            required_dates = self.dates_df.filter(
                self.dates_df.date_id.between(self.since_date, self.cadence)). \
                select("fis_year_id", "fis_week_id", "date_id").distinct().collect()
            temp_lst = [Date_tuple(fis_year_id=str(item["fis_year_id"]),
                                   fis_week_id=str(item["fis_week_id"]),
                                   date_id=item["date_id"].isoformat()) for item in required_dates]
            self.__required_dates = sorted(temp_lst, key=lambda x: x.fis_week_id)
        return self.__required_dates

    @property
    def refresh_dates(self):
        """
        Generate list of dates which need to be refreshed (denorm and summaries for these dates will
        be refreshed)
        :return: refresh_dates: list(Date_tuple()): list of fis weeks and date_id in iso format
        """
        if self.__refresh_dates is None:
            refresh_dates = self.dates_df.filter(
                self.dates_df.date_id.between(self.cadence - td(days=(self.weeks_to_be_refreshed * 7)), self.cadence)).\
                select("fis_year_id", "fis_week_id", "date_id").distinct().collect()
            temp_lst = [Date_tuple(fis_year_id=str(item["fis_year_id"]),
                                   fis_week_id=str(item["fis_week_id"]),
                                   date_id=item["date_id"].isoformat()) for item in refresh_dates]
            self.__refresh_dates = sorted(temp_lst, key=lambda x: x.fis_week_id)
        return self.__refresh_dates

    @property
    def completed_fis_weeks(self):
        if self.__completed_fis_weeks is None:
            completed = []
            # Input to groupby should be sorted (self.required_dates is already sorted)
            for key, group in groupby(self.required_dates, key=lambda x: x.fis_week_id):
                if len(list(group)) == 7:
                    completed.append(key)
            self.__completed_fis_weeks = completed
        return self.__completed_fis_weeks

    @property
    def recent_trans_date(self):
        """
        Fetches most recent transaction date from Transaction entity/tables
        :return: recent_trans_date: object of datetime.date
        """
        if self.__recent_trans_date is None:
            self.__recent_trans_date = self.transactions.most_recent_transaction_date.first()[
                "most_recent_transaction_date"]
        return self.__recent_trans_date

    def register_udfs(self):
        """
        Registers UDFs, so that these UDFs can be used later
        :return: None
        """
        fisweekdiff = lambda h_week, l_week: ((int(h_week[:4]) - int(l_week[:4])) * 52) - (
            int(l_week[4:]) - int(h_week[4:])) if h_week and l_week else None
        self.sqlContext.udf.register("fisweekdiff", fisweekdiff, pt.IntegerType())
        return

    def fetch_dates(self, fis_weeks):
        """
        Return list of dates in given fis week(s)
        :param fis_weeks: list of fis weeks
        :return: fetch_dates: list(): list of dates (in ISO string format)
        """
        dt_lst = self.dates_df.filter(self.dates_df.fis_week_id.isin(fis_weeks)). \
            select("date_short_name").collect()
        return [item["date_short_name"] for item in dt_lst]

    def write_purchase(self, date_id):
        """
        Write data into Purchase table
        :param date_id: date in ISO string format
        :return: res: Denormalization_res_tuple
        """
        b_time = time.time()
        logger.info("Creating purchases for date : %s", date_id)
        try:
            # TODO: Test/check if below operation is thread safe
            transactions_part_df = self.transactions.get_partition(date_id=date_id)
            self.purchases.write_data(transactions_part_df, self.customers_df, self.products_df, self.stores_df)
            e_time = time.time()
            time_taken = int(e_time - b_time)
            logger.info("Created purchases for date: %s in %d secs", date_id, time_taken)
            res = Denormalization_res_tuple(date_id=date_id, result=True, time_taken=time_taken)
        except Exception as e:
            # TODO: Narrow down exception level to handle only spark exception
            logger.error("Purchases creation failed for date %s : %s", date_id, str(e))
            res = Denormalization_res_tuple(date_id=date_id, result=False, time_taken=0)
        return res

    def execute_sql(self, stmt_tup):
        """
        Execute spark/hive sqls in hiveContext
        :param stmt_tup: Statement_tuple
        :return: res: Exec_res_tuple
        """
        try:
            b_time = time.time()
            logger.info("Executing %s for %s %s", stmt_tup.stmt_type, stmt_tup.tab_type,
                        stmt_tup.tab_name)
            self.sqlContext.sql(stmt_tup.sql_stmt)
            e_time = time.time()
            time_taken = int(e_time - b_time)
            logger.info("Executed %s for %s %s in %d secs", stmt_tup.stmt_type, stmt_tup.tab_type,
                        stmt_tup.tab_name, time_taken)
            if stmt_tup.log:
                temp_lst = [(self.cadence.isoformat(), self.cadence_week, self.cadence_attribute,
                             self.__run_epoch, stmt_tup.section, stmt_tup.tab_name,
                             stmt_tup.stmt_type)]
                self.write_to_log(temp_lst)
            res = Exec_res_tuple(feature_name=stmt_tup.feature_name, tab_name=stmt_tup.tab_name,
                                 result=True, time_taken=time_taken, log=stmt_tup.log,
                                 section=stmt_tup.section)
        except Exception as e:
            # TODO: Narrow down exception level to handle only spark exception
            logger.error("Execution of %s failed for %s %s : %s", stmt_tup.stmt_type,
                         stmt_tup.tab_type, stmt_tup.tab_name, str(e))
            res = Exec_res_tuple(feature_name=stmt_tup.feature_name, tab_name=stmt_tup.tab_name,
                                 result=False, time_taken=0, log=stmt_tup.log,
                                 section=stmt_tup.section)
        return res

    def get_partition_info(self, tab_name):
        """
        Return partitions info of any hive table
        :param tab_name: Hive table name
        :return: partition_info: list()
        """
        show_stmt = "show partitions {tabname}".format(tabname=tab_name)
        logger.info("Executing sql - %s", show_stmt)
        part_info = self.sqlContext.sql(show_stmt).collect()
        # Assuming tables have only single level partition, not multilevel partitioned
        return [row["partition"].split("=")[1] for row in part_info]

    def del_partition(self, tab_name, **kwargs):
        """
        Safe delete partition from underlying hive table.
        :param tab_name: hive table name
        :param kwargs: partition specification in key-val format where key will be partition column
        name and partition value (column value) would be val
        :return: None
        """
        partition_spec = []
        for key in kwargs:
            partition_spec.append("{colname}='{value}'".format(colname=key, value=kwargs[key]))
        if partition_spec:
            drop_stmt = "ALTER TABLE " + tab_name + \
                        " DROP IF EXISTS PARTITION ({0})".format(",".join(partition_spec))
            logger.info("Executing sql - %s", drop_stmt)
            self.sqlContext.sql(drop_stmt)
        return

    def gen_summary_statements(self, features_spec):
        """
        Generate required details for summary like sql's (table ddl, ins-sel statement)
        :param features_spec: dict(): element of self.features_specifications
        :return: temp: Summary_info_tuple
        """
        feature_name = features_spec["name"]
        tab_name = self.config["SSEHiveWorkdb"] + "." + features_spec["name"] + "_summary"
        run_mode = "parallel"
        i = (i for i in xrange(1, 1000))
        # Generate select expression for dim attributes
        sel_col = []  # element format - Sel_col_tuple
        group_col = []  # element format - list of column name
        # Filter null value from aggregation grain, get this value from feature specification else
        # use group_col list, which will be same in most cases except when we need more attribute
        # from dimension entity
        not_null_col = features_spec.get("dimension_attribute_null_filter", group_col)
        for item in self.dimension_grain:
            dim_attr = features_spec["dimension_attribute_grain"][item + "Attribute"]
            if isinstance(dim_attr, list):
                for attr in dim_attr:
                    sel_col.append(Sel_col_tuple(colname=attr,
                                                 select_expr="{expr} AS {col}".format(expr=attr,
                                                                                      col=attr),
                                                 hive_datatype="string", col_num=i.next()))
                    group_col.append(attr)
            elif dim_attr.lower() == "all":
                sel_col.append(Sel_col_tuple(colname=item,
                                             select_expr="{expr} AS {col}".format(expr="'All'",
                                                                                  col=item),
                                             hive_datatype="string", col_num=i.next()))
            else:
                sel_col.append(Sel_col_tuple(colname=dim_attr,
                                             select_expr="{expr} AS {col}".format(expr=dim_attr,
                                                                                  col=dim_attr),
                                             hive_datatype="string", col_num=i.next()))
                group_col.append(dim_attr)
        # Generate select expression for base_features
        sel_col = sel_col + [Sel_col_tuple(colname=self.feature_mapping[col]["col_name"],
                                           select_expr="{expr} AS {col}".format(
                                               expr=self.feature_mapping[col]["sum_cal"],
                                               col=self.feature_mapping[col]["col_name"]),
                                           hive_datatype=self.feature_mapping[col].get(
                                               "sum_hive_type",
                                               self.feature_mapping[col]["hive_type"]),
                                           col_num=i.next())
                             for col in features_spec.get("base_features", [])
                             if self.feature_mapping[col]["sum_cal"]]
        # Attach sel_col & grouping info
        sel_col = sel_col
        group_info = group_col
        # Generate sql statement
        # Table header
        ins_header = "INSERT OVERWRITE TABLE " + tab_name + \
                     " PARTITION (fis_week_id = '{summary_week}') "
        # Projection/Select clause
        ins_projection = " SELECT " + ",".join([item.select_expr for item in sel_col])
        # From clause
        ins_from = " FROM " + self.config["SSEHiveWorkdb"] + "." + self.config["SSEHivePurchaseTab"]
        # where clause
        where_lst = ["fis_week_id = '{summary_week}'"]
        if not_null_col and feature_name.lower() != self.config["SSEFeatureDistinctTab"].lower():
            where_lst = where_lst + ["{0} IS NOT NULL".format(item) for item in not_null_col]
        ins_where = " WHERE {0} ".format(" AND ".join(where_lst))
        # Any grouping, ordering, clustering clause
        grouping_stmt = " GROUP BY {0}".format(",".join(group_col)) if group_col else ""
        clustering_stmt = " CLUSTER BY {0}".format(",".join(group_col)) if group_col and any(
            item in group_col for item in self.__pc_identifier.values()) else ""
        ins_grp_ord_clust = grouping_stmt + (clustering_stmt if self._bucketing_flag else "")
        dml = ins_header + ins_projection + ins_from + ins_where + ins_grp_ord_clust
        # Generate create statement
        # Table header
        create_header = "CREATE TABLE IF NOT EXISTS " + tab_name
        # Column list
        create_col_lst = " (" + ",".join(["{colname} {hive_datatype}".format(colname=item.colname,
                                                                             hive_datatype=
                                                                             item.hive_datatype)
                                          for item in sel_col]) + ") "
        # Table storage properties
        cluster_stmt = " CLUSTERED BY ({0}) SORTED BY ({0}) INTO 250 BUCKETS".format(
            ",".join(group_col)) if group_col and any(
            item in group_col for item in self.__pc_identifier.values()) else ""
        create_storage_prop = " PARTITIONED BY (fis_week_id string) " + \
                              (cluster_stmt if self._bucketing_flag else "") + \
                              " STORED AS PARQUET" \
                              + ' TBLPROPERTIES ("parquet.compression"="gzip")'
        ddl_create = create_header + create_col_lst + create_storage_prop
        # Generate drop statement
        ddl_drop = "DROP TABLE IF EXISTS " + tab_name
        part_col = [Col_tuple(col_name="fis_week_id", data_type="string")]
        # Wave info, based on table size we are grouping tables to run in a particular wave
        # TODO: In future this logic should be derived from historical run details
        if self.__pc_identifier["customer"] in tab_name.split("_"):
            wave = 2
        else:
            wave = 1
        temp = Summary_info_tuple(feature_name=feature_name, tab_name=tab_name, run_mode=run_mode,
                                  ddl_drop=ddl_drop, ddl_create=ddl_create, dml=dml,
                                  group_info=group_info, sel_col=sel_col, part_col=part_col,
                                  wave=wave)
        return temp

    def gen_aggregate_statements(self, agg_info):
        """
        Generate required details for aggregation like sql's (table ddl, ins-sel statement)
        :param agg_info: tuple(duration, features_spec): duration is tuple denoting week duration
        like (1,4), (1, 52) etc., features_spec(dict()) is element of self.features_specifications
        :return: temp: Aggregate_info_tuple
        """
        get_expr = lambda expr, col: "{expr} AS {col}".format(expr=expr, col=col)
        week_duration, features_spec = agg_info
        feature_name = features_spec["name"]
        db_name = self.config["SSEHivePobdb"] if self.__paar_flag else self.config["SSEHiveWorkdb"]
        postfix = "_daily" if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY else ""
        tab_name = db_name + "." + feature_name + postfix + "_{0}w{1}w".format(week_duration[0],
                                                                               week_duration[1])
        if feature_name.lower() == self.config["SSEFeatureDistinctTab"].lower():
            run_mode = "sequential"
        else:
            run_mode = "parallel"
        i = (i for i in xrange(1, 500))  # start column num counter
        sel_col = []  # element format - Agg_sel_col_tuple
        group_col = []  # element format - list of column name
        input_summary_col = []  # element format - Sel_col_tuple - list of summary column name which
        # are used in aggregation compute
        # Filter null value from aggregation grain, get this value from feature specification else
        # use group_col list, which will be same in most cases except when we need more attribute
        # from dimension entity
        not_null_col = features_spec.get("dimension_attribute_null_filter", group_col)
        # Generate select expression for dim attributes
        for item in self.dimension_grain:
            dim_attr = features_spec["dimension_attribute_grain"][item + "Attribute"]
            if isinstance(dim_attr, list):
                for attr in dim_attr:
                    sel_col.append(Agg_sel_col_tuple(colname=attr,
                                                     in_select_expr="{expr} AS {col}".format(
                                                         expr=attr, col=attr),
                                                     out_select_expr="{expr} AS {col}".format(
                                                         expr="in_tab." + attr, col=attr),
                                                     hive_datatype="string", col_num=i.next()))
                    group_col.append(attr)
                    input_summary_col.append(Sel_col_tuple(colname=attr,
                                                           select_expr="{expr} AS {col}".format(
                                                               expr=attr, col=attr),
                                                           hive_datatype="string", col_num=0))
            elif dim_attr.lower() == "all":
                sel_col.append(Agg_sel_col_tuple(colname=item, in_select_expr=None,
                                                 out_select_expr="{expr} AS {col}".format(
                                                     expr="'All'", col=item),
                                                 hive_datatype="string", col_num=i.next()))
            else:
                sel_col.append(Agg_sel_col_tuple(colname=dim_attr,
                                                 in_select_expr="{expr} AS {col}".format(
                                                     expr=dim_attr, col=dim_attr),
                                                 out_select_expr="{expr} AS {col}".format(
                                                     expr="in_tab." + dim_attr, col=dim_attr),
                                                 hive_datatype="string", col_num=i.next()))
                group_col.append(dim_attr)
                input_summary_col.append(Sel_col_tuple(colname=dim_attr,
                                                       select_expr="{expr} AS {col}".format(
                                                           expr=dim_attr, col=dim_attr),
                                                       hive_datatype="string", col_num=0))
        # Generate select expression for base_features
        for col in features_spec.get("base_features", []):
            if self.feature_mapping[col]["Agg_cal"] and \
                    ((self.feature_mapping[col]).get("condition", lambda x: True))([week_duration]):
                col_name = self.feature_mapping[col]["col_name"] \
                           + "_{0}w{1}w".format(week_duration[0], week_duration[1])
                in_expr = self.feature_mapping[col]["Agg_cal"]
                out_expr = self.feature_mapping[col].get("Agg_proj",
                                                         self.feature_mapping[col]["col_name"] +
                                                         "_{0}w{1}w").format(week_duration[0],
                                                                             week_duration[1])
                tmp_tup = Agg_sel_col_tuple(colname=col_name,
                                            in_select_expr=get_expr(expr=in_expr, col=col_name),
                                            out_select_expr=get_expr(expr=out_expr, col=col_name),
                                            hive_datatype=self.feature_mapping[col]["hive_type"],
                                            col_num=i.next())
                sel_col.append(tmp_tup)
                if self.feature_mapping[col]["sum_cal"]:
                    col_name = self.feature_mapping[col]["col_name"]
                    expr = self.feature_mapping[col]["sum_cal"]
                    datatype = self.feature_mapping[col].get("sum_hive_type",
                                                             self.feature_mapping[col]["hive_type"])
                    input_summary_col.append(Sel_col_tuple(colname=col_name,
                                                           select_expr="{expr} AS {col}".format(
                                                               expr=expr, col=col_name),
                                                           hive_datatype=datatype, col_num=0))
        # Adding select expression for derived_features to sel_col list for paar run only
        i = (i for i in xrange(501, 1000))  # restart column num counter
        if self.__paar_flag:
            for col in features_spec.get("derived_features", []):
                col_name = self.feature_mapping[col]["col_name"] + \
                           "_{0}w{1}w".format(week_duration[0], week_duration[1])
                out_expr = self.feature_mapping[col].get("Agg_proj",
                                                         self.feature_mapping[col]["col_name"] +
                                                         "_{0}w{1}w").format(week_duration[0],
                                                                             week_duration[1])
                tmp_tup = Agg_sel_col_tuple(colname=col_name, in_select_expr=None,
                                            out_select_expr=get_expr(expr=out_expr, col=col_name),
                                            hive_datatype=self.feature_mapping[col]["hive_type"],
                                            col_num=i.next())
                sel_col.append(tmp_tup)
        # Generate select expression for other_features & create compute sql
        i = (i for i in xrange(1001, 1500))  # restart column num counter
        other_features_sql = None
        if features_spec.get("other_features"):
            temp_lst = []
            for col in features_spec.get("other_features", []):
                if self.feature_mapping[col]["Agg_cal"] and \
                        ((self.feature_mapping[col]).get("condition", lambda x: True))(
                            [week_duration]):
                    col_name = self.feature_mapping[col]["col_name"] + \
                               "_{0}w{1}w".format(week_duration[0], week_duration[1])
                    out_expr = self.feature_mapping[col]["Agg_proj"]
                    compute_expr = get_expr(expr=self.feature_mapping[col]["Agg_cal"], col=out_expr)
                    tmp_tup = Agg_sel_col_tuple(colname=col_name, in_select_expr=None,
                                                out_select_expr=get_expr(expr=out_expr,
                                                                         col=col_name),
                                                hive_datatype=self.feature_mapping[col][
                                                    "hive_type"],
                                                col_num=i.next())
                    sel_col.append(tmp_tup)
                    temp_lst.append(compute_expr)
            # Create other features compute sql
            of_projection = " SELECT " + ",".join(group_col + temp_lst)
            of_from = " FROM {purchase_tab} ".format(purchase_tab=self.purchases.table_name)
            of_where_lst = ["date_id in ({denorm_dates})"]
            if not_null_col:
                of_where_lst = of_where_lst + ["{0} IS NOT NULL".format(item)
                                               for item in not_null_col]
            of_where_stmt = " WHERE {0} ".format(" AND ".join(of_where_lst))
            of_grouping_stmt = "GROUP BY {0}".format(",".join(group_col)) if group_col else ""
            other_features_sql = "({0}{1}{2}{3}) AS of_tab".format(of_projection, of_from,
                                                                   of_where_stmt, of_grouping_stmt)
        # Generate select expression for distinct_features & create distinct count sql
        i = (i for i in xrange(1501, 2000))  # restart column num counter
        dist_sql = None
        if features_spec.get("distinct_features"):
            for col in features_spec["distinct_features"]:
                col_name = self.feature_mapping[col]["col_name"] \
                           + "_{0}w{1}w".format(week_duration[0], week_duration[1])
                tmp_tup = Agg_sel_col_tuple(colname=col_name,
                                            in_select_expr=None,
                                            out_select_expr=
                                            get_expr(expr=self.feature_mapping[col]["Agg_cal"],
                                                     col=col_name),
                                            hive_datatype=self.feature_mapping[col]["hive_type"],
                                            col_num=i.next())
                sel_col.append(tmp_tup)
            # TODO: come up with better method to calculate distinct
            # Create distinct count sql - last logic, distinct count were calculated in single go
            # from distinct tab, but this is causing bottle neck in bigger data set
            dist_projection = "SELECT " + ",".join(group_col + ["COUNT(DISTINCT {0}) AS {1}".format(
                item.replace("Count", ""), item) for item in features_spec["distinct_features"]])
            dist_tab = "{0}.{1}{2}_{3}w{4}w".format(db_name,
                                                    self.config["SSEFeatureDistinctTab"].lower(),
                                                    postfix, week_duration[0], week_duration[1])
            dist_from = "FROM {0}".format(dist_tab)
            cadence_where = "cadence_week = {cadence_week}".format(cadence_week=self.cadence_week)
            not_null_where = " AND ".join(
                ["{0} IS NOT NULL".format(item) for item in not_null_col]) if not_null_col else ""
            dist_where_stmt = "WHERE {0}".format(
                " AND ".join([where_clause for where_clause in [cadence_where, not_null_where] if where_clause]))
            dist_grouping_stmt = "GROUP BY {0}".format(",".join(group_col)) if group_col else ""
            in_join_lst = ["tab1.{0} = {1}.{0}".format(item, "tab{0}") for item in group_col]
            in_join_cond = "ON ({0})".format(" and ".join(in_join_lst)) if group_col else "ON (1=1)"
            if len(features_spec["distinct_features"]) == 1:
                dist_sql = "( {0} {1} {2} {3} ) AS dist_tab".format(dist_projection, dist_from,
                                                                    dist_where_stmt,
                                                                    dist_grouping_stmt)
            else:
                dist_inner_lst = []
                for idx, item in enumerate(features_spec["distinct_features"], 1):
                    dist_col_lst = ",".join(group_col + ["COUNT(DISTINCT {0}) AS {1}".format(
                        item.replace("Count", ""), item)])
                    if idx == 1:
                        in_join_clause = ""
                    else:
                        in_join_clause = in_join_cond.format(idx)
                    temp_sql_fmt = "(SELECT {0} FROM {1} {2} {3}) AS tab{4} {5}"
                    tmp_sql = temp_sql_fmt.format(dist_col_lst, dist_tab, dist_where_stmt,
                                                  dist_grouping_stmt, idx, in_join_clause)
                    dist_inner_lst.append(tmp_sql)
                dist_projection = "SELECT " + ",".join(
                    ["tab1.{0}".format(col) for col in group_col] +
                    [col for col in features_spec["distinct_features"]])
                dist_from = "FROM {0}".format(" INNER JOIN ".join(dist_inner_lst))
                dist_sql = "( {0} {1} ) AS dist_tab".format(dist_projection, dist_from)
        # Generate select expression for additional dimension attribute & create its sql
        i = (i for i in xrange(2001, 2500))  # restart column num counter
        extra_dim_attr_sql = None
        if features_spec.get("additional_dimension_attribute"):
            extra_dim_attr_sql = ""
            for dim in sorted(features_spec["additional_dimension_attribute"],
                              key=lambda x: x["dimension"]):
                dim_tab_name = self.config["SSEHiveWorkdb"] + "." + dim["dimension"] + "_dim_tab"
                d_alias = "dim_" + dim["dimension"]
                col_list = deepcopy(dim["join_key"])
                for col in sorted(dim["attribute"]):
                    col_list.append(col)
                    sel_col.append(Agg_sel_col_tuple(colname=col, in_select_expr=None,
                                                     out_select_expr="{expr} AS {col}".format(
                                                         expr=d_alias + "." + col, col=col),
                                                     hive_datatype="string", col_num=i.next()))
                # Create sql for extra dim attribute
                dim_sql = "( SELECT DISTINCT " + ",".join(col_list) + " FROM " + dim_tab_name + \
                          " ) AS " + d_alias
                j_lst = ["in_tab.{1} = {0}.{1}".format(d_alias, item) for item in dim["join_key"]]
                dim_join_condition = "ON ({0})".format(" and ".join(j_lst))
                extra_dim_attr_sql = extra_dim_attr_sql + " LEFT JOIN {dim_tab} {join_condition}".\
                    format(dim_tab=dim_sql, join_condition=dim_join_condition)
        # Add fis_week_id column to input_summary_col list, as this column used in one of the
        # feature calculation, so it is required to read this column from summary table and also we
        # need to supply dummy value which will be returned in case column is read from purchase
        input_summary_col.append(Sel_col_tuple(colname="fis_week_id",
                                               select_expr="'{expr}' AS {col}".format(
                                                   expr=max(self.required_fis_weeks),
                                                   col="fis_week_id"), hive_datatype="string",
                                               col_num=0))
        # Toggle partition column as per cadence attribute
        if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
            part_col_name, part_col_value = "cadence_day", self.cadence
        else:
            part_col_name, part_col_value = "cadence_week", self.cadence_week
        # Generate sql statement
        # Table header
        ins_header = "INSERT OVERWRITE TABLE " + tab_name + \
                     " PARTITION ({0} = '{1}')".format(part_col_name, part_col_value)
        # Projection/Select clause
        ins_projection = " SELECT " + ",".join([item.out_select_expr for item in sel_col])
        # Inner subquery
        inner_projection = " SELECT " + ",".join([item.in_select_expr for item in sel_col
                                                  if item.in_select_expr])
        union_projection1 = " SELECT " + ",".join([item.colname for item in input_summary_col])
        union_projection2 = " SELECT " + ",".join([item.select_expr for item in input_summary_col])
        union_from1 = " FROM {db}.{featurename}_summary ".format(db=self.config["SSEHiveWorkdb"],
                                                                featurename=feature_name)
        union_from2 = " FROM {purchase_tab} ".format(purchase_tab=self.purchases.table_name)
        union_where_lst1 = ["fis_week_id in ({summary_weeks})"]
        union_where_lst2 = ["date_id in ({incomplete_dates})"]
        if not_null_col and feature_name.lower() != self.config["SSEFeatureDistinctTab"].lower():
            union_where_lst1 = union_where_lst1 + ["{0} IS NOT NULL".format(item)
                                                   for item in not_null_col]
            union_where_lst2 = union_where_lst2 + ["{0} IS NOT NULL".format(item)
                                                   for item in not_null_col]
        union_where1 = " WHERE {0} ".format(" AND ".join(union_where_lst1))
        union_where2 = " WHERE {0} ".format(" AND ".join(union_where_lst2))
        union_grouping_stmt2 = " GROUP BY {0} ".format(",".join(group_col)) if group_col else ""
        inner_grouping_stmt = " GROUP BY {0} ".format(",".join(group_col)) if group_col else ""
        subquery_fmt = "({0} FROM ({1}{2}{3} UNION ALL {4}{5}{6}{7}) AS union_tab {8}) AS in_tab"
        ins_inner_subquery = subquery_fmt.format(inner_projection, union_projection1, union_from1,
                                                 union_where1, union_projection2, union_from2,
                                                 union_where2, union_grouping_stmt2,
                                                 inner_grouping_stmt)
        # From clause
        ins_from = " FROM " + ins_inner_subquery
        # Join clause
        of_join_lst = ["in_tab.{0} = of_tab.{0}".format(item) for item in group_col]
        of_join_cond = "ON ({0})".format(" and ".join(of_join_lst)) if group_col else "ON (1=1)"
        of_join_stmt = " LEFT JOIN {other_feature_tab} {join_condition}". \
            format(other_feature_tab=other_features_sql, join_condition=of_join_cond) \
            if other_features_sql else ""
        dist_join_lst = ["in_tab.{0} = dist_tab.{0}".format(item) for item in group_col]
        dis_join_cond = "ON ({0})".format(" and ".join(dist_join_lst)) if group_col else "ON (1=1)"
        dist_join_stmt = " LEFT JOIN {dist_tab} {join_condition}". \
            format(dist_tab=dist_sql, join_condition=dis_join_cond) if dist_sql else ""
        extra_dim_join_stmt = extra_dim_attr_sql if extra_dim_attr_sql else ""
        ins_join_stmt = of_join_stmt + dist_join_stmt + extra_dim_join_stmt
        # Any grouping, ordering, clustering clause
        clustering_stmt = " CLUSTER BY {0}".format(",".join(group_col)) if group_col and any(
            item in group_col for item in self.__pc_identifier.values()) else ""
        ins_grp_ord_clust = (clustering_stmt if self._bucketing_flag else "")
        dml = ins_header + ins_projection + ins_from + ins_join_stmt + ins_grp_ord_clust
        # Generate create statement
        # Table header
        create_header = "CREATE TABLE IF NOT EXISTS " + tab_name
        # Column list
        create_col_lst = " (" + ",".join(["{colname} {hive_datatype}".format(colname=item.colname,
                                                                             hive_datatype=
                                                                             item.hive_datatype)
                                          for item in sel_col]) + ")"
        # Table storage properties
        cluster_stmt = " CLUSTERED BY ({0}) SORTED BY ({0}) INTO 250 BUCKETS".format(
            ",".join(group_col)) if group_col and any(
            item in group_col for item in self.__pc_identifier.values()) else ""
        create_storage_prop = " PARTITIONED BY ({0} string)".format(part_col_name) + \
                              (cluster_stmt if self._bucketing_flag else "") + " STORED AS PARQUET"\
                              + ' TBLPROPERTIES ("parquet.compression"="gzip")'
        ddl_create = create_header + create_col_lst + create_storage_prop
        # Generate drop statement
        ddl_drop = "DROP TABLE IF EXISTS " + tab_name
        part_col = [Col_tuple(col_name=part_col_name, data_type="string")]
        # Wave info, based on table size we are grouping tables to run in a particular wave
        # TODO: In future this logic should be derived from historical run details
        week_diff = week_duration[1] - week_duration[0]
        if week_diff < 10:
            wave = 1
        elif week_diff < 20:
            wave = 2
        elif week_diff < 30:
            wave = 3
        else:
            wave = 4
        temp = Aggregate_info_tuple(feature_name=feature_name, tab_name=tab_name,
                                    duration=week_duration, run_mode=run_mode, ddl_drop=ddl_drop,
                                    ddl_create=ddl_create, dml=dml, group_info=group_col,
                                    sel_col=sel_col, part_col=part_col, wave=wave)
        return temp

    def gen_merge_statements(self, merge_info):
        """
        Generate required details for Merge of different durations features like sql's (table ddl,
        ins-sel statement)
        :param merge_info: Merge_info_tuple
        :return: temp: Merge_info_tuple
        """
        get_expr = lambda expr, col, durations: "{expr} AS {col}".format(expr=expr, col=col) \
            if re.match("[a-zA-Z0-9]+_\d+w\d+w(vs\d+w\d+w)?$", col) else \
            "COALESCE({expr}) AS {col}".format(expr=",".join(
                ["{0}w{1}w.{2}".format(dur[0], dur[1], expr) for dur in durations]), col=col)
        postfix = "_daily" if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY else ""
        feature_name = merge_info.feature_name
        tab_name = self.config["SSEHivePobdb"] + "." + feature_name + postfix
        durations = merge_info.durations
        agg_tabs = merge_info.agg_tabs
        run_mode = "parallel"
        group_info = merge_info.group_info
        bigger_duration = merge_info.durations[0]
        # sel_col - element format - Sel_col_tuple
        sel_col = [Sel_col_tuple(colname=item.colname,
                                 select_expr=get_expr(expr=item.colname, col=item.colname,
                                                      durations=durations),
                                 hive_datatype=item.hive_datatype, col_num=item.col_num)
                   for item in merge_info.sel_col]
        # Adding select expression for derived_features & dependent_derived_features to sel_col list
        # for each required duration
        i = (i for i in xrange(2501, 3000))  # restart column num counter
        for item in self.features_specifications:
            if item["name"].lower() == feature_name.lower() and \
                            self.cadence_attribute.lower() == item["cadence_attribute"]:
                for d_feature in item.get("derived_features", []):
                    for dur in sorted(merge_info.durations, key=lambda x: x[0] + x[1]):
                        if dur in item["durations"]:
                            col_name = self.feature_mapping[d_feature]["col_name"] + \
                                       "_{0}w{1}w".format(dur[0], dur[1])
                            sel_expr = get_expr(expr=self.feature_mapping[d_feature]["Agg_cal"].
                                                format(dur[0], dur[1]),
                                                col=col_name, durations=durations)
                            col_info = Sel_col_tuple(colname=col_name,
                                                     select_expr=sel_expr,
                                                     hive_datatype=self.feature_mapping[d_feature]
                                                     ["hive_type"], col_num=i.next())
                            sel_col.append(col_info)
                for dd_feature in item.get("dependent_derived_features", []):
                    if self.feature_mapping[dd_feature]["condition"](merge_info.durations):
                        col_name = self.feature_mapping[dd_feature]["col_name"]
                        sel_expr = get_expr(expr=self.feature_mapping[dd_feature]["Agg_cal"],
                                            col=col_name, durations=durations)
                        col_info = Sel_col_tuple(colname=col_name, select_expr=sel_expr,
                                                 hive_datatype=self.feature_mapping[dd_feature]
                                                 ["hive_type"], col_num=i.next())
                        sel_col.append(col_info)
        # Toggle partition column as per cadence attribute
        if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
            part_col_name, part_col_value = "cadence_day", self.cadence
        else:
            part_col_name, part_col_value = "cadence_week", self.cadence_week
        # Generate select expression
        # Table header
        ins_header = "INSERT OVERWRITE TABLE " + tab_name + \
                     " PARTITION ({0} = '{1}')".format(part_col_name, part_col_value)
        # Projection/Select clause
        ins_projection = " SELECT " + ",".join([item.select_expr for item in sel_col])
        # From clause
        bigger_tab = merge_info.agg_tabs[0]
        ins_from = " FROM " + "{0} AS {1}w{2}w".format(bigger_tab[0], bigger_tab[1][0],
                                                       bigger_tab[1][1])
        # Join clause
        group_cols = merge_info.group_info
        join_condition = " ON ({0})".format(
            " and ".join(["{1}w{2}w.{0}".format(item, bigger_duration[0], bigger_duration[1])
                          + "= {0}w{1}w." + "{0}".format(item) for item in group_cols])) \
            if group_cols else " ON (1=1)"
        join_stmt = ""
        for agg_tab in merge_info.agg_tabs[1:]:
            join_stmt = join_stmt + " FULL OUTER JOIN {0} AS {1}w{2}w ". \
                format(agg_tab[0], agg_tab[1][0], agg_tab[1][1]) + \
                        join_condition.format(agg_tab[1][0], agg_tab[1][1])
        ins_join_stmt = " " + join_stmt
        dml = ins_header + ins_projection + ins_from + ins_join_stmt
        # Generate create statement
        # Table header
        create_header = "CREATE TABLE IF NOT EXISTS " + tab_name
        # Column list
        create_col_lst = " (" + ",".join(["{colname} {hive_datatype}".format(colname=item.colname,
                                                                             hive_datatype=
                                                                             item.hive_datatype)
                                          for item in sel_col]) + ") "
        # Table storage properties
        create_storage_prop = "PARTITIONED BY ({0} string) STORED AS PARQUET".format(part_col_name)\
                              + ' TBLPROPERTIES ("parquet.compression"="gzip")'
        ddl_create = create_header + create_col_lst + create_storage_prop
        # Generate drop statement
        drop_stmt = "DROP TABLE IF EXISTS " + tab_name
        ddl_drop = drop_stmt
        part_col = [Col_tuple(col_name=part_col_name, data_type="string")]
        # Wave info, based on table size we are grouping tables to run in a particular wave
        # TODO: In future this logic should be derived from historical run details
        all_num = sum([1 for item in feature_name.split("_") if item.lower() == "all"])
        if all_num >= 3:
            wave = 1
        else:
            wave = 2
        temp = Merge_info_tuple(feature_name=feature_name, tab_name=tab_name, durations=durations,
                                agg_tabs=agg_tabs, run_mode=run_mode, ddl_drop=ddl_drop,
                                ddl_create=ddl_create, dml=dml, group_info=group_info,
                                sel_col=sel_col, part_col=part_col, wave=wave)
        return temp

    def create_log_tab(self):
        """
        Create log table if log table does not exist in hive
        :return: res: Exec_res_tuple
        """
        logger.info("Creating log table [IF NOT EXITS] - %s", self._log_tab)
        if self._clean_run:
            drop_stmt = "DROP TABLE IF EXISTS " + self._log_tab
            stmt_tup = Statement_tuple(feature_name="log_tab", tab_type="table",
                                       tab_name=self._log_tab, stmt_type="ddl - drop",
                                       sql_stmt=drop_stmt, log=False, section="pre_run", wave=None)
            res = self.execute_sql(stmt_tup)
        create_stmt = "CREATE TABLE IF NOT EXISTS " + self._log_tab + \
                      "(cadence string, cadence_week string, cadence_attribute string, " \
                      "run_epoch bigint, section string, tab_name string, stmt_type string) " \
                      "ROW FORMAT DELIMITED FIELDS TERMINATED BY '|' STORED AS TEXTFILE"
        stmt_tup = Statement_tuple(feature_name="log_tab", tab_type="table", tab_name=self._log_tab,
                                   stmt_type="ddl - create", sql_stmt=create_stmt, log=False,
                                   section="pre_run", wave=None)
        res = self.execute_sql(stmt_tup)
        return res.result

    def write_to_log(self, data, overwrite=False):
        """
        Write row(s) to log table
        :param data: rows to write in list or in dataframe
        :param overwrite: existing data override flag
        :return: None
        """
        w_mode = "overwrite" if overwrite else "append"
        logger.info("Writing success result to log table")
        feature_run_log_schema = pt.StructType([
            pt.StructField("cadence", pt.StringType(), True),
            pt.StructField("cadence_week", pt.StringType(), True),
            pt.StructField("cadence_attribute", pt.StringType(), True),
            pt.StructField("run_epoch", pt.LongType(), True),
            pt.StructField("section", pt.StringType(), True),
            pt.StructField("tab_name", pt.StringType(), True),
            pt.StructField("stmt_type", pt.StringType(), True)
        ])
        if isinstance(data, DataFrame):
            data = data.select([pf.col(field.name).cast(field.dataType).alias(field.name)
                                for field in feature_run_log_schema.fields])
            data.coalesce(1).write.format("text").mode(w_mode).insertInto(self._log_tab,
                                                                          overwrite=overwrite)
        else:
            temp_df = self.sqlContext.createDataFrame(data, feature_run_log_schema)
            temp_df.coalesce(1).write.format("text").mode(w_mode).insertInto(self._log_tab,
                                                                             overwrite=overwrite)
        return

    def pre_run(self, clean_run=None):
        """
        PRE RUN SECTION
        :param clean_run: boolean: Argument clean_run (when True) activate clean slate run, i.e.
        process will remove all old data & tables related to pfg and provide refresh/clean run.
        :return: boolean: True/False
        """
        self._clean_run = clean_run if clean_run else self._clean_run
        logger.info("#### PRE RUN SECTION ####")
        logger.info("Paar flag - %s", self.__paar_flag)
        logger.info("Clean run - %s", self._clean_run)
        logger.info("Feature durations - %s", str(self.durations))
        logger.info("Current date - %s", str(self.current_date))
        logger.info("Run date - %s", str(self.run_date))
        logger.info("Most recent transaction date - %s", str(self.recent_trans_date))
        logger.info("Cadence attribute - %s", str(self.cadence_attribute))
        logger.info("Cadence date - %s", str(self.cadence))
        logger.info("Cadence fis_week - %s", self.cadence_week)
        logger.info("Since date (based on feature durations) - %s", str(self.since_date))
        logger.info("Required number of dates - %d", len(self.required_dates))
        logger.info("Required fis_weeks - %d - %s to %s", len(self.required_fis_weeks),
                    min(self.required_fis_weeks), max(self.required_fis_weeks))
        if self.completed_fis_weeks:
            logger.info("Completed fis_weeks - %d - %s to %s", len(self.completed_fis_weeks),
                        min(self.completed_fis_weeks), max(self.completed_fis_weeks))
        else:
            logger.info("Completed fis_weeks - %d", len(self.completed_fis_weeks))
        self.__run_epoch = int(time.time())
        if not self.create_log_tab():
            logger.error("log table not found/created - %s", self._log_tab)
            return False
        return True

    def post_run(self):
        """
        POST RUN SECTION
        :return: boolean: True/False
        """
        logger.info("#### POST RUN SECTION ####")
        # Clean log table, weed out unwanted section & remove old run_ids
        log_df = self.sqlContext.table(self._log_tab)
        e_time = int(time.time()) + (24 * 60 * 60)  # current timestamp + 1 day
        b_time = int(time.time()) - (30 * 24 * 60 * 60)  # removing rows belonging to last month
        log_df = log_df.filter((log_df.section.isin("aggregation", "merge")) &
                               (log_df.run_epoch.between(b_time, e_time)) &
                               (log_df.stmt_type == "dml - insert"))
        self.write_to_log(log_df, overwrite=True)
        return True

    def denormalization_section(self):
        """
        DENORMALIZATION SECTION
        Calculate any missing fis week in Purchase entity/table and kick off spark job to fill in
        missing data in Purchase entity/table
        :return: purchase_res: list(): list of Denormalization_res_tuple
        """
        logger.info("#### DENORMALIZATION SECTION ####")
        purchase_tab = self.config["SSEHiveWorkdb"] + "." + self.config["SSEHivePurchaseTab"]
        # Drop denorm table if clean run
        if self._clean_run:
            logger.info("Dropping denorm table %s", purchase_tab)
            drop_ddl = "DROP TABLE IF EXISTS " + purchase_tab
            drop_res = self.execute_sql(Statement_tuple(feature_name="purchase_tab",
                                                        tab_type="table", tab_name=purchase_tab,
                                                        stmt_type="ddl - drop", sql_stmt=drop_ddl,
                                                        log=False, section="denormalization",
                                                        wave=None))
            if not drop_res:
                logger.error("Error occurred while dropping denorm table %s", purchase_tab)
                return [Denormalization_res_tuple(date_id="No processing", result=False,
                                                  time_taken=0)]
        # Check for any structural change in denrom table (purchase_fct)
        if self.purchases.table_structural_change_flag:
            logger.info("Structural change in denorm table %s, table will be refreshed",
                        purchase_tab)
        denormalization_res = [Denormalization_res_tuple(date_id="No processing", result=True,
                                                         time_taken=0)]
        # Delete last 14 days denorm so that these can be refreshed, based on refresh flag value
        if self._refresh_denorm:
            logger.info("Dropping partition from denrom/purchase table - %d days - %s to %s",
                        len(self.refresh_dates),
                        str(min(self.refresh_dates, key=lambda x: x.date_id)),
                        str(max(self.refresh_dates, key=lambda x: x.date_id)))
            for item in self.refresh_dates:
                self.purchases.del_partition(fis_week_id=item.fis_week_id, date_id=item.date_id)
        # Check if data is available for required dates in Purchases tables
        logger.debug("Purchase table partitions - %s", str(self.purchases.get_partition_info()))
        purchase_dates = set([item[1] for item in self.purchases.get_partition_info()])
        not_in_dates = [item.date_id for item in self.required_dates
                        if item.date_id not in purchase_dates]
        logger.info("Creating purchases for missing dates - %d - %s", len(not_in_dates),
                    str(not_in_dates))
        # Remove holiday dates
        if "stores_closed_flag" in self._dates_df.columns:
            holidays_from_date_df = self._dates_df.filter(self._dates_df.stores_closed_flag).select("date_id").collect()
            holidays_from_date_df = set([(item["date_id"]).strftime("%Y-%m-%d") for item in holidays_from_date_df])
            missing_dt = [item for item in not_in_dates if (item not in self.__business_holidays) and (item not in holidays_from_date_df)]
        else:
            missing_dt = [item for item in not_in_dates if item not in self.__business_holidays]

        # Check if data is available for missing dates (missing fis_week) in Transactions table
        logger.info("Transaction table partitions - %s",
                    str(self.transactions.get_partition_info()))
        not_in_dates = [item for item in missing_dt
                        if item not in self.transactions.get_partition_info()]
        if not_in_dates:
            raise ValueError("Transaction table doesn't include all required dates, missing date(s)"
                             " - {0}".format(not_in_dates))
        logger.info("Input dates for missing purchases - %d - %s", len(missing_dt), str(missing_dt))
        if missing_dt:
            # Switch value of spark.sql.shuffle.partitions, customer_df would be repartitioned as
            # per value of shuffle.partitions
            tempd = self.config.get("SSEFeatureDenormWave", {})
            shuffle_part = tempd.get("ShufflePart", 200)
            workers = tempd.get("WorkerNum", 15)
            replica = tempd.get("cacheReplica", 3)
            old_shuffle_part = self.sqlContext.conf.get("spark.sql.shuffle.partitions", "200")
            self.sqlContext.conf.set("spark.sql.shuffle.partitions", "{0}".format(shuffle_part))
            logger.info("Starting DenormWave with %d ShufflePart (old=%s) & %d workers",
                        shuffle_part, old_shuffle_part, workers)
            logger.info("Caching customers df")
            # Caching customer df, will help in joins while creating purchases
            self.customers_df = self.customers_df.repartition(shuffle_part, "Customer"). \
                sortWithinPartitions("Customer"). \
                persist(storageLevel=StorageLevel(False, True, False, False, replica))
            customer_cnt = self.customers_df.count()
            logger.info("customers df count - %d", customer_cnt)
            # Caching products df, will help in joins while creating purchases
            logger.info("Caching products df")
            self.products_df = self.products_df.repartition(shuffle_part, "Product"). \
                sortWithinPartitions("Product"). \
                persist(storageLevel=StorageLevel(False, True, False, False, replica))
            product_cnt = self.products_df.count()
            logger.info("products df count - %d", product_cnt)
            # If product table small enough to fit in memory, it can be broadcasted instead of cache
            # pf.broadcast(self.products_df)
            # If we haven't used any entity df before, please do so now else below call will cause
            # each thread to trigger schema evaluation & uniqueness check on that entity
            with ThreadPoolExecutor(max_workers=workers) as executor:
                denormalization_res = executor.map(self.write_purchase, missing_dt)
            # TODO: Handle cleanup of failed date_id's if any
            denormalization_res = list(denormalization_res)
            logger.info("Removing customers df from cache")
            self.customers_df.unpersist()
            logger.info("Removing products df from cache")
            self.products_df.unpersist()
            # Restore value of spark.sql.shuffle.partitions
            self.sqlContext.conf.set("spark.sql.shuffle.partitions", old_shuffle_part)
        return denormalization_res

    def summary_section(self):
        """
        SUMMARY SECTION
        :return: (summary_res, summary_info_lst): tuple, summary_res - Exec_res_tuple and
        summary_info_lst - list of Summary_info_tuple
        """
        logger.info("#### SUMMARY SECTION ####")
        # Generate summary statements
        summary_info_lst = map(self.gen_summary_statements,
                               [item for item in self.features_specifications if item["is_active"]
                                and self.cadence_attribute.lower() == item["cadence_attribute"]
                                and item["summary_on"]])
        logger.info("Generated summary details are below.")
        for item in summary_info_lst:
            logger.info("Summary details - %s", str(item))
        # Drop summary tables if clean run else check for structural change in existing hive tables
        skip_tab, drop_tab = [], []
        if self._clean_run:
            logger.info("Dropping all summary tables [IF EXITS] - %d", len(summary_info_lst))
            for item in summary_info_lst:
                drop_tab.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                                tab_name=item.tab_name, stmt_type="ddl - drop",
                                                sql_stmt=item.ddl_drop, log=False,
                                                section="summary", wave=None))
        else:
            for item in summary_info_lst:
                db_name, tab_name = item.tab_name.split(".")
                col_info = [Col_tuple(col_name=col.colname.lower(),
                                      data_type=col.hive_datatype.lower().replace(" ", ""))
                            for col in item.sel_col] + item.part_col
                part_info = [col.col_name for col in item.part_col]
                if match_table_structure(sql_context=self.sqlContext, db_name=db_name,
                                         tab_name=tab_name, col_info=col_info, part_info=part_info):
                    skip_tab.append(item.tab_name)
                else:
                    drop_tab.append(Statement_tuple(feature_name=item.feature_name,
                                                    tab_type="table", tab_name=item.tab_name,
                                                    stmt_type="ddl - drop", sql_stmt=item.ddl_drop,
                                                    log=False, section="summary", wave=None))
            logger.info("Dropping missing or structurally changed summary tables - %d",
                        len(drop_tab))
        if drop_tab:
            drop_res = map(self.execute_sql, drop_tab)
            if not all(item.result for item in drop_res):
                logger.error("Not all summary ddl - drop executed successfully")
                return drop_res, summary_info_lst
        # Creating summary tables
        create_tab_cnt = len(summary_info_lst) - len(skip_tab)
        if create_tab_cnt != 0:
            logger.info("Creating missing summary tables [IF NOT EXITS] - %d", create_tab_cnt)
            create_res = map(self.execute_sql, [Statement_tuple(feature_name=item.feature_name,
                                                                tab_type="table",
                                                                tab_name=item.tab_name,
                                                                stmt_type="ddl - create",
                                                                sql_stmt=item.ddl_create, log=False,
                                                                section="summary", wave=None)
                                                for item in summary_info_lst
                                                if item.tab_name not in skip_tab])
            if not all(item.result for item in create_res):
                logger.error("Not all summary ddl - create executed successfully")
                return create_res, summary_info_lst
        # Delete last 14 days (corresponding fis_weeks) summary so that these can be refreshed,
        # based on refresh flag value
        if self._refresh_summary:
            drop_fis_weeks = list(set([item.fis_week_id for item in self.refresh_dates]))
            logger.info("Dropping partition from summary tables - %d weeks - %s to %s",
                        len(drop_fis_weeks), str(min(drop_fis_weeks)), str(max(drop_fis_weeks)))
            for item in summary_info_lst:
                logger.info("Deleting partition from summary table %s - %d weeks", item.tab_name,
                            len(drop_fis_weeks))
                for fis_week in drop_fis_weeks:
                    self.del_partition(item.tab_name, fis_week_id=fis_week)
        # Check for already populated summaries & skip them.
        seq_run, par_run = [], []
        for item in summary_info_lst:
            summary_fis_weeks = self.get_partition_info(tab_name=item.tab_name)
            logger.info("fis weeks in %s - %s", item.tab_name, str(summary_fis_weeks))
            item_missing_weeks = [week for week in self.completed_fis_weeks
                                  if week not in summary_fis_weeks]
            logger.info("Missing fis weeks in %s - %d - %s", item.tab_name, len(item_missing_weeks),
                        str(item_missing_weeks))
            for week in item_missing_weeks:
                if item.run_mode.lower() == "parallel":
                    par_run.append(
                        Statement_tuple(feature_name=deepcopy(item.feature_name),
                                        tab_type="table",
                                        tab_name=deepcopy(item.tab_name) + " - " + week,
                                        stmt_type="dml - insert",
                                        sql_stmt=deepcopy(item.dml).format(summary_week=week),
                                        log=False, section="summary", wave=deepcopy(item.wave)))
                else:
                    seq_run.append(
                        Statement_tuple(feature_name=deepcopy(item.feature_name),
                                        tab_type="table",
                                        tab_name=deepcopy(item.tab_name) + " - " + week,
                                        stmt_type="dml - insert",
                                        sql_stmt=deepcopy(item.dml).format(summary_week=week),
                                        log=False, section="summary", wave=deepcopy(item.wave)))
        logger.info("Total summaries to run in sequential mode - %d", len(seq_run))
        logger.info("Total summaries to run in parallel mode - %d", len(par_run))
        # Run missing summaries
        summary_res = [Exec_res_tuple(feature_name=None, tab_name="No processing", result=True,
                                      time_taken=0, log=False, section="summary")]
        if seq_run:
            pass  # We know in summaries everything will run in parallel
        if par_run:
            summary_res = []
            logger.info("Starting parallel run of summaries")
            par_run = sorted(par_run, key=lambda x: x.wave)
            for key, group in groupby(par_run, key=lambda x: x.wave):
                run_lst = list(group)
                # Switch value of spark.sql.shuffle.partitions
                tempd = self.config.get("SSEFeatureSummaryWave{0}".format(key), {})
                shuffle_part = tempd.get("ShufflePart", 200)
                workers = tempd.get("WorkerNum", 3)
                old_shuffle_part = self.sqlContext.conf.get("spark.sql.shuffle.partitions", "200")
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", "{0}".format(shuffle_part))
                logger.info("Parallel run of summary wave %d with %d tables, %d ShufflePart "
                            "(old=%s) & %d workers", key, len(run_lst), shuffle_part,
                            old_shuffle_part, workers)
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    summary_res_par = executor.map(self.execute_sql, run_lst)
                # TODO: handle error/failure & cleanup if any
                summary_res = summary_res + list(summary_res_par)
                # Restore value of spark.sql.shuffle.partitions
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", old_shuffle_part)
        return summary_res, summary_info_lst

    @staticmethod
    def is_duration(durations, dur):
        """
        this function is used in aggregation section
        :param durations: list of time durations (most probably fis week duration)
        :param dur: time duration
        :return: True/False: Boolean
        """
        if dur in durations:
            return True
        return False

    def aggregate_section(self):
        """
        AGGREGATION SECTION
        :return: (aggregation_res, r_agg_info_lst): tuple, aggregation_res - Exec_res_tuple and
        r_agg_info_lst - Aggregate_info_tuple
        """
        # TODO: Introduce logic to stop execution of agg if summary are missing above threshold
        logger.info("#### AGGREGATION SECTION ####")
        # Register supplementary table required to derive dimension attribute
        res_register, dim_tab_lst = self.register_supplementary_tables()
        if not res_register:
            logger.error("Not all supplementary table created successfully")
        # Expand feature duration list based on duration specified
        feature_duration_lst = [(dur, deepcopy(item)) for item in self.features_specifications
                                if item["is_active"] and self.cadence_attribute.lower() ==
                                item["cadence_attribute"] for dur in self.durations
                                if self.is_duration(item["durations"], dur)]
        # Generate aggregation statements
        agg_info_lst = map(self.gen_aggregate_statements, feature_duration_lst)
        logger.info("Generated aggregation details are below.")
        for item in agg_info_lst:
            logger.info("Aggregation details - %s", str(item))
        # Drop aggregation tables if clean run or non-paar features else check for structural change
        # in existing hive tables
        populated_agg_tab, skip_tab, drop_tab = [], [], []
        if self._clean_run:
            logger.info("Dropping all aggregation tables - %d", len(agg_info_lst))
            for item in agg_info_lst:
                drop_tab.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                                tab_name=item.tab_name, stmt_type="ddl - drop",
                                                sql_stmt=item.ddl_drop, log=False,
                                                section="aggregation", wave=None))
        else:
            for item in agg_info_lst:
                db_name, tab_name = item.tab_name.split(".")
                col_info = [Col_tuple(col_name=col.colname.lower(),
                                      data_type=col.hive_datatype.lower().replace(" ", ""))
                            for col in item.sel_col] + item.part_col
                part_info = [col.col_name for col in item.part_col]
                if match_table_structure(sql_context=self.sqlContext, db_name=db_name,
                                         tab_name=tab_name, col_info=col_info, part_info=part_info):
                    skip_tab.append(item.tab_name)
                else:
                    drop_tab.append(Statement_tuple(feature_name=item.feature_name,
                                                    tab_type="table", tab_name=item.tab_name,
                                                    stmt_type="ddl - drop", sql_stmt=item.ddl_drop,
                                                    log=False, section="aggregation", wave=None))
            logger.info("Dropping missing or structurally changed aggregation tables - %d",
                        len(drop_tab))
        # Check for already populated aggregation tables in database and log table, for these table
        # skip compute/population sql/job
        if skip_tab:
            dbname = self.config["SSEHivePobdb"] if self.__paar_flag \
                else self.config["SSEHiveWorkdb"]
            db_tab_lst = [item.database.lower() + "." + item.name.lower() for item in self.sqlContext.catalog.listTables(dbName=dbname) if item.tableType == "MANAGED"]

            agg_tab_lst = [item.tab_name.lower() for item in agg_info_lst
                           if item.tab_name.lower() in db_tab_lst and item.tab_name in skip_tab]
            if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
                part_val = self.cadence.isoformat()
            else:
                part_val = self.cadence_week
            agg_tab_set = [item for item in agg_tab_lst
                           if part_val in self.get_partition_info(item)]
            # Read table list from log table for qualifying run_id
            log_tab_df = self.sqlContext.table(self._log_tab)
            filter_cond = (log_tab_df["cadence"] == self.cadence.isoformat()) & \
                          (log_tab_df["cadence_attribute"] == self.cadence_attribute) & \
                          (log_tab_df["section"] == "aggregation") & \
                          (log_tab_df["stmt_type"] == "dml - insert")
            log_tab_lst = log_tab_df.filter(filter_cond).select("tab_name").distinct().collect()
            log_tab_set = set([item["tab_name"].lower() for item in log_tab_lst])
            populated_tab_set = log_tab_set.intersection(agg_tab_set)
            populated_agg_tab = [item for item in skip_tab if item.lower() in populated_tab_set]
            logger.info("Skipping aggregation section for %d tables - %s", len(populated_agg_tab),
                        str(populated_agg_tab))
        # For non paar run, drop aggregation tables which aren't already populated, so that we have
        # only current run partition in aggregation table at any given moment
        if not self.__paar_flag:
            for item in agg_info_lst:
                if item.tab_name.lower() not in populated_agg_tab:
                    drop_tab.append(Statement_tuple(feature_name=item.feature_name,
                                                    tab_type="table", tab_name=item.tab_name,
                                                    stmt_type="ddl - drop", sql_stmt=item.ddl_drop,
                                                    log=False, section="aggregation", wave=None))
                    if item.tab_name in skip_tab:
                        skip_tab.remove(item.tab_name)
        if drop_tab:
            drop_res = map(self.execute_sql, drop_tab)
            if not all(item.result for item in drop_res):
                logger.error("Not all aggregation ddl - drop executed successfully")
                return drop_res, populated_agg_tab, agg_info_lst
        if len(agg_info_lst) - len(populated_agg_tab) == 0:
            logger.info("Nothing to process in aggregation section")
            aggregation_res = [Exec_res_tuple(feature_name=None, tab_name="No processing",
                                              result=True, time_taken=0, log=False,
                                              section="aggregation")]
            return aggregation_res, populated_agg_tab, agg_info_lst
        # Creating aggregation tables
        create_tab_cnt = len(agg_info_lst) - len(skip_tab)
        if create_tab_cnt != 0:
            logger.info("Creating aggregate tables [IF NOT EXITS] - %d", create_tab_cnt)
            create_res = map(self.execute_sql, [Statement_tuple(feature_name=item.feature_name,
                                                                tab_type="table",
                                                                tab_name=item.tab_name,
                                                                stmt_type="ddl - create",
                                                                sql_stmt=item.ddl_create, log=False,
                                                                section="aggregation", wave=None)
                                                for item in agg_info_lst
                                                if item.tab_name not in skip_tab])
            if not all(item.result for item in create_res):
                logger.error("Not all aggregate ddl - create executed successfully")
                return create_res, populated_agg_tab, agg_info_lst
        seq_run, par_run = [], []  # element format - Statement_tuple
        for item in agg_info_lst:
            if item.tab_name in populated_agg_tab:
                continue
            # Based on time duration get list of completed and incomplete weeks/dates and use that
            # info to populate values for summary weeks (completed) and incomplete_dates in where
            # clause of aggregation sqls
            end_dt = self.cadence
            start_dt = self.cadence - td(days=(item.duration[1] * 7) - 1)
            dt_range = sorted([item_dt for item_dt in self.required_dates
                               if start_dt.isoformat() <= item_dt.date_id <= end_dt.isoformat()],
                              key=lambda x: x.fis_week_id)
            completed_weeks, incomplete_dates = [], []
            for key, group in groupby(dt_range, key=lambda x: x.fis_week_id):
                date_range = list(group)
                if len(date_range) == 7:
                    completed_weeks.append(key)
                else:
                    for dates in date_range:
                        incomplete_dates.append(dates.date_id)
            completed_weeks = ",".join(["'{0}'".format(week) for week in completed_weeks]) \
                if completed_weeks else "'no_partition'"
            incomplete_dates = ",".join(["'{0}'".format(dates) for dates in incomplete_dates]) \
                if incomplete_dates else "'no_partition'"
            denorm_dates = ",".join(["'{0}'".format(dates.date_id) for dates in dt_range]) \
                if dt_range else "'no_partition'"
            dml = item.dml.format(summary_weeks=completed_weeks, incomplete_dates=incomplete_dates,
                                  denorm_dates=denorm_dates)
            if item.run_mode.lower() == "parallel":
                par_run.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                               tab_name=item.tab_name, stmt_type="dml - insert",
                                               sql_stmt=dml, log=True, section="aggregation",
                                               wave=item.wave))
            else:
                seq_run.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                               tab_name=item.tab_name, stmt_type="dml - insert",
                                               sql_stmt=dml, log=True, section="aggregation",
                                               wave=item.wave))
        logger.info("Total aggregation to run in sequential mode - %d", len(seq_run))
        logger.info("Total aggregation to run in parallel mode - %d", len(par_run))
        # Run aggregation
        aggregation_res_seq = [Exec_res_tuple(feature_name=None, tab_name="No processing",
                                              result=True, time_taken=0, log=False,
                                              section="aggregation")]
        aggregation_res = [Exec_res_tuple(feature_name=None, tab_name="No processing", result=True,
                                          time_taken=0, log=False, section="aggregation")]
        if seq_run:
            aggregation_res = []
            logger.info("Starting sequential run of aggregation")
            seq_run = sorted(seq_run, key=lambda x: x.wave)
            for key, group in groupby(seq_run, key=lambda x: x.wave):
                run_lst = list(group)
                # Switch value of spark.sql.shuffle.partitions
                tempd = self.config.get("SSEFeatureAggregationWave{0}".format(key), {})
                shuffle_part = tempd.get("ShufflePart", 200)
                workers = tempd.get("WorkerNum", 1)
                old_shuffle_part = self.sqlContext.conf.get("spark.sql.shuffle.partitions", "200")
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", "{0}".format(shuffle_part))
                logger.info("Sequential run of aggregation wave %d with %d tables,%d ShufflePart "
                            "(old=%s) & %d workers", key, len(run_lst), shuffle_part,
                            old_shuffle_part, workers)
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    aggregation_res_seq = executor.map(self.execute_sql, run_lst)
                # TODO: handle error/failure & clean-up if any
                aggregation_res = aggregation_res + list(aggregation_res_seq)
                # Restore value of spark.sql.shuffle.partitions
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", old_shuffle_part)
        if par_run and all(item.result for item in aggregation_res_seq):
            if len(aggregation_res) == 1 and aggregation_res[0].tab_name == "No processing":
                aggregation_res = []
            logger.info("Starting parallel run of aggregation")
            par_run = sorted(par_run, key=lambda x: x.wave)
            for key, group in groupby(par_run, key=lambda x: x.wave):
                run_lst = list(group)
                # Switch value of spark.sql.shuffle.partitions
                tempd = self.config.get("SSEFeatureAggregationWave{0}".format(key), {})
                shuffle_part = tempd.get("ShufflePart", 200)
                workers = tempd.get("WorkerNum", 2)
                old_shuffle_part = self.sqlContext.conf.get("spark.sql.shuffle.partitions", "200")
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", "{0}".format(shuffle_part))
                logger.info("Parallel run of aggregation wave %d with %d tables,%d ShufflePart "
                            "(old=%s) & %d workers", key, len(run_lst), shuffle_part,
                            old_shuffle_part, workers)
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    aggregation_res_par = executor.map(self.execute_sql, run_lst)
                # TODO: handle error/failure & clean-up if any
                aggregation_res = aggregation_res + list(aggregation_res_par)
                # Restore value of spark.sql.shuffle.partitions
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", old_shuffle_part)
        else:
            logger.error("sequential run of aggregation was unsuccessful")
        # Delete supplementary table required to derive dimension attribute
        res_delete = self.delete_supplementary_tables(dim_tab_lst)
        if not res_delete:
            logger.error("Not all supplementary table deleted successfully")
        return aggregation_res, populated_agg_tab, agg_info_lst

    def merge_section(self, agg_info_lst):
        """
        MERGE SECTION
        :param agg_info_lst: list(): list of Aggregate_info_tuple
        :return: (merge_res, r_merge_info_lst): tuple, merge_res - Exec_res_tuple and
        r_merge_info_lst - list of Merge_info_tuple
        """
        logger.info("#### MERGE SECTION ####")
        merge_info_lst = []
        agg_info_lst = sorted([item for item in agg_info_lst if item.feature_name.lower() !=
                               self.config["SSEFeatureDistinctTab"].lower()],
                              key=lambda x: x.feature_name)
        for key, group in groupby(agg_info_lst, key=lambda x: x.feature_name):
            agg_tabs, durations, sel_col, group_info = [], [], set(), []
            for item in group:
                durations.append(item.duration)
                agg_tabs.append((item.tab_name, item.duration))
                for col in item.sel_col:
                    sel_col.add(col)
                group_info = item.group_info
            # Sort list (in desc) as per duration, remove duplicate column from sel_col list
            # this sorting will decide order of table going into left join, so if we have duration
            # whose starting week isn't common, then we will have to revisit this i.e (4, 52)
            # current assumption is duration will have common starting point like (1,1), (1,4)
            durations.sort(key=lambda x: int(x[1]), reverse=True)
            agg_tabs.sort(key=lambda x: int(x[1][1]), reverse=True)
            sel_col = list(sel_col)
            sel_col.sort(key=lambda x: int(x.col_num * 1000 + sum(
                [int(match_digit) for match_digit in re.findall("\d+", x.colname)])), reverse=False)
            temp = Merge_info_tuple(feature_name=key, tab_name=None, durations=durations,
                                    agg_tabs=agg_tabs, run_mode=None, ddl_drop=None,
                                    ddl_create=None, dml=None, group_info=group_info,
                                    sel_col=sel_col, part_col=None, wave=None)
            merge_info_lst.append(temp)
        # Generate merge statements
        merge_info_lst = map(self.gen_merge_statements, merge_info_lst)
        logger.info("Generated merge details are below.")
        for item in merge_info_lst:
            logger.info("Merge details - %s", str(item))
        # Drop aggregation tables if clean run else check for structural change in existing tables
        populated_merge_tab, skip_tab, drop_tab = [], [], []
        if self._clean_run:
            logger.info("Dropping all merge tables - %d", len(merge_info_lst))
            for item in merge_info_lst:
                drop_tab.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                                tab_name=item.tab_name, stmt_type="ddl - drop",
                                                sql_stmt=item.ddl_drop, log=False, section="merge",
                                                wave=None))
        else:
            for item in merge_info_lst:
                db_name, tab_name = item.tab_name.split(".")
                col_info = [Col_tuple(col_name=col.colname.lower(),
                                      data_type=col.hive_datatype.lower().replace(" ", ""))
                            for col in item.sel_col] + item.part_col
                part_info = [col.col_name for col in item.part_col]
                if match_table_structure(sql_context=self.sqlContext, db_name=db_name,
                                         tab_name=tab_name, col_info=col_info, part_info=part_info):
                    skip_tab.append(item.tab_name)
                else:
                    drop_tab.append(Statement_tuple(feature_name=item.feature_name,
                                                    tab_type="table", tab_name=item.tab_name,
                                                    stmt_type="ddl - drop", sql_stmt=item.ddl_drop,
                                                    log=False, section="merge", wave=None))
            logger.info("Dropping missing or structurally changed merge tables - %d", len(drop_tab))
        # Check for already populated aggregation tables in database and log table, for these table
        # skip compute/population sql/job
        if skip_tab:
            dbname = self.config["SSEHivePobdb"]
            db_tab_lst = [item.database.lower() + "." + item.name.lower() for item in self.sqlContext.catalog.listTables(dbName=dbname) if item.tableType == "MANAGED"]
            merge_tab_lst = [item.tab_name.lower() for item in merge_info_lst
                             if item.tab_name.lower() in db_tab_lst and item.tab_name in skip_tab]
            if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
                part_val = self.cadence.isoformat()
            else:
                part_val = self.cadence_week
            merge_tab_set = [item for item in merge_tab_lst
                             if part_val in self.get_partition_info(item)]
            # Read table list from log table for qualifying run_id
            log_tab_df = self.sqlContext.table(self._log_tab)
            filter_cond = (log_tab_df["cadence"] == self.cadence.isoformat()) & \
                          (log_tab_df["cadence_attribute"] == self.cadence_attribute) & \
                          (log_tab_df["section"] == "merge") & \
                          (log_tab_df["stmt_type"] == "dml - insert")
            log_tab_lst = log_tab_df.filter(filter_cond).select("tab_name").distinct().collect()
            log_tab_set = set([item["tab_name"].lower() for item in log_tab_lst])
            populated_tab_set = log_tab_set.intersection(merge_tab_set)
            populated_merge_tab = [item for item in skip_tab if item.lower() in populated_tab_set]
            logger.info("Skipping merge section for %d tables - %s", len(populated_merge_tab),
                        str(populated_merge_tab))
        if drop_tab:
            drop_res = map(self.execute_sql, drop_tab)
            if not all(item.result for item in drop_res):
                logger.error("Not all merge ddl - drop executed successfully")
                return drop_res, populated_merge_tab, merge_info_lst
        if len(merge_info_lst) - len(populated_merge_tab) == 0:
            logger.info("Nothing to process in merge section")
            merge_res = [Exec_res_tuple(feature_name=None, tab_name="No processing", result=True,
                                        time_taken=0, log=False, section="merge")]
            return merge_res, populated_merge_tab, merge_info_lst
        pass
        # Creating aggregation tables
        create_tab_cnt = len(merge_info_lst) - len(skip_tab)
        if create_tab_cnt != 0:
            logger.info("Creating merge tables [IF NOT EXITS] - %d", create_tab_cnt)
            create_res = map(self.execute_sql, [Statement_tuple(feature_name=item.feature_name,
                                                                tab_type="table",
                                                                tab_name=item.tab_name,
                                                                stmt_type="ddl - create",
                                                                sql_stmt=item.ddl_create, log=False,
                                                                section="merge", wave=None)
                                                for item in merge_info_lst
                                                if item.tab_name not in skip_tab])
            if not all(item.result for item in create_res):
                logger.error("Not all merge ddl - create executed successfully")
                return create_res, populated_merge_tab, merge_info_lst
        seq_run, par_run = [], []  # element format - Statement_tuple
        for item in merge_info_lst:
            if item.tab_name in populated_merge_tab:
                continue
            if item.run_mode.lower() == "parallel":
                par_run.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                               tab_name=item.tab_name, stmt_type="dml - insert",
                                               sql_stmt=item.dml, log=True, section="merge",
                                               wave=item.wave))
            else:
                seq_run.append(Statement_tuple(feature_name=item.feature_name, tab_type="table",
                                               tab_name=item.tab_name, stmt_type="dml - insert",
                                               sql_stmt=item.dml, log=True, section="merge",
                                               wave=item.wave))
        logger.info("Total merge to run in sequential mode - %d", len(seq_run))
        logger.info("Total merge to run in parallel mode - %d", len(par_run))
        # Run merge
        merge_res = [Exec_res_tuple(feature_name=None, tab_name="No processing", result=True,
                                    time_taken=0, log=False, section="merge")]
        if seq_run:
            pass  # We know in merge everything will run in parallel
        if par_run:
            merge_res = []
            logger.info("Starting parallel run of merge")
            par_run = sorted(par_run, key=lambda x: x.wave)
            for key, group in groupby(par_run, key=lambda x: x.wave):
                run_lst = list(group)
                # Switch value of spark.sql.shuffle.partitions
                tempd = self.config.get("SSEFeatureMergeWave{0}".format(key), {})
                shuffle_part = tempd.get("ShufflePart", 200)
                workers = tempd.get("WorkerNum", 1)
                old_shuffle_part = self.sqlContext.conf.get("spark.sql.shuffle.partitions", "200")
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", "{0}".format(shuffle_part))
                logger.info("Parallel run of merge wave %d with %d tables,%d ShufflePart (old=%s) "
                            "& %d workers", key, len(run_lst), shuffle_part,
                            old_shuffle_part, workers)
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    merge_res_par = executor.map(self.execute_sql, run_lst)
                # TODO: handle error/failure & clean-up if any
                merge_res = merge_res + list(merge_res_par)
                # Restore value of spark.sql.shuffle.partitions
                self.sqlContext.conf.set("spark.sql.shuffle.partitions", old_shuffle_part)
        return merge_res, populated_merge_tab, merge_info_lst

    def gen_view_statements(self, merge_info):
        """
        Generate required details for views of features like sql's (view ddls etc)
        :param merge_info: Merge_info_tuple
        :return: temp: View_info_tuple
        """
        features_spec = [item for item in self.features_specifications
                         if item["name"].lower() == merge_info.feature_name.lower()
                         and self.cadence_attribute.lower() == item["cadence_attribute"]][0]
        dim_time_identifier, other_dim_identifier = [], []
        if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
            cadence_col, cadence_val, view_postfix = "cadence_day", self.cadence.isoformat(), \
                                                     self.cadence.strftime("%Y%m%d")
        else:
            cadence_col, cadence_val, view_postfix = "cadence_week", self.cadence_week, \
                                                     self.cadence_week
        # Generate select expression for dim attributes
        sel_col = []  # element format - Sel_col_tuple
        i = (i for i in xrange(1, 1000))
        sel_col.append(Sel_col_tuple(colname="cadenceattribute",
                                     select_expr="'{expr}' AS {col}".format(
                                         expr=self.cadence_attribute, col="cadenceattribute"),
                                     hive_datatype="string", col_num=i.next()))
        sel_col.append(Sel_col_tuple(colname="cadence",
                                     select_expr="'{expr}' AS {col}".format(expr=cadence_val,
                                                                          col="cadence"),
                                     hive_datatype="string", col_num=i.next()))
        dim_time_identifier.append("cadenceattribute{0}".format(self.cadence_attribute))
        dim_grain = sorted(self.dimension_grain)
        for item in dim_grain:
            dim_attr = features_spec["dimension_attribute_grain"][item + "Attribute"]
            if isinstance(dim_attr, list):
                if item in dim_attr:
                    sel_col.append(Sel_col_tuple(colname=item + "attribute",
                                                 select_expr="'{expr}' AS {col}".format(
                                                     expr=item, col=item + "attribute"),
                                                 hive_datatype="string", col_num=i.next()))
                    sel_col.append(Sel_col_tuple(colname=item,
                                                 select_expr="{expr} AS {col}".format(expr=item,
                                                                                      col=item),
                                                 hive_datatype="string", col_num=i.next()))
                    other_dim_identifier.append(item + item)
            else:
                sel_col.append(Sel_col_tuple(colname=item + "attribute",
                                             select_expr="'{expr}' AS {col}".format(
                                                 expr=dim_attr, col=item + "attribute"),
                                             hive_datatype="string", col_num=i.next()))
                sel_col.append(Sel_col_tuple(colname=item,
                                             select_expr="{expr} AS {col}".format(
                                                 expr=dim_attr if dim_attr.lower() != "all"
                                                 else item, col=item),
                                             hive_datatype="string", col_num=i.next()))
                other_dim_identifier.append(item + dim_attr)
        # Generate select expression for remaining feature columns (other then dim attributes/cols)
        temp_lst = [item.select_expr.split("AS")[0].strip() for item in sel_col]
        col_already_present = [item.lower() for item in temp_lst
                               if not (item.startswith("'") and item.endswith("'"))]
        for item in merge_info.sel_col:
            if item.colname.lower() not in col_already_present:
                col_name = "_".join(other_dim_identifier) + "_" + item.colname
                sel_col.append(Sel_col_tuple(colname=col_name,
                                             select_expr="{expr} AS {col}".format(expr=item.colname,
                                                                                  col=col_name),
                                             hive_datatype=item.hive_datatype, col_num=i.next()))
        # Generate create statement
        # view header
        view_name = self.config["SSEHivePobdb"] + ".v_" + \
                    "_".join(dim_time_identifier + other_dim_identifier) + "_" + view_postfix
        current_view_name = self.config["SSEHivePobdb"] + ".v_" + \
                            "_".join(dim_time_identifier + other_dim_identifier) + "_current"
        create_header = "CREATE VIEW IF NOT EXISTS " + view_name + " AS "
        current_create_header = "CREATE VIEW IF NOT EXISTS " + current_view_name + " AS "
        # Projection/Select clause
        ins_projection = " SELECT " + ",".join([item.select_expr for item in sel_col])
        # From clause
        ins_from = " FROM " + merge_info.tab_name
        # Where clause
        where_condition = " WHERE {0} = '{1}'".format(cadence_col, cadence_val)
        ddl_create = create_header + ins_projection + ins_from + where_condition
        current_ddl_create = current_create_header + " SELECT * FROM " + view_name
        # Generate drop statement
        ddl_drop = "DROP VIEW IF EXISTS " + view_name
        current_ddl_drop = "DROP VIEW IF EXISTS " + current_view_name
        temp = View_info_tuple(feature_name=merge_info.feature_name, tab_name=merge_info.tab_name,
                               view_name=view_name, current_view_name=current_view_name,
                               sel_col=sel_col, ddl_drop=ddl_drop, ddl_create=ddl_create,
                               current_ddl_drop=current_ddl_drop,
                               current_ddl_create=current_ddl_create)
        return temp

    def view_creation_section(self, merge_info_lst):
        """
        VIEW CREATION SECTION
        :param merge_info_lst: list(): list of Merge_info_tuple
        :return: (res, view_info_lst): tuple: res - True/False,
        view_info_lst - list of View_info_tuple
        """
        logger.info("#### VIEW CREATION SECTION ####")
        # Generate view statements
        view_info_lst = map(self.gen_view_statements, merge_info_lst)
        logger.info("Generated view details are below.")
        for item in view_info_lst:
            logger.info("View details - %s", str(item))
        # Separate base view & current view, as current view are based on base views and should be
        # created after in hive after base views and dropped before base views
        # element format - Statement_tuple
        base_drop, base_create, current_drop, current_create = [], [], [], []
        for item in view_info_lst:
            base_drop.append(Statement_tuple(feature_name=item.feature_name, tab_type="view",
                                             tab_name=item.view_name, stmt_type="ddl - drop",
                                             sql_stmt=item.ddl_drop, log=False,
                                             section="view", wave=None))
            base_create.append(Statement_tuple(feature_name=item.feature_name, tab_type="view",
                                               tab_name=item.view_name, stmt_type="ddl - create",
                                               sql_stmt=item.ddl_create, log=False,
                                               section="view", wave=None))
            # Create current view only if cadence_week/cadence_day is highest/latest, to ensure that
            # current view always point to most latest cadence_week features
            if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
                part_val = self.cadence.isoformat()
            else:
                part_val = self.cadence_week
            if part_val >= max(self.get_partition_info(tab_name=item.tab_name)):
                current_drop.append(Statement_tuple(feature_name=item.feature_name, tab_type="view",
                                                    tab_name=item.view_name, stmt_type="ddl - drop",
                                                    sql_stmt=item.current_ddl_drop, log=False,
                                                    section="view", wave=None))
                current_create.append(Statement_tuple(feature_name=item.feature_name,
                                                      tab_type="view", tab_name=item.view_name,
                                                      stmt_type="ddl - create",
                                                      sql_stmt=item.current_ddl_create, log=False,
                                                      section="view", wave=None))
        # Drop current views
        logger.info("Dropping current views [IF EXITS] - %d", len(current_drop))
        view_ddl_res = map(self.execute_sql, current_drop)
        if not all(item.result for item in view_ddl_res):
            logger.error("Not all current views ddl - drop executed successfully")
            return False, view_info_lst
        # Drop base views
        logger.info("Dropping base views [IF EXITS] - %d", len(base_drop))
        view_ddl_res = map(self.execute_sql, base_drop)
        if not all(item.result for item in view_ddl_res):
            logger.error("Not all base views ddl - drop executed successfully")
            return False, view_info_lst
        # Create base views
        logger.info("Creating base views [IF NOT EXITS] - %d", len(base_create))
        view_ddl_res = map(self.execute_sql, base_create)
        if not all(item.result for item in view_ddl_res):
            logger.error("Not all base views ddl - create executed successfully")
            return False, view_info_lst
        # Create current views
        logger.info("Creating current views [IF NOT EXITS] - %d", len(current_create))
        view_ddl_res = map(self.execute_sql, current_create)
        if not all(item.result for item in view_ddl_res):
            logger.error("Not all current views ddl - create executed successfully")
            return False, view_info_lst
        return True, view_info_lst

    def data_purge_section(self):
        """
        DATA PURGE SECTION
        :return: boolean: True/False
        """
        logger.info("#### DATA PURGE SECTION ####")
        if self.config.get("SSEFeatureDataPurge", "false").lower() == "false":
            logger.info("Data purge is OFF, no data will be deleted")
            return True
        work_db = self.config["SSEHiveWorkdb"]
        pob_db = self.config["SSEHivePobdb"]
        agg_db = pob_db if self.__paar_flag else work_db
        postfix = "_daily" if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY else ""
        summary_tab, agg_tabs, merge_tabs, views = [], [], [], []
        for item in self.features_specifications:
            if item["is_active"] and self.cadence_attribute.lower() == item["cadence_attribute"]:
                if item["summary_on"]:
                    summary_tab.append(item["name"] + "_summary")
                for dur in [dur for dur in self.durations if dur in item["durations"]]:
                    agg_tabs.append(item["name"] + postfix + "_{0}w{1}w".format(dur[0], dur[1]))
                if item["name"].lower() != self.config["SSEFeatureDistinctTab"].lower():
                    merge_tabs.append(item["name"] + postfix)
                    dim_identifier = ["cadenceattribute{0}".format(self.cadence_attribute)]
                    dim_grain = sorted(self.dimension_grain)
                    for dim in dim_grain:
                        dim_attr = item["dimension_attribute_grain"][dim + "Attribute"]
                        dim_identifier.append(dim + dim_attr)
                    view_name = "v_" + "_".join(dim_identifier)
                    views.append(view_name)
        # Calculate retention range for denorm/purchase & summary tables
        end_dt = self.current_date
        st_dt = end_dt - td(days=7 * self.config["SSEFeatureDataPurgeRetentionWeekNum"])
        retention_range = self.dates_df.filter(self.dates_df.date_id.between(st_dt, end_dt)). \
            select("fis_week_id").distinct().collect()
        retention_range = [str(row["fis_week_id"]) for row in retention_range]
        logger.info("Data retention range for denorm & summary tables - %d weeks - %s to  %s",
                    len(retention_range), min(retention_range), max(retention_range))
        # Get list of tables in work_db (summary & denorm tables) and agg_db (aggregation tables)
        work_db_tab_lst = [item.name.lower() for item in self.sqlContext.catalog.listTables(dbName=work_db) if item.tableType == "MANAGED"]
        agg_db_tab_lst = [item.name.lower() for item in self.sqlContext.catalog.listTables(dbName=agg_db) if item.tableType == "MANAGED"]

        # Apply data purging on denorm/purchase table
        if self.purchases.table_name.split(".")[1].lower() in work_db_tab_lst:
            # Get partition info of denorm/purchase table
            purchase_fis_weeks = set([item[0]
                                      for item in self.purchases.get_partition_info(refresh=True)])
            # Filter out partitions to be deleted/purged and delete them
            to_purge_purchase_fis_week = [week for week in purchase_fis_weeks
                                          if week not in retention_range]
            logger.info("Deleting partition from denorm table - %d weeks",
                        len(to_purge_purchase_fis_week))
            for fis_week in to_purge_purchase_fis_week:
                self.purchases.del_partition(fis_week_id=fis_week)
        # Apply data purging on summary tables
        for item in summary_tab:
            tab_name = work_db + "." + item
            # Get partition info of summary table, filter out partitions to be purged & delete them
            if item.lower() in work_db_tab_lst:
                summary_fis_week = self.get_partition_info(tab_name=tab_name)
                to_purge_summary_fis_week = [week for week in summary_fis_week
                                             if week not in retention_range]
                logger.info("Deleting partition from summary table %s - %d weeks", tab_name,
                            len(to_purge_summary_fis_week))
                for fis_week in to_purge_summary_fis_week:
                    self.del_partition(tab_name, fis_week_id=fis_week)
        # Calculate retention range for aggregation tables & published feature tables
        end_dt = self.current_date
        st_dt = end_dt - td(days=7 * self.config["SSEFeatureDataPurgePublishedRetentionWeekNum"])
        if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
            retention_range = self.dates_df.filter(self.dates_df.date_id.between(st_dt, end_dt)). \
                select("date_id").distinct().collect()
            retention_range = [row["date_id"] for row in retention_range]
        else:
            retention_range = self.dates_df.filter(self.dates_df.date_id.cast(pt.TimestampType()).between(st_dt, end_dt)).\
                select("fis_week_id").distinct().collect()
            retention_range = [str(row["fis_week_id"]) for row in retention_range]
        logger.info("Data retention range for published feature tables - %d weeks/days - %s to  %s",
                    len(retention_range), min(retention_range), max(retention_range))
        # Apply data purging on aggregation tables & published feature tables
        for tab in agg_tabs:
            tab_name = agg_db + "." + tab
            if tab.lower() in agg_db_tab_lst:
                agg_part_lst = self.get_partition_info(tab_name=tab_name)
                to_purge_agg_part_lst = [item for item in agg_part_lst
                                         if item not in retention_range]
                logger.info("Deleting partition from aggregation table %s - %d", tab_name,
                            len(to_purge_agg_part_lst))
                for item in to_purge_agg_part_lst:
                    if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
                        self.del_partition(tab_name, cadence_day=item)
                    else:
                        self.del_partition(tab_name, cadence_week=item)
        # Apply data purging on merge tables & view i.e published feature tables in non-paar run
        if not self.__paar_flag:
            merge_db_tab_lst = [item.name.lower() for item in self.sqlContext.catalog.listTables(dbName=pob_db) if item.tableType == "MANAGED"]
            for tab in merge_tabs:
                tab_name = pob_db + "." + tab
                if tab.lower() in merge_db_tab_lst:
                    merge_part_lst = self.get_partition_info(tab_name=tab_name)
                    to_purge_merge_part_lst = [item for item in merge_part_lst
                                               if item not in retention_range]
                    logger.info("Deleting partition from merge table %s - %d - %s", tab_name,
                                len(to_purge_merge_part_lst), str(to_purge_merge_part_lst))
                    for item in to_purge_merge_part_lst:
                        if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
                            self.del_partition(tab_name, cadence_day=item)
                        else:
                            self.del_partition(tab_name, cadence_week=item)
            if self.cadence_attribute.lower() in self.PROCESS_TYPE_DAILY:
                retention_range = ["".join(item.split("-")) for item in retention_range]
            for view in views:
                for item in merge_db_tab_lst:
                    if item.startswith(view.lower()) and not item.endswith("current") and \
                                    item.split("_")[-1] not in retention_range:
                        logger.info("Dropping view %s.%s", pob_db, item)
                        drop_stmt = "DROP VIEW IF EXISTS {0}.{1}".format(pob_db, item)
                        self.sqlContext.sql(drop_stmt)
        return True

    def generate_and_write_features(self, clean_run=None):
        """
        Call & execute all required section for creation of features
        :param clean_run: boolean: Argument clean_run (when True) activate clean slate run, i.e.
        process will remove all old data & tables related to pfg and provide refresh/clean run
        :return: boolean: True/False
        """
        # TODO: Introduce greater flexibility to restart process from last successful step
        st_time = time.time()
        # - PRE RUN SECTION -
        pre_res = self.pre_run(clean_run=clean_run)
        pre_msg = "succeeded" if pre_res else "failed"
        pre_time = time.time()
        logger.info("Pre run section executed in %d secs - %s", int(pre_time - st_time), pre_msg)
        if not pre_res:
            logger.error("Insufficient information or incomplete setup to run feature generator")
            raise Exception("Error in pre run section, please check log for more details")
        # - DENORMALIZATION SECTION -
        denormalization_res = self.denormalization_section()
        denormalization_section_res = all(item.result for item in denormalization_res)
        denormalization_msg = "succeeded" if denormalization_section_res else "failed"
        pe_time = time.time()
        logger.info("Denormalization section executed in %d secs - %s", int(pe_time - pre_time),
                    denormalization_msg)
        if not denormalization_section_res:
            raise Exception("Error in denormalization section, please check log for more details")



        # - SUMMARY SECTION -
        logger.info("Clearing cache")
        self.sqlContext.catalog.clearCache()
        summary_res, summary_info_lst = self.summary_section()
        summary_section_res = all(item.result for item in summary_res)
        summary_msg = "succeeded" if summary_section_res else "failed"
        se_time = time.time()
        logger.info("Summary section executed in %d secs - %s", int(se_time - pe_time), summary_msg)
        if not summary_section_res:
            raise Exception("Error in summary section, please check log for more details")


        # - AGGREGATION SECTION -
        aggregation_res, populated_agg_tab, agg_info_lst = self.aggregate_section()
        aggregation_section_res = all(item.result for item in aggregation_res)
        aggregation_msg = "succeeded" if aggregation_section_res else "failed"
        ae_time = time.time()
        logger.info("Aggregation section executed in %d secs - %s", int(ae_time - se_time),
                    aggregation_msg)
        if not self.__paar_flag:
            # - MERGE SECTION -
            success_aggregation = set([item.feature_name
                                       for item in aggregation_res if item.result])
            success_agg_info_lst = [item for item in agg_info_lst
                                    if item.feature_name in success_aggregation or
                                    item.tab_name in populated_agg_tab]
            if len(aggregation_res) == 1 and aggregation_res[0].tab_name == "No processing":
                success_agg_info_lst = agg_info_lst
            merge_res, populated_mergetab, merge_info_lst = self.merge_section(success_agg_info_lst)
            merge_section_res = all(item.result for item in merge_res)
            merge_msg = "succeeded" if merge_section_res else "failed"
            me_time = time.time()
            logger.info("Merge section executed in %d secs - %s", int(me_time - ae_time), merge_msg)
            # - VIEW CREATION SECTION -
            # Create View over merge tables, this used for non paar features
            success_merge = [item.tab_name for item in merge_res if item.result]
            success_merge_info_lst = [item for item in merge_info_lst if item.tab_name in
                                      success_merge or item.tab_name in populated_mergetab]
            if len(merge_res) == 1 and merge_res[0].tab_name == "No processing":
                success_agg_info_lst = merge_info_lst
            view_res, view_info_lst = self.view_creation_section(success_merge_info_lst)
            if not view_res:
                logger.error("There is some error in view creation section")
                raise ValueError("Error in view creation section for more info check logs")
            view_msg = "succeeded" if view_res else "failed"
            ve_time = time.time()
            logger.info("View section executed in %d secs - %s", int(ve_time - me_time), view_msg)
        # - DATA PURGE SECTION -
        dps_time = time.time()
        # Purge old data based on data retention policy defined in config
        data_purge_res = self.data_purge_section()
        if not data_purge_res:
            logger.error("There is some error in data purge section")
            raise ValueError("Error in data purge section for more info check logs")
        data_purge_msg = "succeeded" if data_purge_res else "failed"
        dpe_time = time.time()
        logger.info("Data purge section executed in %d secs - %s", int(dpe_time - dps_time),
                    data_purge_msg)
        # - POST RUN SECTION -
        post_res = self.post_run()
        post_msg = "succeeded" if post_res else "failed"
        post_time = time.time()
        logger.info("Post run section executed in %d secs - %s", int(post_time - dpe_time),
                    post_msg)
        # - RUN TIMING DETAILS -
        ed_time = time.time()
        print("--------------- Denormalization Run Result -------")
        if "denormalization_res" in locals() or "denormalization_res" in globals():
            for item in denormalization_res:
                print(item.date_id, item.result, item.time_taken)
        print("--------------- Summary Run Result ---------------")
        if "summary_res" in locals() or "summary_res" in globals():
            for item in summary_res:
                print(item.tab_name, item.result, item.time_taken)
        print("--------------- Aggregation Run Result -----------")
        if "aggregation_res" in locals() or "aggregation_res" in globals():
            for item in aggregation_res:
                print(item.tab_name, item.result, item.time_taken)
        if not self.__paar_flag:
            print("--------------- Merge Run Result -----------------")
            if "merge_res" in locals() or "merge_res" in globals():
                for item in merge_res:
                    print(item.tab_name, item.result, item.time_taken)
        print("--------------------------------------------------")
        print("--------------- Dates Details --------------------")
        print("Run date - {0}".format(self.run_date))
        print("Most recent transaction date - {0}".format(self.recent_trans_date))
        print("Cadence attribute - {0}".format(self.cadence_attribute))
        print("Cadence date - {0}".format(self.cadence))
        print("Cadence fis_week - {0}".format(self.cadence_week))
        print("Since date (based on feature durations) - {0}".format(self.since_date))
        print("Required number of dates - {0}".format(len(self.required_dates)))
        print("Required fis_weeks - {0}".format(len(self.required_fis_weeks)))
        print("Completed fis_weeks - {0}".format(len(self.completed_fis_weeks)))
        print("--------------------------------------------------")
        print("--------------- Run Timing -----------------------")
        print("Total Run - {0} secs".format(int(ed_time - st_time)))
        print("Pre Run Section - {0} secs - {1}".format(int(pre_time - st_time), pre_msg))
        print("Denormalization Section - {0} secs - {1}".format(int(pe_time - pre_time),
                                                                denormalization_msg))
        print("Summary Section - {0} secs - {1}".format(int(se_time - pe_time), summary_msg))
        print("Aggregation Section - {0} secs - {1}".format(int(ae_time - se_time), aggregation_msg))
        if not self.__paar_flag:
            print("Merge Section - {0} secs - {1}".format(int(me_time - ae_time), merge_msg))
            print("View Section - {0} secs - {1}".format(int(ve_time - me_time), view_msg))
        print("Data Purge Section - {0} secs - {1}".format(int(dpe_time - dps_time), data_purge_msg))
        print("Post Run Section - {0} secs - {1}".format(int(post_time - dpe_time), post_msg))
        print("--------------------------------------------------")
        if self.__paar_flag:
            result_lst = [denormalization_section_res, summary_section_res, aggregation_section_res,
                          data_purge_res]
        else:
            result_lst = [denormalization_section_res, summary_section_res, aggregation_section_res,
                          merge_section_res, view_res, data_purge_res]
        if all(result_lst) is False:
            error_msg = "Purchasing Feature Generator job failed for run_date: {run_date}. " \
                        "Please check log for more details.".format(run_date=self.run_date)
            logger.error(error_msg)
            raise Exception(error_msg)
        return all(result_lst)
