"""
Purchasing feature util file
"""


import re
import logging
from collections import namedtuple, OrderedDict


logger = logging.getLogger(__name__)


Date_tuple = namedtuple("Date_tuple", ["fis_year_id", "fis_week_id", "date_id"])
Col_tuple = namedtuple("Col_tuple", ["col_name", "data_type"])
Denormalization_res_tuple = namedtuple("Denormalization_res_tuple",
                                       ["date_id", "result", "time_taken"])
Summary_info_tuple = namedtuple("Summary_info_tuple",
                                ["feature_name", "tab_name", "run_mode", "ddl_drop", "ddl_create",
                                 "dml", "group_info", "sel_col", "part_col", "wave"])
Aggregate_info_tuple = namedtuple("Aggregate_info_tuple",
                                  ["feature_name", "tab_name", "duration", "run_mode", "ddl_drop",
                                   "ddl_create", "dml", "group_info", "sel_col", "part_col",
                                   "wave"])
Merge_info_tuple = namedtuple("Merge_info_tuple",
                              ["feature_name", "tab_name", "durations", "agg_tabs", "run_mode",
                               "ddl_drop", "ddl_create", "dml", "group_info", "sel_col", "part_col",
                               "wave"])
View_info_tuple = namedtuple("View_info_tuple",
                             ["feature_name", "tab_name", "view_name", "current_view_name",
                              "sel_col", "ddl_drop", "ddl_create", "current_ddl_drop",
                              "current_ddl_create"])
Sel_col_tuple = namedtuple("Sel_col_tuple",
                           ["colname", "select_expr", "hive_datatype", "col_num"])
Agg_sel_col_tuple = namedtuple("Agg_sel_col_tuple",
                               ["colname", "in_select_expr", "out_select_expr", "hive_datatype",
                                "col_num"])
Statement_tuple = namedtuple("Statement_tuple",
                             ["feature_name", "tab_type", "tab_name", "stmt_type", "sql_stmt",
                              "log", "section", "wave"])
Exec_res_tuple = namedtuple("Exec_res_tuple",
                            ["feature_name", "tab_name", "result", "time_taken", "log", "section"])
EPOCH_DATE = "1970-01-01"


def match_table_structure(sql_context, db_name, tab_name, col_info, part_info):
    """
    Check existing hive table structure against given parameter
    :param sql_context: spark HiveContext or sqlContext
    :param db_name: String: database name
    :param tab_name: String: table name
    :param col_info: List(Col_tuple()): list of column name along with hive datatype
    :param part_info: List(String): list of partition column name
    :return: True/False: Boolean
    """
    # Check if table exist or not
    if tab_name.lower() not in [item.name.lower() for item in sql_context.catalog.listTables(dbName=db_name) if item.tableType == "MANAGED"]:
        logger.info("Table %s.%s not found, skipping comparison", db_name, tab_name)
        return False
    # Get existing table column info and partition column list
    old_col_info = OrderedDict([(item["col_name"].lower(), item["data_type"].lower())
                                for item in sql_context.sql("DESCRIBE {0}.{1}".format(db_name,
                                                                                      tab_name))
                               .collect() if not item["col_name"].startswith("#")])


    old_ddl = " ".join([row["createtab_stmt"].strip().replace("`", "")
                        for row in sql_context.sql("SHOW CREATE TABLE {0}.{1}".format(db_name,
                                                                                      tab_name))
                       .collect()])
    match_obj = re.match(
        "[\w\s\\(\\)\\.,]+PARTITIONED BY[ ]?\\(([\w\s,]+)\\)[\w\s\\(\\)\\.,=/:_']+", old_ddl)
    if match_obj:
        old_part_info = [item.strip().split(" ")[0].lower()
                         for item in match_obj.groups()[0].split(",")]
    else:
        old_part_info = []
    if len(col_info) != len(old_col_info):
        return False
    for item in col_info:
        old_data_type = old_col_info.get(item.col_name.lower(), None)
        if not old_data_type or old_data_type != item.data_type.lower():
            return False
    if part_info:
        if not [item.lower() for item in part_info] == old_part_info:
            return False
    elif old_part_info:
        return False
    return True
