"""
Purchasing feature coordinator
"""
import logging
from abc import ABCMeta, abstractproperty
from pyspark import StorageLevel

import dunnhumby.cmp_features.purchasingfeaturecoordinator2 as base
import dunnhumby.cmp_features.featureswriter as featureswriter

logger = logging.getLogger(__name__)


class PurchasingFeatureCoordinator(base.PurchasingFeatureCoordinator2):
    """
    Purchasing feature coordinator
    This came before PurchasingFeatureCoordinator2() (obviously, given the name) however
    PurchasingFeatureCoordinator2() pretty much supercedes it so in order that we
    do not have redundant code we have made PurchasingFeatureCoordinator() derive
    from PurchasingFeatureCoordinator2() instead of deriving from CMPFeaturesCoordinator
    which is what it used to derive from.
    """
    __metaclass__ = ABCMeta

    def generate_and_write_features(self, database='_pob', persist_storage_level=StorageLevel.MEMORY_ONLY):
        """
        :param database:
        :param persist_storage_level: StorageLevel to be used when persisting spark dataframes
        :return:
        """
        """Generate and write features"""
        logger.info('Pull data from client transactions source class')
        purchases_df = self._get_filtered_purchases()
        logger.info('Caching Transactions Data')
        purchases_df.persist(persist_storage_level)
        logger.info('Caching Done')

        database_name = self.SSEHiveDatabasePrefix + database
        features_writer = featureswriter.FeaturesWriter(database_name)

        # Iterate over feature_specifications
        for specification in self.features_specifications:
            if specification['is_active'] \
                    and specification['cadence_attribute'] == self.cadence_attribute:
                logger.info('Generating features for following specifications :%s',
                            specification)
                self.features_generator.rsd = specification['rsd']

                features_df = self.features_generator.get_data(
                    as_at=self.as_at,
                    purchases_df=purchases_df,
                    customer_attribute=specification['dimension_attribute_grain'][
                        'CustomerAttribute'],
                    product_attribute=specification['dimension_attribute_grain'][
                        'ProductAttribute'],
                    store_attribute=specification['dimension_attribute_grain'][
                        'StoreAttribute'],
                    channel_attribute=specification['dimension_attribute_grain'][
                        'ChannelAttribute'],
                    customer_attributes_df=self.get_attributes_df(
                        'Customer',
                        specification['dimension_attribute_grain']['CustomerAttribute']),
                    product_attributes_df=self.get_attributes_df(
                        'Product',
                        specification['dimension_attribute_grain']['ProductAttribute']),
                    store_attributes_df=self.get_attributes_df(
                        'Store',
                        specification['dimension_attribute_grain']['StoreAttribute']),
                    channel_attributes_df=self.get_attributes_df(
                        'Channel',
                        specification['dimension_attribute_grain']['ChannelAttribute']),
                    supplementary_dataframes=self.get_supplementary_dataframes(
                        specification, self.config))
                logger.info(
                    'Writing features to {%s}', database_name)
                self._select_and_write_features_and_create_view(
                    features_df, features_writer, specification, database_name)

    @abstractproperty
    def Transactions(self):
        """Transactions entity"""
        pass

    @abstractproperty
    def Product(self):
        """Products entity"""
        pass

    @abstractproperty
    def Channel(self):
        """Channels entity"""
        pass

    @abstractproperty
    def Customer(self):
        """Customers entity"""
        pass

    @abstractproperty
    def Store(self):
        """Stores entity"""
        pass
