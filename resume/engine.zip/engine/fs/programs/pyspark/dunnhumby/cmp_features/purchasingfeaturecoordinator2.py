"""
Purchasing Feature Coordinator 2
"""
import logging
from abc import ABCMeta, abstractproperty
from pyspark import StorageLevel
import dunnhumby.cmp_features.featurescoordinatorbase as base
import dunnhumby.cmp_features.featureswriter as featureswriter
import dunnhumby.cmp_features.purchasingfeaturegenerator as pfg

logger = logging.getLogger(__name__)


class PurchasingFeatureCoordinator2(base.CMPFeaturesCoordinator):
    """
    Purchasing Feature Coordinator 2
    """
    __metaclass__ = ABCMeta

    def __init__(self, config, cadence_attribute, run_date):
        super(PurchasingFeatureCoordinator2, self).__init__()
        self.__Dates = None
        self.__Store = None
        self.__Customer = None
        self.__Product = None
        self.__Channel = None
        self.__Transactions = None
        self.dimension_grain = set(['Customer', 'Product', 'Store', 'Channel'])
        self.features_generator = pfg.PurchasingFeatureGenerator()
        self.config = config
        self.cadence_attribute = cadence_attribute
        self.SSEHiveDatabasePrefix = self.config['SSEHiveDatabasePrefix']
        self.run_date = run_date
        self.durations = [
            (1, 1), (1, 4), (1, 13), (1, 26), (1, 52), (1, 56),
            (50, 57), (53, 78), (53, 104), (101, 107), (153, 159),
            (205, 211)]
        logger.info('run_date = %s', self.run_date)

        # Initialise features_specifications to a default value. This can (and
        # should) be overridden in client-specific implementations
        # however this default is a starting point.
        # When implementing CMP for a new client our aim should be to get
        # something (anything) deployed as quickly as possible
        # (and by that I mean within a week) and then tweak things later. One
        # of the big things that slows us down is deciding which features
        # to generate. Well, now we have a default set of features, go with
        # this at the start to just something (anything) working and then override
        # accordingly later.
        self.features_specifications = [
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "max_purchase_date_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "InstoreAisle",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "Section",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "Group",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "InstoreShelf",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "Subgroup",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "Product",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "ProductDescription", "Subgroup", "SubgroupDescription",
                    "Group", "GroupDescription", "Section", "SectionDescription",
                    "Department", "DepartmentDescription", "Division",
                    "DivisionDescription", "InstoreShelf", "InstoreShelfDescription",
                    "InstoreAisle", "InstoreAisleDescription",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Products", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "InstoreAisle",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Section",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Group",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "InstoreShelf",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Subgroup",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Product",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "StdDevNetSpendPerDuration_1w52w",
                    "CustomerGender", "CustomerAgeRange",
                    "CustomerPriceSensitivity", "IsEmailable", "SloyaltyHigh", "SloyaltyLow",
                    "ProductDescription", "Subgroup", "SubgroupDescription", "Group",
                    "GroupDescription", "Section", "SectionDescription", "Department",
                    "DepartmentDescription", "Division", "DivisionDescription", "InstoreShelf",
                    "InstoreShelfDescription", "InstoreAisle", "InstoreAisleDescription",
                    "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"},
                    {"entity": "Products", "fields": "*"}
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "StdDevNetSpendPerDuration_1w52w",
                    "CustomerGender", "CustomerAgeRange",
                    "CustomerPriceSensitivity", "IsEmailable", "SloyaltyHigh", "SloyaltyLow",
                    "max_purchase_date_1w52w"
                ],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            }
        ]

    def _get_filtered_purchases(self):
        """
        Filter purchases to only those that are needed to satisfy
        the required features
        :return:
        """
        all_transactions = self.Transactions.data
        logger.info('filtering transactions from %s to %s', self.pull_data_since_date, self.as_at)
        purchases_df = all_transactions.where(
            (all_transactions['Date'] > self.pull_data_since_date) &
            (all_transactions['Date'] <= self.as_at))
        return purchases_df

    def generate_and_write_features(
            self, database='_pob', persist_storage_level=StorageLevel.DISK_ONLY):
        """
        Generate and write features
        :param database:
        :param persist_storage_level: StorageLevel to be used when persisting spark dataframes
        :return:
        """
        logger.info('Pull data from client transactions source class')
        purchases_df = self._get_filtered_purchases()
        purchases_df = self.features_generator\
            .join_additional_attributes_required_for_feature_generation(
                df=purchases_df,
                channel_attributes_df=self.Channel.data
                .select(list(self.all_required_channel_attributes)),
                customer_attributes_df=self.Customer.data
                .select(list(self.all_required_customer_attributes)),
                product_attributes_df=self.Product.data
                .select(list(self.all_required_product_attributes)),
                store_attributes_df=self.Store.data
                .select(list(self.all_required_store_attributes)))
        purchases_df.persist(persist_storage_level)

        database_name = self.SSEHiveDatabasePrefix + database
        features_writer = featureswriter.FeaturesWriter(database_name)

        # Iterate over feature_specifications
        for features_specification in self.features_specifications:
            if features_specification['is_active'] \
                    and features_specification['cadence_attribute'] == self.cadence_attribute:
                logger.info('Generating features for following specifications :%s',
                            features_specification)
                self.features_generator.rsd = features_specification['rsd']
                supplementary_dataframes = self.get_supplementary_dataframes(
                    features_specification, self.config)
                purchases_for_current_feature_spec_df, \
                    customer_attribute, \
                    product_attribute, \
                    store_attribute, \
                    channel_attribute = \
                    self.features_generator.adjust_purchases_df_when_dimension_aggregated_to_all(
                        purchases_df,
                        customer_attribute=
                        features_specification['dimension_attribute_grain']['CustomerAttribute'],
                        product_attribute=
                        features_specification['dimension_attribute_grain']['ProductAttribute'],
                        store_attribute=
                        features_specification['dimension_attribute_grain']['StoreAttribute'],
                        channel_attribute=
                        features_specification['dimension_attribute_grain']['ChannelAttribute']
                    )
                purchases_for_current_feature_spec_df = \
                    self.features_generator.filter_out_purchases_with_missing_dimension_attributes(
                        purchases_for_current_feature_spec_df,
                        customer_attribute,
                        product_attribute,
                        store_attribute,
                        channel_attribute)
                features_df = self.features_generator.generate_features(
                    as_at=self.as_at,
                    df=purchases_for_current_feature_spec_df,
                    durations=
                    self.durations,
                    customer_attribute=customer_attribute,
                    product_attribute=product_attribute,
                    store_attribute=store_attribute,
                    channel_attribute=channel_attribute,
                    rsd=features_specification['rsd']
                )
                if supplementary_dataframes is not None:
                    features_df = self.features_generator.join_supplementary_dataframes(
                        features_df, supplementary_dataframes, self.dimension_grain)
                self._select_and_write_features_and_create_view(
                    features_df, features_writer, features_specification, database_name)
        purchases_df.unpersist()

    @abstractproperty
    def Transactions(self):
        """Transactions entity"""
        pass

    @abstractproperty
    def Product(self):
        """Products entity"""
        pass

    @abstractproperty
    def Channel(self):
        """Channels entity"""
        pass

    @abstractproperty
    def Customer(self):
        """Customers entity"""
        pass

    @abstractproperty
    def Store(self):
        """Stores entity"""
        pass
