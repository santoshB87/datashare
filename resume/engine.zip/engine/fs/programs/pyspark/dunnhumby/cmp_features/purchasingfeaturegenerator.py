"""
Purchasing Feature Generator
"""
import logging
import dunnhumby.cmp_features.featuregeneratorbase as base
import pyspark.sql.functions as f
from pyspark.sql.types import DateType, StringType, DecimalType
from tools.dataframe_utilities import check_is_dataframe, check_columns, check_df_for_duplicates

logger = logging.getLogger(__name__)

# pylint: disable=logging-format-interpolation
# pylint: disable=super-on-old-class
# pylint: disable=line-too-long
# pylint: disable=too-many-lines
class PurchasingFeatureGenerator(base.CMPFeatureGenerator):
    """
    Purchasing Feature Generator
    """

    def __init__(self, rsd=None):
        """
        Constructor for PurchasingFeatureGenerator
        :param rsd: Error margin residual for approxCountDistinct calculations. approxCountDistinct
        will use rsd=0.05 if none is specified, which means the approximate count will be within 5%
        of the true value. If rsd=0.0 then countDistinct will be used instead of approxCountDistinct
        however this will likely be detrimental to performance.
        """
        super(PurchasingFeatureGenerator, self).__init__()
        self.__rsd = None
        self.rsd = rsd
        return

    def get_data(self,
                 as_at,
                 purchases_df,
                 customer_attributes_df=None,
                 product_attributes_df=None,
                 store_attributes_df=None,
                 channel_attributes_df=None,
                 customer_attribute='Customer',
                 product_attribute='Product',
                 store_attribute='Store',
                 channel_attribute='Channel',
                 supplementary_dataframes=None,
                 timeofday_attribute='All',
                 feature_filters=None):
        """
        Returns a dataframe of features, aggregated to the dimension attributes specified
        in parameters customer_attribute, product_attribute, store_attribute and channel_attribute

        Depending on the volume of data supplied to purchases_df this function will likely take a
        long time to complete. It carries out group by and join operations, both of which are
        computationally expensive. We hope your wait is worth it.

        :param as_at: Date at which features should be calculated. Transactions in the 7 days prior
        to as_at will be considered to be in week 1. The 7 days prior to that are in week 2 etc...
        :param purchases_df: Spark dataframe of transactions. The dataframe must adhere to a certain
        schema, appropriate and (hopefully) useful error messages will be raised if the schema is
        not met.
        :param customer_attributes_df: dataframe of Customer attributes. It must contain a field
        called 'Customer' which should uniquely identify each row
        :param product_attributes_df: dataframe of Product attributes. It must contain a field
        called 'Product' which should uniquely identify each row
        :param store_attributes_df: dataframe of Store attributes. It must contain a field called
        'Store' which should uniquely identify each row
        :param channel_attributes_df: dataframe of Channel attributes. It must contain a field
        called 'Channel' which should uniquely identify each row
        :param customer_attribute: The attribute of the Customer dimension to which data should be
        aggregated. Default value is 'Customer' (i.e. the Customer identifier)
        :param product_attribute: The attribute of the Product dimension to which data should be
        aggregated. Default value is 'Product' (i.e. the Product identifier)
        :param store_attribute: The attribute of the Store dimension to which data should be
        aggregated. Default value is 'Store' (i.e. the Store identifier)
        :param channel_attribute: The attribute of the Channel dimension to which data should be
        aggregated. Default value is 'Channel' (i.e. the Channel identifier)
        :return: A dataframe, containing features aggregated to customer_attribute,
        product_attribute, store_attribute, channel_attribute
        """
        # *_attributes parameters must be dataframes and must include a column with a name
        # matching the expected unique
        # identifier of the dataframe
        self.check_time_of_day_attribute(timeofday_attribute)
        check_is_dataframe(purchases_df)
        check_columns(purchases_df, ['Customer', 'Product', 'Store', 'Channel'])
        feature_filters = PurchasingFeatureGenerator._check_feature_filters(feature_filters)

        purchases_df, customer_attribute, product_attribute, store_attribute, channel_attribute = \
            self.adjust_purchases_df_when_dimension_aggregated_to_all(
                purchases_df, customer_attribute, product_attribute, store_attribute,
                channel_attribute)
        purchases_df = self.join_additional_attributes_required_for_feature_generation(
            purchases_df, channel_attributes_df, customer_attributes_df,
            product_attributes_df, store_attributes_df)
        purchases_df = self.filter_out_purchases_with_missing_dimension_attributes(
            purchases_df, customer_attribute, product_attribute, store_attribute, channel_attribute)
        df = PurchasingFeatureGenerator.generate_features(
            as_at, purchases_df, self.durations,
            customer_attribute, product_attribute, store_attribute, channel_attribute,
            timeofday_attribute, self.rsd, feature_filters=feature_filters)
        if supplementary_dataframes is not None:
            df = self.join_supplementary_dataframes(
                df, supplementary_dataframes, set(['Customer', 'Product', 'Store', 'Channel']))
        return df

    @staticmethod
    def adjust_purchases_df_when_dimension_aggregated_to_all(
            df, customer_attribute, product_attribute, store_attribute, channel_attribute):
        """
        When a dimension is aggregated to all then we need add a column of known name
        containing a constant that can be used to aggregate to "All"
        """
        if customer_attribute == 'All':
            df = df.withColumn('AllCustomer', f.lit('All'))
            customer_attribute = 'AllCustomer'
        if product_attribute == 'All':
            df = df.withColumn('AllProduct', f.lit('All'))
            product_attribute = 'AllProduct'
        if store_attribute == 'All':
            df = df.withColumn('AllStore', f.lit('All'))
            store_attribute = 'AllStore'
        if channel_attribute == 'All':
            df = df.withColumn('AllChannel', f.lit('All'))
            channel_attribute = 'AllChannel'
        return (
            df,
            customer_attribute,
            product_attribute,
            store_attribute,
            channel_attribute)

    @staticmethod
    def join_additional_attributes_required_for_feature_generation(
            df, channel_attributes_df, customer_attributes_df,
            product_attributes_df, store_attributes_df):
        """
        Additional attributes may be required on the df in order to generate certain features.
        For example, at the time of writing a Customer's preferred store 1, 2 & 3, and a Customer's
        fulfillment store are required. These additional attributes must be gotten from attributes
        of the entities.
        :param df:
        :param channel_attributes_df:
        :param customer_attributes_df:
        :param product_attributes_df:
        :param store_attributes_df:
        :return: Dataframe resulting from joining the incoming dataframes
        """
        if channel_attributes_df:
            df = PurchasingFeatureGenerator.join_df_to_entity_attributes(
                df, 'Channel', channel_attributes_df)
        if store_attributes_df:
            df = PurchasingFeatureGenerator.join_df_to_entity_attributes(
                df, 'Store', store_attributes_df)
        if customer_attributes_df:
            df = PurchasingFeatureGenerator.join_df_to_entity_attributes(
                df, 'Customer', customer_attributes_df)
        if product_attributes_df:
            df = PurchasingFeatureGenerator.join_df_to_entity_attributes(
                df, 'Product', product_attributes_df)
        return df

    @staticmethod
    def join_df_to_multiple_entity_attributes_on_identifying_attribute(
            aggregated_df, customer_attributes_df, customer_attribute,
            product_attributes_df, product_attribute, store_attributes_df,
            store_attribute, channel_attributes_df, channel_attribute):
        '''

        :param aggregated_df:
        :param customer_attributes_df:
        :param customer_attribute:
        :param product_attributes_df:
        :param product_attribute:
        :param store_attributes_df:
        :param store_attribute:
        :param channel_attributes_df:
        :param channel_attribute:
        :return:
        '''
        aggregated_df = PurchasingFeatureGenerator. \
            join_df_to_entity_attributes_on_identifying_attribute(
                aggregated_df, 'Product', product_attribute, product_attributes_df)
        aggregated_df = PurchasingFeatureGenerator. \
            join_df_to_entity_attributes_on_identifying_attribute(
                aggregated_df, 'Store', store_attribute, store_attributes_df)
        aggregated_df = PurchasingFeatureGenerator. \
            join_df_to_entity_attributes_on_identifying_attribute(
                aggregated_df, 'Customer', customer_attribute, customer_attributes_df)
        aggregated_df = PurchasingFeatureGenerator. \
            join_df_to_entity_attributes_on_identifying_attribute(
                aggregated_df, 'Channel', channel_attribute, channel_attributes_df)
        return aggregated_df

    @staticmethod
    def join_df_to_entity_attributes_on_identifying_attribute(
            df, entity, entity_attribute_being_aggregated_to, entity_attributes_df):
        """
        Join data to entities if appropriate to do so
        :param df: Dataframe that has entity as one of its fields
        :param entity: The entity being joined
        :param entity_attribute_being_aggregated_to:
        :param entity_attributes_df: Dataframe of attributes of the entity
        :return:
        """
        if entity_attributes_df and entity_attribute_being_aggregated_to == entity:
            df = PurchasingFeatureGenerator.join_df_to_entity_attributes(
                df, entity, entity_attributes_df)
        return df

    @staticmethod
    def join_df_to_entity_attributes(df, entity, entity_attributes_df):
        """
        Joins a dataframe to a dataframe of entity attributes. Assumes both dataframes have
        a field with a name equal to that of the entity.
        The reason for this is that each entity should be uniquely defined by a field of
        the same name. For example, the Product entity should be uniquely defined by a
        field called Product.

        :param df:
        :param entity:
        :param entity_attributes_df:
        :return: A dataframe containing all fields from both dataframes. Cardinality will
        be equal to that of inputted df
        """
        check_is_dataframe(df)
        check_is_dataframe(entity_attributes_df)
        check_df_for_duplicates(entity_attributes_df, entity)
        expected_entities = ['Product', 'Customer', 'Store', 'Channel']
        if entity not in expected_entities:
            raise ValueError('entity: {entity} not one of expected entities: {expected_entities}'
                             .format(entity=entity, expected_entities=expected_entities))
        logger.info(
            (
                'Joining dataframe with schema {df_schema} to {entity} attributes dataframe ' +
                ' with schema {attributes_schema}').format(
                    df_schema=[field.name for field in df.schema.fields],
                    entity=entity,
                    attributes_schema=[field.name for field in entity_attributes_df.schema.fields])
        )
        # left_outer join specified in case where, either intentionally or accidentally,
        # all values in df[entity]
        # do not exist in entity_attributes_df[entity]
        df = df.join(
            entity_attributes_df,
            entity,
            'left_outer')\
            .drop(entity_attributes_df[entity])
        return df

    @staticmethod
    def filter_out_purchases_with_missing_dimension_attributes(
            purchases_df, customer_attribute, product_attribute,
            store_attribute, channel_attribute):
        '''

        :param purchases_df:
        :param customer_attribute:
        :param product_attribute:
        :param store_attribute:
        :param channel_attribute:
        :return:
        '''
        for attribute in [customer_attribute, product_attribute,
                          store_attribute, channel_attribute]:
            if attribute != 'All':
                purchases_df = purchases_df.filter(purchases_df[attribute].isNotNull())

        return purchases_df

    @staticmethod
    def generate_features(as_at, df, durations, customer_attribute='Customer',
                          product_attribute='Product', store_attribute='Store',
                          channel_attribute='Channel', timeofday_attribute='All',
                          rsd=None, feature_filters=None):
        """
        This is the workhorse method of this class. It ultimately returns a dataframe of
        features that have been generated by aggregating transactions over the dimension_grain.
        At the time of writing the vast majority of our features are generated by this method.
        :param as_at: Date at which features should be calculated
        :param df: dataframe of transactions
        :param durations: List of of durations over which features are to be calculated
        :param customer_attribute: The attribute of the Customer dimension to which data should
        be aggregated.
        :param product_attribute: The attribute of the Product dimension to which data should
        be aggregated.
        :param store_attribute: The attribute of the Store dimension to which data should be
        aggregated.
        :param channel_attribute: The attribute of the Channel dimension to which data should
        be aggregated.
        :param timeofday_attribute: The attribute of the TimeOfDay dimension to which data should
        be aggregated.
        :param rsd: Residual for approxDistinctCount()
        :param feature_filters: Filters to apply to the purchases
        :return: A dataframe, containing features aggregated as desired by dimension_grain
        """

        PurchasingFeatureGenerator._check_as_at_and_transactions_df_arguments(as_at, df)
        dimension_grain = PurchasingFeatureGenerator.get_dimension_grain(
            channel_attribute, customer_attribute, product_attribute, store_attribute)
        df, dimension_grain, timeofday_attribute = \
            PurchasingFeatureGenerator.create_timeofday_dimension_if_required(
                df, dimension_grain, timeofday_attribute)
        check_columns(df, ['Basket', 'Customer', 'Product', 'Store', 'Channel', 'Date',
                           'Quantity', 'SpendAmount', 'NetSpendAmount', 'DiscountAmount',
                           customer_attribute, product_attribute, store_attribute,
                           channel_attribute])
        #renaming columns so we can better take advantage of reusable code (called
        # _get_expressions_using_sum() at time of writing) in feature calculations
        df = df.withColumnRenamed('SpendAmount', 'GrossSpend')
        df = df.withColumnRenamed('NetSpendAmount', 'NetSpend')
        df = df.withColumnRenamed('DiscountAmount', 'Discount')
        df = PurchasingFeatureGenerator._add_fields_week_number_and_recency_days(as_at, df)
        df = PurchasingFeatureGenerator._derive_base_features(
            df, dimension_grain, durations, rsd=rsd,
            feature_filters=feature_filters)
        df = PurchasingFeatureGenerator.add_dimension_columns_for_dimensions_aggregated_to_all(
            df, channel_attribute, customer_attribute, product_attribute, store_attribute)
        df = PurchasingFeatureGenerator._derive_extra_features_from_base_features(
            durations, df)
        df = PurchasingFeatureGenerator._rename_groupby_columns_to_entity_name(
            df, customer_attribute, product_attribute, store_attribute,
            channel_attribute, timeofday_attribute)
        dimension_attribute_grain = {
            "ChannelAttribute": channel_attribute if channel_attribute != "AllChannel" else "All",
            "CustomerAttribute": customer_attribute if customer_attribute != "AllCustomer" else "All",
            "ProductAttribute": product_attribute if product_attribute != "AllProduct" else "All",
            "StoreAttribute": store_attribute if store_attribute != "AllStore" else "All",
            "TimeOfDayAttribute": timeofday_attribute if timeofday_attribute != "AllTimeOfDay" else "All"
        }
        df = PurchasingFeatureGenerator.add_description_metadata(df, dimension_attribute_grain)
        return df

    @staticmethod
    def add_dimension_columns_for_dimensions_aggregated_to_all(
            df, channel_attribute, customer_attribute, product_attribute, store_attribute):
        '''

        :param df:
        :param channel_attribute:
        :param customer_attribute:
        :param product_attribute:
        :param store_attribute:
        :return:
        '''
        if customer_attribute == "AllCustomer":
            df = df.withColumn("AllCustomer", f.lit('All'))
        if product_attribute == "AllProduct":
            df = df.withColumn("AllProduct", f.lit('All'))
        if store_attribute == "AllStore":
            df = df.withColumn("AllStore", f.lit('All'))
        if channel_attribute == "AllChannel":
            df = df.withColumn("AllChannel", f.lit('All'))
        return df

    @staticmethod
    def get_dimension_grain(
            channel_attribute, customer_attribute, product_attribute, store_attribute):
        '''
        """Determine which dimensions should be aggregated over"""
        :param channel_attribute:
        :param customer_attribute:
        :param product_attribute:
        :param store_attribute:
        :return:
        '''

        dimension_grain = []
        # If a dimension is to be aggregated to "All" then there's really no point in
        # aggregating over it. Not doing so
        # will avoid data skew problems in the Spark pipeline
        PurchasingFeatureGenerator.append_attribute_to_dimension_grain(
            'Customer', customer_attribute, dimension_grain)
        PurchasingFeatureGenerator.append_attribute_to_dimension_grain(
            'Product', product_attribute, dimension_grain)
        PurchasingFeatureGenerator.append_attribute_to_dimension_grain(
            'Store', store_attribute, dimension_grain)
        PurchasingFeatureGenerator.append_attribute_to_dimension_grain(
            'Channel', channel_attribute, dimension_grain)
        return dimension_grain

    @staticmethod
    def _rename_groupby_columns_to_entity_name(
            df, customer_attribute, product_attribute,
            store_attribute, channel_attribute, timeofday_attribute):
        """
        Where data has been aggregated to attributes of an entity (aka dimension)
        other than the identifying attribute the dataframe will contain a field,
        named for that attribute. We need to rename it back to the name of the entity
        :param df:
        :param customer_attribute:
        :param product_attribute:
        :param store_attribute:
        :param channel_attribute:
        :return:
        """
        df = PurchasingFeatureGenerator._rename_entity_attribute_to_entity_identifying_attribute(
            df, 'Customer', customer_attribute)
        df = PurchasingFeatureGenerator._rename_entity_attribute_to_entity_identifying_attribute(
            df, 'Product', product_attribute)
        df = PurchasingFeatureGenerator._rename_entity_attribute_to_entity_identifying_attribute(
            df, 'Store', store_attribute)
        df = PurchasingFeatureGenerator._rename_entity_attribute_to_entity_identifying_attribute(
            df, 'Channel', channel_attribute)
        # The dataframe may not have a contain a column with name timeofday_attribute. That's OK,
        # it just means this function call will have no effect
        df = PurchasingFeatureGenerator._rename_entity_attribute_to_entity_identifying_attribute(
            df, 'TimeOfDay', timeofday_attribute)
        return df

    @staticmethod
    def _derive_extra_features_from_base_features(durations, df):
        '''

        :param durations:
        :param df:
        :return:
        '''
        for week_tuple in [(13, 26), (13, 52)]:
            earliest_week_number, latest_week_number = week_tuple
            df = PurchasingFeatureGenerator._add_column_baskets_decay(df, earliest_week_number,
                                                                      latest_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_column_baskets_flag(
                df, start_week_number, end_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_quantity_per_basket(
                df, start_week_number, end_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_discount_per_basket(
                df, start_week_number, end_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_discount_percent_per_basket(
                df, start_week_number, end_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_averagepurchasecycle(
                df, start_week_number, end_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_cyclessincelastpurchase(
                df, start_week_number, end_week_number)
        for start_week_number, end_week_number in durations:
            df = PurchasingFeatureGenerator._add_netspendperbasket(
                df, start_week_number, end_week_number)
        return df

    @staticmethod
    def _add_new_column_to_df_if_it_does_not_already_exist(df, column_name, column_type):
        '''

        :param df:
        :param column_name:
        :param column_type:
        :return:
        '''
        if column_name not in [field.name for field in df.schema.fields]:
            df = df.withColumn(column_name, f.lit(None).cast(column_type))
        return df

    @staticmethod
    def _aggregate_transactions_per_week(df, dimension_grain, feature_filters, rsd=None):
        """
        Raw transactions must be aggregated over week_number
        countDistinct produces an accurate answer but approxCountDistinct is much much quicker.
        We allow the user to choose which to use by specifying the residual (rsd). If its 0.
        0 then use countDistinct, otherwise approxCountDistinct.
        :param df: data to be aggregated
        :param dimension_grain: columns over which to aggregate df
        :param rsd: error margin residual for approxCountDistinct
        :return: aggregated dataframe
        """
        dimension_grain_with_week_number = dimension_grain + ['week_number']
        check_columns(df, dimension_grain_with_week_number)
        expressions = []
        if feature_filters is None:
            feature_filters = []
        for feature_filter in feature_filters + [None]:
            if feature_filter is None \
                    or PurchasingFeatureGenerator._check_feature_filter_elements_exist_in_df(
                            df, feature_filter):
                expressions.append(PurchasingFeatureGenerator._get_baskets_per_week_expression(
                    df, rsd, feature_filter))
                expressions.append(PurchasingFeatureGenerator._get_purchase_was_made_expression(
                    df, feature_filter))
                expressions.append(PurchasingFeatureGenerator._get_net_spend_per_week_expression(
                    df, feature_filter))
        df = PurchasingFeatureGenerator._groupby_dimension_grain_and_derive_features(
            df, dimension_grain_with_week_number, expressions)
        return df

    @staticmethod
    def _derive_base_features(
            df, dimension_grain, durations, rsd=None, feature_filters=None):
        """
        There are (at the time of writing) two distinct dataframes of features
        being calculated here:
         Basic aggregations over the whole corpus of transactions
         Aggregates over the week that each transaction appears in
        These are then joined together, and the joined dataframe is returned.

        :param df: dataframe of transactions
        :param dimension_grain: columns to groupBy()
        :return: dataframe of aggregated data
        """

        features_from_week_based_aggregations_df = \
            PurchasingFeatureGenerator._get_features_from_week_based_aggregations(
                df, durations, dimension_grain, feature_filters, rsd=rsd)
        features_from_base_aggregations_df = \
            PurchasingFeatureGenerator._get_features_from_base_aggregations(
                df, durations, dimension_grain, feature_filters, rsd)
        return features_from_week_based_aggregations_df.join(
            features_from_base_aggregations_df, dimension_grain)

    @staticmethod
    def _get_features_from_week_based_aggregations(
            df, durations, dimension_grain, feature_filters, rsd=None):
        '''

        :param df:
        :param durations:
        :param dimension_grain:
        :param feature_filters:
        :param rsd:
        :return:
        '''
        aggregated_transactions_per_week_df = \
            PurchasingFeatureGenerator._aggregate_transactions_per_week(
                df, dimension_grain, feature_filters, rsd=rsd)
        expressions = PurchasingFeatureGenerator._get_expressions_for_week_based_aggregations(
            aggregated_transactions_per_week_df, durations, feature_filters)
        features_df = \
            PurchasingFeatureGenerator._groupby_dimension_grain_and_derive_features(
                aggregated_transactions_per_week_df, dimension_grain, expressions)
        return features_df

    @staticmethod
    def _get_expressions_for_week_based_aggregations(
            df, durations, feature_filters):
        '''

        :param df:
        :param durations:
        :param feature_filters:
        :return:
        '''
        expressions = []
        expressions = (
            expressions +
            PurchasingFeatureGenerator._get_expressions_for_week_aggregations_per_filter(
                durations, None, df))
        if feature_filters:
            for feature_filter in feature_filters:
                expressions = (
                    expressions +
                    PurchasingFeatureGenerator._get_expressions_for_week_aggregations_per_filter(
                        durations, feature_filter, df))
        return expressions

    @staticmethod
    def _get_expressions_for_week_aggregations_per_filter(
            durations, feature_filter, df):
        '''

        :param durations:
        :param feature_filter:
        :param df:
        :return:
        '''
        expressions_to_calculate_baskets_columns = [
            PurchasingFeatureGenerator._get_baskets_expressions(
                df, start_week_number, end_week_number, feature_filter)
            for start_week_number, end_week_number in durations]
        expressions_to_calculate_basketsweeks_columns = [
            PurchasingFeatureGenerator._get_basketweeks_expressions(
                df, start_week_number, end_week_number, feature_filter)
            for start_week_number, end_week_number in durations]
        expressions_to_calculate_recencyweightedbasketweeks_columns = [
            PurchasingFeatureGenerator._get_recencyweightedbasketweeks_expressions(
                df, start_week_number=1, end_week_number=52, smoothing_factor=smoothing_factor,
                feature_filter=feature_filter)
            for smoothing_factor in [0.75, 0.95]]
        expressions_to_calculate_stddev_netspend_per_duration_columns = [
            PurchasingFeatureGenerator._get_stddev_netspend_per_duration_expressions(
                df, start_week_number, end_week_number, feature_filter)
            for start_week_number, end_week_number in durations]
        expressions = (
            expressions_to_calculate_baskets_columns +
            expressions_to_calculate_basketsweeks_columns +
            expressions_to_calculate_recencyweightedbasketweeks_columns +
            expressions_to_calculate_stddev_netspend_per_duration_columns)
        return expressions

    @staticmethod
    def _get_features_from_base_aggregations(
            df, durations, dimension_grain, feature_filters, rsd=None):
        '''

        :param df:
        :param durations:
        :param dimension_grain:
        :param feature_filters:
        :param rsd:
        :return:
        '''
        expressions = PurchasingFeatureGenerator._get_expressions_for_base_aggregations(
            df, durations, feature_filters, rsd=rsd)
        features_df = PurchasingFeatureGenerator._groupby_dimension_grain_and_derive_features(
            df, dimension_grain, expressions)
        return features_df

    @staticmethod
    def _get_expressions_for_base_aggregations(
            df, durations, feature_filters, rsd=None):
        '''

        :param df:
        :param durations:
        :param feature_filters:
        :param rsd:
        :return:
        '''
        expressions = []
        expressions = (
            expressions +
            PurchasingFeatureGenerator._get_expressions_for_base_aggregations_per_filter(
                df, None, durations, rsd))
        if feature_filters:
            for feature_filter in feature_filters:
                expressions = (
                    expressions +
                    PurchasingFeatureGenerator._get_expressions_for_base_aggregations_per_filter(
                        df, feature_filter, durations, rsd))
        return expressions

    @staticmethod
    def _get_expressions_for_base_aggregations_per_filter(
            df, feature_filter, durations, rsd):
        '''

        :param df:
        :param feature_filter:
        :param durations:
        :param rsd:
        :return:
        '''
        expressions = []
        if feature_filter is None \
                or PurchasingFeatureGenerator._check_feature_filter_elements_exist_in_df(
                        df, feature_filter):
            customer_count_expressions = [
                PurchasingFeatureGenerator._get_customer_count_expressions(
                    df, start_week_number, end_week_number, feature_filter, rsd=rsd)
                for start_week_number, end_week_number in durations]
            store_count_expressions = [
                PurchasingFeatureGenerator._get_store_count_expressions(
                    df, start_week_number, end_week_number, feature_filter, rsd=rsd)
                for start_week_number, end_week_number in durations]
            channel_count_expressions = [
                PurchasingFeatureGenerator._get_channel_count_expressions(
                    df, start_week_number, end_week_number, feature_filter, rsd=rsd)
                for start_week_number, end_week_number in durations]
            product_count_expressions = [
                PurchasingFeatureGenerator._get_product_count_expressions(
                    df, start_week_number, end_week_number, feature_filter, rsd=rsd)
                for start_week_number, end_week_number in durations]
            recency_days_expressions = [
                PurchasingFeatureGenerator._get_recency_days_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            min_purchase_date_expressions = [
                PurchasingFeatureGenerator._get_min_purchase_date_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            max_purchase_date_expressions = [
                PurchasingFeatureGenerator._get_max_purchase_date_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            minimum_price_expressions = [
                PurchasingFeatureGenerator._get_minimum_price_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            maximum_price_expressions = [
                PurchasingFeatureGenerator._get_maximum_price_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            average_price_expressions = [
                PurchasingFeatureGenerator._get_average_price_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            gross_spend_expressions = [
                PurchasingFeatureGenerator._get_gross_spend_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            minimum_net_price_expressions = [
                PurchasingFeatureGenerator._get_minimum_net_price_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            maximum_net_price_expressions = [
                PurchasingFeatureGenerator._get_maximum_net_price_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            average_net_price_expressions = [
                PurchasingFeatureGenerator._get_average_net_price_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            net_spend_expressions = [
                PurchasingFeatureGenerator._get_net_spend_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            quantity_expressions = [
                PurchasingFeatureGenerator._get_quantity_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            discount_expressions = [
                PurchasingFeatureGenerator._get_discount_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            discount_percent_expressions = [
                PurchasingFeatureGenerator._get_discount_percent_expressions(
                    df, start_week_number, end_week_number, feature_filter)
                for start_week_number, end_week_number in durations]
            expressions = (quantity_expressions + customer_count_expressions +
                           product_count_expressions + recency_days_expressions +
                           min_purchase_date_expressions + max_purchase_date_expressions +
                           minimum_price_expressions + maximum_price_expressions +
                           average_price_expressions + gross_spend_expressions +
                           minimum_net_price_expressions + maximum_net_price_expressions +
                           average_net_price_expressions + net_spend_expressions +
                           discount_expressions + discount_percent_expressions +
                           channel_count_expressions + store_count_expressions)
            df_fields = [field.name for field in df.schema.fields]
            if 'PreferredStore1' in df_fields:
                qtyprefstr1_expressions = [
                    PurchasingFeatureGenerator._get_qtyprefstrn_expressions(
                        df, start_week_number, end_week_number, 1, feature_filter)
                    for start_week_number, end_week_number in durations]
                expressions = expressions + qtyprefstr1_expressions
            if 'PreferredStore2' in df_fields:
                qtyprefstr2_expressions = [
                    PurchasingFeatureGenerator._get_qtyprefstrn_expressions(
                        df, start_week_number, end_week_number, 2, feature_filter)
                    for start_week_number, end_week_number in durations]
                expressions = expressions + qtyprefstr2_expressions
            if 'PreferredStore3' in df_fields:
                qtyprefstr3_expressions = [
                    PurchasingFeatureGenerator._get_qtyprefstrn_expressions(
                        df, start_week_number, end_week_number, 3, feature_filter)
                    for start_week_number, end_week_number in durations]
                expressions = expressions + qtyprefstr3_expressions
            if 'FulfillmentStore' in df_fields:
                qtyfulstr_expressions = [
                    PurchasingFeatureGenerator._get_qtyfulstr_expressions(
                        df, start_week_number, end_week_number, feature_filter)
                    for start_week_number, end_week_number in durations]
                expressions = expressions + qtyfulstr_expressions
        return expressions

    @staticmethod
    def _add_column_baskets_decay(df, earliest_week_number, latest_week_number):
        '''

        :param df:
        :param earliest_week_number:
        :param latest_week_number:
        :return:
        '''
        earliest_baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', 1, earliest_week_number)
        latest_baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', 1, latest_week_number)
        return df.withColumn(
            'BasketsDecay_1w{earliest_week_number}wvs1w{latest_week_number}w'.format(
                earliest_week_number=earliest_week_number,
                latest_week_number=latest_week_number),
            (df[earliest_baskets] / df[latest_baskets]).cast(DecimalType(38, 2)))

    @staticmethod
    def _add_column_baskets_flag(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'BasketsFlag', start_week_number, end_week_number)
        baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number)
        return df.withColumn(feature_name, f.when(df[baskets] > 0, True).otherwise(False))

    @staticmethod
    def _add_quantity_per_basket(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'QuantityPerBasket', start_week_number, end_week_number)
        baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number)
        quantity = PurchasingFeatureGenerator._get_feature_name(
            'Quantity', start_week_number, end_week_number)
        return df.withColumn(
            feature_name,
            f.when(
                df[baskets] > 0,
                (df[quantity] / df[baskets])
            ).otherwise(None).cast(DecimalType(8, 2)))

    @staticmethod
    def _add_discount_per_basket(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'DiscountPerBasket', start_week_number, end_week_number)
        baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number)
        discount = PurchasingFeatureGenerator._get_feature_name(
            'Discount', start_week_number, end_week_number)
        return df.withColumn(
            feature_name,
            f.when(
                df[baskets] > 0,
                (df[discount] / df[baskets])
            ).otherwise(None).cast(DecimalType(38, 2)))

    @staticmethod
    def _add_discount_percent_per_basket(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'DiscountPercentPerBasket', start_week_number, end_week_number)
        baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number)
        discountpercent = PurchasingFeatureGenerator._get_feature_name(
            'DiscountPercent', start_week_number, end_week_number)
        return df.withColumn(
            feature_name,
            f.when(
                df[baskets] > 0,
                (df[discountpercent] / df[baskets])
            ).otherwise(None).cast(DecimalType(38, 2)))

    @staticmethod
    def _add_cyclessincelastpurchase(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'CyclesSinceLastPurchase', start_week_number, end_week_number)
        recencydays = PurchasingFeatureGenerator._get_feature_name(
            'RecencyDays', start_week_number, end_week_number)
        averagepurchasecycle = PurchasingFeatureGenerator._get_feature_name(
            'AveragePurchaseCycle', start_week_number, end_week_number)
        return df.withColumn(
            feature_name,
            (df[recencydays] / df[averagepurchasecycle]).cast(DecimalType(6, 2)))

    @staticmethod
    def _add_averagepurchasecycle(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'AveragePurchaseCycle', start_week_number, end_week_number)
        max_purchase_date = PurchasingFeatureGenerator._get_feature_name(
            'max_purchase_date', start_week_number, end_week_number)
        min_purchase_date = PurchasingFeatureGenerator._get_feature_name(
            'min_purchase_date', start_week_number, end_week_number)
        baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number)
        return df.withColumn(
            feature_name,
            (
                (f.datediff(df[max_purchase_date], df[min_purchase_date])) / (df[baskets] - 1)
            ).cast(DecimalType(6, 2))
        )

    @staticmethod
    def _add_netspendperbasket(df, start_week_number, end_week_number):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :return:
        '''
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'NetSpendPerBasket', start_week_number, end_week_number)
        baskets = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number)
        netspend = PurchasingFeatureGenerator._get_feature_name(
            'NetSpend', start_week_number, end_week_number)
        return df.withColumn(
            feature_name,
            f.when(
                df[baskets] > 0,
                (df[netspend] / df[baskets])
            ).otherwise(None).cast(DecimalType(8, 2)))

    @staticmethod
    def _rename_entity_attribute_to_entity_identifying_attribute(df, entity, entity_attribute):
        '''

        :param df:
        :param entity:
        :param entity_attribute:
        :return:
        '''
        df = df.withColumnRenamed(entity_attribute, entity)
        return df

    @staticmethod
    def _get_baskets_per_week_expression(df, rsd, feature_filter=None):
        '''

        :param df:
        :param rsd:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df=df, start_week_number=None, end_week_number=None,
            feature_filter=feature_filter, feature='BasketsPerWeek')
        if filters is not None:
            if rsd == 0.0:
                expression = f.countDistinct(f.when(filters, df.Basket))
            else:
                expression = f.approxCountDistinct(col=f.when(filters, df.Basket), rsd=rsd)
        else:
            if rsd == 0.0:
                expression = f.countDistinct(df.Basket)
            else:
                expression = f.approxCountDistinct(col=df.Basket, rsd=rsd)
        return expression.alias(feature_name)

    @staticmethod
    def _get_net_spend_per_week_expression(df, feature_filter=None):
        '''

        :param df:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df=df, start_week_number=None, end_week_number=None,
            feature_filter=feature_filter, feature='NetSpendPerWeek')
        if filters is not None:
            expression = f.sum(f.when(filters, df.NetSpend))
        else:
            expression = f.sum(df.NetSpend)
        return expression.alias(feature_name)

    @staticmethod
    def _get_purchase_was_made_expression(df, feature_filter=None):
        '''

        :param df:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df=df, start_week_number=None, end_week_number=None,
            feature_filter=feature_filter, feature='PurchaseWasMade')
        if filters is not None:
            expression = f.coalesce(f.max(f.when(filters, f.lit(1))), f.lit(0))
        else:
            expression = f.lit(1)
        return expression.alias(feature_name)

    @staticmethod
    def _get_qtyprefstrn_expressions(
            df, start_week_number, end_week_number, preferred_store_n, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param preferred_store_n:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter,
            'QuantityPrefStore{n}'.format(n=preferred_store_n))
        filters = filters & (df.Store == df['PreferredStore{n}'.format(n=preferred_store_n)])
        return f.coalesce(
            f.sum(
                f.when(
                    filters,
                    df.Quantity)),
            f.lit(0)
        ).alias(feature_name)

    @staticmethod
    def _get_qtyfulstr_expressions(df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'QuantityFulfillmentStore')
        filters = filters & (df.Store == df.FulfillmentStore)
        return f.coalesce(
            f.sum(
                f.when(
                    filters,
                    df.Quantity)
            ),
            f.lit(0)
        ).alias(feature_name)

    @staticmethod
    def _get_recencyweightedbasketweeks_expressions(
            df, start_week_number, end_week_number, smoothing_factor, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param smoothing_factor:
        :param feature_filter:
        :return:
        '''
        baskets_per_week_feature_name = PurchasingFeatureGenerator._get_feature_name(
            'BasketsPerWeek', start_week_number=None,
            end_week_number=None, feature_filter=feature_filter)
        if not (smoothing_factor > 0.0) & (smoothing_factor < 1):
            raise RuntimeError(
                'Supplied smoothing factor ({smoothing_factor}) is not between 0 and 1'
                .format(smoothing_factor=smoothing_factor))
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'RecencyWeightedBasketWeeks{smoothing_factor}'.format(
                smoothing_factor=int(smoothing_factor * 100)),
            start_week_number, end_week_number, feature_filter)
        filters = PurchasingFeatureGenerator._get_filters(df, start_week_number, end_week_number)
        return f.coalesce(
            f.sum(
                f.when(
                    filters,
                    df[baskets_per_week_feature_name]
                ) * f.pow(smoothing_factor, df.week_number - 1)
            ),
            f.lit(0)
        ).cast(DecimalType(38, 10)).alias(feature_name)

    @staticmethod
    def _get_quantity_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        return PurchasingFeatureGenerator._get_integer_type_expressions_using_sum(
            df, start_week_number, end_week_number, feature_filter, 'Quantity')

    @staticmethod
    def _get_baskets_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        baskets_per_week_feature_name = PurchasingFeatureGenerator._get_feature_name(
            'BasketsPerWeek', start_week_number=None,
            end_week_number=None, feature_filter=feature_filter)
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'Baskets', start_week_number, end_week_number, feature_filter)
        filters = PurchasingFeatureGenerator._get_filters(
            df, start_week_number, end_week_number)
        return f.coalesce(
            f.sum(
                f.when(
                    filters,
                    df[baskets_per_week_feature_name]
                )
            ),
            f.lit(0)
        ).alias(feature_name)

    @staticmethod
    def _get_stddev_netspend_per_duration_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        netspend_per_week_feature_name = PurchasingFeatureGenerator._get_feature_name(
            'NetSpendPerWeek', start_week_number=None,
            end_week_number=None, feature_filter=feature_filter)
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'StdDevNetSpendPerDuration', start_week_number, end_week_number, feature_filter)
        filters = PurchasingFeatureGenerator._get_filters(
            df, start_week_number, end_week_number)
        return f.coalesce(
            f.stddev(
                f.when(
                    filters,
                    df[netspend_per_week_feature_name]
                )
            ),
            f.lit(0)
        ).cast(DecimalType(10, 6)).alias(feature_name)

    @staticmethod
    def _get_basketweeks_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        purchase_was_made_feature_name = PurchasingFeatureGenerator._get_feature_name(
            'PurchaseWasMade', start_week_number=None,
            end_week_number=None, feature_filter=feature_filter)
        feature_name = PurchasingFeatureGenerator._get_feature_name(
            'BasketWeeks', start_week_number, end_week_number, feature_filter)
        filters = PurchasingFeatureGenerator._get_filters(
            df, start_week_number, end_week_number)
        return f.coalesce(
            f.sum(
                f.when(
                    filters,
                    df[purchase_was_made_feature_name]
                )
            ),
            f.lit(0)
        ).alias(feature_name)

    @staticmethod
    def _get_customer_count_expressions(
            df, start_week_number, end_week_number, feature_filter=None, rsd=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :param rsd:
        :return:
        '''
        return PurchasingFeatureGenerator._get_distinct_count_expressions(
            df=df,
            start_week_number=start_week_number,
            end_week_number=end_week_number,
            feature_filter=feature_filter,
            rsd=rsd,
            input_field='Customer')

    @staticmethod
    def _get_store_count_expressions(
            df, start_week_number, end_week_number, feature_filter=None, rsd=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :param rsd:
        :return:
        '''
        return PurchasingFeatureGenerator._get_distinct_count_expressions(
            df=df,
            start_week_number=start_week_number,
            end_week_number=end_week_number,
            feature_filter=feature_filter,
            rsd=rsd,
            input_field='Store')

    @staticmethod
    def _get_channel_count_expressions(
            df, start_week_number, end_week_number, feature_filter=None, rsd=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :param rsd:
        :return:
        '''
        return PurchasingFeatureGenerator._get_distinct_count_expressions(
            df=df,
            start_week_number=start_week_number,
            end_week_number=end_week_number,
            feature_filter=feature_filter,
            rsd=rsd,
            input_field='Channel')

    @staticmethod
    def _get_product_count_expressions(
            df, start_week_number, end_week_number, feature_filter=None, rsd=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :param rsd:
        :return:
        '''
        return PurchasingFeatureGenerator._get_distinct_count_expressions(
            df=df,
            start_week_number=start_week_number,
            end_week_number=end_week_number,
            feature_filter=feature_filter,
            rsd=rsd,
            input_field='Product')

    @staticmethod
    def _get_recency_days_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        return PurchasingFeatureGenerator._get_short_type_expressions_using_min(
            df=df, start_week_number=start_week_number, end_week_number=end_week_number,
            feature_filter=feature_filter, input_field='RecencyDays')

    @staticmethod
    def _get_min_purchase_date_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'min_purchase_date')
        return f.min(
            f.when(
                filters,
                df.Date)
        ).cast(DateType()).alias(feature_name)

    @staticmethod
    def _get_max_purchase_date_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'max_purchase_date')
        return f.max(
            f.when(
                filters,
                df.Date)
        ).cast(DateType()).alias(feature_name)

    @staticmethod
    def _get_minimum_price_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'MinimumPrice')
        return (
            f.min(
                f.when(
                    filters,
                    (df.GrossSpend / df.Quantity))
            ).cast(DecimalType(38, 2)).alias(feature_name))

    @staticmethod
    def _get_maximum_price_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'MaximumPrice')
        return f.max(
            f.when(
                filters,
                (df.GrossSpend / df.Quantity))
        ).cast(DecimalType(38, 2)).alias(feature_name)

    @staticmethod
    def _get_average_price_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'AveragePrice')
        return f.avg(
            f.when(
                filters,
                (df.GrossSpend / df.Quantity))
        ).cast(DecimalType(38, 10)).alias(feature_name)

    @staticmethod
    def _get_gross_spend_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        return PurchasingFeatureGenerator._get_expressions_using_sum(
            df=df, start_week_number=start_week_number, end_week_number=end_week_number,
            feature_filter=feature_filter, input_field='GrossSpend')

    @staticmethod
    def _get_minimum_net_price_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'MinimumNetPrice')
        return f.min(
            f.when(
                filters,
                (df.NetSpend / df.Quantity))
        ).cast(DecimalType(38, 10)).alias(feature_name)

    @staticmethod
    def _get_maximum_net_price_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'MaximumNetPrice')
        return f.max(
            f.when(
                filters,
                (df.NetSpend / df.Quantity))
        ).cast(DecimalType(38, 10)).alias(feature_name)

    @staticmethod
    def _get_average_net_price_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'AverageNetPrice')
        return f.avg(
            f.when(
                filters,
                (df.NetSpend / df.Quantity))
        ).cast(DecimalType(38, 10)).alias(feature_name)

    @staticmethod
    def _get_net_spend_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        return PurchasingFeatureGenerator._get_expressions_using_sum(
            df=df, start_week_number=start_week_number, end_week_number=end_week_number,
            feature_filter=feature_filter, input_field='NetSpend')

    @staticmethod
    def _get_discount_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        return PurchasingFeatureGenerator._get_expressions_using_sum(
            df=df, start_week_number=start_week_number, end_week_number=end_week_number,
            feature_filter=feature_filter, input_field='Discount')

    @staticmethod
    def _get_discount_percent_expressions(
            df, start_week_number, end_week_number, feature_filter=None):
        '''

        :param df:
        :param start_week_number:
        :param end_week_number:
        :param feature_filter:
        :return:
        '''
        feature_name, filters = PurchasingFeatureGenerator.get_feature_name_and_filters(
            df, start_week_number, end_week_number, feature_filter, 'DiscountPercent')
        return f.coalesce(
            f.sum(
                f.when(
                    filters,
                    ((df.Discount / df.GrossSpend) * 100)
                ).cast(DecimalType(38, 10))), f.lit(0)).alias(feature_name)



    @staticmethod
    def add_description_metadata(df, dimension_attribute_grain={}):
        if not isinstance(dimension_attribute_grain, dict):
            raise RuntimeError(
                "dimension_attribute_grain must be a dict, not a {type_}".
                format(type_=type(dimension_attribute_grain)))
        for field in df.schema.fields:
            if field.name.startswith('Baskets_'):
                field.metadata = PurchasingFeatureGenerator._get_baskets_feature_description(
                    field.name, dimension_attribute_grain)
        return df

    @staticmethod
    def _get_baskets_feature_description(feature_name, dimension_attribute_grain):
        description = "Tally of baskets"
        description = PurchasingFeatureGenerator._append_entity_attribute_description(
            description, 'Product', 'containing', dimension_attribute_grain)
        description = PurchasingFeatureGenerator._append_entity_attribute_description(
            description, 'Customer', 'bought by', dimension_attribute_grain)
        description = PurchasingFeatureGenerator._append_entity_attribute_description(
            description, 'Store', 'bought in', dimension_attribute_grain)
        description = PurchasingFeatureGenerator._append_entity_attribute_description(
            description, 'Channel', 'bought in', dimension_attribute_grain)
        duration_start, duration_start_unit, duration_end, duration_end_unit = \
            PurchasingFeatureGenerator._get_duration_constituents(feature_name)
        description = "{description} bought between {duration_start} {duration_start_unit} ago and {duration_end} {duration_end_unit} ago (inclusive)"\
            .format(
                description=description,
                duration_start=duration_start,
                duration_start_unit=duration_start_unit,
                duration_end=duration_end,
                duration_end_unit=duration_end_unit)
        return {"Description": description}
