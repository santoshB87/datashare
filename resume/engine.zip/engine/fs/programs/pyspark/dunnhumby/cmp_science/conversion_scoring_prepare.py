'''
Conversion_scoring_prepare.py
'''
from utilities import prepare_features_df, get_model_features_list

__author__ = 'rudraps and millan'


# pylint: disable=bad-continuation
# pylint: disable=line-too-long


def insert(logger, sqlContext, config, prod_df, pmml_root):
    '''
    Get the final DataFrame whose columns are to be written out to
    the Hive and insert overwrite the table for the features for
    Conversoin Scoring.

    :param logger: logger object to be used globally across the application
    :param sqlContext: a SQLContext instance
    :param config: complete configuration required to run Scoring
    :param prod_df: DataFrame created out of Products entity
    :param pmml_root: content under the <root> tag of PMML

    :return: None
    '''
    target_table_name, temp_target_table_name = _get_table_names(config)
    # Get list of columns from PMML model
    list_of_reqd_cols = get_model_features_list(pmml_root, ('is_predicted', 'yes'))
    logger.info("List of columns data to be saved: %s" % list_of_reqd_cols)
    # Get data science model input dataframe
    df = prepare_features_df(logger=logger, sqlContext=sqlContext, config=config,
                             prod_df=prod_df, cust_df=None, is_conv=True)
    data_to_write = df.select(list_of_reqd_cols)
    _create_table_from_df(logger, sqlContext, data_to_write, target_table_name, temp_target_table_name)


def _get_table_names(config):
    '''
    Derive the table names for both the intermediary and final outputs.

    :param config: complete configuration required to run Scoring

    :return: None
    '''
    destination_schema = config.get('destination_schema')
    suffix = config.get('proposition')
    table_base_name = 'standard_scoring_features'
    target_table_name = "{hive_schema}.{table_base_name}".format(
        hive_schema=destination_schema,
        table_base_name=table_base_name
    )
    temp_target_table_name = table_base_name + '_temp'
    if suffix is not None:
        target_table_name = '{target_table_name}_{suffix}'.format(
            target_table_name=target_table_name, suffix=suffix)
        temp_target_table_name = '{temp_target_table_name}_{suffix}'.format(
            temp_target_table_name=temp_target_table_name, suffix=suffix)
    return target_table_name, temp_target_table_name


def _create_table_from_df(logger, sqlContext, df, target_table_name, temp_target_table_name):
    '''
    Persist the DataFrame to a Hive table.

    :param logger: logger object to be used globally across the application
    :param sqlContext: a SQLContext instance
    :param df: the DataFrame to be written
    :param target_table_name: name of the table to persist df to
    :param temp_target_table_name: name of the temporary table for SparkSQL

    :return: None
    '''
    df.registerTempTable(temp_target_table_name)
    # Now first need to delete the old table
    _drop_table_if_exists(logger, sqlContext, target_table_name)

    # Now we can create and populate the table with the new features
    sql = '''
        CREATE TABLE
           {target_table_name}
        row format
           delimited fields terminated by ','
        stored as textfile
        AS SELECT * from {temp_target_table_name}
            '''.format(
        target_table_name=target_table_name,
        temp_target_table_name=temp_target_table_name
    )
    logger.debug('Issuing SQL: {sql}'.format(sql=sql))
    logger.info("Loading prepared data into '{table}'".format(table=target_table_name))
    try:
        sqlContext.sql(sql)
    except Exception as e:
        logger.error("Error in table creation (%s)" % target_table_name)
        raise Exception(e)


def _drop_table_if_exists(logger, sqlContext, target_table_name):
    '''
    Drop the given table.

    :param logger: logger object to be used globally across the application
    :param sqlContext: a SQLContext instance
    :param target_table_name: name of the table to be dropped

    :return: None
    '''
    sql = '''
            DROP TABLE IF EXISTS {target_table_name}
          '''.format(target_table_name=target_table_name)
    logger.debug('Issuing DROP TABLE SQL: {sql}'.format(sql=sql))
    sqlContext.sql(sql)
