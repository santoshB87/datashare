'''
prepare_jobs.py
'''
from dunnhumby import contexts
from pyspark.sql import functions as F
from pyspark.sql import types as T

from conversion_scoring_prepare import insert as conv_std_insert
from scoring_prepare import insert as std_insert

__author__ = 'rudraps and millan'


# pylint: disable=bad-continuation
# pylint: disable=too-few-public-methods


class StandardConversionPrepare(object):
    def __init__(self, config):
        '''
        Initialize the object here with the sqlContext and config.

        :param config: Complete configuration to be used
        '''
        self.sqlContext = contexts.sql_context()
        self.config = config
        self.prod_df = None

    def _get_data_from_entities(self):
        '''
        Get the data from the Products entity to fetch the product attributes.

        :return: None
        '''
        module = __import__('{client_name}.cmp_entities.products'.
                            format(client_name=self.config['client_name']),
                            globals(), locals(), -1)
        prods = module.Products
        prod_obj = prods(self.config)
        self.prod_df = (prod_obj.data.select(['Product', 'Subgroup', 'Group', 'Division', 'InstoreShelf', 'InstoreSubAisle', 'InstoreArea'])
                        .withColumnRenamed('Subgroup', 'productsubgroup')
                        .withColumnRenamed('Group', 'productgroup')
                        .withColumnRenamed('Division', 'productdivision')
                        .withColumnRenamed('InstoreShelf', 'productinstoreshelf')
                        .withColumnRenamed('InstoreSubAisle', 'productinstoresubaisle')
                        .withColumnRenamed('InstoreArea', 'productinstorearea')
                        )

    def prepare_data_for_scoring(self, logger, pmml_root):
        '''
        Calls the logic for populating the data for the Conversion Scoring.

        :param logger: logger object to be used globally across the application
        :param pmml_root: all the content under the <root> tag of PMML

        :return:None
        '''
        self._get_data_from_entities()
        conv_std_insert(logger, self.sqlContext, self.config, self.prod_df, pmml_root)


class StandardPrepare(object):
    def __init__(self, config):
        '''
        Initialize the object here with the sqlContext and config.

        :param config: Complete configuration to be used
        '''
        self.sqlContext = contexts.sql_context()
        self.config = config
        self.conversion_scores = None
        self.prod_df = None
        self.cust_df = None

    def _get_std_conversion_scores(self):
        '''
        Get the output of Conversion Scoring and manipulate it.

        :return: None
        '''
        conversion_scores_table = '{source_schema}.{proposition}_conv_standard_latest'.format(
            source_schema=self.config.get('source_schema'),
            proposition=self.config.get('proposition')
        )
        cust_prod_attrb_product = self.config.get('CustomerProduct_grain') + '_' + 'product'
        cust_prod_attrb_customer = self.config.get('CustomerProduct_grain') + '_' + 'customer'
        df = self.sqlContext.table(conversion_scores_table)
        df = df.groupBy([cust_prod_attrb_customer, cust_prod_attrb_product]).max('score')
        self.conversion_scores = df.select(
            cust_prod_attrb_customer,
            cust_prod_attrb_product,
            (1 / (1 + F.exp((F.col('max(score)') * -1)))).cast(T.DecimalType(38, 10)).alias(
                'prob_{proposition}_conversion'.format(proposition=self.config.get('proposition')))
        )

    def _get_data_from_entities(self):
        '''
        Get the required attributes from Products and Customer entities.

        :return: None
        '''
        module = __import__('{client_name}.cmp_entities.products'.
                            format(client_name=self.config['client_name']),
                            globals(), locals(), -1)
        prods = module.Products
        prod_obj = prods(self.config)
        self.prod_df = (prod_obj.data.select(['Product', 'Subgroup', 'Group', 'Division', 'InstoreShelf', 'InstoreSubAisle', 'InstoreArea'])
                        .withColumnRenamed('Subgroup', 'productsubgroup')
                        .withColumnRenamed('Group', 'productgroup')
                        .withColumnRenamed('Division', 'productdivision')
                        .withColumnRenamed('InstoreShelf', 'productinstoreshelf')
                        .withColumnRenamed('InstoreSubAisle', 'productinstoresubaisle')
                        .withColumnRenamed('InstoreArea', 'productinstorearea')
                        )

        module = __import__('{client_name}.cmp_entities.customers'.
                            format(client_name=self.config['client_name']),
                            globals(), locals(), -1)
        Custs = module.Customers
        cust_obj = Custs(self.config)
        self.cust_df = cust_obj.data

    def prepare_data_for_scoring(self, logger, pmml_root):
        '''
        Calls the logic for populating the data for the Standard Scoring.

        :param logger: logger object to be used globally across the application
        :param pmml_root: all the content under the <root> tag of PMML
        :return:None
        '''
        self._get_std_conversion_scores()
        self._get_data_from_entities()
        std_insert(logger, self.sqlContext, self.config, self.conversion_scores,
                   self.prod_df, self.cust_df, pmml_root)
