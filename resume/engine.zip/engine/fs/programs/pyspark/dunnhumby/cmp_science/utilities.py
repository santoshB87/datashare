'''
These're some functions which we'll use in the prepare steps of both conversion and final scorings.
'''

from __future__ import print_function

import xml.etree.cElementTree as ET
from functools import partial

from pyspark.sql import functions as F

__author__ = 'rudraps and millan'


# pylint: disable=trailing-whitespace, deprecated-lambda
# pylint: disable=anomalous-backslash-in-string, anomalous-unicode-escape-in-string
# pylint: disable=line-too-long, pointless-string-statement

def prepare_features_df(logger, sqlContext, config, prod_df=None, cust_df=None, is_conv=False):
    """
    This function takes in a dictionary wherein the keys are grain filters and the values are DataFrames
    of features calculated at the corresponding grains; and joins them to form one DataFrame of final features
    DataFrame.

    :param sqlContext: SQLContext object
    :param sse_hive_database_prefix: client identifying prefix to be stuck on the front of database name
    :param is_conv: either True for conversion or False for final scoring
    :param prod_df: DataFrame of Products entity
    :param cust_df: DataFrame of Customers entity

    :return: Final DataFrame of features
    """

    source_schema = config.get('source_schema')
    logger.info("Collecting features data (Source Schema:%s)" % source_schema)
    """
    Exeption handling added to read data from entities individually,
    so that, if later as per bussiness logic we can proceed with empty dataframe for 
    some entities, then we can add empty dataframe creation code in excption handiling 
    part for perticular entities.
    """
    try:
        source_entity = config.get('features_CustomerProduct_dataset')
        df_cu_pr = sqlContext.table('{hive_schema}.{entity_name}'.format(
            hive_schema=source_schema,
            entity_name=source_entity
        ))
    except Exception as e:
        logger.error("Exception in reading data from entity :%s" % source_entity)
        raise Exception(e)

    try:
        source_entity = config.get('features_ProductAll_dataset')
        df_pr = (sqlContext.table('{hive_schema}.{entity_name}'.format(
            hive_schema=source_schema,
            entity_name=source_entity
        )).drop(F.col('customer')).drop(F.col('store')).drop(F.col('channel')).drop(F.col('cadence')).drop(
            F.col('productattribute')).drop(F.col('customerattribute')).drop(F.col('storeattribute')).drop(
            F.col('channelattribute')).drop(F.col('cadenceattribute')))
    except Exception as e:
        logger.error("Exception in reading data from entity :%s" % source_entity)
        raise Exception(e)

    try:
        source_entity = config.get('features_CustomerAll_dataset')
        df_cu = (sqlContext.table('{hive_schema}.{entity_name}'.format(
            hive_schema=source_schema,
            entity_name=source_entity
        )).drop(F.col('product')).drop(F.col('store')).drop(F.col('channel')).drop(F.col('cadence')).drop(
            F.col('productattribute')).drop(F.col('customerattribute')).drop(F.col('storeattribute')).drop(
            F.col('channelattribute')).drop(F.col('cadenceattribute')))
    except Exception as e:
        logger.error("Exception in reading data from entity :%s" % source_entity)
        raise Exception(e)

    df = (df_cu_pr.join(df_pr, df_cu_pr.product == df_pr.product, 'left_outer').drop(df_pr.product))
    df = df.join(df_cu, df.customer == df_cu.customer, 'left_outer').drop(df_cu.customer)
    df = df.join(prod_df, df.product == prod_df.Product, 'left_outer').drop(prod_df.Product)
    if is_conv:
        try:
            source_entity = config.get('features_prod_heirarchy_dataset')
            df_cu_subgrp = (sqlContext.table('{hive_schema}.{entity_name}'.format(
                hive_schema=source_schema,
                entity_name=source_entity
            )).drop(F.col('store')).drop(F.col('channel'))
                            .drop(F.col('productattribute')).drop(F.col('customerattribute'))
                            .drop(F.col('storeattribute')).drop(F.col('channelattribute')))
        except Exception as e:
            logger.error("Exception in reading data from entity :%s" % source_entity)
            raise Exception(e)

        df = (df.join(df_cu_subgrp,
                      ((df.customer == df_cu_subgrp.customer) & (df.productsubgroup == df_cu_subgrp.product)),
                      'left_outer')
              .drop(df_cu_subgrp.product).drop(df_cu_subgrp.customer))
        """
        if source table/view names of features will change then the attributes name will also change.
        So we can derive grain from entinity name to form required feature attribute name
        """
        cust_prod_attrb_baskets_1w52w = config.get('CustomerProduct_grain') + '_' + 'baskets_1w52w'
        cust_prod_attrb_customer = config.get('CustomerProduct_grain') + '_' + 'customer'
        cust_prod_attrb_product = config.get('CustomerProduct_grain') + '_' + 'product'

        result = (df.filter(df[cust_prod_attrb_baskets_1w52w] > 0)
                  .withColumnRenamed('customer', cust_prod_attrb_customer)
                  .withColumnRenamed('product', cust_prod_attrb_product))
    else:
        result = df.join(cust_df, df.customer == cust_df.Customer, 'left_outer').drop(cust_df.Customer)

    return result


#   Following 4 functions will enable parsing of PMML to get the columns in the final standard conversion
#   scoring features table.

def get_model_features_list(pmml_root, excl_cond_attr_val):
    """
    #   >>> path_to_pmml = 'C:\Users\miland\Desktop\Temp\RP_CONV.standard.pmml'
    #   >>> path_to_pmml = 'C:\Users\miland\Desktop\Temp\RP_CONV.standard.pmml'
    #   >>> excl_cond_attr_val = ('is_predicted', 'yes')
    #   >>> res = get_col_rules(path_to_pmml, excl_cond_attr_val)

    :param pmml_root: whole tree structure of the PMML
    :param excl_cond_attr_val: tuple of attributes and the corresponding values to define filtering rules
    :return: list of features required by the given model
    """
    elmnts_lst = _get_ft_nm_tags(pmml_root)
    filtered_elmnts_list = filter(partial(_excl_test, excl_cond_attr_val), elmnts_lst)
    return map(lambda each: each.attrib.get('name'), filtered_elmnts_list)


def _get_ft_nm_tags(root):
    '''

    :param root:
    :return:
    '''
    nmspc = root.tag[: root.tag.rfind('PMML')]
    fnl_lookup_tag = '{0}{1}'.format(nmspc, 'DataField')
    return root.findall('.//{0}'.format(fnl_lookup_tag))


def _excl_test(excl_cond_attr_val, elmnt):
    '''

    :param excl_cond_attr_val:
    :param elmnt:
    :return:
    '''
    (key, val) = excl_cond_attr_val
    return not (elmnt.attrib.get(key) == val)


def read_pmml_root(path_to_pmml):
    '''

    :param path_to_pmml:
    :return:
    '''
    pmml_tree = ET.parse(path_to_pmml)
    return pmml_tree.getroot()
