"""
Module to hold SparkContext and HiveContext for application
"""
import logging
import pyspark
from pyspark.sql import SparkSession

# pylint: disable=global-statement, redefined-outer-name


logger = logging.getLogger(__name__)

_sc = None
_sql_context = None


def sc(spark_conf=pyspark.SparkConf()):
    '''

    :param spark_conf:
    :return:
    '''
    global _sc
    if _sc is None:
        logger.debug('No SparkContext set - getOrCreating a new one')

        spark_conf.set("spark.sql.parquet.binaryAsString", "true")
        spark_conf.set("spark.sql.crossJoin.enabled", "true")

        # TODO Remove the explicit config passed and fix the code instead.
        _sc = SparkSession.builder.enableHiveSupport().getOrCreate()
        _sc.conf.set("spark.sql.crossJoin.enabled", "true")
        _sc.conf.set("spark.sql.cbo.enabled", True)
        _sc.conf.set("spark.sql.cbo.joinReorder.enabled", True)

        # reduce the logging output of the spark context - otherwise it's incredibly verbose
        spark_logger = _sc.sparkContext._jvm.org.apache.log4j
        spark_logger.LogManager.getLogger("org").setLevel(spark_logger.Level.ERROR)
        spark_logger.LogManager.getLogger("akka").setLevel(spark_logger.Level.ERROR)
    return _sc


def set_sc(sc):
    '''

    :param sc:
    :return:
    '''
    global _sc
    _sc = sc


def sql_context():
    '''

    :return:
    '''
    global _sql_context
    if _sql_context is None:
        logger.debug('No sqlContext set - creating a new HiveContext')
        _sql_context = sc()

        # _sql_context = SparkSession.builder.enableHiveSupport()\
        #     .config("spark.sql.crossJoin.enabled", "true")\
        #     .getOrCreate()
        # _sql_context.sparkContext.setLogLevel("ERROR")
    return _sql_context


def set_sql_context(sql_context):
    global _sql_context
    _sql_context = sql_context
