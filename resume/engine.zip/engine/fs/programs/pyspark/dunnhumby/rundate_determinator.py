'''
Base class for rundate_determinator.py
'''
import abc
import datetime

# pylint: disable=too-few-public-methods, no-self-use
class RunDateDeterminator(object):
    """
    Base Run-date determiner Class
    """
    __metaclass__ = abc.ABCMeta

    @property
    def run_date(self):
        '''

        :return:
        '''
        #Sets the run date to today
        return datetime.date.today()
