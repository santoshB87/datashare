import json
import os
import re

# base_folder = "/home/cengadmin/engine/fs/programs/pyspark"
base_folder = "/opt/project/fs/programs/pyspark"

market = ['shoprite','tesco_ie','ci_colombia','coop_no']

environment = ['dev']

airflow_config = ["enginePath","ClientShortName","client_name","EnvironmentIdentifier",
 "fsLev","ScoringBaseRetentionHistory","SSEHiveDatabasePrefix",
 "airflowNode","airflowUser"]

def get_mapping(config_file):
    return json.load(open(config_file))

for mkt in ['tesco_ie']:
    for env in environment:
        config_path = base_folder + '/' + mkt + '/'
        config_file = env + '_config.json'
        config = get_mapping(config_path + config_file)
        server_config = {k: v for k, v in config.items() if k not in airflow_config}
        with open(config_path + config_file,'w') as fp:
            json.dump(server_config, fp, indent = 4)

