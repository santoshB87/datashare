"""
meijer CMP Entities
"""
import logging
database = 'meijer_media_mart'

logger = logging.getLogger(__name__)