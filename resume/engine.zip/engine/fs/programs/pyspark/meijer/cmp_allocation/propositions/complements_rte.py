"""
Meijers complements proposition module
"""

import logging
import tools.configs as config
from dunnhumby.cmp_allocation.propositions import complements

LOGGER = logging.getLogger(__name__)


class ComplementsAllocation(complements.ComplementsAllocation):
    """
    Inheriting base usual module to use common functionality for every client.
    We can override or create client specific methods in this module.
    """

    def __init__(self, config_file, algorithm, variation):
        super(ComplementsAllocation, self).__init__(config_file, algorithm, variation)
        self.config_ = config_file
        self.full_config = config.Config().add_source_file(config_file)
        # self.store_region = self.full_config.get_item(keys=(algorithm, 'store_region_rules'), mandatory=True)


    def allocate(self, path):
        self.get_scores()
        self.df = self.scores_df
        self.cap_and_infill_recommendations()
        self.df.printSchema()
        self.write_results_to_hdfs(path)
