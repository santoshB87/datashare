"""
Meijer RPAllocation class
"""
import logging

import tools.configs as config
from dunnhumby.cmp_allocation.propositions import relevant_promotions
from pyspark.sql import Window
from pyspark.sql.functions import col, lit, when, rand, round, \
    dense_rank, udf, row_number, count, max, current_date, date_add, \
    countDistinct, format_string, min, rank

from dunnhumby.cmp_allocation import spark_tools
from pyspark import StorageLevel
from pyspark.sql import functions as F
import pyspark.sql.types as pt
# noinspection PyUnresolvedReferences


logger = logging.getLogger(__name__)


class RPAllocation(relevant_promotions.RPAllocation):
    """
        Inherits the base RPAllocation class
    """

    def __init__(self, config_file, algorithm, variation):
        super(RPAllocation, self).__init__(config_file, algorithm, variation)
        self.config_ = config_file
        self.full_config = config.Config().add_source_file(config_file)
        self.recommendations = self.full_config.get_item(keys=(algorithm, 'outputs', 'recommendations'), mandatory=True)
        self.final_columns = self.recommendations['columns']
        self.sort_columns = self.recommendations['sort_columns']
        self.allocation_dis = self.recommendations['rename_columns']


    def get_best_promotion_for_a_product(self):
        logger.info("Best promotion for a product")
        discount = self.get_promo_rules['discount']
        allocation_key_attribute = self.allocation_rules[
            'allocation_key_attribute']
        if discount is None:
            # getting count of number of stores a promotion is active in per allocation_key_attribute
            promo_store_df = self.promo_df.select(
                *[key for key in
                  ['Promotion', allocation_key_attribute, 'Store'] if
                  key]).distinct().groupBy(
                *[key for key in ['Promotion', allocation_key_attribute] if
                  key]).count()

            self.promo_df = self.promo_df.join(promo_store_df,
                                               [key for key in ['Promotion',
                                                                allocation_key_attribute]
                                                if key])

            temp_df = self.promo_df.select(
                *[key for key in
                  ['Product', 'Promotion', 'count', allocation_key_attribute] if
                  key]).distinct()

            wc = Window.partitionBy(
                *[temp_df[key] for key in ['Product', allocation_key_attribute]
                  if key])

            temp_df = temp_df.withColumn("rank", row_number().over(wc)).orderBy(
                col('count').desc(), col('Promotion').desc()).where(
                'rank = 1').drop('rank').select(
                *[key for key in
                  ['Promotion', allocation_key_attribute, 'Product'] if key])

            self.promo_df = self.promo_df.join(temp_df,
                                               [key for key in ['Promotion',
                                                                allocation_key_attribute,
                                                                'Product'] if
                                                key], 'inner').drop('count')

        else:
            temp_df = self.promo_df.groupBy(['Product', 'Store']).agg(
                max('DiscountAmount').alias("DiscountAmount"))
            # making window so that a promotion having same maximum discount could pick only one using rank.
            wc = Window.partitionBy("Product", "Store").orderBy("Promotion")

            # joining on product, store and DiscountAmount as we need to consider all the stores.
            self.promo_df = self.promo_df.join(temp_df, ["Product", "Store", "DiscountAmount"]). \
                withColumn("rank", row_number().over(wc)).where('rank =1').drop('rank')
            self.promo_df = self.promo_df.withColumnRenamed("DiscountAmount", "Discount")
        # Convert the promo start date time and promo end date time into the required timestamp format
        out_format = '%Y/%m/%d %H:%M:%S'
        convert_to_required_time_stamp = udf(lambda x: x.strftime(out_format))
        self.promo_df = self.promo_df.withColumn('PromotionStartDatetime',
                                                 convert_to_required_time_stamp(
                                                     'PromotionStartDatetime'))
        self.promo_df = self.promo_df.withColumn('PromotionEndDatetime',
                                                 convert_to_required_time_stamp(
                                                     'PromotionEndDatetime'))

        self.promo_df = self.promo_df.withColumn('StoreRegion', lit(None).cast(
            pt.StringType()))
        # TODO Handle generic allocation_key_attribute - allocation_key_attribute can be any field in Product/Promotion/Store hierarchy
        if allocation_key_attribute != 'Banner':
            self.promo_df = self.promo_df.drop(self.promo_df['Banner'])
            self.promo_df = self.promo_df.withColumn('Banner', lit(None).cast(
                pt.StringType()))

        # TODO Get Min end_date and Max start date at Product, Allocation Key Attribute level
        # de-duping on product store level as de-duping on product alone will cause loss in promotions for pref.stores.
        self.promo_df = self.promo_df.dropDuplicates(
            [key for key in ['Product', 'Store', allocation_key_attribute] if key])
        self.promo_df.persist()
        logger.info("QA : unique promotions after applying best promotions for product logic : {}".format(
            self.promo_df.select("Promotion").distinct().count()))


    def adding_product_hierarchy(self):

        """
        adding variable from product entity to apply the business rule.

        """
        self.df = self.scores_df
        product_df = self.product_df.select('Product', 'Subgroup', 'Group', 'Department', 'Division')
        self.df = self.df.join(product_df, ['product']).drop(product_df['product'])


    def join_promotions(self):
        """join self.promo_df onto self.df, implicitly applying promotion store ranging if required, controlled by
                self.join_promotions_rules dict, eg:
                {
                    "promo_store_key": "store",
                    "promo_product_key": "product",
                    "score_product_key": "product"
                }

                keys are:
                    promo_store_key: store join key on self.promo_df
                    score_store_key: store join key on self.df or None
                    promo_product_key: product join key on self.promo_df
                    score_product_key: product join key on self.df

                if score_store_key is specified join on both product and store, implicitly applying promo store ranging,
                otherwise drop store key from promo data, deduplicate and join on just product.
                """

        required_keys = ['promo_store_key', 'promo_product_key',
                         'score_product_key', 'score_store_key']
        missing_keys = [key for key in required_keys if
                        key not in self.join_promotions_rules.keys()]
        if len(missing_keys) > 0:
            raise RuntimeError(
                'Required keys missing from promo_ranging object: {0}'.format(
                    missing_keys))

        promo_product_key = self.join_promotions_rules['promo_product_key']
        score_product_key = self.join_promotions_rules['score_product_key']
        score_store_key = self.join_promotions_rules['score_store_key']

        spark_tools.check_columns(self.promo_df, [promo_product_key])
        spark_tools.check_columns(self.df, score_product_key)

        logger.info("Joining customer and PreferredStore with score")
        customer_df = self.customer_df.select('customer', col('PreferredStore1').alias('store')).dropDuplicates()
        # Applied store ranging for RP allocation
        self.df = self.df.join(customer_df, ['customer'])

        join_condition = [self.df[score_product_key] == self.promo_df[
            promo_product_key], self.df["store"] == self.promo_df["Store"]]

        logger.info('Joining active promotions to scores, applying store ranging on {0}'.format(score_store_key))
        # self.df = self.promo_df.join(self.df, join_condition).drop(self.promo_df[promo_product_key])
        self.df = self.df.join(self.promo_df, join_condition).drop(
            self.promo_df[promo_product_key]).drop(self.df["store"])
        logger.info("QA : Number Of distinct Customers after joining Promotions in RP : {}".format(self.df.select("customer").distinct().count()))

        self.df.persist()
        self.join_promo_df = self.df

        logger.info("QA : Number Of distinct Customers after applying Store ranging on RP  : {}".format(
            self.df.select("customer").distinct().count()))



    def rp_allocation(self):
        """

        :return:
        """
        self.join_promotions()
        self.df = self.apply_exclusions(exclusion_df=self.df)
        logger.info(
            "QA : Number of customers after exclusions rule {cnt}".format(cnt=self.df.select('customer').distinct().count()))
        self.df = self.apply_conditional_inclusions(df=self.df)
        # logger.info(
        #     "QA : Number of customers before sensitive rule {cnt}".format(cnt=self.df.select('customer').distinct().count()))
        self.df = self.apply_sensitive_products_exclusion()
        # logger.info(
        #     "QA : Number of customers after senstive rule {cnt}".format(cnt=self.df.select('customer').distinct().count()))
        self.df = self.apply_required_diversity(df=self.df,
                                                level=self.allocation_rules[
                                                    'allocation_key_attribute'])
        logger.info(
            "QA : Number of customers after applying diversity {cnt}".format(
                cnt=self.df.select('customer').distinct().count()))
        self.df = self.limit_alcoholic_drinks_recommendations(df=self.df,
                                                              level=
                                                              self.allocation_rules[
                                                                  'allocation_key_attribute'])


    def customer_bifurcation(self):
        """
        infill recommendations in self.df at required number for each customer, optionally infilling with infill type
        offers and optionally removing all customers with less than the minimum number of offers, based on rules in
        self.allocation_rules dict, eg:

        The dict should contain keys:
            ranking_column
            infill_type - may be None to disable infilling with second offer type
            infill_cap
            minimum_offers - may be None to disable applying minimum recommendations threshold
            allocation_key - it will be true if allocate the promotion to category directly not drectly to customer
            allocation_key_attribute - attribute to which promotion/product need to allocate
            generic_infilling_required - will be true if generic infilling is required

        """

        allocation_value_attribute = self.allocation_rules[
            'allocation_value_attribute']
        allocation_key_attribute = self.allocation_rules[
            'allocation_key_attribute']
        self.offer_cap = self.generic_table['offer_cap']


        if allocation_key_attribute:
            logger.info(
                "Allocation key is {att}".format(att=allocation_key_attribute))

        # Separating Customer-allocation_key_attribute combinations which require infilling from those that don't

        keep = self.df.groupBy(
            *[self.df[key] for key in ['customer', allocation_key_attribute] if
              key]).agg(
            countDistinct(allocation_value_attribute).alias(
                "count_distinct_%s" % allocation_value_attribute))

        cond = [key for key in ['customer', allocation_key_attribute] if key]
        self.df = self.df.join(keep, cond, "inner")

        self.df.persist(StorageLevel.MEMORY_AND_DISK)
        self.max_offer_cap_df = self.df.where(
            self.df[
                "count_distinct_%s" % allocation_value_attribute] >= self.offer_cap)
        logger.info("QA : max offer df count is  :{}".format(self.max_offer_cap_df.count()))
        self.infilling_df = self.df.where(self.df[
                                              "count_distinct_%s" % allocation_value_attribute] < self.offer_cap)
        logger.info("QA : infill df required count is  :{}".format(self.infilling_df.count()))
        all_customers = self.scores_df.select('customer').drop_duplicates()

        self.number_of_customers_scored = all_customers.count()
        self.number_of_customers_allocated_less_than_offer_cap = self.infilling_df.select(
            [self.infilling_df[column] for column in
             ['customer', allocation_key_attribute] if
             column]).distinct().count()
        self.number_of_customers_allocated_more_than_offer_cap = self.max_offer_cap_df.select(
            [self.infilling_df[column] for column in
             ['customer', allocation_key_attribute] if
             column]).distinct().count()
        # logger.info("Number of customers scored {cnt}".format(
        #     cnt=self.number_of_customers_scored))
        logger.info(
            "QA : Number of customer-{key} allocated more than offer cap  {cnt}".format(
                key=allocation_key_attribute,
                cnt=self.number_of_customers_allocated_more_than_offer_cap))
        logger.info(
            "QA : Number of customer-{key} allocated less than offer cap {cnt}".format(
                key=allocation_key_attribute,
                cnt=self.number_of_customers_allocated_less_than_offer_cap))

        # dropping count columns
        self.max_offer_cap_df = self.max_offer_cap_df.drop(
            self.max_offer_cap_df[
                "count_distinct_%s" % allocation_value_attribute])
        self.infilling_df = self.infilling_df.drop(
            self.infilling_df["count_distinct_%s" % allocation_value_attribute])

        # Creating relevance scores for customers that don't require infilling
        if self.number_of_customers_allocated_more_than_offer_cap > 0:
            self.max_offer_cap_df = self.max_offer_cap_df.repartition(
                *[key for key in [1050, 'customer', allocation_key_attribute,
                                  allocation_value_attribute] if key])
            self.max_offer_cap_df = self.generate_offer_position(
                df=self.max_offer_cap_df, level=self.allocation_rules[
                    'allocation_key_attribute'])
            self.max_offer_cap_df = self.create_relevancy_score(
                df=self.max_offer_cap_df)
            self.max_offer_cap_df = self.create_offer_relevancy_score(
                df=self.max_offer_cap_df,
                level=self.allocation_rules[
                    'allocation_key_attribute'])
            self.max_offer_cap_df.persist(StorageLevel.MEMORY_AND_DISK)


        self.customer_that_dont_need_infilling = self.max_offer_cap_df.select(
            [column for column in ['customer', allocation_key_attribute] if
             column]).distinct()
        self.customer_that_dont_need_infilling = self.customer_that_dont_need_infilling.withColumn(
            'need_infilling', F.lit(0))
        cond = [key for key in ['customer', allocation_key_attribute] if key]
        all_customers = all_customers.join(self.customer_that_dont_need_infilling,
                                           cond, 'left')
        all_customers = all_customers.na.fill(1, 'need_infilling')
        self.all_customers_that_need_infilling = all_customers.where(
            all_customers['need_infilling'] == 1).drop(
            'need_infilling')
        logger.info("QA : customers that need infilling : {}".format(self.all_customers_that_need_infilling.count()))


    def get_generic_df(self):

            """
            "generic_view":
                 {
                "feature_db": "cno_pob",
                "feature_view": "v_cadenceattributefis_week_id_channelall_customerall_productproduct_storeall_current",
                "select_column" : ["channelall_customerall_productproduct_storeall_baskets_1w4w","product"],
                "Promotion_Directly_allocate_To_Customer": false,
                "offer_cap":50,
                "allocation_key_attribute": "Banner",
                "database_prefix": "cno",
                "product_module": "coop_no.cmp_entities.products",
                "product_class" : "Products",
                "product_columns" : ["Product","InstoreSubAisle"],
                "rename_columns" : ["product","InstoreSubAisle"],
    "allocation_key_filter":true
                }

            :return: self.generic_df

            """
            if not self.allocation_rules['generic_infilling_required']:
                logger.info('No Generic Infilling Required')
                return

            required_generic_table_keys = ['feature_db', 'feature_view',
                                           'select_column', 'sensitive_attribute',
                                           'sensitive_attribute_values',
                                           'Promotion_Directly_allocate_To_Customer',
                                           'offer_cap', 'allocation_key_attribute',
                                           'allocation_value_attribute', 'cadence']

            missing_group_keys = [key for key in required_generic_table_keys if
                                  key not in required_generic_table_keys]
            if len(missing_group_keys) > 0:
                raise RuntimeError(
                    'Required keys missing from generic_table object: {0}'.format(
                        missing_group_keys))

            feature_view = self.generic_table.get('feature_view')
            feature_db = self.generic_table['feature_db']
            select_column = self.generic_table['select_column']
            Promotion_Directly_allocate_To_Customer = self.generic_table[
                'Promotion_Directly_allocate_To_Customer']
            offer_cap = self.generic_table['offer_cap']
            allocation_key_attribute = self.generic_table[
                'allocation_key_attribute']
            allocation_value_attribute = self.generic_table[
                'allocation_value_attribute']
            allocation_key_filter = self.generic_table['allocation_key_filter']
            product_module = self.generic_table['product_module']
            product_class = self.generic_table['product_class']
            product_columns = self.generic_table['product_columns']
            rename_columns = self.generic_table['rename_columns']
            cadence = self.generic_table['cadence']

            module = __import__(product_module, fromlist=[product_class])
            product_class = getattr(module, product_class)
            product_df = product_class().data

            self.offer_cap = offer_cap

            product_df = product_df.select(product_columns)

            product_df = spark_tools.rename_df_columns(input_df=product_df,
                                                       select_columns=product_columns,
                                                       rename_columns=rename_columns)

            customer_df = self.customer_df.select("Customer", col("PreferredStore1").alias("store"))
            required_customers_for_infilling = customer_df.join(self.all_customers_that_need_infilling, ["Customer"])


            # This is the new change that has been implemented to set values to the null columns.
            # This is being achieved using monotonically increasing id instead of windowing which helps
            # in improving performance.
            for field in product_df.schema.fields:
                product_df = product_df.withColumn(field.name, F.coalesce(
                    product_df[field.name], lit(F.monotonically_increasing_id())))


            table = feature_db + '.' + feature_view
            logger.info('Reading table form view: {0}'.format(table))
            query = "select max({cadence}) from {database}.{feature_tab}".format(cadence=cadence, database=feature_db,
                                                                                 feature_tab=feature_view)
            latest_cadence = self.sqlContext.sql(query).collect()[0].asDict().values()[0]
            logger.info('Latest cadence is : {0}'.format(latest_cadence))
            self.generic_df = self.sqlContext.table(table).where(
                "{cadence} = {latest_cadence}".format(latest_cadence=latest_cadence, cadence=cadence)).select(select_column)

            # ranking the products on popularity
            # TODO replace index reference to feature column with named reference

            # This is also new implementation where we have removed the window function and used baskets as rank
            # achieved the same by just changing the the mathematical operator while assigning score.
            self.generic_df = self.generic_df.withColumnRenamed(
                select_column[0], 'baskets').withColumn("rank", col("baskets"))

            # joining the self.generic_df with promo_df based on product attribute
            # getting the promos from the promo entity.
            self.generic_df = self.generic_df.join(product_df, ["product"])

            cond = self.generic_df['product'] == self.promo_df['Product']
            self.generic_df = self.generic_df.join(self.promo_df, cond,
                                                   "inner").drop(self.promo_df['Product'])

            # adding customer id column with value "0000" for unknown customer
            # commenting the line below as we have already associated customer in generic df now.
            self.generic_df = self.generic_df.withColumn('Customer',
                                                         lit("0000").cast(
                                                             pt.StringType()))

            # Applying exclusion rule to remove the blacklisted products/promotions
            self.generic_df = self.apply_exclusions(exclusion_df=self.generic_df)
            # Applying conditional inclusions rule -- Need to check the code of this rule as it is not applied to any market as now.
            self.generic_df = self.apply_conditional_inclusions(df=self.generic_df)
            # Needs to apply sensitive_products_exclusion rule however, as per discussion with PM, removing all the sensitive product as for generic#  product we have no records either customer baught that product in desired duration or not.

            if self.sensitivity_rules is None:
                logger.info(
                    'No sensitivity exclusions to apply for generic recommandation')
            else:

                logger.info('Applying sensitivity exclusions')

                for sensitivity_rule in self.sensitivity_rules["rules"]:
                    logger.info("Applying sensitivity rule {rule_name}".format(
                        rule_name=sensitivity_rule))
                    product_attribute = \
                        self.sensitivity_rules["rules"][sensitivity_rule][
                            'product_attribute']

                    dimension_filters = \
                        self.sensitivity_rules['rules'][sensitivity_rule][
                            'dimension_filters']

                    for dimension_filter in dimension_filters:
                        substring_length = \
                            self.sensitivity_rules['rules'][sensitivity_rule][
                                'dimension_filters'][
                                dimension_filter].get('substring_length', False)
                        value = self.sensitivity_rules['rules'][sensitivity_rule][
                            'dimension_filters'][
                            dimension_filter].get('value', False)

                        if substring_length:
                            try:
                                substring_length = int(substring_length)
                            except ValueError:
                                raise ValueError(
                                    'substring_length value of \'{0}\' not castable to int'.format(
                                        substring_length))
                            for value in value:
                                if len(value) != substring_length:
                                    logger.warning(
                                        'Value of \'{0}\' does not match substring_length of \'{1}\''.format(
                                            value,
                                            substring_length))

                            logger.info("### Applying condition on {filter}".format(
                                filter=product_attribute))

                            self.generic_df = self.generic_df.filter(
                                ~self.generic_df[product_attribute].substr(1,
                                                                           substring_length).isin(
                                    value))

                        else:
                            self.generic_df = self.generic_df.filter(
                                ~self.generic_df[product_attribute].isin(
                                    value))

            # getting score based on ranking
            self.generic_df = self.generic_df.withColumn('score',
                                                         format_string("%.8f",
                                                                       lit(
                                                                           -999999999 - self.generic_df.rank).cast(
                                                                           pt.DoubleType())))

            self.generic_df = self.generic_df.withColumn("type", lit(3))
            # Applying required_diversity &  alcoholic_drinks_recommendations rule

            self.generic_df = self.apply_required_diversity(df=self.generic_df,
                                                            level="Store")
            self.generic_df = self.limit_alcoholic_drinks_recommendations(
                df=self.generic_df, level=self.allocation_rules[
                    'allocation_key_attribute'])

            rename_columns.remove('product')
            # TODO add customer, type
            self.generic_df = self.generic_df.select(
                [key for key in
                 ["Customer", "Product", "Store", "Promotion", allocation_key_attribute, "rank",
                  "PromotionStartDatetime", "PromotionEndDatetime", "score", "type"] + rename_columns
                 if key])

            # setting the level to Store for Meijer's
            self.generic_df = self.generate_offer_position(
                df=self.generic_df,
                level="Store")
            self.generic_df = self.create_relevancy_score(
                df=self.generic_df)
            self.generic_df = self.create_offer_relevancy_score(
                df=self.generic_df, level="Store")

            temp_generic_df = self.generic_df.select("Promotion", "Store", "offerrelevance")
            temp_generic_df = temp_generic_df.withColumn(
                    "%s_rank" % allocation_value_attribute,
                    row_number().over(
                        Window.partitionBy(*[key for key in
                                             ['Store'
                                              ]
                                             if key]).orderBy(
                            temp_generic_df["offerrelevance"].desc(),
                            temp_generic_df[
                                allocation_value_attribute].asc())))

            temp_generic_df = temp_generic_df.filter(col(allocation_value_attribute + "_rank") <= self.offer_cap)
            temp_generic_df = temp_generic_df.select(col("Promotion").alias("Promotion"), col("Store").alias("Store"))
            self.generic_df = self.generic_df.join(temp_generic_df, ["Promotion", "Store"])
            self.generic_df = self.generic_df.drop('customer')
            self.generic_df = self.generic_df.join(required_customers_for_infilling, ["store"])

            logger.info(
                "Number of records in generic customer dataframe {cnt}".format(
                    cnt=self.generic_df.count()))

            self.generic_df.persist()
            logger.info(
                "QA : Final Number of customers in generic df {cnt}".format(
                    cnt=self.generic_df.select('Customer').distinct().count()))


    def infilling(self):
        """
        infill recommendations in self.df at required number for each customer, optionally infilling with infill type
        offers and optionally removing all customers with less than the minimum number of offers, based on rules in
        self.allocation_rules dict, eg:

        The dict should contain keys:
            ranking_column
            infill_type - may be None to disable infilling with second offer type
            infill_cap
            minimum_offers - may be None to disable applying minimum recommendations threshold
            allocation_key - it will be true if allocate the promotion to category directly not drectly to customer
            allocation_key_attribute - attribute to which promotion/product need to allocate
            generic_infilling_required - will be true if generic infilling is required

        """
        if not self.allocation_rules['generic_infilling_required']:
            logger.info('No Generic Infilling Required')
            return

        allocation_value_attribute = self.allocation_rules[
            'allocation_value_attribute']
        allocation_key_attribute = self.allocation_rules[
            'allocation_key_attribute']

        if allocation_key_attribute:
            logger.info(
                "Allocation key is {att}".format(att=allocation_key_attribute))

        # Separating Customer-allocation_key_attribute combinations which require infilling from those that don't


        generic_allocations_for_those_who_need_it = self.generic_df.withColumn(
            'Sponsored', F.lit(0)). \
            withColumnRenamed('Product', 'product'). \
            withColumnRenamed('Customer', 'customer').\
            drop("score")

        logger.info("QA : Number of customers allocated less than offer cap : {}".format(self.number_of_customers_allocated_less_than_offer_cap))

        if self.number_of_customers_allocated_less_than_offer_cap > 0:
            # Ensure consistent score for each customer-product pair
            logger.info("creating customer_product_relevancy_scores")
            customer_product_relevancy_scores = self.infilling_df.select(
                'customer', 'product',
                'score').drop_duplicates(
                ['customer', 'product'])

            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.join(
                customer_product_relevancy_scores, ['customer', 'product'],
                'left')
            logger.info("QA : Number of customers after left joining generic df and infilling df {cnt}".format(
                    cnt=generic_allocations_for_those_who_need_it.select('customer').distinct().count()))
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
                "score",
                when(
                    generic_allocations_for_those_who_need_it[
                        "score"].isNull(),
                    format_string(
                        "%.8f",
                        lit(
                            -999999999 - generic_allocations_for_those_who_need_it.rank).cast(
                            pt.DoubleType()))).otherwise(
                    generic_allocations_for_those_who_need_it[
                        "score"]))

        else:
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
                "score",
                format_string(
                    "%.8f",
                    lit(
                        -999999999 - generic_allocations_for_those_who_need_it.rank).cast(
                        pt.DoubleType())))

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.drop(
            generic_allocations_for_those_who_need_it['rank'])

        # ensuring only one generic allocation per customer-allocation_key_attribute(if any)-allocation_value_attribute

        """

        ## Commented because of Norway changes - As currently it is not 
        ##impacting shoprite market. If in future Infilling and this feature  
        ##will be required for other market, then at that time we have to 
        #make it configured 

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
            "allocation_rank", row_number().over(Window.partitionBy(
                *[key for key in ["customer", allocation_key_attribute, allocation_value_attribute] if key]).orderBy(
                generic_allocations_for_those_who_need_it['score'].asc())))

        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.where(
            generic_allocations_for_those_who_need_it['allocation_rank'] == 1).drop(
            generic_allocations_for_those_who_need_it["allocation_rank"])

        """

        # Setting all missing columns from generic allocations dataframe to null before union
        missing_columns = [field_name for field_name in [field.name for field in
                                                         self.infilling_df.schema.fields]
                           if field_name not in [field.name for field in
                                                 generic_allocations_for_those_who_need_it.schema.fields]]

        logger.info(
            'The following columns are present in infilling and absent in generic allocations df :%s' % missing_columns)

        for column in missing_columns:
            generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.withColumn(
                column,
                F.lit(
                    None))

        # Re-order columns in generic allocations dataframe to match the order in infilling df
        generic_allocations_for_those_who_need_it = generic_allocations_for_those_who_need_it.select(
            self.infilling_df.schema.names)

        # Append generic allocations to relevant allocations
        # self.infilling_df = self.infilling_df.unionAll(generic_allocations_for_those_who_need_it)

        self.infilling_df = \
            generic_allocations_for_those_who_need_it.unionAll(
                self.infilling_df)

        # Choose only one allocation per customer,allocation_key_attribute,product.
        # Filtering out customer, product pairs which are already allocated in RP.
        self.infilling_df = self.infilling_df.withColumn("Promotion_rank",
                                                         row_number().over(
                                                             Window.partitionBy(
                                                                 *[key for key
                                                                   in
                                                                   ["customer",
                                                                    allocation_key_attribute,
                                                                    "product"]
                                                                   if
                                                                   key]).orderBy(
                                                                 self.infilling_df[
                                                                     'type'].asc())))
        self.infilling_df = self.infilling_df.where(
            self.infilling_df['Promotion_rank'] == 1).drop(
            self.infilling_df["Promotion_rank"])

        # If an allocation_value has been allocated as relevant don't allocate it again as generic
        self.infilling_df = self.infilling_df.withColumn(
            "%s_rank" % allocation_value_attribute, dense_rank().over(
                Window.partitionBy(
                    *[key for key in ["customer", allocation_key_attribute,
                                      allocation_value_attribute] if
                      key]).orderBy(
                    self.infilling_df['type'].asc())))
        self.infilling_df = self.infilling_df.where(
            self.infilling_df[
                "%s_rank" % allocation_value_attribute] == 1).drop(
            self.infilling_df["%s_rank" % allocation_value_attribute])

        self.infilling_df = self.apply_required_diversity(df=self.infilling_df,
                                                          level=
                                                          self.allocation_rules[
                                                              'allocation_key_attribute'])
        self.infilling_df = self.limit_alcoholic_drinks_recommendations(
            df=self.infilling_df,
            level=self.allocation_rules[
                'allocation_key_attribute'])
        self.infilling_df = self.generate_offer_position(df=self.infilling_df,
                                                         level=
                                                         self.allocation_rules[
                                                             'allocation_key_attribute'])
        self.infilling_df = self.create_relevancy_score(df=self.infilling_df)
        self.infilling_df = self.create_offer_relevancy_score(
            df=self.infilling_df,
            level=self.allocation_rules['allocation_key_attribute'])

        self.infilling_df.persist(StorageLevel.MEMORY_AND_DISK)
        logger.info("Infilling done! Number of count in infilling df {cnt}".format(cnt=self.infilling_df.count()))
        logger.info("QA : Final Number of customers in infilling df {cnt}".format(
                cnt=self.infilling_df.select('customer').distinct().count()))



    def qa_stats(self, path):
        """
        Logs the QA Stats
        :return:
        """
        self.join_promo_df.persist()

        logger.info("Number of customers after capping {cnt}".format(
            cnt=self.df.select('customer').distinct().count()))

        num_promotion_per_num_of_customer = self.df.select("customer", "Promotion") \
            .distinct().groupBy("customer").count().withColumnRenamed("count", "Promotioncount").groupBy(
            "Promotioncount").count().withColumnRenamed("count", "Customer_count").orderBy("Customer_count")
        # num_promotion_per_num_of_customer.coalesce(100)
        spark_tools.write_csv_to_hdfs(num_promotion_per_num_of_customer.coalesce(100),
                                      path + "/num_promotion_per_num_of_customer_qa_stats")

        logger.info(
            "Distinct active customers in the scoring table: {0}".format(
                self.scores_df.select(self.customer_key).distinct().count()))

        logger.info(
            "Number of distinct promotions in product_on_promotion_in_store entity {cnt}".format(
                cnt=self.promo_total))
        logger.info(
            "Number of distinct Products after joining scoring and get_best_promotion_for_a_product's data frame {cnt}".format(
                cnt=self.join_promo_df.select("product").distinct().count()))
        logger.info(
            "Number of distinct Promotions after joining scoring and get_best_promotion_for_a_product's dataframe {cnt}".format(
                cnt=self.join_promo_df.select("Promotion").distinct().count()))

        self.join_promo_df.unpersist()


    def add_storeRegion(self):
        self.df = self.df.drop("StoreRegion")
        store_df = self.store_df.select("Store", "storeregion")
        self.df = self.df.join(store_df, ["Store"]).drop(store_df.Store)

    def add_origin_id(self):
        self.df = self.df.withColumn("origin_id", lit("0"))

    def add_infilled_type(self):
        self.df = self.df.withColumn("InfilledType", lit("Offer"))


    def enforce_schema(self):
        print "Enforcing required final schema"
        self.df = spark_tools.rename_df_columns(input_df=self.df,
                                      select_columns=self.final_columns,
                                      rename_columns=self.allocation_dis)


    def apply_required_diversity(self, df, level=None):

        """Apply required diversity rules to self.df/generic_df, based on self.required_diversity_rules, which should be a list
        of dicts indicating column and diversity count, eg:

        [
            {"column":"product_subgroup", "count": 2}
        ],

        For each column in the list:
            rank self.df by descending self.score_column, partitioned by
            self.customer_key and column specified, and keep only the top N
            ranked Promotion in each partition.

            So, in the example above, top two ranked promotion per
            product_subgroup

        If self.required_diversity_rules is None or zero length no required diversity rules will be applied.
        """
        if self.required_diversity_rules is None or len(
                self.required_diversity_rules) == 0:
            logger.info('No required diversity rules to apply')
            return df

        if not isinstance(self.required_diversity_rules, list):
            raise ValueError(
                'required_diversity_rules is not a list: {0}'.format(
                    self.required_diversity_rules))

        check_columns = list()
        for d in self.required_diversity_rules:
            if not isinstance(d, dict):
                raise ValueError(
                    'Each element in required_diversity_rules should be a dict: {0}'.format(
                        d))
            required_keys = ['column', 'count']
            missing_keys = [key for key in required_keys if key not in d.keys()]
            if len(missing_keys) > 0:
                raise RuntimeError(
                    'Required keys missing from element of required_diversity_rules object: {0}'
                        .format(missing_keys))
            check_columns.append(d['column'])
        spark_tools.check_columns(df, check_columns)

        df.printSchema()
        for diversity_rule in self.required_diversity_rules:
            diversity_column = diversity_rule['column']
            diversity_count = diversity_rule['count']

            logger.info(
                'Applying required diversity rule: keeping only top {0} ranked recommendation(s) for each {1}'
                    .format(diversity_count, diversity_column))
            if diversity_column.lower() == 'promotion':
                print "in the new promotion logic"
                for i in range(0, 32):
                    rank_col = 'req_div_rank_col' + str(i)
                    if rank_col not in df.columns:
                        break
                    rank_col = None
                if rank_col is None:
                    raise RuntimeError(
                        'Unable to come up with a name for the required diversity ranking column not in input_df.columns:'
                            .format(df.columns)
                    )

                order_by_columns = [df[self.score_type_column].asc(),
                                    df[self.score_column].desc()]
                window_spec = Window.partitionBy(
                    *[df[column] for column in
                    [self.customer_key, diversity_column, level] if
                    column]).orderBy(
                    order_by_columns)
                df = df.withColumn(rank_col, row_number().over(window_spec))
                df = df.filter(df[rank_col] <= lit(diversity_count)).drop(
                    df[rank_col])
            else:
                w = Window.partitionBy("customer", "Promotion").orderBy(col(
                    "score").desc())
                df = df.withColumn("product_rank", max(df['score']).over(w))
                df = df.withColumn("promotion_rank", dense_rank().over(
                    Window.partitionBy('customer', 'Group').orderBy(df['product_rank'].desc(), df["Promotion"].desc())))
                df = df.drop(df.product_rank)

                df = df.filter(df["promotion_rank"] <= lit(diversity_count)).drop(
                    df['promotion_rank'])
        logger.info("Number of records after diversity rule {cnt}".format(
            cnt=df.count()))
        return df


    def allocate(self, path):
        self.get_entity()
        self.get_promos()
        self.get_banners()
        self.get_best_promotion_for_a_product()
        self.get_scores()
        self.adding_product_hierarchy()
        self.rp_allocation()
        self.customer_bifurcation()
        self.get_generic_df()
        self.infilling()
        self.capping_recommendations()
        self.add_storeRegion()
        self.add_origin_id()
        self.add_infilled_type()
        self.qa_stats(path)
        self.enforce_schema()
        self.df.printSchema()
        self.df.show()
        self.write_results_to_hdfs(path)
