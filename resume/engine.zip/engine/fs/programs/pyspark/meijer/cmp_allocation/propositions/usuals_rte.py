"""
Meijers usuals proposition module
"""

import logging
import tools.configs as config
from dunnhumby.cmp_allocation.propositions import usuals
from pyspark.sql.functions import col, lit

LOGGER = logging.getLogger(__name__)


class UsualsAllocation(usuals.UsualsAllocation):
    """
    Inheriting base usual module to use common functionality for every client.
    We can override or create client specific methods in this module.
    """

    def __init__(self, config_file, algorithm, variation):
        super(UsualsAllocation, self).__init__(config_file, algorithm, variation)
        self.config_ = config_file
        self.full_config = config.Config().add_source_file(config_file)
        self.store_region = self.full_config.get_item(keys=(algorithm, 'store_region_rules'), mandatory=True)
        self.recommendations = self.full_config.get_item(keys=(algorithm, 'outputs', 'recommendations'), mandatory=True)
        self.select_columns = self.recommendations['columns']
        self.sort_columns = self.recommendations['sort_columns']

    def column_department_addition(self):
        """
        adding the Department column from the product entity
        :return:
        """
        pass

    # create the usual flag rules to identify consumption pattern for certain products
    # and influence the offer positions.

    def create_usuals_flag(self):
        """
        create the usual flag rules to identify consumption pattern for certain products
        and influence the offer positions.
        """
        pass

    def column_sponsored_addition(self):
        """
        adding the column sponsored with null value
        :return:
        """
        self.df = self.df.withColumn("sponsored", lit(0))

    def adding_product_hierarchy(self):
        """
        adding variable from product entity to apply the business rule.

        """
        self.product_df.printSchema()
        product_df = self.product_df.select('Product', 'Subgroup', 'Group', 'Department', 'Division').withColumnRenamed(
            "Product", 'product').withColumnRenamed("Subgroup", 'product_subgroup').withColumnRenamed("Group",
                                                                                                      'product_group').withColumnRenamed(
            "Department", 'department')
        self.df = self.df.join(product_df, ['product']).drop(product_df['product'])
        self.df.select(
            ['customer', 'product', 'product_subgroup', 'product_group', 'score', 'department', 'type', 'Division'])

        self.df.printSchema()

    def add_store(self, df):
        """
        adding store and storeregion using features at Product customer store level for 8 weeks.
        :return: df
        """

        if (self.store_region != None):
            cadence = self.store_region['cadence']
            database = self.store_region['store_region_db']
            feature_tab = self.store_region['feature_used']
            query = "select max({cadence}) from {database}.{feature_tab}".format(cadence=cadence, database=database,
                                                                                 feature_tab=feature_tab)
            latest_cadence = self.sqlContext.sql(query).collect()[0].asDict().values()[0]

            store_region_df = self.sqlContext.table(
                "{database}.{feature_tab}".format(database=database, feature_tab=feature_tab)).where(
                "{cadence} = {latest_cadence}".format(latest_cadence=latest_cadence, cadence=cadence)).select('product', 'customer', 'store')

            prelim_df = df.join(store_region_df, ['customer', 'product'], 'inner').drop(df['Store'])
            store_df = self.store_df.select('store', 'storeregion').dropDuplicates()
            final_df = prelim_df.join(store_df, ['store'], 'inner').drop(store_df['store']).drop(
                prelim_df['StoreRegion'])
            final_df = final_df.dropDuplicates(['customer', 'product', 'store'])
            return final_df


    def keep_prefferd_store_only(self, df):
        """
        filtering exploded data from add_store. Filter is on prefered customere store.
        :return: df
        """
        if (self.store_region != None):
            cust_df = self.customer_df.select('customer', col('PreferredStore1').alias("Store")).dropDuplicates()
            final_df = cust_df.join(df, ['customer', 'Store'], 'inner').drop(df['Store'])
            return final_df

    def enforce_schema(self, df, select_columns):
        return df.select(select_columns)


    def allocate(self, path):
        self.get_entity()
        self.get_scores()
        self.df = self.scores_df
        self.column_department_addition()
        self.adding_product_hierarchy()
        self.get_banners()
        self.df = self.apply_exclusions(show_counts=False, exclusion_df=self.df)
        self.df = self.apply_conditional_inclusions(df=self.df)
        self.apply_sensitive_products_exclusion()
        self.df = self.apply_required_diversity(df=self.df)
        self.create_usuals_flag()
        #self.df = self.keep_prefferd_store_only(self.df)
        self.df = self.generate_offer_position(df=self.df)
        self.df = self.create_relevancy_score(df=self.df)
        self.df = self.add_store(self.df)
        self.column_sponsored_addition()
        self.cap_and_infill_recommendations()
        #self.detailed_qualitycheck()
        self.df.printSchema()
        self.df = self.enforce_schema(self.df, self.select_columns)
        self.df.printSchema()
        self.df.show()
        self.write_results_to_hdfs(path)
