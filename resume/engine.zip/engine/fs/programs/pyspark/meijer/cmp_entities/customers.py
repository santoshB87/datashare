""""
meijer Customers
"""
import logging
import pyspark.sql.types as pt
import dunnhumby
from meijer import database

logger = logging.getLogger(__name__)


class Customers(dunnhumby.cmp_entities.customers.Customers):
    """
    Inherits the base CMP Customer class and implements the get_data() method'
    """

    def __init__(self):
        """
        Define the Customers schema and column or columns that uniquely define a Customer
        """
        super(Customers, self).__init__()

        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Customer', pt.StringType(), True))
        required_schema.add(pt.StructField('FulfillmentStore', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore1', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore2', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore3', pt.StringType(), True))

        self.required_schema = required_schema
        self.get_data()

    @property
    def database(self):
        return database