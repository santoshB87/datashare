"""
Monoprix-specific CMP
"""
import logging
import monoprix.cmp_entities
import cmp_entities
import cmp_audience_selection_integration

logger = logging.getLogger(__name__)
