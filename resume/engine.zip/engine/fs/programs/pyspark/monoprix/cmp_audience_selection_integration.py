"""
CMP and audience selection integration
All the information herein is true at the time of writing (2018-02-09 initially when this script had
written on science server notebook ) however is subject to change, especially as Audience Selection
is a work-in-progress
Audience Selection is a solution consisting of an API (built in .Net) atop a postgres database. The
main table in that postgres database is called features.customerproductstorechannelfeatures.
Most of its columns match columns in CMP's features table, with a few additions specifically for
Audience Selection.
"""

import abc
import logging
import six

from pyspark.sql.types import *
from pyspark.sql.functions import col, row_number, when, instr, current_date, date_add, udf, max, \
    lit, dense_rank, countDistinct, format_string, count, desc, round, max, coalesce, sum, md5
from datetime import datetime, timedelta
from dunnhumby import contexts
from pyspark.sql.window import Window
import monoprix.cmp_entities.transactions as transactions
import monoprix.cmp_entities.products as products
import monoprix.cmp_entities.customers as customers

logger = logging.getLogger(__name__)


class GenerateCsvForAudienceSelection(object):
    """
    This class is intend to write some common functions used in different inherited classes to
    generating audience selection CSVs.
    """

    def __init__(self, config):
        self.config = config
        self.sqlContext = contexts.sql_context()
        self.feature_database = '{sse_hive_database_prefix}_pob'.format(
            sse_hive_database_prefix=config['SSEHiveDatabasePrefix'])
        self.cadence_date = config['cadence_date']

    def get_feature_data(self, feature_view_name, columns=None, hivequery=None, datab=None):
        """
        This function use to create feature df with selected columns
        :param feature_view_name: Name of feature view i.e. v_cadenceattributefis_
        week_id_channelall_customerall_productproduct_storeall_current
        :param columns: this take a list of columns e.g. [c1, c2, c3]
        :return: return required feature df
        """
        if datab:
            feature_database = datab
        else:
            feature_database = self.feature_database
        if hivequery:
            df = self.sqlContext.sql(hivequery)
        else:
            df = self.sqlContext.table('{database}.{feature_view}'.format(database=feature_database,
                                                                          feature_view=feature_view_name))
            if columns:
                df = df.select(columns)

        return df

    @staticmethod
    def write_csv_to_hdfs(input_df, hdfs_path, file_format='com.databricks.spark.csv',
                          file_saveMode='overwrite'):
        """

        :param input_df:
        :param hdfs_path:
        :param file_format:
        :param file_saveMode:
        :return:
        """
        return input_df.write.mode(file_saveMode).format(file_format).option('nullValue', '').save(
            hdfs_path, )

    def generate_audience_data_for_product_all_grain(self, path):
        """
        This function returns the df after making all the required changes and adding addition
        columns.
        :return: dataframe
        """
        feature_view_name = "product_all_all_all_1w52w"
        latest_cadence = self.cadence_date
        hive_query = "select * from {feature_db}.{feature_view_name} where cadence_week={latest_cadence}".format(
            feature_db=self.feature_database, feature_view_name=feature_view_name,
            latest_cadence=latest_cadence)
        df = self.get_feature_data(feature_view_name, hivequery=hive_query)
        df = df.withColumn('basketsflag_1w52w', when(df.baskets_1w52w > 0, True).otherwise(False))
        df = df.withColumn('customer', when(df.customer.isNotNull(), df.customer).otherwise('All'))
        df = df.withColumn('store', when(df.store.isNotNull(), df.store).otherwise('All'))
        df = df.withColumn('channel', when(df.channel.isNotNull(), df.channel).otherwise('All'))
        df = df.withColumn('customerattribute', lit('All'))
        df = df.withColumn('productattribute', lit('Product'))
        df = df.withColumn('storeattribute', lit('All'))
        df = df.withColumn('channelattribute', lit('All'))
        df = df.select(df.customerattribute, df.customer, df.productattribute, df.product,
                       df.storeattribute, df.store, df.channelattribute, df.channel,
                       df.basketsflag_1w52w, df.baskets_1w52w, lit('').alias('customergender'),
                       lit('').alias('customeragerange'), lit('').alias('customerpricesensitivity'),
                       lit('').alias('CustomerIsEmailable'), lit('').alias('CustomerRegion'),
                       lit('').alias('IsFrequencyIncreaseCandidate'),
                       lit('').alias('IsRewardLoyalCandidate'),
                       lit('').alias('IsIncreaseAverageRevenuePerUserCandidate'),
                       lit('').alias('IsIncreasePenetrationCandidate'),
                       lit('').alias('IsConsumerRecoverCandidate'),
                       lit('').alias('IsProductLaunchCandidate'), lit(1).alias('Tally'),

                       )
        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        product_df = products.Products(config).data
        # Filtering delisted products
        # Conditions of Acceptance (Chris Towl)
        # No products appear in the Monodeal platform that have been delisted by the data the
        # products were uploaded to the postgres db.
        # No Products apear in the Monodeal platform that will be delisted upto 30 days from the
        # date the products were uploaded to postgres db.

        product_df = product_df.filter(product_df.Delist_flag == False)
        # Julie Wojciekowski (Client Solutions Manager for Monoprix)
        # has specified that we only require features for a subset of
        # all products.
        # L24code |           L24name            |     L23name    |  L20code  | L20name
        # -----------------------------------------------------------------------------------------------
        #   CA    | ALIMENTAIRE NON PERISSABLE   | All            | All       | All
        #   CP    | ALIMENTAIRE PERISSABLE       | All            | All       | All
        #   MC    | PARFUMERIE                   | All            | All       | All
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_10 | COLLES ET ADHESIFS
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_50 | ECLAIRAGE
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_98 | EMBALLAGES MENAGERS
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_55 | ENERGIE PORTABLE
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_90 | ACCESSOIRES/SOINS ANIMAUX
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_92 | LITIERE
        #   MB    | MAISON LOISIRS               | MB52-papeterie | MB5252_20 | ECRITURE
        #   MB    | MAISON LOISIRS               | MB52-papeterie | MB5252_30 | ACCESSOIRES DE DESSIN
        #   MB    | MAISON LOISIRS               | MB52-papeterie | MB5252_35 | CAHIER ET COPIES
        # The filters applied below match that spec. Based on today's calculations the tally
        # of products for which we shall be generating features will reduce by ~76%
        # -Jamie Thomson, 2018-01-12.
        product_df = product_df.where(
            product_df.Department.isin('CA', 'CP', 'MC') | product_df.InstoreShelf.isin('MB6767_10',
                                                                                        'MB6767_50',
                                                                                        'MB6767_98',
                                                                                        'MB6767_55',
                                                                                        'MB6767_90',
                                                                                        'MB6767_92',
                                                                                        'MB5252_20',
                                                                                        'MB5252_30',
                                                                                        'MB5252_35'))
        #product_df.persist()
        df = df.join(product_df, df.product == product_df.Product, 'inner').select(
            df.customerattribute, df.customer, df.productattribute, df.product, df.storeattribute,
            df.store, df.channelattribute, df.channel,
            product_df.ProductDescription.alias('productdescription'),
            product_df.Subgroup.alias('subgroup'),
            product_df.SubgroupDescription.alias('subgroupdescription'),
            product_df.Group.alias('group'), product_df.GroupDescription.alias('groupdescription'),
            product_df.Section.alias('section'),
            product_df.SectionDescription.alias('sectiondescription'),
            product_df.Department.alias('department'),
            product_df.DepartmentDescription.alias('departmentdescription'),
            product_df.Division.alias('division'),
            product_df.DivisionDescription.alias('divisiondescription'),
            product_df.ProductBrand.alias('productbrand'), df.basketsflag_1w52w, df.baskets_1w52w,
            product_df.IsAlcohol, df.customergender, df.customeragerange,
            df.customerpricesensitivity, df.CustomerIsEmailable, df.CustomerRegion,
            df.IsFrequencyIncreaseCandidate, df.IsRewardLoyalCandidate,
            df.IsIncreaseAverageRevenuePerUserCandidate, df.IsIncreasePenetrationCandidate,
            df.IsConsumerRecoverCandidate, df.IsProductLaunchCandidate, df.Tally,
            product_df.InstoreShelf, product_df.InstoreShelfDescription, product_df.InstoreAisle,
            product_df.InstoreAisleDescription, product_df.ProductImageUri,
            product_df.IsSoldByWeight, product_df.ProductSupplier)

        df = df.withColumn('NavigationHierarchy',
                           when(instr(df.InstoreAisle, 'MC56') == 1, lit('InStoreShelf')).otherwise(
                               lit('Group')))

        # Adding ModePrice by calculating it from transactions entity
        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        recent_date_df = transactions.Transactions(config).most_recent_transaction_date
        recent_date_13w = recent_date_df.first().most_recent_transaction_date
        recent_date_1w = recent_date_13w - timedelta(days=91)

        transactions_entity = transactions.Transactions(config)

        transactions_df = transactions_entity.data
        transactions_df = transactions_df.join(product_df,
                                               transactions_df.Product == product_df.Product,
                                               'left_semi')
        transactions_df.persist()
        transactions_df_13w = transactions_df.filter(transactions_df.Date >= recent_date_1w).filter(
            transactions_df.Date <= recent_date_13w)
        transactions_df_13w = transactions_df_13w.select('Product', round(
            (transactions_df_13w.NetSpendAmount / transactions_df_13w.Quantity), 2).alias(
            'NetSpend')).groupBy('Product', 'NetSpend').count()
        window = Window.partitionBy("Product").orderBy(desc("count"))
        transactions_df_13w = transactions_df_13w.withColumn('_row_number',
                                                             row_number().over(window))
        transactions_df_13w = transactions_df_13w.filter(
            transactions_df_13w._row_number == 1).select("Product", "NetSpend",
                                                         "count").withColumnRenamed('NetSpend',
                                                                                    'ModePrice').drop(
            "count")

        df = df.join(transactions_df_13w, df.product == transactions_df_13w.Product, 'left').drop(
            transactions_df_13w.Product)

        df.persist()

        # Bringing last sold price for products which are not sold in last 13 weeks
        df_MP_null = df.filter('ModePrice is null')
        prod_notin_13w = df_MP_null.select('product')
        df_with_price = transactions_df.join(prod_notin_13w,
                                             transactions_df.Product == prod_notin_13w.product,
                                             'inner').drop(prod_notin_13w.product)
        window = Window.partitionBy("Product").orderBy(desc("Date"))
        df_with_price = df_with_price.withColumn('_row_number', row_number().over(window))
        df_with_price = df_with_price.filter(df_with_price._row_number == 1).select("Product",
                                                                                    "NetSpendAmount",
                                                                                    "Date")
        df = df.join(df_with_price, df.product == df_with_price.Product, 'left').drop(
            df_with_price.Product)
        df = df.select('*', coalesce(df["ModePrice"], df["NetSpendAmount"])).drop('ModePrice').drop(
            'NetSpendAmount').withColumnRenamed('coalesce(ModePrice,NetSpendAmount)',
                                                'ModePrice').drop('Date')

        df = df.select('*', lit('').alias('QuantityPerPerson_1w52w'))
        df = df.repartition(1)
        #self.write_csv_to_hdfs(df, path)
        return df

    def generate_audience_data_for_multiple_customer_product_grain(self, path):
        """
        This function returns the df after making all the required changes and adding addition
        columns.
        :return: dataframe
        """
        feature_view_name = "product_customer_all_all_1w52w"
        latest_cadence = self.cadence_date
        hive_query = "select hash(customer) as customerhash,* from {feature_db}.{feature_view_name} where cadence_week={latest_cadence} and product is not null".format(
            feature_db=self.feature_database, feature_view_name=feature_view_name,
            latest_cadence=latest_cadence)
        df = self.get_feature_data(feature_view_name, hivequery=hive_query)
        df = df.withColumn('customerattribute', lit('Customer'))
        df = df.withColumn('productattribute', lit('Product'))
        df = df.withColumn('storeattribute', lit('All'))
        df = df.withColumn('channelattribute', lit('All'))
        df = df.withColumn('basketsflag_1w52w', when(df.baskets_1w52w > 0, True).otherwise(False))
        df = df.withColumn('store', when(df.store.isNotNull(), df.store).otherwise('All'))
        df = df.withColumn('channel', when(df.channel.isNotNull(), df.channel).otherwise('All'))
        df = df.filter(df.customer != '')
        df = df.filter(df.product != '')
        df = df.select(df.customerattribute, df.customer, df.productattribute, df.product,
                       df.storeattribute, df.store, df.channelattribute, df.channel,
                       df.basketsflag_1w52w, df.baskets_1w52w)

        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        product_df = products.Products(config).data
        product_df = product_df.filter(product_df.Delist_flag == False)
        product_df = product_df.where(
            product_df.Department.isin('CA', 'CP', 'MC') | product_df.InstoreShelf.isin('MB6767_10',
                                                                                        'MB6767_50',
                                                                                        'MB6767_98',
                                                                                        'MB6767_55',
                                                                                        'MB6767_90',
                                                                                        'MB6767_92',
                                                                                        'MB5252_20',
                                                                                        'MB5252_30',
                                                                                        'MB5252_35'))
        product_df.persist()

        df = df.join(product_df, df.product == product_df.Product, 'inner').select(
            df.customerattribute, df.customer, df.productattribute, df.product, df.storeattribute,
            df.store, df.channelattribute, df.channel, df.basketsflag_1w52w, df.baskets_1w52w,
            product_df.IsAlcohol.alias('productisalcohol'))

        customer_df = customers.Customers(config).data
        customer_df.persist()

        df = df.join(customer_df, df.customer == customer_df.Customer, 'left_outer').select(
            df.customerattribute, df.customer, df.productattribute, df.product, df.storeattribute,
            df.store, df.channelattribute, df.channel, df.basketsflag_1w52w, df.baskets_1w52w,
            df.productisalcohol, customer_df.CustomerGender.alias('customergender'),
            customer_df.CustomerAgeRange.alias('customeragerange'),
            customer_df.CustomerPriceSensitivity.alias('customerpricesensitivity'),
            customer_df.IsEmailable.alias('isemailable'),
            customer_df.CustomerRegion.alias('customerregion'))

        audience_science_df = self.sqlContext.table(
            "{0}.monodeal_audience_science_current".format(self.feature_database))
        df = df.join(audience_science_df, ['customer', 'product'], 'left_outer')
        df = df.groupby('productattribute', 'product', 'storeattribute', 'store',
                        'channelattribute', 'channel', lit('').alias('basketsflag_1w52w'),
                        lit('').alias('baskets_1w52w'), 'productisalcohol', 'customergender',
                        'customeragerange', 'customerpricesensitivity', 'isemailable',
                        'isFrequencyincreasecandidate', 'isrewardloyalcandidate',
                        'isincreaseaveragerevenueperusercandidate',
                        'IsConsumerRecoverCandidate').count().withColumnRenamed('count', 'Tally')
        df = df.select(lit('Multiple').alias('CustomerAttribute'),
                       lit('Multiple').alias('Customer'), 'productattribute', 'product',
                       'storeattribute', 'store', 'channelattribute', 'channel',
                       lit('').alias('productdescription'), lit('').alias('subgroup'),
                       lit('').alias('subgroupdescription'), lit('').alias('group'),
                       lit('').alias('groupdescription'), lit('').alias('section'),
                       lit('').alias('sectiondescription'), lit('').alias('department'),
                       lit('').alias('departmentdescription'), lit('').alias('division'),
                       lit('').alias('divisiondescription'), lit('').alias('productbrand'),
                       'basketsflag_1w52w', 'baskets_1w52w', 'productisalcohol', 'customergender',
                       'customeragerange', 'customerpricesensitivity', 'isemailable',
                       lit('').alias('customerregion'), 'isfrequencyincreasecandidate',
                       'isrewardloyalcandidate', 'isincreaseaveragerevenueperusercandidate',
                       lit('').alias('IsIncreasePenetrationCandidate'),
                       'isconsumerrecovercandidate', lit('').alias('IsProductLaunchCandidate'),
                       'Tally', lit('').alias('InStoreShelf'),
                       lit('').alias('InStoreShelfDescription'), lit('').alias('InStoreAisle'),
                       lit('').alias('InStoreAisleDescription'), lit('').alias('ProductImageUri'),
                       lit('').alias('IsSoldByWeight'), lit('').alias('ProductSupplier'),
                       lit('').alias('NavigationHierarchy'), lit('').alias('ModePrice'),
                       lit('').alias('QuantityPerPerson_1w52w'))

        #self.write_csv_to_hdfs(df, path)
        return df

    def generate_audience_data_for_customer_product_grain(self, path):
        """
        This function returns the df after making all the required changes and adding addition
        columns.
        :return: dataframe
        """
        feature_view_name = "product_customer_all_all_1w52w"
        latest_cadence = self.cadence_date
        hive_query = "select hash(customer) as customerhash,* from {feature_db}.{feature_view_name} where cadence_week={latest_cadence} and product is not null".format(
            feature_db=self.feature_database, feature_view_name=feature_view_name,
            latest_cadence=latest_cadence)
        df = self.get_feature_data(feature_view_name, hivequery=hive_query)
        df = df.withColumn('basketsflag_1w52w', when(df.baskets_1w52w > 0, True).otherwise(False))
        df = df.withColumn('store', when(df.store.isNotNull(), df.store).otherwise('All'))
        df = df.withColumn('channel', when(df.channel.isNotNull(), df.channel).otherwise('All'))
        df = df.withColumn('customerattribute', lit('Customer'))
        df = df.withColumn('productattribute', lit('Product'))
        df = df.withColumn('storeattribute', lit('All'))
        df = df.withColumn('channelattribute', lit('All'))
        df = df.filter(df.customer != '')
        df = df.filter(df.product != '')
        df = df.filter(df.customerhash % 2 == 0)
        df = df.select(df.customerattribute, df.customer, df.productattribute, df.product,
                       df.storeattribute, df.store, df.channelattribute, df.channel)
        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        product_df = products.Products(config).data
        product_df = product_df.filter(product_df.Delist_flag == False)
        product_df = product_df.where(
            product_df.Department.isin('CA', 'CP', 'MC') | product_df.InstoreShelf.isin('MB6767_10',
                                                                                        'MB6767_50',
                                                                                        'MB6767_98',
                                                                                        'MB6767_55',
                                                                                        'MB6767_90',
                                                                                        'MB6767_92',
                                                                                        'MB5252_20',
                                                                                        'MB5252_30',
                                                                                        'MB5252_35'))
        df = df.join(product_df, df.product == product_df.Product, 'left_semi')
        # Passing empty strings (that will get converted to NULLs when imported to postgresql) because we currently
        # don't need any of those columns to be populated for this dataset. Its better to keep the number of bytes as low
        # as possible, because there are a lot of rows. If and when the requirements change we can simply
        # add the logic here accordingly.
        df = df.select('CustomerAttribute', 'Customer', 'productattribute', 'product',
                       'storeattribute', 'store', 'channelattribute', 'channel',
                       lit('').alias('productdescription'), lit('').alias('subgroup'),
                       lit('').alias('subgroupdescription'), lit('').alias('group'),
                       lit('').alias('groupdescription'), lit('').alias('section'),
                       lit('').alias('sectiondescription'), lit('').alias('department'),
                       lit('').alias('departmentdescription'), lit('').alias('division'),
                       lit('').alias('divisiondescription'), lit('').alias('productbrand'),
                       lit('').alias('basketsflag_1w52w'), lit('').alias('baskets_1w52w'),
                       lit('').alias('productisalcohol'), lit('').alias('customergender'),
                       lit('').alias('customeragerange'), lit('').alias('customerpricesensitivity'),
                       lit('').alias('isemailable'), lit('').alias('customerregion'),
                       lit('').alias('isfrequencyincreasecandidate'),
                       lit('').alias('isrewardloyalcandidate'),
                       lit('').alias('isincreaseaveragerevenueperusercandidate'),
                       lit('').alias('IsIncreasePenetrationCandidate'),
                       lit('').alias('isconsumerrecovercandidate'),
                       lit('').alias('IsProductLaunchCandidate'), lit('').alias('Tally'),
                       lit('').alias('InstoreShelf'), lit('').alias('InstoreShelfDescription'),
                       lit('').alias('InstoreAisle'), lit('').alias('InstoreAisleDescription'),
                       lit('').alias('ProductImageUri'), lit('').alias('IsSoldByWeight'),
                       lit('').alias('ProductSupplier'), lit('').alias('NavigationHierarchy'),
                       lit('').alias('ModePrice'))

        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        transactions_entity = transactions.Transactions(config)

        transactions_df = transactions_entity.data

        transactions_df = transactions_df.withColumn('customerhash', md5('Customer'))

        transactions_df = transactions_df.filter(transactions_df.customerhash % 2 == 0)
        transactions_df = transactions_df.select('Customer', 'Product', 'Quantity').groupBy(
            'Customer', 'Product').agg(sum('Quantity').alias('QuantityPerPerson_1w52w'))

        join_cond = [df.product == transactions_df.Product, df.Customer == transactions_df.Customer]

        df = df.join(transactions_df, join_cond, 'left').drop(transactions_df.Product).drop(
            transactions_df.Customer)

        df = df.fillna({'QuantityPerPerson_1w52w': '0'})
        return df
        #self.write_csv_to_hdfs(df, path)

    def generate_audience_data_for_maquillage_non_maquillage(self, maquillage_groups=False,
                                                             non_maquillage_groups=False):
        """
        Create data frame for maquillage and non_maquillage

        :param maquillage_groups:
        :param non_maquillage_groups:
        :return: dataframe
        """
        feature_view_name = "product_all_all_all_1w52w"
        latest_cadence = self.cadence_date
        hive_query = "select * from {feature_db}.{feature_view_name} where cadence_week={latest_cadence} and product is not null".format(
            feature_db=self.feature_database, feature_view_name=feature_view_name,
            latest_cadence=latest_cadence)
        df = self.get_feature_data(feature_view_name, hivequery=hive_query)
        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        product_df = products.Products(config).data
        product_df = product_df.filter(product_df.Delist_flag == False)
        product_df = product_df.where(
            product_df.Department.isin('CA', 'CP', 'MC') | product_df.InstoreShelf.isin('MB6767_10',
                                                                                        'MB6767_50',
                                                                                        'MB6767_98',
                                                                                        'MB6767_55',
                                                                                        'MB6767_90',
                                                                                        'MB6767_92',
                                                                                        'MB5252_20',
                                                                                        'MB5252_30',
                                                                                        'MB5252_35'))
        product_df.persist()
        df = df.join(product_df, df.product == product_df.Product, 'inner')
        if maquillage_groups:
            maquillage_groups_df = df.filter(df.InstoreAisle == 'MC56').select(
                df.Group.alias('group'), df.GroupDescription.alias('groupdescription')).distinct()
            return maquillage_groups_df
        if non_maquillage_groups:
            non_maquillage_instoreshelves_df = df.filter(df.InstoreAisle != 'MC56').select(
                df.InstoreShelf.alias('instoreshelf'),
                df.InstoreShelfDescription.alias('instoreshelfdescription')).distinct()
            return non_maquillage_instoreshelves_df

    def generate_audience_data_for_customer_instoreshelf_grain(self, path):
        """

        :return:
        """
        feature_view_name = "instoreshelf_customer_all_all_1w52w"
        latest_cadence = self.cadence_date
        hive_query = "select hash(customer) as customerhash,* from {feature_db}.{feature_view_name} where cadence_week={latest_cadence}".format(
            feature_db=self.feature_database, feature_view_name=feature_view_name,
            latest_cadence=latest_cadence)
        df = self.get_feature_data(feature_view_name, hivequery=hive_query)
        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        product_df = products.Products(config).data
        product_df = product_df.filter(product_df.Delist_flag == False)
        product_df = product_df.where(
            product_df.Department.isin('CA', 'CP', 'MC') | product_df.InstoreShelf.isin('MB6767_10',
                                                                                        'MB6767_50',
                                                                                        'MB6767_98',
                                                                                        'MB6767_55',
                                                                                        'MB6767_90',
                                                                                        'MB6767_92',
                                                                                        'MB5252_20',
                                                                                        'MB5252_30',
                                                                                        'MB5252_35'))
        df = df.join(product_df, df.instoreshelf == product_df.InstoreShelf, 'left_semi')
        df = df.withColumn('product', df.instoreshelf)
        df = df.withColumn('basketsflag_1w52w', when(df.baskets_1w52w > 0, True).otherwise(False))
        df = df.withColumn('customerattribute', lit('Customer'))
        df = df.withColumn('productattribute', lit('InstoreShelf'))
        df = df.withColumn('storeattribute', lit('All'))
        df = df.withColumn('channelattribute', lit('All'))
        df = df.withColumn('store', when(df.store.isNotNull(), df.store).otherwise('All'))
        df = df.withColumn('channel', when(df.channel.isNotNull(), df.channel).otherwise('All'))
        df = df.filter(df.customer != '')
        df = df.filter(df.product != '')
        df = df.filter(df.customerhash % 2 == 0)
        non_maquillage_instoreshelves_df = self.generate_audience_data_for_maquillage_non_maquillage(
            non_maquillage_groups=True)
        df = df.join(non_maquillage_instoreshelves_df,
                     df.product == non_maquillage_instoreshelves_df.instoreshelf)
        df = df.select(df.customerattribute, df.customer, df.productattribute, df.product,
                       df.storeattribute, df.store, df.channelattribute, df.channel)
        audience_science_table_name = "monodeal_audience_science_penetration_categories_current"
        audience_science_df = self.get_feature_data(audience_science_table_name)
        audience_science_df = audience_science_df.filter(
            audience_science_df.category_attribute == 'InstoreShelf')
        df = df.join(audience_science_df, ((df.customer == audience_science_df.customer) & (
            df.product == audience_science_df.category)), 'left_outer').drop(
            audience_science_df.customer).drop(audience_science_df.category).drop(
            audience_science_df.category_attribute)
        df = df.select('CustomerAttribute', 'Customer', 'productattribute', 'product',
                       'storeattribute', 'store', 'channelattribute', 'channel',
                       lit('').alias('productdescription'), lit('').alias('subgroup'),
                       lit('').alias('subgroupdescription'), lit('').alias('group'),
                       lit('').alias('groupdescription'), lit('').alias('section'),
                       lit('').alias('sectiondescription'), lit('').alias('department'),
                       lit('').alias('departmentdescription'), lit('').alias('division'),
                       lit('').alias('divisiondescription'), lit('').alias('productbrand'),
                       lit('').alias('basketsflag_1w52w'), lit('').alias('baskets_1w52w'),
                       lit('').alias('productisalcohol'), lit('').alias('customergender'),
                       lit('').alias('customeragerange'), lit('').alias('customerpricesensitivity'),
                       lit('').alias('isemailable'), lit('').alias('customerregion'),
                       lit('').alias('isfrequencyincreasecandidate'),
                       lit('').alias('isrewardloyalcandidate'),
                       lit('').alias('isincreaseaveragerevenueperusercandidate'),
                       'IsIncreasePenetrationCandidate',
                       lit('').alias('isconsumerrecovercandidate'),
                       lit('').alias('IsProductLaunchCandidate'), lit('').alias('Tally'),
                       lit('').alias('InstoreShelf'), lit('').alias('InstoreShelfDescription'),
                       lit('').alias('InstoreAisle'), lit('').alias('InstoreAisleDescription'),
                       lit('').alias('ProductImageUri'), lit('').alias('IsSoldByWeight'),
                       lit('').alias('ProductSupplier'), lit('').alias('NavigationHierarchy'),
                       lit('').alias('ModePrice'), lit('').alias('QuantityPerPerson_1w52w'))

        #self.write_csv_to_hdfs(df, path)
        return df

    def generate_audience_data_for_customer_group_grain(self, path):
        """

        :return:
        """
        feature_view_name = "group_customer_all_all_1w52w"
        latest_cadence = self.cadence_date
        hive_query = "select hash(customer) as customerhash,* from {feature_db}.{feature_view_name} where cadence_week={latest_cadence}".format(
            feature_db=self.feature_database, feature_view_name=feature_view_name,
            latest_cadence=latest_cadence)
        df = self.get_feature_data(feature_view_name, hivequery=hive_query)
        config = {'SSEHiveDatabasePrefix': '{sse_hive_database_prefix}'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])}
        product_df = products.Products(config).data
        product_df = product_df.filter(product_df.Delist_flag == False)
        product_df = product_df.where(
            product_df.Department.isin('CA', 'CP', 'MC') | product_df.InstoreShelf.isin('MB6767_10',
                                                                                        'MB6767_50',
                                                                                        'MB6767_98',
                                                                                        'MB6767_55',
                                                                                        'MB6767_90',
                                                                                        'MB6767_92',
                                                                                        'MB5252_20',
                                                                                        'MB5252_30',
                                                                                        'MB5252_35'))
        df = df.join(product_df, df.group == product_df.Group, 'left_semi')
        df = df.withColumn('product', df.group)
        df = df.withColumn('basketsflag_1w52w', when(df.baskets_1w52w > 0, True).otherwise(False))
        df = df.withColumn('customerattribute', lit('Customer'))
        df = df.withColumn('productattribute', lit('Group'))
        df = df.withColumn('storeattribute', lit('All'))
        df = df.withColumn('channelattribute', lit('All'))
        df = df.withColumn('store', when(df.store.isNotNull(), df.store).otherwise('All'))
        df = df.withColumn('channel', when(df.channel.isNotNull(), df.channel).otherwise('All'))
        df = df.filter(df.customer != '')
        df = df.filter(df.product != '')
        df = df.filter(df.customerhash % 2 == 0)
        df = df.select(df.customerattribute, df.customer, df.productattribute, df.product,
                       df.storeattribute, df.store, df.channelattribute, df.channel)
        audience_science_table_name = "monodeal_audience_science_penetration_categories_current"
        audience_science_df = self.get_feature_data(audience_science_table_name)
        audience_science_df = audience_science_df.filter(
            audience_science_df.category_attribute == 'Group')
        df = df.join(audience_science_df, ((df.customer == audience_science_df.customer) & (
            df.product == audience_science_df.category)), 'left_outer').drop(
            audience_science_df.customer).drop(audience_science_df.category).drop(
            audience_science_df.category_attribute)
        df = df.select('CustomerAttribute', 'Customer', 'productattribute', 'product',
                       'storeattribute', 'store', 'channelattribute', 'channel',
                       lit('').alias('productdescription'), lit('').alias('subgroup'),
                       lit('').alias('subgroupdescription'), lit('').alias('group'),
                       lit('').alias('groupdescription'), lit('').alias('section'),
                       lit('').alias('sectiondescription'), lit('').alias('department'),
                       lit('').alias('departmentdescription'), lit('').alias('division'),
                       lit('').alias('divisiondescription'), lit('').alias('productbrand'),
                       lit('').alias('basketsflag_1w52w'), lit('').alias('baskets_1w52w'),
                       lit('').alias('productisalcohol'), lit('').alias('customergender'),
                       lit('').alias('customeragerange'), lit('').alias('customerpricesensitivity'),
                       lit('').alias('isemailable'), lit('').alias('customerregion'),
                       lit('').alias('isfrequencyincreasecandidate'),
                       lit('').alias('isrewardloyalcandidate'),
                       lit('').alias('isincreaseaveragerevenueperusercandidate'),
                       'IsIncreasePenetrationCandidate',
                       lit('').alias('isconsumerrecovercandidate'),
                       lit('').alias('IsProductLaunchCandidate'), lit('').alias('Tally'),
                       lit('').alias('InstoreShelf'), lit('').alias('InstoreShelfDescription'),
                       lit('').alias('InstoreAisle'), lit('').alias('InstoreAisleDescription'),
                       lit('').alias('ProductImageUri'), lit('').alias('IsSoldByWeight'),
                       lit('').alias('ProductSupplier'), lit('').alias('NavigationHierarchy'),
                       lit('').alias('ModePrice'), lit('').alias('QuantityPerPerson_1w52w'))

        #self.write_csv_to_hdfs(df, path)
        return df
