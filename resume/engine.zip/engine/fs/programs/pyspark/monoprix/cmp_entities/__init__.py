"""
Monoprix CMP entities
"""
import logging
logger = logging.getLogger(__name__)
