"""
Monoprix Channels
"""
import dunnhumby
from dunnhumby import contexts
from pyspark.sql import functions as pf, types as pt


# Data will flow into our solution through python classes that we define.
# Initially that data will be sourced from CDM, later it will be sourced
# from Mercury.
# Either way we need an abstraction over those data sources that defines
# the data as SSE requires it.

class Channels(dunnhumby.cmp_entities.channels.Channels):
    """
    Inherits the Base CMP products entity class and overrides the get_data method
    """

    def __init__(self, config, channel_id=False):
        super(Channels, self).__init__()
        self.sqlContext = contexts.sql_context()
        if channel_id:
            required_schema = self.required_schema
            required_schema.add(pt.StructField('channel_id', pt.LongType(), True))
            # TODO: Is there any better way to override parent class variable in child.
            self.required_schema = required_schema
            self.unique_columns = ['channel_id']
        self.config = config
        self.get_data(channel_id)

    def get_data(self, channel_id=False):
        """
        :return: A dataframe of Channels
        """

        hive_database_prefix = self.config['SSEHiveDatabasePrefix']

        df = self.sqlContext.table(hive_database_prefix + '_ssewh.channel_dim_c')

        if channel_id:
            df = df.select(
                df.channel_code.alias('Channel'),
                df.channel_name.alias('ChannelDescription'), df.channel_id)
        else:
            df = df.select(
                df.channel_code.alias('Channel'),
                df.channel_name.alias('ChannelDescription'))

        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            df = df.withColumn(field.name, df[field.name].cast(field.dataType))

        # Reordering columns to comply with required schema
        df = df.select(list(field.name for field in self.required_schema.fields))

        # self.df is a property - validation of its schema and column uniqueness
        # is handled in the setter method
        self.data = df
