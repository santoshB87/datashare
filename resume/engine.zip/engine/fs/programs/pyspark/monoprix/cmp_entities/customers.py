"""
Monprix Customers entity
"""
import logging
import collections
import datetime
import dunnhumby
from dunnhumby import contexts
import pyspark.sql.functions as F
import pyspark.sql.types as pt
from pyspark.sql import Window

logger = logging.getLogger(__name__)


class Customers(dunnhumby.cmp_entities.customers.Customers):
    """
    Inherits the base CMP Customer class and implements the get_data() method'
    """

    def __init__(self, config, card_id=False):
        super(Customers, self).__init__()
        self.config = config
        if card_id:
            required_schema = pt.StructType()
            required_schema.add(pt.StructField('card_id', pt.LongType(), True))
            for item in self.required_schema.fields:
                required_schema.add(item)

#             required_schema = self.required_schema
#             required_schema.add(pt.StructField('card_id', pt.LongType(), True))
            self.required_schema = required_schema
            # TODO: Is there any better way to override parent class variable in child.
            self.unique_columns = ['card_id']
        self.get_data(card_id)
        self.sqlContext = contexts.sql_context()

    def get_data(self, card_id=False):
        """
        Fields:
            -  destination_column_names: CMP Entity columns
            -  source_column_names: CDM column names

        Returns:
            - A dataframe of Customers
        """

        destination_column_names = ['Customer', 'IsEmailable', 'IsBlacklisted', 'IsMailable',
                                    'IsScottish', 'IsBabyCompliant', 'IsBabyAddrSupress',
                                    'IsBereaved', 'IsDiabetic', 'IsHalal', 'IsKosher',
                                    'IsTeetotal', 'IsVegetarian', 'IsAddrSuppress',
                                    'SloyaltyHigh', 'SloyaltyHighDescription', 'SloyaltyLow',
                                    'SloyaltyLowDescription',
                                    'FulfillmentStore', 'PreferredStore1', 'PreferredStore2',
                                    'PreferredStore3', 'PreferredStoreFormat',
                                    'CustomerGender', 'CustomerAgeRange',
                                    'CustomerPriceSensitivity',
                                    'CustomerPriceSensitivityDescription',
                                    'CustomerRegion', 'CustomerLifeStage',
                                    'CustomerLifeStageDescription',
                                    'CustomerLifeStyle', 'CustomerLifeStyleDescription']

        source_column_names = ['customer']

        derived_column_names = ['IsEmailable', 'IsBlacklisted', 'IsMailable', 'IsScottish',
                                'IsBabyCompliant', 'IsBabyAddrSupress', 'IsBereaved', 'IsDiabetic',
                                'IsHalal', 'IsKosher', 'IsTeetotal', 'IsVegetarian',
                                'IsAddrSuppress',
                                'sloyalty_high', 'SloyaltyHighDescription', 'sloyalty_low',
                                'SloyaltyLowDescription', 'FulfillmentStore',
                                'preferred_store_1', 'preferred_store_2', 'preferred_store_3',
                                'PreferredStoreFormat', 'CustomerGender', 'CustomerAgeRange',
                                'CustomerPriceSensitivity', 'CustomerPriceSensitivityDescription',
                                'CustomerRegion', 'CustomerLifeStage',
                                'CustomerLifeStageDescription',
                                'CustomerLifeStyle', 'CustomerLifeStyleDescription']

        sse_hive_database_prefix = '{sse_hive_database_prefix}_ssewh'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])

        if card_id:
            destination_column_names = ['card_id'] + destination_column_names
            source_column_names = ['card_id'] + source_column_names
            customer_df = self.sqlContext.table('{sse_hive_database}.card_dim_c'.format(
                sse_hive_database=sse_hive_database_prefix)).\
                select('card_id', 'prsn_code', 'prsn_id', 'prsn_email_suppress_flag',
                       'prsn_birth_date', 'prsn_title_name', 'prsn_address_city_name')
        else:
            window = Window.partitionBy("prsn_code").orderBy(F.col("modified_dttm").desc())
            customer_df = (
                self.sqlContext.table(
                    '{sse_hive_database}.card_dim_c'.format(
                        sse_hive_database=sse_hive_database_prefix)
                ).withColumn('_row_number', F.row_number().over(window)).where(
                    F.col('_row_number') == 1).select('prsn_code', 'prsn_id',
                        'prsn_email_suppress_flag', 'prsn_birth_date',
                        'prsn_title_name', 'prsn_address_city_name')
        )

        customer_df = self.derive_customer_sloyalty(customer_df)
        customer_df = self.derive_preferred_stores(customer_df)
        customer_df = self.derive_fulfillment_store(customer_df)
        customer_df = self.derive_is_emailable(customer_df)
        customer_df = self.derive_customer_gender(customer_df)
        customer_df = self.derive_customer_age_range(customer_df)
        customer_df = self.derive_price_sensitivity(customer_df)
        customer_df = self.derive_region(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsMailable(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsBlacklisted(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsScottish(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsBabyCompliant(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsBabyAddrSupress(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsBereaved(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsDiabetic(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsHalal(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsKosher(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsTeetotal(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsVegetarian(customer_df)
        customer_df = super(Customers, self).DeriveDefaultIsAddrSuppress(customer_df)
        customer_df = super(Customers, self).DeriveDefaultSloyaltyHighDescription(customer_df)
        customer_df = super(Customers, self)\
            .DeriveDefaultSloyaltyLowDescription(customer_df)
        customer_df = super(Customers, self).DeriveDefaultPreferredStoreFormat(customer_df)
        customer_df = super(Customers, self).DeriveDefaultCustomerPriceSensitivityDescription(customer_df)
        customer_df = super(Customers, self).DeriveDefaultCustomerLifeStage(customer_df)
        customer_df = super(Customers, self).DeriveDefaultCustomerLifeStageDescription(customer_df)
        customer_df = super(Customers, self).DeriveDefaultCustomerLifeStyle(customer_df)
        customer_df = super(Customers, self).DeriveDefaultCustomerLifeStyleDescription(customer_df)

        # Renaming columns to comply with CMP Entity schema
        mapping = collections.OrderedDict(
            zip(source_column_names + derived_column_names,
                destination_column_names))
        customer_df = customer_df.select(
            [F.col(c).alias(mapping.get(c, c)) for c in mapping.keys()])

        # Converting customer_df to rdd and again to DF to adhere to base schema
        customer_df = self.sqlContext.createDataFrame(customer_df.rdd, self.required_schema)
        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            customer_df = customer_df.withColumn(
                field.name,
                customer_df[field.name].cast(field.dataType))

        # self.df is a property - validation of its schema and column
        # uniqueness is handled in the setter method
        # customer_df.select(destination_column_names).show()
        self.data = customer_df.select(destination_column_names)

    def derive_customer_sloyalty(self, customer_df):
        """derive customer sloyalty"""
        sse_hive_database_prefix = '{sse_hive_database_prefix}_ssewh'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])
        person_loyalty_dimension_table = '{sse_hive_database}.prsn_loyalty_seg'.format(
            sse_hive_database=sse_hive_database_prefix)
        segmentation_value_dimension_table = '{sse_hive_database}.seg_value_dim_c'.format(
            sse_hive_database=sse_hive_database_prefix)
        customer_dimension_table = '{sse_hive_database}.card_dim_c'.format(
            sse_hive_database=sse_hive_database_prefix)
        seg_df = self.sqlContext.table(person_loyalty_dimension_table)
        high_df = self.sqlContext.table(segmentation_value_dimension_table).where(
            "seg_type_code = 'PRSN_SLOYALTY_HIGH'").select('seg_value_id', 'seg_value_code')
        low_df = self.sqlContext.table(segmentation_value_dimension_table).where(
            "seg_type_code = 'PRSN_SLOYALTY_LOW'").select('seg_value_id', 'seg_value_code')
        card_df = self.sqlContext.table(customer_dimension_table).groupBy('prsn_id').agg(
            F.max('prsn_code').alias('customer'))
        join_condition_1 = seg_df['prsn_seg_loyalty_high_id'] == high_df['seg_value_id']
        join_condition_2 = seg_df['prsn_seg_loyalty_low_id'] == low_df['seg_value_id']
        join_condition_3 = seg_df['prsn_id'] == card_df['prsn_id']
        customer_sloyalty_df = seg_df.join(high_df, join_condition_1, 'inner') \
            .withColumnRenamed('seg_value_code', 'sloyalty_high') \
            .join(low_df, join_condition_2, 'left_outer')\
            .withColumnRenamed('seg_value_code', 'sloyalty_low') \
            .join(card_df, join_condition_3, 'left_outer') \
            .select(card_df['customer'], 'sloyalty_high', 'sloyalty_low')
        customer_df = customer_df.join(
            customer_sloyalty_df,
            customer_df['prsn_code'] == customer_sloyalty_df['customer'],
            'left_outer').drop('customer').withColumnRenamed(
                'prsn_code',
                'customer')
        return customer_df

    def derive_preferred_stores(self, customer_df):
        """derive preferred stores"""
        sse_hive_database_prefix = '{sse_hive_database_prefix}_ssewh'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])
        preferred_store_table = '{sse_hive_database}.prsn_pref_seg'.format(
            sse_hive_database=sse_hive_database_prefix)
        store_dimension_table = '{sse_hive_database}.store_dim_c'.format(
            sse_hive_database=sse_hive_database_prefix)
        preferred_store_df = self.sqlContext.table(preferred_store_table)\
            .withColumnRenamed('prsn_id', 'customer_id')
        store_dim_df = self.sqlContext.table(store_dimension_table).\
            select('store_id', 'store_code')
        preferred_store_columns = \
            [col_name for col_name in preferred_store_df.columns if
             '_seg_pref_store_' in col_name]
        join_condition_1 = \
            preferred_store_df[
                preferred_store_columns[0]] == store_dim_df['store_id']
        join_condition_2 = \
            preferred_store_df[
                preferred_store_columns[1]] == store_dim_df['store_id']
        join_condition_3 = \
            preferred_store_df[
                preferred_store_columns[2]] == store_dim_df['store_id']
        preferred_store_df = preferred_store_df.join(
            store_dim_df,
            join_condition_1, 'left') \
            .withColumnRenamed('store_code', 'preferred_store_1').drop('store_id') \
            .join(store_dim_df, join_condition_2, 'left') \
            .withColumnRenamed('store_code', 'preferred_store_2').drop('store_id') \
            .join(store_dim_df, join_condition_3, 'left') \
            .withColumnRenamed('store_code', 'preferred_store_3').drop('store_id')
        customer_df = customer_df.join(
            preferred_store_df,
            preferred_store_df['customer_id'] == customer_df['prsn_id'],
            'left_outer'
        )
        return customer_df

    def derive_price_sensitivity(self, customer_df):
        """derive price_sensitivity"""
        sse_hive_database_prefix = '{sse_hive_database_prefix}_ssewh'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])
        pricesense_dimension_table = '{sse_hive_database}.prsn_pricesense_seg'.format(
            sse_hive_database=sse_hive_database_prefix)
        pricensense_dim_df = self.sqlContext.table(pricesense_dimension_table).select(
            'prsn_id',
            'prsn_seg_pricesense_id'
        )
        customer_df = customer_df.join(
            pricensense_dim_df,
            customer_df.prsn_id == pricensense_dim_df.prsn_id,
            'left') \
            .drop(pricensense_dim_df.prsn_id) \
            .withColumn('CustomerPriceSensitivity',
                        F.when(F.col("prsn_seg_pricesense_id") == 19, 'Mid-market')
                        .when(
                            F.col("prsn_seg_pricesense_id") == 18, 'Price Sensitive')
                        .when(
                            F.col("prsn_seg_pricesense_id") == 20, 'Up-market')
                        .otherwise('Unclassified'))
        customer_df.drop('prsn_seg_pricesense_id')
        return customer_df

    @staticmethod
    def derive_is_emailable(df):
        """IsEmailable column derived using prsn_email_suppress_flag
        column in card_dim_c table"""
        df = df.withColumn(
            "IsEmailable",
            F.when(F.col("prsn_email_suppress_flag") == "Y", False)
            .when(F.col("prsn_email_suppress_flag") == "N", True)
            .otherwise(F.lit(None).cast(pt.BooleanType())))
        return df

    @staticmethod
    def derive_region(df):
        """derive region"""
        df = df.withColumnRenamed("prsn_address_city_name", "CustomerRegion")
        return df

    @staticmethod
    def derive_fulfillment_store(df):
        """
        There is no business logic to derive "FulfillmentStore"
        """
        logger.info("There is no business logic to determine FulfillmentStore."
                    "Adding None values and casting to appropriate data types")
        df = df.withColumn('FulfillmentStore', F.lit(None).cast(pt.StringType()))
        return df

    @staticmethod
    def derive_customer_gender(df):
        """
            prsn_title_name=1 means monsieur
            prsn_title_name=2 means madame
            prsn_title_name=3 means mademoiselle
            """
        df = df.withColumn("CustomerGender",
                           F.when(df.prsn_title_name == '1', 'Male')
                           .when(df.prsn_title_name == '2', 'Female')
                           .when(df.prsn_title_name == '3', 'Female')
                           .otherwise(F.lit(None).cast(pt.StringType())))
        return df

    @staticmethod
    def derive_customer_age_range(df):
        """
        Dividing by 365 is crude but its effective enough until Spark's
        datadiff function gets the ability
        to specify interval, which it does not at the time of writing
        """
        df = df.withColumn("CustomerAge",
                           F.when(df.prsn_birth_date.isNull(),
                                  F.lit(None).cast(pt.IntegerType()))
                           .otherwise(F.datediff(
                               F.lit(datetime.date.today()),
                               df.prsn_birth_date
                           ) / 365))
        df = df.withColumn("CustomerAgeRange",
                           F.when(df.CustomerAge < 20, '<20')
                           .when((df.CustomerAge >= 20) & (df.CustomerAge < 30),
                                 '20-29')
                           .when((df.CustomerAge >= 30) & (df.CustomerAge < 40),
                                 '30-39')
                           .when((df.CustomerAge >= 40) & (df.CustomerAge < 50),
                                 '40-49')
                           .when((df.CustomerAge >= 50) & (df.CustomerAge < 60),
                                 '50-59')
                           .when((df.CustomerAge > 60), '>60')
                           .otherwise(F.lit(None).cast(pt.StringType())))
        df = df.drop("CustomerAge")
        return df
