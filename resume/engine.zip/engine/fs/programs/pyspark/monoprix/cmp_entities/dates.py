"""
Monoprix Dates entity
"""
import dunnhumby
from dunnhumby import contexts
import pyspark.sql.functions as F


# Data will flow into our solution through python classes that we define.
# Initially that data will be sourced from CDM, later it will be sourced from
# Mercury.
# Either way we need an abstraction over those data sources that defines the
# data as SSE requires it.

class Dates(dunnhumby.cmp_entities.dates.Dates):
    """
    Inherits the Base CMP entity class and overrides the get_data method
    """

    def __init__(self, config):
        super(Dates, self).__init__()
        self.sqlContext = contexts.sql_context()
        self.config = config
        self.get_data()

    def get_data(self):
        """
        :return: A dataframe of Dates
        """

        # code here to implement the logic required to provide dates data
        # src_column_names : Source (currently CDM) column names
        # derived_column_names : Columns to be derived within get_data
        # dest_column_names :  CMP Entity column names

        src_column_names = ['date_id', 'date_name', 'date_short_name',
                            'day_of_week_name', 'fis_week_id',
                            'fis_day_of_week_num']
        dest_column_names = ['date_id', 'date_name', 'date_short_name',
                             'day_of_week_name', 'fis_week_id',
                             'fis_day_of_week_num']

        # Fetching database suffix from config
        hive_database_prefix = self.config['SSEHiveDatabasePrefix']

        date_df = self.sqlContext.table('{hive_database_prefix}_ssewh.date_dim'.format(
            hive_database_prefix=hive_database_prefix
        )).select(src_column_names)

        # Renaming columns to comply with CMP Entity schema
        mapping = dict(zip(src_column_names, dest_column_names))
        date_df = date_df.select([F.col(c).alias(mapping.get(c, c)) for c in date_df.columns])

        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            date_df = date_df.withColumn(field.name, date_df[field.name].cast(field.dataType))

        # self.df is a property - validation of its schema and
        # column uniqueness is handled in the setter method
        self.data = date_df
