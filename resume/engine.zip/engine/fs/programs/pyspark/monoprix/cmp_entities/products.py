import dunnhumby
from dunnhumby import contexts
from pyspark.sql.functions import when, lit, length, current_date, date_add
from pyspark.sql import functions as pf, types as pt


# Data will flow into our solution through python classes that we define.
# Initially that data will be sourced from CDM, later it will be sourced from Mercury.
# Either way we need an abstraction over those data sources that defines the data
# as SSE requires it.

class Products(dunnhumby.cmp_entities.products.Products):
    """
    Inherits the Base CMP products entity class and overrides the get_data method
    """

    def __init__(self, config, prod_id=False):
        super(Products, self).__init__()
        self.sqlContext = contexts.sql_context()
        self.config = config
        self.one_to_manys = [('Group', 'Subgroup'), ('Section', 'Group'), ('Department', 'Section'),
                             ('Division', 'Department')]
        required_schema = self.required_schema
        if prod_id:
            required_schema.add(pt.StructField('prod_id', pt.LongType(), True))
        if self.config.get("SSEFeaturePacFlag", "False").lower() == "true":
            required_schema.add(pt.StructField('PacSection', pt.StringType(), True))
            required_schema.add(pt.StructField('PacInstoreShelf', pt.StringType(), True))
        required_schema.add(pt.StructField('Delist_flag', pt.BooleanType(), True))
        self.required_schema = required_schema

        self.get_data(prod_id)

    def get_data(self, prod_id=False):
        """
        :return: A dataframe of Products
        """

        # code here to implement the logic required to provide products data.
        # src_column_names : Source (currently CDM) column names
        # derived_column_names : Columns to be derived within get_data
        # dest_column_names :  CMP Entity column names

        # Fetching database suffix from config
        hive_database_prefix = self.config['SSEHiveDatabasePrefix']

        df = self.sqlContext.table(hive_database_prefix + '_ssewh.prod_dim_c')
        # Julie Wojciekowski (Client Solutions Manager for Monoprix)
        # has specified that we only require features for a subset of
        # all products.
        # L24code |           L24name            |     L23name    |  L20code  | L20name
        # -----------------------------------------------------------------------------------------------
        #   CA    | ALIMENTAIRE NON PERISSABLE   | All            | All       | All
        #   CP    | ALIMENTAIRE PERISSABLE       | All            | All       | All
        #   MC    | PARFUMERIE                   | All            | All       | All
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_10 | COLLES ET ADHESIFS
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_50 | ECLAIRAGE
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_98 | EMBALLAGES MENAGERS
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_55 | ENERGIE PORTABLE
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_90 | ACCESSOIRES/SOINS ANIMAUX
        #   MB    | MAISON LOISIRS               | MB67-bricolage | MB6767_92 | LITIERE
        #   MB    | MAISON LOISIRS               | MB52-papeterie | MB5252_20 | ECRITURE
        #   MB    | MAISON LOISIRS               | MB52-papeterie | MB5252_30 | ACCESSOIRES DE DESSIN
        #   MB    | MAISON LOISIRS               | MB52-papeterie | MB5252_35 | CAHIER ET COPIES
        # The filters applied below match that spec. Based on today's calculations the tally
        # of products for which we shall be generating features will reduce by ~76%
        # -Jamie Thomson, 2018-01-12
        # df.where(
        # df.prod_comml_l24_code.isin('CA', 'CP', 'MC') |
        # df.prod_comml_l20_code.isin('MB6767_10','MB6767_50','MB6767_98','MB6767_55','MB6767_90',
        #                              'MB6767_92','MB5252_20','MB5252_30','MB5252_35'))
        # Removing above filter as we had latest discussion with science team(Vivek kapoor), they
        # need all the data for science modeling
        selectColumns = ["prod_code as Product", "coalesce(commercial_designation, prod_desc) as ProductDescription",
                         "prod_comml_l10_code as Subgroup",
                         "prod_comml_l10_desc as SubgroupDescription",
                         "prod_comml_l21_code as `Group`",
                         "prod_comml_l21_desc as GroupDescription",
                         "prod_comml_l22_code as Section",
                         "prod_comml_l22_desc as SectionDescription",
                         "prod_comml_l24_code as Department",
                         "prod_comml_l24_desc as DepartmentDescription",
                         "prod_comml_l30_code as Division",
                         "prod_comml_l30_desc as DivisionDescription",
                         "prod_comml_l20_code as InstoreShelf",
                         "prod_comml_l20_desc as InstoreShelfDescription",
                         "prod_comml_l23_code as InstoreAisle",
                         "prod_comml_l23_desc as InstoreAisleDescription",
                         "brand_name as ProductBrand", "vendor_id",
                         "image_url as ProductImageUri", "delist_date"]

        if prod_id:
            selectColumns.append("prod_id")

        df = df.selectExpr(*selectColumns)
        df = df.withColumn('Delist_flag', when(df.delist_date.cast(pt.DateType()) >=
                                               date_add(current_date(), 30), False).otherwise(True)
                           ).drop('delist_date')
        df = Products._derive_isalcohol(df=df)

        # Calling base class methods to derive InStoreShelf, InStoreAisle, InStoreArea
        # IsBaby, IsPet and ConsumptionType
        df = super(Products, self).DeriveDefaultInstoreSubAisleAndDescription(df)
        df = super(Products, self).DeriveDefaultInstoreSubAreaAndDescription(df)
        df = super(Products, self).DeriveDefaultInstoreAreaAndDescription(df)
        df = super(Products, self).DeriveDefaultIsBaby(df)
        df = super(Products, self).DeriveDefaultIsPet(df)
        df = super(Products, self).DeriveDefaultConsumptionType(df)
        df = self.DeriveIsSoldByWeight(df)
        df = self.DeriveProductSupplier(df)
        # Deriving pac details
        if self.config.get("SSEFeaturePacFlag", "False").lower() == "true":
            sse_hive_database_prefix = '{sse_hive_database_prefix}_ssewh'.format(
                sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])
            pac_section_table = '{sse_hive_database}.pacs_info_prod_comml_l22_code'.format(
                sse_hive_database=sse_hive_database_prefix)
            pac_InstoreShelf_table = '{sse_hive_database}.pacs_info_prod_comml_l20_code'.format(
                sse_hive_database=sse_hive_database_prefix)
            pac_section_df = self.sqlContext.table(pac_section_table)
            pac_InstoreShelf_df = self.sqlContext.table(pac_InstoreShelf_table)
            join_condition_1 = df['Section'] == pac_section_df['prod_comml_l22_code']
            join_condition_2 = df['InstoreShelf'] == pac_InstoreShelf_df['prod_comml_l20_code']
            df = df.join(pac_section_df, join_condition_1, 'left_outer')
            df = df.drop(df.prod_comml_l22_code).withColumnRenamed('affinityclusternum', 'PacSection')
            df = df.join(pac_InstoreShelf_df, join_condition_2, 'left_outer')
            df = df.drop(df.prod_comml_l20_code).withColumnRenamed('affinityclusternum',
                                                                   'PacInstoreShelf')
        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            df = df.withColumn(field.name, df[field.name].cast(field.dataType))

        # Reordering columns to comply with required schema
        df = df.select(list(field.name for field in self.required_schema.fields))

        # Re-applying schema as spark automatically infers and changes schema for boolean fields
        df = self.sqlContext.createDataFrame(df.rdd, self.required_schema)

        # Data will be checked multiple times for one-to-many relationships,
        # persisting/caching will speed that up
        # df.persist()

        # self.df is a property - validation of its schema and column uniqueness
        # is handled in the setter method
        self.data = df

    @staticmethod
    def _derive_isalcohol(df):
        """
        Determine whether a product is an alcoholic product
        or not depending on which InstoreShelf it appears on
        """
        alcoholic_instoreshelves = ['CA0707_01', 'CA0707_03', 'CA0707_04', 'CA0707_05', 'CA0707_07',
            'CA0707_10', 'CA0707_11', 'CA0707_12', 'CA0707_13', 'CA0707_14', 'CA0707_15',
            'CA0707_16', 'CA0707_40', 'CA0707_50', 'CA0707_51', 'CA0707_52', 'CA0707_61',
            'CA0707_62', 'CA0707_63', 'CA0707_64', 'CA0707_65', 'CA0707_66', 'CA0707_67',
            'CA0707_68', 'CA0707_69', 'CA0707_70', 'CA0707_71', 'CA0707_72', 'CA0707_73',
            'CA0707_80', 'CA0707_81', 'CA0707_90']
        return df.withColumn('IsAlcohol',
            when(df.InstoreShelf.isin(alcoholic_instoreshelves), lit(True)).otherwise(lit(False)))

    def DeriveIsSoldByWeight(self, df):
        """
        Add IsSoldByWeight with product
        """

        return df.withColumn('IsSoldByWeight',
                             when((length(df.Product) == 7) & (df.Product.like('0%')),
                                  lit(True)).otherwise(lit(False)))

    def DeriveProductSupplier(self, df):
        """
        Add supplier details with product
        """
        # df.show()
        sse_hive_database_prefix = '{sse_hive_database_prefix}_ssewh'.format(
            sse_hive_database_prefix=self.config['SSEHiveDatabasePrefix'])
        vendor_lkp_table = '{sse_hive_database}.vendor_lkp_c'.format(
            sse_hive_database=sse_hive_database_prefix)
        vendor_df = self.sqlContext.table(vendor_lkp_table).select('vendor_id', 'vendor_code')
        join_condition = df['vendor_id'] == vendor_df['vendor_id']
        df = df.join(vendor_df, join_condition, 'left_outer').withColumnRenamed('vendor_code',
                                                                                'ProductSupplier').\
            drop(df.vendor_id)
        # df.show()
        # df = df.drop(df.vendor_id)
        # df.show()
        return df
