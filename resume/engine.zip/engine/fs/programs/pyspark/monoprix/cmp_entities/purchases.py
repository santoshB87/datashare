"""
Tesco GB Purchases
"""


from os import path
from pyspark.sql import functions as pf, types as pt
from dunnhumby.cmp_entities.purchases import Purchases as PurchasesBase


class Purchases(PurchasesBase):
    """
    Tesco GB Purchases
    """

    def __init__(self, config):
        super(Purchases, self).__init__(config=config)
        self.get_data()
