"""
Monoprix stores entity
"""
import dunnhumby
from dunnhumby import contexts
from pyspark.sql import functions as pf, types as pt


# Data will flow into our solution through python classes that we define.
# Initially that data will be sourced from CDM, later it will be sourced from Mercury.
# Either way we need an abstraction over those data sources that defines the data as
# SSE requires it.

class Stores(dunnhumby.cmp_entities.stores.Stores):
    """
    Inherits the Base CMP products entity class and overrides the get_data method
    """

    def __init__(self, config, store_id=False):
        super(Stores, self).__init__()
        self.sqlContext = contexts.sql_context()
        self.config = config
        if store_id:
            required_schema = self.required_schema
            required_schema.add(pt.StructField('store_id', pt.LongType(), True))
            # TODO: Is there any better way to override parent class variable in child.
            self.required_schema = required_schema
            # self.unique_columns = ['Store']
            self.unique_columns = ['store_id']
        self.get_data(store_id)

    def get_data(self, store_id=False):
        """
        :return: A dataframe of Stores
        """

        # Fetching database suffix from config
        hive_database_prefix = self.config['SSEHiveDatabasePrefix']

        df = self.sqlContext.table(hive_database_prefix + '_ssewh.store_dim_c')


        if store_id:
            df = df.select(
                df.store_code.alias('Store'), df.store_name.alias('StoreDescription'),
                df.banner_name.alias('Banner'), df.store_mgmt_l20_desc.alias('StoreRegion'),
                df.banner_name.alias('BannerDescription'), df.store_id
            )

        else:
            df = df.select(
                df.store_code.alias('Store'), df.store_name.alias('StoreDescription'),
                df.banner_name.alias('Banner'), df.store_mgmt_l20_desc.alias('StoreRegion'),
                df.banner_name.alias('BannerDescription')
            )


        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            df = df.withColumn(field.name, df[field.name].cast(field.dataType))

        # Reordering columns to comply with required schema
        df = df.select(list(field.name for field in self.required_schema.fields))

        # self.df is a property - validation of its schema and column uniqueness
        # is handled in the setter method
        self.data = df
