"""
Monoprix transactions entity
"""
import pyspark.sql.functions as F
import pyspark.sql.types as T
import dunnhumby
from dunnhumby import contexts


# Data will flow into our solution through python classes that we define.
# Initially that data will be sourced from CDM, later it will be sourced from Mercury.
# Either way we need an abstraction over those data sources that defines the data
# as SSE requires it.

class Transactions(dunnhumby.cmp_entities.transactions.Transactions):
    """
    Inherits the Base CMP Transactions entity class and overrides the get_data method
    """

    def __init__(self, config):
        super(Transactions, self).__init__()
        self.sqlContext = contexts.sql_context()
        self.config = config
        self.get_data()
        self.get_most_recent_transaction_date()

    def get_data(self):
        """
        :return: A dataframe of Transactions
        """

        # Fetching database suffix from config
        hive_database_prefix = self.config['SSEHiveDatabasePrefix']

        # Fetching required fields from source table
        df = self.sqlContext.table(hive_database_prefix + '_ssewh.transaction_item_fct')
        #At time of writing approximately 45% of transactions are for
        # card=-1 which creates huge data skew during
        # feature generation, so we're choosing to filter them out
        df = df.filter(df.card_id != -1)

        # Joining with products dimension to fetch product identifier
        product_df = self.sqlContext.table(hive_database_prefix + '_ssewh.prod_dim_c')
        # Julie Wojciekowski (Client Solutions Manager for Monoprix)
        # has specified that we only require features for a subset of
        # all products.
        # L24code|           L24name          |     L23name    |  L20code  | L20name
        # ----------------------------------------------------------------------------------------
        #   CA   | ALIMENTAIRE NON PERISSABLE | All            | All       | All
        #   CP   | ALIMENTAIRE PERISSABLE     | All            | All       | All
        #   MC   | PARFUMERIE                 | All            | All       | All
        #   MB   | MAISON LOISIRS             | MB67-bricolage | MB6767_10 | COLLES ET ADHESIFS
        #   MB   | MAISON LOISIRS             | MB67-bricolage | MB6767_50 | ECLAIRAGE
        #   MB   | MAISON LOISIRS             | MB67-bricolage | MB6767_98 | EMBALLAGES MENAGERS
        #   MB   | MAISON LOISIRS             | MB67-bricolage | MB6767_55 | ENERGIE PORTABLE
        #   MB   | MAISON LOISIRS             | MB67-bricolage | MB6767_90 | ACCESSOIRES/ANIMAUX
        #   MB   | MAISON LOISIRS             | MB67-bricolage | MB6767_92 | LITIERE
        #   MB   | MAISON LOISIRS             | MB52-papeterie | MB5252_20 | ECRITURE
        #   MB   | MAISON LOISIRS             | MB52-papeterie | MB5252_30 | ACCESSOIRES DE DESSIN
        #   MB   | MAISON LOISIRS             | MB52-papeterie | MB5252_35 | CAHIER ET COPIES
        # The filters applied below match that spec. Based on today's calculations the tally
        # of transactions for which we shall be generating features will reduce by ~11%.
        # During testing we found this reduced the tally of outputted features by
        # ~14% (430m down to 370m for features at the grain of Customer/Product)
        # -Jamie Thomson, 2018-01-12
        # df.where(
        # df.prod_comml_l24_code.isin('CA', 'CP', 'MC') |
        # df.prod_comml_l20_code.isin('MB6767_10','MB6767_50','MB6767_98','MB6767_55','MB6767_90',
        #                              'MB6767_92','MB5252_20','MB5252_30','MB5252_35'))
        # Removing above filter as we had latest discussion with science team(Vivek kapoor), they
        # need all the data for science modeling

        product_df = product_df.select(product_df.prod_id, product_df.prod_code.alias('Product'))
        df = df.join(product_df, df.prod_id == product_df.prod_id, 'inner')

        # Joining with card dimension to fetch Customer identifier
        # Note : card_id -> hshd_code is a many-to-one mapping
        customer_df = self.sqlContext.table(hive_database_prefix + '_ssewh.card_dim_c')
        customer_df = customer_df.select(
            customer_df.card_id,
            customer_df.prsn_code.alias('Customer'))
        df = df.join(customer_df, df.card_id == customer_df.card_id, 'left_outer')

        # Joining with store dimension to fetch Store identifier
        store_df = self.sqlContext.table(hive_database_prefix + '_ssewh.store_dim_c')
        store_df = store_df.select(store_df.store_id, store_df.store_code.alias('Store'))
        df = df.join(store_df, df.store_id == store_df.store_id, 'left_outer')

        # Joining with channel dimension to fetch channel identifier
        channel_df = self.sqlContext.table(hive_database_prefix + '_ssewh.channel_dim_c')
        channel_df = channel_df.select(
            channel_df.channel_id,
            channel_df.channel_code.alias('Channel'))
        df = df.join(channel_df, df.channel_id == channel_df.channel_id, 'left_outer')

        df = df.select(
            df.transaction_fid.alias('Basket'),
            df.date_id.alias('Date'),
            df.Customer,
            df.Product,
            df.Store,
            df.Channel,
            df.item_qty.alias('Quantity'),
            df.net_spend_amt.alias('NetSpendAmount')
        ) \
            .withColumn('SpendAmount', F.lit(None).cast(T.DecimalType(18, 2))) \
            .withColumn('DiscountAmount', F.lit(None).cast(T.DecimalType(18, 2)))

        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            df = df.withColumn(field.name, df[field.name].cast(field.dataType))

        # Reordering columns to comply with required schema
        df = df.select(list(field.name for field in self.required_schema.fields))

        # self.df is a property - validation of its schema and column
        # uniqueness is handled in the setter method
        self.data = df

    def get_most_recent_transaction_date(self):
        hive_database_prefix = self.config['SSEHiveDatabasePrefix']
        self.most_recent_transaction_date = (
            self.sqlContext.table(
                '{SSEHiveDatabasePrefix}_ssewh.transaction_item_fct'.format(
                    SSEHiveDatabasePrefix=hive_database_prefix)
            ).agg(F.max("date_id").alias('max_date_id'))
            .withColumn(
                'most_recent_transaction_date',
                F.col('max_date_id').cast(T.DateType())
            ).drop('max_date_id')
        )
        