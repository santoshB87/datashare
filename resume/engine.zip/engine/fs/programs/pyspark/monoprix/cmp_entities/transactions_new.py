"""
Monoprix Transactions
"""
from os import path
from pyspark.sql import functions as pf, types as pt
from dunnhumby.cmp_entities.transactions_new import TransactionsNew as TransactionsNewBase
from collections import OrderedDict


class TransactionsNew(TransactionsNewBase):
    """
    Monoprix Transactions
    """

    def __init__(self, config, skip_most_recent_calc=False):
        """
        Constructor of Transactions entity (new)
        :param config: config info from config.json
        :param date_id: if date_id is specified, data related to only that date_id will be returned
        :param skip_most_recent_calc: if set to True calculation of most recent transaction date
        postponed till user explicitly call the required function
        """
        super(TransactionsNew, self).__init__()
        self.config = config
        self.table_name = self.config["SSEHiveWarehousedb"] + "." + \
                          self.config["SSEHiveTransactionTab"]
        self.table_path = path.join(self.config["SSEHiveWarehousePath"],
                                    self.config["SSEHiveWarehousedb"],
                                    self.config["SSEHiveTransactionTab"])
        self.__partition_info = None
        # Column mapping
        # __cmp_col_names - column names in CMP entity
        # __source_col_name - column names in Hive/CDM/Mercury (Hive tables)
        # __derived_col_name - column names which are derived using custom logic.
        # __input_column_names - additional list which combine source & derived col, this is to
        # maintain column order and will be used in col_mapping
        # __col_mapping - one to one mapping of CMP column to input/source column names
        self.__cmp_col_names = ['prod_id', 'card_id', 'store_id', 'channel_id',
                                'Basket', 'Date', 'fis_week_id', 'Quantity'
                                , 'NetSpendAmount', 'SpendAmount', 'DiscountAmount']
        self.__source_column_names = ['prod_id', 'card_id', 'store_id', 'channel_id',
                                      'transaction_fid', 'date_id', 'fis_week_id', 'item_qty',
                                      'net_spend_amt']
        self.__derived_column_names = ['SpendAmount','DiscountAmount']
        self.__input_column_names = self.__source_column_names + self.__derived_column_names
        # zip column mapping into a order dict.
        # Is order dict necessary, can further code live with normal dict()?
        self.__col_mapping = OrderedDict(zip(self.__cmp_col_names, self.__input_column_names))
        self.get_data()
        if not skip_most_recent_calc:
            self.get_most_recent_transaction_date()

    def get_data(self):
        """
        Create a spark dataframe on top of transactions entity/table
        Note - This is read/return whole tables, doesn't leverage partition access, use with caution
        :return: None
        """
        # Read whole table transaction_item_fct
        transactions_df = self.sqlContext.table(self.table_name).select(self.__source_column_names)
        transactions_df = transactions_df.withColumn("SpendAmount", pf.lit(None))
        transactions_df = transactions_df.withColumn("DiscountAmount", pf.lit(None))
        # Renaming & casting columns to comply with CMP Entity schema
        transactions_df = transactions_df.select(
            [pf.col(self.__col_mapping.get(field.name)).cast(field.dataType).alias(field.name)
             for field in self.required_schema.fields])
        self.data = transactions_df

    def get_partition(self, date_id):
        """
        Return spark dataframe over a partition of transactions entity/table this should be thread
        safe in case if different partitioned are read/accessed in parallel
        Note - Transactions entity/table is partitioned on date_id in hive
        :param date_id: data related to only that date_id will be returned
        :return: transactions_part_df: Spark dataframe
        """
        if date_id is None:
            raise ValueError("Caller must provide valid value for date_id")
        partition_path = path.join(self.table_path, "date_id={0}".format(date_id))
        # TODO: should we handle error while loading invalid partitions (like Py4JJavaError etc)
        transactions_part_df = self.sqlContext.read.format("parquet"). \
            option("basePath", self.table_path).load(partition_path). \
            select(self.__source_column_names)
        transactions_part_df = transactions_part_df.withColumn("SpendAmount", pf.lit(None))
        transactions_part_df = transactions_part_df.withColumn("DiscountAmount", pf.lit(None))
        # Renaming & casting columns to comply with CMP Entity schema
        transactions_part_df = transactions_part_df.select(
            [pf.col(self.__col_mapping.get(field.name)).cast(field.dataType).alias(field.name)
             for field in self.required_schema.fields])
        self.validate(transactions_part_df)
        return transactions_part_df

    def get_partition_info(self, refresh=False):
        """
        Fetches partitions info of transactions entity/table
        :param refresh: invalidate last cached result and fetch partitions info again
        :return: list(): list of partition values
        """
        # table partition info, sample row - Row(result=u'date_id=2017-12-01')
        if self.__partition_info is None or refresh:
            part_info = self.sqlContext.sql("show partitions {tabname}".
                                            format(tabname=self.table_name)).collect()
            self.__partition_info = [row["result"].split("=")[1] for row in part_info]
        return self.__partition_info

    def get_most_recent_transaction_date(self):
        """
        :return: None
        """
        self.most_recent_transaction_date = (self.sqlContext.table(self.table_name)
                                             .agg(pf.max('date_id').alias('max_date_id'))
                                             .withColumn('most_recent_transaction_date',
                                                         pf.col('max_date_id').cast(pt.DateType()))
                                             .drop('max_date_id'))
