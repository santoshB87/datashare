"""
Monoprix features
"""
import logging
logger = logging.getLogger(__name__)
