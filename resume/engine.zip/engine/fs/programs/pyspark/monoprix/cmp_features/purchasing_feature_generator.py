"""
Monoprix Purchasing feature generator
"""


import logging
from copy import deepcopy
from dunnhumby.cmp_features.purchasing_feature_generator_base import PurchasingFeatureGeneratorBase
# from dunnhumby.cmp_features.purchasing_feature_util import *
from monoprix.cmp_entities.customers import Customers
from monoprix.cmp_entities.products import Products
from monoprix.cmp_entities.stores import Stores
from monoprix.cmp_entities.channels import Channels
from monoprix.cmp_entities.dates import Dates
from monoprix.cmp_entities.purchases import Purchases
from monoprix.cmp_entities.transactions_new import TransactionsNew


logger = logging.getLogger(__name__)


class PurchasingFeatureGenerator(PurchasingFeatureGeneratorBase):
    """
    Monoprix Purchasing feature generator
    """

    # pylint: disable=too-many-instance-attributes
    # pylint: disable=access-member-before-definition

    def __init__(self, config, cadence_attribute, run_date):
        """

        :param config: client config
        :param cadence_attribute: cadence attribute can be either fis_week_id or date_short_name
        for either week or daily feature calculation.
        :param run_date: run_date can be either current date i.e today or any specific past date
        for which feature will be calculated.
        """
        super(PurchasingFeatureGenerator, self).__init__(config=config,
                                                         cadence_attribute=cadence_attribute,
                                                         run_date=run_date)
        # feature specification, based on this list feature will be created, this should contain
        # atleast these elements.
        # name - feature name, this will derive all the hive table names (final & temp tables).
        # cadence_attribute - on which time dimension feature is calculated (not in use now,
        # included for future use).
        # is_active - active flag, whether feature should be calculated or not.
        # summary_on - summary creation flag, whether feature needs its own summary or not.
        # durations - list of time durations for which feature is calculated.
        # rsd - rsd value i.e error rate for distinct calc (not in use now, included for future use)
        # dimension_attribute_grain - grouping information, which dimension attribute should be used
        # for grouping in calculation of feature metrics.
        # base_features - list of feature metrics which will be calculated in summary & upward.
        # derived_features - list of feature metrics which are based on some other metrics.
        # dependent_derived_features - list of feature metrics which are based on metrics which
        # don't belong to same table.
        # distinct_features - list of features metrics which are calculated as distinct of something
        self.features_specifications = [
            {
                "name": "All_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "All",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["InstoreAisleCount", "PacSectionCount",
                                      "PacInstoreShelfCount", "InstoreShelfCount", "SectionCount",
                                      "GroupCount", "SubgroupCount", "ProductCount",
                                      "CustomerCount"] if self._pac_flag else
                ["InstoreAisleCount", "InstoreShelfCount", "SectionCount", "GroupCount",
                 "SubgroupCount", "ProductCount", "CustomerCount"]
            },
            {
                "name": "All_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "All",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["InstoreAisleCount", "PacSectionCount",
                                      "PacInstoreShelfCount", "InstoreShelfCount", "SectionCount",
                                      "GroupCount", "SubgroupCount", "ProductCount"]
                if self._pac_flag else ["InstoreAisleCount",  "InstoreShelfCount", "SectionCount",
                                        "GroupCount", "SubgroupCount", "ProductCount"]
            },
            {
                "name": "Product_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Product",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["CustomerCount"]
            },
            {
                "name": "Product_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": ["Product"],
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "dimension_attribute_null_filter": ["Product", "Customer"],
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95",
                                  "StandardDeviationNetSpendPerWeek"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": None,
                "additional_dimension_attribute": [
                    {
                        "dimension": "Product",
                        "attribute": ["Delist_flag", "InstoreAisle", "PacSection",
                                      "PacInstoreShelf", "InstoreShelf", "Section", "Group",
                                      "Subgroup"] if self._pac_flag else
                        ["Delist_flag", "InstoreAisle", "InstoreShelf", "Section", "Group",
                         "Subgroup"],
                        "join_key": ["Product"]
                    }
                ]
            },
            {
                "name": "InstoreShelf_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "InstoreShelf",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["SubgroupCount", "ProductCount", "CustomerCount"]
            },
            {
                "name": "InstoreShelf_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "InstoreShelf",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["SubgroupCount", "ProductCount"]

            },
            {
                "name": "InstoreAisle_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "InstoreAisle",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["PacSectionCount", "PacInstoreShelfCount",
                                      "InstoreShelfCount", "SectionCount", "GroupCount",
                                      "SubgroupCount", "ProductCount", "CustomerCount"]
                if self._pac_flag else ["InstoreShelfCount", "SectionCount", "GroupCount",
                                        "SubgroupCount", "ProductCount", "CustomerCount"]
            },
            {
                "name": "InstoreAisle_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "InstoreAisle",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["PacSectionCount", "PacInstoreShelfCount",
                                      "InstoreShelfCount", "SectionCount", "GroupCount",
                                      "SubgroupCount", "ProductCount"]
                if self._pac_flag else ["InstoreShelfCount", "SectionCount", "GroupCount",
                                        "SubgroupCount", "ProductCount"]
            },
            {
                "name": "Group_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Group",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["SubgroupCount", "ProductCount"]
            },
            {
                "name": "Group_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Group",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["SubgroupCount", "ProductCount", "CustomerCount"]
            },
            {
                "name": "SubGroup_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "SubGroup",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["ProductCount", "CustomerCount"]
            },
            {
                "name": "SubGroup_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "SubGroup",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["ProductCount"]
            },
            {
                "name": "Section_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Section",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["GroupCount", "SubgroupCount", "ProductCount",
                                      "CustomerCount"]
            },
            {
                "name": "Section_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Section",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["GroupCount", "SubgroupCount", "ProductCount"]
            },
            {
                "name": "PacSection_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True if self._pac_flag else False,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "PacSection",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["PacInstoreShelfCount", "InstoreShelfCount", "SectionCount",
                                      "GroupCount", "SubgroupCount", "ProductCount"]
                if self._pac_flag else ["InstoreShelfCount", "SectionCount", "GroupCount",
                                        "SubgroupCount", "ProductCount"]
            },
            {
                "name": "PacSection_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True if self._pac_flag else False,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "PacSection",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["PacInstoreShelfCount", "InstoreShelfCount", "SectionCount",
                                      "GroupCount", "SubgroupCount", "ProductCount",
                                      "CustomerCount"]
                if self._pac_flag else ["InstoreShelfCount", "SectionCount", "GroupCount",
                                        "SubgroupCount", "ProductCount", "CustomerCount"]
            },
            {
                "name": "PacInstoreShelf_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True if self._pac_flag else False,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "PacInstoreShelf",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["PacSectionCount", "SectionCount", "InstoreShelfCount",
                                      "GroupCount", "SubgroupCount", "ProductCount"]
                if self._pac_flag else ["SectionCount", "InstoreShelfCount", "GroupCount",
                                        "SubgroupCount", "ProductCount"]
            },
            {
                "name": "PacInstoreShelf_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True if self._pac_flag else False,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "PacInstoreShelf",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                # "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                #                                "BasketsDecay1w13wvs1w52w"],
                "distinct_features": ["PacSectionCount", "SectionCount", "InstoreShelfCount",
                                      "GroupCount", "SubgroupCount", "ProductCount",
                                      "CustomerCount"]
                if self._pac_flag else ["SectionCount", "InstoreShelfCount", "GroupCount",
                                        "SubgroupCount", "ProductCount", "CustomerCount"]
            },
            {
                "name": deepcopy(self.config["SSEFeatureDistinctTab"]),
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    # These should be list of attribute, please don't mention all instead use empty
                    # list in place of all
                    "ProductAttribute": deepcopy(self._product_hierarchy),
                    "CustomerAttribute": ["Customer"],
                    "StoreAttribute": [],
                    "ChannelAttribute": []
                },
                "base_features": [],
                "derived_features": [],
                "dependent_derived_features": [],
                "distinct_features": None
            }
        ]

    @property
    def purchases(self):
        """
        Return Purchases entity object, should be used for only accessing/deleting metadata info,
        if used for data access they will result in full scan of object/fact table
        :return: purchases: monoprix.cmp_entities.purchases.Purchases
        """
        if self._purchases is None:
            self._purchases = Purchases(config=self.config)
        return self._purchases

    @property
    def transactions(self):
        """
        Return Transactions entity object, should be used for only accessing metadata info and
        reading single partitions only else will result in full scan of object/fact table
        :return: transactions: Monoprix.cmp_entities.transactions_new.TransactionsNew
        """
        if self._transactions is None:
            self._transactions = TransactionsNew(self.config, skip_most_recent_calc=False)
        return self._transactions

    @property
    def customers_df(self):
        """
        Return Customers entity's data (only required columns) as spark dataframe
        :return: customers_df: Dataframe
        """
        if self._customer_df is None:
            customers = Customers(self.config, card_id=True)  # use this in cluster run
            # customers = self.get_cust()  # use this in docker, it uses mock
            customers_df = customers.data.select('card_id', 'Customer', 'FulfillmentStore',
                                                 'PreferredStore1', 'PreferredStore2',
                                                 'PreferredStore3')
            self._customer_df = customers_df
        return self._customer_df

    @customers_df.setter
    def customers_df(self, customers_df):
        """
        Accommodate any changes in customer_df, doesn't do any kind check before assigning
        :param customers_df: dataframe containing information about customer entity
        :return: None
        """
        self._customer_df = customers_df

    @property
    def products_df(self):
        """
        Return Products entity's data (only required columns) as spark dataframe
        :return: products_df: Dataframe
        """
        if self._products_df is None:
            products = Products(self.config, prod_id=True)
            products_df = products.data.select(["prod_id"] + self._product_hierarchy)
            self._products_df = products_df
        return self._products_df

    @products_df.setter
    def products_df(self, products_df):
        """
        Accommodate any changes in products_df, doesn't do any kind check before assigning
        :param products_df: dataframe containing information about product entity
        :return: None
        """
        self._products_df = products_df

    @property
    def stores_df(self):
        """
        Return Stores entity's data (only required columns) as spark dataframe
        :return: stores_df: Dataframe
        """
        if self._stores_df is None:
            stores = Stores(self.config, store_id=True)
            stores_df = stores.data.select('store_id', 'Store')
            self._stores_df = stores_df
        return self._stores_df

    @property
    def channels_df(self):
        """
        Return Channels entity's data (only required columns) as spark dataframe
        :return: channels_df: Dataframe
        """
        if self._channels_df is None:
            channels = Channels(self.config, channel_id=True)
            channels_df = channels.data.select('channel_id', 'Channel')
            self._channels_df = channels_df
        return self._channels_df

    @property
    def dates_df(self):
        """
        Return Dates entity's data as spark dataframe
        :return: dates_df: Dataframe
        """
        if self._dates_df is None:
            dates = Dates(self.config)
            dates_df = dates.data
            self._dates_df = dates_df
        return self._dates_df

    def register_supplementary_tables(self):
        """
        Client implementation to register supplementary table required to derive extra dimension
        attribute or any other supplementary column/information.
        :return: (True/False, tab_lst): (boolean, list() of supplementary table)
        """
        work_db = self.config["SSEHiveWorkdb"]
        logger.info("Creating required supplementary table in work db %s", work_db)
        tab_lst = []
        products = Products(self.config, prod_id=False)
        products_df = products.data.select(self._product_hierarchy + ["Delist_flag"])
        temp_table = work_db + "." + "Product_dim_tab"
        self.sqlContext.sql("DROP TABLE IF EXISTS " + temp_table)
        products_df.repartition(200).write.saveAsTable(temp_table, format="parquet",
                                                       mode="overwrite")
        tab_lst.append("Product_dim_tab")
        db_tab_lst = self.sqlContext.tableNames(dbName=work_db)
        return all([True for item in tab_lst if item.lower() in db_tab_lst]), tab_lst

    def delete_supplementary_tables(self, tab_lst):
        """
        Client implementation to delete supplementary tables required to derive extra dimension
        attribute or any other supplementary column/information.
        :param tab_lst: list() of supplementary table
        :return: True/False: boolean
        """
        work_db = self.config["SSEHiveWorkdb"]
        logger.info("Deleting supplementary table in work db %s", work_db)
        for tab in tab_lst:
            self.sqlContext.sql("DROP TABLE IF EXISTS " + work_db + "." + tab)
        return True
