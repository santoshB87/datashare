"""
Monoprix purchasing feature coordinator 3
"""
import datetime
import logging

import dunnhumby.cmp_entities.channels as channels_base
import dunnhumby.cmp_entities.customers as customers_base
import dunnhumby.cmp_entities.dates as dates_base
import dunnhumby.cmp_entities.products as products_base
import dunnhumby.cmp_entities.stores as stores_base
import dunnhumby.cmp_entities.transactions as transactions_base
import dunnhumby.cmp_features.purchasingfeaturecoordinator3 as base
import monoprix.cmp_entities.channels as channels
import monoprix.cmp_entities.customers as customers
import monoprix.cmp_entities.dates as dates
import monoprix.cmp_entities.products as products
import monoprix.cmp_entities.stores as stores
import monoprix.cmp_entities.transactions as transactions

logger = logging.getLogger(__name__)


class PurchasingFeatureCoordinator3(base.PurchasingFeatureCoordinator3):
    """
    Monoprix purchasing feature coordinator 3
    """
    def __init__(self, config, cadence_attribute, run_date=datetime.date.today()):
        super(PurchasingFeatureCoordinator3, self).__init__(config, cadence_attribute, run_date)
        self.__dates = None
        self.__customer = None
        self.__product = None
        self.__transactions = None
        self.__store = None
        self.__channel = None
        self.Dates = dates.Dates(self.config)
        self.Transactions = transactions.Transactions(self.config)
        self.Product = products.Products(self.config)
        self.Channel = channels.Channels(self.config)
        self.Store = stores.Stores(self.config)
        self.Customer = customers.Customers(self.config)

        # In the future I suspect the list of Product Affinity Clusters (PACs)
        # will get passed in from an external caller. For now though we're putting
        # them here in the code and I think its OK to do so because they will not be
        # changing very often.
        # Jamie Thomson, 2018-01-08
        features_specs = [
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "StdDevNetSpendPerDuration_1w52w",
                    "CustomerGender", "CustomerAgeRange",
                    "CustomerPriceSensitivity", "IsEmailable", "SloyaltyHigh", "SloyaltyLow",
                    "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Customer", "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {},
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": []
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Group"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            }]
                    }]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Subgroup"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow", "CustomerRegion",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "InstoreShelf"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow", "CustomerRegion",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Group"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow", "CustomerRegion",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "name": "PACs",
                "is_active": True,
                "cadence_attribute": "fis_week_id",
                "rsd": 0.0,
                "dimension_attribute_grain": {"ProductAttribute": "Section",
                                              "CustomerAttribute": "Customer"},
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"],
                "entity_groups_specifications":
                    [
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06212",
                                        "CP11469",
                                        "CP26338",
                                        "CP11487",
                                        "CP26337",
                                        "CP11326",
                                        "CA06213",
                                        "CP13987",
                                        "CP26340",
                                        "CP25187",
                                        "CP26445"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "42"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP21021",
                                        "CP21193",
                                        "CP21194",
                                        "CP21195",
                                        "CP21428",
                                        "CP21430",
                                        "CP21433",
                                        "CP21473"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "48"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP14307",
                                        "CP14388",
                                        "CP14429",
                                        "CP14468",
                                        "CP26444",
                                        "CP26443",
                                        "CP14448",
                                        "CP14302",
                                        "CP14477"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "43"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07252",
                                        "CA07251",
                                        "CA07253",
                                        "CA07381",
                                        "CA07380"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "49"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP10492",
                                        "CP28158",
                                        "CP28159",
                                        "CP17185",
                                        "CP11091",
                                        "CP28118",
                                        "CP11087",
                                        "CP11090",
                                        "CP28114"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "24"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06177",
                                        "CP25000",
                                        "CP14304",
                                        "CP23424"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "25"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07282",
                                        "CA07268",
                                        "CA07271",
                                        "CA07272",
                                        "CA07270",
                                        "CA07269",
                                        "CA07281",
                                        "CA07007",
                                        "CA06263"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "26"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07295",
                                        "CA07296",
                                        "CA07297",
                                        "CA07293",
                                        "CA07291",
                                        "CA07290",
                                        "CA07294",
                                        "CA07292",
                                        "CA06244"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "27"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06530",
                                        "CA06224"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "20"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP17003",
                                        "CP17017",
                                        "CP17148",
                                        "CP17149",
                                        "CP17150",
                                        "CP17460",
                                        "CP17465",
                                        "CP17466",
                                        "CP25958",
                                        "CP17247",
                                        "CP17464",
                                        "CP17461",
                                        "CP17192",
                                        "CP17463",
                                        "CP17493",
                                        "CP25959"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "21"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP11001",
                                        "CA06240",
                                        "CA07264",
                                        "CA07262",
                                        "CA07265",
                                        "CA07260",
                                        "CA07259",
                                        "CA07266",
                                        "CA07258",
                                        "CA06204",
                                        "CA06237",
                                        "CA06239",
                                        "CP17687"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "22"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP14308",
                                        "CP14309",
                                        "CP14317",
                                        "CP14470",
                                        "CP14471",
                                        "CP14472",
                                        "CP14491",
                                        "CP14520"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "23"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP10486",
                                        "CA06989",
                                        "CA07569",
                                        "CP14980",
                                        "CP25983",
                                        "CA06246",
                                        "CP26440",
                                        "CP11083",
                                        "CA07964"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "46"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP10010",
                                        "CP10481",
                                        "CP10482",
                                        "CP13013",
                                        "CP13306",
                                        "CP13589",
                                        "CP25025",
                                        "CP25186"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "47"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06205",
                                        "CA06227",
                                        "CA06228",
                                        "CP14303",
                                        "CP14459",
                                        "CP14467",
                                        "CP14476",
                                        "CA06238",
                                        "CA06231"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "44"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP23196",
                                        "CA07274"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "45"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06352",
                                        "CA06315",
                                        "CA06347",
                                        "CA06349",
                                        "CA06318",
                                        "CA06331"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "28"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP11096",
                                        "CP11321",
                                        "CP11324",
                                        "CP11586",
                                        "CP11587",
                                        "CP14479",
                                        "CP14496",
                                        "CP14497",
                                        "CP14499",
                                        "CP21431",
                                        "CP10489",
                                        "CP14498",
                                        "CP11323",
                                        "CP23404"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "29"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06000",
                                        "CP19000",
                                        "CP14000",
                                        "CP10000",
                                        "CP21000",
                                        "CP11000",
                                        "CP23000",
                                        "CP26000"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "40"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP26342",
                                        "CP26343",
                                        "CP26344",
                                        "CP26441"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "41"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP23422",
                                        "CP23423",
                                        "CP21438",
                                        "CP23886"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "1"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06174",
                                        "CA06173",
                                        "CP13000",
                                        "CP10490",
                                        "CA06329",
                                        "CA06169",
                                        "CA06176",
                                        "CP18018",
                                        "CP18073",
                                        "CP17439",
                                        "CP28961"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "3"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06616",
                                        "CA06651",
                                        "CP14979",
                                        "CP14978",
                                        "CP14977",
                                        "CP14449",
                                        "CP28327",
                                        "CP28161",
                                        "CP28028"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "2"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07267",
                                        "CA06386",
                                        "CP14541",
                                        "CA06223",
                                        "CP14310",
                                        "CP14353"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "5"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP26999",
                                        "CP26339",
                                        "CP14480",
                                        "CP26701",
                                        "CP13389",
                                        "CP14305",
                                        "CP11071",
                                        "CP11191",
                                        "CP26442"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "4"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07284",
                                        "CA06220",
                                        "CA06366",
                                        "CP11084",
                                        "CP17147",
                                        "CP17462",
                                        "CA07283",
                                        "CP11085",
                                        "CP11086"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "7"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP14348",
                                        "CP14458",
                                        "CP14457"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "6"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP21345",
                                        "CP21320",
                                        "CA07257",
                                        "CA07256",
                                        "CA07255"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "9"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP25446",
                                        "CP13997",
                                        "CP13998",
                                        "CP10484",
                                        "CP10488",
                                        "CA07254",
                                        "CA07385"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "8"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06044",
                                        "CA07045",
                                        "CA06711",
                                        "CP08000",
                                        "CP18000",
                                        "CA07000"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "39"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07298",
                                        "CA07261"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "38"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP23421",
                                        "CP14332",
                                        "CP23390",
                                        "CP28319",
                                        "CP23415",
                                        "CP28369",
                                        "CP25960",
                                        "CA06621"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "11"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP28157",
                                        "CP28156"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "10"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06850",
                                        "CA06198",
                                        "CA06199",
                                        "CA06202",
                                        "CA06217",
                                        "CP11092",
                                        "CP11093",
                                        "CP11095",
                                        "CP14311",
                                        "CP14447",
                                        "CP14456",
                                        "CP23403",
                                        "CP28153",
                                        "CA06200"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "13"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP23410",
                                        "CP23414",
                                        "CP23409",
                                        "CP23402",
                                        "CP23416",
                                        "CP14455",
                                        "CP11588",
                                        "CP23418",
                                        "CP23023",
                                        "CP23405",
                                        "CP23417",
                                        "CP23411"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "12"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06379",
                                        "CA06373",
                                        "CA06368",
                                        "CA06372",
                                        "CA06371",
                                        "CA06375",
                                        "CA06376",
                                        "CA06378"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "15"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP17973",
                                        "CP17360",
                                        "CA06963",
                                        "CP17426",
                                        "CA06006",
                                        "CA06330"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "14"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP13970",
                                        "CP13885",
                                        "CP13545",
                                        "CP13556",
                                        "CP13677",
                                        "CP13847"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "17"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP21408",
                                        "CP23437",
                                        "CP21401"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "16"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP14014",
                                        "CP19019",
                                        "CP26026",
                                        "CP11011"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "19"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP17350",
                                        "CP17521",
                                        "CP17798"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "18"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP23407",
                                        "CA06229",
                                        "CP26341",
                                        "CP21434",
                                        "CP23435",
                                        "CP11189",
                                        "CP21432",
                                        "CP21355",
                                        "CP23425"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "31"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06206",
                                        "CA06234",
                                        "CA06361",
                                        "CA07286",
                                        "CA06982",
                                        "CA06374",
                                        "CP08008"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "30"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP10485",
                                        "CP10483"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "37"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CP28000",
                                        "CP17097",
                                        "CP17000",
                                        "CP23065"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "36"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06203",
                                        "CA06230",
                                        "CP11081",
                                        "CP11322",
                                        "CP11325",
                                        "CP14475",
                                        "CP19241",
                                        "CP23419",
                                        "CP26335"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "35"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06232",
                                        "CA07273",
                                        "CP14478",
                                        "CP19243",
                                        "CP19242",
                                        "CP14387",
                                        "CA06188",
                                        "CA06226",
                                        "CA06233",
                                        "CA06225",
                                        "CP14316",
                                        "CP08301"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "34"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06201",
                                        "CA06208",
                                        "CA06209",
                                        "CA06210",
                                        "CA06211",
                                        "CA06215",
                                        "CA06218",
                                        "CA06219",
                                        "CA06221",
                                        "CA06222",
                                        "CA06207",
                                        "CA06216"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "33"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA06164",
                                        "CA06165",
                                        "CA06166",
                                        "CA06167",
                                        "CA06168",
                                        "CA06170",
                                        "CA06171",
                                        "CA06172",
                                        "CA06450",
                                        "CA06451",
                                        "CA06524",
                                        "CA07277",
                                        "CA07275",
                                        "CA07276"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "32"
                        },
                        {
                            "entity_groups": [
                                {
                                    "members": "*",
                                    "entity": "Customer"
                                },
                                {
                                    "members": [
                                        "CA07289",
                                        "CA07249",
                                        "CA07250",
                                        "CA07288",
                                        "CA07248",
                                        "CA07279",
                                        "CA07278",
                                        "CA07287"
                                    ],
                                    "entity": "Product"
                                }
                            ],
                            "is_active": True,
                            "name": "50"
                        }
                    ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Section"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow", "CustomerRegion",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "InstoreAisle"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "CustomerGender", "CustomerAgeRange", "CustomerPriceSensitivity", "IsEmailable",
                    "SloyaltyHigh", "SloyaltyLow", "CustomerRegion",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"}
                ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Product"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "BasketsFlag_1w52w",
                    "ProductDescription", "Subgroup", "SubgroupDescription",
                    "Group", "GroupDescription", "Section", "SectionDescription",
                    "Department", "DepartmentDescription", "Division",
                    "DivisionDescription", "InstoreShelf", "InstoreShelfDescription",
                    "InstoreAisle", "InstoreAisleDescription", "ProductBrand",
                    "IsSoldByWeight", "ProductSupplier", "ProductImageUri", "IsAlcohol",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            }]
                    }],
                "supplementary_dataframes": [
                    {"entity": "Products", "fields": "*"}
                ]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Subgroup"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            }]
                    }]
            },
            {
                "name": "",
                "is_active": True,
                "cadence_attribute": "fis_week_id",
                "rsd": 0.0,
                "dimension_attribute_grain": {"ProductAttribute": "Product",
                                              "CustomerAttribute": "Customer"},
                "supplementary_dataframes": [
                    {"entity": "Customers", "fields": "*"},
                    {"entity": "Products", "fields": "*"}
                ],
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "BasketsFlag_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "StdDevNetSpendPerDuration_1w52w",
                    "CustomerGender", "CustomerAgeRange",
                    "CustomerPriceSensitivity", "IsEmailable", "SloyaltyHigh", "SloyaltyLow",
                    "CustomerRegion",
                    "ProductDescription", "Subgroup", "SubgroupDescription", "Group",
                    "GroupDescription", "Section", "SectionDescription", "Department",
                    "DepartmentDescription", "Division", "DivisionDescription", "InstoreShelf",
                    "InstoreShelfDescription", "InstoreAisle", "InstoreAisleDescription",
                    "ProductBrand", "IsAlcohol",
                    "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "ProductAttribute": "InstoreShelf"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            }]
                    }]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Section"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            }]
                    }]
            },
            {
                "name": "",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "ProductAttribute": "InstoreAisle"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"
                ],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": "*"
                            }]
                    }]
            },
            {
                "name": "PACs",
                "is_active": True,
                "cadence_attribute": "fis_week_id",
                "rsd": 0.0,
                "dimension_attribute_grain": {"ProductAttribute": "InstoreShelf",
                                              "CustomerAttribute": "Customer"},
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w", "NetSpendPerBasket_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w", "NetSpendPerBasket_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w", "NetSpendPerBasket_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w", "NetSpendPerBasket_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w", "NetSpendPerBasket_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyDays_1w52w",
                    "CyclesSinceLastPurchase_1w52w",
                    "StdDevNetSpendPerDuration_1w52w", "max_purchase_date_1w52w"],
                "entity_groups_specifications": [
                    {
                        "name": "1",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": [
                                    'MC5151_16', 'MC5151_17', 'MC5151_19', 'MC5151_27',
                                    'MC5151_50', 'MC5151_60', 'MC5151_65', 'MC5151_70']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "2",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": [
                                    'MH3131_50', 'MH3131_54', 'MH3131_56', 'MH3131_65', 'MH3131_70',
                                    'MH3131_74', 'MH3131_75', 'MH3131_79', 'MH3131_82', 'MH3131_84',
                                    'MH3131_88', 'MH3131_89']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "3",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": [
                                    'CA0606_06', 'CA0606_10', 'CA0606_24', 'CA0606_32', 'CA0606_61',
                                    'CA0606_64', 'CA0606_77', 'CP1414_08', 'CP1414_10', 'CP1414_12']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "4",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": [
                                    'CP1111_01', 'CP1717_02', 'CP1717_04', 'CP1717_05', 'CP1717_06',
                                    'CP1717_11', 'CP1717_13', 'CP1717_27', 'CP1717_28', 'CP1717_29',
                                    'CP1717_30', 'CP1717_31']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "5",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB5252_05', 'MB5252_10', 'MB5252_20',
                                            'MB5252_30', 'MB5252_35']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "6",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": [
                                    'MC5757_41', 'MC5757_42', 'MC5757_43', 'MC5757_44', 'MC5757_46',
                                    'MC5757_78', 'MC5757_79', 'MC5757_81', 'MC5757_83']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "7",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_27', 'MC5151_66', 'MC5151_67']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "8",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP2121_10', 'CP2323_01', 'CP2323_07', 'CP2323_09',
                                            'CP2323_10', 'CP2323_11', 'CP2525_06']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "9",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP1010_01', 'CP1010_02', 'CP1313_01', 'CP2121_01',
                                            'CP2121_03', 'CP2121_04', 'CP2121_19', 'CP2525_01',
                                            'CP2525_03', 'CP2525_04']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "10",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB5050_10', 'MB5050_26', 'MB5050_36', 'MB5050_44',
                                            'MB5050_46', 'MB6868_08', 'MB6969_70']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "11",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3636_04', 'MH3636_07', 'MH3636_10', 'MH3636_15',
                                            'MH3636_20', 'MH3636_21', 'MH3636_39', 'MH3636_61']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "12",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0707_61', 'CA0707_62', 'CA0707_70',
                                            'CA0707_71', 'CA0707_80', 'CA0707_81']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "13",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_58', 'CA0606_59', 'MB6767_90', 'MB6767_92']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "14",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_97', 'MB4949_02', 'MB5050_48', 'MB6767_15',
                                            'MB6767_50', 'MB6767_55', 'MB6767_80', 'MB6868_32']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "15",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_88', 'CA0606_89', 'CA0606_91', 'CA0606_93',
                                            'CA0606_94', 'CA0606_98', 'CA0606_99', 'CA0707_41',
                                            'MB6767_98']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "16",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3030_05', 'MH3030_06', 'MH3030_07', 'MH3030_08',
                                            'MH3030_09', 'MH3030_10', 'MH3030_31', 'MH3030_32',
                                            'MH3030_33', 'MH3030_34', 'MH3030_35', 'MH3030_36',
                                            'MH3030_39', 'MH3030_41', 'MH3030_43', 'MH3030_47',
                                            'MH3030_54']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "17",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP1010_09', 'CP1010_11', 'CP1111_03', 'CP1111_11',
                                            'CP1111_12', 'CP1313_03', 'CP2626_01', 'CP2626_03',
                                            'CP2626_04', 'CP2626_05', 'CP2828_05', 'CP2828_06']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "18",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_39', 'CA0606_62', 'CA0606_67', 'CA0606_68',
                                            'CA0707_46', 'CP1414_04', 'CP1414_05', 'CP1414_07',
                                            'CP1919_02', 'CP1919_03', 'CP1919_04']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "19",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_41', 'MH3333_11', 'MH3535_20', 'MH3535_22',
                                            'MH3535_24', 'MH3535_30', 'MH3535_34', 'MH3535_42',
                                            'MH3535_52', 'MH4848_70']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "20",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0707_01', 'CA0707_10', 'CA0707_12', 'CA0707_15',
                                            'CA0707_16', 'CA0707_90']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "21",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3333_01', 'MH3333_06', 'MH3333_08']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "22",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_14', 'CA0707_42', 'CP1717_25', 'CP1717_26',
                                            'CP2828_07', 'CP2828_08', 'MB5353_96']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "23",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_16', 'CA0606_20', 'CA0606_31',
                                            'CA0606_37', 'CP2323_13', 'CP2828_02']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "24",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB5252_07', 'MB5252_40', 'MB5252_50', 'MB5252_60',
                                            'MB5353_15', 'MB5353_21', 'MB5353_33', 'MB5555_02',
                                            'MB6969_71']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "25",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3434_02', 'MH3434_05', 'MH3434_06', 'MH3434_09',
                                            'MH3434_13', 'MH3434_16']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "26",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MC5656_03', 'MC5656_04', 'MC5656_08', 'MC5656_09',
                                            'MC5656_11', 'MC5656_12', 'MC5656_17', 'MC5656_18',
                                            'MC5656_20', 'MC5656_22', 'MC5656_36']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "27",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_01', 'CA0606_05', 'CA0606_11', 'CA0606_23',
                                            'CP1111_09', 'CP1111_10', 'CP1111_16', 'CP1414_06',
                                            'CP1414_09', 'CP1414_14', 'CP1414_17', 'CP1414_18']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "28",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_30', 'CP1818_51', 'CP2525_11', 'CP2525_20',
                                            'MC5151_82']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "29",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_56', 'CP0808_11', 'CP0808_13', 'CP0808_14',
                                            'CP0808_16', 'CP1111_02', 'CP1111_15', 'CP2323_12']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "30",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP1111_14', 'CP1414_01', 'CP1414_02', 'CP1414_03',
                                            'CP1414_11', 'CP1414_15', 'CP1414_16']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "31",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB6868_12', 'MB6868_16', 'MB6868_18', 'MB6868_20',
                                            'MB6868_68']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "32",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3333_12', 'MH3333_13', 'MH3333_14', 'MH3333_20',
                                            'MH3333_23']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "33",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3333_02', 'MH3333_03', 'MH3333_05', 'MH3333_18',
                                            'MH3333_19']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "34",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MC5656_33', 'MH3131_45', 'MH3131_46', 'MH3131_51',
                                            'MH3131_55', 'MH3131_58', 'MH3131_60', 'MH3131_62',
                                            'MH3131_64', 'MH3131_66', 'MH3131_68', 'MH3131_72',
                                            'MH3131_76', 'MH3131_85']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "35",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_17', 'CA0606_02', 'CA0606_15', 'CA0606_22',
                                            'CA0606_28', 'CA0606_46', 'CA0606_48', 'CP0808_12',
                                            'CP0808_15']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "36",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0707_50', 'CA0707_52', 'CA0707_63', 'CA0707_64',
                                            'CA0707_65', 'CA0707_66']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "37",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3434_41', 'MH3434_51', 'MH3535_32', 'MH3636_25',
                                            'MH4848_25', 'MH4848_56', 'MH4848_75', 'MH4848_80']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "38",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB5353_12', 'MB5555_12', 'MB5555_22', 'MB5555_32',
                                            'MB5555_42', 'MB5555_62', 'MB5555_92']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "39",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP1111_13', 'CP1111_17', 'CP1111_26', 'CP1717_01',
                                            'CP1717_12']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "40",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB6767_10', 'MB6767_30', 'MB6767_40', 'MB6767_60']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "41",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MC5656_06', 'MC5656_40', 'MC5656_94']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "42",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP0808_17', 'CP0808_19', 'CP0808_20', 'CP0808_22',
                                            'CP1313_02']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "43",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MB5252_16', 'MB6868_04', 'MB6868_06', 'MB6868_42',
                                            'MB6969_38', 'MB6969_48', 'MB6969_49', 'MB6969_72']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "44",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MH3434_08', 'MH3434_10', 'MH3434_15', 'MH3434_21']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "45",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0707_03', 'CA0707_40', 'CA0707_51', 'CA0707_67',
                                            'CA0707_69', 'CA0707_72', 'CA0707_73']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "46",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MC5151_23', 'MC5151_28', 'MC5151_76', 'MC5151_80',
                                            'MC5151_85', 'MC5656_10', 'MC5656_30', 'MC5656_35']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "47",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP2828_01', 'CP2828_03']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "48",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_07', 'CA0606_75', 'CA0707_47', 'CA0707_48',
                                            'CP0808_21']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "49",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CP2121_05', 'CP2121_06', 'CP2121_07', 'CP2121_08',
                                            'CP2121_33', 'CP2323_16']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "50",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['CA0606_18', 'CA0606_42', 'CA0606_81', 'CA0606_86']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }, {
                        "name": "51",
                        "is_active": True,
                        "entity_groups": [
                            {
                                "entity": "Product",
                                "members": ['MC5656_19', 'MH4848_05', 'MH4848_10', 'MH4848_20']
                            },
                            {
                                "entity": "Customer",
                                "members": "*"
                            }]
                    }
                ]
            }
        ]
        logger.info('setting features_specifications to:')
        logger.info(features_specs)
        self.features_specifications = features_specs

    @property
    def Transactions(self):
        return self.__transactions

    @Transactions.setter
    def Transactions(self, value):
        """
        Transactions source class that will be used to generate features
        :param value:
        :return:
        """
        if not isinstance(value, transactions_base.Transactions):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.transactions.Transactions'))
        self.__transactions = value

    @property
    def Dates(self):
        return self.__dates

    @Dates.setter
    def Dates(self, value):
        """
        Dates source class
        :param value:
        :return:
        """
        if not isinstance(value, dates_base.Dates):
            raise TypeError(
                'value must be an implementation of {classname}'
                .format(classname='dunnhumby.cmp_entities.dates.Dates'))
        self.__dates = value

    @property
    def Product(self):
        return self.__product

    @Product.setter
    def Product(self, value):
        """
        Products source class
        :param value:
        :return:
        """
        if not isinstance(value, products_base.Products):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.products.Products'))
        self.__product = value

    @property
    def Channel(self):
        return self.__channel

    @Channel.setter
    def Channel(self, value):
        """
        Channels source class
        :param value:
        :return:
        """
        if not isinstance(value, channels_base.Channels):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.channels.Channels'))
        self.__channel = value

    @property
    def Store(self):
        return self.__store

    @Store.setter
    def Store(self, value):
        """
        Stores source class
        :param value:
        :return:
        """
        if not isinstance(value, stores_base.Stores):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.stores.Stores'))
        self.__store = value

    @property
    def Customer(self):
        return self.__customer

    @Customer.setter
    def Customer(self, value):
        """
        Customers source class
        :param value:
        :return:
        """
        if not isinstance(value, customers_base.Customers):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.customers.Customers'))
        self.__customer = value
