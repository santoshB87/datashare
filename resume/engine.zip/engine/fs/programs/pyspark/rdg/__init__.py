"""
rdg CMP Entities
"""
import logging
import os, ast

mm_database = os.environ.get('MM_DATABASE')
custom_fact_dim_databases = ast.literal_eval(os.environ.get('CUSTOM_FACT_DIM_DATABASES', '{}'))

logger = logging.getLogger(__name__)
