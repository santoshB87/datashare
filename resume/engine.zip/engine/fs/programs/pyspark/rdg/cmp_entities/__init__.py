"""
rdg CMP Entities
"""
import logging

logger = logging.getLogger(__name__)