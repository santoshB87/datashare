""""
rdg Channels
"""
from dunnhumby.cmp_entities.channels import Channels as baseChannels
from rdg import custom_fact_dim_databases, mm_database


# Data will flow into our solution through python classes that we define.
# Data will be sourced from Media Mart.
# Either way we need an abstraction over those data sources that defines the data as SSE requires
#  it.

class Channels(baseChannels):

    """
    Inherits the Base CMP channels entity class and overrides the get_data method
    """

    def __init__(self, config):
        """
        Define the Channels schema and column or columns that uniquely define a Channel
        """
        super(Channels, self).__init__()

        if "filters" in config:
            filter_config = config["filters"]
            if "channels" in filter_config:
                channels_config = filter_config["channels"]
            else:
                channels_config = {}
        else:
            channels_config = {}

        self.get_data(config_dict=channels_config)


    @property
    def database(self):
        return custom_fact_dim_databases.get("Channels", mm_database)
