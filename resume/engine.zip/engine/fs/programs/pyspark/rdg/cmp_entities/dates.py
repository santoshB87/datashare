""""
rdg Dates
"""
import logging

import dunnhumby
from rdg import custom_fact_dim_databases, mm_database

logger = logging.getLogger(__name__)


class Dates(dunnhumby.cmp_entities.dates.Dates):
    """
    Inherits the base CMP Customer class and implements the get_data() method'
    """

    def __init__(self, config):
        """
        Define the Dates schema and column or columns that uniquely define a Date
        """
        super(Dates, self).__init__()
        if "filters" in config:
            filter_config = config["filters"]
            if "dates" in filter_config:
                dates_config = filter_config["dates"]
            else:
                dates_config = {}
        else:
            dates_config = {}

        self.get_data(config_dict=dates_config)


    @property
    def database(self):
        return custom_fact_dim_databases.get("Dates", mm_database)
