""""
rdg Products
"""
import dunnhumby
from rdg import custom_fact_dim_databases, mm_database

# Data will flow into our solution through python classes that we define.
# Data will be sourced from Media mart.
# Either way we need an abstraction over those data sources that defines the data as SSE requires
#  it.

class Products(dunnhumby.cmp_entities.products.Products):
    """
    Inherits the Base CMP 'Products' entity class and overrides the get_data method
    """

    def __init__(self, config):
        """
        Define the Products schema and column or columns that uniquely define a Product
        """
        super(Products, self).__init__()

        if "filters" in config:
            filter_config = config["filters"]
            if "products" in filter_config:
                products_config = filter_config["products"]
            else:
                products_config = {}
        else:
            products_config = {}

        self.get_data(config_dict=products_config)


    @property
    def database(self):
        return custom_fact_dim_databases.get("Products", mm_database)
