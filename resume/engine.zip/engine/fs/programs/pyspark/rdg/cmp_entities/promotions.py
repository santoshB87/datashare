"""
rdg product_on_promotion_in_store module
"""
import dunnhumby.cmp_entities.promotions
from rdg import custom_fact_dim_databases, mm_database

# Data will flow into our solution through python classes that we define.
# Data will be sourced from CSV files through incoming promo feed.
# We need an abstraction over those data sources that defines the data as CMP requires it.

class Promotions(
    dunnhumby.cmp_entities.promotions.Promotions):
    """
    Inherits the Base CMP ProductOnPromotionInStore entity class and overrides the get_data method
    """

    def __init__(self, config):
        """
        Define the Promotions schema and column or columns that uniquely define a Promotion
        """
        super(Promotions, self).__init__()
        if "filters" in config:
            filter_config = config["filters"]
            if "promotions" in filter_config:
                promotions_config = filter_config["promotions"]
            else:
                promotions_config = {}
        else:
            promotions_config = {}

        self.get_data(config_dict=promotions_config)


    # pylint: disable=too-few-public-methods
    @property
    def database(self):
        return custom_fact_dim_databases.get("Promotions", mm_database)
