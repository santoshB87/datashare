""""
rdg Transactions
"""
from pyspark.sql import functions as F
from dunnhumby.cmp_entities.transactions import Transactions as baseTransactions
from rdg import custom_fact_dim_databases, mm_database


# Data will flow into our solution through python classes that we define.
# Data will be sourced from Media Mart.
# Either way we need an abstraction over those data sources that defines the data as SSE requires
#  it.


class Transactions(baseTransactions):
    """
    Inherits the Base CMP Transactions entity class and overrides the get_data method
    """

    def __init__(self, config):
        """
        Define the Transactions schema and column or columns that uniquely define a Transaction
        """
        super(Transactions, self).__init__()

        if "filters" in config:
            filter_config = config["filters"]
            if "transactions" in filter_config:
                transactions_config = filter_config["transactions"]
            else:
                transactions_config = {}
        else:
            transactions_config = {}

        self.get_data(config_dict=transactions_config)
        self.get_most_recent_transaction_date()

    def get_data(self, config_dict=None):
        transactions_df = self.sqlContext.table('.'.join([self.database, self.table])).drop('customer')
        customerlkp_df = self.sqlContext.table('.'.join([self.database, 'customerlkp'])).select("customer", "customeralt1").distinct()

        df = transactions_df.join(customerlkp_df, "customeralt1")

        if not bool(config_dict):
            df = df.select([field.name for field in self.required_schema.fields])
        else:
            filter_condition = config_dict["filter_condition"]
            df = df.filter(filter_condition).select([field.name for field in self.required_schema.fields])

        # Casting column datatypes to comply with CMP Entity schema
        for field in self.required_schema.fields:
            df = df.withColumn(field.name, df[field.name].cast(field.dataType))

        # Casting column datatypes to comply with CMP Entity schema
        # df = df.select(
        #     [F.col(field.name).cast(field.dataType)
        #      for field in self.required_schema.fields])

        self.data = df

    @property
    def database(self):
        return custom_fact_dim_databases.get("Transactions", mm_database)
