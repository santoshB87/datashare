"""RDG features module"""
import logging

logger = logging.getLogger(__name__)
