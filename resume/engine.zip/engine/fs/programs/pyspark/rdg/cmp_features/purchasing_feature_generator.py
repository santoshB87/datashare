"""
rdg Purchasing feature generator
"""

import logging
import pyspark.sql.functions as pf
from copy import deepcopy
from dunnhumby.cmp_features.purchasing_feature_generator_base import PurchasingFeatureGeneratorBase
from dunnhumby.cmp_features.features_specification_parser_base import FeaturesSpecificationParserBase
from rdg.cmp_entities.customers import Customers
from rdg.cmp_entities.stores import Stores
from rdg.cmp_entities.channels import Channels
from rdg.cmp_entities.products import Products
from rdg.cmp_entities.purchases import Purchases
from rdg.cmp_entities.transactions import Transactions
from rdg.cmp_entities.dates import Dates

import datetime

logger = logging.getLogger(__name__)


class PurchasingFeatureGenerator(PurchasingFeatureGeneratorBase, FeaturesSpecificationParserBase):
    """
    RDG Purchasing feature generator
    """

    def __init__(self, config, feature_specs, cadence_attribute, run_date, refresh_denorm=False, refresh_summary=False):
        """

        :param config: client config
        :param feature_specs: client feature specifications
        :param cadence_attribute: cadence attribute can be either fis_week_id or date_short_name
        for either week or daily feature calculation.
        :param run_date: run_date can be either current date i.e today or any specific past date
        for which feature will be calculated.
        """
        super(PurchasingFeatureGenerator, self).__init__(config=config,
                                                         cadence_attribute=cadence_attribute,
                                                         run_date=run_date)

        self._refresh_denorm = refresh_denorm
        self._refresh_summary = refresh_summary

        # feature specification, based on this list feature will be created, this should contain
        # atleast these elements.
        # name - feature name, this will derive all the hive table names (final & temp tables).
        # cadence_attribute - on which time dimension feature is calculated (not in use now,
        # included for future use).
        # is_active - active flag, whether feature should be calculated or not.
        # summary_on - summary creation flag, whether feature needs its own summary or not.
        # durations - list of time durations for which feature is calculated.
        # rsd - rsd value i.e error rate for distinct calc (not in use now, included for future use)
        # dimension_attribute_grain - grouping information, which dimension attribute should be used
        # for grouping in calculation of feature metrics.
        # base_features - list of feature metrics which will be calculated in summary & upward.
        # derived_features - list of feature metrics which are based on some other metrics.
        # dependent_derived_features - list of feature metrics which are based on metrics which
        # don't belong to same table.
        # distinct_features - list of features metrics which are calculated as distinct of something
        feature_distinct_tab_spec = {
            "name": deepcopy(self.config["SSEFeatureDistinctTab"]),
            "durations": self.durations,
            "dimension_attribute_grain": {
                # These should be list of attribute, please don't mention all instead use empty
                # list in place of all
                "ProductAttribute": deepcopy(self._product_hierarchy),
                "CustomerAttribute": ["Customer"],
                "StoreAttribute": ["Store"],
                "ChannelAttribute": []
            }
        }
        feature_specs.append(feature_distinct_tab_spec)
        self.features_specifications = self._parse_feature_specs(feature_specs)

    @property
    def purchases(self):
        """
        Return Purchases entity object, should be used for only accessing/deleting metadata info,
        if used for data access they will result in full scan of object/fact table
        :return: purchases: rdg.cmp_entities.purchases.Purchases
        """
        if self._purchases is None:
            self._purchases = Purchases(config=self.config)
        return self._purchases

    @property
    def transactions(self):
        """
        Return Transactions entity object, should be used for only accessing metadata info and
        reading single partitions only else will result in full scan of object/fact table
        :return: transactions: rdg.cmp_entities.transactions.Transactions
        """
        if self._transactions is None:

            self._transactions = Transactions(config=self.config)
        return self._transactions


    @property
    def customers_df(self):
        """
        Return Customers entity's data (only required columns) as spark dataframe
        :return: customers_df: Dataframe
        """
        if self._customer_df is None:
            customers = Customers(config=self.config)  # use this in cluster run
            # customers = self.get_cust()  # use this in docker, it uses mock
            customers_df = customers.data.select('Customer', 'FulfillmentStore',
                                                 'PreferredStore1', 'PreferredStore2',
                                                 'PreferredStore3')
            self._customer_df = customers_df
        return self._customer_df

    @customers_df.setter
    def customers_df(self, customers_df):
        """
        Accommodate any changes in customer_df, doesn't do any kind check before assigning
        :param customers_df: dataframe containing information about customer entity
        :return: None
        """
        self._customer_df = customers_df

    @property
    def products_df(self):
        """
        Return Products entity's data (only required columns) as spark dataframe
        Add pac column if required
        :return: products_df: Dataframe
        """
        if self._products_df is None:
            products = Products(config=self.config)
            products_df = products.data

            #Attach PAC hierarchy if PAC features are enabled
            if self._pac_flag:
                pacs = self.sqlContext.table('.'.join([self.config["SSEHiveWorkdb"],'pac_subgroup_table']))
                pacs_df = pacs.withColumnRenamed("affinityclusternum", "PacSubgroup").\
                               withColumnRenamed("subgroup", "Subgroup")
                products_df = products_df.join(pacs_df, 'Subgroup', "left_outer")

            #Select only required columns
            products_df = products_df.select(self._product_hierarchy)

            self._products_df = products_df
        return self._products_df

    @products_df.setter
    def products_df(self, products_df):
        """
        Accommodate any changes in products_df, doesn't do any kind check before assigning
        :param products_df: dataframe containing information about product entity
        :return: None
        """
        self._products_df = products_df

    @property
    def dates_df(self):
        """
        Return Dates entity's data as spark dataframe
        :return: dates_df: Dataframe
        """
        if self._dates_df is None:
            # dates = Dates()  # use this in cluster run
            # customers = self.get_cust()  # use this in docker, it uses mock
            # dates_df = dates.data
            # self._customer_df = customers_df
            dates_table = Dates(config=self.config).data.select(pf.col('date_id').cast("date"), 'fis_week_id', 'fis_day_of_week_num').drop_duplicates()
            dates_df = self.transactions.data.select('fis_week_id', 'fis_year_id').drop_duplicates()
            dates_df = dates_df.join(dates_table, ['fis_week_id']).drop_duplicates()
            #old version-The fis_day_of_week_num column should be set to  : 1 for Sunday - 7 for Saturday
            #old version-dayofweek = pf.udf(lambda date: ((datetime.datetime.weekday(date) + 1) % 7) + 1)
            #old version-dates_df = dates_df.withColumn('fis_day_of_week_num', dayofweek('date_id'))
            ## Caching dates_df here to avoid repeated computation over transactions
            dates_df.cache()
            self._dates_df = dates_df
        return self._dates_df

    @dates_df.setter
    def dates_df(self, dates_df):
        """
        Accommodate any changes in customer_df, doesn't do any kind check before assigning
        :param dates_df: dataframe containing information about customer entity
        :return: None
        """
        self._dates_df = dates_df

    @property
    def stores_df(self):
        """
        Return Stores entity's data (only required columns) as spark dataframe
        :return: stores_df: Dataframe
        """
        if self._stores_df is None:
            stores = Stores(config=self.config)
            stores_df = stores.data
            stores_df = stores_df.select('Store', 'Banner')
            self._stores_df = stores_df
        return self._stores_df

    @stores_df.setter
    def stores_df(self, stores_df):
        """
        Accommodate any changes in customer_df, doesn't do any kind check before assigning
        :param customers_df: dataframe containing information about customer entity
        :return: None
        """
        self._stores_df = stores_df



    def register_supplementary_tables(self):
        """
        Client implementation to register supplementary table required to derive extra dimension
        attribute or any other supplementary column/information.
        :return: (True/False, tab_lst): (boolean, list() of supplementary table)
        """
        work_db = self.config["SSEHiveWorkdb"]
        logger.info("Creating required supplementary table in work db %s", work_db)
        tab_lst = []
        # products = Products()
        # products_df = products.data.select(self._product_hierarchy)
        temp_table = work_db + "." + "Product_dim_tab"
        self.sqlContext.sql("DROP TABLE IF EXISTS " + temp_table)
        self.products_df.repartition(200).write.saveAsTable(temp_table, format="parquet",
                                                       mode="overwrite")
        tab_lst.append("Product_dim_tab")
        db_tab_lst = [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]

        return all([True for item in tab_lst if item.lower() in db_tab_lst]), tab_lst

    def delete_supplementary_tables(self, tab_lst):
        """
        Client implementation to delete supplementary tables required to derive extra dimension
        attribute or any other supplementary column/information.
        :param tab_lst: list() of supplementary table
        :return: True/False: boolean
        """
        work_db = self.config["SSEHiveWorkdb"]
        logger.info("Deleting supplementary table in work db %s", work_db)
        for tab in tab_lst:
            self.sqlContext.sql("DROP TABLE IF EXISTS " + work_db + "." + tab)
        return True
