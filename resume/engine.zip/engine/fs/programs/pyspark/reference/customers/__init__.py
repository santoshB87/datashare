import logging
from customers import get_customers

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
