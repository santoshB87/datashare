import pyspark.sql.types as types
import logging
from tools.dataframe_utilities import check_df_for_duplicates
from tools.config.sse_hive_database_prefix import get_sse_hive_database_prefix_from_config
from tools.config.customer import get_customer_identifying_attribute_from_config

logger = logging.getLogger(__name__)


def get_customers(sc, sqlContext, config):
    '''
    Exists to provide a market-agnostic abstraction over the data source for customers. The set of columns provided in the
     returned dataframe is the minimum set of required columns. More columns can be added as required.
    '''
    expected_schema = types.StructType(
        [
            types.StructField("Customer",               types.StringType(), True)
        ]
    )

    df = get_customers_from_card_dim_h(sqlContext, config)
    if df.schema != expected_schema:
        raise RuntimeError(
            'Schema returned dataframe does not match the expected schema. This is prohibited! Expected schema is '

            '{expected_schema}. '

            'Returned dataframe is '
            ''
            '{returned_schema}'.format(
                expected_schema=expected_schema, returned_schema=df.schema))
    """We're about to call check_for_duplicates on this DF so it makes sense to persist it,
            because its going to get used again by whatever calls this method"""
    df.persist()
    check_df_for_duplicates(df, ['Customer'])
    return df


def get_customers_from_card_dim_h(sqlContext, config):
    sse_hive_database_prefix = get_sse_hive_database_prefix_from_config(config)
    customer_identifying_attribute = get_customer_identifying_attribute_from_config(config)
    df = sqlContext.table('{sse_hive_database_prefix}_ssewh.card_dim_h'.format(
        sse_hive_database_prefix=sse_hive_database_prefix
    ))
    df = df.withColumnRenamed(customer_identifying_attribute, 'Customer')
    df = df.filter(df.active_flag == 'Y')
    select_columns_list = [
        'Customer'
    ]
    df = df.select(select_columns_list)
    return df

