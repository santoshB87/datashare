import pyspark.sql.types as types
import pyspark.sql.functions as funcs
import datetime
import logging
from tools.dataframe_utilities import check_df_for_duplicates,check_week_id_conforms_to_iso8601

logger = logging.getLogger(__name__)


def get_dates(sc, sqlContext, config):
    '''
    Exists to provide a market-agnostic abstraction over the data source for dates. The set of columns provided in the
     returned dataframe is the minimum set of required columns. More columns can be added as required.
    Note that at the time of writing a single implementation is provided to suit all markets. It is fully expected that
     market-specific implementations will be required in the future. This is both fine and expected, as long as the
     column names are adhered to.
    The author thought long and hard about what the column names should be. In the end it was decided to adhere to
     column names that are already defined in CDM. No advantage was discerned to be gained by deviating from
     those conventions. To put it another way, someone has clearly put a lot of thought into the names of those columns,
     why bother changing them given that the concept of a date dimension is by its very nature market agnostic.
    Returns:

    '''
    expected_schema = types.StructType(
        [
            types.StructField("date_id",                types.DateType(),   True),
            types.StructField("date_name",              types.StringType(), True),
            types.StructField("date_short_name",        types.StringType(), True),
            types.StructField("day_of_week_name",       types.StringType(), True),
            types.StructField("fis_week_id",            types.StringType(), True),
            types.StructField("fis_day_of_week_num",    types.ShortType(),  True)
        ]
    )

    sse_hive_database_prefix = config['SSEHiveDatabasePrefix']
    df = get_dates_from_date_dim(sqlContext, sse_hive_database_prefix)
    if df.schema != expected_schema:
        raise RuntimeError(
            'Schema returned dataframe does not match the expected schema. This is prohibited! Expected schema is '

            '{expected_schema}. '

            'Returned dataframe is '
            ''
            '{returned_schema}'.format(
                expected_schema=expected_schema, returned_schema=df.schema))
    """We're about to call check_for_duplicates on this DF so it makes sense to persist it,
            because its going to get used again by whatever calls this method"""
    df.persist()
    check_df_for_duplicates(df, ['date_id'])
    check_week_id_conforms_to_iso8601(df, 'fis_week_id')
    return df


def get_dates_from_date_dim(sqlContext, sse_hive_database_prefix):
    df = sqlContext.table('{sse_hive_database_prefix}_ssewh.date_dim'.format(
        sse_hive_database_prefix=sse_hive_database_prefix
    ))
    select_columns_list = [
        'date_id',
        'date_name',
        'date_short_name',
        'day_of_week_name',
        'fis_week_id',
        'fis_day_of_week_num'
    ]
    # At some point in the past it was decided that date_id field should be sourced as a string when in fact its a Date.
    # Let's fix that.
    df = df.withColumn('date_id', df.date_id.cast(types.DateType()))
    df = df.withColumn('fis_day_of_week_num', df.fis_day_of_week_num.cast(types.ShortType()))
    df = df.withColumn('fis_week_id', df.fis_week_id.cast(types.StringType()))
    #Converting fis_week_id to format YYYYWww to conform to ISO8601 https://en.wikipedia.org/wiki/ISO_8601#Week_dates
    df = df.withColumn('fis_week_id',
                       funcs.concat(df.fis_week_id.substr(1, 4), funcs.lit('W'), df.fis_week_id.substr(5, 2)))
    df = df.select(select_columns_list)
    return df


def get_previous_period_code(sc, sqlContext, config, period_code_type):
    logger.info('period_code_type: {period_code_type}'.format(period_code_type=period_code_type))
    all_dates_df = get_dates(sc, sqlContext, config)
    all_dates_df.cache()
    logger.info('all_dates_df.count(): {count}'.format(count=str(all_dates_df.count())))
    today = datetime.datetime.now().date()
    logger.info('today: {today}'.format(today=today))
    current_date = all_dates_df.filter(all_dates_df.date_id == today).collect()
    current_date_single_row = current_date[0]
    period_code_for_current_date = current_date_single_row[period_code_type]
    all_previous_period_codes_for_given_period_code_type = all_dates_df.select(period_code_type).distinct().filter(
        all_dates_df[period_code_type] < period_code_for_current_date)
    previous_period_code = all_previous_period_codes_for_given_period_code_type.orderBy(
            all_dates_df[period_code_type].desc()
        ).collect()[0][period_code_type]
    previous_period_code =  previous_period_code.replace('-',
                                 '')  # can't have dashes in the returned value because it gets used in hive object names
    logger.info('previous_period_code: {previous_period_code}'.format(previous_period_code=previous_period_code))
    return previous_period_code

