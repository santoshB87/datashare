from tools.config.product.product_attributes import *
from tools.config.sse_hive_database_prefix import get_sse_hive_database_prefix_from_config
from tools.config.client import *
from tools.dataframe_utilities import check_df_for_duplicates
import pyspark.sql.functions as f
from pyspark.sql.window import Window
import logging

logger = logging.getLogger(__name__)


def get_products(sqlContext, config):
    """
    Out solution requires an abstraction over the product dimension. A single method that returns a dataframe
      containing all information about products. This is that method.
    The returned dataframe will have an identical schema for each client, the implementation can (and likely will) be
     different per-client
    :param sc: Sparkcontext
    :param sqlContext: Spark SqlContext
    :param config: configuration object
    :return: dataframe of products
    """

    client = get_client_from_config(config)
    df = _get_products_for_client(sqlContext, config, client)
    """We're about to call check_for_duplicates on this DF so it makes sense to persist it,
        because its going to get used again by whatever calls this method"""
    df.persist()
    check_df_for_duplicates(df, ['Product'])
    return df


def _get_products_for_client(sqlContext, config, client):
    df = None
    if client in []:
        # at the time of writing there are no more client-specific customisation required here, but there undoubtedly
        # will be in the future when PROD_DIM_H is no longer the table that we have to go to
        pass
    elif client in ['met']:
        df = _get_products_from_prod_dim_h(sqlContext, config)
        df = _eliminate_duplicate_products(df)
    else:
        df = _get_products_from_prod_dim_h(sqlContext, config)
    return df


def _get_products_from_prod_dim_h(sqlContext, config):
    """In config we store mappings between what product attributes are called in the source, and what we refer
        to them as in SSE. In order to keep SSE agnostic of the source system the agnostic names are simply
        0, 1, 2, 3 etc... (because what else can we call them? Answer, nothing. And once upon a time we spent a lot of
        time debating this and couldn't come up with anything.).
        That said, we also have well-understood names for some product attributes too:
          Product - the attribute that unqiuely defines a product
          Subgroup - an attribute that defines a classification of Product
          Group - an attribute that defines a classification of Subgroup
          Division - an attribute that defines a classification of Group
        In essence these define a 4-level hierarchy of products. We expose these four attributes throughout SSE.
        """
    sse_hive_database_prefix = get_sse_hive_database_prefix_from_config(config)
    client_specific_0_attribute, \
    client_specific_1_attribute, \
    client_specific_2_attribute, \
    client_specific_3_attribute, \
    client_specific_4_attribute, \
    client_specific_5_attribute = _get_client_specific_attributes(config)
    product_product_attribute = get_product_product_attribute_from_config(config)
    product_subgroup_attribute = get_product_subgroup_attribute_from_config(config)
    product_group_attribute = get_product_group_attribute_from_config(config)
    product_division_attribute = get_product_division_attribute_from_config(config)
    df = sqlContext.table('{sse_hive_database_prefix}_ssewh.v_prod_dim_h'.format(
        sse_hive_database_prefix=sse_hive_database_prefix))
    df = df.withColumnRenamed(client_specific_0_attribute, '_0')
    df = df.withColumnRenamed(client_specific_1_attribute, '_1')
    df = df.withColumnRenamed(client_specific_2_attribute, '_2')
    df = df.withColumnRenamed(client_specific_3_attribute, '_3')
    df = df.withColumnRenamed(client_specific_4_attribute, '_4')
    df = df.withColumnRenamed(client_specific_5_attribute, '_5')
    df = df.withColumn('Product', f.col('_{attr}'.format(attr=product_product_attribute)))
    df = df.withColumn('ProductSubgroup', f.col('_{attr}'.format(attr=product_subgroup_attribute)))
    df = df.withColumn('ProductGroup', f.col('_{attr}'.format(attr=product_group_attribute)))
    df = df.withColumn('ProductDivision', f.col('_{attr}'.format(attr=product_division_attribute)))
    df = df.select(
        ['Product', 'ProductSubgroup', 'ProductGroup', 'ProductDivision', '_0', '_1', '_2', '_3', '_4', '_5']
    ).distinct()
    return df


def _eliminate_duplicate_products(df):
    """
    This function was originally written for Metro for which we had an issue where multiple records existed for the same
    Product (and it wasn't just because this is a type2 dimension table, there were still multiple records per product
    with ACtIVE_FLAG='Y'). The issue wasn't going to get resolved at source so a mechanism of eliminating duplicates
    was required, this function is that mechanism.
    We don't have any criteria with which I can choose the "correct" record for a Product, thus we need to
    arbitrarily choose one.
    The replacing of "DEFAULT_HIERARCHY" with "zzzzzz" ensures that where we have multiple records for a Product and
    one of those records is under "DEFAULT_HIERARCHY", that record will not be the one that gets chosen.
    If the only record that exists for a Product is indeed under "DEFAULT_HIERARCHY" then we still need to bring
    it through, we can't just filter them out because we do not know that there will not be transactions
    against such Products, thus we should err on the side of caution and assume that there are.
    -Jamie Thomson, 2017-03-02"""
    df = df.withColumn('columnToOrderBy', df.ProductSubgroup).replace('DEFAULT_HIERARCHY', 'zzzzzzz', 'columnToOrderBy')
    w = Window.partitionBy(df.Product).orderBy(f.asc('columnToOrderBy'))
    df = df.withColumn('row_number', f.row_number().over(w))
    df = df.filter(df.row_number == 1).drop(df.columnToOrderBy).drop(df.row_number)
    return df


def _get_client_specific_attributes(config):
    product_attribute_mappings = get_product_attribute_mappings_from_config(config)
    client_specific_0_attribute = _get_client_specific_attribute_for_client_agnostic_attribute(
        product_attribute_mappings,
        '0')
    client_specific_1_attribute = _get_client_specific_attribute_for_client_agnostic_attribute(
        product_attribute_mappings,
        '1')
    client_specific_2_attribute = _get_client_specific_attribute_for_client_agnostic_attribute(
        product_attribute_mappings,
        '2')
    client_specific_3_attribute = _get_client_specific_attribute_for_client_agnostic_attribute(
        product_attribute_mappings,
        '3')
    client_specific_4_attribute = _get_client_specific_attribute_for_client_agnostic_attribute(
        product_attribute_mappings,
        '4')
    client_specific_5_attribute = _get_client_specific_attribute_for_client_agnostic_attribute(
        product_attribute_mappings,
        '5')
    logger.info("""
    client_specific_0_attribute: {client_specific_0_attribute}
    client_specific_1_attribute: {client_specific_1_attribute}
    client_specific_2_attribute: {client_specific_2_attribute}
    client_specific_3_attribute: {client_specific_3_attribute}
    client_specific_4_attribute: {client_specific_4_attribute}
    client_specific_5_attribute: {client_specific_5_attribute}
    product_attribute_mappings: {product_attribute_mappings}
    """.format(
        client_specific_0_attribute=client_specific_0_attribute,
        client_specific_1_attribute=client_specific_1_attribute,
        client_specific_2_attribute=client_specific_2_attribute,
        client_specific_3_attribute=client_specific_3_attribute,
        client_specific_4_attribute=client_specific_4_attribute,
        client_specific_5_attribute=client_specific_5_attribute,
        product_attribute_mappings=product_attribute_mappings))
    return client_specific_0_attribute, \
           client_specific_1_attribute, \
           client_specific_2_attribute, \
           client_specific_3_attribute, \
           client_specific_4_attribute, \
           client_specific_5_attribute


def _get_client_specific_attribute_for_client_agnostic_attribute(product_attribute_mappings,
                                                                 client_agnostic_attribute):
    """
    You may notice there is some mixing up of the terms 'client' and 'market'
    This is because our solution used to refer to 'market' but somewhere near the end of 2016 there came a directive
    where we had to start talking about 'client' instead (undoubtedly because there is now more than one client
    per market given we're moving away from the JV model).
    Hence please accept that for some time there may be some mixing up of these terms.
    """
    return [
        attribute['MarketSpecificAttribute']
        for attribute in product_attribute_mappings
        if attribute['MarketAgnosticAttribute'] == client_agnostic_attribute
        ][0]
