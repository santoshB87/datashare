from tools.dataframe_utilities import check_df_for_duplicates
from tools.config.client import get_client_from_config
from tools.config.sse_hive_database_prefix import get_sse_hive_database_prefix_from_config
from tools.config.store import get_store_from_config
import logging

logger = logging.getLogger(__name__)

def get_stores(sc, sqlContext, config):
    """
    Out solution requires an abstraction over the store dimension. A single method that returns a dataframe
      containing all information about stores. This is that method.
    The returned dataframe will have an identical schema for each client, the implementation can (and likely will) be
     different per-client
    :param sc: Sparkcontext
    :param sqlContext: Spark SqlContext
    :param config: configuration object
    :return: dataframe of products
    """

    client = get_client_from_config(config)
    df = _get_stores_for_client(sqlContext, config, client)
    """We're about to call check_for_duplicates on this DF so it makes sense to persist it,
        because its going to get used again by whatever calls this method"""
    df.persist()
    check_df_for_duplicates(df, ['Store'])
    return df

def _get_stores_for_client(sqlContext, config, client):
    df = None
    if client in []:
        # at the time of writing there are no more client-specific customisations required here, but there undoubtedly
        # will be in the future when STORE_DIM_H is no longer the table that we have to go to
        pass
    else:
        df = _get_stores_from_store_dim_h(sqlContext, config)
    return df

def _get_stores_from_store_dim_h(sqlContext, config):
    sse_hive_database_prefix = get_sse_hive_database_prefix_from_config(config)
    store_identifying_attribute = get_store_from_config(config)
    df = sqlContext.table('{sse_hive_database_prefix}_ssewh.store_dim_h'.format(
        sse_hive_database_prefix=sse_hive_database_prefix
    ))
    df = df.filter(df.active_flag == 'Y')
    df = df.withColumnRenamed(store_identifying_attribute,  'Store'     )
    df = df.withColumnRenamed('store_name',                 'StoreName' )
    select_columns_list = [
        'Store',
        'StoreName'
    ]
    df = df.select(select_columns_list)
    return df