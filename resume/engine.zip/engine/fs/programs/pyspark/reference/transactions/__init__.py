import logging
from transactions import get_transactions

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
