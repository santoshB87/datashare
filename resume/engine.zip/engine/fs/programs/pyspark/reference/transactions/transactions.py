from tools.config.sse_hive_database_prefix import get_sse_hive_database_prefix_from_config
from tools.config.client import *
import logging
from pyspark.sql.types import *
import pyspark.sql.functions as funcs

logger = logging.getLogger(__name__)


def get_transactions(sc, sqlContext, config):
    """
    Our solution requires an abstraction over transactions. A single method that returns a dataframe
      containing all information about transactions. This is that method.
    The returned dataframe will have an identical schema for each client, the implementation can (and likely will) be
     different per-client
    Never persist the dataframe herein. The dataframe could potentially be massive and we want to ensure that any
    filters that may be applied in the consuming application get pushed down to the source. This is called predicate
    pushdown (https://www.slideshare.net/JamieThomson12/clipboards/predicatepushdown).
    To put that another way, the dataframe returned from this function will very possibly be cached by whatever is
    consuming it however if that is the case then that consuming appplication will probably have applied filters to it
    - those filters need to get pushed down to the source. Persisting herein would prevent that.
    :param sc: Sparkcontext
    :param sqlContext: Spark SqlContext
    :param config: configuration object
    :return: dataframe of transactions
    """

    client = get_client_from_config(config)
    sse_hive_database_prefix = get_sse_hive_database_prefix_from_config(config)
    df = get_transactions_for_client(sqlContext, client, sse_hive_database_prefix)
    """It is important that the dataframe returned from this function has exactly the same schema regardless
    of client. For that reason here the schema of the dataframe is being checked against the expected schema.
    This is not to say that the expected schema will not change in the future, but if it does so then it
    should change for every client"""
    expected_schema = StructType(
        [
            StructField("Basket", StringType(), True),
            StructField("Date", DateType(), True),
            StructField("Product", StringType(), True),
            StructField("Customer", StringType(), True),
            StructField("Store", StringType(), True),
            StructField("Quantity", IntegerType(), True),
            StructField("SpendAmount", DecimalType(18, 2), True),
            StructField("NetSpendAmount", DecimalType(18, 2), True),
            StructField("DiscountAmount", DecimalType(18, 2), True)
        ]
    )
    if df.schema != expected_schema:
        raise RuntimeError(
            'Schema returned dataframe does not match the expected schema. This is prohibited! Expected schema is '

            '{expected_schema}. '

            'Returned dataframe is '
            ''
            '{returned_schema}'.format(
                expected_schema=expected_schema, returned_schema=df.schema))
    return df


def get_transactions_for_client(sqlContext, client, sse_hive_database_prefix):
    df = None
    if client in []:
        pass
    elif client in ['met']:
        df = get_transactions_for_met(sqlContext, sse_hive_database_prefix)
    elif client in ['casbr']:
        df = get_transactions_for_casbr(sqlContext, sse_hive_database_prefix)
    else:
        raise NotImplementedError('Not immplemented for client={client}'.format(client=client))
    return df


def get_transactions_for_met(sqlContext, sse_hive_database_prefix):
    df = get_transactions_from_trans_table_joined_with_store_dim(sqlContext, sse_hive_database_prefix)
    df = df.withColumn('Basket', df.transaction_fid.cast(StringType()))
    df = df.withColumn('Date', funcs.to_date(df.date_id))
    df = df.withColumn('Product', df.prod_group_code)
    df = df.withColumn('Customer', df.prsn_code)
    df = df.withColumn('Store', df.store_code)
    df = df.withColumn('Quantity', df.item_qty.cast(IntegerType()))
    df = df.withColumn('SpendAmount', funcs.when(df.item_discount_amt == None, df.net_spend_amt).otherwise(
        df.net_spend_amt + df.item_discount_amt).cast(DecimalType(18, 2)))
    df = df.withColumn('NetSpendAmount', df.net_spend_amt.cast(DecimalType(18, 2)))
    df = df.withColumn('DiscountAmount', df.item_discount_amt.cast(DecimalType(18, 2)))
    df = df.select(['Basket', 'Date', 'Product', 'Customer', 'Store', 'Quantity', 'SpendAmount', 'NetSpendAmount',
                    'DiscountAmount'])
    return df


def get_transactions_for_casbr(sqlContext, sse_hive_database_prefix):
    df = get_transactions_from_trans_table_joined_with_store_dim(sqlContext, sse_hive_database_prefix)
    df = df.withColumn('Basket', df.transaction_fid.cast(StringType()))
    df = df.withColumn('Date', funcs.to_date(df.date_id))
    df = df.withColumn('Product', df.prod_code)
    df = df.withColumn('Customer', df.prsn_code)
    df = df.withColumn('Store', df.store_code)
    df = df.withColumn('Quantity', df.item_qty.cast(IntegerType()))
    df = df.withColumn('SpendAmount', df.spend_amt.cast(DecimalType(18, 2)))
    df = df.withColumn('NetSpendAmount', df.net_spend_amt.cast(DecimalType(18, 2)))
    df = df.withColumn('DiscountAmount', df.item_discount_amt.cast(DecimalType(18, 2)))
    df = df.select(['Basket', 'Date', 'Product', 'Customer', 'Store', 'Quantity', 'SpendAmount', 'NetSpendAmount',
                    'DiscountAmount'])
    return df


def get_transactions_from_trans_table_joined_with_store_dim(sqlContext, sse_hive_database_prefix):
    """The trans table contains nearly everything we need but in most (possibly all) cases it doesn't
    contain the store identifier, only the store surrogate key (which is useless to us other than for joining to
    store_dim).
    I don't know why this is the case, I'm guessing its because the first person that wrote the trans table didn't
    think we'd ever need the store identifier in there, and thereafter that first trans table basically got
    duplicated for each client. Annoying, but can't be helped.
    -Jamie Thomson, 2017-04-01"""
    trans_table_name = '{sse_hive_database_prefix}_ssepr.trans'.format(
        sse_hive_database_prefix=sse_hive_database_prefix)
    df = sqlContext.table(trans_table_name)
    store_table_name = '{sse_hive_database_prefix}_ssewh.store_dim_h'.format(
        sse_hive_database_prefix=sse_hive_database_prefix)
    store_df = sqlContext.table(store_table_name)
    df = df.join(store_df, 'store_id')
    return df

