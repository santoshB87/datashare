"""
Shoprite CMP
"""

import logging

import cmp_entities
import cmp_features
database = 'shoprite_media_mart'

logger = logging.getLogger(__name__)
