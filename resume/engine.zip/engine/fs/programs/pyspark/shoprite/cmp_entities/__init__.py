"""
Shoprite entities module
"""
import logging

database = 'shoprite_media_mart'
logger = logging.getLogger(__name__)
