import dunnhumby
from shoprite import database
import pyspark.sql.types as pt

# Data will flow into our solution through python classes that we define.
# The data will be sourced from media mart.
# Either way we need an abstraction over those data sources that defines the data as SSE requires it

class Customers(dunnhumby.cmp_entities.customers.Customers):
    """
    Inherits the Base CMP 'Products' entity class and overrides the get_data method
    """

    def __init__(self):
        """
        Define the Customers schema and column or columns that uniquely define a Customer
        """
        super(Customers, self).__init__()
        required_schema = pt.StructType()
        required_schema.add(pt.StructField('Customer', pt.StringType(), True))
        required_schema.add(pt.StructField('FulfillmentStore', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore1', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore2', pt.StringType(), True))
        required_schema.add(pt.StructField('PreferredStore3', pt.StringType(), True))

        self.required_schema = required_schema
        self.get_data()


    @property
    def database(self):
        return database
