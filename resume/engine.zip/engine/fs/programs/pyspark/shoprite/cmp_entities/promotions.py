"""
Shoprite promotions module
"""
import pyspark.sql.functions as F

import dunnhumby.cmp_entities.promotions


# Data will flow into our solution through python classes that we define.
# The data will be sourced from media mart.
# Either way we need an abstraction over those data sources that defines the data as SSE requires it

from shoprite import database
import dunnhumby.cmp_entities.promotions


# Data will flow into our solution through python classes that we define.
# Data will be sourced from CSV files through incoming promo feed.
# We need an abstraction over those data sources that defines the data as CMP requires it.

class Promotions(
    dunnhumby.cmp_entities.promotions.Promotions):
    """
    Inherits the Base CMP ProductOnPromotionInStore entity class and overrides the get_data method
    """

    def __init__(self):
        """
        Define the Promotions schema and column or columns that uniquely define a Promotion
        """
        super(Promotions, self).__init__()

        self.get_data()

    # pylint: disable=too-few-public-methods
    @property
    def database(self):
        return database
