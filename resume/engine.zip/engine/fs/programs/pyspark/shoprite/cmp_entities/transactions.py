"""
Shoprite Transactions
"""
from dunnhumby.cmp_entities.transactions import Transactions as baseTransactions
from shoprite import database



class Transactions(baseTransactions):
    """
    Inherits the Base CMP Transactions entity class and overrides the get_data method
    """

    def __init__(self):
        """
        Define the Transactions schema and column or columns that uniquely define a Transaction
        """
        super(Transactions, self).__init__()

        self.get_data()
        self.get_most_recent_transaction_date()

    @property
    def database(self):
        return database