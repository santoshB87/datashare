"""
Shoprite CMP Features
"""
import logging

logger = logging.getLogger(__name__)
