"""
Shoprite Purchasing Feature Coordinator module
"""


import datetime
import logging

import dunnhumby.cmp_entities.channels as channels_base
import dunnhumby.cmp_entities.customers as customers_base
import dunnhumby.cmp_entities.dates as dates_base
import dunnhumby.cmp_entities.products as products_base
import dunnhumby.cmp_entities.stores as stores_base
import dunnhumby.cmp_entities.transactions as transactions_base
import dunnhumby.cmp_features.purchasingfeaturecoordinator as base
import shoprite.cmp_entities.channels as channels
import shoprite.cmp_entities.customers as customers
import shoprite.cmp_entities.dates as dates
import shoprite.cmp_entities.products as products
import shoprite.cmp_entities.stores as stores
import shoprite.cmp_entities.transactions as transactions

logger = logging.getLogger(__name__)


class PurchasingFeatureCoordinator(base.PurchasingFeatureCoordinator):
    """
    Purchasing feature coordinator Class for Shoprite
    """

    # pylint: disable=too-many-instance-attributes
    # Thirteen is reasonable in this case.

    def __init__(self, config, cadence_attribute, run_date=datetime.date.today()):
        super(PurchasingFeatureCoordinator, self).__init__(config, cadence_attribute, run_date)

        self.Dates = dates.Dates(self.config)
        self.Product = products.Products(self.config)
        self.Channel = channels.Channels(self.config)
        self.Store = stores.Stores(self.config)
        self.Customer = customers.Customers(self.config)

        self.features_specifications = [
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "BasketWeeks_1w13w", "AveragePurchaseCycle_1w13w",
                    "BasketWeeks_1w26w", "Baskets_1w26w", "AveragePurchaseCycle_1w26w",
                    "RecencyDays_1w26w",
                    "BasketWeeks_1w52w", "Baskets_1w52w", "AveragePurchaseCycle_1w52w",
                    "NetSpend_1w52w",
                    "RecencyDays_1w52w", "QuantityPerBasket_1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All",
                    "ProductAttribute": "Product",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "BasketsFlag_1w1w", "Quantity_1w1w", "MinimumNetPrice_1w1w",
                    "AverageNetPrice_1w1w", "Baskets_1w52w", "Baskets_1w4w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Product",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "BasketWeeks_1w1w", "Quantity_1w1w", "NetSpend_1w1w",
                    "BasketWeeks_1w13w", "Quantity_1w13w", "RecencyDays_1w13w", "NetSpend_1w13w",
                    "AveragePurchaseCycle_1w13w",
                    "Baskets_1w26w", "BasketWeeks_1w26w", "Quantity_1w26w", "NetSpend_1w26w",
                    "RecencyDays_1w26w",
                    "AveragePurchaseCycle_1w26w",
                    "Baskets_1w52w", "RecencyDays_1w52w", "RecencyWeightedBasketWeeks75_1w52w",
                    "AveragePurchaseCycle_1w52w", "RecencyWeightedBasketWeeks95_1w52w",
                    "BasketsFlag_50w57w", "BasketsDecay_1w13wvs1w26w", "BasketsDecay_1w13wvs1w52w"
                ]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Subgroup",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": ["AveragePurchaseCycle_1w26w", "Baskets_1w26w"]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer",
                    "ProductAttribute": "Group",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": ["BasketsFlag_1w4w"]
            }
        ]

        self.Transactions = transactions.Transactions(self.config, since_date = self.pull_data_since_date, to_date = self.as_at)

    @property
    def Transactions(self):
        """
        :return: Shoprite Transactions Entity
        """
        return self.__Transactions

    @Transactions.setter
    def Transactions(self, value):
        """
        Shoprite transactions source class that will be used to generate features
        :param value:
        :return:
        """
        if not isinstance(value, transactions_base.Transactions):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.transactions.Transactions'))
        self.__Transactions = value

    @property
    def Dates(self):
        """
        :return: Shoprite Dates Entity
        """
        return self.__Dates

    @Dates.setter
    def Dates(self, value):
        """
        Shoprite dates source class
        :param value:
        :return:
        """
        if not isinstance(value, dates_base.Dates):
            raise TypeError(
                'value must be an implementation of {classname}'.format(
                    classname='dunnhumby.cmp_entities.dates.Dates'))
        self.__Dates = value

    @property
    def Product(self):
        """
        :return: Shoprite Products Entity
        """
        return self.__Product

    @Product.setter
    def Product(self, value):
        """
        Shoprite products source class
        :param value:
        :return:
        """
        if not isinstance(value, products_base.Products):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.products.Products'))
        self.__Product = value

    @property
    def Channel(self):
        """
        :return: Shoprite Channels Entity
        """
        return self.__Channel

    @Channel.setter
    def Channel(self, value):
        """
        Shoprite channels source class
        :param value:
        :return:
        """
        if not isinstance(value, channels_base.Channels):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.channels.Channels'))
        self.__Channel = value

    @property
    def Store(self):
        """
        :return: Shoprite Stores Entity
        """
        return self.__Store

    @Store.setter
    def Store(self, value):
        """
        Shoprite stores source class
        :param value:
        :return:
        """
        if not isinstance(value, stores_base.Stores):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.stores.Stores'))
        self.__Store = value

    @property
    def Customer(self):
        """
        :return: Shoprite Customers Entity
        """
        return self.__Customer

    @Customer.setter
    def Customer(self, value):
        """
        Shoprite customers source class
        :param value:
        :return:
        """
        if not isinstance(value, customers_base.Customers):
            raise TypeError('value must be an implementation of {classname}'.format(
                classname='dunnhumby.cmp_entities.customers.Customers'))
        self.__Customer = value
