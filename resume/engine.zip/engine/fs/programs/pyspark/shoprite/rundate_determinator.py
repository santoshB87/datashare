"""
Shoprite Run date determinator
"""

from datetime import timedelta,date

import dunnhumby.rundate_determinator
import shoprite.cmp_entities.transactions as transactions


class RunDateDeterminator(dunnhumby.rundate_determinator.RunDateDeterminator):
    """
    Sets the run date for Shoprite
    :return: Run date for Shoprite
    """

    def __init__(self, config):
        self.config = config

    @property
    def run_date(self):
        """
        :return: max date_id from the transactions table + one day
        """

        # Sets the run date to the max date_id from the transactions table + one day
        # cadence is defined as the week prior to the run_date week
        # cadence should be the latest week for which have 7 days worth data

        # 1.If the max date_id in the transactions table is not the last day of a fis_week_id,
        # adding a day to it keeps the run_date in the same fis_week_id - and the week prior to it,
        # one with all 7 days of transactions, is set as the cadence

        # 2.If the max date_id in the transactions table is the last day of a fis_week_id, this
        # fis_week_id id has all 7 days data and should be set as the cadence. Adding one day to
        # max date_id puts the run_date in the next week - and the week prior to it, one with all
        # 7 days of transactions, is set as the cadence

        return (transactions.Transactions(self.config, since_date = '1950-01-01', to_date = date.today()).most_recent_transaction_date.first().
                most_recent_transaction_date) + timedelta(days=1)
