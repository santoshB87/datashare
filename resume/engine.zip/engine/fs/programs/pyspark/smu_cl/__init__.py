"""This is CMP module for SMU chile"""
# pylint: disable=relative-import
import logging
database = 'smu_cl_media_mart'

logger = logging.getLogger(__name__)
