"""SMU Chile entities module"""
import logging

database = 'smu_cl_media_mart'

logger = logging.getLogger(__name__)
