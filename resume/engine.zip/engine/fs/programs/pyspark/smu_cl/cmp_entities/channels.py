"""
SMU Chile channels module
"""
from dunnhumby.cmp_entities.channels import Channels as baseChannels
from smu_cl import database

# Data will flow into our solution through python classes that we define.
# Data will be sourced from Media Mart.
# Either way we need an abstraction over those data sources that defines the data as SSE requires
#  it.

class Channels(baseChannels):
    """
    Inherits the Base CMP channels entity class and overrides the get_data method
    """

    def __init__(self):
        """
        Define the Channels schema and column or columns that uniquely define a Channel
        """
        super(Channels, self).__init__()

        self.get_data()


    @property
    def database(self):
        return database
