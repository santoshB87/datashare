"""
SMU Chile Purchases
"""


from dunnhumby.cmp_entities.purchases import Purchases as PurchasesBase
from smu_cl import database



class Purchases(PurchasesBase):
    """
    SMU Chile Purchases
    """

    def __init__(self, config):
        super(Purchases, self).__init__(config=config)
        self.get_data()
