"""
This module is use to transfer audience data from hdfs to nfs.
"""
# !/dhcommon/dhpython/python/bin/python2.7
import json
import logging
import sys
import os
from datetime import datetime

logger = logging.getLogger(__name__)

TOOLS_EGG_PATH = 'programs/pyspark/dunnhumby/cmp_allocation/tools-latest.egg'
ALLOCATION_MODULE_PATH = 'programs/pyspark/dunnhumby/cmp_allocation/allocation'
CONFIG_PATH = 'config.json'


def main(argv):
    # set up basic logger with stream handler
    import output_to_linux as output_to_linux
    import util
    if len(argv) < 3:
        raise RuntimeError(
            "Too few arguments have been supplied. Arguments environment, engine-path, config dictionary required.")
    env = argv[1]
    argv = json.loads(argv[3])
    config = json.load(open(CONFIG_PATH, 'r'))
    environment = config['audience_selection']
    webhdfs_url = util.get_active_namenode_webhdfs_root(
        namenode_list=environment['hdfs_name_nodes'], webhdfs_root=environment['webhdfs_root'],
        logger=logger)
    hdfs_path = argv['hdfs_root_path']
    function_list = argv['functioncall_and_resultpath']
    nfs_servers = environment['nfs_servers']
    nfs_path = environment['output_path']

    for func_list in function_list:
        path = hdfs_path + "/sse/audience_selection/" + func_list[1]
        nfs_full_path = [os.path.join(nfs_path_, func_list[1]) for nfs_path_ in nfs_path]
        output_to_linux.transfer_results_without_filename_change(path, webhdfs_url, nfs_servers,
                                                                 nfs_full_path)


if __name__ == "__main__":
    engine_path = sys.argv[2]
    CONFIG_PATH = os.path.join(engine_path, CONFIG_PATH)
    TOOLS_EGG_PATH = os.path.join(engine_path, TOOLS_EGG_PATH)
    ALLOCATION_MODULE_PATH = os.path.join(engine_path, ALLOCATION_MODULE_PATH)
    sys.path.append(TOOLS_EGG_PATH)
    sys.path.append(ALLOCATION_MODULE_PATH)
    main(sys.argv)
