#!/dhcommon/dhpython/python/bin/python2.7
"""
This module is use to run the audience script and transferring the files into postgres server.
"""
import json
import os
import sys
from dunnhumby import contexts

args_config = json.loads(sys.argv[-1])
hdfs_path = args_config['hdfs_root_path']
print args_config

module_name = args_config['client_name']+'.cmp_audience_selection_integration'
audience_class = __import__(module_name, fromlist=['GenerateCsvForAudienceSelection'])
GenerateCsvForAudienceSelection = getattr(audience_class, "GenerateCsvForAudienceSelection")

cadence_date = args_config['cadence_date']
client_hdfs_path = 'pob/hive/{0}_pob'.format(args_config['hive_database_prefix'])
db_path = os.path.join(hdfs_path, client_hdfs_path)

sc = contexts.sc()
latest_cadence = sc.textFile(hdfs_path+'/sse/latest_cadence.txt').collect()
latest_cadence = str(latest_cadence[0])
if cadence_date != 'latest':
    latest_cadence = cadence_date

audience_dataframe_module = GenerateCsvForAudienceSelection({"SSEHiveDatabasePrefix": args_config['hive_database_prefix'], "cadence_date": latest_cadence})

function_list = args_config['functioncall_and_resultpath']

for func_list in function_list:
    print "Generating data for "+func_list[0]
    path = hdfs_path+"/sse/audience_selection/"+func_list[1]
    data_creation_function = getattr(audience_dataframe_module, func_list[0])
    data_writer_function = getattr(audience_dataframe_module, 'write_csv_to_hdfs')
    data = data_creation_function(path)
    data_writer_function(data, path)