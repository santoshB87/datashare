#!/dhcommon/dhpython/python/bin/python2.7


import sys
import json
import logging
from datetime import datetime as dt
from dunnhumby import contexts


def main(argv):
    if len(argv) < 4:
        raise RuntimeError("Too few arguments have been supplied. "
                           "Arguments client_name, clean_run and run_date are required")
    # set up basic logger with stream handler
    logger = logging.getLogger(__name__)
    sh = logging.StreamHandler()
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%y/%m/%d %H:%M:%S")
    sh.setLevel(logging.DEBUG)
    sh.setFormatter(fmt)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(sh)
    # A string that can be searched for in the log in order to find the pertinent info
    logger.info("Begin SSE logging...")
    # Command line arguments supplied to script
    logger.info("Command-line arguments:")
    for arg in argv:
        logger.info("{arg}".format(arg=arg))
    # Setup required spark conf properties
    sc = contexts.sc()
    sqlContext = contexts.sql_context()
    for conf_option in sorted(sc._conf.getAll()):
        logger.info("{conf_option}={value}".format(conf_option=conf_option[0],
                                                   value=conf_option[1]))
    # Load client config file
    logger.info('Reading client config file')
    with open("config.json", "r") as fptr:
        config = json.load(fptr)
    # First command line args - client_name
    client_name = argv[1].lower()
    logger.info('client_name = {client_name}'.format(client_name=client_name))
    # Second command line args - job_type
    job_type = argv[2].lower()
    logger.info("job_type = {job_type}".format(job_type=job_type))
    # Third command line args - run_date
    run_date = argv[3]
    run_date = dt.strptime(run_date, "%Y-%m-%d").date()
    logger.info("run_date = {run_date}".format(run_date=run_date))
    # Import & initialize client specific class and call the generate_and_write_purchases method
    pgdataloader = __import__("{client_name}.audience_selection.pg_data_loader".format(client_name=client_name),
        globals(), locals(), -1)
    pg_data_loader = pgdataloader.PGDataLoader(config=config, rundate=run_date)
    pg_data_loader.gen_and_load(job_type=job_type)
    contexts.clean_up()


if __name__ == "__main__":
    main(sys.argv)
