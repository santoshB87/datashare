import sys
import json
import logging
from datetime import datetime, timedelta
from pyspark.sql import functions as F
from dunnhumby import contexts
from pyspark.sql.types import StructType, StructField, StringType

logger = logging.getLogger(__name__)


class CadenceWeekCalculator(object):

    __date_format = "%Y-%m-%d"
    __cadence_period = ["current", "in_time_pre", "in_time_post", "out_time_pre", "out_time_post"]
    __df_columns = ["fis_week_id", "fis_week_dates", "period_type"]

    def __init__(self, argv):

        """
        Input arguments must contain below mentioned parameters to run cadence week calculations.
        1. SSEFeaturePacPrePeriod
        2. SSEFeaturePacFallowPeriod
        3. SSEFeaturePacPostPeriod
        4. SSEFeaturePacPostPeriodNum
        5. SSEHiveWarehouseDB
        6. SSECadenceWeekPath
        :param argv:
        """
        logger.info("Input arguments: {argv}".format(argv=str(argv)))
        if len(argv) < 6:
            logger.error("Expected keys in input dictionary are: 'SSEFeaturePacPrePeriod', "
                         "'SSEFeaturePacFallowPeriod', 'SSEFeaturePacPostPeriod', 'SSEFeaturePacPostPeriodNum', "
                         "'SSEHiveWarehouseDB', 'SSECadenceWeekPath'")
            raise Exception("Too few keys have been supplied. Check logs for required params.")
        self.sql_context = contexts.sql_context()
        self.pre_period = timedelta(weeks=int(argv.get("SSEFeaturePacPrePeriod")))
        self.fallow_period = timedelta(weeks=int(argv.get("SSEFeaturePacFallowPeriod")))
        self.post_period = timedelta(weeks=int(argv.get("SSEFeaturePacPostPeriod")))
        self.post_period_num = int(argv.get("SSEFeaturePacPostPeriodNum"))
        self.warehouse_db = argv.get("SSEHiveWarehouseDB")
        self.cadence_hdfs_path = argv.get("SSECadenceWeekPath")
        self.current_date = datetime.now()

    def run(self):
        logger.info("Starting cadence weeks calculation...")
        cadence_week_df = self._get_fis_week_dates()
        logger.info("Writing csv file for cadence week dates...")
        if self.current_period < max(self.out_time_post_period):
            raise Exception("Suggested time periods exceeds the current cadence week. "
                            "Please reconsider the input parameters and try again.")
        cadence_week_df.repartition(1).write.format('com.databricks.spark.csv'). \
            mode('overwrite').option("header", "true"). \
            save(self.cadence_hdfs_path)
        logger.info("Process completed.")

    def _get_fis_week_dates(self):
        required_schema = StructType()
        for column in self.__df_columns:
            required_schema.add(StructField(column, StringType(), False))
        df = self.sql_context.createDataFrame([], required_schema).select(*self.__df_columns)
        logger.info("Empty dataframe created.")

        for period in self.__cadence_period:
            getattr(self, '_get_{period_type}_period'.format(period_type=period))()
            df = df.unionAll(self._get_fis_week_id(getattr(self, '{period_type}_period'.format(period_type=period)), period))

        return df \
            .withColumn("feature_run_dates", F.date_add("fis_week_dates", 1).astype(StringType())) \
            .groupBy("period_type") \
            .agg(F.collect_set("fis_week_id").alias("fis_week_id"),
                 F.collect_set("feature_run_dates").alias("feature_run_dates")) \
            .withColumn("fis_week_id", F.concat_ws(",", "fis_week_id")) \
            .withColumn("feature_run_dates", F.concat_ws(",", "feature_run_dates"))

    def _get_current_period(self):
        """
        Get current cadence week last day.
        :return:
        """
        self.current_period = self.current_date - timedelta(self.current_date.weekday() + 1)
        logger.info("Current cadence week last date: {current_period}".format(current_period=self.current_period))

    def _get_in_time_pre_period(self):
        """
        Get in time pre period cadence week last day. Dependent on '_get_current_period' method.
        :return:
        """
        self.in_time_pre_period = [self.current_period - self.pre_period]
        logger.info("In time pre period last date: {in_time_pre}".format(in_time_pre=self.in_time_pre_period))

    def _get_in_time_post_period(self):
        """
        Get in time post period cadence week last day. Dependent on '_get_in_time_pre_period' method.
        :return:
        """
        self.in_time_post_period = self._calc_post_period_dates(self.in_time_pre_period[-1])
        logger.info("In time post period last date: {in_time_post}".format(in_time_post=self.in_time_post_period))

    def _get_out_time_pre_period(self):
        """
        Get out of time pre period cadence week last day. Dependent on '_get_in_time_post_period' method.
        :return:
        """
        self.out_time_pre_period = [self.in_time_post_period[-1] + self.post_period + timedelta(weeks=1)]
        logger.info("Out of time pre period last date: {out_of_time_pre}".format(out_of_time_pre=self.out_time_pre_period))

    def _get_out_time_post_period(self):
        """
        Get out of time post period cadence week last day. Dependent on '_get_out_time_pre_period' method.
        :return:
        """
        self.out_time_post_period = self._calc_post_period_dates(self.out_time_pre_period[0])
        logger.info("Out of time post period last date: {out_of_time_post}".format(out_of_time_post=self.out_time_post_period))

    def _calc_post_period_dates(self, pre_period_date):
        """
        Get a list of post period dates for number of required periods from a reference pre period date.
        :param pre_period_date: Datetime Object
        :return:
        """
        post_period_dates = list()
        fallow_period_date = pre_period_date + self.fallow_period
        for num in range(self.post_period_num):
            fallow_period_date = fallow_period_date + timedelta(weeks=1)
            post_period_dates.append(fallow_period_date)
        return post_period_dates

    def _convert_date_to_str(self, date):
        """
        Convert date time object to class specific date format.
        :param date:
        :return:
        """
        return date.strftime(self.__date_format)

    def _get_fis_week_id(self, dates, period_type):
        """
        Get 'fis_week_id' for each datetime object in the given list.
        :param dates: List of datetime objects
        :param period_type
        :return:
        """
        if not isinstance(dates, list):
            dates = [dates]

        dates = "','".join(map(self._convert_date_to_str, dates))
        query = "SELECT fis_week_id, date_short_name AS fis_week_dates FROM {warehouse_db}.dates " \
                "WHERE date_short_name IN ('{dates}')".format(warehouse_db=self.warehouse_db, dates=dates)
        try:
            date_dim_rec = self.sql_context.sql(query)
            return date_dim_rec.withColumn("period_type", F.lit(period_type)).select(*self.__df_columns)
        except Exception as ex:
            message = "Query execution failed. Query statement: {query}".format(query=query)
            logger.error(message)
            logger.error(ex.message)
            raise Exception(message)


if __name__ == "__main__":
    cadence_week_calc = CadenceWeekCalculator(argv=json.loads(sys.argv[-1]))
    cadence_week_calc.run()
