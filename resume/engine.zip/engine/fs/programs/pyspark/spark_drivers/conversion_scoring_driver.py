import json
import logging
import sys

from dunnhumby.cmp_science.prepare_jobs import StandardConversionPrepare
from dunnhumby.cmp_science.utilities import read_pmml_root
from pyspark import SparkConf

__author__ = 'rudraps and milan'

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
sh = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y-%m-%d %H:%M:%S')
sh.setLevel(logging.DEBUG)
sh.setFormatter(fmt)
logger.setLevel(logging.DEBUG)
logger.addHandler(sh)

conf = SparkConf().setAppName('standard_conversion_scoring_data_prepare_driver')
conf.set("spark.sql.parquet.binaryAsString", "true")
args_config = json.loads(sys.argv[-1])
config = json.load(open('config.json', 'r'))

logger.info('Begin Standard-Conversion-Scoring data preparation job')
config = dict((key, value) for (key, value) in config.items() if
              key in [
                  'SSEHiveDatabasePrefix',
                  'Market'
              ]
              )

args_from_cmd = ['client_name', 'proposition', 'model', 'source_schema', 'features_CustomerAll_dataset',
                 'features_ProductAll_dataset', 'features_CustomerProduct_dataset',
                 'features_prod_heirarchy_dataset', 'destination_schema']

for each in args_from_cmd:
    config.__setitem__(each, args_config[each])

grain_from_view_names = {'CustomerAll_grain': config['features_CustomerAll_dataset'],
                         'ProductAll_grain': config['features_ProductAll_dataset'],
                         'CustomerProduct_grain': config['features_CustomerProduct_dataset'],
                         'CustomerProductHeirarchy_grain': config['features_prod_heirarchy_dataset']}

for (k, v) in grain_from_view_names.items():
    config.__setitem__(k, v.replace('v_cadenceattributefis_week_id_', '').replace('_current', ''))

# Now need to read the PMML file associated with this Scoring Process so that we pick up the required
# column names in the order they are in the PMML and hence, prepare the standard_scoring_features_[proposition]_conv
# table with the columns in the above described order.
pmml_file = '{proposition}.{model}.pmml'.format(proposition=config['proposition'], model=config['model'])
pmml_root = read_pmml_root(pmml_file)
std_conv_prep_obj = StandardConversionPrepare(config)

try:
    logger.info('PMML Model: %s' % pmml_file)
    std_conv_prep_obj.prepare_data_for_scoring(logger, pmml_root)
    logger.info('Conversion-Scoring data preparation job :Success')
except Exception as e:
    logger.error('Conversion-Scoring data preparation job :Failed')
    raise Exception(e)
