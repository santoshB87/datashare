import os.path as op
import sys
from datetime import datetime as dt
from inspect import getargspec

import numpy as np
import pandas as pd

# Define the constants to be used throughout the code
CUSTOMER_CODE = 'CustomerId'
CUSTOMER_ID = 'HashedCreditCard'
APP_ID_FIRST = 'UId'
APP_ID_SECOND = 'UId2'


class Operation(object):
    """
    This class defines almost all the common operations performed throughout the code.
    The important thing to notice here is that these operations (except `add_cols`)
    are composite in nature i.e. each of them is a series of transformations being
    applied to the dataframes rather than one single operation (e.g. select). Also,
    the first parameter in each method is `df` which won't be needed to be supplied
    as these transformations will be applied to the DataFrames via `transform` method
    defined in the `DFContainer` class we define next.
    """

    @staticmethod
    def get_unique_dataframe(df, sort_params={}, drop_dup_subset=[], select_cols=[]):
        """
        Get rid of all the duplicates in the DataFrame based on the certain criteria.
        :param df: DataFramed to be transformed
        :param sort_params: columns and their orders to sort `df` by
        :param drop_dup_subset: columns to drop duplicates by
        :param select_cols: Optional. Required columns in the deduped DataFrame
        :return: Deduped DataFrame
        """
        if not drop_dup_subset == [-1]:
            op_df = df.sort_values(**sort_params).drop_duplicates(subset=drop_dup_subset)
        else:
            op_df = df.sort_values(**sort_params).drop_duplicates()
        final_df = op_df[select_cols] if select_cols else op_df
        del op_df
        return final_df

    @staticmethod
    def add_cols(df, col_names, data):
        """
        Add multiple columns to a DataFrame. `col_names` and `data` must be
        supplied in an agreed order to maintain correct references to the column data.
        :param df: DataFrame to add columns to
        :param col_names: names of the newly added columns
        :param data: data required in the new columns, as numpy array
        :return: DataFrame with added columns
        """
        inp_df = df
        df_data = dict(zip(col_names, data))
        final_df = inp_df.join(pd.DataFrame(df_data, index=inp_df.index))
        del inp_df, df_data
        return final_df

    @staticmethod
    def rename_and_select_cols(df, rename_cols={}, select_cols=[]):
        """
        Rename the columns and return a subset of the resulting DataFrame
        :param df: DataFrame to apply transformation to
        :param rename_cols: mapping of old and new column names
        :param select_cols: columns required in the final DataFrame
        :return: DataFrame with the renamed columns.
        """
        inp_df = df
        renamed_df = inp_df.rename(index=str, columns=rename_cols)[select_cols]
        del inp_df
        return renamed_df

    @staticmethod
    def merge_dataframes(df, another_df, merge_params={}, rename_cols={}, sort_params={}, select_cols=[]):
        """
        Merge two DataFrames, rename some columns if required, sort the result if required
        and finally return a DataFrame with the required columns.
        :param df: DataFrame on the left side of join
        :param another_df: DataFrame on the right side of join
        :param merge_params: merging settings such as `on`, `how` etc.
        :param rename_cols: Optional. mapping of old and new column names
        :param sort_params: Optional. columns and their orders to sort the merged DataFrame by
        :param select_cols: columns required in the final DataFrame
        :return: result of merge of two DataFrames.
        """
        merged_df = pd.merge(df, another_df, **merge_params)
        col_renamed_df = merged_df.rename(index=str, columns=rename_cols) if rename_cols \
            else merged_df
        del merged_df
        if sort_params:
            sorted_df = col_renamed_df.sort_values(**sort_params)
            del col_renamed_df
            return sorted_df[select_cols] if select_cols else sorted_df
        return col_renamed_df[select_cols] if select_cols else col_renamed_df


class DFContainer(object):
    """
    Container class to hold a DataFrame and apply the required transformation
    to the DataFrame contained.
    """

    def __init__(self, df):
        """
        :param df: DataFrame to be contained
        """
        self.df = df

    def free_up(self):
        """
        Routine to free up the memory occupied by the members of DFContainer objects.

        :param list_of_objects: list of DFContainer objects to be run clean up on.
        :return: None
        """
        del self.df

    def transform(self, operation, parameters={}):
        """
        Apply the given transformation to the DataFrame contained within this
        instance.
        :param operation: a transformation from `Operation` class defined above
        :param parameters: parameters required by the given transformation
        :return: DFContainer instance containing the output DataFrame
        """
        all_args = filter(lambda arg_key: not (arg_key == 'df'), getargspec(operation).args)
        final_args = {key: value for (key, value) in parameters.iteritems() if key in all_args}
        df = operation(self.df, **final_args)
        return DFContainer(df)


def clean_up(list_of_objects):
    """
    Routine to free up the memory occupied by the members of DFContainer objects.

    :param list_of_objects: list of DFContainer objects to be run clean up on.
    :return: None
    """
    for each in list_of_objects:
        each.free_up()


def iteratively_transform_df(inp_lookup_df, connected_cards_phones):
    """
    Iteratively apply several transformations to the DataFrame.
    :param lookup_df: DataFrame containing initially assigned IDs
    :param connected_cards_phones: Self joined DataFrame having all the phone numbers
                                    corresponding to an ID
    :return: transformed DataFrame
    """
    lookup_df = inp_lookup_df
    print 'In iteratively_transform_df()', dt.now()
    final_df = pd.DataFrame()
    ord = 0
    while not all((lookup_df.df == final_df.reindex_like(lookup_df.df)).values.flatten()):
        print ord
        if ord:
            lookup_df = DFContainer(final_df)
        ord = ord + 1
        sorted_lookup_df = DFContainer(lookup_df.df.sort_values(by=[APP_ID_FIRST], ascending=[True]))
        first_id_df = connected_cards_phones.transform(Operation.merge_dataframes,
                                                       dict(
                                                           another_df=sorted_lookup_df.df,
                                                           merge_params=dict(on=APP_ID_FIRST, how='left'),
                                                           sort_params=dict(by=[APP_ID_SECOND], ascending=[True]),
                                                           select_cols=[APP_ID_FIRST, APP_ID_SECOND, 'id_first']
                                                       )
                                                       )
        second_id_df = sorted_lookup_df.transform(Operation.rename_and_select_cols,
                                                  dict(
                                                      rename_cols={APP_ID_FIRST: APP_ID_SECOND},
                                                      select_cols=[APP_ID_SECOND, 'id_second']
                                                  )
                                                  )
        id_df = first_id_df.transform(Operation.merge_dataframes,
                                      dict(
                                          another_df=second_id_df.df,
                                          merge_params=dict(on=APP_ID_SECOND, how='left')
                                      )
                                      )
        min_ids = id_df.df.loc[:, ['id_first', 'id_second']].min(axis=1).values
        min_ids_df = id_df.transform(Operation.add_cols,
                                     dict(
                                         col_names=['min_first', 'min_second'],
                                         data=[min_ids, min_ids]
                                     )
                                     )
        min_ids_df_subset = DFContainer(min_ids_df.df[[APP_ID_FIRST, APP_ID_SECOND, 'min_first', 'min_second']])
        min_ids_subset = min_ids_df_subset.transform(Operation.rename_and_select_cols,
                                                     dict(
                                                         rename_cols=dict(min_first='id_first', min_second='id_second'),
                                                         select_cols=[APP_ID_FIRST, 'id_first', 'id_second']
                                                     )
                                                     )
        unique_min_ids_subset = min_ids_subset.transform(Operation.get_unique_dataframe,
                                                         dict(
                                                             sort_params=dict(
                                                                 by=[APP_ID_FIRST, 'id_first', 'id_second'],
                                                                 ascending=[True, True, True]
                                                                 ),
                                                             drop_dup_subset=[APP_ID_FIRST, 'id_first', 'id_second']
                                                         )
                                                         )
        final_df = unique_min_ids_subset.df.drop_duplicates(subset=APP_ID_FIRST, keep='first')
        # lookup_df = DFContainer(final_df)
        to_clean_up = [sorted_lookup_df, id_df, first_id_df, min_ids_df, min_ids_df_subset, min_ids_subset,
                       unique_min_ids_subset]
        clean_up(to_clean_up)

    return lookup_df


def create_new_app_ids(source_df):
    """
    Create the DataFrame with the unique ID assigned to each customer by applying
    a series of transformations to the source DataFrame.
    :param source_df: source DataFrame to Derive customer lookup from
    :return: DataFrame with the unique ID
    """
    print 'In create_new_app_ids()', dt.now()
    source_data = DFContainer(source_df)
    initial_data_subset = source_data.transform(Operation.get_unique_dataframe,
                                                dict(
                                                    sort_params=dict(by=[CUSTOMER_ID, APP_ID_FIRST],
                                                                     ascending=[True, True]),
                                                    drop_dup_subset=[CUSTOMER_ID, APP_ID_FIRST],
                                                    select_cols=[APP_ID_FIRST, CUSTOMER_ID]
                                                )
                                                )
    first_lookup_tmp = initial_data_subset.transform(Operation.get_unique_dataframe,
                                                     dict(
                                                         sort_params=dict(by=[APP_ID_FIRST], ascending=[True]),
                                                         drop_dup_subset=[APP_ID_FIRST],
                                                         select_cols=[APP_ID_FIRST]
                                                     )
                                                     )
    new_cols_data = np.array(range(1, len(first_lookup_tmp.df) + 1))
    first_lookup = first_lookup_tmp.transform(Operation.add_cols,
                                              dict(
                                                  col_names=['id_first', 'id_second'],
                                                  data=[new_cols_data, new_cols_data]
                                              )
                                              )
    connected_cards_phones = initial_data_subset.transform(Operation.merge_dataframes,
                                                           dict(
                                                               another_df=initial_data_subset.df,
                                                               merge_params=dict(on=CUSTOMER_ID, how='inner'),
                                                               rename_cols={APP_ID_FIRST + "_x": APP_ID_FIRST,
                                                                            APP_ID_FIRST + "_y": APP_ID_SECOND},
                                                               sort_params=dict(by=[APP_ID_FIRST, CUSTOMER_ID],
                                                                                ascending=[True, True]),
                                                               select_cols=[APP_ID_FIRST, APP_ID_SECOND]
                                                           )
                                                           )
    unique_ids_df = iteratively_transform_df(first_lookup, connected_cards_phones)
    sorted_unique_ids_df = DFContainer(unique_ids_df.df.sort_values(by=[APP_ID_FIRST], ascending=[True]))
    another_df_from_source = DFContainer(source_df[[CUSTOMER_CODE, APP_ID_FIRST, CUSTOMER_ID]])
    another_unique_df = another_df_from_source.transform(Operation.get_unique_dataframe,
                                                         dict(
                                                             sort_params=dict(by=[CUSTOMER_ID, APP_ID_FIRST],
                                                                              ascending=[True, True]),
                                                             drop_dup_subset=[-1],
                                                             select_cols=[CUSTOMER_CODE, APP_ID_FIRST, CUSTOMER_ID]
                                                         )
                                                         )
    final_new_ids_df = another_unique_df.transform(Operation.merge_dataframes,
                                                   dict(
                                                       another_df=sorted_unique_ids_df.df,
                                                       merge_params=dict(on=APP_ID_FIRST, how='left'),
                                                       sort_params=dict(by=[APP_ID_FIRST], ascending=[True]),
                                                       select_cols=[APP_ID_FIRST, CUSTOMER_ID, CUSTOMER_CODE,
                                                                    'id_first']
                                                   )
                                                   )
    to_clean_up = [source_data, initial_data_subset, first_lookup_tmp, first_lookup, \
                   connected_cards_phones, unique_ids_df, sorted_unique_ids_df, another_df_from_source,
                   another_unique_df]
    clean_up(to_clean_up)
    return final_new_ids_df.df


def persist_prev_new_ids(new_ids_df, prev_new_ids_df):
    df = Operation.merge_dataframes(prev_new_ids_df,
                                    new_ids_df,
                                    merge_params=dict(on=[APP_ID_FIRST, CUSTOMER_ID], how='right'),
                                    rename_cols={APP_ID_FIRST + "_y": APP_ID_FIRST,
                                                 CUSTOMER_ID + "_y": CUSTOMER_ID,
                                                 CUSTOMER_CODE + "_y": CUSTOMER_CODE},
                                    sort_params=dict(by=['id_first_y', 'id_first_x'], ascending=[True, True]),
                                    select_cols=[APP_ID_FIRST, CUSTOMER_ID, CUSTOMER_CODE, 'id_first_x', 'id_first_y']
                                    )
    rep_cust_instances_df = df[df.id_first_x.notnull()]
    rep_cust_instances_df['final_id'] = rep_cust_instances_df.id_first_x
    new_to_prev_idmap = dict(zip(rep_cust_instances_df.id_first_y.values,
                                 rep_cust_instances_df.id_first_x.values))
    new_cust_instances_df = df[df.id_first_x.isnull()]
    new_cust_instances_df['final_id'] = new_cust_instances_df['id_first_y'] \
        .apply(lambda x: new_to_prev_idmap[x] if x in new_to_prev_idmap else 0)
    newcust_instances_previds_df = new_cust_instances_df[new_cust_instances_df.final_id != 0]
    partially_final_df = pd.concat([rep_cust_instances_df, newcust_instances_previds_df])
    new_cust_df = new_cust_instances_df[new_cust_instances_df.final_id == 0]
    prev_to_new_idmap = dict(zip(partially_final_df.final_id.values,
                                 partially_final_df.id_first_y.values))
    new_cust_df['final_id'] = new_cust_df['id_first_y'].apply(
        lambda x: prev_to_new_idmap[x] if x in prev_to_new_idmap else x)
    final_df = pd.concat([partially_final_df, new_cust_df])
    return Operation.rename_and_select_cols(final_df, rename_cols={'final_id': 'id_first'},
                                            select_cols=[APP_ID_FIRST, CUSTOMER_ID, CUSTOMER_CODE, 'id_first'])


def run_job(inp_path, out_path, last_file_path):
    """
    Read the CSV file as a pandas DataFrame, create a DataFrame with
    the unique customer IDs.
    :param inp_path: full qualified path to the input file from Shoprite
    :param out_path: path to store the output at
    :return: out_path
    """
    source_df = pd.read_csv(inp_path)
    print 'Read I/P as DataFrame...', dt.now()
    new_ids_df = create_new_app_ids(source_df)
    if op.isfile(last_file_path):
        prev_new_ids_df = pd.read_csv(last_file_path)
        prev_new_ids_df.columns = new_ids_df.columns
        final_df = persist_prev_new_ids(new_ids_df, prev_new_ids_df)
        final_df.to_csv(out_path, index=False, header=False)
    else:
        new_ids_df.to_csv(out_path, index=False, header=False)
    return out_path


if __name__ == '__main__':
    # Entry point of the code.
    print 'In the __main__', dt.now()
    inp_file_path, out_file_path, last_file_path = sys.argv[1: 4]
    sys.stdout.write(run_job(inp_file_path, out_file_path, last_file_path))
    sys.stdout.flush()
