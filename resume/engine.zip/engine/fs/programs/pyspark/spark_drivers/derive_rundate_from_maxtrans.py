from json import load
from pyhive.hive import connect
import datetime
import logging
import sys, os


# Get the run_date from max_trans_date_dim
# outdate is returned from this function so that it makes it to Xcom
def get_run_date():
    # Get the required parameters from config.json which resides at the engine_path
    CONFIG_PATH = "{}/config.json".format(sys.argv[1])
    with open(CONFIG_PATH, 'r') as fh:
        config_dict = load(fh)
        sse_request_pool = config_dict.get('SSERequestPool')
        config_dict = config_dict.get("SqoopOracleTableAndColumnMetadata2").get("sqoop").get("hadoop").get("jdbc")

    offset_num_days = 0
    hive_host = config_dict.get("host")
    hive_port = int(config_dict.get("port"))
    database = config_dict.get("database")

    # Run the python script as would from Cronacle, to get the maximum run_date
    cursor = connect(host=hive_host,
                     port=hive_port,
                     database=database,
                     configuration={'mapreduce.job.queuename': sse_request_pool}).cursor()

    cursor.execute("""
                   create table if not exists max_trans_date_dim(DATE_ID   string )
                     stored as parquet
                   """)

    cursor.execute("""select
                     DATE_SUB(date_id, {}) as date_id
                   from
                      max_trans_date_dim
                   """.format(offset_num_days, ))

    dates = None
    try:
        dates = cursor.fetchone()
    except Exception as e:
        logging.info("No data in max_trans_date_dim")

    outdate = str(dates[0])[:10]
    logging.info("INFO: Run date will be set to " + outdate + ", the latest transaction date available from the WH")
    cursor.close()
    return outdate


if __name__ == "__main__":
    sys.stdout.write(get_run_date())
    sys.stdout.flush()