import sys

import pandas as pd


def get_reqd_colnames(desired_cols, actual_cols):
    searchable_cols = map(lambda _: _.lower(), actual_cols)
    reqd_cols = list()
    for each in desired_cols:
        try:
            reqd_cols.append(actual_cols[searchable_cols.index(each.lower())])
        except Exception as e:
            pass
    return reqd_cols


def check_order_and_names(desired_cols, actual_cols):
    col_subset = actual_cols[: len(actual_cols)]
    out_of_order = list()
    for (left, right) in zip(desired_cols, col_subset):
        if left.lower() != right.lower():
            out_of_order.append(left)
    reqd_cols = get_reqd_colnames(desired_cols, actual_cols)
    changed_names = list(set(desired_cols) - set(reqd_cols))
    return out_of_order, changed_names


def parse_args_for_colnames(argv, index=2):
    req_arg = argv[index]
    return req_arg.replace("'", "").strip('[').strip(']').split(', ')


def job():
    desired_cols = parse_args_for_colnames(sys.argv)
    filepath = sys.argv[1]
    df = pd.read_csv(filepath)
    actual_cols = list(df.columns)
    reqd_cols = get_reqd_colnames(desired_cols, actual_cols)
    print 'Desired Columns:', desired_cols
    print 'Actual Columns:', actual_cols
    print 'Required Columns:', reqd_cols
    if len(desired_cols) != len(reqd_cols):
        missing_cols = list(set(actual_cols) - set(reqd_cols))
        raise TypeError("MISSING: {}. EXITING...".format(str(missing_cols)))
    df[reqd_cols].to_csv(filepath, header=False, index=False)
    order, names = check_order_and_names(desired_cols, actual_cols)
    if names and not order:
        return 'COLUMN NAMES WERE CHANGED FOR: {}'.format(names)
    elif not names and order:
        return 'COLUMN ORDERS WERE CHANGED FOR: {}'.format(order)
    elif names and order:
        return 'BOTH COLUMNS NAMES AND ORDERS WERE CHANGED. DESIRED: {0}, RECEIVED: {1}'.format(desired_cols,
                                                                                                actual_cols)
    else:
        return 'SUCCESS'


if __name__ == '__main__':
    sys.stdout.write(job())
    sys.stdout.flush()
