import os
import sys
from datetime import datetime

import simplejson as json
from impala.dbapi import connect

if __name__ == "__main__":
    engine_path = sys.argv[1]
    extract_name = sys.argv[2]

    # get the extract properties from the config file
    with open(os.path.join(engine_path, "config.json"), 'r') as file:
        options_dict      = json.load(file)
        hadoop_host       = options_dict['HiveServerNodeName']
        hive_port         = options_dict['HivePortNumber']
        request_pool      = options_dict['SSERequestPool']
        query             = options_dict['CSVExtracts'][extract_name]['query']
        local_path        = options_dict['CSVExtracts'][extract_name]['local_path']
        file_name         = options_dict['CSVExtracts'][extract_name]['file_name']
        add_timestamp     = options_dict['CSVExtracts'][extract_name]['add_timestamp']
        file_suffix       = options_dict['CSVExtracts'][extract_name]['file_suffix']
        write_header_row  = options_dict['CSVExtracts'][extract_name]['write_header_row']
        file_delimiter    = options_dict['CSVExtracts'][extract_name]['file_delimiter']
        remote_host       = options_dict['CSVExtracts'][extract_name]['remote_host']
        remote_path       = options_dict['CSVExtracts'][extract_name]['remote_path']
        remote_buffer     = options_dict['CSVExtracts'][extract_name]['remote_buffer']
        delete_local_file = options_dict['CSVExtracts'][extract_name]['delete_local_file']

    print("Hadoop Cluster = ")
    print("  hadoop_host:        " + hadoop_host)
    print("  hive_port:          " + hive_port)
    print("  request_pool:       " + request_pool + "\n")

    print("CSV Extract =")
    print("  query:              " + query)
    print("  local_path:         " + local_path)
    print("  file_name:          " + file_name)
    print("  add_timestamp:      " + add_timestamp)
    print("  file_suffix:        " + file_suffix)
    print("  write_header_row:   " + write_header_row)
    print("  file_delimiter:     " + file_delimiter)
    print("  remote_host:        " + remote_host)
    print("  remote_path:        " + remote_path)
    print("  remote_buffer:      " + remote_buffer)
    print("  delete_local_file:  " + delete_local_file + "\n")

    # generate local file name
    if add_timestamp == "y":
        timestamp = "_" + datetime.now().strftime("%Y%m%d%H%M%S")
    else:
        timestamp = ""
    if file_suffix and file_suffix[0] != ".":
        file_suffix = "." + file_suffix
    file_name = file_name + timestamp + file_suffix
    if not os.path.exists(local_path):
        raise RuntimeError("local path does not exist", local_path)
    local_file = os.path.join(local_path, file_name)
    print("creating local file: " + local_file)

    # run query though impyla and stream result set to file
    with connect(host=hadoop_host, port=hive_port, timeout=600, auth_mechanism = 'GSSAPI', user='hive', password='', database='default', kerberos_service_name='hive').cursor() as c:
        c.execute("set mapred.job.queue.name = {request_pool}".format(request_pool=request_pool))
        c.execute(query)
        with open(local_file, "w") as f:
            if write_header_row == "y":
                f.write(file_delimiter.join([str(i[0]) for i in c.description]) + "\n")
            for r in c:
                f.write(file_delimiter.join(map(str, r)) + "\n")

    os.system("chmod 777 %s"%local_file)

    # scp file to remote host
    scp_path = os.path.join(remote_path, remote_buffer, file_name)
    print("SCPing file to: %s:%s" % (remote_host, scp_path))
    os.system("scp -p '%s' '%s:%s'" % (local_file, remote_host, scp_path))

    # if buffer was specified move file from buffer to final destination
    if remote_buffer:
        print("moving file to : %s:%s" % (remote_host, remote_path))
        os.system("ssh %s mv '%s' '%s'" % (remote_host, scp_path, remote_path))

    if delete_local_file == "y":
        print("deleting local file: " + local_file)
        os.remove(local_file)
