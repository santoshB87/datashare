#!/dhcommon/dhpython/python/bin/python2.7
import json
import logging
import sys
import datetime
import tools.configs as cfg
from dunnhumby.cmp_allocation.allocation import util as util
from dunnhumby.cmp_allocation.allocation.spark_submit import SparkApplicationError, SparkSubmitError
from dunnhumby.cmp_allocation.spark_drivers.update_event_id import update_event
from dunnhumby.cmp_allocation.spark_drivers.run_allocation import allocate_variations
from dunnhumby.cmp_allocation.spark_drivers.update_control import update_control as update_control
from dunnhumby.cmp_allocation.spark_drivers.send_control_files import generate_send_files
# from dunnhumby.cmp_allocation.spark_drivers.format_results import format_results  ## These imports will be required while merging gcp and bda codes later in the roadmap
# from dunnhumby.cmp_allocation.spark_drivers.format_results_unica import format_results_unica
import ast



def main(alg, metadata_only):
    '''
    # Load config file into Conf object
    :param alg:
    :param metadata_only:
    :return:
    '''

    conf = cfg.Config(logger=logger)
    conf.add_source_file(path="config.json")

    # Client config
    client_name = conf.get_item(keys='client_name', mandatory=True)
    client_short_name = conf.get_item(keys='ClientShortName', mandatory=True)

    # HDFS details
    hdfs_output_path = conf.get_item(keys=(alg, 'hdfs_output_path'), mandatory=True)

    # timezone of timestamps for output files
    timezone = conf.get_item(keys=(alg, 'timezone'), mandatory=True)

    # event, variations and tranche configuration/metadata
    event_id = conf.get_item(keys=(alg, 'event', 'event_id'), mandatory=True)
    increment_event_ids = conf.get_item(keys=(alg, 'increment_event_ids'), mandatory=False, default=False)
    derive_event_dates = conf.get_item(keys=(alg, 'derive_event_dates'), mandatory=False, default=False)
    event_id_hdfs_path = conf.get_item(keys=(alg, 'event_id_hdfs_path'), mandatory=False, default=None)
    event_id_after_increment = None

    event = conf.get_item(keys=(alg, 'event'), mandatory=True)
    variation = conf.get_item(keys=(alg, 'variation'), mandatory=True)

    # final output configuration - whether we take controls and what files are sent where
    control_rules = conf.get_item(keys=(alg, 'control_rules'), mandatory=False, default=None)
    # linux_outputs = conf.get_item(keys=(alg, 'linux_outputs'), mandatory=False, default=dict())
    # send_to_unica_exadata = conf.get_item(keys=(alg, 'send_to_unica'), mandatory=False, default=dict())

    conf.error_on_mandatory_exceptions()

    # date time stamp in YYYYMMDDhhmmss format used to label all files generated during this allocation run
    allocation_start_dttm_datetime = util.get_time_zoned_dttm(timezone)
    allocation_start_dttm = allocation_start_dttm_datetime.strftime('%Y%m%d%H%M%S')

    # NameNodes may be in HA (active/standby) configuration - poke them until we find an active one and return the URL
    # webhdfs_url = "http://gbwatbd1r01s01.dunnhumby.co.uk:50070/webhdfs/v1"
    # capture event_id hard coded in config - if we're incrementing the event IDs then the ID hard coded in config
    # is only used to label the directory we keep the event's control and target population files - incrementing this
    # ID will cause control and target populations to be regenerated during allocation
    control_event_id = event_id
    if increment_event_ids:

        # increment event_id and start and end dates, return as tuple and update lookup file on hdfs
        updated_event_id, event_start_date, event_end_date = update_event(
            algorithm=alg,
            config_file=conf.file_name,
            derive_event_dates=derive_event_dates,
            event_id_hdfs_path=event_id_hdfs_path
        )

        # update event IDs and dates in event dict - update_event_id will return dates as datetime objects
        event_id_after_increment = updated_event_id
        # event['event_id'] = event_id
        # event['start_date'] = event_start_date
        # event['end_date'] = event_end_date

    else:
        # otherwise convert string dates from yyyy/mm/dd to yyyy-mm-ddThh:mm:ss datetime formats
        logger.info("increment_event_ids false")
        in_format = '%Y/%m/%d'
        out_format = '%Y/%m/%d'

        start_dt = datetime.datetime.strptime(event['start_date'], in_format)
        start_dttm = datetime.datetime(start_dt.year, start_dt.month, start_dt.day, 0, 0, 0)
        start_dttm_string = start_dttm.strftime(out_format)
        event['start_date'] = start_dttm_string

        end_dt = datetime.datetime.strptime(event['end_date'], in_format)
        end_dttm = datetime.datetime(end_dt.year, end_dt.month, end_dt.day, 23, 59, 59)
        end_dttm_string = end_dttm.strftime(out_format)
        event['end_date'] = end_dttm_string

    # get list of allocatable variations and raise error if we do not have one each of CONTROL and CHAMPION variations
    # also capture ID and weighting of control variations
    variation_list, control_variation_id, control_weight = get_variations(variation)

    # loop over each variations and spark submit the run_allocation spark driver for each, writing results to HDFS
    # all customers will be allocated to each allocatable variations at this stage, and no file will be created for
    # the control variation
    # allocated_variation_files will be dict with variations ID as key, path to results as value, ie:
    #  {
    #       1: "/hdfs/path/variation_1_result_file",
    #       2: "/hdfs/path/variation_2_result_file",
    #       ...,
    #       n: "/hdfs/path/variation_n_result_file"
    # }

    if not metadata_only:
        allocated_variation_files = allocate_variations(
            client=client_name.lower(),
            variation_list=variation_list,
            algorithm=alg,
            event_id=event_id,
            dttm=allocation_start_dttm,
            hdfs_output_path=hdfs_output_path,
            config_file=conf.file_name
        )

        logger.info("Allocated variation files: {0}".format(allocated_variation_files))

        # if control_rules is not None:
        #
        #     control_conf = cfg.Config(logger=logger)
        #     control_conf.add_dict(control_rules)
        #     control_hdfs_path = control_conf.get_item(keys='hdfs_path', mandatory=True)
        #     control_conf.error_on_mandatory_exceptions()
        #
        #     # spark submit the update_control spark driver, adding any new customers identified in this allocation to
        #     # the event's static target, control and program control populations
        #     update_control(
        #         algorithm=alg,
        #         dttm=allocation_start_dttm,
        #         allocated_files=allocated_variation_files,
        #         hdfs_output_path=hdfs_output_path,
        #         hdfs_control=control_hdfs_path,
        #         event_id=control_event_id,
        #         config_file=conf.file_name
        #     )

            # spark submit the send_control_files spark driver, creating a control variation file and allocating each
            # target customer to one of the allocated variations in accordance with the variations weights
            # send_files will be another dict, in the same format as allocated_variation_files, ie:
            #  {
            #       0: "/hdfs/path/variation_1_result_file.controlled",
            #       1: "/hdfs/path/variation_2_result_file.controlled",
            #       2: "/hdfs/path/variation_2_result_file.controlled",
            #       ...,
            #       n: "/hdfs/path/variation_n_result_file.controlled"
            # }
        #     send_files = generate_send_files(
        #         algorithm=alg,
        #         dttm=allocation_start_dttm,
        #         allocated_files=allocated_variation_files,
        #         hdfs_output_path=hdfs_output_path,
        #         event_id=event_id,
        #         control_variation_id=control_variation_id,
        #         config_file=conf.file_name
        #     )
        # else:
        #     # if we do not maintain controls then just send all files output from allocate_variations step
        #     send_files = allocated_variation_files

    # loop over all the destinations we want to use SSH/webHDFS to transfer metadata and/or results to



def get_variations(variation_dict):
    """Return a list of each non-control variation's ID and description, and count the CONTROL and CHAMPION variations.
    Args:
        variation_dict: Dict containing the "variation" key from the algorithm's config file
    Returns:
        List of Tuples: [(var1_id, var1_description), (var2_id, var2_description), ...]
        ID of Control variation
        Weighting of Control variation
    """
    control_count = 0
    champion_count = 0
    challenger_count = 0
    allocatable_variations = list()
    control_variation_id = None
    control_weight = None

    logger.info('Event Variations found in config file:')
    for variation_id in sorted([variation_id for variation_id in variation_dict.keys() if variation_id.isdecimal()]):
        variation_description = variation_dict[variation_id]['variation_description']
        variation_type = variation_dict[variation_id]['variation_type']
        variation_weight = variation_dict[variation_id]['weighting']
        do_not_allocate = variation_dict[variation_id].get('do_not_allocate', 'false') == 'true'
        logger.info('    ID: {0}, Type {1}, Description: {2}'.
                    format(variation_id, variation_type, variation_description))
        if variation_type == "CONTROL":
            control_variation_id = variation_id
            control_weight = variation_weight
            control_count += 1
        else:
            if not do_not_allocate:
                allocatable_variations.append((variation_id, variation_description))
            if variation_type == "CHAMPION":
                champion_count += 1
            elif variation_type == "CHALLENGER":
                challenger_count += 1
    if control_count != 1:
        raise RuntimeError('A single variation of type "CONTROL" is required - found {0}'.format(control_count))
    if champion_count != 1:
        raise RuntimeError('A single variation of type "CHAMPION" is required - found {0}'.format(champion_count))
    return allocatable_variations, control_variation_id, control_weight



if __name__ == "__main__":
    args = None
    err = None
    err_str = None
    tracking_url = None
    status = "Unknown"
    start_time = datetime.datetime.today()
    logger = logging.getLogger(__name__)
    sh = logging.StreamHandler()
    fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y-%m-%d %H:%M:%S')
    sh.setLevel(logging.DEBUG)
    sh.setFormatter(fmt)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(sh)


    try:
        args_config = json.loads(sys.argv[-1])
        main(alg=args_config['algorithm'], metadata_only=ast.literal_eval(args_config['metadata-only']))
        status = 'Complete'
    except SparkApplicationError as err:
        status = 'Failed'
        tracking_url = err.application_url
        err_str = err.error
    except SparkSubmitError as err:
        status = 'Failed'
        tracking_url = None
        err_str = err.message
    except Exception as err:  # sokay, we're re-raising below, just want to nab the traceback for chat message
        status = 'Failed'
        logger.info("Application has failed")
        logger.info(err)
        # tracking_url = None
        # _, _, ex_traceback = sys.exc_info()
        # tb_lines = traceback.format_exception(err.__class__, err, ex_traceback)
        # err_str = "\n".join(tb_lines)
        #TO-DO  : add notify method here