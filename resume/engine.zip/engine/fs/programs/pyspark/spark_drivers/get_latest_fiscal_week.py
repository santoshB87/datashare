import subprocess
import sys
import re

RE_PATTERN = re.compile(".*[a-z]*_[a-z]*_[a-z]*_[a-z]*_[0-9]*w[0-9]*w")

def is_table_path(path):
    match = re.match(RE_PATTERN, path)
    return True if match else False


def list_partitions(table_path, part_col):
    hdfs_command = ["hdfs", "dfs", "-ls", table_path]
    raw_output = subprocess.check_output(hdfs_command).split("\n")
    return map(lambda x: x.split("=")[-1], filter(lambda x: part_col in x, raw_output))


def list_all_tables(db_path, tables):
    if tables:
        list_of_tables = []
        for table in tables:
            list_of_tables.append(db_path + "/" + table)
    else:
        hdfs_command = ["hdfs", "dfs", "-ls", db_path]
        raw_output = subprocess.check_output(hdfs_command).split("\n")
        list_of_tables = map(lambda x: x.split(" ")[-1], raw_output[1:-1])
    return list_of_tables


if __name__ == "__main__":
    base_path = sys.argv[1]
    tables = sys.argv[2:] or []
    partition_col_name = "cadence_week"
    list_of_tables = list_all_tables(base_path, tables)
    list_of_tables = list_of_tables if tables else filter(lambda x: is_table_path(x), list_all_tables(base_path, tables))
    print "List of all tables:", str(list_of_tables)
    table_partitions_list = filter(lambda x: len(x) > 0, [list_partitions(each, partition_col_name) for each in list_of_tables])
    print "List of partitions in the tables:", str(table_partitions_list)
    list_of_successful_partitions = list(reduce(lambda x, y: set(x).intersection(set(y)), table_partitions_list))
    latest_successful_partition_id = max(map(lambda x: int(x), list_of_successful_partitions))
    sys.stdout.write(str(latest_successful_partition_id))
    sys.stdout.flush()
