import subprocess
import re
import logging
import sys

logger = logging.getLogger(__name__)


def features_list(features_dir):

    if bool(re.search("/$",features_dir))== False:
        features_dir = features_dir + '/'

    cmd = "gsutil ls {features_dir}".format(**locals())

    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    val = []
    for line in p.stdout.readlines():
            if line == "\n" :
                    continue
            val.append(line.replace("\n",""))

    if bool(re.search("CommandException: One or more URLs matched no objects","\n".join(val))):
        raise Exception("Unable to list the file with pattern matching {0}*".format(features_dir))

    list_of_features = []
    for i in val:
        dir_name = re.sub(features_dir, '', i)
        dir_name = re.sub('/', '', dir_name)
        feature_bucket_pattern = re.compile(r'^[a-z]+_[a-z]+_[a-z]+_[a-z]+_[0-9]+w[0-9]+w$')

        if feature_bucket_pattern.search(dir_name) is not None:
            list_of_features.append(dir_name)

    return list_of_features


def find_latest_cadence(features_dir, feature):

    if bool(re.search("/$",features_dir))== False:
        features_dir = features_dir + '/'

    cmd = "gsutil ls {features_dir}{feature} | sort -n | tail -n 1".format(**locals())

    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    val = []
    for line in p.stdout.readlines():
            if line == "\n" :
                    continue
            val.append(line.replace("\n",""))

    if bool(re.search("CommandException: One or more URLs matched no objects","\n".join(val))):
        raise Exception("Unable to list the file with pattern matching {0}*".format(features_dir))

    return val


def features_latest_cadence_mapping(features_dir):

    if bool(re.search("/$",features_dir))== False:
        features_dir = features_dir + '/'

    list_of_features = features_list(features_dir)
    latest_cadence_mapping = {}
    latest_cadence_list = []
    for feature in list_of_features:
        latest_cadence_path = find_latest_cadence(features_dir, feature)[0]
        val = re.search(r'20[0-9]{4}', latest_cadence_path)
        if val is not None :
            latest_cadence = val.group()
            latest_cadence_mapping.update({feature: latest_cadence})
            latest_cadence_list.append(latest_cadence_path)

    return latest_cadence_mapping


if __name__ == "__main__":
    features_dir = sys.argv[1]
    latest_cadence_mapping = features_latest_cadence_mapping(features_dir)
    latest_cadence_week = latest_cadence_mapping[max(latest_cadence_mapping.keys())]
    sys.stdout.write(str(latest_cadence_week))
    sys.stdout.flush()