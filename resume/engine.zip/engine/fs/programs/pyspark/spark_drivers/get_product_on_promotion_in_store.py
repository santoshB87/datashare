"""This is the spark driver scrips which calls the product_on_promotion_in_store class.
This returns us a dataframe which is stored in our HDFS location as a CSV file."""

import logging
from pyspark import SparkConf
from coop_no.cmp_entities.product_on_promotion_in_store import ProductOnPromotionInStore

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
sh = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y-%m-%d %H:%M:%S')
sh.setLevel(logging.DEBUG)
sh.setFormatter(fmt)
logger.setLevel(logging.DEBUG)
logger.addHandler(sh)

conf = SparkConf().setAppName('get data from product_on_promotion_in_store')
conf.set("spark.sql.parquet.binaryAsString", "true")

try:
    products = ProductOnPromotionInStore({"SSEHiveDatabasePrefix": "cno"})
    prod_df = products.data
    prod_df.write.format('com.databricks.spark.csv').\
        mode('overwrite').option("header", "true").\
        save("/coop_no/Lev1/sse/hive/cno_ssewh/product_on_promotion_in_store")
    logger.info('Data Extraction from product_on_promotion_in_store :Success')
except Exception as e:
    logger.error('Data Extraction from product_on_promotion_in_store :Failed')
    logger.error('Possible cause  :: {0}'.format(e))
    raise Exception(e)
