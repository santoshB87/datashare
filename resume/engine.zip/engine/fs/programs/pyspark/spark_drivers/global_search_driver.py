#!/dhcommon/dhpython/python/bin/python2.7
"""
This module is use to run the global search script and saving results in hive pob database
"""
import json
import logging

from client.global_search.global_search_trial_rate import create_and_write_trial_rates
from client.global_search.global_search_popularity import calculate_popularity
from client.global_search.global_search_combined import create_combined_view

logger = logging.getLogger(__name__)

logger.info('Reading client config file')
config = json.load(open('config.json', 'r'))

# Is global search something we intend to implement for a number of clients?
# module_name = (config['ClientName']).lower() +'.global_search_popularity'

media_mart_database = config['media_mart_database']
write_database = config['write_database']
pre = config['trial_pre']
trial = config['trial_trial']
min_hshd = config['trial_min_hshd']
channel_id = config['trial_channel']
min_visits = config['pop_min_visits']
weight_itm = config["pop_weight_itm"]
weight_bsk = config["pop_weight_bsk"]
pop_trial_channel = config["pop_trial_channel"]


# Create Trial Rate Metrics
create_and_write_trial_rates(media_mart_database,write_database,pre,trial,min_hshd,channel_id)

# For each channel-trial period, create popularity metric
for trial_period,channel_lists in pop_trial_channel.items():
    for channel_list in channel_lists:
        if isinstance(channel_list, basestring) : channel_list = [channel_list]
        logger.info('Trial Period : {trial_period}, Channels : {channel_list}'.format(trial_period=trial_period,channel_list=channel_list))
        calculate_popularity(trial_period=trial_period,  media_mart_database=media_mart_database, write_database=write_database, channel=channel_list, weight_itm=weight_itm,
                             weight_bsk=weight_bsk, min_visits=min_visits)

# Create combined view
create_combined_view(write_database=write_database)
