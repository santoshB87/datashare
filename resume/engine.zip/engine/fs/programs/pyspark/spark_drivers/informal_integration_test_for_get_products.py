import json
import logging

from pyspark import SparkContext, HiveContext, SparkConf
from reference.products import get_products

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
sh = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
sh.setLevel(logging.INFO)
sh.setFormatter(fmt)
logger.setLevel(logging.INFO)
logger.addHandler(sh)

conf = SparkConf().setAppName('standard_conversion_scoring_prepare driver')
conf.set("spark.sql.parquet.binaryAsString", "true")
sc = SparkContext(conf=conf)
sqlContext = HiveContext(sc)
config = json.load(open('control.json', 'r'))

logger.info('Begin SSE logging...')  # a string that can be searched for in the log in order to find the pertinent info

config = dict((key, value) for (key, value) in config.items() if
              key in [
                  'Market',
                  'SSEHiveDatabasePrefix',
                  'ProductDivisionAttribute',
                  'ProductGroupAttribute',
                  'ProductSubgroupAttribute',
                  'ProductProductAttribute',
                  'ProductAttributeMappings'
              ]
              )
get_products(sc, sqlContext, config).show()

