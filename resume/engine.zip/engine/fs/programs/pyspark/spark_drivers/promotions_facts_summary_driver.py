#!/dhcommon/dhpython/python/bin/python2.7

import logging
import sys
import json


from pyspark.sql.functions import current_date, date_add, count, countDistinct

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
sh = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
sh.setLevel(logging.INFO)
sh.setFormatter(fmt)
logger.setLevel(logging.INFO)
logger.addHandler(sh)

logger.info('Begin SSE logging...')  # a string that can be searched for in the log in order to find the pertinent info


#Loading sys arguments
args_config = json.loads(sys.argv[-1])

client_name = args_config['client_name']
logger.info('client_name = %s'%client_name)

period = args_config['period']
logger.info('period = %s'%period)

SSEHiveDatabasePrefix = args_config['SSEHiveDatabasePrefix']
logger.info('SSEHiveDatabasePrefix = %s'%SSEHiveDatabasePrefix)

dimensions_to_aggregate_on = args_config['dimensions_to_aggregate_on']
logger.info('dimensions_to_aggregate_on = %s'%dimensions_to_aggregate_on)


## Importing client CMP entity modules
logger.info('Importing %s CMP entities'%client_name)
stores = __import__('{client_name}.cmp_entities.stores'.format(client_name=client_name), globals(), locals(), -1)
products = __import__('{client_name}.cmp_entities.products'.format(client_name=client_name), globals(), locals(), -1)
product_on_promotion_in_store = __import__('{client_name}.cmp_entities.product_on_promotion_in_store'.format(client_name=client_name), globals(), locals(), -1)


## Initializing client CMP entities
stores_df  = stores.Stores({'SSEHiveDatabasePrefix' : SSEHiveDatabasePrefix}).data
products_df  = products.Products({'SSEHiveDatabasePrefix' : SSEHiveDatabasePrefix}).data
product_on_promotion_in_store_df  = product_on_promotion_in_store.ProductOnPromotionInStore({'SSEHiveDatabasePrefix' : SSEHiveDatabasePrefix}).data

# Joining entities' data
product_on_promotion_in_store_df = product_on_promotion_in_store_df.join(stores_df, product_on_promotion_in_store_df.Store == stores_df.Store).drop(stores_df.Store)
product_on_promotion_in_store_df = product_on_promotion_in_store_df.join(products_df, product_on_promotion_in_store_df.Product == products_df.Product).drop(products_df.Product)

## Creating df of active promotion facts
product_on_promotion_in_store_df_active = product_on_promotion_in_store_df.where(
    (product_on_promotion_in_store_df['PromotionStartDatetime'] <= current_date())
    & (product_on_promotion_in_store_df['PromotionEndDatetime'] > date_add(current_date(),period)))

logger.info('Total Number of distinct Promotions in the Promo Entity : {0}'.format(
    product_on_promotion_in_store_df.select(product_on_promotion_in_store_df.Promotion).distinct().count()))

logger.info('Number of distinct Active Promotions in the Promo Entity : {0}'.format(
    product_on_promotion_in_store_df_active.select(product_on_promotion_in_store_df_active.Promotion).distinct().count()))

logger.info('Total Number of Promotion facts in the Promo Entity : {0}'.format(
    product_on_promotion_in_store_df.count()))

logger.info('Number of Active Promotions facts in the Promo Entity : {0}'.format(
    product_on_promotion_in_store_df_active.count()))

## Creating summaries
for grain in dimensions_to_aggregate_on :
    logger.info(grain)

    logger.info('Total Promotions Counts')
    grouped_df = product_on_promotion_in_store_df.groupby(grain).agg(countDistinct('Promotion').alias('Promotions'),\
                                                                     count('Promotion').alias('Facts'))
    logger.info(grouped_df.show(grouped_df.count()))

    logger.info('Active Promotions Counts')
    grouped_df = product_on_promotion_in_store_df_active.groupby(grain).agg(countDistinct('Promotion').alias('Promotions'),\
                                                                     count('Promotion').alias('Facts'))
    logger.info(grouped_df.show(grouped_df.count()))
