#!/dhcommon/dhpython/python/bin/python2.7
from dunnhumby import contexts
import json
import logging
import sys
from datetime import datetime

def main(argv):
    # set up basic logger with stream handler
    if len(argv) < 3:
        raise RuntimeError("Too few arguments have been supplied. Arguments client & cadence_attribute are required")
    logger = logging.getLogger(__name__)
    sh = logging.StreamHandler()
    fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
    sh.setLevel(logging.DEBUG)
    sh.setFormatter(fmt)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(sh)

    logger.info('Begin SSE logging...')  # a string that can be searched for in the log in order to find the pertinent info
    sc = contexts.sc()
    for conf_option in sorted(sc._conf.getAll()):
        logger.info("{conf_option}={value}".format(conf_option=conf_option[0],value=conf_option[1]))

    logger.info('Reading client config file')
    fh = open("config.json","r")

    config = json.load(open('config.json', 'r'))

    # The first system argument in call to spark-submit must be the client name
    client_name = argv[1].lower()
    logger.info('client_name = {client_name}'.format(client_name=client_name))
    # The second  system argument in call to spark-submit must be the cadence attribute
    cadence_attribute = argv[2].lower()
    logger.info('cadence_attribute = {cadence_attribute}'.format(cadence_attribute=cadence_attribute))

    logger.info('Command-line arguments:')
    for arg in argv:
        logger.info('  {arg}'.format(arg=arg))
    run_date = None
    if len(argv) > 3:
        #Expecting that the last arg is a JSON document
        argv3 = argv[3]
        logger.info("Attempting to parse {argv3} as json".format(argv3=argv3))
        j = json.loads(argv3)
        if 'run_date' in j.keys():
            run_date_str = j['run_date']
            try:
                run_date = datetime.strptime(run_date_str, '%Y-%m-%d').date()
            except:
                raise
        else:
            logger.info('No run_date supplied on command-line. Default run_date will be used.')

    if not run_date:
        logger.info('Importing {client_name} specific rundate-determinator module'.format(client_name=client_name))
        rundate_determinator = __import__('{client_name}.rundate_determinator'.format(client_name=client_name),
                                          globals(),
                                          locals(),
                                          -1
                                          )
        run_date = rundate_determinator.RunDateDeterminator(config).run_date
    logger.info("run_date  = {run_date}".format(run_date=run_date))
    logger.info('Importing {client_name} specific features-coordinator module'.format(client_name=client_name))
    purchasingfeaturecoordinator = __import__(
        '{client_name}.cmp_features.purchasingfeaturecoordinator'.format(client_name=client_name), globals(), locals(),
        -1)
    feature_coordinator = purchasingfeaturecoordinator.PurchasingFeatureCoordinator(config,
                                                                                    cadence_attribute,
                                                                                    run_date=run_date)
    feature_coordinator.generate_and_write_features()

if __name__ == "__main__":
    main(sys.argv)