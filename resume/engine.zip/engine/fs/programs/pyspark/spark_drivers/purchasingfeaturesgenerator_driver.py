#!/dhcommon/dhpython/python/bin/python2.7


import json
import logging
import sys
import time
import os
from datetime import datetime as dt
from dunnhumby import contexts


def main(argv):
    # set up basic logger with stream handler
    print(argv)
    if len(argv) < 4:
        raise RuntimeError("Too few arguments have been supplied. Arguments client & cadence_attribute are required")
    logger = logging.getLogger(__name__)
    sh = logging.StreamHandler()
    fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
    sh.setLevel(logging.DEBUG)
    sh.setFormatter(fmt)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(sh)

    logger.info('Begin SSE logging...')  # a string that can be searched for in the log in order to find the pertinent info
    sc = contexts.sc()
    # for conf_option in sorted(sc._conf.getAll()):
    #     logger.info("{conf_option}={value}".format(conf_option=conf_option[0],value=conf_option[1]))

    logger.info('Reading client config file')
    fh = open("config.json","r")

    config = json.load(open('config.json', 'r'))
    feature_specs = json.load(open('feature_specs.json', 'r')).values()

    # The first system argument in call to spark-submit must be the client name
    client_name = argv[1].lower()
    logger.info('client_name = {client_name}'.format(client_name=client_name))
    # The second  system argument in call to spark-submit must be the cadence attribute
    cadence_attribute = argv[2].lower()
    logger.info('cadence_attribute = {cadence_attribute}'.format(cadence_attribute=cadence_attribute))
    if cadence_attribute not in ['fis_week_id']:
        raise ValueError('invalid value for argument cadence_attribute, accepted values are '
                         '(fis_week_id, date_short_name)')

    clean_run = argv[3].lower()
    logger.info('clean_run = {clean_run}'.format(clean_run=clean_run))
    clean_run = True if clean_run in ['true', '1', 'True', 'TRUE'] else False

    refresh_denorm = config.get("refresh_purchases_features", False)
    refresh_summary = config.get("refresh_summary_features", False)
    os.environ['MM_DATABASE'] = config["mm_database"]
    os.environ['CUSTOM_FACT_DIM_DATABASES'] = str(config.get("custom_fact_dim_databases", {}))

    #If a fourth argument is supplied parse it as run_date
    if  len(argv) > 4:
        run_date = argv[4]
        run_date = dt.strptime(run_date, '%Y-%m-%d').date()
        logger.info('run_date = {run_date}'.format(run_date=run_date))
    else:
        run_date = dt.today().date()

    sqlContext = contexts.sql_context()
    sqlContext.conf.set("hive.exec.dynamic.partition", "true")
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    sqlContext.conf.set("spark.sql.parquet.compression.codec", "gzip")

    purchasingfeaturegenerator = __import__(
        '{client_name}.cmp_features.purchasing_feature_generator'.format(client_name=client_name), globals(), locals(),
        -1)
    purchasing_feature_gen = purchasingfeaturegenerator.PurchasingFeatureGenerator(config=config,
                                                                                   feature_specs=feature_specs,
                                                                                   cadence_attribute=cadence_attribute,
                                                                                   run_date=run_date,
                                                                                   refresh_denorm=refresh_denorm,
                                                                                   refresh_summary=refresh_summary)
    purchasing_feature_gen.generate_and_write_features(clean_run)

if __name__ == "__main__":
    main(sys.argv)
