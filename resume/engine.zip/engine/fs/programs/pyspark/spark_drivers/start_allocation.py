#!/dhcommon/dhpython/python/bin/python2.7
import sys
import os
import logging

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
sh = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
sh.setLevel(logging.DEBUG)
sh.setFormatter(fmt)
logger.setLevel(logging.DEBUG)
logger.addHandler(sh)

if __name__ == "__main__":

    # parse command line args
    engine_path = sys.argv[1]
    algorithm = sys.argv[2]
    client = sys.argv[3]

    logger.info('Begin SSE logging...')  # a string that can be searched for in the log in order to find the pertinent info

    working_directory = "{engine_path}/programs/pyspark/dunnhumby/cmp_allocation".format(engine_path=engine_path)

    logger.info('Changing working directory to {0}'.format(working_directory))
    os.chdir(working_directory)

    logger.info('Starting Allocation')
    start_allocation = "/dhcommon/dhpython/python/bin/python2.7 -m allocation --algorithm {algorithm} " \
                       "--config-file market_configs/{client}/config.json".format(algorithm=algorithm, client=client)
    process = os.system(start_allocation)
    return_code = os.WEXITSTATUS(process)

    if (return_code != 0):
        raise Exception("Process failed with exit code {0}".format(return_code))

    logger.info('End SSE logging...')

