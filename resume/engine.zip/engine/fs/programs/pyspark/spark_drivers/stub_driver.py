#!/dhcommon/dhpython/python/bin/python2.7
"""useful for when you simply need something that doesn't do every much, perhaps when testing spark-submit
Can be executed using (for example):

"/dhcommon/dhpython/python/bin/python2.7" "/monoprix/Lev4/sse/engine/airflow_call_ape_broker.py" "PySparkJob2" "/monoprix/Lev4/sse/engine" "{\"py-files\": \"engine/programs/pyspark/cmp-0.0.0-py2.7.egg\", \"spark_driver_args\": [\"jamie\"], \"pyspark_script_name\": \"engine/programs/pyspark/spark_drivers/cmp_hello_world_driver.py\"}"

"""
import logging
import sys
from pyspark import SparkConf
from dunnhumby import contexts
from pyspark.sql.types import *

def main(argv):
    # set up basic logger with stream handler
    if len(argv) < 3:
        raise RuntimeError("Too few arguments have been supplied. Arguments client & cadence_attribute are required")
    logger = logging.getLogger(__name__)

    logger.info('Begin stub logging...')  # a string that can be searched for in the log in order to find the pertinent info
    name = argv[1].lower()
    print "hello " + name

    conf = SparkConf().setAppName('stub_driver')
    conf.set("spark.sql.parquet.binaryAsString", "true")
    sc = contexts.sc(conf)
    for conf_option in sorted(sc._conf.getAll()):
        logger.info("{conf_option}={value}".format(conf_option=conf_option[0],value=conf_option[1]))
    sqlContext = contexts.sql_context()
    df = sqlContext.createDataFrame(
        [('Beans', 'JohnD', 'Brook Green', 'Online')],
        StructType(
            [StructField("Product", StringType(), True), StructField("Customer", StringType(), True),
             StructField("Store", StringType(), True), StructField("Channel", StringType(), True)]
        )
    )
    print df.count()

if __name__ == "__main__":
    main(sys.argv)