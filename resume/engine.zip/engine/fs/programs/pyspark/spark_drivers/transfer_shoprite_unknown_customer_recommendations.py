import os
import sys
import logging

logger = logging.getLogger(__name__)

CONFIG_FILE = 'programs/pyspark/dunnhumby/cmp_allocation/market_configs/shoprite/config.json'
TOOLS_EGG_PATH = 'programs/pyspark/dunnhumby/cmp_allocation/tools-latest.egg'
ALLOCATION_MODULE_PATH = 'programs/pyspark/dunnhumby/cmp_allocation/allocation'
ALGORITHM = 'relevant_promotions'

def transfer_recommendations_for_unknown_customers(config_file,algorithm):
    import util
    import tools.configs as config
    import output_to_linux as linux_out

    full_config = config.Config().add_source_file(config_file)
    linux_outputs_config_dict = full_config.get_item(keys=[algorithm, 'linux_outputs', 'axway'], mandatory=True)

    host = linux_outputs_config_dict['host']
    path = linux_outputs_config_dict['path']

    # HDFS/WebHDFS details
    hdfs_output_path = full_config.get_item(keys=(algorithm, 'hdfs_output_path'), mandatory=True)
    hdfs_name_nodes = full_config.get_item(keys='hdfs_name_nodes', mandatory=True)
    webhdfs_root = full_config.get_item(keys='webhdfs_root', mandatory=True)


    webhdfs_url = util.get_active_namenode_webhdfs_root(namenode_list=hdfs_name_nodes, webhdfs_root=webhdfs_root,logger=logger)

    latest_file_name = hdfs_output_path + '/MobileRecommendationsStore_' + 'latest'

    allocation_start_dttm_datetime = util.get_time_zoned_dttm("Europe/Dublin")
    allocation_start_dttm = allocation_start_dttm_datetime.strftime('%Y%m%d_%H%M%S')

    # transfer recommendation to destination system by SSHing onto it and then pulling data down over webHDFS
    linux_out.transfer_results({'1': latest_file_name}, webhdfs_root=webhdfs_url, destination_hostname=host,
                               destination_path=path, destination_buffer=None, drop_dot_complete=True,
                               dot_complete_with_stats=False, algorithm=None, client=None, dttm_stamp=allocation_start_dttm,
                               event_id=None, filename_pattern="MobileRecommendationsStore_{dttm}.csv")


if __name__ == "__main__":
    engine_path = sys.argv[1]

    CONFIG_FILE = os.path.join(engine_path, CONFIG_FILE)
    TOOLS_EGG_PATH = os.path.join(engine_path, TOOLS_EGG_PATH)
    ALLOCATION_MODULE_PATH = os.path.join(engine_path, ALLOCATION_MODULE_PATH)

    sys.path.append(TOOLS_EGG_PATH)
    sys.path.append(ALLOCATION_MODULE_PATH)

    transfer_recommendations_for_unknown_customers(config_file=CONFIG_FILE,algorithm=ALGORITHM)

