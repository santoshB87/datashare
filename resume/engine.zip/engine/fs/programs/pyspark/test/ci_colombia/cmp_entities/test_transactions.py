import unittest
import datetime
from dunnhumby import contexts
from ci_colombia.cmp_entities.transactions import Transactions
from pyspark.sql.types import *
from decimal import *


class TestTransactions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists ci_colombia_media_mart')
        self.sqlContext.sql('drop table if exists ci_colombia_media_mart.transactions')

        self.transaction_schema = StructType(
            [StructField("basket", StringType(), True),
             StructField("datetime", TimestampType(), True),
             StructField("product", StringType(), True),
             StructField("customer", StringType(), True),
             StructField("store", StringType(), True),
             StructField("channel", StringType(), True),
             StructField("quantity", IntegerType(), True),
             StructField("spendamount", DecimalType(18, 2), True),
             StructField("netspendamount", DecimalType(18, 2), True),
             StructField("discountamount", DecimalType(18, 2), True),
             StructField("fis_year_id", IntegerType(), True),
             StructField("fis_week_id", IntegerType(), True),
             StructField("date_id", DateType(), True)
             ])

    def tearDown(self):
        self.sqlContext.sql('drop table if exists ci_colombia_media_mart.transactions')
        self.sqlContext.sql('drop database if exists ci_colombia_media_mart')

    def test_one_row_returned_if_data_exists_in_all_underlying_tables(self):
        l = [('000004828750804', datetime.datetime(2018, 12, 16), '000000003700015846', '000000000000432', '41', None, 1,\
              Decimal('7.99'), Decimal('7.99'), Decimal('0.00'), 2018, 201846, datetime.date(2018, 12, 16))]
        self.sqlContext.createDataFrame(l, self.transaction_schema).write.\
            saveAsTable('ci_colombia_media_mart.transactions')
        transactions = Transactions()
        transactions_df = transactions.data.collect()
        self.assertEquals(len(transactions_df), 1)

