"""
ci_colombia mocked sample data set - being used in unit test cases of PurchasingFeatureGenerator
"""


from decimal import Decimal
import datetime
from datetime import datetime as dt
from pyspark.sql import types as pt

"""
Client config for test cases
"""
test_config = {
    "SSEHiveDatabasePrefix": "client",
    "SSEProductHierarchy": ["Division", "Department", "Section", "Group", "PacSubgroup", "Subgroup", "Product"],
    "SSEFeaturePacColumns": ["PacSubgroup"],
    "SSEHiveWarehousePath": "/user/hive/warehouse",
    "SSEHiveWarehousedb": "ci_colombia_media_mart",
    "SSEHiveWorkdb": "client_ssework",
    "SSEHivePobdb": "client_pob",
    "SSEHivePurchaseTab": "purchase_fct",
    "SSEHiveTransactionTab": "transactions",
    "SSEFeatureLogTab": "feature_run_log",
    "SSEFeatureDistinctTab": "feature_distinct_tab",
    "Sseraw_dataHdfsRootPath": "/dummy_path",
    "SSEFeatureDurations": [[1, 1], [1, 4]],
    "SSEFeatureCleanRun": "False",
    "SSEFeaturePacFlag": "True",
    "SSEFeatureBucketingFlag": "False",
    "SSEFeaturePaarFlag": "True",
    "filters": {
        "products": {
          "filter_condition": "(product is not null) and ((subgroup is not null) or (group is not null) or (section is not null) or (department is not null) or (division is not null))"
        }
    },
    # Data purging feature is controlled by SSEFeatureDataPurge (accept boolean value), it can be
    # tuned on/off. Specific behaviour of data retention in different stages are controlled by their
    # respective config values.
    # SSEFeatureDataPurgeMergeRetentionWeekNum - define data retention period for purchases and
    # summary tables. Any data beyond (T - n) weeks will be deleted (here T is week of day on which
    # process is launched/executed).
    # SSEFeatureDataPurgeMergeRetentionWeekNum - define data retention period for merge tables.
    # Any feature generated beyond (T - n) weeks will be deleted (here T is week of day on which
    # process is launched/executed).
    "SSEFeatureDataPurge": "False",
    "SSEFeatureDataPurgeRetentionWeekNum": 108,
    "SSEFeatureDataPurgePublishedRetentionWeekNum": 6,
    # Number of partition used for coalescing, before writing denorm/purchase table to disk/hive
    "SSEFeaturePurchaseRePartitionNum": 1,
    # In wave we are specifying two types of setting which will determine extent of parallelism in
    # our feature calculation process WorkerNum specifies how many parallel job can run and
    # ShufflePart will used to set value for spark.sql.shuffle.partitions
    # In denom section customer_df would be repartitioned as per shufflePart value
    "SSEFeatureDenormWave": {'WorkerNum': 2, 'ShufflePart': 1, "cacheReplica": 1},
    "SSEFeatureSummaryWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureSummaryWave2": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave2": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave3": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave4": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureMergeWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureMergeWave2": {'WorkerNum': 1, 'ShufflePart': 1},
}

"""
Setup Feature Specifications
"""
feature_specs = [
  {
    'name': 'All_All_All_All',
    'cadence_attribute': 'fis_week_id',
    'is_active': True,
    'summary_on': True,
    'durations': [
      [1, 1],
      [1, 4]
    ],
    'rsd': 0.0,
    'dimension_attribute_grain': {
      'ProductAttribute': 'All',
      'CustomerAttribute': 'All',
      'StoreAttribute': 'All',
      'ChannelAttribute': 'All'
    },
    'base_features': [
      'Baskets',
      'BasketWeeks',
      'Discount',
      'MaximumPrice',
      'MinimumPrice',
      'MaximumNetPrice',
      'MinimumNetPrice',
      'Quantity',
      'QuantityPrefStore1',
      'QuantityPrefStore2',
      'QuantityPrefStore3',
      'QuantityFulfillmentStore',
      'GrossSpend',
      'NetSpend',
      'MaxPurchaseDate',
      'MinPurchaseDate',
      'RecencyWeightedBasketWeeks75',
      'RecencyWeightedBasketWeeks95'
    ],
    'derived_features': [
      'BasketsFlag',
      'DiscountPerBasket',
      'DiscountPercent',
      'AveragePrice',
      'QuantityPerBasket',
      'NetSpendPerBasket',
      'AveragePurchaseCycle',
      'RecencyDays',
      'CyclesSinceLastPurchase'
    ],
    'distinct_features': [
      'DivisionCount',
      'DepartmentCount',
      'SectionCount',
      'GroupCount',
      'PacSubgroupCount',
      'SubgroupCount',
      'ProductCount',
      'CustomerCount'
    ]
  },
  {
    'name': 'All_Customer_All_All',
    'cadence_attribute': 'fis_week_id',
    'is_active': True,
    'summary_on': True,
    'durations': [
      [1, 1],
      [1, 4]
    ],
    'rsd': 0.0,
    'dimension_attribute_grain': {
      'ProductAttribute': 'All',
      'CustomerAttribute': 'Customer',
      'StoreAttribute': 'All',
      'ChannelAttribute': 'All'
    },
    'base_features': [
      'Baskets',
      'BasketWeeks',
      'Discount',
      'MaximumPrice',
      'MinimumPrice',
      'MaximumNetPrice',
      'MinimumNetPrice',
      'Quantity',
      'QuantityPrefStore1',
      'QuantityPrefStore2',
      'QuantityPrefStore3',
      'QuantityFulfillmentStore',
      'GrossSpend',
      'NetSpend',
      'MaxPurchaseDate',
      'MinPurchaseDate',
      'RecencyWeightedBasketWeeks75',
      'RecencyWeightedBasketWeeks95'
    ],
    'derived_features': [
      'BasketsFlag',
      'DiscountPerBasket',
      'DiscountPercent',
      'AveragePrice',
      'QuantityPerBasket',
      'NetSpendPerBasket',
      'AveragePurchaseCycle',
      'RecencyDays',
      'CyclesSinceLastPurchase'
    ],
    'distinct_features': [
      'DivisionCount',
      'DepartmentCount',
      'SectionCount',
      'GroupCount',
      'PacSubgroupCount',
      'SubgroupCount',
      'ProductCount'
    ]
  }
]

"""
Setup sqls
"""
setup_sql = {
    "drop_db_ssewh": "DROP DATABASE IF EXISTS ci_colombia_media_mart CASCADE",
    "drop_db_ssework": "DROP DATABASE IF EXISTS client_ssework CASCADE",
    "drop_db_pob": "DROP DATABASE IF EXISTS client_pob CASCADE",
    "create_db_ssewh": "CREATE DATABASE IF NOT EXISTS ci_colombia_media_mart "
                       "LOCATION '/user/hive/warehouse/ci_colombia_media_mart'",
    "create_db_ssework": "CREATE DATABASE IF NOT EXISTS client_ssework "
                         "LOCATION '/user/hive/warehouse/client_ssework'",
    "create_db_pob": "CREATE DATABASE IF NOT EXISTS client_pob LOCATION "
                     "'/user/hive/warehouse/client_pob'",
    "drop_transaction_item_fct": "DROP TABLE IF EXISTS ci_colombia_media_mart.transactions",
    "drop_purchase_fct": "DROP TABLE IF EXISTS client_ssework.purchase_fct",
    "create_transaction_item_fct": "CREATE TABLE ci_colombia_media_mart.transactions( "
                                    "basket string, datetime timestamp, product string, customer string,"
                                    "store string, channel string, quantity int, spendamount decimal(15,2),"
                                    "netspendamount decimal(15,2), discountamount decimal(15,2))"
                                    "PARTITIONED BY (fis_year_id int, fis_week_id int, date_id date)"
                                            "STORED AS PARQUET",
    "ins_transaction_item_fct": "INSERT INTO ci_colombia_media_mart.transactions PARTITION(fis_year_id, fis_week_id, date_id) "
                                "SELECT * FROM client_ssework.temp_trans",
    "create_purchase_fct": "CREATE TABLE IF NOT EXISTS client_ssework.purchase_fct (basket string, "
                           "division string, department string, section string, group string, pacsubgroup string, subgroup string, "
                           "product string, customer string, store string, banner string, fulfillmentstore string,"
                           " preferredstore1 string, preferredstore2 string, preferredstore3 string"
                           ", channel string, quantity decimal(24,2), netspendamount decimal(38,2),"
                           " spendamount decimal(38,2), discountamount decimal(38,2)) "
                           "PARTITIONED BY (fis_week_id string, date_id string) STORED AS PARQUET "
                           'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_purchase_fct": "INSERT INTO client_ssework.purchase_fct PARTITION(fis_week_id, date_id) "
                        "SELECT * FROM client_ssework.temp_purchase",
}

"""
Result set
"""
result_set = {
    "required_fis_weeks": [u"201743", u"201742", u"201741", u"201744", u"201740"],
    "cadence_week_for_fis_week_id": "201744",
    "since_date": dt.strptime("2017-12-03", "%Y-%m-%d").date(),
}

"""
date_dim/date_df - 42 rows for each date_id between 2017-11-27 & 2018-01-07
"""
date_schema = pt.StructType([
    pt.StructField("date_id", pt.DateType(), True),
    pt.StructField("date_name", pt.StringType(), True),
    pt.StructField("date_short_name", pt.StringType(), True),
    pt.StructField("day_of_week_name", pt.StringType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("fis_day_of_week_num", pt.ShortType(), True),
    pt.StructField("fis_year_id", pt.IntegerType(), True)
])
date_lst = [
    (dt.strptime("2017-11-29 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 29, 2017", "2017-11-29", "WEDNESDAY", "201740", 4, 2017),
    (dt.strptime("2017-11-30 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 30, 2017", "2017-11-30", "THURSDAY", "201740", 5, 2017),
    (dt.strptime("2017-12-01 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 01, 2017", "2017-12-01", "FRIDAY", "201740", 6, 2017),
    (dt.strptime("2017-12-02 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 02, 2017", "2017-12-02", "SATURDAY", "201740", 7, 2017),
    (dt.strptime("2017-12-03 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 03, 2017", "2017-12-03", "SUNDAY", "201740", 1, 2017),
    (dt.strptime("2017-12-04 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 04, 2017", "2017-12-04", "MONDAY", "201741", 2, 2017),
    (dt.strptime("2017-12-05 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 05, 2017", "2017-12-05", "TUESDAY", "201741", 3, 2017),
    (dt.strptime("2017-12-06 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 06, 2017", "2017-12-06", "WEDNESDAY", "201741", 4, 2017),
    (dt.strptime("2017-12-07 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 07, 2017", "2017-12-07", "THURSDAY", "201741", 5, 2017),
    (dt.strptime("2017-12-08 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 08, 2017", "2017-12-08", "FRIDAY", "201741", 6, 2017),
    (dt.strptime("2017-12-09 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 09, 2017", "2017-12-09", "SATURDAY", "201741", 7, 2017),
    (dt.strptime("2017-12-10 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 10, 2017", "2017-12-10", "SUNDAY", "201741", 1, 2017),
    (dt.strptime("2017-12-11 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 11, 2017", "2017-12-11", "MONDAY", "201742", 2, 2017),
    (dt.strptime("2017-12-12 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 12, 2017", "2017-12-12", "TUESDAY", "201742", 3, 2017),
    (dt.strptime("2017-12-13 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 13, 2017", "2017-12-13", "WEDNESDAY", "201742", 4, 2017),
    (dt.strptime("2017-12-14 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 14, 2017", "2017-12-14", "THURSDAY", "201742", 5, 2017),
    (dt.strptime("2017-12-15 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 15, 2017", "2017-12-15", "FRIDAY", "201742", 6, 2017),
    (dt.strptime("2017-12-16 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 16, 2017", "2017-12-16", "SATURDAY", "201742", 7, 2017),
    (dt.strptime("2017-12-17 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 17, 2017", "2017-12-17", "SUNDAY", "201742", 1, 2017),
    (dt.strptime("2017-12-18 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 18, 2017", "2017-12-18", "MONDAY", "201743", 2, 2017),
    (dt.strptime("2017-12-19 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 19, 2017", "2017-12-19", "TUESDAY", "201743", 3, 2017),
    (dt.strptime("2017-12-20 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 20, 2017", "2017-12-20", "WEDNESDAY", "201743", 4, 2017),
    (dt.strptime("2017-12-21 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 21, 2017", "2017-12-21", "THURSDAY", "201743", 5, 2017),
    (dt.strptime("2017-12-22 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 22, 2017", "2017-12-22", "FRIDAY", "201743", 6, 2017),
    (dt.strptime("2017-12-23 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 23, 2017", "2017-12-23", "SATURDAY", "201743", 7, 2017),
    (dt.strptime("2017-12-24 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 24, 2017", "2017-12-24", "SUNDAY", "201743", 1, 2017),
    (dt.strptime("2017-12-25 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 25, 2017", "2017-12-25", "MONDAY", "201744", 2, 2017),
    (dt.strptime("2017-12-26 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 26, 2017", "2017-12-26", "TUESDAY", "201744", 3, 2017),
    (dt.strptime("2017-12-27 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 27, 2017", "2017-12-27", "WEDNESDAY", "201744", 4, 2017),
    (dt.strptime("2017-12-28 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 28, 2017", "2017-12-28", "THURSDAY", "201744", 5, 2017),
    (dt.strptime("2017-12-29 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 29, 2017", "2017-12-29", "FRIDAY", "201744", 6, 2017),
    (dt.strptime("2017-12-30 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 30, 2017", "2017-12-30", "SATURDAY", "201744", 7, 2017),
    (dt.strptime("2017-12-31 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 31, 2017", "2017-12-31", "SUNDAY", "201744", 1, 2017),
    (dt.strptime("2018-01-01 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 01, 2018", "2018-01-01", "MONDAY", "201745", 2, 2017),
    (dt.strptime("2018-01-02 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 02, 2018", "2018-01-02", "TUESDAY", "201745", 3, 2017),
    (dt.strptime("2018-01-03 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 03, 2018", "2018-01-03", "WEDNESDAY", "201745", 4, 2017)
]

"""
products_df
"""
product_schema = pt.StructType([ pt.StructField('product', pt.StringType(), True), ##
                              pt.StructField('productdescription', pt.StringType(), True),
                              pt.StructField('productalternate', pt.StringType(), True),
                              pt.StructField('subgroup', pt.StringType(), True), ##
                              pt.StructField('subgroupdescription', pt.StringType(), True),
                              pt.StructField('group', pt.StringType(), True), ##
                              pt.StructField('groupdescription', pt.StringType(), True),
                              pt.StructField('section', pt.StringType(), True), ##
                              pt.StructField('sectiondescription', pt.StringType(), True),
                              pt.StructField('department', pt.StringType(), True),
                              pt.StructField('departmentdescription', pt.StringType(), True),
                              pt.StructField('division', pt.StringType(), True), ##
                              pt.StructField("divisiondescription", pt.StringType(), True),
                              pt.StructField("producthiearchytype", pt.StringType(), True),
                              pt.StructField("productbrand", pt.StringType(), True),
                              pt.StructField("productsupplier", pt.StringType(), True),
                              pt.StructField("isalcohol", pt.IntegerType(), True),
                              pt.StructField("isfuel", pt.IntegerType(), True),
                              pt.StructField("isbaby", pt.IntegerType(), True),
                              pt.StructField("ispet", pt.IntegerType(), True),
                              pt.StructField("issoldbyweight", pt.IntegerType(), True),
                              pt.StructField("productimage", pt.StringType(), True),
                              pt.StructField("isnew", pt.IntegerType(), True),
                              pt.StructField("newproductlaunchdatetime", pt.TimestampType(), True),
                              pt.StructField("fis_week_id", pt.IntegerType(), True)
                             ])
product_lst = [
    ("Product0", None, None, "UNKNOWN_DIMENSION", None, "UNKNOWN_DIMENSION", None, "UNKNOWN_DIMENSION", None, None, None, "UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product1", None, None, "A1A1", None, "A1A", None, "A1", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product2", None, None, "B1A1", None, "B1A", None, "B1", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product3", None, None, "C1A1", None, "C1A", None, "C1", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product4", None, None, "A1B1", None, "A1B", None, "A1", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product5", None, None, "C1B1", None, "C1B", None, "C1", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product6", None, None, "C1A2", None, "C1A", None, "C1", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product7", None, None, "B1B1", None, "B1B", None, "B1", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product8", None, None, "D1A1", None, "D1A", None, "D1", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product9", None, None, "D1B1", None, "D1B", None, "D1", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product10", None, None, "D1A2", None, "D1A", None, "D1", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product11", None, None, "D2A1", None, "D2A", None, "D2", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product12", None, None, "D2B1", None, "D2B", None, "D2", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product13", None, None, "D2A1", None, "D2A", None, "D2", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product14", None, None, "A2A1", None, "A2A", None, "A2", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product15", None, None, "B2A1", None, "B2A", None, "B2", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product16", None, None, "B2B1", None, "B2B", None, "B2", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product17", None, None, "D1B2", None, "D1B", None, "D1", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product18", None, None, "A2B1", None, "A2B", None, "A2", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product19", None, None, "D2B2", None, "D2B", None, "D2", None, None, None, "D", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product20", None, None, "B1A1", None, "B1A", None, "B1", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product21", None, None, "A1A1", None, "A1A", None, "A1", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product22", None, None, "A1B1", None, "A1B", None, "A1", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product23", None, None, "A2A2", None, "A2A", None, "A2", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product24", None, None, "B2A2", None, "B2A", None, "B2", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product25", None, None, "B2B2", None, "B2B", None, "B2", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product26", None, None, "C2A1", None, "C2A", None, "C2", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product27", None, None, "C2B1", None, "C2B", None, "C2", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product28", None, None, "C2A1", None, "C2A", None, "C2", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product29", None, None, "B1B2", None, "B1B", None, "B1", None, None, None, "B", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product30", None, None, "C1B2", None, "C1B", None, "C1", None, None, None, "C", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
    ("Product31", None, None, "A2B2", None, "A2B", None, "A2", None, None, None, "A", None, None, None, None, None, None, None, None, None, None, None, None, 201904),
]

"""
customers_df
"""
customer_schema = pt.StructType([
        pt.StructField("Customer", pt.StringType(), True),
        pt.StructField("IsEmailable", pt.IntegerType(), True),
        pt.StructField("CustomerSloyaltyHigh", pt.StringType(), True),
        pt.StructField("CustomerSloyaltyLow", pt.StringType(), True),
        pt.StructField("FulfillmentStore", pt.StringType(), True),
        pt.StructField("PreferredStore1", pt.StringType(), True),
        pt.StructField("PreferredStore2", pt.StringType(), True),
        pt.StructField("PreferredStore3", pt.StringType(), True),
        pt.StructField("CustomerGender", pt.StringType(), True),
        pt.StructField("CustomerAge", pt.IntegerType(), True),
        pt.StructField("CustomerSloyaltyHighDescription", pt.StringType(), True),
        pt.StructField("CustomerSloyaltyLowDescription", pt.StringType(), True),
        pt.StructField("CustomerRegion", pt.StringType(), True),
        pt.StructField("CustomerFamilyCustomPanelName", pt.StringType(), True),
        pt.StructField("CustomerLifeStage", pt.StringType(), True),
        pt.StructField("CustomerLifeStageDescription", pt.StringType(), True),
        pt.StructField("CustomerPriceSensitivity", pt.StringType(), True),
        pt.StructField("CustomerPriceSensitivityDescription", pt.StringType(), True),
        pt.StructField("CustomerLifeStyle", pt.StringType(), True),
        pt.StructField("CustomerLifeStyleDescription", pt.StringType(), True),
        pt.StructField("IsBlacklisted", pt.IntegerType(), True),
        pt.StructField("IsMailable", pt.IntegerType(), True),
        pt.StructField("IsScottish", pt.IntegerType(), True),
        pt.StructField("IsBabyCompliant", pt.IntegerType(), True),
        pt.StructField("IsBabyAddrSupress", pt.IntegerType(), True),
        pt.StructField("IsBereaved", pt.IntegerType(), True),
        pt.StructField("IsDiabetic", pt.IntegerType(), True),
        pt.StructField("IsHalal", pt.IntegerType(), True),
        pt.StructField("IsKosher", pt.IntegerType(), True),
        pt.StructField("IsTeetotal", pt.IntegerType(), True),
        pt.StructField("IsAddrSuppress", pt.IntegerType(), True),
        pt.StructField("IsVegetarian", pt.IntegerType(), True),
        pt.StructField("fis_week_id", pt.IntegerType(), True)
    ])
customer_lst = [
    ("Customer1", 0, "SLH1", "SLL1", "Store30", "Store22", "Store30", "UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer2", 0, "SLH2", "SLL2", "Store4", "Store4", "Store1", "Store2", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer3", 0, "SLH2", "SLL2", "Store3", "Store3", "UNKNOWN_DIMENSION","UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer4", 0, "SLH2", "SLL2", "Store27", "Store20", "Store22", "Store30", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer5", 0, "SLH2", "SLL2", "Store20", "Store28", "Store2", "UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer6", 1, "SLH2", "SLL2", "Store24", "Store24", "Store4", "Store23", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer7", 0, "SLH3", "SLL3", "Store8", "Store25", "UNKNOWN_DIMENSION","UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer8", 1, "SLH2", "SLL2", "Store8", "Store7", "Store18", "Store19", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer9", 0, "SLH1", "SLL1", "Store18", "Store18", "Store11", "UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer10", 1, "SLH2", "SLL2", "Store11", "Store11", "Store8", "Store18", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer11", 0, "SLH3", "SLL3", "Store18", "Store18", "Store26", "Store31", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer12", 1, "SLH2", "SLL2", "Store5", "Store5", "Store19", "Store14", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer13", 1, "SLH2", "SLL2", "Store6", "Store20", "Store5", "Store1", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer14", 1, "SLH2", "SLL2", "Store23", "Store23", "Store20", "Store27", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer15", 1, "SLH1", "SLL4", "store12", "store1", "store10", "store11", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer16", 0, "SLH2", "SLL5", "Store24", "Store24", "Store31", "UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer17", 0, "SLH2", "SLL2", "Store11", "Store10", "Store20", "Store12", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer18", 0, "SLH2", "SLL2", "Store2", "Store2", "Store3", "Store4", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer19", 1, "SLH2", "SLL2", "Store31", "Store30", "Store12", "UNKNOWN_DIMENSION", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
    ("Customer20", 1, "SLH1", "SLL1", "Store18", "Store16", "Store17", "Store19", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None),
]

"""
pac_prod_merch_l10_code
"""
pac_subgroup_schema = pt.StructType([
    pt.StructField("affinityclusternum", pt.StringType(), True),
    pt.StructField("subgroup", pt.StringType(), True)
])
pac_subgroup_lst = [
    ("1", "A1A1"),
    ("1", "A1B1"),
    ("1", "B1A1"),
    ("2", "B1B1"),
    ("3", "A2A2"),
    ("4", "A2B2"),
    ("4", "B2B2"),
    ("4", "B2A2"),
]

"""
ci_colombia_media_mart.transactions - 32 rows for each date_id between 2017-12-01 & 2018-01-01
"""
trans_schema = pt.StructType([
    pt.StructField("basket", pt.StringType(), True),
    pt.StructField("datetime", pt.TimestampType(), True),
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("quantity", pt.IntegerType(), True),
    pt.StructField("spendamount", pt.DecimalType(15, 2), True),
    pt.StructField("netspendamount", pt.DecimalType(15, 2), True),
    pt.StructField("discountamount", pt.DecimalType(15, 2), True),
    pt.StructField("fis_year_id", pt.IntegerType(), True),
    pt.StructField("fis_week_id",pt.IntegerType(),True),
    pt.StructField("date_id",pt.DateType(),True),
])
trans_lst = [
('20171129193423499870213247', datetime.datetime(2017, 11, 29, 0, 0), 'Product5', 'Customer20', 'Store16', 'Channel1', 1, Decimal('10.0'), Decimal('0.0'), Decimal('10.0'), 2017, 201740, datetime.date(2017, 11, 29)),
('20171130100591093610012352', datetime.datetime(2017, 11, 30, 0, 0), 'Product28',  None, 'Store8', 'Channel1', 1, Decimal('0.99'), Decimal('0.99'), Decimal('0.0'), 2017, 201740, datetime.date(2017, 11, 30)),
('20171201100950023960194157', datetime.datetime(2017, 12, 1, 0, 0), 'Product24', 'Customer7', 'Store9', 'Channel1', 2, Decimal('3.76'), Decimal('3.0'), Decimal('0.76'), 2017, 201740, datetime.date(2017, 12, 1)),
('20171202084727039160822244', datetime.datetime(2017, 12, 2, 0, 0), 'Product31', 'Customer2', 'Store4', 'Channel1', 1, Decimal('41.99'), Decimal('41.99'), Decimal('0.0'), 2017, 201740, datetime.date(2017, 12, 2)),
('20171203144007026950149675', datetime.datetime(2017, 12, 3, 0, 0), 'Product8', 'Customer4', 'Store27', 'Channel1', 1, Decimal('1.29'), Decimal('1.1'), Decimal('0.19'), 2017, 201740, datetime.date(2017, 12, 3)),
('20171204132046039250829023', datetime.datetime(2017, 12, 4, 0, 0), 'Product30', 'Customer14', 'Store23', 'Channel1', 1, Decimal('47.93'), Decimal('47.93'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 4)),
('20171205172100023100165409', datetime.datetime(2017, 12, 5, 0, 0), 'Product16', 'Customer8', 'Store7', 'Channel1', 1, Decimal('4.0'), Decimal('4.0'), Decimal('0.0'), 2017,201741, datetime.date(2017, 12, 5)),
('20171206151619060560788167', datetime.datetime(2017, 12, 6, 0, 0), 'Product28',  None, 'Store8', 'Channel1', 1, Decimal('0.99'), Decimal('0.99'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 6)),
('20171206151619325325435331', datetime.datetime(2017, 12, 6, 0, 0), 'Product28', 'Customer18', 'Store2', 'Channel1', 1, Decimal('0.99'), Decimal('0.99'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 6)),
('20171207194616042343535787', datetime.datetime(2017, 12, 7, 0, 0), 'Product7', 'Customer20', 'Store16', 'Channel1', 1, Decimal('10.0'), Decimal('10.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 7)),
('20171207194616043570212117', datetime.datetime(2017, 12, 7, 0, 0), 'Product5', 'Customer20', 'Store17', 'Channel1', 1, Decimal('10.0'), Decimal('0.0'), Decimal('10.0'), 2017, 201741, datetime.date(2017, 12, 7)),
('20171208155253052347723957', datetime.datetime(2017, 12, 8, 0, 0), 'Product4', 'Customer5', 'Store28', 'Channel1', 2, Decimal('3.6'), Decimal('3.0'),Decimal('0.6'), 2017, 201741, datetime.date(2017, 12, 8)),
('20171208155253059040314327', datetime.datetime(2017, 12, 8, 0, 0), 'Product12', 'Customer5', 'Store28', 'Channel1', 2, Decimal('3.6'), Decimal('3.0'), Decimal('0.6'), 2017, 201741, datetime.date(2017, 12, 8)),
('20171209193441051090911618', datetime.datetime(2017, 12, 9, 0, 0), 'Product27', None, 'Store25', 'Channel1', 1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
('20171209193441008064406123', datetime.datetime(2017, 12, 9, 0, 0), 'Product27', 'Customer4', 'Store20', 'Channel1', 1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
('20171209193441051090806440', datetime.datetime(2017, 12, 9, 0, 0), 'Product1', 'Customer7', 'Store25', 'Channel1', 1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
('20171209193441008064100806', datetime.datetime(2017, 12, 9, 0, 0), 'Product27', 'Customer11', 'Store18', 'Channel1', 1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
('20171209095798274987398474', datetime.datetime(2017, 12, 9, 0, 0), 'Product11', 'Customer6', 'Store24', 'Channel1', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
('20171210141252063990066053', datetime.datetime(2017, 12, 10, 0, 0), 'Product3', None, 'Store6', 'Channel1', 1, Decimal('0.1'), Decimal('0.1'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 10)),
('20171211183244053040092730', datetime.datetime(2017, 12, 11, 0, 0), 'Product20', None, 'Store21', 'Channel1', 1, Decimal('16.0'), Decimal('16.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 11)),
('20171212211525033110016688', datetime.datetime(2017, 12, 12, 0, 0), 'Product15', 'Customer17', 'Store10', 'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 12)),
('20171212211524643666341111', datetime.datetime(2017, 12, 12, 0, 0), 'Product12', None, 'Store26', 'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 12)),
('20171213054908064401417129', datetime.datetime(2017, 12, 13, 0, 0), 'Product7', 'Customer13', 'Store5', 'Channel2', 2, Decimal('3.2'), Decimal('3.2'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 13)),
('20171214100145021040141377', datetime.datetime(2017, 12, 14, 0, 0), 'Product4', 'Customer9', 'Store18', 'Channel1', 2, Decimal('0.6'), Decimal('0.6'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 14)),
('20171215164554027330745161', datetime.datetime(2017, 12, 15, 0, 0), 'Product6', None, 'Store13', 'Channel1', 1, Decimal('2.7'), Decimal('2.7'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 15)),
('20171216065447030841034847', datetime.datetime(2017, 12, 16, 0, 0), 'Product17', 'Customer10', 'Store11', 'Channel2', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 16)),
('20171216170539020390291592', datetime.datetime(2017, 12, 16, 0, 0), 'Product17', 'Customer15', 'Store11', 'Channel2', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 16)),
('20171217170539020302039029', datetime.datetime(2017, 12, 17, 0, 0), 'Product29', 'Customer10', 'Store11', 'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 17)),
('20171217170539020390291592', datetime.datetime(2017, 12, 17,0, 0), 'Product29', 'Customer15', 'Store1', 'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 17)),
('20171218154137234428937498', datetime.datetime(2017, 12,18, 0, 0), 'Product1', 'Customer16', 'Store24', 'Channel1', 1, Decimal('1.24'), Decimal('1.24'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 18)),
('20171218154137037970823411', datetime.datetime(2017, 12, 18, 0, 0), 'Product1', None, 'Store20', 'Channel1', 1, Decimal('1.24'), Decimal('1.24'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 18)),
('20171219181319979212133431', datetime.datetime(2017, 12, 19, 0, 0), 'Product9', 'Customer14', 'Store23', 'Channel1', 2, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 19)),
('20171219181319021700096809', datetime.datetime(2017, 12, 19, 0, 0), 'Product9', None, 'Store12', 'Channel1', 2, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 19)),
('20171220213338029620756325', datetime.datetime(2017, 12, 20, 0, 0), 'Product18', 'Customer1', 'Store22', 'Channel1', 2, Decimal('2.0'), Decimal('1.33'), Decimal('0.67'), 2017, 201743, datetime.date(2017, 12, 20)),
('20171221213338064864816485', datetime.datetime(2017, 12, 21, 0, 0), 'Product18', 'Customer1', 'Store22', 'Channel1', 2, Decimal('2.0'), Decimal('1.33'), Decimal('0.67'), 2017, 201743, datetime.date(2017, 12, 21)),
('20171221174247064890026667', datetime.datetime(2017, 12, 21, 0, 0), 'Product23', None, 'Store32', 'Channel1', 1, Decimal('0.39'), Decimal('0.39'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 21)),
('20171222214737575304746565', datetime.datetime(2017, 12, 22, 0, 0), 'Product13', 'Customer1', 'Store30', 'Channel1', 2, Decimal('2.0'), Decimal('1.33'), Decimal('0.67'), 2017, 201743, datetime.date(2017, 12, 22)),
('20171222173256020232532303', datetime.datetime(2017, 12, 22, 0, 0), 'Product10', 'Customer18', 'Store2', 'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 22)),
('20171222173256020730588687', datetime.datetime(2017, 12, 22, 0, 0), 'Product4', 'Customer13', 'Store20', 'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 22)),
('20171223173256023532523232', datetime.datetime(2017, 12, 23, 0, 0), 'Product0', 'Customer13', 'Store20', 'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 23)),
('20171222173256234593899311', datetime.datetime(2017, 12, 22, 0, 0), 'Product19', 'Customer12', 'Store5', 'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 22)),
('20171223095737061960142624', datetime.datetime(2017, 12, 23, 0, 0), 'Product11', 'Customer6', 'Store24', 'Channel1', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 23)),
('20171224115651032120238394', datetime.datetime(2017, 12, 24, 0, 0), 'Product22', 'Customer11', 'Store26', 'Channel1', 2, Decimal('1.98'), Decimal('1.98'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 24)),
('20171225210537038850806205', datetime.datetime(2017, 12, 25, 0, 0), 'Product30', None, 'Store29', 'Channel1', 1, Decimal('63.84'), Decimal('63.84'), Decimal('0.0'),2017, 201744, datetime.date(2017, 12, 25)),
('20171226174448062910023178', datetime.datetime(2017, 12, 26, 0, 0), 'Product13', None, 'Store14', 'Channel1', 1, Decimal('2.5'), Decimal('2.5'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 26)),
('20171227123719054340847535', datetime.datetime(2017, 12, 27, 0, 0), 'Product19', 'Customer19', 'Store30', 'Channel1', 1, Decimal('2.3'), Decimal('2.3'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 27)),
('20171228224443056530713473', datetime.datetime(2017, 12, 28, 0, 0), 'Product14', None, 'Store15', 'Channel1', 2, Decimal('1.38'), Decimal('1.38'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 28)),
('20171229121555032201011627', datetime.datetime(2017, 12, 29, 0, 0), 'Product2', 'Customer3', 'Store3', 'Channel1', 1, Decimal('7.0'), Decimal('5.6'), Decimal('1.4'), 2017, 201744, datetime.date(2017, 12, 29)),
('20171229121274759874987987', datetime.datetime(2017, 12, 29, 0, 0), 'Product2', 'Customer18', 'Store3', 'Channel1', 1, Decimal('7.0'), Decimal('5.6'), Decimal('1.4'), 2017, 201744, datetime.date(2017, 12, 29)),
('20171230104316033800147802', datetime.datetime(2017, 12, 30, 0, 0), 'Product21', 'Customer16', 'Store31', 'Channel1', 1, Decimal('2.1'), Decimal('2.1'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
('20171230104274398723235321', datetime.datetime(2017, 12, 30, 0, 0), 'Product21', 'Customer11', 'Store31', 'Channel1', 1, Decimal('2.1'), Decimal('2.1'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
('20171230151553021020019894', datetime.datetime(2017, 12, 30, 0, 0), 'Product26', 'Customer12', 'Store19', 'Channel1', 1, Decimal('9.0'), Decimal('9.0'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
('20171231151274398749837878', datetime.datetime(2017, 12, 31, 0, 0), 'Product26', 'Customer12', 'Store19', 'Channel1', 1, Decimal('9.0'), Decimal('9.0'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 31)),
('20180101134623025441005632', datetime.datetime(2018, 1, 1, 0, 0), 'Product25', None, 'Store17', 'Channel1', 1, Decimal('2.0'), Decimal('2.0'), Decimal('0.0'), 2018, 201745, datetime.date(2018, 1, 1)),
('20180102121555032230251627', datetime.datetime(2018, 1, 2, 0, 0), 'Product2', 'Customer3', 'Store3', 'Channel1',1, Decimal('7.0'), Decimal('5.6'), Decimal('1.4'), 2018, 201745, datetime.date(2018, 1, 2)),
('20180103104736033500123025', datetime.datetime(2018, 1, 3, 0, 0), 'Product21', 'Customer16', 'Store24', 'Channel1', 1, Decimal('2.1'), Decimal('2.1'), Decimal('0.0'), 2018, 201745, datetime.date(2018, 1, 3))
]

"""
purchase_fct
"""
purchases_schema = pt.StructType([
    pt.StructField("Basket", pt.StringType(), True),
    pt.StructField("Division", pt.StringType(), True),
    pt.StructField("Department", pt.StringType(), True),
    pt.StructField("Section", pt.StringType(), True),
    pt.StructField("Group", pt.StringType(), True),
    pt.StructField("PacSubgroup", pt.StringType(), True),
    pt.StructField("Subgroup", pt.StringType(), True),
    pt.StructField("Product", pt.StringType(), True),
    pt.StructField("Customer", pt.StringType(), True),
    pt.StructField("Store", pt.StringType(), True),
    pt.StructField("Banner", pt.StringType(), True),
    pt.StructField("FulfillmentStore", pt.StringType(), True),
    pt.StructField("PreferredStore1", pt.StringType(), True),
    pt.StructField("PreferredStore2", pt.StringType(), True),
    pt.StructField("PreferredStore3", pt.StringType(), True),
    pt.StructField("Channel", pt.StringType(), True),
    pt.StructField("Quantity", pt.DecimalType(24, 2), True),
    pt.StructField("NetSpendAmount", pt.DecimalType(38, 2), True),
    pt.StructField("SpendAmount", pt.DecimalType(38, 2), True),
    pt.StructField("DiscountAmount", pt.DecimalType(38, 2), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("date_id", pt.DateType(), True),
])
purchases_lst = [
    # Week - 201741
    ("20171204132046039250829023", "C", None, "C1", "C1B", None,"C1B2", "Product30", "Customer14", "Store23", None, "Store23", "Store23",
     "Store20", "Store27", "Channel1", Decimal("1.00"), Decimal("47.93"), Decimal("47.93"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 4)),
    ("20171205172100023100165409", "B", None, "B2", "B2B",  None,"B2B1", "Product16", "Customer8", "Store7", None, "Store8", "Store7",
     "Store18", "Store19", "Channel1", Decimal("1.00"), Decimal("4.00"), Decimal("4.00"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 5)),
    ("20171206151619325325435331", "C", None, "C2", "C2A",  None,"C2A1", "Product28", "Customer18", "Store2", None, "Store2", "Store2",
     "Store3", "Store4", "Channel1", Decimal("1.00"), Decimal("0.99"), Decimal("0.99"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 6)),
    ("20171206151619060560788167", "C", None, "C2", "C2A",  None,"C2A1", "Product28", None, "Store8", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("0.99"), Decimal("0.99"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 6)),
    ("20171207194616042343535787", "B", None, "B1", "B1B",  2,"B1B1", "Product7", "Customer20", "Store16", None, "Store18", "Store16",
     "Store17", "Store19", "Channel1", Decimal("1.00"), Decimal("10.00"), Decimal("10.00"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 7)),
    ("20171208155253059040314327", "D", None, "D2", "D2B",  None,"D2B1", "Product12", "Customer5", "Store28", None, "Store20", "Store28",
     "Store2", "UNKNOWN_DIMENSION", "Channel1", Decimal("2.00"), Decimal("3.00"), Decimal("3.60"), Decimal("0.60"),
     "201741", datetime.date(2017, 12, 8)),
    ("20171208155253052347723957", "A", None, "A1", "A1B",  1,"A1B1", "Product4", "Customer5", "Store28", None, "Store20", "Store28",
     "Store2", "UNKNOWN_DIMENSION", "Channel1", Decimal("2.00"), Decimal("3.00"), Decimal("3.60"), Decimal("0.60"),
     "201741", datetime.date(2017, 12, 8)),
    ("20171209193441008064406123", "C", None, "C2", "C2B",  None,"C2B1", "Product27", "Customer4", "Store20", None, "Store27", "Store20",
     "Store22", "Store30", "Channel1", Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 9)),
    ("20171209095798274987398474", "D", None, "D2", "D2A",  None,"D2A1", "Product11", "Customer6", "Store24", None, "Store24", "Store24",
     "Store4", "Store23", "Channel1", Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 9)),
    ("20171209193441051090806440", "A", None, "A1", "A1A",  1,"A1A1", "Product1", "Customer7", "Store25", None, "Store8", "Store25",
     "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "Channel1", Decimal("1.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("0.00"), "201741", datetime.date(2017, 12, 9)),
    ("20171209193441008064100806", "C", None, "C2", "C2B",  None,"C2B1", "Product27", "Customer11", "Store18", None, "Store18", "Store18",
     "Store26", "Store31", "Channel1", Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 9)),
    ("20171209193441051090911618", "C", None, "C2", "C2B",  None,"C2B1", "Product27", None, "Store25", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 9)),
    ("20171210141252063990066053", "C", None, "C1", "C1A",  None,"C1A1", "Product3", None, "Store6", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("0.10"), Decimal("0.10"), Decimal("0.00"), "201741",
     datetime.date(2017, 12, 10)),
    # Week - 201742
    ("20171211183244053040092730", "B", None, "B1", "B1A",  1,"B1A1", "Product20", None, "Store21", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("16.00"), Decimal("16.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 11)),
    ("20171212211524643666341111", "D", None, "D2", "D2B",  None,"D2B1", "Product12", None, "Store26", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 12)),
    ("20171212211525033110016688", "B", None, "B2", "B2A",  None,"B2A1", "Product15", "Customer17", "Store10", None, "Store11", "Store10",
     "Store20", "Store12", "Channel1", Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 12)),
    ("20171213054908064401417129", "B", None, "B1", "B1B",  2,"B1B1", "Product7", "Customer13", "Store5", None, "Store6", "Store20",
     "Store5", "Store1", "Channel2", Decimal("2.00"), Decimal("3.20"), Decimal("3.20"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 13)),
    ("20171214100145021040141377", "A", None, "A1", "A1B",  1,"A1B1", "Product4", "Customer9", "Store18", None, "Store18", "Store18",
     "Store11", "UNKNOWN_DIMENSION", "Channel1", Decimal("2.00"), Decimal("0.60"), Decimal("0.60"), Decimal("0.00"),
     "201742", datetime.date(2017, 12, 14)),
    ("20171215164554027330745161", "C", None, "C1", "C1A",  None,"C1A2", "Product6", None, "Store13", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("2.70"), Decimal("2.70"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 15)),
    ("20171216065447030841034847", "D", None, "D1", "D1B",  None,"D1B2", "Product17", "Customer10", "Store11", None, "Store11", "Store11",
     "Store8", "Store18", "Channel2", Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 16)),
    ("20171216170539020390291592", "D", None, "D1", "D1B",  None,"D1B2", "Product17", "Customer15", "Store11", None, "store12", "store1",
     "store10", "store11", "Channel2", Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 16)),
    ("20171217170539020390291592", "B", None, "B1", "B1B",  None,"B1B2", "Product29", "Customer15", "Store1", None, "store12", "store1",
     "store10", "store11", "Channel1", Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 17)),
    ("20171217170539020302039029", "B", None, "B1", "B1B",  None,"B1B2", "Product29", "Customer10", "Store11", None, "Store11", "Store11",
     "Store8", "Store18", "Channel1", Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("0.00"), "201742",
     datetime.date(2017, 12, 17)),
    # Week - 201743
    ("20171218154137234428937498", "A", None, "A1", "A1A",  1,"A1A1", "Product1", "Customer16", "Store24", None, "Store24", "Store24",
     "Store31", "UNKNOWN_DIMENSION", "Channel1", Decimal("1.00"), Decimal("1.24"), Decimal("1.24"), Decimal("0.00"),
     "201743", datetime.date(2017, 12, 18)),
    ("20171218154137037970823411", "A", None, "A1", "A1A",  1,"A1A1", "Product1", None, "Store20", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("1.24"), Decimal("1.24"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 18)),
    ("20171219181319021700096809", "D", None, "D1", "D1B",  None,"D1B1", "Product9", None, "Store12", None, None, None, None, None,
     "Channel1", Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 19)),
    ("20171219181319979212133431", "D", None, "D1", "D1B",  None,"D1B1", "Product9", "Customer14", "Store23", None, "Store23", "Store23",
     "Store20", "Store27", "Channel1", Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 19)),
    ("20171220213338029620756325", "A", None, "A2", "A2B",  None,"A2B1", "Product18", "Customer1", "Store22", None, "Store30", "Store22",
     "Store30", "UNKNOWN_DIMENSION", "Channel1", Decimal("2.00"), Decimal("1.33"), Decimal("2.00"), Decimal("0.67"),
     "201743", datetime.date(2017, 12, 20)),
    ("20171221174247064890026667", "A", None, "A2", "A2A",  3,"A2A2", "Product23", None, "Store32", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("0.39"), Decimal("0.39"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 21)),
    ("20171221213338064864816485", "A", None, "A2", "A2B",  None,"A2B1", "Product18", "Customer1", "Store22", None, "Store30", "Store22",
     "Store30", "UNKNOWN_DIMENSION", "Channel1", Decimal("2.00"), Decimal("1.33"), Decimal("2.00"), Decimal("0.67"),
     "201743", datetime.date(2017, 12, 21)),
    ("20171222173256020730588687", "A", None, "A1", "A1B",  1,"A1B1", "Product4", "Customer13", "Store20", None, "Store6", "Store20",
     "Store5", "Store1", "Channel1", Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 22)),
    ("20171222173256020232532303", "D", None, "D1", "D1A",  None,"D1A2", "Product10", "Customer18", "Store2", None, "Store2", "Store2",
     "Store3", "Store4", "Channel1", Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 22)),
    ("20171222214737575304746565", "D", None, "D2", "D2A",  None,"D2A1", "Product13", "Customer1", "Store30", None, "Store30", "Store22",
     "Store30", "UNKNOWN_DIMENSION", "Channel1", Decimal("2.00"), Decimal("1.33"), Decimal("2.00"), Decimal("0.67"),
     "201743", datetime.date(2017, 12, 22)),
    ("20171222173256234593899311", "D", None, "D2", "D2B",  None,"D2B2", "Product19", "Customer12", "Store5", None, "Store5", "Store5",
     "Store19", "Store14", "Channel1", Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 22)),
    ("20171223095737061960142624", "D", None, "D2", "D2A",  None,"D2A1", "Product11", "Customer6", "Store24", None, "Store24", "Store24",
     "Store4", "Store23", "Channel1", Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 23)),
    ("20171223173256023532523232", "UNKNOWN_DIMENSION", None, "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", None, "UNKNOWN_DIMENSION", "Product0", "Customer13", "Store20", None, "Store6", "Store20", "Store5",
     "Store1", "Channel1", Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 23)),
    ("20171224115651032120238394", "A", None, "A1", "A1B",  1,"A1B1", "Product22", "Customer11", "Store26", None, "Store18", "Store18",
     "Store26", "Store31", "Channel1", Decimal("2.00"), Decimal("1.98"), Decimal("1.98"), Decimal("0.00"), "201743",
     datetime.date(2017, 12, 24)),
    # Week - 201744
    ("20171225210537038850806205", "C", None, "C1", "C1B",  None,"C1B2", "Product30", None, "Store29", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("63.84"), Decimal("63.84"), Decimal("0.00"), "201744",
     datetime.date(2017, 12, 25)),
    ("20171226174448062910023178", "D", None, "D2", "D2A",  None,"D2A1", "Product13", None, "Store14", None, None, None, None, None,
     "Channel1", Decimal("1.00"), Decimal("2.50"), Decimal("2.50"), Decimal("0.00"), "201744",
     datetime.date(2017, 12, 26)),
    ("20171227123719054340847535", "D", None, "D2", "D2B",  None,"D2B2", "Product19", "Customer19", "Store30", None, "Store31", "Store30",
     "Store12", "UNKNOWN_DIMENSION", "Channel1", Decimal("1.00"), Decimal("2.30"), Decimal("2.30"), Decimal("0.00"),
     "201744", datetime.date(2017, 12, 27)),
    ("20171228224443056530713473", "A", None, "A2", "A2A",  None,"A2A1", "Product14", None, "Store15", None, None, None, None, None,
     "Channel1", Decimal("2.00"), Decimal("1.38"), Decimal("1.38"), Decimal("0.00"), "201744",
     datetime.date(2017, 12, 28)),
    ("20171229121555032201011627", "B", None, "B1", "B1A",  1,"B1A1", "Product2", "Customer3", "Store3", None, "Store3", "Store3",
     "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "Channel1", Decimal("1.00"), Decimal("5.60"), Decimal("7.00"),
     Decimal("1.40"), "201744", datetime.date(2017, 12, 29)),
    ("20171229121274759874987987", "B", None, "B1", "B1A",  1,"B1A1", "Product2", "Customer18", "Store3", None, "Store2", "Store2",
     "Store3", "Store4", "Channel1", Decimal("1.00"), Decimal("5.60"), Decimal("7.00"), Decimal("1.40"), "201744",
     datetime.date(2017, 12, 29)),
    ("20171230104316033800147802", "A", None, "A1", "A1A",  1,"A1A1", "Product21", "Customer16", "Store31", None, "Store24", "Store24",
     "Store31", "UNKNOWN_DIMENSION", "Channel1", Decimal("1.00"), Decimal("2.10"), Decimal("2.10"), Decimal("0.00"),
     "201744", datetime.date(2017, 12, 30)),
    ("20171230151553021020019894", "C", None, "C2", "C2A",  None,"C2A1", "Product26", "Customer12", "Store19", None, "Store5", "Store5",
     "Store19", "Store14", "Channel1", Decimal("1.00"), Decimal("9.00"), Decimal("9.00"), Decimal("0.00"), "201744",
     datetime.date(2017, 12, 30)),
    ("20171230104274398723235321", "A", None, "A1", "A1A",  1,"A1A1", "Product21", "Customer11", "Store31", None, "Store18", "Store18",
     "Store26", "Store31", "Channel1", Decimal("1.00"), Decimal("2.10"), Decimal("2.10"), Decimal("0.00"), "201744",
     datetime.date(2017, 12, 30)),
    ("20171203144007026950149675", "D", None, "D1", "D1A",  None,"D1A1", "Product8", "Customer4", "Store27", None, "Store27", "Store20",
     "Store22", "Store30", "Channel1", Decimal("1.00"), Decimal("1.10"), Decimal("1.29"), Decimal("0.19"), "201740",
     datetime.date(2017, 12, 3))
]

"""
Stores data
"""

stores_schema = pt.StructType([
    pt.StructField("Store", pt.StringType(), True),
    pt.StructField("Banner", pt.StringType(), True),
    pt.StructField("StoreDescription", pt.StringType(), True),
    pt.StructField("BannerDescription", pt.StringType(), True),
    pt.StructField("StoreFormat", pt.StringType(), True),
    pt.StructField("StoreRegion", pt.StringType(), True),
    pt.StructField("StoreDivision", pt.StringType(), True),
])
stores_lst = [
('Store16', None, None, None, None, None, None)
]

