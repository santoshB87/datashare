import os

os.environ['MM_DATABASE'] = 'ci_colombia_media_mart'