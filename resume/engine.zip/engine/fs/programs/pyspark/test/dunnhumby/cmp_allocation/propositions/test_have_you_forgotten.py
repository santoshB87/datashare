import unittest
from os import path
"""
 uncomment below lines when running on VM,csv related testcases
"""
# from os import environ, path, listdir
# SUBMIT_ARGS = "--jars /opt/project/lib/spark-csv_2.10-1.4.0.jar," \
#               "/opt/project/lib/commons-csv-1.4.jar pyspark-shell"
# environ["PYSPARK_SUBMIT_ARGS"] = SUBMIT_ARGS
# from pyspark import SparkConf
# # inject a local spark context into our contexts module
# conf = SparkConf().setMaster('local').setAppName('test_spark_tools')\
#     .set('spark.sql.shuffle.partitions', 1)
# contexts.sc(conf)

from pyspark.sql.types import StructField, StructType, StringType, IntegerType, DateType
from ci_colombia.cmp_allocation.propositions import have_you_forgotten_rte
from dunnhumby import contexts
import tempfile
import mock




class TesHaveYouForgotten(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.sc = contexts.sc()
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")


    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(dir=path.expanduser('~'))
        config_file = '/CMP/engine/fs/programs/pyspark/test/dunnhumby/cmp_allocation/propositions/test_configs/HYF_config.json'
        self.hyf = have_you_forgotten_rte.HYFAllocation(config_file, 'have_you_forgotten_rte', '1')
        self.sqlContext.sql('create database if not exists client_pob')
        self.sqlContext.sql('drop table if exists client_pob.hyf_standard_latest')
        self.sqlContext.sql('create database if not exists client_ssewh')
        self.sqlContext.sql('drop table if exists client_ssewh.card_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.store_dim_h')
        self.sqlContext.sql('drop table if exists client_ssewh.prsn_loyalty_seg')
        self.sqlContext.sql('drop table if exists client_ssewh.seg_value_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.prsn_pref_seg')
        self.sqlContext.sql('create database if not exists client_sseft')
        self.sqlContext.sql('drop table if exists client_ssewh.promo_item_fct')
        self.sqlContext.sql('drop table if exists client_ssewh.store_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.promo_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.plan_promo_item_fct')
        self.sqlContext.sql('drop table if exists client_ssewh.prod_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.offer_tier_dtl_c')
        self.sqlContext.sql('drop table if exists client_ssewh.offer_rl_grp_dtl_c')
        self.sqlContext.sql('drop table if exists client_ssewh.date_dim')
        self.sqlContext.sql('drop table if exists client_ssewh.offer_dim_c')
        self.sqlContext.sql('drop table if exists client_sseft.v_Pr0Cafw_current')
        self.sqlContext.sql('drop table if exists client_pob.v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_current')


    def tearDown(self):
        pass

    @mock.patch('dunnhumby.cmp_allocation.spark_tools.write_csv_to_nfs', return_value=None)
    @mock.patch('dunnhumby.cmp_allocation.propositions.have_you_forgotten.HYFAllocation.send_notification_mail',
                return_value=None)
    def test_hyf_allocates(self, mock_wctn, mock_snm):
        """
        This test ensure the working of channels entity class if data exist in underlying tables.
        :return:
        """
        self.hyf_standard_latest_schema = StructType([StructField("customer", StringType(), True),
                                                     StructField("product", StringType(), True),
                                                     StructField("productsubgroup", StringType(), True),
                                                     StructField("productgroup", StringType(), True),
                                                     StructField("score", StringType(), True), ])
        self.card_dim_c_schema = StructType([StructField("card_id", IntegerType(), True),StructField("prsn_id", IntegerType(), True),
                                             StructField("prsn_code", StringType(), True),
                                             StructField("prsn_email_suppress_flag", StringType(),
                                                         True),
                                             StructField("modified_dttm", StringType(), True)])
        self.hshd_loyalty_seg = StructType(
            [StructField("prsn_seg_loyalty_high_id", IntegerType(), True),
             StructField("prsn_seg_loyalty_low_id", IntegerType(), True),
             StructField("prsn_id", IntegerType(), True),
             StructField("modified_dttm", StringType(), True)
             ])
        self.store_schema = StructType([StructField('store_id', StringType(), True),
                                        StructField('converted_store_id', StringType(), True),
                             StructField('store_name', StringType(), True),
                             StructField('banner_code', StringType(), True),
                             StructField('banner_name', StringType(), True),
                             StructField('store_mgmt_l20_code', StringType(), True)])
        test_data = [('1','412127500000118', 'BODEGUITA STMAX CAMPANELA', 'S', 'SURTIMAX', '01')]
        self.sqlContext.createDataFrame(test_data, self.store_schema).saveAsTable(
            'client_ssewh.store_dim_c')
        self.seg_value_dim_c = StructType(
            [StructField("seg_type_code", IntegerType(), True),
             StructField("seg_value_id", IntegerType(), True),
             StructField("seg_value_code", IntegerType(), True)
             ])
        self.hshd_pref_seg = StructType(
            [StructField("prsn_id", IntegerType(), True),
             StructField("prsn_seg_pref_store_1_id", IntegerType(), True),
             StructField("prsn_seg_pref_store_2_id", IntegerType(), True),
             StructField("prsn_seg_pref_store_3_id", IntegerType(), True)
             ])
        test_data = [('10000004',	'64368861',	'F51C',	'F51CA',	'1.0483452648675138'),
                     ('10000141',	'56068638',	'F51C',	'F51CO',	'0.44580286701018645'),
                        ('10000344',	'54905437',	'G78B',	'G78BD',	'0.091705406220999999'),
                        ('1000051',	    '77474830',	'F15I',	'F15IF',	'3.6304749761417092'),
                        ('10000805',	'64919596',	'F11B',	'F11BA',	'0.36415085027125593'),
                       ('10000805',	'77556371',	'B45A',	'B45AI',	'0.10265886426134635'),
                        ('10000818',	'54820312',	'B31A',	'B31AM',	'0'),
                        ('10000818',	'64196401',	'N35G',	'N35GP',	'0.12858919380700001'),
                        ('10000818',	'79868816',	'H33J',	'H33JE',	'0.066256653499999998'),
                        ('10000818',	'80843073',	'B61A',	'B61AD',	'0.92670469744557304')]
        test_data_cust = [(1,10000004,'10000004','N', '2016-07-11 08:23:27.0'),
                          (2,10000004,'10000004','N', '2016-07-11 08:23:27.0'),
                          (3,10000344,'10000344','N', '2016-07-11 08:23:27.0'),
                          (4,1000051,'1000051','N', '2016-07-11 08:23:27.0'),
                          (5,10000805,'10000805','N', '2016-07-11 08:23:27.0'),(6,10000818,'10000818','N', '2016-07-11 08:23:27.0')]

        self.sqlContext.createDataFrame(test_data, self.hyf_standard_latest_schema).saveAsTable(
            'client_pob.hyf_standard_latest')
        self.sqlContext.createDataFrame(test_data_cust, self.card_dim_c_schema).saveAsTable(
            'client_ssewh.card_dim_c')
        self.sqlContext.createDataFrame([],self.hshd_loyalty_seg).saveAsTable(
            'client_ssewh.prsn_loyalty_seg')

        self.sqlContext.createDataFrame([], self.seg_value_dim_c).saveAsTable(
            'client_ssewh.seg_value_dim_c')
        self.sqlContext.createDataFrame([],self.hshd_pref_seg).saveAsTable(
            'client_ssewh.prsn_pref_seg')

        schema = StructType([StructField('prod_alt_code', StringType(), True),
                             StructField('prod_desc', StringType(), True),
                             StructField('prod_comml_l10_code', StringType(),
                                         True),
                             StructField('prod_comml_l10_desc', StringType(),
                                         True),
                             StructField('prod_comml_l20_code', StringType(),
                                         True),
                             StructField('prod_comml_l20_desc', StringType(),
                                         True),
                             StructField('prod_comml_l21_code', StringType(),
                                         True),
                             StructField('prod_comml_l21_desc', StringType(),
                                         True),
                             StructField('prod_comml_l22_code', StringType(),
                                         True),
                             StructField('prod_comml_l22_desc', StringType(),
                                         True),
                             StructField('prod_comml_l30_code', StringType(),
                                         True),
                             StructField('prod_comml_l30_desc', StringType(),
                                         True),
                             StructField("modified_dttm", StringType(), True),
                             StructField('brand_name', StringType(), True)])
        l = [(
            '77556371', 'CAMISETA MS BASICA FE A', '01230014120140050109',
            'CAMISETA MS MUJER',
            '01412014005010009', 'CAMISETA MUJER', '014005010009',
            'MUJER EXTER JOVEN Y UNIVERSITA',
            '005010009', 'EXTERIOR FEMENINA', '010', 'MERCANCIA',
            '2016-07-11 08:23:27.0', 'TESCO')]

        #schema = StructType([StructField("prod_id", IntegerType(), True),StructField("prod_group_code", StringType(), True),StructField("prod_alt_code", StringType(), True)])
        #l = [(64368861, '64368861','64368861'), (56068638, '56068638','64368861'),(54905437, '54905437','64368861'), (64919596, '64919596','64368861'),(64368861, '64368861','64368861')]
        self.sqlContext.createDataFrame(l, schema).saveAsTable(
            'client_ssewh.prod_dim_c')

        schema = StructType(
            [StructField("customer", StringType(), True),
             StructField("product", StringType(), True),
             StructField("channelall_customercustomer_productsubgroup_storeall_baskets_1w4w", IntegerType(), True)
             ])
        l = [('1', '4',2)]
        self.sqlContext.createDataFrame(l, schema).saveAsTable(
            'client_pob.v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_current')
        file_path = path.join(self.temp_dir, 'df_text')

        hdfs_path='file://{0}'.format(file_path)
        self.assertIsNone(self.hyf.allocate(hdfs_path), 'Success')

