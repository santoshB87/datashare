import unittest
from os import path

from dunnhumby import contexts

"""
 uncomment below lines when running on VM, csv related testcases
"""
# from os import environ, path, listdir
# SUBMIT_ARGS = "--jars /opt/project/lib/spark-csv_2.10-1.4.0.jar," \
#               "/opt/project/lib/commons-csv-1.4.jar pyspark-shell"
# environ["PYSPARK_SUBMIT_ARGS"] = SUBMIT_ARGS
# from pyspark import SparkConf
# # inject a local spark context into our contexts module
# conf = SparkConf().setMaster('local').setAppName('test_spark_tools')\
#     .set('spark.sql.shuffle.partitions', 1)
# contexts.sc(conf)

from pyspark.sql.types import StructField, StructType, StringType, IntegerType, DateType
from dunnhumby.cmp_allocation.propositions import relevant_promotions
from datetime import datetime
import tempfile
import mock
import sys
sys.path.append(['/CMP/engine/fs/programs/pyspark/test/dunnhumby'
                '/cmp_allocation/lib/commons-csv-1.4.jar','/CMP/engine/fs/programs/pyspark/test/dunnhumby'
                '/cmp_allocation/lib/spark-csv_2.10-1.4.0.jar'])

class TestRelevantPromotions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sc = contexts.sc()
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(dir=path.expanduser('~'))
        config_file = '/CMP/engine/fs/programs/pyspark/test/dunnhumby/cmp_allocation/propositions' \
                      '/test_configs/RP_config.json'
        self.rp = relevant_promotions.RPAllocation(config_file, 'relevant_promotions_rte', '2')
        self.sqlContext.sql('create database if not exists client_ssewh')
        self.sqlContext.sql('drop table if exists client_ssewh.card_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.store_dim_h')
        self.sqlContext.sql('drop table if exists client_ssewh.hshd_loyalty_seg')
        self.sqlContext.sql('drop table if exists client_ssewh.seg_value_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.hshd_pref_seg')
        self.sqlContext.sql('drop table if exists client_ssewh.store_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.prod_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.prod_dim_h')
        self.sqlContext.sql('drop table if exists client_ssewh.date_dim')
        self.sqlContext.sql('drop table if exists client_ssewh.promo_lookup')

        self.sqlContext.sql('create database if not exists client_pob')
        self.sqlContext.sql('drop table if exists client_pob.rp_standard_latest')
        self.sqlContext.sql(
            'drop table if exists client_pob.v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_current')

    def tearDown(self):
        self.sqlContext.sql('drop table if exists client_ssewh.card_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.store_dim_h')
        self.sqlContext.sql('drop table if exists client_ssewh.hshd_loyalty_seg')
        self.sqlContext.sql('drop table if exists client_ssewh.seg_value_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.hshd_pref_seg')
        self.sqlContext.sql('drop table if exists client_ssewh.store_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.prod_dim_c')
        self.sqlContext.sql('drop table if exists client_ssewh.prod_dim_h')
        self.sqlContext.sql('drop table if exists client_ssewh.date_dim')
        self.sqlContext.sql('drop table if exists client_ssewh.promo_lookup')

        self.sqlContext.sql('drop table if exists client_pob.rp_standard_latest')
        self.sqlContext.sql(
            'drop table if exists client_pob.v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_current')

    @mock.patch('dunnhumby.cmp_allocation.spark_tools.write_csv_to_hdfs', return_value=None)
    def test_rp_allocation_throws_error_when_nothing_to_allocate(self, mock_wch):
        self.rp_standard_latest_schema = StructType(
            [StructField("customer", StringType(), True), StructField("product", StringType(), True),
             StructField("productsubgroup", StringType(), True), StructField("productgroup", StringType(), True),
             StructField("score", StringType(), True), ])
        self.cust_schema = StructType(
            [StructField("hshd_id", StringType(), True), StructField("hshd_code", StringType(), True)])
        self.hshd_loyalty_seg = StructType([StructField("hshd_seg_loyalty_high_id", IntegerType(), True),
                                            StructField("hshd_seg_loyalty_low_id", IntegerType(), True),
                                            StructField("hshd_id", IntegerType(), True)])
        self.store_schema = StructType(
            [StructField("store_id", IntegerType(), True), StructField(
                "store_code", StringType(), True),StructField("store_name", IntegerType(), True)])
        self.seg_value_dim_c = StructType(
            [StructField("seg_type_code", IntegerType(), True), StructField("seg_value_id", IntegerType(), True),
             StructField("seg_value_code", IntegerType(), True)])
        self.hshd_pref_seg = StructType(
            [StructField("hshd_id", IntegerType(), True), StructField("hshd_seg_pref_store_1_id", IntegerType(), True),
             StructField("hshd_seg_pref_store_2_id", IntegerType(), True),
             StructField("hshd_seg_pref_store_3_id", IntegerType(), True)])

        schema = StructType(
            [StructField("promo_group_code", StringType(), True), StructField("promo_item_id", IntegerType(), True),
             StructField("store_code", IntegerType(), True), StructField("offer_type_code", StringType(), True),
             StructField("promo_start_date", StringType(), True), StructField("promo_end_date", StringType(), True),
             StructField("promo_desc", StringType(), True)])
        l = [('1', 64368861, 1234, 'SOM', '20171218', '20190301', 'NudgeNudgeWinkWink')]
        self.sqlContext.createDataFrame(l, schema).saveAsTable('client_ssewh.promo_lookup')

        test_data = [('10000004', '64368861', 'F51C', 'F51CA', '1.0483452648675138'),
                     ('10000141', '56068638', 'F51C', 'F51CO', '0.44580286701018645'),
                     ('10000344', '54905437', 'G78B', 'G78BD', '0.091705406220999999'),
                     ('1000051', '77474830', 'F15I', 'F15IF', '3.6304749761417092'),
                     ('10000805', '64919596', 'F11B', 'F11BA', '0.36415085027125593'),
                     ('10000805', '77556371', 'B45A', 'B45AI', '0.10265886426134635'),
                     ('10000818', '54820312', 'B31A', 'B31AM', '0'),
                     ('10000818', '64196401', 'N35G', 'N35GP', '0.12858919380700001'),
                     ('10000818', '79868816', 'H33J', 'H33JE', '0.066256653499999998'),
                     ('10000818', '80843073', 'B61A', 'B61AD', '0.92670469744557304')]
        test_data_cust = [('10000004', '10000004'), ('10000004', '10000004'), ('10000344', '10000344'),
                          ('1000051', '1000051'), ('10000805', '10000805'), ('10000818', '10000818')]

        self.sqlContext.createDataFrame(test_data, self.rp_standard_latest_schema).saveAsTable(
            'client_pob.rp_standard_latest')
        self.sqlContext.createDataFrame(test_data_cust, self.cust_schema).saveAsTable('client_ssewh.card_dim_c')
        self.sqlContext.createDataFrame([], self.hshd_loyalty_seg).saveAsTable('client_ssewh.hshd_loyalty_seg')
        self.sqlContext.createDataFrame([], self.store_schema).saveAsTable('client_ssewh.store_dim_h')
        self.sqlContext.createDataFrame([], self.seg_value_dim_c).saveAsTable('client_ssewh.seg_value_dim_c')
        self.sqlContext.createDataFrame([], self.hshd_pref_seg).saveAsTable('client_ssewh.hshd_pref_seg')

        schema = StructType(
            [StructField("store_id", IntegerType(), True), StructField(
                "store_code", StringType(), True),StructField("store_name", StringType(), True)])
        l = [(1, 1234,123)]
        self.sqlContext.createDataFrame(l, schema).saveAsTable('client_ssewh.store_dim_c')

        schema = StructType(
            [StructField("prod_id", IntegerType(), True), StructField("prod_group_code", StringType(), True)])
        l = [(64368861, '64368861'), (56068638, '56068638'), (54905437, '54905437'), (64919596, '64919596'),
             (64368861, '64368861')]
        self.sqlContext.createDataFrame(l, schema).saveAsTable('client_ssewh.prod_dim_c')


        schema = StructType([StructField('prod_group_code', StringType(), True),
                             StructField('prod_group_desc', StringType(), True),
                             StructField('prod_comml_l10_code', StringType(),
                                         True),
                             StructField('prod_comml_l10_desc', StringType(),
                                         True),
                             StructField('prod_comml_l20_code', StringType(),
                                         True),
                             StructField('prod_comml_l20_desc', StringType(),
                                         True),
                             StructField('prod_comml_l21_code', StringType(),
                                         True),
                             StructField('prod_comml_l21_desc', StringType(),
                                         True),
                             StructField('prod_comml_l22_code', StringType(),
                                         True),
                             StructField('prod_comml_l22_desc', StringType(),
                                         True),
                             StructField('prod_comml_l30_code', StringType(),
                                         True),
                             StructField('prod_comml_l30_desc', StringType(),
                                         True),
                             StructField('modified_dttm', StringType(),
                                         True),
                             StructField('brand_name', StringType(), True)])
        l = [(
            '548171', 'CAMISETA MS BASICA FE A', '01230014120140050109',
            'CAMISETA MS MUJER',
            '01412014005010009', 'CAMISETA MUJER', '014005010009',
            'MUJER EXTER JOVEN Y UNIVERSITA',
            '005010009', 'EXTERIOR FEMENINA', '010', 'MERCANCIA', '2014-05-28 06:34:55.0','TESCO')]
        self.sqlContext.createDataFrame(l, schema).saveAsTable(
            'client_ssewh.prod_dim_h')

        schema = StructType(
            [StructField("date_short_name", StringType(), True), StructField("fis_week_end_date", DateType(), True)])
        d = datetime.now()
        m = '-'.join(str(x) for x in (d.year, d.month, d.day))
        l = [(m, (datetime.strptime('2017-07-24 00:00:00', '%Y-%m-%d %H:%M:%S')))]
        self.sqlContext.createDataFrame(l, schema).saveAsTable('client_ssewh.date_dim')

        schema = StructType([StructField("customer", StringType(), True), StructField("product", StringType(), True),
                             StructField("channelall_customercustomer_productsubgroup_storeall_baskets_1w4w",
                                         IntegerType(), True)])
        l = [('1', '4', 2)]
        self.sqlContext.createDataFrame(l, schema).saveAsTable(
            'client_pob.v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_current')
        file_path = path.join(self.temp_dir, 'df_text')

        hdfs_path = 'file://{0}'.format(file_path)
        self.assertRaises(SystemExit, self.rp.allocate, hdfs_path)
