import unittest
import mock
import dunnhumby.cmp_allocation.file_system as fs


class FileSystemTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_client_err(self):
        self.assertRaises(RuntimeError, fs.get_client, 'hdfs')

    # If we have hadoop fs available on our testing env (docker, ci/cd etc.),
    # then please remove below mock implementation
    @mock.patch('subprocess.Popen')
    def test_get_client(self, mock_subproc_popen):
        process_mock = mock.Mock()
        args = {'communicate.return_value': ('output', 'error')}
        process_mock.configure_mock(**args)
        type(process_mock).returncode = mock.PropertyMock(return_value=0)
        mock_subproc_popen.return_value = process_mock
        self.assertIsInstance(fs.get_client('dummy'), fs.DummyClient)
        self.assertRaises(NotImplementedError, fs.get_client, 'fs')
        self.assertIsInstance(fs.get_client('hdfs'), fs.HDFSClient)

    def test_DummyClient(self):
        dummy = fs.DummyClient()
        path = '/dummypath'
        self.assertTrue(dummy.file_exists(path))
        self.assertTrue(dummy.create_file(path))
        self.assertTrue(dummy.delete_file(path, True))
        self.assertTrue(dummy.directory_exists(path))
        self.assertTrue(dummy.create_directory(path, True))
        self.assertTrue(dummy.delete_directory(path, True, True))

    @mock.patch('subprocess.Popen')
    def test_HDFSClient(self, mock_subproc_popen):
        process_mock = mock.Mock()
        args = {'communicate.return_value': ('output', 'error')}
        process_mock.configure_mock(**args)
        type(process_mock).returncode = mock.PropertyMock(return_value=0)
        mock_subproc_popen.return_value = process_mock
        hdfs_client = fs.HDFSClient()
        path = '/dummypath'
        self.assertTrue(hdfs_client.file_exists(path))
        self.assertTrue(hdfs_client.file_exists(path))
        self.assertTrue(hdfs_client.file_exists(path))
        self.assertTrue(hdfs_client.create_file(path))
        self.assertTrue(hdfs_client.delete_file(path, False))
        self.assertTrue(hdfs_client.delete_file(path, True))
        self.assertTrue(hdfs_client.directory_exists(path))
        self.assertTrue(hdfs_client.create_directory(path, False))
        self.assertTrue(hdfs_client.create_directory(path, True))
        self.assertTrue(hdfs_client.delete_directory(path, False, True))
        self.assertTrue(hdfs_client.delete_directory(path, True, True))
        self.assertTrue(hdfs_client.delete_directory(path, False, False))
        self.assertTrue(hdfs_client.delete_directory(path, True, False))
        type(process_mock).returncode = mock.PropertyMock(return_value=1)
        self.assertFalse(hdfs_client.file_exists(path))
        self.assertRaises(RuntimeError, hdfs_client.create_file, path)
