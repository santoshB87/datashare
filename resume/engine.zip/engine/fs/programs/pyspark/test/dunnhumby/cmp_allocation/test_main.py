import logging
import os
import shutil
import tempfile
import unittest

import dunnhumby.cmp_allocation.allocation.__main__ as main


class MainTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.temp_folder = tempfile.mkdtemp(dir=os.path.expanduser('~'))
        self.temp_log_file = os.path.join(self.temp_folder, 'test.log')

    def tearDown(self):
        shutil.rmtree(self.temp_folder)

    def test_get_args_algorithm_only(self):
        argv = ['--algorithm', 'test']
        args = main.get_args(argv)
        self.assertEqual(args.algorithm, 'test')
        self.assertEqual(args.log_file, None)
        self.assertEqual(args.verbose, False)

    def test_get_args_algorithm_and_file(self):
        argv = ['--algorithm', 'test1', '--log-file', 'test2']
        args = main.get_args(argv)
        self.assertEqual(args.algorithm, 'test1')
        self.assertEqual(args.log_file, 'test2')
        self.assertEqual(args.verbose, False)

    def test_get_args_algorithm_and_file_and_verbose(self):
        argv = ['--algorithm', 'test1', '--log-file', 'test2', '--verbose']
        args = main.get_args(argv)
        self.assertEqual(args.algorithm, 'test1')
        self.assertEqual(args.log_file, 'test2')
        self.assertEqual(args.verbose, True)

    def test_get_args_required_arg_missing(self):
        argv = ['--log_file', 'test']
        self.assertRaises(
            SystemExit,
            main.get_args,
            argv
        )

    def test_get_args_unrecognised_arg(self):
        argv = ['--algorithm', 'test', '--foo', 'bar']
        self.assertRaises(
            SystemExit,
            main.get_args,
            argv
        )

    def test_configure_logger(self):
        logger = logging.getLogger(self.__class__.__name__)
        main.configure_logger(log_file=self.temp_log_file, verbose=True)
        logger.error('test')
        self.assertTrue(os.path.isfile(self.temp_log_file))

    def test_configure_logger_unverbose(self):
        logger = logging.getLogger(self.__class__.__name__)
        main.configure_logger(log_file=self.temp_log_file, verbose=False)
        logger.debug('test')
        self.assertEqual(len(open(self.temp_log_file, 'r').readlines()), 0)

    def test_configure_logger_verbose(self):
        logger = logging.getLogger(self.__class__.__name__)
        main.configure_logger(log_file=self.temp_log_file, verbose=True)
        logger.debug('test')
        self.assertEqual(len(open(self.temp_log_file, 'r').readlines()), 0)

    def test_configure_logger_no_file(self):
        logger = logging.getLogger(self.__class__.__name__)
        main.configure_logger(log_file=None, verbose=False)
        logger.info('test')
        self.assertFalse(os.path.isfile(self.temp_log_file))

