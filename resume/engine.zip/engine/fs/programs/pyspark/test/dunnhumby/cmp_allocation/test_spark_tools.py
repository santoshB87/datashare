import unittest
import mock
from os import environ, path, listdir
from shutil import rmtree
import tempfile
from dunnhumby import contexts
'''
Uncomment below to run on VM csv related testcases
'''
# SUBMIT_ARGS = "--jars /opt/project/lib/spark-csv_2.10-1.4.0.jar," \
#               "/opt/project/lib/commons-csv-1.4.jar pyspark-shell"
# environ["PYSPARK_SUBMIT_ARGS"] = SUBMIT_ARGS
#from pyspark import SparkConf
# # inject a local spark context into our contexts module
# conf = SparkConf().setMaster('local').setAppName('test_spark_tools')\
#     .set('spark.sql.shuffle.partitions', 1)
# contexts.sc(conf)
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.utils import AnalysisException
import pyspark.sql.functions as F
import dunnhumby.cmp_allocation.spark_tools as tools



class SparkToolsTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.sc = contexts.sc()
        cls.sql_context = contexts.sql_context()
        cls.sql_context.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(dir=path.expanduser('~'))
        self.temp_csv = path.join(self.temp_dir,'temp.csv')
        with open(self.temp_csv, 'w') as fptr:
            fptr.write('\n'.join(['customer,region', '123,London', '124,Wales']))
        temp_data = [('123', 'London'), ('124', 'Wales')]
        temp_col = ['customer', 'region']
        self.df = self.sql_context.createDataFrame(temp_data, temp_col)

    def tearDown(self):
        rmtree(self.temp_dir)

    def test_quiet_logs(self):
        self.assertIsNone(tools.quiet_logs(self.sc))

    # def test_get_df_from_csv(self):
    #     df_out = tools.get_df_from_csv(self.sql_context, 'file://{0}'.format(self.temp_csv))
    #     self.assertIsInstance(df_out,DataFrame)
    #     self.assertEquals(df_out.count(), 2)

    def test_union_all(self):
        df3 = self.df.withColumn('id',F.lit(1))
        df_out = tools.union_all([self.df, self.df])
        self.assertIsInstance(df_out, DataFrame)
        self.assertEquals(df_out.count(), 4)
        self.assertRaises(AnalysisException, tools.union_all, [self.df, df3])

    def test_write_formatted_results_to_hdfs(self):
        file_path = path.join(self.temp_dir, 'df_text')
        tools.write_formatted_results_to_hdfs(spark_context=self.sc, input_df=self.df,
                                              hdfs_path='file://{0}'.format(file_path),
                                              number_of_files=1,
                                              partition_column=self.df['customer'],
                                              select_columns=self.df['customer'],
                                              sort_columns=self.df['customer'],
                                              write_mode='overwrite', file_format='text',
                                              file_option_codec='gzip',
                                              add_columns=[{'name': 'col1', 'value': '01'}],
                                              header=False)
        # if found _SUCCESS file, then write is successful
        self.assertTrue('_SUCCESS' in listdir(file_path))

    @mock.patch('pyspark.SparkContext.version', return_value='1.5.0')
    def test_write_formatted_results_to_hdfs_sparkversion(self, mock_version):
        # this will test some line of function specifically written for version below spark 1.6.0
        file_path = path.join(self.temp_dir, 'df_text_version')
        tools.write_formatted_results_to_hdfs(spark_context=self.sc, input_df=self.df,
                                              hdfs_path='file://{0}'.format(file_path),
                                              number_of_files=1,
                                              partition_column=self.df['customer'],
                                              select_columns=self.df['customer'],
                                              sort_columns=self.df['customer'],
                                              write_mode='overwrite', file_format='text',
                                              file_option_codec=None,
                                              add_columns=None,
                                              header='False')
        # if found _SUCCESS file, then write is successful
        self.assertTrue('_SUCCESS' in listdir(file_path))

    def test_write_to_hdfs(self):
        file_path = path.join(self.temp_dir, 'df_parquet')
        file_path_part = path.join(self.temp_dir, 'df_parquet_part')
        tools.write_to_hdfs(input_df=self.df, hdfs_path='file://{0}'.format(file_path),
                            file_format='parquet', file_saveMode='overwrite',
                            partition_column=None, number_of_files=2)
        tools.write_to_hdfs(input_df=self.df, hdfs_path='file://{0}'.format(file_path_part),
                            file_format='parquet', file_saveMode='overwrite',
                            partition_column='region', number_of_files=2)
        self.assertTrue('_SUCCESS' in listdir(file_path))
        self.assertTrue('_SUCCESS' in listdir(file_path_part))

    # def test_write_csv_to_hdfs(self):
    #     file_path = path.join(self.temp_dir, 'df_csv')
    #     tools.write_csv_to_hdfs(input_df=self.df, hdfs_path='file://{0}'.format(file_path),
    #                             file_format='com.databricks.spark.csv', file_saveMode='overwrite',
    #                             number_of_files=1)
    #     self.assertTrue('_SUCCESS' in listdir(file_path))
    #
    # def test_write_csv_to_nfs(self):
    #     file_path = path.join(self.temp_dir, 'df_csv_nfs')
    #     tools.write_csv_to_nfs(input_df=self.df, nfs_path='file://{0}'.format(file_path),
    #                            file_format='com.databricks.spark.csv', file_saveMode='overwrite',
    #                            number_of_files=1)
    #     self.assertTrue('_SUCCESS' in listdir(file_path))

    def test_dropAll(self):
        df_out = tools.dropAll(self.df, self.df['region'])
        self.assertNotIn('region', df_out.columns)

    @mock.patch('pyspark.sql.DataFrameWriter.jdbc', return_value=None)
    def test_write_formatted_results_to_jdbc(self, mock_jdbc):
        # as both function write_formatted_results_to_jdbc & pyspark.sql.DataFrameWriter.jdbc
        # doesn't return anything hence taking mock return value as None and same is asserted.
        df_out = tools.write_formatted_results_to_jdbc(input_df=self.df,
                                                       url='jdbc:hive2://localhost:10000/default',
                                                       where='test_tab', write_mode='append',
                                                       properties=None, partition_column=None)
        self.assertIsNone(df_out)
        df_out = tools.write_formatted_results_to_jdbc(input_df=self.df,
                                                       url='jdbc:hive2://localhost:10000/default',
                                                       where='test_tab', write_mode='append',
                                                       properties=None, partition_column='region')
        self.assertIsNone(df_out)

    @mock.patch('pyspark.sql.DataFrameReader.jdbc')
    def test_read_from_jdbc(self, mock_jdbc):
        mock_jdbc.return_value = self.df
        df_out = tools.read_from_jdbc(hive_context=self.sql_context,
                                      url='jdbc:hive2://localhost:10000/default', where=None,
                                      properties=None, jdbc_table='test_tab', partition_column=None)
        self.assertIsInstance(df_out, DataFrame)

    def test_check_columns(self):
        self.assertIsNone(tools.check_columns(self.df, ['customer']))
        self.assertIsNone(tools.check_columns(self.df, 'region'))
        self.assertRaises(RuntimeError, tools.check_columns, self.df, 'id')

    def test_update_df_attribute_content(self):
        self.assertRaises(RuntimeError, tools.update_df_attribute_content,
                          self.df, 'id', F.lit('01'))
        df_out = tools.update_df_attribute_content(self.df, 'region', F.lit('London')).\
            select('region').distinct().collect()
        self.assertEquals(len(df_out), 1)
        self.assertEquals(df_out[0]['region'], 'London')

    def test_rename_df_columns(self):
        self.assertRaises(RuntimeError, tools.rename_df_columns, self.df, 'id', 'ids')
        self.assertRaises(RuntimeError, tools.rename_df_columns, self.df,
                          ['customer', 'region'], ['id'])
        df_out = tools.rename_df_columns(self.df, ['customer'], ['custid'])
        self.assertIn('custid', df_out.columns)

