import unittest
from pyspark import SparkConf
from pyspark.sql.types import *
import dunnhumby
from dunnhumby.cmp_entities.base import CMPEntity
from dunnhumby import contexts


# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)


class MyEntity(dunnhumby.cmp_entities.base.CMPEntity):
    """
    This is a stub implementation of CMPEntity that we can use for testing purposes
    """

    def __init__(self):
        super(MyEntity, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('MyEntity', StringType(), True))
        required_schema.add(StructField('MyEntityAttribute', StringType(), True))

        self.required_schema = required_schema

        self.unique_columns = ['MyEntity']

        self.one_to_manys = None

        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        schema = StructType(
            [StructField("MyEntity", StringType(), True), StructField("MyEntityAttribute", StringType(), True)])
        l = [('foo1', 'bar1'), ('foo2', 'bar2'), ('foo3', 'bar3')]
        df = self.sqlContext.createDataFrame(l, schema)

        # self.df is a property - validation of its schema and column uniqueness is handled in the setter method
        self.data = df


class MyEntityWithACompositeKey(dunnhumby.cmp_entities.base.CMPEntity):
    """
    This is a stub implementation of CMPEntity that we can use for testing purposes
    """

    def __init__(self):
        super(MyEntityWithACompositeKey, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('Basket', StringType(), True))
        required_schema.add(StructField('Product', StringType(), True))
        required_schema.add(StructField('QuantityBought', IntegerType(), True))

        self.required_schema = required_schema

        self.unique_columns = [['Basket', 'Product']]

        self.one_to_manys = None

        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        schema = StructType(
            [
                StructField("Basket", StringType(), True),
                StructField("Product", StringType(), True),
                StructField("QuantityBought", IntegerType(), True)
            ]
        )
        l = [('Basket1', 'Product1', 1), ('Basket1', 'Product2', 2), ('Basket2', 'Product1', 3)]
        df = self.sqlContext.createDataFrame(l, schema)

        # self.df is a property - validation of its schema and column uniqueness is handled in the setter method
        self.data = df


class MyEntityWithTwoUniqueColumns(dunnhumby.cmp_entities.base.CMPEntity):
    """
    This is a stub implementation of CMPEntity that we can use for testing purposes
    """

    def __init__(self):
        super(MyEntityWithTwoUniqueColumns, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('UniqueColumn1', StringType(), True))
        required_schema.add(StructField('UniqueColumn2', StringType(), True))

        self.required_schema = required_schema

        self.unique_columns = ['UniqueColumn1', 'UniqueColumn2']

        self.one_to_manys = None

        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        schema = StructType(
            [
                StructField("UniqueColumn1", StringType(), True),
                StructField("UniqueColumn2", StringType(), True)
            ]
        )
        l = [('Basket1', 'Product1'), ('Basket2', 'Product2'), ('Basket3', 'Product3')]
        df = self.sqlContext.createDataFrame(l, schema)

        # self.df is a property - validation of its schema and column uniqueness is handled in the setter method
        self.data = df


class TestNormalBehaviour(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_base_returns_correct_data_when_all_constraints_are_satisfied_and_unique_columns_comprises_one_field(self):
        myEntity = MyEntity()
        self.assertTrue(myEntity.data.count(), 3)

    def test_base_returns_correct_data_when_all_constraints_are_satisfied_and_unique_columns_comprises_multiple_fields(
            self):
        myEntityWithACompositeKey = MyEntityWithACompositeKey()
        self.assertTrue(myEntityWithACompositeKey.data.count(), 3)

    def test_base_returns_correct_data_when_all_constraints_are_satisfied_and_there_are_multiple_unique_columns(
            self):
        myEntityWithTwoUniqueColumns = MyEntityWithTwoUniqueColumns()
        self.assertTrue(myEntityWithTwoUniqueColumns.data.count(), 3)

