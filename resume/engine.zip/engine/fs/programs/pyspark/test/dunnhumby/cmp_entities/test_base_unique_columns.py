import unittest
from pyspark import SparkConf
from pyspark.sql.types import *
import dunnhumby
from dunnhumby.cmp_entities.base import CMPEntity
from dunnhumby import contexts


# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)


class MyEntity(dunnhumby.cmp_entities.base.CMPEntity):
    """
    This is a stub implementation of CMPEntity that we can use for testing purposes
    """
    def __init__(self):
        super(MyEntity, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('MyEntity', StringType(), True))
        required_schema.add(StructField('MyEntityAttribute', StringType(), True))

        self.required_schema = required_schema

        self.unique_columns = ['MyEntity']

        self.one_to_manys = None

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        schema = StructType(
            [StructField("MyEntity", StringType(), True), StructField("MyEntityAttribute", StringType(), True)])
        l = [('foo','bar'),('foo','bar')]
        df = self.sqlContext.createDataFrame(l, schema)

        # self.df is a property - validation of its schema and column uniqueness is handled in the setter method
        self.data = df


class TestUniqueColumns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_base_raises_error_when_unique_columns_is_not_met(self):
        myEntity = MyEntity()
        with self.assertRaisesRegexp(ValueError, 'Incoming dataframe does not meet uniqueness rules defined in unique_columns'):
            myEntity.get_data()
