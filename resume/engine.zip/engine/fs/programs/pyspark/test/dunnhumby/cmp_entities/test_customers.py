import unittest
from dunnhumby.cmp_entities.customers import Customers as base
import pyspark.sql.types as pt
from pyspark import SparkConf
from dunnhumby import contexts

# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)

class Customers(base):

    # Adding dummy database property and overriding get_data to do nothing
    # as we don't need to fetch actual data in this test case
    @property
    def database(self):
        return ''

    def get_data(self):
        pass


class TestCustomers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init_specifies_required_schema(self):
        entity= Customers()
        self.assertIsInstance(entity.required_schema, pt.StructType)

    def test_init_specifies_unique_columns(self):
        entity = Customers()
        self.assertIsInstance(entity.unique_columns, list)

