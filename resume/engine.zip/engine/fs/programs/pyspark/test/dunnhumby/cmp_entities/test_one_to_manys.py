import unittest
from pyspark import SparkConf
from pyspark.sql.types import *
import dunnhumby
from dunnhumby.cmp_entities.base import CMPEntity
from dunnhumby import contexts


# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)


class MyWidget(dunnhumby.cmp_entities.base.CMPEntity):
    """
    This is a stub implementation of CMPEntity that we can use for testing purposes
    """

    def __init__(self):
        super(MyWidget, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('Widget', StringType(), True))
        required_schema.add(StructField('WidgetSubCategory', StringType(), True))
        required_schema.add(StructField('WidgetCategory', StringType(), True))

        self.required_schema = required_schema

        self.unique_columns = ['Widget']

        self.one_to_manys = [('WidgetCategory', 'WidgetSubCategory')]

        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        schema = StructType(
            [StructField("Widget", StringType(), True),
             StructField("WidgetSubCategory", StringType(), True),
             StructField("WidgetCategory", StringType(), True)
             ]
        )
        #The data in this dataframe violates a one-to-many relationship between WidgetCategory and Widget SubCategory.
        #Each particular WidgetSubCategory should have the same WidgetCategory, in this examplle they do not
        l = [
            ('Widget1', 'WidgetSubCategory1', 'WidgetCategory1'),
            ('Widget2', 'WidgetSubCategory2', 'WidgetCategory2'),
            ('Widget3', 'WidgetSubCategory2', 'WidgetCategory3')
        ]
        df = self.sqlContext.createDataFrame(l, schema)

        # self.df is a property - validation of its schema and column uniqueness is handled in the setter method
        self.data = df

class MyWidgetWithAOneToManyThatIsNotAList(dunnhumby.cmp_entities.base.CMPEntity):
    def __init__(self):
        super(MyWidgetWithAOneToManyThatIsNotAList, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('Widget', StringType(), True))
        required_schema.add(StructField('WidgetSubCategory', StringType(), True))
        required_schema.add(StructField('WidgetCategory', StringType(), True))
        self.required_schema = required_schema
        self.unique_columns = ['Widget']
        self.one_to_manys = 'not a list'
        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        pass

class MyWidgetWhereEachElementOfTheOneToManyListIsNotATuple(dunnhumby.cmp_entities.base.CMPEntity):
    def __init__(self):
        super(MyWidgetWhereEachElementOfTheOneToManyListIsNotATuple, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('Widget', StringType(), True))
        required_schema.add(StructField('WidgetSubCategory', StringType(), True))
        required_schema.add(StructField('WidgetCategory', StringType(), True))
        self.required_schema = required_schema
        self.unique_columns = ['Widget']
        self.one_to_manys = ['not a tuple']
        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        pass


class MyWidgetWhereEachTupleOfTheListIsDoesNotHaveTwoElements(dunnhumby.cmp_entities.base.CMPEntity):
    def __init__(self):
        super(MyWidgetWhereEachTupleOfTheListIsDoesNotHaveTwoElements, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('Widget', StringType(), True))
        required_schema.add(StructField('WidgetSubCategory', StringType(), True))
        required_schema.add(StructField('WidgetCategory', StringType(), True))
        self.required_schema = required_schema
        self.unique_columns = ['Widget']
        self.one_to_manys = [('a','b','c')]
        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''


    def get_data(self):
        pass


class MyWidgetWhereTupleInOneToManysSpecifiesUnknownColumns(dunnhumby.cmp_entities.base.CMPEntity):
    def __init__(self):
        super(MyWidgetWhereTupleInOneToManysSpecifiesUnknownColumns, self).__init__()

        required_schema = StructType()
        required_schema.add(StructField('Widget', StringType(), True))
        required_schema.add(StructField('WidgetSubCategory', StringType(), True))
        required_schema.add(StructField('WidgetCategory', StringType(), True))
        self.required_schema = required_schema
        self.unique_columns = ['Widget']
        self.one_to_manys = [('WidgetCategory', 'nonexistentcolumn'),('WidgetCategory', 'nonexistentcolumn2')]
        self.get_data()

    @property
    def table(self):
        return ''

    @property
    def database(self):
        return ''

    def get_data(self):
        pass


class TestOneToMany(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_data_that_violates_one_to_many_causes_an_error(self):
        with self.assertRaisesRegexp(
                ValueError,
                'Incoming dataframe does not meet referential integrity rules defined in one_to_manys'
        ):
                MyWidget()

    def test_one_to_manys_value_that_is_not_a_list_causes_an_error(self):
        with self.assertRaisesRegexp(
                ValueError,
                'Value attempting to be assigned to one_to_manys is not a list'
        ):
                MyWidgetWithAOneToManyThatIsNotAList()

    def test_one_to_manys_value_where_list_is_not_a_list_of_tuples_raises_an_error(self):
        with self.assertRaisesRegexp(
                ValueError,
                'Value attempting to be assigned to one_to_manys is a list of tuples'
        ):
                MyWidgetWhereEachElementOfTheOneToManyListIsNotATuple()

    def test_one_to_manys_value_where_list_is_not_a_list_of_tuples_raises_an_error(self):
        with self.assertRaisesRegexp(
                ValueError,
                'Value attempting to be assigned to one_to_manys contains tuples whose length is not 2'
        ):
                MyWidgetWhereEachTupleOfTheListIsDoesNotHaveTwoElements()

    def test_one_to_manys_value_specifying_non_existent_column_raises_an_error(self):
        with self.assertRaisesRegexp(
                ValueError,
                'The columns specified in the one_to_manys list were not found in the required_schema'
        ):
            MyWidgetWhereTupleInOneToManysSpecifiesUnknownColumns()

