"""
Purchases Entity base class - Unit test cases
"""


import unittest
from decimal import Decimal
from random import choice
from pyspark.sql import types as pt
from dunnhumby import contexts
from dunnhumby.cmp_entities.purchases import Purchases as base

class Purchases(base):

    # Adding dummy database property
    @property
    def database(self):
        return ''

    # Adding dummy table property
    @property
    def table(self):
        return ''

class TestPurchases(unittest.TestCase):
    """
    Unit test cases for class TransactionsNew
    """

    @classmethod
    def setUpClass(cls):
        # Set required hive & spark config and create databases & tables
        cls.config = {
            "SSEProductHierarchy": ["Division", "Section", "Group", "Subgroup", "Product"],
            "SSEHiveWarehousePath": "/user/hive/warehouse",
            "SSEHiveWorkdb": "client_ssework",
            "SSEHivePurchaseTab": "purchase_fct",
            "SSEFeaturePurchaseRePartitionNum": 1
        }
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("hive.exec.dynamic.partition", "true")
        cls.sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")
        cls.sqlContext.conf.set("spark.sql.parquet.compression.codec", "gzip")
        cls.sqlContext.sql("DROP DATABASE IF EXISTS client_ssework CASCADE")
        cls.sqlContext.sql("CREATE DATABASE IF NOT EXISTS client_ssework "
                           "LOCATION '/user/hive/warehouse/client_ssework'")
        cls.drop_purchases = "DROP TABLE IF EXISTS client_ssework.purchase_fct"
        cls.drop_purchases = "DROP TABLE IF EXISTS client_ssework.temp_purchase"
        cls.drop_ddl = "DROP TABLE IF EXISTS client_ssework.purchase_fct"
        cls.create_ddl = "CREATE TABLE IF NOT EXISTS client_ssework.purchase_fct (basket string, " \
                         "division string, section string, group string, subgroup string, product" \
                         " string, customer string, store string, banner string, fulfillmentstore string, prefer" \
                         "redstore1 string, preferredstore2 string, preferredstore3 string, chann" \
                         "el string, quantity decimal(24,2), netspendamount decimal(38,2), spenda" \
                         "mount decimal(38,2), discountamount decimal(38,2)) PARTITIONED BY (fis_" \
                         "week_id string, date_id string) STORED AS PARQUET " \
                         'TBLPROPERTIES ("parquet.compression"="gzip")'
        cls.ins_dml = "INSERT INTO client_ssework.purchase_fct PARTITION(fis_week_id, date_id) " \
                      "SELECT * FROM client_ssework.temp_purchase"
        cls.purchases_schema = pt.StructType([
            pt.StructField("Basket", pt.StringType(), True),
            pt.StructField("Division", pt.StringType(), True),
            pt.StructField("Section", pt.StringType(), True),
            pt.StructField("Group", pt.StringType(), True),
            pt.StructField("SubGroup", pt.StringType(), True),
            pt.StructField("Product", pt.StringType(), True),
            pt.StructField("Customer", pt.StringType(), True),
            pt.StructField("Store", pt.StringType(), True),
            pt.StructField("Banner", pt.StringType(), True),
            pt.StructField("FulfillmentStore", pt.StringType(), True),
            pt.StructField("PreferredStore1", pt.StringType(), True),
            pt.StructField("PreferredStore2", pt.StringType(), True),
            pt.StructField("PreferredStore3", pt.StringType(), True),
            pt.StructField("Channel", pt.StringType(), True),
            pt.StructField("Quantity", pt.DecimalType(24, 2), True),
            pt.StructField("NetSpendAmount", pt.DecimalType(38, 2), True),
            pt.StructField("SpendAmount", pt.DecimalType(38, 2), True),
            pt.StructField("DiscountAmount", pt.DecimalType(38, 2), True),
            pt.StructField("fis_week_id", pt.StringType(), True),
            pt.StructField("date_id", pt.StringType(), True)
        ])
        cls.purchases_lst = [
            ("20171202084727039160822244", "A", "A2", "A2B", "A2B2", "Product31", "Customer2",
             "Store4", "Banner1", "Store4", "Store4", "Store1", "Store2", "Channel1", Decimal("1.0"),
             Decimal("41.99"), Decimal("41.99"), Decimal("0.0"), "201740", "2017-12-02"),
            ("20171203144007026950149675", "D", "D1", "D1A", "D1A1", "Product8", "Customer4",
             "Store27", "Banner6","Store27", "Store20", "Store22", "Store30", "Channel1", Decimal("1.0"),
             Decimal("1.1"), Decimal("1.29"), Decimal("0.19"), "201740", "2017-12-03"),
            ("20171204132046039250829023", "C", "C1", "C1B", "C1B2", "Product30", "Customer14",
             "Store23", "Banner5","Store23", "Store23", "Store20", "Store27", "Channel1", Decimal("1.00"),
             Decimal("47.93"), Decimal("47.93"), Decimal("0.00"), "201741", "2017-12-04"),
            ("20171204132046039250829023", "C", "C1", "C1B", "C1B2", "Product30", "",
             "Store23", "Banner5", "Store23", "Store23", "Store20", "Store27", "Channel1", Decimal("1.00"),
             Decimal("47.93"), Decimal("47.93"), Decimal("0.00"), "201741", "2017-12-04")
        ]
        cls.sqlContext.createDataFrame(cls.purchases_lst, cls.purchases_schema).\
            write.saveAsTable("client_ssework.temp_purchase")

    @classmethod
    def tearDownClass(cls):
        cls.sqlContext.sql("DROP DATABASE IF EXISTS client_ssework CASCADE")

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def refresh_purchase_table(self):
        """
        Drop & recreate purchase_fct table
        :return: None
        """
        self.sqlContext.sql(self.drop_ddl)
        self.sqlContext.sql(self.create_ddl)
        self.sqlContext.sql(self.ins_dml)

    def test_init(self):
        """
        Unit test case for __init__()
        :return: None
        """
        purchases = Purchases(config=self.config)
        self.assertIsInstance(purchases, Purchases)
        self.assertIsInstance(purchases.required_schema, pt.StructType)
        self.assertIsInstance(purchases.unique_columns, list)
        self.assertEqual(purchases.one_to_manys, None)

    def test_fix_table_structure(self):
        """

        :return: None
        """
        self.sqlContext.sql(self.drop_ddl)
        purchases = Purchases(config=self.config)
        self.assertTrue(purchases.table_structural_change_flag)
        purchases = Purchases(config=self.config)
        self.assertFalse(purchases.table_structural_change_flag)
        self.sqlContext.sql(self.drop_ddl)
        wrong_create_ddl = "CREATE TABLE IF NOT EXISTS client_ssework.purchase_fct (basket string" \
                           ", division string, section string, group string, subgroup string, " \
                           "product string, customer string, store string, banner string, fulfillmentstore " \
                           "string) PARTITIONED BY (fis_week_id string) STORED AS PARQUET"
        self.sqlContext.sql(wrong_create_ddl)
        purchases = Purchases(config=self.config)
        self.assertTrue(purchases.table_structural_change_flag)

    def test_table_ddl(self):
        """
        Unit test case for table_ddl()
        :return: None
        """
        purchases = Purchases(config=self.config)
        self.assertEqual(purchases.table_ddl().replace(" ", "").lower(),
                         self.create_ddl.replace(" ", "").lower())

    def test_get_data(self):
        """
        Unit test case for get_data()
        :return: None
        """
        self.refresh_purchase_table()
        purchases = Purchases(config=self.config)
        purchases.get_data()
        self.assertEqual(purchases.data.count(), len(self.purchases_lst))
        result_df = self.sqlContext.createDataFrame(self.purchases_lst, self.purchases_schema)
        self.assertEqual(purchases.data.subtract(result_df).count(), 0)
        self.assertEqual(result_df.subtract(purchases.data).count(), 0)

    def test_get_partition(self):
        """
        Unit test case for get_partition()
        :return: None
        """
        self.refresh_purchase_table()
        random_week = choice([item[18] for item in self.purchases_lst])
        random_date = choice([item[19] for item in self.purchases_lst if item[18] == random_week])
        result1_lst = [item for item in self.purchases_lst if item[18] == random_week]
        result2_lst = [item for item in self.purchases_lst if item[19] == random_date]
        purchases = Purchases(config=self.config)
        part1_df = purchases.get_partition(fis_week_id=random_week)
        part2_df = purchases.get_partition(fis_week_id=random_week, date_id=random_date)
        result1_df = self.sqlContext.createDataFrame(result1_lst, self.purchases_schema)
        result2_df = self.sqlContext.createDataFrame(result2_lst, self.purchases_schema)
        self.assertRaises(ValueError, purchases.get_partition, fis_week_id=None)
        self.assertEqual(part1_df.count(), len(result1_lst))
        self.assertEqual(part1_df.subtract(result1_df).count(), 0)
        self.assertEqual(result1_df.subtract(part1_df).count(), 0)
        self.assertEqual(part2_df.count(), len(result2_lst))
        self.assertEqual(part2_df.subtract(result2_df).count(), 0)
        self.assertEqual(result2_df.subtract(part2_df).count(), 0)

    def test_get_partition_info(self):
        """
        Unit test case for get_partition_info()
        :return: None
        """
        self.refresh_purchase_table()
        purchases = Purchases(config=self.config)
        part_lst = sorted(set([(item[18], item[19]) for item in self.purchases_lst]),
                          key=lambda x: (x[0], x[1]))
        part_info = sorted(purchases.get_partition_info(), key=lambda x: (x[0], x[1]))
        self.assertListEqual(part_lst, part_info)
        part_info = sorted(purchases.get_partition_info(), key=lambda x: (x[0], x[1]))
        self.assertListEqual(part_lst, part_info)

    def test_del_partition(self):
        """
        Unit test case for del_partition()
        :return: None
        """
        self.refresh_purchase_table()
        purchases = Purchases(config=self.config)
        self.assertIsNone(purchases.del_partition())
        random_week = choice([item[18] for item in self.purchases_lst])
        random_date = choice([item[19] for item in self.purchases_lst if item[18] == random_week])
        result_lst = [item for item in self.purchases_lst if item[19] != random_date]
        purchases.del_partition(fis_week_id=random_week, date_id=random_date)
        purchases.get_data()
        self.assertEqual(purchases.data.count(), len(result_lst))
        self.assertNotIn((random_week, random_date), purchases.get_partition_info())

    def test_write_data(self):
        """
        Unit test case for write_data()
        :return: None
        """
        self.sqlContext.sql(self.drop_ddl)
        self.sqlContext.sql(self.create_ddl)
        channel_schema = pt.StructType([
            pt.StructField("channel_id", pt.LongType(), True),
            pt.StructField("Channel", pt.StringType(), True),
        ])
        channel_lst = [
            (-1, "UNKNOWN_DIMENSION"),
            (1, "Channel1"),
        ]
        store_schema = pt.StructType([
            pt.StructField("store_id", pt.LongType(), True),
            pt.StructField("Store", pt.StringType(), True),
            pt.StructField("Banner", pt.StringType(), True)
        ])
        store_lst = [
            (4, "Store4", "Banner1"),
            (23, "Store23", "Banner5"),
            (27, "Store27", "Banner6"),
        ]
        product_schema = pt.StructType([
            pt.StructField("Product", pt.StringType(), True),
            pt.StructField("SubGroup", pt.StringType(), True),
            pt.StructField("Group", pt.StringType(), True),
            pt.StructField("Section", pt.StringType(), True),
            pt.StructField("Division", pt.StringType(), True),
        ])
        product_lst = [
            ("Product8", "D1A1", "D1A", "D1", "D"),
            ("Product30", "C1B2", "C1B", "C1", "C"),
            ("Product31", "A2B2", "A2B", "A2", "A"),
        ]

        customer_schema = pt.StructType([
            pt.StructField("Customer", pt.StringType(), True),
            pt.StructField("FulfillmentStore", pt.StringType(), True),
            pt.StructField("PreferredStore1", pt.StringType(), True),
            pt.StructField("PreferredStore2", pt.StringType(), True),
            pt.StructField("PreferredStore3", pt.StringType(), True),
        ])
        customer_lst = [
            ("Customer2", "Store4", "Store4", "Store1", "Store2"),
            ("Customer4", "Store27", "Store20", "Store22", "Store30"),
            ("Customer14", "Store23", "Store23", "Store20", "Store27"),
        ]

        trans_schema = pt.StructType([
            pt.StructField("Product", pt.StringType(), True),
            pt.StructField("Customer", pt.StringType(), True),
            pt.StructField("Store", pt.StringType(), True),
            pt.StructField("Channel", pt.StringType(), True),
            pt.StructField("Basket", pt.StringType(), True),
            pt.StructField("date_id", pt.StringType(), True),
            pt.StructField("fis_week_id", pt.StringType(), True),
            pt.StructField("Quantity", pt.DecimalType(24, 2), True),
            pt.StructField("SpendAmount", pt.DecimalType(38, 2), True),
            pt.StructField("NetSpendAmount", pt.DecimalType(38, 2), True),
            pt.StructField("DiscountAmount", pt.DecimalType(38, 2), True),
        ])
        trans_lst = [
            ("Product31", "Customer2", "Store4", "Channel", "20171202084727039160822244", "2017-12-02", "201740", Decimal("1.0"),
             Decimal("41.99"), Decimal("41.99"), Decimal("0.0")),
            ("Product8", "Customer4", "Store4", "Channel", "20171203144007026950149675", "2017-12-03", "201740", Decimal("1.0"),
             Decimal("1.29"), Decimal("1.1"), Decimal("0.19")),
            ("Product30", "Customer14", "Store23", "Channel", "20171204132046039250829023", "2017-12-04", "201741", Decimal("1.0"),
             Decimal("47.93"), Decimal("47.93"), Decimal("0.0")),
            ("Product30", "", "Store27", "Channel", "20171204132046039250829023", "2017-12-04", "201741",
             Decimal("1.0"), Decimal("47.93"), Decimal("47.93"), Decimal("0.0")),
            ("Product30", "Customer14", "Store23", "Channel", "20171204132046039250829023", "2017-12-04", "201741",
             Decimal("1.0"), Decimal("47.93"), Decimal("47.93"), Decimal("0.0"))
        ]
        channels_df = self.sqlContext.createDataFrame(channel_lst, channel_schema)
        stores_df = self.sqlContext.createDataFrame(store_lst, store_schema)
        products_df = self.sqlContext.createDataFrame(product_lst, product_schema)
        customers_df = self.sqlContext.createDataFrame(customer_lst, customer_schema)
        transactions_df = self.sqlContext.createDataFrame(trans_lst, trans_schema)

        purchase = Purchases(config=self.config)
        purchase.get_data()
        old_cnt = purchase.data.count()
        self.assertEqual(old_cnt, 0)
        purchase.write_data(transactions_df, customers_df, products_df, stores_df)
        purchase.get_data()
        new_cnt = purchase.data.count()
        self.assertEqual(old_cnt + new_cnt, len(trans_lst))
