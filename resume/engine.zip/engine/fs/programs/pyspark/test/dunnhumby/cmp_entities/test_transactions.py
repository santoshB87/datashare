import unittest
import datetime
from decimal import *
from dunnhumby.cmp_entities.transactions import Transactions as base
import pyspark.sql.types as pt
from pyspark import SparkConf
from dunnhumby import contexts

# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)

class Transactions(base):

    # Adding dummy database property

    @property
    def database(self):
        return 'dummy_database'

class TestTransactions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists dummy_database')
        self.sqlContext.sql('drop table if exists dummy_database.transactions')

        self.transaction_schema = pt.StructType(
            [pt.StructField("basket", pt.StringType(), True),
             pt.StructField("datetime", pt.TimestampType(), True),
             pt.StructField("product", pt.StringType(), True),
             pt.StructField("customer", pt.StringType(), True),
             pt.StructField("store", pt.StringType(), True),
             pt.StructField("channel", pt.StringType(), True),
             pt.StructField("quantity", pt.IntegerType(), True),
             pt.StructField("spendamount", pt.DecimalType(18, 2), True),
             pt.StructField("netspendamount", pt.DecimalType(18, 2), True),
             pt.StructField("discountamount", pt.DecimalType(18, 2), True),
             pt.StructField("fis_year_id", pt.IntegerType(), True),
             pt.StructField("fis_week_id", pt.IntegerType(), True),
             pt.StructField("date_id", pt.DateType(), True)
             ])
        l = [('000004828750804', datetime.datetime(2018, 12, 16), '000000003700015846', '000000000000432',\
              '41', None, 1, Decimal('7.99'), Decimal('7.99'), Decimal('0.00'), 2018, 201846, datetime.date(2018, 12, 16))]
        self.sqlContext.createDataFrame(l, self.transaction_schema).write.\
            saveAsTable('dummy_database.transactions')


    def tearDown(self):
        pass

    def test_init_specifies_required_schema(self):
        entity= Transactions()
        self.assertIsInstance(entity.required_schema, pt.StructType)

    def test_init_specifies_unique_columns(self):
        entity = Transactions()
        self.assertIsInstance(entity.unique_columns, list)