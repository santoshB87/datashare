import unittest
from dunnhumby.cmp_features.gen_feature_specs import FeatureSpecsGenerator as FeatureSpecsGenerator


class TestFeatureSpecsGenerator(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.product_hierarchy = [
            "Division",
            "Department",
            "Section",
            "PacSubgroup"
        ]
        cls.feature_specs_obj = FeatureSpecsGenerator(cls.product_hierarchy)

    def test_get_levels(self):
        self.feature_specs_obj.get_levels()
        actual = self.feature_specs_obj.levels
        expected = [
            "Division_All_All_All",
            "Department_All_All_All",
            "Section_All_All_All",
            "PacSubgroup_All_All_All",
            "All_All_All_All",
            "Division_Customer_All_All",
            "Department_Customer_All_All",
            "Section_Customer_All_All",
            "PacSubgroup_Customer_All_All",
            "All_Customer_All_All"
        ]
        self.assertEqual(actual, expected)

    def test_generate(self):
        actual = self.feature_specs_obj.generate("Department_All_All_All")
        expected = dict()
        expected["name"] = "department_all_all_all"
        expected["cadence_attribute"] = "fis_week_id"
        expected["rsd"] = 0
        expected["is_active"] = True
        expected["summary_on"] = True
        expected["durations"] = [
            [
                1,1
            ],
            [
                1,4
            ],
            [
                1,8
            ],
            [
                1,13
            ],
            [
                1,26
            ],
            [
                1,52
            ],
            [
                1,56
            ]
        ]
        expected["base_features"] = [
            "Baskets",
            "BasketWeeks",
            "Discount",
            "MaximumPrice",
            "MinimumPrice",
            "MaximumNetPrice",
            "MinimumNetPrice",
            "Quantity",
            "QuantityPrefStore1",
            "QuantityPrefStore2",
            "QuantityPrefStore3",
            "QuantityFulfillmentStore",
            "GrossSpend",
            "NetSpend",
            "MaxPurchaseDate",
            "MinPurchaseDate",
            "RecencyWeightedBasketWeeks75",
            "RecencyWeightedBasketWeeks95",
            "StandardDeviationNetSpendPerWeek"
        ]
        expected["derived_features"] = [
            "BasketsFlag",
            "DiscountPerBasket",
            "DiscountPercent",
            "AveragePrice",
            "QuantityPerBasket",
            "NetSpendPerBasket",
            "AveragePurchaseCycle",
            "RecencyDays",
            "CyclesSinceLastPurchase"
        ]
        expected["distinct_features"] = [
            "SectionCount",
            "PacSubgroupCount",
            "CustomerCount"
        ]
        expected["dimension_attribute_grain"] = {
            "ProductAttribute": "Department",
            "CustomerAttribute": "All",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        expected["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division"
                ],
                "join_key": ["Department"]
            }
        ]
        expected["dimension_attribute_null_filter"] = [
            "Department"
        ]
        self.assertEqual(actual, expected)

    def test_start(self):
        rsd = 0
        cadence_attribute = "fis_week_id"
        is_active = True
        summary_on = True
        base_features = [
            "Baskets",
            "BasketWeeks",
            "Discount",
            "MaximumPrice",
            "MinimumPrice",
            "MaximumNetPrice",
            "MinimumNetPrice",
            "Quantity",
            "QuantityPrefStore1",
            "QuantityPrefStore2",
            "QuantityPrefStore3",
            "QuantityFulfillmentStore",
            "GrossSpend",
            "NetSpend",
            "MaxPurchaseDate",
            "MinPurchaseDate",
            "RecencyWeightedBasketWeeks75",
            "RecencyWeightedBasketWeeks95",
            "StandardDeviationNetSpendPerWeek"
        ]
        derived_features = [
            "BasketsFlag",
            "DiscountPerBasket",
            "DiscountPercent",
            "AveragePrice",
            "QuantityPerBasket",
            "NetSpendPerBasket",
            "AveragePurchaseCycle",
            "RecencyDays",
            "CyclesSinceLastPurchase"
        ]
        durations = [
            [
                1, 1
            ],
            [
                1, 4
            ],
            [
                1, 8
            ],
            [
                1, 13
            ],
            [
                1, 26
            ],
            [
                1, 52
            ],
            [
                1, 56
            ]
        ]

        division = dict()
        division["name"] = "division_all_all_all"
        division["cadence_attribute"] = cadence_attribute
        division["rsd"] = rsd
        division["is_active"] = is_active
        division["summary_on"] = summary_on
        division["durations"] = durations
        division["base_features"] = base_features
        division["derived_features"] = derived_features
        division["distinct_features"] = [
            "DepartmentCount",
            "SectionCount",
            "PacSubgroupCount",
            "CustomerCount"
        ]
        division["dimension_attribute_grain"] = {
            "ProductAttribute": "Division",
            "CustomerAttribute": "All",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        division["additional_dimension_attribute"] = []
        division["dimension_attribute_null_filter"] = [
            "Division"
        ]
        
        department = dict()
        department["name"] = "department_all_all_all"
        department["cadence_attribute"] = cadence_attribute
        department["rsd"] = rsd
        department["is_active"] = is_active
        department["summary_on"] = summary_on
        department["durations"] = durations
        department["base_features"] = base_features
        department["derived_features"] = derived_features
        department["distinct_features"] = [
            "SectionCount",
            "PacSubgroupCount",
            "CustomerCount"
        ]
        department["dimension_attribute_grain"] = {
            "ProductAttribute": "Department",
            "CustomerAttribute": "All",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        department["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division"
                ],
                "join_key": ["Department"]
            }
        ]
        department["dimension_attribute_null_filter"] = [
            "Department"
        ]

        section = dict()
        section["name"] = "section_all_all_all"
        section["cadence_attribute"] = cadence_attribute
        section["rsd"] = rsd
        section["is_active"] = is_active
        section["summary_on"] = summary_on
        section["durations"] = durations
        section["base_features"] = base_features
        section["derived_features"] = derived_features
        section["distinct_features"] = [
            "PacSubgroupCount",
            "CustomerCount"
        ]
        section["dimension_attribute_grain"] = {
            "ProductAttribute": "Section",
            "CustomerAttribute": "All",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        section["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division",
                    "Department"
                ],
                "join_key": ["Section"]
            }
        ]
        section["dimension_attribute_null_filter"] = [
            "Section"
        ]

        pacsubgroup = dict()
        pacsubgroup["name"] = "pacsubgroup_all_all_all"
        pacsubgroup["cadence_attribute"] = cadence_attribute
        pacsubgroup["rsd"] = rsd
        pacsubgroup["is_active"] = is_active
        pacsubgroup["summary_on"] = summary_on
        pacsubgroup["durations"] = durations
        pacsubgroup["base_features"] = base_features
        pacsubgroup["derived_features"] = derived_features
        pacsubgroup["distinct_features"] = [
            "CustomerCount"
        ]
        pacsubgroup["dimension_attribute_grain"] = {
            "ProductAttribute": "PacSubgroup",
            "CustomerAttribute": "All",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        pacsubgroup["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division",
                    "Department",
                    "Section",
                ],
                "join_key": ["PacSubgroup"]
            }
        ]
        pacsubgroup["dimension_attribute_null_filter"] = [
            "PacSubgroup"
        ]

        all = dict()
        all["name"] = "all_all_all_all"
        all["cadence_attribute"] = cadence_attribute
        all["rsd"] = rsd
        all["is_active"] = is_active
        all["summary_on"] = summary_on
        all["durations"] = durations
        all["base_features"] = base_features
        all["derived_features"] = derived_features
        all["distinct_features"] = [
            "DivisionCount",
            "DepartmentCount",
            "SectionCount",
            "PacSubgroupCount",
            "CustomerCount"
        ]
        all["dimension_attribute_grain"] = {
            "ProductAttribute": "All",
            "CustomerAttribute": "All",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }

        division_customer = dict()
        division_customer["name"] = "division_customer_all_all"
        division_customer["cadence_attribute"] = cadence_attribute
        division_customer["rsd"] = rsd
        division_customer["is_active"] = is_active
        division_customer["summary_on"] = summary_on
        division_customer["durations"] = durations
        division_customer["base_features"] = base_features
        division_customer["derived_features"] = derived_features
        division_customer["distinct_features"] = [
            "DepartmentCount",
            "SectionCount",
            "PacSubgroupCount"
        ]
        division_customer["dimension_attribute_grain"] = {
            "ProductAttribute": "Division",
            "CustomerAttribute": "Customer",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        division_customer["additional_dimension_attribute"] = []
        division_customer["dimension_attribute_null_filter"] = [
            "Division",
            "Customer"
        ]

        department_customer = dict()
        department_customer["name"] = "department_customer_all_all"
        department_customer["cadence_attribute"] = cadence_attribute
        department_customer["rsd"] = rsd
        department_customer["is_active"] = is_active
        department_customer["summary_on"] = summary_on
        department_customer["durations"] = durations
        department_customer["base_features"] = base_features
        department_customer["derived_features"] = derived_features
        department_customer["distinct_features"] = [
            "SectionCount",
            "PacSubgroupCount"
        ]
        department_customer["dimension_attribute_grain"] = {
            "ProductAttribute": "Department",
            "CustomerAttribute": "Customer",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        department_customer["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division"
                ],
                "join_key": ["Department"]
            }
        ]
        department_customer["dimension_attribute_null_filter"] = [
            "Department",
            "Customer"
        ]

        section_customer = dict()
        section_customer["name"] = "section_customer_all_all"
        section_customer["cadence_attribute"] = cadence_attribute
        section_customer["rsd"] = rsd
        section_customer["is_active"] = is_active
        section_customer["summary_on"] = summary_on
        section_customer["durations"] = durations
        section_customer["base_features"] = base_features
        section_customer["derived_features"] = derived_features
        section_customer["distinct_features"] = [
            "PacSubgroupCount"
        ]
        section_customer["dimension_attribute_grain"] = {
            "ProductAttribute": "Section",
            "CustomerAttribute": "Customer",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        section_customer["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division",
                    "Department"
                ],
                "join_key": ["Section"]
            }
        ]
        section_customer["dimension_attribute_null_filter"] = [
            "Section",
            "Customer"
        ]

        pacsubgroup_customer = dict()
        pacsubgroup_customer["name"] = "pacsubgroup_customer_all_all"
        pacsubgroup_customer["cadence_attribute"] = cadence_attribute
        pacsubgroup_customer["rsd"] = rsd
        pacsubgroup_customer["is_active"] = is_active
        pacsubgroup_customer["summary_on"] = summary_on
        pacsubgroup_customer["durations"] = durations
        pacsubgroup_customer["base_features"] = base_features
        pacsubgroup_customer["derived_features"] = derived_features
        pacsubgroup_customer["distinct_features"] = []
        pacsubgroup_customer["dimension_attribute_grain"] = {
            "ProductAttribute": "PacSubgroup",
            "CustomerAttribute": "Customer",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }
        pacsubgroup_customer["additional_dimension_attribute"] = [
            {
                "dimension": "Product",
                "attribute": [
                    "Division",
                    "Department",
                    "Section"
                ],
                "join_key": ["PacSubgroup"]
            }
        ]
        pacsubgroup_customer["dimension_attribute_null_filter"] = [
            "PacSubgroup",
            "Customer"
        ]

        all_customer = dict()
        all_customer["name"] = "all_customer_all_all"
        all_customer["cadence_attribute"] = cadence_attribute
        all_customer["rsd"] = rsd
        all_customer["is_active"] = is_active
        all_customer["summary_on"] = summary_on
        all_customer["durations"] = durations
        all_customer["base_features"] = base_features
        all_customer["derived_features"] = derived_features
        all_customer["distinct_features"] = [
            "DivisionCount",
            "DepartmentCount",
            "SectionCount",
            "PacSubgroupCount"
        ]
        all_customer["dimension_attribute_grain"] = {
            "ProductAttribute": "All",
            "CustomerAttribute": "Customer",
            "StoreAttribute": "All",
            "ChannelAttribute": "All"
        }

        expected = dict()
        expected["0"] = division
        expected["1"] = department
        expected["2"] = section
        expected["3"] = pacsubgroup
        expected["4"] = all
        expected["5"] = division_customer
        expected["6"] = department_customer
        expected["7"] = section_customer
        expected["8"] = pacsubgroup_customer
        expected["9"] = all_customer

        self.feature_specs_obj.get_levels()
        actual = self.feature_specs_obj.start()

        self.assertEqual(actual, expected)