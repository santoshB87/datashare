from decimal import Decimal
import datetime
from dunnhumby import contexts
from dunnhumby.cmp_entities.dates import Dates
from dunnhumby.cmp_entities.transactions import Transactions
from dunnhumby.cmp_entities.products import Products
from dunnhumby.cmp_entities.customers import Customers
from dunnhumby.cmp_entities.channels import Channels
from dunnhumby.cmp_entities.stores import Stores
from pyspark.sql.types import StructType, StructField, StringType, BooleanType


def cleardown():
    contexts.sql_context().sql('drop table if exists client_pob.channel_customer_product_store_features')


class MyDates(Dates):
    def __init__(self, config):
        super(MyDates, self).__init__()
        self.config = config
        dates_schema = self.required_schema
        l = [
            (datetime.date(2017, 9, 3), '3rd September, 2017', '2017-09-03', 'Sunday', '201719', 7),
            (datetime.date(2017, 9, 4), '4th September, 2017', '2017-09-04', 'Monday', '201720', 1),
            (datetime.date(2017, 9, 5), '5th September, 2017', '2017-09-05', 'Tuesday', '201720', 2),
            (datetime.date(2017, 9, 6), '6th September, 2017', '2017-09-06', 'Wednesday', '201720', 3),
            (datetime.date(2017, 9, 7), '7th September, 2017', '2017-09-07', 'Thursday', '201720', 4),
            (datetime.date(2017, 9, 8), '8th September, 2017', '2017-09-08', 'Friday', '201720', 5),
            (datetime.date(2017, 9, 9), '9th September, 2017', '2017-09-09', 'Saturday', '201720', 6),
            (datetime.date(2017, 9, 10), '10th September, 2017', '2017-09-10', 'Sunday', '201720', 7),
            (datetime.date(2017, 9, 11), '11th September, 2017', '2017-09-11', 'Monday', '201721', 1),
            (datetime.date(2017, 9, 12), '12th September, 2017', '2017-09-12', 'Tuesday', '201721', 2)
        ]
        df = self.sqlContext.createDataFrame(l, dates_schema)
        self.data = df

class MyTransactions(Transactions):
    def __init__(self, config):
        super(MyTransactions, self).__init__()
        self.config = config
        schema = self.required_schema
        l = [
            ('basket1', datetime.date(2017, 9, 04),
             'Football Shorts', 'John Doe', 'Brook green', 'InStore',
             8, Decimal(10.99), Decimal(9.99), Decimal(1.00)),
            ('basket1', datetime.date(2017, 9, 04),
             'Girls school shirt', 'John Doe', 'Brook green', 'InStore',
             6, Decimal(8.99), Decimal(6.99), Decimal(2.00)),
            ('basket1', datetime.date(2017, 9, 04),
             'Boys school shirt', 'John Doe', 'Brook green', 'InStore',
             3, Decimal(7.99), Decimal(4.99), Decimal(3.00)),
            ('basket1', datetime.date(2017, 9, 04),
             'Adult work shirt', 'John Doe', 'Brook green', 'InStore',
             1, Decimal(8.99), Decimal(2.99), Decimal(6.00)),
            ('basket1', datetime.date(2017, 9, 04),
             'Boys school trousers', 'John Doe', 'Brook green', 'InStore',
             1, Decimal(10.99), Decimal(1.50), Decimal(9.45)),
            ('basket2', datetime.date(2017, 9, 04),
             'Boys school shirt', 'Jane Doe', 'Brook green', 'InStore',
             3, Decimal(7.99), Decimal(4.99), Decimal(3.00))
        ]
        df = self.sqlContext.createDataFrame(l, schema)
        self.data = df


class MyProducts(Products):
    def __init__(self, config):
        super(MyProducts, self).__init__()
        self.config = config
        schema = StructType()
        schema.add(StructField('Product', StringType(), True))
        schema.add(StructField('ProductDescription', StringType(), True))
        schema.add(StructField('Subgroup', StringType(), True))
        schema.add(StructField('SubgroupDescription', StringType(), True))
        l = [
            ('Football Shorts', 'Football Shorts', 'Mixed Sportswear', 'Mixed Sportswear'),
            ('Girls school shirt', 'Girls school shirt', 'Girls Schoolwear', 'Girls Schoolwear'),
            ('Boys school shirt', 'Boys school shirt', 'Boys Schoolwear', 'Boys Schoolwear'),
            ('Boys school trousers', 'Boys school trousers', 'Boys Schoolwear', 'Boys Schoolwear'),
            ('Adult work shirt', 'Adult work shirt', 'Adult Workwear', 'Adult Workwear')
        ]
        df = self.sqlContext.createDataFrame(l, schema)
        df = MyProducts.DeriveDefaultGroupAndDescription(df)
        df = MyProducts.DeriveDefaultSectionAndDescription(df)
        df = MyProducts.DeriveDefaultDepartmentAndDescription(df)
        df = MyProducts.DeriveDefaultDivisionAndDescription(df)
        df = MyProducts.DeriveDefaultInstoreShelfAndDescription(df)
        df = MyProducts.DeriveDefaultInstoreSubAisleAndDescription(df)
        df = MyProducts.DeriveDefaultInstoreAisleAndDescription(df)
        df = MyProducts.DeriveDefaultInstoreSubAreaAndDescription(df)
        df = MyProducts.DeriveDefaultInstoreAreaAndDescription(df)
        df = MyProducts.DeriveDefaultDepartmentAndDescription(df)
        df = MyProducts.DeriveDefaultIsBaby(df)
        df = MyProducts.DeriveDefaultIsPet(df)
        df = MyProducts.DeriveDefaultConsumptionType(df)
        df = MyProducts.DeriveDefaultProductBrand(df)
        df = MyProducts.DeriveDefaultIsAlcohol(df)
        df = MyProducts.DeriveDefaultProductImageUri(df)
        df = MyProducts.DeriveDefaultIsSoldByWeight(df)
        df = MyProducts.DeriveDefaultProductSupplier(df)
        self.data = df


class MyCustomers(Customers):
    def __init__(self, config):
        super(MyCustomers, self).__init__()
        self.config = config
        schema = StructType()
        schema.add(StructField('Customer', StringType(), True))
        schema.add(StructField('IsEmailable', BooleanType(), True))
        schema.add(StructField('SloyaltyHigh', StringType(), True))
        schema.add(StructField('SloyaltyLow', StringType(), True))
        schema.add(StructField('FulfillmentStore', StringType(), True))
        schema.add(StructField('PreferredStore1', StringType(), True))
        schema.add(StructField('PreferredStore2', StringType(), True))
        schema.add(StructField('PreferredStore3', StringType(), True))
        schema.add(StructField('CustomerRegion', StringType(), True))
        l = [('John Doe', False, '', '', '', '', '', '', 'Ealing'),
             ('Jane Doe', False, '', '', '', '', '', '', 'Hammersmith')]
        df = self.sqlContext.createDataFrame(l, schema)
        df = self.DeriveDefaultCustomerGender(df)
        df = self.DeriveDefaultCustomerAgeRange(df)
        df = self.DeriveDefaultCustomerPriceSensitivity(df)
        df = self.DeriveDefaultIsMailable(df)
        df = self.DeriveDefaultIsBlacklisted(df)
        df = self.DeriveDefaultIsScottish(df)
        df = self.DeriveDefaultIsBabyCompliant(df)
        df = self.DeriveDefaultIsBabyAddrSupress(df)
        df = self.DeriveDefaultIsBereaved(df)
        df = self.DeriveDefaultIsDiabetic(df)
        df = self.DeriveDefaultIsHalal(df)
        df = self.DeriveDefaultIsKosher(df)
        df = self.DeriveDefaultIsTeetotal(df)
        df = self.DeriveDefaultIsVegetarian(df)
        df = self.DeriveDefaultIsAddrSuppress(df)
        df = self.DeriveDefaultSloyaltyHigh(df)
        df = self.DeriveDefaultSloyaltyHighDescription(df)
        df = self.DeriveDefaultSloyaltyLowDescription(df)
        df = self.DeriveDefaultPreferredStoreFormat(df)
        df = self.DeriveDefaultCustomerPriceSensitivityDescription(df)
        df = self.DeriveDefaultCustomerLifeStage(df)
        df = self.DeriveDefaultCustomerLifeStageDescription(df)
        df = self.DeriveDefaultCustomerLifeStyle(df)
        df = self.DeriveDefaultCustomerLifeStyleDescription(df)
        df = df.select('Customer', 'IsEmailable', 'IsBlacklisted', 'IsMailable', 'IsScottish', 'IsBabyCompliant', 'IsBabyAddrSupress', 'IsBereaved', 'IsDiabetic',
                                'IsHalal', 'IsKosher', 'IsTeetotal', 'IsVegetarian', 'IsAddrSuppress', 'SloyaltyHigh', 'SloyaltyHighDescription', 'SloyaltyLow',
                                         'SloyaltyLowDescription', 'FulfillmentStore', 'PreferredStore1', 'PreferredStore2',
                                         'PreferredStore3', 'PreferredStoreFormat', 'CustomerGender', 'CustomerAgeRange', 'CustomerPriceSensitivity',
             'CustomerPriceSensitivityDescription', 'CustomerRegion', 'CustomerLifeStage', 'CustomerLifeStageDescription', 'CustomerLifeStyle', 'CustomerLifeStyleDescription')
        self.data = df


class MyChannels(Channels):
    def __init__(self, config):
        super(MyChannels, self).__init__()
        self.config = config
        schema = StructType()
        schema.add(StructField('Channel', StringType(), True))
        schema.add(StructField('ChannelDescription', StringType(), True))
        l = [('A channel', 'A channel')]
        df = self.sqlContext.createDataFrame(l, schema)
        self.data = df


class MyStores(Stores):
    def __init__(self, config):
        super(MyStores, self).__init__()
        self.config = config
        schema = StructType()
        schema.add(StructField('Store', StringType(), True))
        schema.add(StructField('StoreDescription', StringType(), True))
        l = [('Brook green', 'Brook green')]
        df = self.sqlContext.createDataFrame(l, schema)
        df = self.DeriveDefaultBanner(df)
        df = self.DeriveDefaultStoreRegion(df)
        self.data = df
