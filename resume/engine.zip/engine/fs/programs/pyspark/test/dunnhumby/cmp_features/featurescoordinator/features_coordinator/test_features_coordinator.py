import unittest
import dunnhumby.cmp_features.purchasingfeaturecoordinator as base
from pyspark.sql.types import *
from test.dunnhumby.cmp_features.featurescoordinator.TestSetup import MyDates
from dunnhumby.cmp_features.featurescoordinatorbase import *


class MyPurchasingFeatureCoordinator(base.PurchasingFeatureCoordinator):
    """Need an implementation of PurchasingFeatureCoordinator in order to test its methods"""
    def __init__(self, config, cadence_attribute, run_date=datetime.date.today()):
        super(MyPurchasingFeatureCoordinator, self).__init__(config, cadence_attribute, run_date)
        self.Dates = MyDates(config)

    def Transactions(self):
        pass

    @property
    def Dates(self):
        return self.__Dates

    @Dates.setter
    def Dates(self, value):
        self.__Dates = value

    @property
    def Product(self):
        pass

    @property
    def Channel(self):
        pass

    @property
    def Customer(self):
        pass

    @property
    def Store(self):
        pass


class DummyFeaturesCoordinatorThatNamesExistingSupplementaryDataframe(CMPFeaturesCoordinator):
    def __init__(self):
        super(DummyFeaturesCoordinatorThatNamesExistingSupplementaryDataframe, self).__init__()

        self.dimension_grain = set(['Customer'])
        self.features_specifications = [
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All"
                },
                "rsd": 0.0,
                "features": [
                    "Baskets_1w1w", "Quantity_1w1w", "NetSpend_1w1w",
                    "Baskets_1w4w", "Quantity_1w4w", "NetSpend_1w4w",
                    "Baskets_1w13w", "Quantity_1w13w", "NetSpend_1w13w",
                    "Baskets_1w26w", "Quantity_1w26w", "NetSpend_1w26w",
                    "Baskets_1w52w", "Quantity_1w52w", "NetSpend_1w52w"
                ],
                "supplementary_dataframes": [{"entity": "Stores", "fields": ["field1"]}]
            }
        ]


class TestFeaturesCoordinator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        # cls.spark_context.stop()
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_dimension_grain_must_be_a_set(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(TypeError, 'Value supplied for dimension_grain must be a set'):
            fc.dimension_grain = 1

    def test_unknown_dimension_in_dimension_grain_raises_valueerror(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError, ' is not a valid dimension. Valid dimensions are '):
            fc.dimension_grain = {'Product', 'Customer', 'Stroe'}

    def test_value_assigned_to_features_specifications_must_be_a_list(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(TypeError,
                                     'Value to be assigned to property features_specifications must be a list'):
            fc.features_specifications = 'I am not a list'

    def test_value_assigned_to_features_specifications_must_be_a_list_containing_at_least_one_element(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError,
                                     'Value to be assigned to property features_specifications must be a list with length > 0'):
            fc.features_specifications = []

    def test_each_element_in_features_specifications_list_must_be_a_dict(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(TypeError,
                                     'Every element of the list assigned to property features_specifications must be a dict'):
            fc.features_specifications = ['I am not a dict']

    def test_each_features_specification_in_features_specifications_property_has_an_is_active_key(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError,
                                     'Each dict of the list assigned to property features_specifications must have an is_active key'):
            fc.features_specifications = [{"cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_each_features_specification_in_features_specifications_property_has_a_cadence_attribute_key(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError,
                                     'Each dict of the list assigned to property features_specifications must have a cadence_attribute key'):
            fc.features_specifications = [{"is_active": True, "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                                            "ProductAttribute": "All",
                                                                                            "StoreAttribute": "All",
                                                                                            "ChannelAttribute": "All"},
                                           "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_each_features_specification_in_features_specifications_property_has_a_dimension_attribute_grain_key(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError,
                                     'Each dict of the list assigned to property features_specifications must have a dimension_attribute_grain key'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id", "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_each_features_specification_in_features_specifications_property_has_a_rsd_key(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError,
                                     'Each dict of the list assigned to property features_specifications must have a rsd key'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"},
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_each_features_specification_in_features_specification_property_has_a_features_key(self):
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError,
                                     'Each dict of the list assigned to property features_specifications must have a features key'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0}]

    def test_value_assigned_to_is_active_key_must_be_in_domain_of_allowable_values(self):
        """
        This regex test might help to understand this test: https://regex101.com/r/Fg4EcV/3
        :return:
        """
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError, 'Value of is_active key must be one of \[[A-Za-z,\s]*\]'):
            fc.features_specifications = [{"is_active": "1", "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_value_assigned_to_cadence_attribute_key_must_be_in_domain_of_allowable_values(self):
        """
        This regex test might help to understand this test: https://regex101.com/r/Fg4EcV/2
        At time of writing the allowable values are:
        - fis_week_id
        - date_short_name
        :return:
        """
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(ValueError, 'Value of cadence_attribute key must be one of \[[A-Za-z,\s_\']*\]'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "day",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_value_assigned_to_features_specifications_dimension_attribute_grain_must_be_a_dict(self):
        """
        :return:
        """
        fc = CMPFeaturesCoordinator()
        with self.assertRaisesRegexp(TypeError,
                                     'Value to be assigned to dimension_attribute_grain of a features_specification must be a dict'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": "This is not a dict", "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_value_assigned_to_features_specification_dimension_attribute_grain_must_have_an_entry_for_element_of_property_dimension_grain(
            self):
        """
        :return:
        """
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError, 'An attribute must be supplied for each dimension in dimension_grain'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"]}]

    def test_value_assigned_to_supplementary_dataframes_must_be_a_list(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(TypeError,
                                     'Value to be assigned to supplementary_dataframes of a feature specification must be a list'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": "not a list"}]

    def test_each_element_in_supplementary_dataframes_list_must_be_a_dict(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(TypeError,
                                     'Every element of the list assigned to property supplementary_dataframes must be a dict'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": ["not a dict"]}]

    def test_each_supplementary_dataframe_dict_must_have_a_key_called_entity(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError,
                                     'Each supplementary_dataframe dict must have a key called "entity"'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [{}]}]

    def test_each_entity_specified_in_a_supplementary_dataframe_is_of_type_str(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(TypeError,
                                     'Each value given for entity key in a supplementary_dataframe dict must be a string'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [{"entity": 1}]}]

    def test_each_supplementary_dataframe_dict_must_have_a_key_called_fields(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError,
                                     'Each supplementary_dataframe dict must have a key called "fields"'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [{"entity": "some_entity"}]}]

    def test_each_field_specified_in_a_supplementary_dataframe_is_a_list_or_an_asterisk(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError,
                                     'Each value given for fields key in a supplementary_dataframe dict must be a list or *'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [
                                               {"entity": "Stores", "fields": "a_string"}]}]
        fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                       "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                     "ProductAttribute": "All",
                                                                     "StoreAttribute": "All",
                                                                     "ChannelAttribute": "All"}, "rsd": 0.0,
                                       "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                       "supplementary_dataframes": [{"entity": "Stores", "fields": "*"}]}]
        self.assertTrue(fc.features_specifications)
        fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                       "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                     "ProductAttribute": "All",
                                                                     "StoreAttribute": "All",
                                                                     "ChannelAttribute": "All"}, "rsd": 0.0,
                                       "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                       "supplementary_dataframes": [{"entity": "Stores", "fields": ["field1"]}]}]
        self.assertTrue(fc.features_specifications)

    def test_where_fields_specified_in_a_supplementary_dataframe_is_a_list_that_it_is_not_an_empty_list(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError,
                                     'List of fields specified in a supplementary_dataframe dict must be non empty'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [
                                               {"entity": "some_entity", "fields": []}]}]

    def test_fields_specified_in_a_supplementary_dataframe_must_be_strings(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError,
                                     'Fields specified in a supplementary_dataframe dict must be strings'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [
                                               {"entity": "some_entity", "fields": ["field1", 2]}]}]

    def test_fields_specified_in_a_supplementary_dataframe_must_be_unique(self):
        fc = CMPFeaturesCoordinator()
        fc.dimension_grain = {'Customer', 'Product', 'Store', 'Channel'}
        with self.assertRaisesRegexp(ValueError,
                                     'Fields specified in a supplementary_dataframe dict must be unique'):
            fc.features_specifications = [{"is_active": True, "cadence_attribute": "fis_week_id",
                                           "dimension_attribute_grain": {"CustomerAttribute": "All",
                                                                         "ProductAttribute": "All",
                                                                         "StoreAttribute": "All",
                                                                         "ChannelAttribute": "All"}, "rsd": 0.0,
                                           "features": ["Quantity_1w1w", "Quantity_1w4w", "Baskets_1w_13w"],
                                           "supplementary_dataframes": [
                                               {"entity": "some_entity", "fields": ["field1", "field1"]}]}]

    def test_when_cadence_attribute_is_fis_week_id_then_cadence_is_prior_week_to_run_date(self):
        config = {"SSEHiveDatabasePrefix": "client"}
        fc = MyPurchasingFeatureCoordinator(config, 'fis_week_id', datetime.date(2017,9,5))
        self.assertEqual(fc.cadence, '201719')

    def test_when_cadence_attribute_is_date_short_name_then_cadence_is_prior_day_to_run_date(self):
        config = {"SSEHiveDatabasePrefix": "client"}
        fc = MyPurchasingFeatureCoordinator(config, 'date_short_name', datetime.date(2017,9,5))
        self.assertEqual(fc.cadence, '2017-09-04')