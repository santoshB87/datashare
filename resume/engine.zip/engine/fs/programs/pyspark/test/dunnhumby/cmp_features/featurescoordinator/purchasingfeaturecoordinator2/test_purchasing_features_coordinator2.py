import unittest
from dunnhumby.cmp_features.featurescoordinatorbase import *
import dunnhumby.cmp_features.purchasingfeaturecoordinator2 as base
from pyspark.sql.types import *
from test.dunnhumby.cmp_features.featurescoordinator.TestSetup import MyDates


class MyPurchasingFeatureCoordinator2(base.PurchasingFeatureCoordinator2):
    """Need an implementation of PurchasingFeatureCoordinator in order to test its methods"""
    def __init__(self, config, cadence_attribute, run_date=datetime.date.today()):
        super(MyPurchasingFeatureCoordinator2, self).__init__(config, cadence_attribute, run_date)
        self.Dates = MyDates(config)
        self.features_specifications = [
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All", "ProductAttribute": "Subgroup",
                    "StoreAttribute": "All", "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": ["Baskets_1w1w"]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "All", "ProductAttribute": "InstoreAisle",
                    "StoreAttribute": "All", "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": ["Baskets_1w1w"]
            },
            {
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "Customer", "ProductAttribute": "Subgroup",
                    "StoreAttribute": "All", "ChannelAttribute": "All"
                },
                "rsd": 0.0,
                "features": ["Baskets_1w1w"]
            },
            {
                "cadence_attribute": "date_short_name",
                "is_active": True,
                "dimension_attribute_grain": {
                    "CustomerAttribute": "CustomerGender", "ProductAttribute": "Group",
                    "StoreAttribute": "Banner", "ChannelAttribute": "Channel"
                },
                "rsd": 0.0,
                "features": ["Baskets_1w1w"]
            }]

    def Transactions(self):
        pass

    @property
    def Dates(self):
        return self.__Dates

    @Dates.setter
    def Dates(self, value):
        self.__Dates = value

    @property
    def Product(self):
        pass

    @property
    def Channel(self):
        pass

    @property
    def Customer(self):
        pass

    @property
    def Store(self):
        pass



class TestPurchasingFeaturesCoordinator2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        # cls.spark_context.stop()
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_when_cadence_attribute_is_fis_week_id_then_cadence_is_prior_week_to_run_date(self):
        config = {"SSEHiveDatabasePrefix": "client"}
        fc = MyPurchasingFeatureCoordinator2(config, 'fis_week_id', datetime.date(2017, 9, 5))
        self.assertEqual(fc.cadence, '201719')

    def test_when_cadence_attribute_is_date_short_name_then_cadence_is_prior_day_to_run_date(self):
        config = {"SSEHiveDatabasePrefix": "client"}
        fc = MyPurchasingFeatureCoordinator2(config, 'date_short_name', datetime.date(2017, 9, 5))
        self.assertEqual(fc.cadence, '2017-09-04')

    def test_all_entity_attributes(self):
        """property all_product_attributes returns the union of all product attributes named in
        features_specifications. Similarly for Customer, Store & Channel"""
        config = {"SSEHiveDatabasePrefix": "client"}
        fc = MyPurchasingFeatureCoordinator2(config, 'fis_week_id', datetime.date(2017, 9, 5))
        self.assertEqual(sorted(fc.all_required_product_attributes), sorted(set(['Product', 'Subgroup', 'InstoreAisle'])))
        self.assertEqual(sorted(fc.all_required_customer_attributes), sorted(set(['Customer'])))
        self.assertEqual(sorted(fc.all_required_store_attributes), sorted(set(['Store'])))
        self.assertEqual(sorted(fc.all_required_channel_attributes), sorted(set(['Channel'])))
        config = {"SSEHiveDatabasePrefix": "client"}
        fc = MyPurchasingFeatureCoordinator2(config, 'date_short_name', datetime.date(2017, 9, 5))
        self.assertEqual(sorted(fc.all_required_product_attributes), sorted(set(['Product', 'Group'])))
        self.assertEqual(sorted(fc.all_required_customer_attributes), sorted(set(['Customer', 'CustomerGender'])))
        self.assertEqual(sorted(fc.all_required_store_attributes), sorted(set(['Store', 'Banner'])))
        self.assertEqual(sorted(fc.all_required_channel_attributes), sorted(set(['Channel'])))