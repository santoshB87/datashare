import unittest
from pyspark import SparkConf
from pyspark.sql.types import *
from dunnhumby import contexts
from dunnhumby.cmp_features.featureswriter import FeaturesWriter


# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)


class TestFeaturesWriter(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_feature_table_name(self):
        columns = set(['a', 'b'])
        self.assertEqual(FeaturesWriter._get_feature_table_name(columns), 'a_b_features')

    def test_get_feature_table_name_order_of_specific_columns_is_correct(self):
        columns = set(['b', 'a'])
        self.assertEqual(FeaturesWriter._get_feature_table_name(columns), 'a_b_features')

    def test_get_create_table_sql_statement(self):
        database_name = 'gonzo'
        dimension_grain = set(['Product', 'Customer'])
        file_format = 'PARQUET'
        self.assertEqual(
            FeaturesWriter._get_create_table_sql_statement(database_name, dimension_grain, file_format),
            "CREATE EXTERNAL TABLE IF NOT EXISTS gonzo.Customer_Product_features (Customer STRING, Product STRING, created_at TIMESTAMP) PARTITIONED BY (CadenceAttribute STRING, Cadence STRING, CustomerAttribute STRING, ProductAttribute STRING) STORED AS PARQUET"
        )

    # commented out because it causes a call to an external data source, and I haven't yet figured out a way of mocking those calls
    # def test_get_alter_table_sql_statement(self):
    #     database_name = 'gonzo'
    #     dimension_grain = set(['Product', 'Customer'])
    #
    #     schema = StructType([
    #         StructField("Customer", StringType(), True),
    #         StructField("Product", StringType(), True),
    #         StructField("a", StringType(), True),
    #         StructField("b", StringType(), True)])
    #     df = self.sqlContext.createDataFrame([('john doe', 'oranges', 'a value', 'b value')], schema)
    #     self.assertEqual(
    #         FeaturesWriter._get_alter_table_sql_statement(self.sqlContext, database_name, dimension_grain,
    #                                                       df.schema.fields),
    #         "ALTER TABLE gonzo.Customer_Product ADD COLUMNS (a string, b bigint)"
    #     )

    def test_error_is_raised_when_no_value_is_supplied_for_a_partition_column(self):
        with self.assertRaisesRegexp(ValueError, 'must include an item with key'):
            FeaturesWriter._check_value_has_been_supplied_for_each_partition_column(['Product'],
                                                                                    ChannelAttribute='Department')

    def test_error_is_raised_when_value_supplied_for_a_partition_column_is_not_of_type_str(self):
        with self.assertRaisesRegexp(TypeError, 'Value supplied for \w*Attribute must be of type str'):
            FeaturesWriter._check_value_has_been_supplied_for_each_partition_column(['Product'], ProductAttribute=1)

    def test_no_error_is_raised_when_valid_values_for_all_partition_columns_are_supplied(self):
        self.assertEquals(
            FeaturesWriter._check_value_has_been_supplied_for_each_partition_column(
                ['Product', 'Customer', 'Store', 'Channel'],
                ProductAttribute='Department',
                StoreAttribute='Banner',
                ChannelAttribute='Channel',
                CustomerAttribute='Gender'
            ),
            None
        )

    def test_get_insert_statement_with_overwrite(self):
        df = self.sqlContext.createDataFrame(
            [('Beans', 'JohnD', 'Brook Green', 'Online', 5)],
            StructType(
                [StructField("Product", StringType(), True), StructField("Customer", StringType(), True),
                 StructField("Store", StringType(), True), StructField("Channel", StringType(), True),
                 StructField("fop_1w1w", IntegerType(), True)]
            )
        )
        self.assertEquals(
            FeaturesWriter._get_insert_statement(database_name='mydb', df=df,
                                                 dimension_grain=['Product', 'Customer', 'Store', 'Channel'],
                                                 feature_table_name='table_name',
                                                 table_field_names=['productattribute', 'customerattribute',
                                                                    'storeattribute',
                                                                    'channelattribute', 'product', 'customer', 'store',
                                                                    'channel',
                                                                    'fop_1w1w', 'qty_1w1w'],
                                                 CadenceAttribute='weekly',
                                                 Cadence='1950W01',
                                                 ProductAttribute='Subgroup',
                                                 CustomerAttribute='Gender',
                                                 StoreAttribute='Banner',
                                                 ChannelAttribute='Instore'),
            "INSERT OVERWRITE TABLE mydb.table_name PARTITION (CadenceAttribute='weekly', Cadence='1950W01', ProductAttribute='Subgroup', CustomerAttribute='Gender', StoreAttribute='Banner', ChannelAttribute='Instore') SELECT Product, Customer, Store, Channel, fop_1w1w, NULL as qty_1w1w FROM {df}"
        )

    def test_get_insert_statement_with_no_overwrite(self):
        df = self.sqlContext.createDataFrame(
            [('Beans', 'JohnD', 'Brook Green', 'Online', 5)],
            StructType(
                [StructField("Product", StringType(), True), StructField("Customer", StringType(), True),
                 StructField("Store", StringType(), True), StructField("Channel", StringType(), True),
                 StructField("fop_1w1w", IntegerType(), True)]
            )
        )
        self.assertEquals(
            FeaturesWriter._get_insert_statement(database_name='mydb', df=df,
                                                 dimension_grain=['Product', 'Customer', 'Store', 'Channel'],
                                                 feature_table_name='table_name',
                                                 table_field_names=['productattribute', 'customerattribute',
                                                                    'storeattribute',
                                                                    'channelattribute', 'product', 'customer', 'store',
                                                                    'channel',
                                                                    'fop_1w1w', 'qty_1w1w'],
                                                 CadenceAttribute='weekly',
                                                 Cadence='1950W01',
                                                 ProductAttribute='Subgroup',
                                                 CustomerAttribute='Gender',
                                                 StoreAttribute='Banner',
                                                 ChannelAttribute='Instore',
                                                 overwrite=False),
            "INSERT INTO TABLE mydb.table_name PARTITION (CadenceAttribute='weekly', Cadence='1950W01', ProductAttribute='Subgroup', CustomerAttribute='Gender', StoreAttribute='Banner', ChannelAttribute='Instore') SELECT Product, Customer, Store, Channel, fop_1w1w, NULL as qty_1w1w FROM {df}"
        )

    def test_get_prefix(self):
        dimension_grain = set(['Customer', 'Product'])
        dimension_attribute_grain = {"CustomerAttribute": "All", "ProductAttribute": "All"}
        self.assertEqual(FeaturesWriter._get_prefix(dimension_grain,dimension_attribute_grain), 'CustomerAll_ProductAll_')

