"""
Mocked sample data set - being used in unit test cases of PurchasingFeatureGeneratorBase
"""

from decimal import Decimal
from datetime import datetime as dt
import datetime
from collections import OrderedDict
from os import path
from copy import deepcopy
from pyspark.sql import functions as pf, types as pt
from dunnhumby import contexts
from dunnhumby.cmp_entities.transactions import Transactions as TransactionsBase
from dunnhumby.cmp_entities.purchases import Purchases as PurchasesBase
from dunnhumby.cmp_features.purchasing_feature_generator_base import PurchasingFeatureGeneratorBase

sqlContext = contexts.sql_context()

"""
Client config for test cases
"""
test_config = {
    "client": "dunnhumby",
    "SSEHiveDatabasePrefix": "client",
    "SSEProductHierarchy": ["Division", "Section", "Group", "Subgroup", "Product"],
    "SSEHiveWarehousePath": "/user/hive/warehouse",
    "SSEHiveWarehousedb": "client_media_mart",
    "SSEHiveWorkdb": "client_ssework",
    "SSEHivePobdb": "client_pob",
    "SSEHivePurchaseTab": "purchase_fct",
    "SSEHiveTransactionTab": "transactions",
    "SSEFeatureLogTab": "feature_run_log",
    "SSEFeatureDistinctTab": "feature_distinct_tab",
    "SSEFeatureDurations": [[1, 1], [1, 4]],
    "SSEFeaturePacFlag": "False",
    "SSEFeatureBucketingFlag": "False",
    "SSEFeatureCleanRun": "False",
    "SSEFeaturePaarFlag": "False",
    "filters": {
        "products": {
            "filter_condition": "(product is not null) and ((subgroup is not null) or (group is not null) or (section is not null) or (department is not null) or (division is not null))"
        }
    },
    # Data purging feature is controlled by SSEFeatureDataPurge (accept boolean value), it can be
    # tuned on/off. Specific behaviour of data retention in different stages are controlled by their
    # respective config values.
    # SSEFeatureDataPurgeMergeRetentionWeekNum - define data retention period for purchases and
    # summary tables. Any data beyond (T - n) weeks will be deleted (here T is week of day on which
    # process is launched/executed).
    # SSEFeatureDataPurgeMergeRetentionWeekNum - define data retention period for merge tables.
    # Any feature generated beyond (T - n) weeks will be deleted (here T is week of day on which
    # process is launched/executed).
    "SSEFeatureDataPurge": "False",
    "SSEFeatureDataPurgeRetentionWeekNum": 108,
    "SSEFeatureDataPurgePublishedRetentionWeekNum": 6,
    # Number of partition used for coalescing, before writing denorm/purchase table to disk/hive
    "SSEFeaturePurchaseRePartitionNum": 1,
    # In wave we are specifying two types of setting which will determine extent of parallelism in
    # our feature calculation process WorkerNum specifies how many parallel job can run and
    # ShufflePart will used to set value for spark.sql.shuffle.partitions
    # In denom section customer_df would be repartitioned as per shufflePart value
    "SSEFeatureDenormWave": {'WorkerNum': 2, 'ShufflePart': 1, "cacheReplica": 1},
    "SSEFeatureSummaryWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureSummaryWave2": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave2": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave3": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave4": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureMergeWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureMergeWave2": {'WorkerNum': 1, 'ShufflePart': 1},
}

"""
Setup sqls
"""
setup_sql = {
    "drop_db_media_mart": "DROP DATABASE IF EXISTS client_media_mart CASCADE",
    "drop_db_ssework": "DROP DATABASE IF EXISTS client_ssework CASCADE",
    "drop_db_pob": "DROP DATABASE IF EXISTS client_pob CASCADE",
    "create_db_media_mart": "CREATE DATABASE IF NOT EXISTS client_media_mart "
                            "LOCATION '/user/hive/warehouse/client_media_mart'",
    "create_db_ssework": "CREATE DATABASE IF NOT EXISTS client_ssework "
                         "LOCATION '/user/hive/warehouse/client_ssework'",
    "create_db_pob": "CREATE DATABASE IF NOT EXISTS client_pob LOCATION "
                     "'/user/hive/warehouse/client_pob'",
    "drop_transaction_item_fct": "DROP TABLE IF EXISTS client_media_mart.transactions",
    "drop_purchase_fct": "DROP TABLE IF EXISTS client_ssework.purchase_fct",
    "create_transaction_item_fct": "CREATE TABLE client_media_mart.transactions( "
                                   "basket string, datetime timestamp, product string, customer string,"
                                   "store string, channel string, quantity int, spendamount decimal(15,2),"
                                   "netspendamount decimal(15,2), discountamount decimal(15,2))"
                                   "PARTITIONED BY (fis_year_id int, fis_week_id int, date_id date)"
                                   "STORED AS PARQUET",
    "ins_transaction_item_fct": "INSERT INTO client_media_mart.transactions PARTITION(fis_year_id, fis_week_id, date_id) "
                                "SELECT * FROM client_ssework.temp_trans",
    "create_purchase_fct": "CREATE TABLE IF NOT EXISTS client_ssework.purchase_fct (basket string, "
                           "division string, section string, group string, subgroup string, "
                           "product string, customer string, store string, banner string,fulfillmentstore string,"
                           " preferredstore1 string, preferredstore2 string, preferredstore3 string"
                           ", channel string, quantity decimal(24,2), netspendamount decimal(38,2),"
                           " spendamount decimal(38,2), discountamount decimal(38,2)) "
                           "PARTITIONED BY (fis_week_id string, date_id string) STORED AS PARQUET "
                           'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_purchase_fct": "INSERT INTO client_ssework.purchase_fct PARTITION(fis_week_id, date_id) "
                        "SELECT * FROM client_ssework.temp_purchase",
    "drop_all_all_all_all_summary": "DROP TABLE IF EXISTS client_ssework.all_all_all_all_summary",
    "create_all_all_all_all_summary": "CREATE TABLE IF NOT EXISTS client_ssework.all_all_all_all_"
                                      "summary (Product string,Customer string,Store string,Channel"
                                      " string,Baskets bigint,BasketWeeks int,Discount decimal(38, "
                                      "2),MaximumPrice decimal(38, 2),MinimumPrice decimal(38, 2),"
                                      "MaximumNetPrice decimal(38, 2),MinimumNetPrice decimal(38, "
                                      "2),Quantity decimal(24, 2),QuantityPrefStore1 decimal(24, 2)"
                                      ",QuantityPrefStore2 decimal(24, 2),QuantityPrefStore3 "
                                      "decimal(24, 2),QuantityFulfillmentStore decimal(24, 2),"
                                      "GrossSpend decimal(38, 2),NetSpend decimal(38, 2),"
                                      "MaxPurchaseDate int,MinPurchaseDate int) "
                                      "PARTITIONED BY (fis_week_id string) STORED AS PARQUET "
                                      'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_all_all_all_all_summary": "INSERT INTO client_ssework.all_all_all_all_summary PARTITION("
                                   "fis_week_id) SELECT * FROM client_ssework.temp_all_all_all_all"
                                   "_summary",
    "drop_product_customer_all_all_summary": "DROP TABLE IF EXISTS client_ssework.product_customer"
                                             "_all_all_summary",
    "create_product_customer_all_all_summary": "CREATE TABLE IF NOT EXISTS client_ssework.product_"
                                               "customer_all_all_summary (Product string,"
                                               "Customer string,Store string,Channel string,Baskets"
                                               " bigint,BasketWeeks int,Discount decimal(38, 2),"
                                               "MaximumPrice decimal(38, 2),MinimumPrice decimal(38"
                                               ", 2),MaximumNetPrice decimal(38, 2),MinimumNetPrice"
                                               " decimal(38, 2),Quantity decimal(24, 2),QuantityPre"
                                               "fStore1 decimal(24, 2),QuantityPrefStore2 decimal("
                                               "24, 2),QuantityPrefStore3 decimal(24, 2),QuantityF"
                                               "ulfillmentStore decimal(24, 2),GrossSpend decimal("
                                               "38, 2),NetSpend decimal(38, 2),MaxPurchaseDate int"
                                               ",MinPurchaseDate int)  PARTITIONED BY (fis_week_id"
                                               " string) STORED AS PARQUET "
                                               'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_product_customer_all_all_summary": "INSERT INTO client_ssework.product_customer_all_all_"
                                            "summary PARTITION(fis_week_id) SELECT * FROM client_"
                                            "ssework.temp_product_customer_all_all_summary",
    "drop_subgroup_all_all_all_summary": "DROP TABLE IF EXISTS client_ssework.subgroup_all_all_all"
                                         "_summary",
    "create_subgroup_all_all_all_summary": "CREATE TABLE IF NOT EXISTS client_ssework.subgroup_all"
                                           "_all_all_summary (Subgroup string,Customer string,Store"
                                           " string,Channel string,Baskets bigint,BasketWeeks int,"
                                           "Discount decimal(38, 2),MaximumPrice decimal(38, 2),"
                                           "MinimumPrice decimal(38, 2),MaximumNetPrice decimal(38,"
                                           " 2),MinimumNetPrice decimal(38, 2),Quantity decimal(24,"
                                           "2),QuantityPrefStore1 decimal(24, 2),QuantityPrefStore2"
                                           " decimal(24, 2),QuantityPrefStore3 decimal(24, 2),"
                                           "QuantityFulfillmentStore decimal(24, 2),GrossSpend "
                                           "decimal(38, 2),NetSpend decimal(38, 2),MaxPurchaseDate"
                                           " int,MinPurchaseDate int) PARTITIONED BY (fis_week_id "
                                           "string) STORED AS PARQUET "
                                           'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_all_all_all_summary": "INSERT INTO client_ssework.subgroup_all_all_all_summary "
                                        "PARTITION(fis_week_id) SELECT * FROM client_ssework.temp_"
                                        "subgroup_all_all_all_summary",
    "drop_subgroup_customer_all_all_summary": "DROP TABLE IF EXISTS client_ssework.subgroup_"
                                              "customer_all_all_summary",
    "create_subgroup_customer_all_all_summary": "CREATE TABLE IF NOT EXISTS client_ssework.Subgroup"
                                                "_Customer_All_All_summary (Subgroup string,"
                                                "Customer string,Store string,Channel string,"
                                                "Baskets bigint,BasketWeeks int,Discount decimal(38"
                                                ", 2),MaximumPrice decimal(38, 2),MinimumPrice "
                                                "decimal(38, 2),MaximumNetPrice decimal(38, 2),"
                                                "MinimumNetPrice decimal(38, 2),Quantity decimal(24"
                                                ", 2),QuantityPrefStore1 decimal(24, 2),"
                                                "QuantityPrefStore2 decimal(24, 2),"
                                                "QuantityPrefStore3 decimal(24, 2),"
                                                "QuantityFulfillmentStore decimal(24, 2),GrossSpend"
                                                " decimal(38, 2),NetSpend decimal(38, 2),"
                                                "MaxPurchaseDate int,MinPurchaseDate int) "
                                                "PARTITIONED BY (fis_week_id string) "
                                                "STORED AS PARQUET "
                                                'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_customer_all_all_summary": "INSERT INTO client_ssework.subgroup_customer_all_all"
                                             "_summary PARTITION(fis_week_id) SELECT * FROM client"
                                             "_ssework.temp_subgroup_customer_all_all_summary",
    "drop_feature_distinct_tab_summary": "DROP TABLE IF EXISTS client_ssework.feature_distinct_tab_"
                                         "summary",
    "create_feature_distinct_tab_summary": "CREATE TABLE IF NOT EXISTS client_ssework.feature_"
                                           "distinct_tab_summary (Division string, Section string, "
                                           "Group string, Subgroup string, Product string, Customer"
                                           " string) PARTITIONED BY (fis_week_id string) STORED AS "
                                           "PARQUET "
                                           'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_feature_distinct_tab_summary": "INSERT INTO client_ssework.feature_distinct_tab_summary "
                                        "PARTITION(fis_week_id) SELECT * FROM client_ssework.temp"
                                        "_feature_distinct_tab_summary",
    "drop_all_all_all_all_1w1w": "DROP TABLE IF EXISTS client_ssework.all_all_all_all_1w1w",
    "create_all_all_all_all_1w1w": "CREATE TABLE IF NOT EXISTS client_ssework.All_All_All_All_1w1w "
                                   "(Product string,Customer string,Store string,Channel string,"
                                   "Baskets_1w1w bigint,BasketWeeks_1w1w int,Discount_1w1w decimal("
                                   "38, 2),MaximumPrice_1w1w decimal(38, 2),MinimumPrice_1w1w "
                                   "decimal(38, 2),MaximumNetPrice_1w1w decimal(38, 2),"
                                   "MinimumNetPrice_1w1w decimal(38, 2),Quantity_1w1w decimal(24,2"
                                   "),QuantityPrefStore1_1w1w decimal(24,2),QuantityPrefStore2_1w1w"
                                   " decimal(24, 2),QuantityPrefStore3_1w1w decimal(24, 2),"
                                   "QuantityFulfillmentStore_1w1w decimal(24, 2),GrossSpend_1w1w "
                                   "decimal(38,2),NetSpend_1w1w decimal(38,2),MaxPurchaseDate_1w1w "
                                   "string,MinPurchaseDate_1w1w string,"
                                   "RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),"
                                   "RecencyWeightedBasketWeeks95_1w1w decimal(38, 2),"
                                   "DivisionCount_1w1w bigint,SectionCount_1w1w bigint,"
                                   "GroupCount_1w1w bigint,SubgroupCount_1w1w bigint,"
                                   "ProductCount_1w1w bigint,CustomerCount_1w1w bigint) PARTITIONED"
                                   " BY (cadence_week string) STORED AS PARQUET "
                                   'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_all_all_all_all_1w1w": "INSERT INTO client_ssework.all_all_all_all_1w1w PARTITION (cadence"
                                "_week) SELECT * FROM client_ssework.temp_all_all_all_all_1w1w",
    "drop_all_all_all_all_1w4w": "DROP TABLE IF EXISTS client_ssework.all_all_all_all_1w4w",
    "create_all_all_all_all_1w4w": "CREATE TABLE IF NOT EXISTS client_ssework.all_all_all_all_1w4w "
                                   "(Product string,Customer string,Store string,Channel string,"
                                   "Baskets_1w4w bigint,BasketWeeks_1w4w int,Discount_1w4w decimal("
                                   "38, 2),MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w4w "
                                   "decimal(38, 2),MaximumNetPrice_1w4w decimal(38, 2),"
                                   "MinimumNetPrice_1w4w decimal(38, 2),Quantity_1w4w decimal(24,2"
                                   "),QuantityPrefStore1_1w4w decimal(24,2),QuantityPrefStore2_1w4w"
                                   " decimal(24, 2),QuantityPrefStore3_1w4w decimal(24, 2),"
                                   "QuantityFulfillmentStore_1w4w decimal(24, 2),GrossSpend_1w4w "
                                   "decimal(38,2),NetSpend_1w4w decimal(38,2),MaxPurchaseDate_1w4w "
                                   "string,MinPurchaseDate_1w4w string,"
                                   "RecencyWeightedBasketWeeks75_1w4w decimal(38, 2),"
                                   "RecencyWeightedBasketWeeks95_1w4w decimal(38, 2),"
                                   "DivisionCount_1w4w bigint,SectionCount_1w4w bigint,"
                                   "GroupCount_1w4w bigint,SubgroupCount_1w4w bigint,"
                                   "ProductCount_1w4w bigint,CustomerCount_1w4w bigint) PARTITIONED"
                                   " BY (cadence_week string) STORED AS PARQUET "
                                   'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_all_all_all_all_1w4w": "INSERT INTO client_ssework.all_all_all_all_1w4w PARTITION (cadence"
                                "_week) SELECT * FROM client_ssework.temp_all_all_all_all_1w4w",
    "drop_product_customer_all_all_1w1w": "DROP TABLE IF EXISTS client_ssework.product_customer_all"
                                          "_all_1w1w",
    "create_product_customer_all_all_1w1w": "CREATE TABLE IF NOT EXISTS client_ssework.product_"
                                            "customer_all_all_1w1w (Product string,Customer string,"
                                            "Store string,Channel string,Baskets_1w1w bigint,"
                                            "BasketWeeks_1w1w int,Discount_1w1w decimal(38, 2),"
                                            "MaximumPrice_1w1w decimal(38, 2),MinimumPrice_1w1w "
                                            "decimal(38, 2),MaximumNetPrice_1w1w decimal(38, 2),"
                                            "MinimumNetPrice_1w1w decimal(38, 2),Quantity_1w1w "
                                            "decimal(24, 2),QuantityPrefStore1_1w1w decimal(24, 2),"
                                            "QuantityPrefStore2_1w1w decimal(24, 2),"
                                            "QuantityPrefStore3_1w1w decimal(24, 2),"
                                            "QuantityFulfillmentStore_1w1w decimal(24, 2),"
                                            "GrossSpend_1w1w decimal(38, 2),NetSpend_1w1w decimal("
                                            "38,2),MaxPurchaseDate_1w1w string,MinPurchaseDate_1w1w"
                                            " string,RecencyWeightedBasketWeeks75_1w1w decimal(38, "
                                            "2),RecencyWeightedBasketWeeks95_1w1w decimal(38, 2)) P"
                                            "ARTITIONED BY (cadence_week string) STORED AS PARQUET "
                                            'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_product_customer_all_all_1w1w": "INSERT INTO client_ssework.product_customer_all_all_1w1w "
                                         "PARTITION (cadence_week) SELECT * FROM client_ssework.tem"
                                         "p_product_customer_all_all_1w1w",
    "drop_product_customer_all_all_1w4w": "DROP TABLE IF EXISTS client_ssework.product_customer_all"
                                          "_all_1w4w",
    "create_product_customer_all_all_1w4w": "CREATE TABLE IF NOT EXISTS client_ssework.product_"
                                            "customer_all_all_1w4w (Product string,Customer string,"
                                            "Store string,Channel string,Baskets_1w4w bigint"
                                            ",BasketWeeks_1w4w int,Discount_1w4w decimal(38, 2),"
                                            "MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w4w "
                                            "decimal(38, 2),MaximumNetPrice_1w4w decimal(38, 2),"
                                            "MinimumNetPrice_1w4w decimal(38, 2),Quantity_1w4w "
                                            "decimal(24, 2),QuantityPrefStore1_1w4w decimal(24, 2),"
                                            "QuantityPrefStore2_1w4w decimal(24, 2),"
                                            "QuantityPrefStore3_1w4w decimal(24, 2),"
                                            "QuantityFulfillmentStore_1w4w decimal(24, 2),"
                                            "GrossSpend_1w4w decimal(38, 2),NetSpend_1w4w decimal("
                                            "38,2),MaxPurchaseDate_1w4w string,MinPurchaseDate_1w4w"
                                            " string,RecencyWeightedBasketWeeks75_1w4w decimal(38, "
                                            "2),RecencyWeightedBasketWeeks95_1w4w decimal(38, 2)) P"
                                            "ARTITIONED BY (cadence_week string) STORED AS PARQUET "
                                            'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_product_customer_all_all_1w4w": "INSERT INTO client_ssework.product_customer_all_all_1w4w "
                                         "PARTITION (cadence_week) SELECT * FROM client_ssework.tem"
                                         "p_product_customer_all_all_1w4w",
    "drop_subgroup_all_all_all_1w1w": "DROP TABLE IF EXISTS client_ssework.subgroup_all_all_all_"
                                      "1w1w",
    "create_subgroup_all_all_all_1w1w": "CREATE TABLE IF NOT EXISTS client_ssework.subgroup_all_all"
                                        "_all_1w1w (Subgroup string,Customer string,Store string,"
                                        "Channel string,Baskets_1w1w bigint,BasketWeeks_1w1w int,"
                                        "Discount_1w1w decimal(38, 2),MaximumPrice_1w1w decimal(38,"
                                        " 2),MinimumPrice_1w1w decimal(38, 2),MaximumNetPrice_1w1w "
                                        "decimal(38, 2),MinimumNetPrice_1w1w decimal(38, 2),"
                                        "Quantity_1w1w decimal(24, 2),QuantityPrefStore1_1w1w "
                                        "decimal(24, 2),QuantityPrefStore2_1w1w decimal(24, 2),"
                                        "QuantityPrefStore3_1w1w decimal(24, 2),"
                                        "QuantityFulfillmentStore_1w1w decimal(24, 2),"
                                        "GrossSpend_1w1w decimal(38,2),NetSpend_1w1w decimal(38,2),"
                                        "MaxPurchaseDate_1w1w string,MinPurchaseDate_1w1w string,"
                                        "RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),"
                                        "RecencyWeightedBasketWeeks95_1w1w decimal(38, 2),"
                                        "ProductCount_1w1w bigint,CustomerCount_1w1w bigint) PARTIT"
                                        "IONED BY (cadence_week string) STORED AS PARQUET "
                                        'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_all_all_all_1w1w": "INSERT INTO client_ssework.subgroup_all_all_all_1w1w PARTITIO"
                                     "N (cadence_week) SELECT * FROM client_ssework.temp_subgroup_a"
                                     "ll_all_all_1w1w",
    "drop_subgroup_all_all_all_1w4w": "DROP TABLE IF EXISTS client_ssework.subgroup_all_all_all_"
                                      "1w4w",
    "create_subgroup_all_all_all_1w4w": "CREATE TABLE IF NOT EXISTS client_ssework.subgroup_all_all"
                                        "_all_1w4w (Subgroup string,Customer string,Store string,"
                                        "Channel string,Baskets_1w4w bigint,BasketWeeks_1w4w int,"
                                        "Discount_1w4w decimal(38, 2),MaximumPrice_1w4w decimal(38,"
                                        " 2),MinimumPrice_1w4w decimal(38, 2),MaximumNetPrice_1w4w "
                                        "decimal(38, 2),MinimumNetPrice_1w4w decimal(38, 2),"
                                        "Quantity_1w4w decimal(24, 2),QuantityPrefStore1_1w4w "
                                        "decimal(24, 2),QuantityPrefStore2_1w4w decimal(24, 2),"
                                        "QuantityPrefStore3_1w4w decimal(24, 2),"
                                        "QuantityFulfillmentStore_1w4w decimal(24, 2),"
                                        "GrossSpend_1w4w decimal(38,2),NetSpend_1w4w decimal(38,2),"
                                        "MaxPurchaseDate_1w4w string,MinPurchaseDate_1w4w string,"
                                        "RecencyWeightedBasketWeeks75_1w4w decimal(38, 2),"
                                        "RecencyWeightedBasketWeeks95_1w4w decimal(38, 2),"
                                        "ProductCount_1w4w bigint,CustomerCount_1w4w bigint) PARTIT"
                                        "IONED BY (cadence_week string) STORED AS PARQUET "
                                        'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_all_all_all_1w4w": "INSERT INTO client_ssework.subgroup_all_all_all_1w4w PARTITIO"
                                     "N (cadence_week) SELECT * FROM client_ssework.temp_subgroup_a"
                                     "ll_all_all_1w4w",
    "drop_subgroup_customer_all_all_1w1w": "DROP TABLE IF EXISTS client_ssework.subgroup_customer_"
                                           "all_all_1w1w",
    "create_subgroup_customer_all_all_1w1w": "CREATE TABLE IF NOT EXISTS client_ssework.subgroup_cu"
                                             "stomer_all_all_1w1w (Subgroup string,Customer string,"
                                             "Store string,Channel string,Baskets_1w1w bigint,"
                                             "BasketWeeks_1w1w int,Discount_1w1w decimal(38, 2),"
                                             "MaximumPrice_1w1w decimal(38, 2),MinimumPrice_1w1w "
                                             "decimal(38, 2),MaximumNetPrice_1w1w decimal(38, 2),"
                                             "MinimumNetPrice_1w1w decimal(38, 2),Quantity_1w1w "
                                             "decimal(24, 2),QuantityPrefStore1_1w1w decimal(24, 2)"
                                             ",QuantityPrefStore2_1w1w decimal(24, 2),"
                                             "QuantityPrefStore3_1w1w decimal(24, 2),"
                                             "QuantityFulfillmentStore_1w1w decimal(24, 2),"
                                             "GrossSpend_1w1w decimal(38,2),NetSpend_1w1w decimal(3"
                                             "8,2),MaxPurchaseDate_1w1w string,MinPurchaseDate_1w1w"
                                             " string, RecencyWeightedBasketWeeks75_1w1w decimal(38"
                                             ", 2),RecencyWeightedBasketWeeks95_1w1w decimal(38, 2)"
                                             ",ProductCount_1w1w bigint) PARTITIONED BY (cadence_we"
                                             "ek string) STORED AS PARQUET "
                                             'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_customer_all_all_1w1w": "INSERT INTO client_ssework.subgroup_customer_all_all_1w1"
                                          "w PARTITION (cadence_week) SELECT * FROM client_ssework."
                                          "temp_subgroup_customer_all_all_1w1w",
    "drop_subgroup_customer_all_all_1w4w": "DROP TABLE IF EXISTS client_ssework.subgroup_customer_"
                                           "all_all_1w4w",
    "create_subgroup_customer_all_all_1w4w": "CREATE TABLE IF NOT EXISTS client_ssework.subgroup_cu"
                                             "stomer_all_all_1w4w (Subgroup string,Customer string,"
                                             "Store string,Channel string,Baskets_1w4w bigint,"
                                             "BasketWeeks_1w4w int,Discount_1w4w decimal(38, 2),"
                                             "MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w4w "
                                             "decimal(38, 2),MaximumNetPrice_1w4w decimal(38, 2),"
                                             "MinimumNetPrice_1w4w decimal(38, 2),Quantity_1w4w "
                                             "decimal(24, 2),QuantityPrefStore1_1w4w decimal(24, 2)"
                                             ",QuantityPrefStore2_1w4w decimal(24, 2),"
                                             "QuantityPrefStore3_1w4w decimal(24, 2),"
                                             "QuantityFulfillmentStore_1w4w decimal(24, 2),"
                                             "GrossSpend_1w4w decimal(38,2),NetSpend_1w4w decimal(3"
                                             "8,2),MaxPurchaseDate_1w4w string,MinPurchaseDate_1w4w"
                                             " string, RecencyWeightedBasketWeeks75_1w4w decimal(38"
                                             ",2),RecencyWeightedBasketWeeks95_1w4w decimal(38, 2),"
                                             "ProductCount_1w4w bigint) PARTITIONED BY (cadence_wee"
                                             "k string) STORED AS PARQUET "
                                             'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_customer_all_all_1w4w": "INSERT INTO client_ssework.Subgroup_Customer_All_All_1w4"
                                          "w PARTITION (cadence_week) SELECT * FROM client_ssework."
                                          "temp_subgroup_customer_all_all_1w4w",
    "drop_feature_distinct_tab_1w1w": "DROP TABLE IF EXISTS client_ssework.feature_distinct_tab_1w1"
                                      "w",
    "create_feature_distinct_tab_1w1w": "CREATE TABLE IF NOT EXISTS client_ssework.feature_distinct"
                                        "_tab_1w1w (Division string, Section string, Group string, "
                                        "Subgroup string, Product string, Customer string) "
                                        "PARTITIONED BY (cadence_week string) STORED AS PARQUET "
                                        'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_feature_distinct_tab_1w1w": "INSERT INTO client_ssework.feature_distinct_tab_1w1w "
                                     "PARTITION(cadence_week) SELECT * FROM client_ssework.temp_fea"
                                     "ture_distinct_tab_1w1w",
    "drop_feature_distinct_tab_1w4w": "DROP TABLE IF EXISTS client_ssework.feature_distinct_tab_1w4"
                                      "w",
    "create_feature_distinct_tab_1w4w": "CREATE TABLE IF NOT EXISTS client_ssework.feature_distinct"
                                        "_tab_1w4w (Division string, Section string, Group string, "
                                        "Subgroup string, Product string, Customer string) "
                                        "PARTITIONED BY (cadence_week string) STORED AS PARQUET "
                                        'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_feature_distinct_tab_1w4w": "INSERT INTO client_ssework.feature_distinct_tab_1w4w "
                                     "PARTITION(cadence_week) SELECT * FROM client_ssework.temp_fea"
                                     "ture_distinct_tab_1w4w",
    "drop_all_all_all_all": "DROP TABLE IF EXISTS client_pob.all_all_all_all",
    "create_all_all_all_all": "CREATE TABLE IF NOT EXISTS client_pob.all_all_all_all (Product strin"
                              "g,Customer string,Store string,Channel string,Baskets_1w1w bigint,Ba"
                              "skets_1w4w bigint,BasketWeeks_1w1w int,BasketWeeks_1w4w int,Discount"
                              "_1w1w decimal(38, 2),Discount_1w4w decimal(38, 2),MaximumPrice_1w1w "
                              "decimal(38, 2),MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w1w de"
                              "cimal(38, 2),MinimumPrice_1w4w decimal(38, 2),MaximumNetPrice_1w1w d"
                              "ecimal(38, 2),MaximumNetPrice_1w4w decimal(38, 2),MinimumNetPrice_1w"
                              "1w decimal(38, 2),MinimumNetPrice_1w4w decimal(38, 2),Quantity_1w1w "
                              "decimal(24, 2),Quantity_1w4w decimal(24, 2),QuantityPrefStore1_1w1w "
                              "decimal(24, 2),QuantityPrefStore1_1w4w decimal(24, 2),QuantityPrefSt"
                              "ore2_1w1w decimal(24, 2),QuantityPrefStore2_1w4w decimal(24, 2),Quan"
                              "tityPrefStore3_1w1w decimal(24, 2),QuantityPrefStore3_1w4w decimal(2"
                              "4, 2),QuantityFulfillmentStore_1w1w decimal(24, 2),QuantityFulfillme"
                              "ntStore_1w4w decimal(24, 2),GrossSpend_1w1w decimal(38, 2),GrossSpen"
                              "d_1w4w decimal(38, 2),NetSpend_1w1w decimal(38, 2),NetSpend_1w4w dec"
                              "imal(38, 2),MaxPurchaseDate_1w1w string,MaxPurchaseDate_1w4w string,"
                              "MinPurchaseDate_1w1w string,MinPurchaseDate_1w4w string,RecencyWeigh"
                              "tedBasketWeeks75_1w1w decimal(38, 2),RecencyWeightedBasketWeeks75_1w"
                              "4w decimal(38, 2),RecencyWeightedBasketWeeks95_1w1w decimal(38, 2),R"
                              "ecencyWeightedBasketWeeks95_1w4w decimal(38, 2),DivisionCount_1w1w b"
                              "igint,DivisionCount_1w4w bigint,SectionCount_1w1w bigint,SectionCoun"
                              "t_1w4w bigint,GroupCount_1w1w bigint,GroupCount_1w4w bigint,Subgroup"
                              "Count_1w1w bigint,SubgroupCount_1w4w bigint,ProductCount_1w1w bigint"
                              ",ProductCount_1w4w bigint,CustomerCount_1w1w bigint,CustomerCount_1w"
                              "4w bigint,BasketsFlag_1w1w BOOLEAN,BasketsFlag_1w4w BOOLEAN,Discount"
                              "PerBasket_1w1w decimal(38, 2),DiscountPerBasket_1w4w decimal(38, 2),"
                              "DiscountPercent_1w1w decimal(38, 2),DiscountPercent_1w4w decimal(38,"
                              " 2),AveragePrice_1w1w decimal(38, 2),AveragePrice_1w4w decimal(38, 2"
                              "),QuantityPerBasket_1w1w decimal(38, 2),QuantityPerBasket_1w4w decim"
                              "al(38, 2),NetSpendPerBasket_1w1w decimal(38, 2),NetSpendPerBasket_1w"
                              "4w decimal(38, 2),AveragePurchaseCycle_1w1w decimal(38, 2),AveragePu"
                              "rchaseCycle_1w4w decimal(38, 2),RecencyDays_1w1w int,RecencyDays_1w4"
                              "w int,CyclesSinceLastPurchase_1w1w decimal(6, 2),CyclesSinceLastPurc"
                              "hase_1w4w decimal(6, 2)) PARTITIONED BY (cadence_week string) STORED"
                              " AS PARQUET "
                              'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_all_all_all_all": "INSERT INTO client_pob.all_all_all_all PARTITION (cadence_week) SELECT "
                           "* FROM client_pob.temp_all_all_all_all",
    "drop_product_customer_all_all": "DROP TABLE IF EXISTS client_pob.product_customer_all_all",
    "create_product_customer_all_all": "CREATE TABLE IF NOT EXISTS client_pob.product_customer_all_"
                                       "all (Product string,Customer string,Store string,Channel s"
                                       "tring,Baskets_1w1w bigint,Baskets_1w4w bigint,BasketWeeks_1"
                                       "w1w int,BasketWeeks_1w4w int,Discount_1w1w decimal(38, 2),D"
                                       "iscount_1w4w decimal(38,2),MaximumPrice_1w1w decimal(38,2),"
                                       "MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w1w decimal("
                                       "38,2),MinimumPrice_1w4w decimal(38,2),MaximumNetPrice_1w1w "
                                       "decimal(38, 2),MaximumNetPrice_1w4w decimal(38, 2),MinimumN"
                                       "etPrice_1w1w decimal(38,2),MinimumNetPrice_1w4w decimal(38,"
                                       " 2),Quantity_1w1w decimal(24,2),Quantity_1w4w decimal(24,2)"
                                       ",QuantityPrefStore1_1w1w decimal(24, 2),QuantityPrefStore1_"
                                       "1w4w decimal(24, 2),QuantityPrefStore2_1w1w decimal(24, 2),"
                                       "QuantityPrefStore2_1w4w decimal(24, 2),QuantityPrefStore3_1"
                                       "w1w decimal(24, 2),QuantityPrefStore3_1w4w decimal(24, 2),Q"
                                       "uantityFulfillmentStore_1w1w decimal(24, 2),QuantityFulfill"
                                       "mentStore_1w4w decimal(24,2),GrossSpend_1w1w decimal(38,2),"
                                       "GrossSpend_1w4w decimal(38,2),NetSpend_1w1w decimal(38,2),N"
                                       "etSpend_1w4w decimal(38, 2),MaxPurchaseDate_1w1w string,Max"
                                       "PurchaseDate_1w4w string,MinPurchaseDate_1w1w string,MinPur"
                                       "chaseDate_1w4w string,RecencyWeightedBasketWeeks75_1w1w dec"
                                       "imal(38,2),RecencyWeightedBasketWeeks75_1w4w decimal(38,2),"
                                       "RecencyWeightedBasketWeeks95_1w1w decimal(38,2),RecencyWeig"
                                       "htedBasketWeeks95_1w4w decimal(38, 2),BasketsFlag_1w1w BOOL"
                                       "EAN,BasketsFlag_1w4w BOOLEAN,DiscountPerBasket_1w1w decimal"
                                       "(38, 2),DiscountPerBasket_1w4w decimal(38, 2),DiscountPerce"
                                       "nt_1w1w decimal(38, 2),DiscountPercent_1w4w decimal(38, 2),"
                                       "AveragePrice_1w1w decimal(38, 2),AveragePrice_1w4w decimal("
                                       "38, 2),QuantityPerBasket_1w1w decimal(38, 2),QuantityPerBas"
                                       "ket_1w4w decimal(38,2),NetSpendPerBasket_1w1w decimal(38,2)"
                                       ",NetSpendPerBasket_1w4w decimal(38, 2),AveragePurchaseCycle"
                                       "_1w1w decimal(38,2),AveragePurchaseCycle_1w4w decimal(38,2)"
                                       ",RecencyDays_1w1w int,RecencyDays_1w4w int,CyclesSinceLastP"
                                       "urchase_1w1w decimal(6, 2),CyclesSinceLastPurchase_1w4w dec"
                                       "imal(6, 2)) PARTITIONED BY (cadence_week string) STORED AS "
                                       "PARQUET "
                                       'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_product_customer_all_all": "INSERT INTO client_pob.product_customer_all_all PARTITION "
                                    "(cadence_week) SELECT * FROM client_pob.temp_product_customer_"
                                    "all_all",
    "drop_subgroup_all_all_all": "DROP TABLE IF EXISTS client_pob.subgroup_all_all_all",
    "create_subgroup_all_all_all": "CREATE TABLE IF NOT EXISTS client_pob.subgroup_all_all_all (Sub"
                                   "group string,Customer string,Store string,Channel string,Basket"
                                   "s_1w1w bigint,Baskets_1w4w bigint,BasketWeeks_1w1w int,BasketWe"
                                   "eks_1w4w int,Discount_1w1w decimal(38,2),Discount_1w4w decimal("
                                   "38,2),MaximumPrice_1w1w decimal(38,2),MaximumPrice_1w4w decimal"
                                   "(38, 2),MinimumPrice_1w1w decimal(38, 2),MinimumPrice_1w4w deci"
                                   "mal(38, 2),MaximumNetPrice_1w1w decimal(38, 2),MaximumNetPrice_"
                                   "1w4w decimal(38, 2),MinimumNetPrice_1w1w decimal(38, 2),Minimum"
                                   "NetPrice_1w4w decimal(38, 2),Quantity_1w1w decimal(24, 2),Quant"
                                   "ity_1w4w decimal(24, 2),QuantityPrefStore1_1w1w decimal(24, 2),"
                                   "QuantityPrefStore1_1w4w decimal(24, 2),QuantityPrefStore2_1w1w "
                                   "decimal(24, 2),QuantityPrefStore2_1w4w decimal(24, 2),QuantityP"
                                   "refStore3_1w1w decimal(24,2),QuantityPrefStore3_1w4w decimal(24"
                                   ", 2),QuantityFulfillmentStore_1w1w decimal(24, 2),QuantityFulfi"
                                   "llmentStore_1w4w decimal(24, 2),GrossSpend_1w1w decimal(38, 2),"
                                   "GrossSpend_1w4w decimal(38, 2),NetSpend_1w1w decimal(38, 2),Net"
                                   "Spend_1w4w decimal(38, 2),MaxPurchaseDate_1w1w string,MaxPurcha"
                                   "seDate_1w4w string,MinPurchaseDate_1w1w string,MinPurchaseDate_"
                                   "1w4w string,RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),Re"
                                   "cencyWeightedBasketWeeks75_1w4w decimal(38, 2),RecencyWeightedB"
                                   "asketWeeks95_1w1w decimal(38, 2),RecencyWeightedBasketWeeks95_1"
                                   "w4w decimal(38, 2),ProductCount_1w1w bigint,ProductCount_1w4w b"
                                   "igint,CustomerCount_1w1w bigint,CustomerCount_1w4w bigint,Baske"
                                   "tsFlag_1w1w BOOLEAN,BasketsFlag_1w4w BOOLEAN,DiscountPerBasket_"
                                   "1w1w decimal(38, 2),DiscountPerBasket_1w4w decimal(38, 2),Disco"
                                   "untPercent_1w1w decimal(38, 2),DiscountPercent_1w4w decimal(38,"
                                   " 2),AveragePrice_1w1w decimal(38, 2),AveragePrice_1w4w decimal("
                                   "38, 2),QuantityPerBasket_1w1w decimal(38, 2),QuantityPerBasket_"
                                   "1w4w decimal(38, 2),NetSpendPerBasket_1w1w decimal(38, 2),NetSp"
                                   "endPerBasket_1w4w decimal(38, 2),AveragePurchaseCycle_1w1w deci"
                                   "mal(38, 2),AveragePurchaseCycle_1w4w decimal(38, 2),RecencyDays"
                                   "_1w1w int,RecencyDays_1w4w int,CyclesSinceLastPurchase_1w1w dec"
                                   "imal(6, 2),CyclesSinceLastPurchase_1w4w decimal(6, 2)) PARTITIO"
                                   "NED BY (cadence_week string) STORED AS PARQUET "
                                   'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_all_all_all": "INSERT INTO client_pob.subgroup_all_all_all PARTITION(cadence_week"
                                ") SELECT * FROM client_pob.temp_subgroup_all_all_all",
    "drop_subgroup_customer_all_all": "DROP TABLE IF EXISTS client_pob.subgroup_customer_all_all",
    "create_subgroup_customer_all_all": "CREATE TABLE IF NOT EXISTS client_pob.subgroup_customer_al"
                                        "l_all (Subgroup string,Customer string,Store string,Channe"
                                        "l string,Baskets_1w1w bigint,Baskets_1w4w bigint,BasketWee"
                                        "ks_1w1w int,BasketWeeks_1w4w int,Discount_1w1w decimal(38,"
                                        " 2),Discount_1w4w decimal(38, 2),MaximumPrice_1w1w decimal"
                                        "(38, 2),MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w1w"
                                        " decimal(38, 2),MinimumPrice_1w4w decimal(38, 2),MaximumNe"
                                        "tPrice_1w1w decimal(38,2),MaximumNetPrice_1w4w decimal(38,"
                                        " 2),MinimumNetPrice_1w1w decimal(38, 2),MinimumNetPrice_1w"
                                        "4w decimal(38, 2),Quantity_1w1w decimal(24, 2),Quantity_1w"
                                        "4w decimal(24, 2),QuantityPrefStore1_1w1w decimal(24, 2),Q"
                                        "uantityPrefStore1_1w4w decimal(24, 2),QuantityPrefStore2_1"
                                        "w1w decimal(24, 2),QuantityPrefStore2_1w4w decimal(24, 2),"
                                        "QuantityPrefStore3_1w1w decimal(24, 2),QuantityPrefStore3_"
                                        "1w4w decimal(24, 2),QuantityFulfillmentStore_1w1w decimal("
                                        "24, 2),QuantityFulfillmentStore_1w4w decimal(24, 2),GrossS"
                                        "pend_1w1w decimal(38, 2),GrossSpend_1w4w decimal(38, 2),Ne"
                                        "tSpend_1w1w decimal(38, 2),NetSpend_1w4w decimal(38, 2),Ma"
                                        "xPurchaseDate_1w1w string,MaxPurchaseDate_1w4w string,MinP"
                                        "urchaseDate_1w1w string,MinPurchaseDate_1w4w string,Recenc"
                                        "yWeightedBasketWeeks75_1w1w decimal(38, 2),RecencyWeighted"
                                        "BasketWeeks75_1w4w decimal(38, 2),RecencyWeightedBasketWee"
                                        "ks95_1w1w decimal(38, 2),RecencyWeightedBasketWeeks95_1w4w"
                                        " decimal(38, 2),ProductCount_1w1w bigint,ProductCount_1w4w"
                                        " bigint,BasketsFlag_1w1w BOOLEAN,BasketsFlag_1w4w BOOLEAN,"
                                        "DiscountPerBasket_1w1w decimal(38, 2),DiscountPerBasket_1w"
                                        "4w decimal(38, 2),DiscountPercent_1w1w decimal(38, 2),Disc"
                                        "ountPercent_1w4w decimal(38, 2),AveragePrice_1w1w decimal("
                                        "38, 2),AveragePrice_1w4w decimal(38, 2),QuantityPerBasket_"
                                        "1w1w decimal(38, 2),QuantityPerBasket_1w4w decimal(38, 2),"
                                        "NetSpendPerBasket_1w1w decimal(38, 2),NetSpendPerBasket_1w"
                                        "4w decimal(38, 2),AveragePurchaseCycle_1w1w decimal(38, 2)"
                                        ",AveragePurchaseCycle_1w4w decimal(38, 2),RecencyDays_1w1w"
                                        " int,RecencyDays_1w4w int,CyclesSinceLastPurchase_1w1w dec"
                                        "imal(6, 2),CyclesSinceLastPurchase_1w4w decimal(6, 2)) PAR"
                                        "TITIONED BY (cadence_week string) STORED AS PARQUET "
                                        'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_subgroup_customer_all_all": "INSERT INTO client_pob.subgroup_customer_all_all PARTITION "
                                     "(cadence_week) SELECT * FROM client_pob.temp_subgroup_custome"
                                     "r_all_all",
}

"""
Result set - to test values against in unit test cases
"""
scaaaa = "CREATE TABLE IF NOT EXISTS client_ssework.All_All_All_All_summary (Product string,Custo" \
         "mer string,Store string,Channel string,Baskets bigint,BasketWeeks int,Discount decimal(" \
         "38, 2),MaximumPrice decimal(38, 2),MinimumPrice decimal(38, 2),MaximumNetPrice decimal(" \
         "38, 2),MinimumNetPrice decimal(38, 2),Quantity decimal(24, 2),QuantityPrefStore1 decima" \
         "l(24, 2),QuantityPrefStore2 decimal(24, 2),QuantityPrefStore3 decimal(24, 2),QuantityFu" \
         "lfillmentStore decimal(24, 2),GrossSpend decimal(38,2),NetSpend decimal(38,2),MaxPurcha" \
         "seDate int,MinPurchaseDate int) PARTITIONED BY (fis_week_id string) STORED AS PARQUET " \
         'TBLPROPERTIES ("parquet.compression"="gzip")'
siaaaa = "INSERT OVERWRITE TABLE client_ssework.All_All_All_All_summary PARTITION(fis_week_id = " \
         "'{summary_week}') SELECT 'All' AS Product,'All' AS Customer,'All' AS Store,'All' AS Cha" \
         "nnel,COUNT(DISTINCT Basket) AS Baskets,(CASE WHEN COUNT(DISTINCT Basket) > 0 THEN 1 ELS" \
         "E 0 END) AS BasketWeeks,SUM(DiscountAmount) AS Discount,MAX(SpendAmount/Quantity) AS Ma" \
         "ximumPrice,MIN(SpendAmount/Quantity) AS MinimumPrice,MAX(NetSpendAmount/Quantity) AS Ma" \
         "ximumNetPrice,MIN(NetSpendAmount/Quantity) AS MinimumNetPrice,SUM(Quantity) AS Quantity" \
         ",SUM(CASE WHEN Store = PreferredStore1 THEN Quantity ELSE NULL END) AS QuantityPrefStor" \
         "e1,SUM(CASE WHEN Store=PreferredStore2 THEN Quantity ELSE NULL END) AS QuantityPrefStor" \
         "e2,SUM(CASE WHEN Store=PreferredStore3 THEN Quantity ELSE NULL END) AS QuantityPrefStor" \
         "e3,SUM(CASE WHEN Store=FulfillmentStore THEN Quantity ELSE NULL END) AS QuantityFulfill" \
         "mentStore,SUM(SpendAmount) AS GrossSpend,SUM(NetSpendAmount) AS NetSpend,MAX(datediff(d" \
         "ate_id,'1970-01-01')) AS MaxPurchaseDate,MIN(datediff(date_id,'1970-01-01')) AS MinPurchaseDa" \
         "te FROM client_ssework.purchase_fct WHERE fis_week_id = '{summary_week}'"
acaaaa = "CREATE TABLE IF NOT EXISTS client_ssework.All_All_All_All_1w1w (Product string,Customer" \
         " string,Store string,Channel string,Baskets_1w1w bigint,BasketWeeks_1w1w int,Discount_1" \
         "w1w decimal(38, 2),MaximumPrice_1w1w decimal(38, 2),MinimumPrice_1w1w decimal(38, 2),Ma" \
         "ximumNetPrice_1w1w decimal(38, 2),MinimumNetPrice_1w1w decimal(38, 2),Quantity_1w1w dec" \
         "imal(24,2),QuantityPrefStore1_1w1w decimal(24,2),QuantityPrefStore2_1w1w decimal(24, 2)" \
         ",QuantityPrefStore3_1w1w decimal(24, 2),QuantityFulfillmentStore_1w1w decimal(24,2),Gro" \
         "ssSpend_1w1w decimal(38,2),NetSpend_1w1w decimal(38, 2),MaxPurchaseDate_1w1w string,Min" \
         "PurchaseDate_1w1w string,RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),RecencyWeight" \
         "edBasketWeeks95_1w1w decimal(38,2),DivisionCount_1w1w bigint,SectionCount_1w1w bigint,G" \
         "roupCount_1w1w bigint,SubgroupCount_1w1w bigint,ProductCount_1w1w bigint,CustomerCount_" \
         "1w1w bigint) PARTITIONED BY (cadence_week string) STORED AS PARQUET " \
         'TBLPROPERTIES ("parquet.compression"="gzip")'
aiaaaa = "INSERT OVERWRITE TABLE client_ssework.All_All_All_All_1w1w PARTITION (cadence_week = '2" \
         "01744') SELECT 'All' AS Product,'All' AS Customer,'All' AS Store,'All' AS Channel,Baske" \
         "ts_1w1w AS Baskets_1w1w,BasketWeeks_1w1w AS BasketWeeks_1w1w,Discount_1w1w AS Discount_" \
         "1w1w,MaximumPrice_1w1w AS MaximumPrice_1w1w,MinimumPrice_1w1w AS MinimumPrice_1w1w,Maxi" \
         "mumNetPrice_1w1w AS MaximumNetPrice_1w1w,MinimumNetPrice_1w1w AS MinimumNetPrice_1w1w,Q" \
         "uantity_1w1w AS Quantity_1w1w,QuantityPrefStore1_1w1w AS QuantityPrefStore1_1w1w,Quanti" \
         "tyPrefStore2_1w1w AS QuantityPrefStore2_1w1w,QuantityPrefStore3_1w1w AS QuantityPrefSto" \
         "re3_1w1w,QuantityFulfillmentStore_1w1w AS QuantityFulfillmentStore_1w1w,GrossSpend_1w1w" \
         " AS GrossSpend_1w1w,NetSpend_1w1w AS NetSpend_1w1w,date_add('1970-01-01', MaxPurchaseDa" \
         "te_1w1w) AS MaxPurchaseDate_1w1w,date_add('1970-01-01', MinPurchaseDate_1w1w) AS MinPur" \
         "chaseDate_1w1w,RecencyWeightedBasketWeeks75_1w1w AS RecencyWeightedBasketWeeks75_1w1w,R" \
         "ecencyWeightedBasketWeeks95_1w1w AS RecencyWeightedBasketWeeks95_1w1w,DivisionCount AS " \
         "DivisionCount_1w1w,SectionCount AS SectionCount_1w1w,GroupCount AS GroupCount_1w1w,Subg" \
         "roupCount AS SubgroupCount_1w1w,ProductCount AS ProductCount_1w1w,CustomerCount AS Cust" \
         "omerCount_1w1w FROM ( SELECT SUM(Baskets) AS Baskets_1w1w,SUM(BasketWeeks) AS BasketWee" \
         "ks_1w1w,SUM(Discount) AS Discount_1w1w,MAX(MaximumPrice) AS MaximumPrice_1w1w,MIN(Minim" \
         "umPrice) AS MinimumPrice_1w1w,MAX(MaximumNetPrice) AS MaximumNetPrice_1w1w,MIN(MinimumN" \
         "etPrice) AS MinimumNetPrice_1w1w,SUM(Quantity) AS Quantity_1w1w,SUM(QuantityPrefStore1)" \
         " AS QuantityPrefStore1_1w1w,SUM(QuantityPrefStore2) AS QuantityPrefStore2_1w1w,SUM(Quan" \
         "tityPrefStore3) AS QuantityPrefStore3_1w1w,SUM(QuantityFulfillmentStore) AS QuantityFul" \
         "fillmentStore_1w1w,SUM(GrossSpend) AS GrossSpend_1w1w,SUM(NetSpend) AS NetSpend_1w1w,MA" \
         "X(MaxPurchaseDate) AS MaxPurchaseDate_1w1w,MIN(MinPurchaseDate) AS MinPurchaseDate_1w1w" \
         ",SUM(Baskets * pow(0.75, fisweekdiff('201744', fis_week_id) + 1)) AS RecencyWeightedBas" \
         "ketWeeks75_1w1w,SUM(Baskets * pow(0.95, fisweekdiff('201744', fis_week_id) + 1)) AS Rec" \
         "encyWeightedBasketWeeks95_1w1w FROM ( SELECT Baskets,BasketWeeks,Discount,MaximumPrice," \
         "MinimumPrice,MaximumNetPrice,MinimumNetPrice,Quantity,QuantityPrefStore1,QuantityPrefSt" \
         "ore2,QuantityPrefStore3,QuantityFulfillmentStore,GrossSpend,NetSpend,MaxPurchaseDate,Mi" \
         "nPurchaseDate,fis_week_id FROM client_ssework.All_All_All_All_summary  WHERE fis_week_i" \
         "d in ({summary_weeks})  UNION ALL  SELECT COUNT(DISTINCT Basket) AS Baskets,(CASE WHEN " \
         "COUNT(DISTINCT Basket) > 0 THEN 1 ELSE 0 END) AS BasketWeeks,SUM(DiscountAmount) AS Dis" \
         "count,MAX(SpendAmount / Quantity) AS MaximumPrice,MIN(SpendAmount / Quantity) AS Minimu" \
         "mPrice,MAX(NetSpendAmount / Quantity) AS MaximumNetPrice,MIN(NetSpendAmount / Quantity)" \
         " AS MinimumNetPrice,SUM(Quantity) AS Quantity,SUM(CASE WHEN Store = PreferredStore1 THE" \
         "N Quantity ELSE NULL END) AS QuantityPrefStore1,SUM(CASE WHEN Store = PreferredStore2 T" \
         "HEN Quantity ELSE NULL END) AS QuantityPrefStore2,SUM(CASE WHEN Store = PreferredStore3" \
         " THEN Quantity ELSE NULL END) AS QuantityPrefStore3,SUM(CASE WHEN Store = FulfillmentSt" \
         "ore THEN Quantity ELSE NULL END) AS QuantityFulfillmentStore,SUM(SpendAmount) AS GrossS" \
         "pend,SUM(NetSpendAmount) AS NetSpend,MAX(datediff(date_id, '1970-01-01')) AS MaxPurchaseDa" \
         "te,MIN(datediff(date_id, '1970-01-01')) AS MinPurchaseDate,'201744' AS fis_week_id FROM cl" \
         "ient_ssework.purchase_fct  WHERE date_id in ({incomplete_dates}) ) AS union_tab ) AS in_ta" \
         "b LEFT JOIN ( SELECT DivisionCount,SectionCount,GroupCount,SubgroupCount,ProductCount,C" \
         "ustomerCount FROM (SELECT COUNT(DISTINCT Division) AS DivisionCount FROM client_ssework" \
         ".feature_distinct_tab_1w1w  where cadence_week = 201744) AS tab1  INNER JOIN (SELECT COUNT(DISTINCT Section) AS Se" \
         "ctionCount FROM client_ssework.feature_distinct_tab_1w1w  where cadence_week = 201744) AS tab2 ON (1=1) INNER JOIN" \
         " (SELECT COUNT(DISTINCT Group) AS GroupCount FROM client_ssework.feature_distinct_tab_1" \
         "w1w  where cadence_week = 201744) AS tab3 ON (1=1) INNER JOIN (SELECT COUNT(DISTINCT Subgroup) AS SubgroupCount FR" \
         "OM client_ssework.feature_distinct_tab_1w1w  where cadence_week = 201744) AS tab4 ON (1=1) INNER JOIN (SELECT COUN" \
         "T(DISTINCT Product) AS ProductCount FROM client_ssework.feature_distinct_tab_1w1w where cadence_week = 201744 ) AS" \
         " tab5 ON (1=1) INNER JOIN (SELECT COUNT(DISTINCT Customer) AS CustomerCount FROM client" \
         "_ssework.feature_distinct_tab_1w1w where cadence_week = 201744 ) AS tab6 ON (1=1) ) AS dist_tab ON (1=1)"
mcaaaa = "CREATE TABLE IF NOT EXISTS client_pob.All_All_All_All (Product string,Customer string,S" \
         "tore string,Channel string,Baskets_1w1w bigint,Baskets_1w4w bigint,BasketWeeks_1w1w int" \
         ",BasketWeeks_1w4w int,Discount_1w1w decimal(38, 2),Discount_1w4w decimal(38, 2),Maximum" \
         "Price_1w1w decimal(38, 2),MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w1w decimal(38" \
         ", 2),MinimumPrice_1w4w decimal(38, 2),MaximumNetPrice_1w1w decimal(38, 2),MaximumNetPri" \
         "ce_1w4w decimal(38, 2),MinimumNetPrice_1w1w decimal(38, 2),MinimumNetPrice_1w4w decimal" \
         "(38, 2),Quantity_1w1w decimal(24, 2),Quantity_1w4w decimal(24, 2),QuantityPrefStore1_1w" \
         "1w decimal(24, 2),QuantityPrefStore1_1w4w decimal(24, 2),QuantityPrefStore2_1w1w decima" \
         "l(24, 2),QuantityPrefStore2_1w4w decimal(24, 2),QuantityPrefStore3_1w1w decimal(24, 2)," \
         "QuantityPrefStore3_1w4w decimal(24, 2),QuantityFulfillmentStore_1w1w decimal(24, 2),Qua" \
         "ntityFulfillmentStore_1w4w decimal(24, 2),GrossSpend_1w1w decimal(38, 2),GrossSpend_1w4" \
         "w decimal(38, 2),NetSpend_1w1w decimal(38, 2),NetSpend_1w4w decimal(38, 2),MaxPurchaseD" \
         "ate_1w1w string,MaxPurchaseDate_1w4w string,MinPurchaseDate_1w1w string,MinPurchaseDate" \
         "_1w4w string,RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),RecencyWeightedBasketWeek" \
         "s75_1w4w decimal(38, 2),RecencyWeightedBasketWeeks95_1w1w decimal(38, 2),RecencyWeighte" \
         "dBasketWeeks95_1w4w decimal(38, 2),DivisionCount_1w1w bigint,DivisionCount_1w4w bigint," \
         "SectionCount_1w1w bigint,SectionCount_1w4w bigint,GroupCount_1w1w bigint,GroupCount_1w4" \
         "w bigint,SubgroupCount_1w1w bigint,SubgroupCount_1w4w bigint,ProductCount_1w1w bigint,P" \
         "roductCount_1w4w bigint,CustomerCount_1w1w bigint,CustomerCount_1w4w bigint,BasketsFlag" \
         "_1w1w BOOLEAN,BasketsFlag_1w4w BOOLEAN,DiscountPerBasket_1w1w decimal(38, 2),DiscountPe" \
         "rBasket_1w4w decimal(38, 2),DiscountPercent_1w1w decimal(38, 2),DiscountPercent_1w4w de" \
         "cimal(38, 2),AveragePrice_1w1w decimal(38, 2),AveragePrice_1w4w decimal(38, 2),Quantity" \
         "PerBasket_1w1w decimal(38, 2),QuantityPerBasket_1w4w decimal(38, 2),NetSpendPerBasket_1" \
         "w1w decimal(38, 2),NetSpendPerBasket_1w4w decimal(38, 2),AveragePurchaseCycle_1w1w deci" \
         "mal(38, 2),AveragePurchaseCycle_1w4w decimal(38, 2),RecencyDays_1w1w int,RecencyDays_1w" \
         "4w int,CyclesSinceLastPurchase_1w1w decimal(6, 2),CyclesSinceLastPurchase_1w4w decimal(" \
         "6, 2)) PARTITIONED BY (cadence_week string) STORED AS PARQUET " \
         'TBLPROPERTIES ("parquet.compression"="gzip")'
miaaaa = "INSERT OVERWRITE TABLE client_pob.All_All_All_All PARTITION (cadence_week='201744') SEL" \
         "ECT COALESCE(1w4w.Product, 1w1w.Product) AS Product,COALESCE(1w4w.Customer, 1w1w.Custom" \
         "er) AS Customer,COALESCE(1w4w.Store, 1w1w.Store) AS Store,COALESCE(1w4w.Channel, 1w1w.C" \
         "hannel) AS Channel,Baskets_1w1w AS Baskets_1w1w,Baskets_1w4w AS Baskets_1w4w,BasketWeek" \
         "s_1w1w AS BasketWeeks_1w1w,BasketWeeks_1w4w AS BasketWeeks_1w4w,Discount_1w1w AS Discou" \
         "nt_1w1w,Discount_1w4w AS Discount_1w4w,MaximumPrice_1w1w AS MaximumPrice_1w1w,MaximumPr" \
         "ice_1w4w AS MaximumPrice_1w4w,MinimumPrice_1w1w AS MinimumPrice_1w1w,MinimumPrice_1w4w " \
         "AS MinimumPrice_1w4w,MaximumNetPrice_1w1w AS MaximumNetPrice_1w1w,MaximumNetPrice_1w4w " \
         "AS MaximumNetPrice_1w4w,MinimumNetPrice_1w1w AS MinimumNetPrice_1w1w,MinimumNetPrice_1w" \
         "4w AS MinimumNetPrice_1w4w,Quantity_1w1w AS Quantity_1w1w,Quantity_1w4w AS Quantity_1w4" \
         "w,QuantityPrefStore1_1w1w AS QuantityPrefStore1_1w1w,QuantityPrefStore1_1w4w AS Quantit" \
         "yPrefStore1_1w4w,QuantityPrefStore2_1w1w AS QuantityPrefStore2_1w1w,QuantityPrefStore2_" \
         "1w4w AS QuantityPrefStore2_1w4w,QuantityPrefStore3_1w1w AS QuantityPrefStore3_1w1w,Quan" \
         "tityPrefStore3_1w4w AS QuantityPrefStore3_1w4w,QuantityFulfillmentStore_1w1w AS Quantit" \
         "yFulfillmentStore_1w1w,QuantityFulfillmentStore_1w4w AS QuantityFulfillmentStore_1w4w,G" \
         "rossSpend_1w1w AS GrossSpend_1w1w,GrossSpend_1w4w AS GrossSpend_1w4w,NetSpend_1w1w AS N" \
         "etSpend_1w1w,NetSpend_1w4w AS NetSpend_1w4w,MaxPurchaseDate_1w1w AS MaxPurchaseDate_1w1" \
         "w,MaxPurchaseDate_1w4w AS MaxPurchaseDate_1w4w,MinPurchaseDate_1w1w AS MinPurchaseDate_" \
         "1w1w,MinPurchaseDate_1w4w AS MinPurchaseDate_1w4w,RecencyWeightedBasketWeeks75_1w1w AS " \
         "RecencyWeightedBasketWeeks75_1w1w,RecencyWeightedBasketWeeks75_1w4w AS RecencyWeightedB" \
         "asketWeeks75_1w4w,RecencyWeightedBasketWeeks95_1w1w AS RecencyWeightedBasketWeeks95_1w1" \
         "w,RecencyWeightedBasketWeeks95_1w4w AS RecencyWeightedBasketWeeks95_1w4w,DivisionCount_" \
         "1w1w AS DivisionCount_1w1w,DivisionCount_1w4w AS DivisionCount_1w4w,SectionCount_1w1w A" \
         "S SectionCount_1w1w,SectionCount_1w4w AS SectionCount_1w4w,GroupCount_1w1w AS GroupCoun" \
         "t_1w1w,GroupCount_1w4w AS GroupCount_1w4w,SubgroupCount_1w1w AS SubgroupCount_1w1w,Subg" \
         "roupCount_1w4w AS SubgroupCount_1w4w,ProductCount_1w1w AS ProductCount_1w1w,ProductCoun" \
         "t_1w4w AS ProductCount_1w4w,CustomerCount_1w1w AS CustomerCount_1w1w,CustomerCount_1w4w" \
         " AS CustomerCount_1w4w,(CASE WHEN Baskets_1w1w > 0 THEN TRUE ELSE FALSE END) AS Baskets" \
         "Flag_1w1w,(CASE WHEN Baskets_1w4w > 0 THEN TRUE ELSE FALSE END) AS BasketsFlag_1w4w,(Di" \
         "scount_1w1w / Baskets_1w1w) AS DiscountPerBasket_1w1w,(Discount_1w4w / Baskets_1w4w) AS" \
         " DiscountPerBasket_1w4w,((Discount_1w1w / GrossSpend_1w1w) * 100) AS DiscountPercent_1w" \
         "1w,((Discount_1w4w / GrossSpend_1w4w) * 100) AS DiscountPercent_1w4w,(GrossSpend_1w1w /" \
         " Quantity_1w1w) AS AveragePrice_1w1w,(GrossSpend_1w4w / Quantity_1w4w) AS AveragePrice_" \
         "1w4w,(Quantity_1w1w / Baskets_1w1w) AS QuantityPerBasket_1w1w,(Quantity_1w4w / Baskets_" \
         "1w4w) AS QuantityPerBasket_1w4w,(NetSpend_1w1w / Baskets_1w1w) AS NetSpendPerBasket_1w1" \
         "w,(NetSpend_1w4w / Baskets_1w4w) AS NetSpendPerBasket_1w4w,(datediff(MaxPurchaseDate_1w" \
         "1w, MinPurchaseDate_1w1w) / (Baskets_1w1w - 1)) AS AveragePurchaseCycle_1w1w,(datediff(" \
         "MaxPurchaseDate_1w4w, MinPurchaseDate_1w4w) / (Baskets_1w4w - 1)) AS AveragePurchaseCyc" \
         "le_1w4w,(datediff('2018-01-01', MaxPurchaseDate_1w1w)) AS RecencyDays_1w1w,(datediff('2" \
         "018-01-01', MaxPurchaseDate_1w4w)) AS RecencyDays_1w4w,((datediff('2018-01-01', MaxPurc" \
         "haseDate_1w1w)) / (datediff(MaxPurchaseDate_1w1w, MinPurchaseDate_1w1w) / (Baskets_1w1w" \
         " - 1))) AS CyclesSinceLastPurchase_1w1w,((datediff('2018-01-01', MaxPurchaseDate_1w4w))" \
         " / (datediff(MaxPurchaseDate_1w4w, MinPurchaseDate_1w4w) / (Baskets_1w4w - 1))) AS Cycl" \
         "esSinceLastPurchase_1w4w FROM client_ssework.All_All_All_All_1w4w AS 1w4w FULL OUTER JO" \
         "IN client_ssework.All_All_All_All_1w1w AS 1w1w ON (1=1)"
vaaaa = "CREATE VIEW IF NOT EXISTS client_pob.v_cadenceattributefis_week_id_ChannelAll_CustomerAl" \
        "l_ProductAll_StoreAll_201744 AS SELECT 'fis_week_id' AS cadenceattribute,'201744'AS cade" \
        "nce,'All' AS Channelattribute,Channel AS Channel,'All' AS Customerattribute,Customer AS " \
        "Customer,'All' AS Productattribute,Product AS Product,'All' AS Storeattribute,Store AS S" \
        "tore,Baskets_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Baskets_1w1w,Baskets_1w4" \
        "w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Baskets_1w4w,BasketWeeks_1w1w AS Channel" \
        "All_CustomerAll_ProductAll_StoreAll_BasketWeeks_1w1w,BasketWeeks_1w4w AS ChannelAll_Cust" \
        "omerAll_ProductAll_StoreAll_BasketWeeks_1w4w,Discount_1w1w AS ChannelAll_CustomerAll_Pro" \
        "ductAll_StoreAll_Discount_1w1w,Discount_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreA" \
        "ll_Discount_1w4w,MaximumPrice_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Maximum" \
        "Price_1w1w,MaximumPrice_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MaximumPrice_" \
        "1w4w,MinimumPrice_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MinimumPrice_1w1w,M" \
        "inimumPrice_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MinimumPrice_1w4w,Maximum" \
        "NetPrice_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MaximumNetPrice_1w1w,Maximum" \
        "NetPrice_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MaximumNetPrice_1w4w,Minimum" \
        "NetPrice_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MinimumNetPrice_1w1w,Minimum" \
        "NetPrice_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MinimumNetPrice_1w4w,Quantit" \
        "y_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Quantity_1w1w,Quantity_1w4w AS Chan" \
        "nelAll_CustomerAll_ProductAll_StoreAll_Quantity_1w4w,QuantityPrefStore1_1w1w AS ChannelA" \
        "ll_CustomerAll_ProductAll_StoreAll_QuantityPrefStore1_1w1w,QuantityPrefStore1_1w4w AS Ch" \
        "annelAll_CustomerAll_ProductAll_StoreAll_QuantityPrefStore1_1w4w,QuantityPrefStore2_1w1w" \
        " AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityPrefStore2_1w1w,QuantityPrefStore" \
        "2_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityPrefStore2_1w4w,QuantityPre" \
        "fStore3_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityPrefStore3_1w1w,Quant" \
        "ityPrefStore3_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityPrefStore3_1w4w" \
        ",QuantityFulfillmentStore_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityFul" \
        "fillmentStore_1w1w,QuantityFulfillmentStore_1w4w AS ChannelAll_CustomerAll_ProductAll_St" \
        "oreAll_QuantityFulfillmentStore_1w4w,GrossSpend_1w1w AS ChannelAll_CustomerAll_ProductAl" \
        "l_StoreAll_GrossSpend_1w1w,GrossSpend_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll" \
        "_GrossSpend_1w4w,NetSpend_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_NetSpend_1w" \
        "1w,NetSpend_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_NetSpend_1w4w,MaxPurchase" \
        "Date_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MaxPurchaseDate_1w1w,MaxPurchase" \
        "Date_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MaxPurchaseDate_1w4w,MinPurchase" \
        "Date_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MinPurchaseDate_1w1w,MinPurchase" \
        "Date_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_MinPurchaseDate_1w4w,RecencyWeig" \
        "htedBasketWeeks75_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_RecencyWeightedBask" \
        "etWeeks75_1w1w,RecencyWeightedBasketWeeks75_1w4w AS ChannelAll_CustomerAll_ProductAll_St" \
        "oreAll_RecencyWeightedBasketWeeks75_1w4w,RecencyWeightedBasketWeeks95_1w1w AS ChannelAll" \
        "_CustomerAll_ProductAll_StoreAll_RecencyWeightedBasketWeeks95_1w1w,RecencyWeightedBasket" \
        "Weeks95_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_RecencyWeightedBasketWeeks95_" \
        "1w4w,DivisionCount_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_DivisionCount_1w1w" \
        ",DivisionCount_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_DivisionCount_1w4w,Sec" \
        "tionCount_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_SectionCount_1w1w,SectionCo" \
        "unt_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_SectionCount_1w4w,GroupCount_1w1w" \
        " AS ChannelAll_CustomerAll_ProductAll_StoreAll_GroupCount_1w1w,GroupCount_1w4w AS Channe" \
        "lAll_CustomerAll_ProductAll_StoreAll_GroupCount_1w4w,SubgroupCount_1w1w AS ChannelAll_Cu" \
        "stomerAll_ProductAll_StoreAll_SubgroupCount_1w1w,SubgroupCount_1w4w AS ChannelAll_Custom" \
        "erAll_ProductAll_StoreAll_SubgroupCount_1w4w,ProductCount_1w1w AS ChannelAll_CustomerAll" \
        "_ProductAll_StoreAll_ProductCount_1w1w,ProductCount_1w4w AS ChannelAll_CustomerAll_Produ" \
        "ctAll_StoreAll_ProductCount_1w4w,CustomerCount_1w1w AS ChannelAll_CustomerAll_ProductAll" \
        "_StoreAll_CustomerCount_1w1w,CustomerCount_1w4w AS ChannelAll_CustomerAll_ProductAll_Sto" \
        "reAll_CustomerCount_1w4w,BasketsFlag_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_" \
        "BasketsFlag_1w1w,BasketsFlag_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_BasketsF" \
        "lag_1w4w,DiscountPerBasket_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_DiscountPe" \
        "rBasket_1w1w,DiscountPerBasket_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Discou" \
        "ntPerBasket_1w4w,DiscountPercent_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Disc" \
        "ountPercent_1w1w,DiscountPercent_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Disc" \
        "ountPercent_1w4w,AveragePrice_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Average" \
        "Price_1w1w,AveragePrice_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_AveragePrice_" \
        "1w4w,QuantityPerBasket_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityPerBas" \
        "ket_1w1w,QuantityPerBasket_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_QuantityPe" \
        "rBasket_1w4w,NetSpendPerBasket_1w1w AS ChannelAll_CustomerAll_ProductAll_StoreAll_NetSpe" \
        "ndPerBasket_1w1w,NetSpendPerBasket_1w4w AS ChannelAll_CustomerAll_ProductAll_StoreAll_Ne" \
        "tSpendPerBasket_1w4w,AveragePurchaseCycle_1w1w AS ChannelAll_CustomerAll_ProductAll_Stor" \
        "eAll_AveragePurchaseCycle_1w1w,AveragePurchaseCycle_1w4w AS ChannelAll_CustomerAll_Produ" \
        "ctAll_StoreAll_AveragePurchaseCycle_1w4w,RecencyDays_1w1w AS ChannelAll_CustomerAll_Prod" \
        "uctAll_StoreAll_RecencyDays_1w1w,RecencyDays_1w4w AS ChannelAll_CustomerAll_ProductAll_S" \
        "toreAll_RecencyDays_1w4w,CyclesSinceLastPurchase_1w1w AS ChannelAll_CustomerAll_ProductA" \
        "ll_StoreAll_CyclesSinceLastPurchase_1w1w,CyclesSinceLastPurchase_1w4w AS ChannelAll_Cust" \
        "omerAll_ProductAll_StoreAll_CyclesSinceLastPurchase_1w4w FROM client_pob.All_All_All_All" \
        " WHERE cadence_week = '201744'"
scsaaa = "CREATE TABLE IF NOT EXISTS client_ssework.Subgroup_All_All_All_summary( Subgroup string" \
         ",Customer string,Store string,Channel string,Baskets bigint,BasketWeeks int,Discount de" \
         "cimal(38,2),MaximumPrice decimal(38,2),MinimumPrice decimal(38,2),MaximumNetPrice decim" \
         "al(38,2),MinimumNetPrice decimal(38,2),Quantity decimal(24,2),QuantityPrefStore1 decima" \
         "l(24,2),QuantityPrefStore2 decimal(24,2),QuantityPrefStore3 decimal(24,2),QuantityFulfi" \
         "llmentStore decimal(24,2),GrossSpend decimal(38,2),NetSpend decimal(38,2),MaxPurchaseDa" \
         "te int,MinPurchaseDate int) PARTITIONED BY (fis_week_id string) STORED AS PARQUET " \
         'TBLPROPERTIES ("parquet.compression"="gzip")'
sisaaa = "INSERT OVERWRITE TABLE client_ssework.Subgroup_All_All_All_summary PARTITION (fis_week_" \
         "id = '{summary_week}')  SELECT Subgroup AS Subgroup,'All' AS Customer,'All' AS Store,'A" \
         "ll' AS Channel,COUNT(DISTINCT Basket) AS Baskets,(CASE WHEN COUNT(DISTINCT Basket) > 0 " \
         "THEN 1 ELSE 0 END) AS BasketWeeks,SUM(DiscountAmount) AS Discount,MAX(SpendAmount/Quant" \
         "ity) AS MaximumPrice,MIN(SpendAmount/Quantity) AS MinimumPrice,MAX(NetSpendAmount/Quant" \
         "ity) AS MaximumNetPrice,MIN(NetSpendAmount / Quantity) AS MinimumNetPrice,SUM(Quantity)" \
         " AS Quantity,SUM(CASE WHEN Store = PreferredStore1 THEN Quantity ELSE NULL END) AS Quan" \
         "tityPrefStore1,SUM(CASE WHEN Store = PreferredStore2 THEN Quantity ELSE NULL END) AS Qu" \
         "antityPrefStore2,SUM(CASE WHEN Store=PreferredStore3 THEN Quantity ELSE NULL END) AS Qu" \
         "antityPrefStore3,SUM(CASE WHEN Store=FulfillmentStore THEN Quantity ELSE NULL END) AS Q" \
         "uantityFulfillmentStore,SUM(SpendAmount) AS GrossSpend,SUM(NetSpendAmount) AS NetSpend," \
         "MAX(datediff(date_id,'1970-01-01')) AS MaxPurchaseDate,MIN(datediff(date_id,'1970-01-01')) AS" \
         " MinPurchaseDate FROM client_ssework.purchase_fct WHERE fis_week_id = '{summary_week}' " \
         "AND Subgroup IS NOT NULL GROUP BY Subgroup"
acsaaa = "CREATE TABLE IF NOT EXISTS client_ssework.Subgroup_All_All_All_1w1w (Subgroup string,Cu" \
         "stomer string,Store string,Channel string,Baskets_1w1w bigint,BasketWeeks_1w1w int,Disc" \
         "ount_1w1w decimal(38,2),MaximumPrice_1w1w decimal(38,2),MinimumPrice_1w1w decimal(38,2)" \
         ",MaximumNetPrice_1w1w decimal(38,2),MinimumNetPrice_1w1w decimal(38,2),Quantity_1w1w de" \
         "cimal(24,2),QuantityPrefStore1_1w1w decimal(24,2),QuantityPrefStore2_1w1w decimal(24,2)" \
         ",QuantityPrefStore3_1w1w decimal(24,2),QuantityFulfillmentStore_1w1w decimal(24,2),Gros" \
         "sSpend_1w1w decimal(38,2),NetSpend_1w1w decimal(38,2),MaxPurchaseDate_1w1w string,MinPu" \
         "rchaseDate_1w1w string,RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),RecencyWeighted" \
         "BasketWeeks95_1w1w decimal(38,2),ProductCount_1w1w bigint,CustomerCount_1w1w bigint) PA" \
         "RTITIONED BY (cadence_week string) STORED AS PARQUET" \
         'TBLPROPERTIES ("parquet.compression"="gzip")'
aisaaa = "INSERT OVERWRITE TABLE client_ssework.Subgroup_All_All_All_1w1w PARTITION (cadence_week" \
         " = '201744') SELECT in_tab.Subgroup AS Subgroup,'All' AS Customer,'All' AS Store,'All' " \
         "AS Channel,Baskets_1w1w AS Baskets_1w1w,BasketWeeks_1w1w AS BasketWeeks_1w1w,Discount_1" \
         "w1w AS Discount_1w1w,MaximumPrice_1w1w AS MaximumPrice_1w1w,MinimumPrice_1w1w AS Minimu" \
         "mPrice_1w1w,MaximumNetPrice_1w1w AS MaximumNetPrice_1w1w,MinimumNetPrice_1w1w AS Minimu" \
         "mNetPrice_1w1w,Quantity_1w1w AS Quantity_1w1w,QuantityPrefStore1_1w1w AS QuantityPrefSt" \
         "ore1_1w1w,QuantityPrefStore2_1w1w AS QuantityPrefStore2_1w1w,QuantityPrefStore3_1w1w AS" \
         " QuantityPrefStore3_1w1w,QuantityFulfillmentStore_1w1w AS QuantityFulfillmentStore_1w1w" \
         ",GrossSpend_1w1w AS GrossSpend_1w1w,NetSpend_1w1w AS NetSpend_1w1w,date_add('1970-01-01" \
         "', MaxPurchaseDate_1w1w) AS MaxPurchaseDate_1w1w,date_add('1970-01-01', MinPurchaseDate" \
         "_1w1w) AS MinPurchaseDate_1w1w,RecencyWeightedBasketWeeks75_1w1w AS RecencyWeightedBask" \
         "etWeeks75_1w1w,RecencyWeightedBasketWeeks95_1w1w AS RecencyWeightedBasketWeeks95_1w1w,P" \
         "roductCount AS ProductCount_1w1w,CustomerCount AS CustomerCount_1w1w FROM ( SELECT Subg" \
         "roup AS Subgroup,SUM(Baskets) AS Baskets_1w1w,SUM(BasketWeeks) AS BasketWeeks_1w1w,SUM(" \
         "Discount) AS Discount_1w1w,MAX(MaximumPrice) AS MaximumPrice_1w1w,MIN(MinimumPrice) AS " \
         "MinimumPrice_1w1w,MAX(MaximumNetPrice) AS MaximumNetPrice_1w1w,MIN(MinimumNetPrice) AS " \
         "MinimumNetPrice_1w1w,SUM(Quantity) AS Quantity_1w1w,SUM(QuantityPrefStore1) AS Quantity" \
         "PrefStore1_1w1w,SUM(QuantityPrefStore2) AS QuantityPrefStore2_1w1w,SUM(QuantityPrefStor" \
         "e3) AS QuantityPrefStore3_1w1w,SUM(QuantityFulfillmentStore) AS QuantityFulfillmentStor" \
         "e_1w1w,SUM(GrossSpend) AS GrossSpend_1w1w,SUM(NetSpend) AS NetSpend_1w1w,MAX(MaxPurchas" \
         "eDate) AS MaxPurchaseDate_1w1w,MIN(MinPurchaseDate) AS MinPurchaseDate_1w1w,SUM(Baskets" \
         " * pow(0.75, fisweekdiff('201744', fis_week_id) + 1)) AS RecencyWeightedBasketWeeks75_1" \
         "w1w,SUM(Baskets * pow(0.95, fisweekdiff('201744', fis_week_id) + 1)) AS RecencyWeighted" \
         "BasketWeeks95_1w1w FROM ( SELECT Subgroup,Baskets,BasketWeeks,Discount,MaximumPrice,Min" \
         "imumPrice,MaximumNetPrice,MinimumNetPrice,Quantity,QuantityPrefStore1,QuantityPrefStore" \
         "2,QuantityPrefStore3,QuantityFulfillmentStore,GrossSpend,NetSpend,MaxPurchaseDate,MinPu" \
         "rchaseDate,fis_week_id FROM client_ssework.Subgroup_All_All_All_summary  WHERE fis_week" \
         "_id in ({summary_weeks}) AND Subgroup IS NOT NULL  UNION ALL  SELECT Subgroup AS Subgro" \
         "up,COUNT(DISTINCT Basket) AS Baskets,(CASE WHEN COUNT(DISTINCT Basket) > 0 THEN 1 ELSE " \
         "0 END) AS BasketWeeks,SUM(DiscountAmount) AS Discount,MAX(SpendAmount / Quantity) AS Ma" \
         "ximumPrice,MIN(SpendAmount / Quantity) AS MinimumPrice,MAX(NetSpendAmount / Quantity) A" \
         "S MaximumNetPrice,MIN(NetSpendAmount / Quantity) AS MinimumNetPrice,SUM(Quantity) AS Qu" \
         "antity,SUM(CASE WHEN Store = PreferredStore1 THEN Quantity ELSE NULL END) AS QuantityPr" \
         "efStore1,SUM(CASE WHEN Store = PreferredStore2 THEN Quantity ELSE NULL END) AS Quantity" \
         "PrefStore2,SUM(CASE WHEN Store = PreferredStore3 THEN Quantity ELSE NULL END) AS Quanti" \
         "tyPrefStore3,SUM(CASE WHEN Store = FulfillmentStore THEN Quantity ELSE NULL END) AS Qua" \
         "ntityFulfillmentStore,SUM(SpendAmount) AS GrossSpend,SUM(NetSpendAmount) AS NetSpend,MA" \
         "X(datediff(date_id, '1970-01-01')) AS MaxPurchaseDate,MIN(datediff(date_id, '1970-01-01')) AS" \
         " MinPurchaseDate,'201744' AS fis_week_id FROM client_ssework.purchase_fct  WHERE date_id i" \
         "n ({incomplete_dates}) AND Subgroup IS NOT NULL  GROUP BY Subgroup ) AS union_tab  GROU" \
         "P BY Subgroup ) AS in_tab LEFT JOIN ( SELECT tab1.Subgroup,ProductCount,CustomerCount F" \
         "ROM (SELECT Subgroup,COUNT(DISTINCT Product) AS ProductCount FROM client_ssework.featur" \
         "e_distinct_tab_1w1w WHERE cadence_week=201744 AND Subgroup IS NOT NULL GROUP BY Subgroup) AS tab1  INNER JOIN (" \
         "SELECT Subgroup,COUNT(DISTINCT Customer) AS CustomerCount FROM client_ssework.feature_d" \
         "istinct_tab_1w1w WHERE cadence_week=201744 AND Subgroup IS NOT NULL GROUP BY Subgroup) AS tab2 ON (tab1.Subgrou" \
         "p = tab2.Subgroup) ) AS dist_tab ON (in_tab.Subgroup = dist_tab.Subgroup)"
mcsaaa = "CREATE TABLE IF NOT EXISTS client_pob.Subgroup_All_All_All (Subgroup string,Customer st" \
         "ring,Store string,Channel string,Baskets_1w1w bigint,Baskets_1w4w bigint,BasketWeeks_1w" \
         "1w int,BasketWeeks_1w4w int,Discount_1w1w decimal(38, 2),Discount_1w4w decimal(38, 2),M" \
         "aximumPrice_1w1w decimal(38, 2),MaximumPrice_1w4w decimal(38, 2),MinimumPrice_1w1w deci" \
         "mal(38, 2),MinimumPrice_1w4w decimal(38, 2),MaximumNetPrice_1w1w decimal(38, 2),Maximum" \
         "NetPrice_1w4w decimal(38, 2),MinimumNetPrice_1w1w decimal(38, 2),MinimumNetPrice_1w4w d" \
         "ecimal(38, 2),Quantity_1w1w decimal(24, 2),Quantity_1w4w decimal(24, 2),QuantityPrefSto" \
         "re1_1w1w decimal(24, 2),QuantityPrefStore1_1w4w decimal(24, 2),QuantityPrefStore2_1w1w " \
         "decimal(24, 2),QuantityPrefStore2_1w4w decimal(24, 2),QuantityPrefStore3_1w1w decimal(2" \
         "4, 2),QuantityPrefStore3_1w4w decimal(24, 2),QuantityFulfillmentStore_1w1w decimal(24, " \
         "2),QuantityFulfillmentStore_1w4w decimal(24, 2),GrossSpend_1w1w decimal(38, 2),GrossSpe" \
         "nd_1w4w decimal(38, 2),NetSpend_1w1w decimal(38, 2),NetSpend_1w4w decimal(38, 2),MaxPur" \
         "chaseDate_1w1w string,MaxPurchaseDate_1w4w string,MinPurchaseDate_1w1w string,MinPurcha" \
         "seDate_1w4w string,RecencyWeightedBasketWeeks75_1w1w decimal(38, 2),RecencyWeightedBask" \
         "etWeeks75_1w4w decimal(38, 2),RecencyWeightedBasketWeeks95_1w1w decimal(38, 2),RecencyW" \
         "eightedBasketWeeks95_1w4w decimal(38, 2),ProductCount_1w1w bigint,ProductCount_1w4w big" \
         "int,CustomerCount_1w1w bigint,CustomerCount_1w4w bigint,BasketsFlag_1w1w BOOLEAN,Basket" \
         "sFlag_1w4w BOOLEAN,DiscountPerBasket_1w1w decimal(38, 2),DiscountPerBasket_1w4w decimal" \
         "(38, 2),DiscountPercent_1w1w decimal(38, 2),DiscountPercent_1w4w decimal(38, 2),Average" \
         "Price_1w1w decimal(38, 2),AveragePrice_1w4w decimal(38, 2),QuantityPerBasket_1w1w decim" \
         "al(38, 2),QuantityPerBasket_1w4w decimal(38, 2),NetSpendPerBasket_1w1w decimal(38, 2),N" \
         "etSpendPerBasket_1w4w decimal(38, 2),AveragePurchaseCycle_1w1w decimal(38, 2),AveragePu" \
         "rchaseCycle_1w4w decimal(38, 2),RecencyDays_1w1w int,RecencyDays_1w4w int,CyclesSinceLa" \
         "stPurchase_1w1w decimal(6, 2),CyclesSinceLastPurchase_1w4w decimal(6, 2)) PARTITIONED B" \
         "Y (cadence_week string) STORED AS PARQUET " \
         'TBLPROPERTIES ("parquet.compression"="gzip")'
misaaa = "INSERT OVERWRITE TABLE client_pob.Subgroup_All_All_All PARTITION (cadence_week='201744'" \
         ") SELECT COALESCE(1w4w.Subgroup, 1w1w.Subgroup) AS Subgroup,COALESCE(1w4w.Customer, 1w1" \
         "w.Customer) AS Customer,COALESCE(1w4w.Store, 1w1w.Store) AS Store, COALESCE(1w4w.Channe" \
         "l, 1w1w.Channel) AS Channel,Baskets_1w1w AS Baskets_1w1w,Baskets_1w4w AS Baskets_1w4w,B" \
         "asketWeeks_1w1w AS BasketWeeks_1w1w,BasketWeeks_1w4w AS BasketWeeks_1w4w,Discount_1w1w " \
         "AS Discount_1w1w,Discount_1w4w AS Discount_1w4w,MaximumPrice_1w1w AS MaximumPrice_1w1w," \
         "MaximumPrice_1w4w AS MaximumPrice_1w4w,MinimumPrice_1w1w AS MinimumPrice_1w1w,MinimumPr" \
         "ice_1w4w AS MinimumPrice_1w4w,MaximumNetPrice_1w1w AS MaximumNetPrice_1w1w,MaximumNetPr" \
         "ice_1w4w AS MaximumNetPrice_1w4w,MinimumNetPrice_1w1w AS MinimumNetPrice_1w1w,MinimumNe" \
         "tPrice_1w4w AS MinimumNetPrice_1w4w,Quantity_1w1w AS Quantity_1w1w,Quantity_1w4w AS Qua" \
         "ntity_1w4w,QuantityPrefStore1_1w1w AS QuantityPrefStore1_1w1w,QuantityPrefStore1_1w4w A" \
         "S QuantityPrefStore1_1w4w,QuantityPrefStore2_1w1w AS QuantityPrefStore2_1w1w,QuantityPr" \
         "efStore2_1w4w AS QuantityPrefStore2_1w4w,QuantityPrefStore3_1w1w AS QuantityPrefStore3_" \
         "1w1w,QuantityPrefStore3_1w4w AS QuantityPrefStore3_1w4w,QuantityFulfillmentStore_1w1w A" \
         "S QuantityFulfillmentStore_1w1w,QuantityFulfillmentStore_1w4w AS QuantityFulfillmentSto" \
         "re_1w4w,GrossSpend_1w1w AS GrossSpend_1w1w,GrossSpend_1w4w AS GrossSpend_1w4w,NetSpend_" \
         "1w1w AS NetSpend_1w1w,NetSpend_1w4w AS NetSpend_1w4w,MaxPurchaseDate_1w1w AS MaxPurchas" \
         "eDate_1w1w,MaxPurchaseDate_1w4w AS MaxPurchaseDate_1w4w,MinPurchaseDate_1w1w AS MinPurc" \
         "haseDate_1w1w,MinPurchaseDate_1w4w AS MinPurchaseDate_1w4w,RecencyWeightedBasketWeeks75" \
         "_1w1w AS RecencyWeightedBasketWeeks75_1w1w,RecencyWeightedBasketWeeks75_1w4w AS Recency" \
         "WeightedBasketWeeks75_1w4w,RecencyWeightedBasketWeeks95_1w1w AS RecencyWeightedBasketWe" \
         "eks95_1w1w,RecencyWeightedBasketWeeks95_1w4w AS RecencyWeightedBasketWeeks95_1w4w,Produ" \
         "ctCount_1w1w AS ProductCount_1w1w,ProductCount_1w4w AS ProductCount_1w4w,CustomerCount_" \
         "1w1w AS CustomerCount_1w1w,CustomerCount_1w4w AS CustomerCount_1w4w,(CASE WHEN Baskets_" \
         "1w1w > 0 THEN TRUE ELSE FALSE END) AS BasketsFlag_1w1w,(CASE WHEN Baskets_1w4w > 0 THEN" \
         " TRUE ELSE FALSE END) AS BasketsFlag_1w4w,(Discount_1w1w / Baskets_1w1w) AS DiscountPer" \
         "Basket_1w1w,(Discount_1w4w / Baskets_1w4w) AS DiscountPerBasket_1w4w,((Discount_1w1w / " \
         "GrossSpend_1w1w) * 100) AS DiscountPercent_1w1w,((Discount_1w4w / GrossSpend_1w4w) * 10" \
         "0) AS DiscountPercent_1w4w,(GrossSpend_1w1w / Quantity_1w1w) AS AveragePrice_1w1w,(Gros" \
         "sSpend_1w4w / Quantity_1w4w) AS AveragePrice_1w4w,(Quantity_1w1w / Baskets_1w1w) AS Qua" \
         "ntityPerBasket_1w1w,(Quantity_1w4w / Baskets_1w4w) AS QuantityPerBasket_1w4w,(NetSpend_" \
         "1w1w / Baskets_1w1w) AS NetSpendPerBasket_1w1w,(NetSpend_1w4w / Baskets_1w4w) AS NetSpe" \
         "ndPerBasket_1w4w,(datediff(MaxPurchaseDate_1w1w, MinPurchaseDate_1w1w) / (Baskets_1w1w " \
         "- 1)) AS AveragePurchaseCycle_1w1w,(datediff(MaxPurchaseDate_1w4w, MinPurchaseDate_1w4w" \
         ") / (Baskets_1w4w - 1)) AS AveragePurchaseCycle_1w4w,(datediff('2018-01-01', MaxPurchas" \
         "eDate_1w1w)) AS RecencyDays_1w1w,(datediff('2018-01-01', MaxPurchaseDate_1w4w)) AS Rece" \
         "ncyDays_1w4w,((datediff('2018-01-01', MaxPurchaseDate_1w1w)) / (datediff(MaxPurchaseDat" \
         "e_1w1w, MinPurchaseDate_1w1w) / (Baskets_1w1w - 1))) AS CyclesSinceLastPurchase_1w1w,((" \
         "datediff('2018-01-01', MaxPurchaseDate_1w4w)) / (datediff(MaxPurchaseDate_1w4w, MinPurc" \
         "haseDate_1w4w) / (Baskets_1w4w - 1))) AS CyclesSinceLastPurchase_1w4w FROM client_ssewo" \
         "rk.Subgroup_All_All_All_1w4w AS 1w4w  FULL OUTER JOIN client_ssework.Subgroup_All_All_A" \
         "ll_1w1w AS 1w1w  ON (1w4w.Subgroup= 1w1w.Subgroup)"
vsaaa = "CREATE VIEW IF NOT EXISTS client_pob.v_cadenceattributefis_week_id_ChannelAll_CustomerAl" \
        "l_ProductSubgroup_StoreAll_201744 AS SELECT 'fis_week_id' AS cadenceattribute,'201744'AS" \
        " cadence,'All' AS Channelattribute,Channel AS Channel,'All' AS Customerattribute,Custome" \
        "r AS Customer,'Subgroup' AS Productattribute,Subgroup AS Product,'All' AS Storeattribute" \
        ",Store AS Store,Baskets_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Baskets_" \
        "1w1w,Baskets_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Baskets_1w4w,Basket" \
        "Weeks_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_BasketWeeks_1w1w,BasketWee" \
        "ks_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_BasketWeeks_1w4w,Discount_1w1" \
        "w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Discount_1w1w,Discount_1w4w AS Chan" \
        "nelAll_CustomerAll_ProductSubgroup_StoreAll_Discount_1w4w,MaximumPrice_1w1w AS ChannelAl" \
        "l_CustomerAll_ProductSubgroup_StoreAll_MaximumPrice_1w1w,MaximumPrice_1w4w AS ChannelAll" \
        "_CustomerAll_ProductSubgroup_StoreAll_MaximumPrice_1w4w,MinimumPrice_1w1w AS ChannelAll_" \
        "CustomerAll_ProductSubgroup_StoreAll_MinimumPrice_1w1w,MinimumPrice_1w4w AS ChannelAll_C" \
        "ustomerAll_ProductSubgroup_StoreAll_MinimumPrice_1w4w,MaximumNetPrice_1w1w AS ChannelAll" \
        "_CustomerAll_ProductSubgroup_StoreAll_MaximumNetPrice_1w1w,MaximumNetPrice_1w4w AS Chann" \
        "elAll_CustomerAll_ProductSubgroup_StoreAll_MaximumNetPrice_1w4w,MinimumNetPrice_1w1w AS " \
        "ChannelAll_CustomerAll_ProductSubgroup_StoreAll_MinimumNetPrice_1w1w,MinimumNetPrice_1w4" \
        "w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_MinimumNetPrice_1w4w,Quantity_1w1w " \
        "AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Quantity_1w1w,Quantity_1w4w AS Channe" \
        "lAll_CustomerAll_ProductSubgroup_StoreAll_Quantity_1w4w,QuantityPrefStore1_1w1w AS Chann" \
        "elAll_CustomerAll_ProductSubgroup_StoreAll_QuantityPrefStore1_1w1w,QuantityPrefStore1_1w" \
        "4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_QuantityPrefStore1_1w4w,QuantityPr" \
        "efStore2_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_QuantityPrefStore2_1w1w" \
        ",QuantityPrefStore2_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_QuantityPref" \
        "Store2_1w4w,QuantityPrefStore3_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Q" \
        "uantityPrefStore3_1w1w,QuantityPrefStore3_1w4w AS ChannelAll_CustomerAll_ProductSubgroup" \
        "_StoreAll_QuantityPrefStore3_1w4w,QuantityFulfillmentStore_1w1w AS ChannelAll_CustomerAl" \
        "l_ProductSubgroup_StoreAll_QuantityFulfillmentStore_1w1w,QuantityFulfillmentStore_1w4w A" \
        "S ChannelAll_CustomerAll_ProductSubgroup_StoreAll_QuantityFulfillmentStore_1w4w,GrossSpe" \
        "nd_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_GrossSpend_1w1w,GrossSpend_1w" \
        "4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_GrossSpend_1w4w,NetSpend_1w1w AS C" \
        "hannelAll_CustomerAll_ProductSubgroup_StoreAll_NetSpend_1w1w,NetSpend_1w4w AS ChannelAll" \
        "_CustomerAll_ProductSubgroup_StoreAll_NetSpend_1w4w,MaxPurchaseDate_1w1w AS ChannelAll_C" \
        "ustomerAll_ProductSubgroup_StoreAll_MaxPurchaseDate_1w1w,MaxPurchaseDate_1w4w AS Channel" \
        "All_CustomerAll_ProductSubgroup_StoreAll_MaxPurchaseDate_1w4w,MinPurchaseDate_1w1w AS Ch" \
        "annelAll_CustomerAll_ProductSubgroup_StoreAll_MinPurchaseDate_1w1w,MinPurchaseDate_1w4w " \
        "AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_MinPurchaseDate_1w4w,RecencyWeightedB" \
        "asketWeeks75_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_RecencyWeightedBask" \
        "etWeeks75_1w1w,RecencyWeightedBasketWeeks75_1w4w AS ChannelAll_CustomerAll_ProductSubgro" \
        "up_StoreAll_RecencyWeightedBasketWeeks75_1w4w,RecencyWeightedBasketWeeks95_1w1w AS Chann" \
        "elAll_CustomerAll_ProductSubgroup_StoreAll_RecencyWeightedBasketWeeks95_1w1w,RecencyWeig" \
        "htedBasketWeeks95_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_RecencyWeighte" \
        "dBasketWeeks95_1w4w,ProductCount_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll" \
        "_ProductCount_1w1w,ProductCount_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_" \
        "ProductCount_1w4w,CustomerCount_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_" \
        "CustomerCount_1w1w,CustomerCount_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll" \
        "_CustomerCount_1w4w,BasketsFlag_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_" \
        "BasketsFlag_1w1w,BasketsFlag_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Bas" \
        "ketsFlag_1w4w,DiscountPerBasket_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_" \
        "DiscountPerBasket_1w1w,DiscountPerBasket_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_" \
        "StoreAll_DiscountPerBasket_1w4w,DiscountPercent_1w1w AS ChannelAll_CustomerAll_ProductSu" \
        "bgroup_StoreAll_DiscountPercent_1w1w,DiscountPercent_1w4w AS ChannelAll_CustomerAll_Prod" \
        "uctSubgroup_StoreAll_DiscountPercent_1w4w,AveragePrice_1w1w AS ChannelAll_CustomerAll_Pr" \
        "oductSubgroup_StoreAll_AveragePrice_1w1w,AveragePrice_1w4w AS ChannelAll_CustomerAll_Pro" \
        "ductSubgroup_StoreAll_AveragePrice_1w4w,QuantityPerBasket_1w1w AS ChannelAll_CustomerAll" \
        "_ProductSubgroup_StoreAll_QuantityPerBasket_1w1w,QuantityPerBasket_1w4w AS ChannelAll_Cu" \
        "stomerAll_ProductSubgroup_StoreAll_QuantityPerBasket_1w4w,NetSpendPerBasket_1w1w AS Chan" \
        "nelAll_CustomerAll_ProductSubgroup_StoreAll_NetSpendPerBasket_1w1w,NetSpendPerBasket_1w4" \
        "w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_NetSpendPerBasket_1w4w,AveragePurch" \
        "aseCycle_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_AveragePurchaseCycle_1w" \
        "1w,AveragePurchaseCycle_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_AverageP" \
        "urchaseCycle_1w4w,RecencyDays_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Re" \
        "cencyDays_1w1w,RecencyDays_1w4w AS ChannelAll_CustomerAll_ProductSubgroup_StoreAll_Recen" \
        "cyDays_1w4w,CyclesSinceLastPurchase_1w1w AS ChannelAll_CustomerAll_ProductSubgroup_Store" \
        "All_CyclesSinceLastPurchase_1w1w,CyclesSinceLastPurchase_1w4w AS ChannelAll_CustomerAll_" \
        "ProductSubgroup_StoreAll_CyclesSinceLastPurchase_1w4w FROM client_pob.Subgroup_All_All_A" \
        "ll WHERE cadence_week = '201744'"
result_set = {
    "cadence_for_date_short_name": dt.strptime("2018-01-02", "%Y-%m-%d").date(),
    "cadence_for_fis_week_id": dt.strptime("2017-12-31", "%Y-%m-%d").date(),
    "cadence_week_for_fis_week_id": "201744",
    "cadence_week_date_short_name": "201745",
    "since_date": dt.strptime("2017-12-04", "%Y-%m-%d").date(),
    "required_fis_weeks": ["201744", "201743", "201742", "201741"],
    "Product_Customer_All_All_supplementary": {
        "aggregation": {
            "feature_name": "Product_Customer_All_All",
            "tab_name": "client_ssework.Product_Customer_All_All_1w1w",
            "run_mode": "parallel",
            "wave": 1,
            "group_info": ["Product", "Customer"],
            "ddl_drop": "DROP TABLE IF EXISTS client_ssework.Product_Customer_All_All_1w1w",
            "ddl_create": "CREATE TABLE IF NOT EXISTS client_ssework.Product_Customer_All_All_1w1w("
                          "Product string,Customer string,Store string,Channel string,Baskets_1w1w "
                          "bigint,BasketWeeks_1w1w int,Division string,Group string,Section string,"
                          "Subgroup string) PARTITIONED BY (cadence_week string) STORED AS PARQUET "
                          'TBLPROPERTIES ("parquet.compression"="gzip")',
            "dml": "INSERT OVERWRITE TABLE client_ssework.Product_Customer_All_All_1w1w PARTITION ("
                   "cadence_week = '201743') SELECT in_tab.Product AS Product,in_tab.Customer AS Cu"
                   "stomer,'All' AS Store,'All' AS Channel,Baskets_1w1w AS Baskets_1w1w,BasketWeeks"
                   "_1w1w AS BasketWeeks_1w1w,dim_Product.Division AS Division,dim_Product.Group AS"
                   " Group,dim_Product.Section AS Section,dim_Product.Subgroup AS Subgroup FROM ( S"
                   "ELECT Product AS Product,Customer AS Customer,SUM(Baskets) AS Baskets_1w1w,SUM("
                   "BasketWeeks) AS BasketWeeks_1w1w FROM ( SELECT Product,Customer,Baskets,BasketW"
                   "eeks,fis_week_id FROM client_ssework.Product_Customer_All_All_summary  WHERE fi"
                   "s_week_id in ({summary_weeks}) AND Product IS NOT NULL AND Customer IS NOT NULL"
                   "  UNION ALL  SELECT Product AS Product,Customer AS Customer,COUNT(DISTINCT Bask"
                   "et) AS Baskets,(CASE WHEN COUNT(DISTINCT Basket) > 0 THEN 1 ELSE 0 END) AS Bask"
                   "etWeeks,'201743' AS fis_week_id FROM client_ssework.purchase_fct WHERE date_id in "
                   "({incomplete_dates}) AND Product IS NOT NULL AND Customer IS NOT NULL GROUP BY "
                   "Product,Customer ) AS union_tab  GROUP BY Product,Customer) AS in_tab LEFT JOIN"
                   " ( SELECT DISTINCT Product,Division,Group,Section,Subgroup FROM client_ssework."
                   "Product_dim_tab ) AS dim_Product ON (in_tab.Product = dim_Product.Product)",
        },
    },
    "All_All_All_All": {
        "summary": {
            "feature_name": "All_All_All_All",
            "tab_name": "client_ssework.All_All_All_All_summary",
            "run_mode": "parallel",
            "wave": 1,
            "group_info": [],
            "ddl_create": scaaaa,
            "dml": siaaaa,
        },
        "aggregation": {
            "feature_name": "All_All_All_All",
            "tab_name": "client_ssework.All_All_All_All_1w1w",
            "run_mode": "parallel",
            "wave": 1,
            "group_info": [],
            "ddl_drop": "DROP TABLE IF EXISTS client_ssework.All_All_All_All_1w1w",
            "ddl_create": acaaaa,
            "dml": aiaaaa,
        },
        "merge": {
            "feature_name": "All_All_All_All",
            "tab_name": "client_pob.All_All_All_All",
            "agg_tabs": [("client_ssework.All_All_All_All_1w4w", (1, 4)),
                         ("client_ssework.All_All_All_All_1w1w", (1, 1))],
            "run_mode": "parallel",
            "wave": 1,
            "group_info": [],
            "ddl_drop": "DROP TABLE IF EXISTS client_pob.All_All_All_All",
            "ddl_create": mcaaaa,
            "dml": miaaaa,
        },
        "view": {
            "feature_name": "All_All_All_All",
            "tab_name": "client_pob.All_All_All_All",
            "view_name": "client_pob.v_cadenceattributefis_week_id_ChannelAll_CustomerAll_"
                         "ProductAll_StoreAll_201744",
            "current_view_name": "client_pob.v_cadenceattributefis_week_id_ChannelAll_CustomerAll_"
                                 "ProductAll_StoreAll_current",
            "ddl_drop": "DROP VIEW IF EXISTS client_pob.v_cadenceattributefis_week_id_ChannelAll_"
                        "CustomerAll_ProductAll_StoreAll_201744",
            "current_ddl_drop": "DROP VIEW IF EXISTS client_pob.v_cadenceattributefis_week_id_"
                                "ChannelAll_CustomerAll_ProductAll_StoreAll_current",
            "ddl_create": vaaaa,
            "current_ddl_create": "CREATE VIEW IF NOT EXISTS client_pob.v_cadenceattributefis_week"
                                  "_id_ChannelAll_CustomerAll_ProductAll_StoreAll_current AS "
                                  "SELECT * FROM client_pob.v_cadenceattributefis_week_id_"
                                  "ChannelAll_CustomerAll_ProductAll_StoreAll_201744",
        }
    },
    "Subgroup_All_All_All": {
        "summary": {
            "feature_name": "Subgroup_All_All_All",
            "tab_name": "client_ssework.Subgroup_All_All_All_summary",
            "run_mode": "parallel",
            "wave": 1,
            "group_info": ["Subgroup"],
            "ddl_create": scsaaa,
            "dml": sisaaa,
        },
        "aggregation": {
            "feature_name": "Subgroup_All_All_All",
            "tab_name": "client_ssework.Subgroup_All_All_All_1w1w",
            "run_mode": "parallel",
            "wave": 1,
            "group_info": ["Subgroup"],
            "ddl_drop": "DROP TABLE IF EXISTS client_ssework.Subgroup_All_All_All_1w1w",
            "ddl_create": acsaaa,
            "dml": aisaaa,
        },
        "merge": {
            "feature_name": "Subgroup_All_All_All",
            "tab_name": "client_pob.Subgroup_All_All_All",
            "agg_tabs": [("client_ssework.Subgroup_All_All_All_1w4w", (1, 4)),
                         ("client_ssework.Subgroup_All_All_All_1w1w", (1, 1))],
            "run_mode": "parallel",
            "wave": 1,
            "group_info": ["Subgroup"],
            "ddl_drop": "DROP TABLE IF EXISTS client_pob.Subgroup_All_All_All",
            "ddl_create": mcsaaa,
            "dml": misaaa,
        },
        "view": {
            "feature_name": "Subgroup_All_All_All",
            "tab_name": "client_pob.Subgroup_All_All_All",
            "view_name": "client_pob.v_cadenceattributefis_week_id_ChannelAll_CustomerAll_"
                         "ProductSubgroup_StoreAll_201744",
            "current_view_name": "client_pob.v_cadenceattributefis_week_id_ChannelAll_CustomerAll_"
                                 "ProductSubgroup_StoreAll_current",
            "ddl_drop": "DROP VIEW IF EXISTS client_pob.v_cadenceattributefis_week_id_ChannelAll_"
                        "CustomerAll_ProductSubgroup_StoreAll_201744",
            "current_ddl_drop": "DROP VIEW IF EXISTS client_pob.v_cadenceattributefis_week_id_Chan"
                                "nelAll_CustomerAll_ProductSubgroup_StoreAll_current",
            "ddl_create": vsaaa,
            "current_ddl_create": "CREATE VIEW IF NOT EXISTS client_pob.v_cadenceattributefis_week"
                                  "_id_ChannelAll_CustomerAll_ProductSubgroup_StoreAll_current AS "
                                  "SELECT * FROM client_pob.v_cadenceattributefis_week_id_Channel"
                                  "All_CustomerAll_ProductSubgroup_StoreAll_201744",
        }
    },
    "summary_tab_list": [
        "all_all_all_all_summary", "product_customer_all_all_summary",
        "subgroup_all_all_all_summary", "subgroup_customer_all_all_summary",
        "feature_distinct_tab_summary"
    ],
    "aggregation_tab_list": [
        "all_all_all_all_1w1w", "all_all_all_all_1w4w",
        "product_customer_all_all_1w1w", "product_customer_all_all_1w4w",
        "subgroup_all_all_all_1w1w", "subgroup_all_all_all_1w4w",
        "subgroup_customer_all_all_1w1w", "subgroup_customer_all_all_1w4w",
        "feature_distinct_tab_1w1w", "feature_distinct_tab_1w4w"
    ],
    "aggregation_tab_list_supplementary": [
        "product_customer_all_all_1w1w", "product_customer_all_all_1w4w",
    ],
    "merge_tab_list": [
        "all_all_all_all", "product_customer_all_all", "subgroup_all_all_all",
        "subgroup_customer_all_all"
    ],
    "view_list": [
        # all_all_all_all
        "v_cadenceattributefis_week_id_channelall_customerall_productall_storeall_201744",
        "v_cadenceattributefis_week_id_channelall_customerall_productall_storeall_current",
        # product_customer_all_all
        "v_cadenceattributefis_week_id_channelall_customercustomer_productproduct_storeall_201744",
        "v_cadenceattributefis_week_id_channelall_customercustomer_productproduct_storeall_current",
        # subgroup_all_all_all
        "v_cadenceattributefis_week_id_channelall_customerall_productsubgroup_storeall_201744",
        "v_cadenceattributefis_week_id_channelall_customerall_productsubgroup_storeall_current",
        # subgroup_customer_all_all
        "v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_201744",
        "v_cadenceattributefis_week_id_channelall_customercustomer_productsubgroup_storeall_current"
    ],
    "denorm_summary_data_retain_week": ["201744", "201743"],
    "merge_data_retain_week": [],
}

"""
date_dim/date_df - 42 rows for each date_id between 2017-11-27 & 2018-01-07
"""
date_schema = pt.StructType([
    pt.StructField("date_id", pt.DateType(), True),
    pt.StructField("date_name", pt.StringType(), True),
    pt.StructField("date_short_name", pt.StringType(), True),
    pt.StructField("day_of_week_name", pt.StringType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("fis_day_of_week_num", pt.ShortType(), True),
    pt.StructField("fis_year_id", pt.IntegerType(), True),
    pt.StructField("stores_closed_flag", pt.BooleanType(), True)
])
date_lst = [
    (dt.strptime("2017-11-27 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 27, 2017", "2017-11-27", "MONDAY", "201740", 1,
     2017, None),
    (dt.strptime("2017-11-28 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 28, 2017", "2017-11-28", "TUESDAY", "201740", 2,
     2017, None),
    (dt.strptime("2017-11-29 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 29, 2017", "2017-11-29", "WEDNESDAY", "201740",
     3, 2017, None),
    (dt.strptime("2017-11-30 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 30, 2017", "2017-11-30", "THURSDAY", "201740", 4,
    2017, None),
    (dt.strptime("2017-12-01 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 01, 2017", "2017-12-01", "FRIDAY", "201740", 5,
     2017, None),
    (dt.strptime("2017-12-02 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 02, 2017", "2017-12-02", "SATURDAY", "201740", 6,
    2017, None),
    (dt.strptime("2017-12-03 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 03, 2017", "2017-12-03", "SUNDAY", "201740", 7,
     2017, None),
    (dt.strptime("2017-12-04 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 04, 2017", "2017-12-04", "MONDAY", "201741", 1,
     2017, None),
    (dt.strptime("2017-12-05 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 05, 2017", "2017-12-05", "TUESDAY", "201741", 2,
     2017, None),
    (dt.strptime("2017-12-06 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 06, 2017", "2017-12-06", "WEDNESDAY", "201741",
     3, 2017, None),
    (dt.strptime("2017-12-07 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 07, 2017", "2017-12-07", "THURSDAY", "201741", 4,
    2017, None),
    (dt.strptime("2017-12-08 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 08, 2017", "2017-12-08", "FRIDAY", "201741", 5,
     2017, None),
    (dt.strptime("2017-12-09 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 09, 2017", "2017-12-09", "SATURDAY", "201741", 6,
    2017, None),
    (dt.strptime("2017-12-10 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 10, 2017", "2017-12-10", "SUNDAY", "201741", 7,
     2017, None),
    (dt.strptime("2017-12-11 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 11, 2017", "2017-12-11", "MONDAY", "201742", 1,
     2017, None),
    (dt.strptime("2017-12-12 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 12, 2017", "2017-12-12", "TUESDAY", "201742", 2,
     2017, None),
    (dt.strptime("2017-12-13 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 13, 2017", "2017-12-13", "WEDNESDAY", "201742",
     3, 2017, None),
    (dt.strptime("2017-12-14 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 14, 2017", "2017-12-14", "THURSDAY", "201742", 4,
    2017, None),
    (dt.strptime("2017-12-15 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 15, 2017", "2017-12-15", "FRIDAY", "201742", 5,
     2017, None),
    (dt.strptime("2017-12-16 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 16, 2017", "2017-12-16", "SATURDAY", "201742", 6,
    2017, None),
    (dt.strptime("2017-12-17 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 17, 2017", "2017-12-17", "SUNDAY", "201742", 7,
     2017, None),
    (dt.strptime("2017-12-18 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 18, 2017", "2017-12-18", "MONDAY", "201743", 1,
     2017, None),
    (dt.strptime("2017-12-19 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 19, 2017", "2017-12-19", "TUESDAY", "201743", 2,
     2017, None),
    (dt.strptime("2017-12-20 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 20, 2017", "2017-12-20", "WEDNESDAY", "201743",
     3, 2017, None),
    (dt.strptime("2017-12-21 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 21, 2017", "2017-12-21", "THURSDAY", "201743", 4,
    2017, None),
    (dt.strptime("2017-12-22 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 22, 2017", "2017-12-22", "FRIDAY", "201743", 5,
     2017, None),
    (dt.strptime("2017-12-23 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 23, 2017", "2017-12-23", "SATURDAY", "201743", 6,
    2017, None),
    (dt.strptime("2017-12-24 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 24, 2017", "2017-12-24", "SUNDAY", "201743", 7,
     2017, None),
    (dt.strptime("2017-12-25 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 25, 2017", "2017-12-25", "MONDAY", "201744", 1,
     2017, True),
    (dt.strptime("2017-12-26 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 26, 2017", "2017-12-26", "TUESDAY", "201744", 2,
     2017, None),
    (dt.strptime("2017-12-27 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 27, 2017", "2017-12-27", "WEDNESDAY", "201744",
     3, 2017, None),
    (dt.strptime("2017-12-28 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 28, 2017", "2017-12-28", "THURSDAY", "201744", 4,
    2017, None),
    (dt.strptime("2017-12-29 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 29, 2017", "2017-12-29", "FRIDAY", "201744", 5,
     2017, None),
    (dt.strptime("2017-12-30 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 30, 2017", "2017-12-30", "SATURDAY", "201744", 6,
    2017, None),
    (dt.strptime("2017-12-31 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 31, 2017", "2017-12-31", "SUNDAY", "201744", 7,
     2017, True),
    (dt.strptime("2018-01-01 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 01, 2018", "2018-01-01", "MONDAY", "201745", 1,
     2017, True),
    (dt.strptime("2018-01-02 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 02, 2018", "2018-01-02", "TUESDAY", "201745", 2,
     2017, None),
    (dt.strptime("2018-01-03 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 03, 2018", "2018-01-03", "WEDNESDAY", "201745", 3,
    2017, None),
    (dt.strptime("2018-01-04 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 04, 2018", "2018-01-04", "THURSDAY", "201745", 4,
     2017, None),
    (dt.strptime("2018-01-05 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 05, 2018", "2018-01-05", "FRIDAY", "201745", 5,
     2017, None),
    (dt.strptime("2018-01-06 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 06, 2018", "2018-01-06", "SATURDAY", "201745", 6,
     2017, None),
    (dt.strptime("2018-01-07 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 07, 2018", "2018-01-07", "SUNDAY", "201745", 7,
     2017, None),
    (dt.strptime("2018-01-08 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 08, 2018", "2018-01-08", "MONDAY", "201746", 1,
     2017, None),
]

"""
store_dim_c/store_df
"""
store_schema = pt.StructType([
    pt.StructField("store_id", pt.LongType(), True),
    pt.StructField("Store", pt.StringType(), True),
    pt.StructField("StoreDescription", pt.StringType(), True),
    pt.StructField("Banner", pt.StringType(), True),
    pt.StructField("BannerDescription", pt.StringType(), True),
    pt.StructField("StoreRegion", pt.StringType(), True)
])
store_lst = [
    (-1, "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", None, None, None),
    (1, "Store1", "store 1", "Banner1", None, None),
    (2, "Store2", "store 2", "Banner1", None, None),
    (3, "Store3", "store 3", "Banner1", None, None),
    (4, "Store4", "store 4", "Banner1", None, None),
    (5, "Store5", "store 5", "Banner1", None, None),
    (6, "Store6", "store 6", "Banner2", None, None),
    (7, "Store7", "store 7", "Banner2", None, None),
    (8, "Store8", "store 8", "Banner2", None, None),
    (9, "Store9", "store 9", "Banner2", None, None),
    (10, "Store10", "store 10", "Banner2", None, None),
    (11, "Store11", "store 11", "Banner3", None, None),
    (12, "Store12", "store 12", "Banner3", None, None),
    (13, "Store13", "store 13", "Banner3", None, None),
    (14, "Store14", "store 14", "Banner3", None, None),
    (15, "Store15", "store 15", "Banner3", None, None),
    (16, "Store16", "store 16", "Banner4", None, None),
    (17, "Store17", "store 17", "Banner4", None, None),
    (18, "Store18", "store 18", "Banner4", None, None),
    (19, "Store19", "store 19", "Banner4", None, None),
    (20, "Store20", "store 20", "Banner4", None, None),
    (21, "Store21", "store 21", "Banner5", None, None),
    (22, "Store22", "store 22", "Banner5", None, None),
    (23, "Store23", "store 23", "Banner5", None, None),
    (24, "Store24", "store 24", "Banner5", None, None),
    (25, "Store25", "store 25", "Banner5", None, None),
    (26, "Store26", "store 26", "Banner6", None, None),
    (27, "Store27", "store 27", "Banner6", None, None),
    (28, "Store28", "store 28", "Banner6", None, None),
    (29, "Store29", "store 29", "Banner6", None, None),
    (30, "Store30", "store 30", "Banner6", None, None),
    (31, "Store31", "store 31", "Banner7", None, None),
    (32, "Store32", "store 32", "Banner7", None, None),
]

"""
prod_dim_c/product_df
"""
product_schema = pt.StructType([
    pt.StructField("prod_id", pt.LongType(), True),
    pt.StructField("Product", pt.StringType(), True),
    pt.StructField("Subgroup", pt.StringType(), True),
    pt.StructField("Group", pt.StringType(), True),
    pt.StructField("Section", pt.StringType(), True),
    pt.StructField("Division", pt.StringType(), True),
])

product_lst = [
    (0, "Product0", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION"),
    (1, "Product1", "A1A1", "A1A", "A1", "A"),
    (2, "Product2", "B1A1", "B1A", "B1", "B"),
    (3, "Product3", "C1A1", "C1A", "C1", "C"),
    (4, "Product4", "A1B1", "A1B", "A1", "A"),
    (5, "Product5", "C1B1", "C1B", "C1", "C"),
    (6, "Product6", "C1A2", "C1A", "C1", "C"),
    (7, "Product7", "B1B1", "B1B", "B1", "B"),
    (8, "Product8", "D1A1", "D1A", "D1", "D"),
    (9, "Product9", "D1B1", "D1B", "D1", "D"),
    (10, "Product10", "D1A2", "D1A", "D1", "D"),
    (11, "Product11", "D2A1", "D2A", "D2", "D"),
    (12, "Product12", "D2B1", "D2B", "D2", "D"),
    (13, "Product13", "D2A1", "D2A", "D2", "D"),
    (14, "Product14", "A2A1", "A2A", "A2", "A"),
    (15, "Product15", "B2A1", "B2A", "B2", "B"),
    (16, "Product16", "B2B1", "B2B", "B2", "B"),
    (17, "Product17", "D1B2", "D1B", "D1", "D"),
    (18, "Product18", "A2B1", "A2B", "A2", "A"),
    (19, "Product19", "D2B2", "D2B", "D2", "D"),
    (20, "Product20", "B1A1", "B1A", "B1", "B"),
    (21, "Product21", "A1A1", "A1A", "A1", "A"),
    (22, "Product22", "A1B1", "A1B", "A1", "A"),
    (23, "Product23", "A2A2", "A2A", "A2", "A"),
    (24, "Product24", "B2A2", "B2A", "B2", "B"),
    (25, "Product25", "B2B2", "B2B", "B2", "B"),
    (26, "Product26", "C2A1", "C2A", "C2", "C"),
    (27, "Product27", "C2B1", "C2B", "C2", "C"),
    (28, "Product28", "C2A1", "C2A", "C2", "C"),
    (29, "Product29", "B1B2", "B1B", "B1", "B"),
    (30, "Product30", "C1B2", "C1B", "C1", "C"),
    (31, "Product31", "A2B2", "A2B", "A2", "A"),
]

"""
customer_df
"""
customer_schema = pt.StructType([
    pt.StructField("card_id", pt.LongType(), True),
    pt.StructField("Customer", pt.StringType(), True),
    pt.StructField("IsEmailable", pt.BooleanType(), True),
    pt.StructField("SloyaltyHigh", pt.StringType(), True),
    pt.StructField("SloyaltyLow", pt.StringType(), True),
    pt.StructField("FulfillmentStore", pt.StringType(), True),
    pt.StructField("PreferredStore1", pt.StringType(), True),
    pt.StructField("PreferredStore2", pt.StringType(), True),
    pt.StructField("PreferredStore3", pt.StringType(), True),
])
customer_lst = [
    (1, "Customer1", False, "SLH1", "SLL1", "Store30", "Store22", "Store30", "UNKNOWN_DIMENSION"),
    (2, "Customer2", False, "SLH2", "SLL2", "Store4", "Store4", "Store1", "Store2"),
    (3, "Customer3", False, "SLH2", "SLL2", "Store3", "Store3", "UNKNOWN_DIMENSION",
     "UNKNOWN_DIMENSION"),
    (4, "Customer4", False, "SLH2", "SLL2", "Store27", "Store20", "Store22", "Store30"),
    (5, "Customer5", False, "SLH2", "SLL2", "Store20", "Store28", "Store2", "UNKNOWN_DIMENSION"),
    (6, "Customer6", True, "SLH2", "SLL2", "Store24", "Store24", "Store4", "Store23"),
    (7, "Customer7", False, "SLH3", "SLL3", "Store8", "Store25", "UNKNOWN_DIMENSION",
     "UNKNOWN_DIMENSION"),
    (8, "Customer8", True, "SLH2", "SLL2", "Store8", "Store7", "Store18", "Store19"),
    (9, "Customer9", False, "SLH1", "SLL1", "Store18", "Store18", "Store11", "UNKNOWN_DIMENSION"),
    (10, "Customer10", True, "SLH2", "SLL2", "Store11", "Store11", "Store8", "Store18"),
    (11, "Customer11", False, "SLH3", "SLL3", "Store18", "Store18", "Store26", "Store31"),
    (12, "Customer12", True, "SLH2", "SLL2", "Store5", "Store5", "Store19", "Store14"),
    (13, "Customer13", True, "SLH2", "SLL2", "Store6", "Store20", "Store5", "Store1"),
    (14, "Customer14", True, "SLH2", "SLL2", "Store23", "Store23", "Store20", "Store27"),
    (15, "Customer15", True, "SLH1", "SLL4", "store12", "store1", "store10", "store11"),
    (16, "Customer16", False, "SLH2", "SLL5", "Store24", "Store24", "Store31", "UNKNOWN_DIMENSION"),
    (17, "Customer17", False, "SLH2", "SLL2", "Store11", "Store10", "Store20", "Store12"),
    (18, "Customer18", False, "SLH2", "SLL2", "Store2", "Store2", "Store3", "Store4"),
    (19, "Customer19", True, "SLH2", "SLL2", "Store31", "Store30", "Store12", "UNKNOWN_DIMENSION"),
    (20, "Customer20", True, "SLH1", "SLL1", "Store18", "Store16", "Store17", "Store19"),
]

"""
transaction_item_fct - 56 mocked transaction between 2017-12-01 & 2018-01-03
"""
trans_schema = pt.StructType([
    pt.StructField("basket", pt.StringType(), True),
    pt.StructField("datetime", pt.TimestampType(), True),
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("quantity", pt.IntegerType(), True),
    pt.StructField("spendamount", pt.DecimalType(15, 2), True),
    pt.StructField("netspendamount", pt.DecimalType(15, 2), True),
    pt.StructField("discountamount", pt.DecimalType(15, 2), True),
    pt.StructField("fis_year_id", pt.IntegerType(), True),
    pt.StructField("fis_week_id", pt.IntegerType(), True),
    pt.StructField("date_id", pt.DateType(), True),
])
trans_lst = [
    ('20171129193423499870213247', datetime.datetime(2017, 11, 29, 0, 0), 'Product5', 'Customer20', 'Store16',
     'Channel1', 1, Decimal('10.0'), Decimal('0.0'), Decimal('10.0'), 2017, 201740, datetime.date(2017, 11, 29)),
    ('20171130100591093610012352', datetime.datetime(2017, 11, 30, 0, 0), 'Product28', None, 'Store8', 'Channel1', 1,
     Decimal('0.99'), Decimal('0.99'), Decimal('0.0'), 2017, 201740, datetime.date(2017, 11, 30)),
    ('20171201100950023960194157', datetime.datetime(2017, 12, 1, 0, 0), 'Product24', 'Customer7', 'Store9', 'Channel1',
     2, Decimal('3.76'), Decimal('3.0'), Decimal('0.76'), 2017, 201740, datetime.date(2017, 12, 1)),
    ('20171202084727039160822244', datetime.datetime(2017, 12, 2, 0, 0), 'Product31', 'Customer2', 'Store4', 'Channel1',
     1, Decimal('41.99'), Decimal('41.99'), Decimal('0.0'), 2017, 201740, datetime.date(2017, 12, 2)),
    ('20171203144007026950149675', datetime.datetime(2017, 12, 3, 0, 0), 'Product8', 'Customer4', 'Store27', 'Channel1',
     1, Decimal('1.29'), Decimal('1.1'), Decimal('0.19'), 2017, 201740, datetime.date(2017, 12, 3)),
    ('20171204132046039250829023', datetime.datetime(2017, 12, 4, 0, 0), 'Product30', 'Customer14', 'Store23',
     'Channel1', 1, Decimal('47.93'), Decimal('47.93'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 4)),
    ('20171205172100023100165409', datetime.datetime(2017, 12, 5, 0, 0), 'Product16', 'Customer8', 'Store7', 'Channel1',
     1, Decimal('4.0'), Decimal('4.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 5)),
    ('20171206151619060560788167', datetime.datetime(2017, 12, 6, 0, 0), 'Product28', None, 'Store8', 'Channel1', 1,
     Decimal('0.99'), Decimal('0.99'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 6)),
    (
    '20171206151619325325435331', datetime.datetime(2017, 12, 6, 0, 0), 'Product28', 'Customer18', 'Store2', 'Channel1',
    1, Decimal('0.99'), Decimal('0.99'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 6)),
    (
    '20171207194616042343535787', datetime.datetime(2017, 12, 7, 0, 0), 'Product7', 'Customer20', 'Store16', 'Channel1',
    1, Decimal('10.0'), Decimal('10.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 7)),
    (
    '20171207194616043570212117', datetime.datetime(2017, 12, 7, 0, 0), 'Product5', 'Customer20', 'Store17', 'Channel1',
    1, Decimal('10.0'), Decimal('0.0'), Decimal('10.0'), 2017, 201741, datetime.date(2017, 12, 7)),
    ('20171208155253052347723957', datetime.datetime(2017, 12, 8, 0, 0), 'Product4', 'Customer5', 'Store28', 'Channel1',
     2, Decimal('3.6'), Decimal('3.0'), Decimal('0.6'), 2017, 201741, datetime.date(2017, 12, 8)),
    (
    '20171208155253059040314327', datetime.datetime(2017, 12, 8, 0, 0), 'Product12', 'Customer5', 'Store28', 'Channel1',
    2, Decimal('3.6'), Decimal('3.0'), Decimal('0.6'), 2017, 201741, datetime.date(2017, 12, 8)),
    ('20171209193441051090911618', datetime.datetime(2017, 12, 9, 0, 0), 'Product27', None, 'Store25', 'Channel1', 1,
     Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
    (
    '20171209193441008064406123', datetime.datetime(2017, 12, 9, 0, 0), 'Product27', 'Customer4', 'Store20', 'Channel1',
    1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
    ('20171209193441051090806440', datetime.datetime(2017, 12, 9, 0, 0), 'Product1', 'Customer7', 'Store25', 'Channel1',
     1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
    ('20171209193441008064100806', datetime.datetime(2017, 12, 9, 0, 0), 'Product27', 'Customer11', 'Store18',
     'Channel1', 1, Decimal('20.0'), Decimal('20.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
    (
    '20171209095798274987398474', datetime.datetime(2017, 12, 9, 0, 0), 'Product11', 'Customer6', 'Store24', 'Channel1',
    1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 9)),
    ('20171210141252063990066053', datetime.datetime(2017, 12, 10, 0, 0), 'Product3', None, 'Store6', 'Channel1', 1,
     Decimal('0.1'), Decimal('0.1'), Decimal('0.0'), 2017, 201741, datetime.date(2017, 12, 10)),
    ('20171211183244053040092730', datetime.datetime(2017, 12, 11, 0, 0), 'Product20', None, 'Store21', 'Channel1', 1,
     Decimal('16.0'), Decimal('16.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 11)),
    ('20171212211525033110016688', datetime.datetime(2017, 12, 12, 0, 0), 'Product15', 'Customer17', 'Store10',
     'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 12)),
    ('20171212211524643666341111', datetime.datetime(2017, 12, 12, 0, 0), 'Product12', None, 'Store26', 'Channel1', 1,
     Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 12)),
    (
    '20171213054908064401417129', datetime.datetime(2017, 12, 13, 0, 0), 'Product7', 'Customer13', 'Store5', 'Channel2',
    2, Decimal('3.2'), Decimal('3.2'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 13)),
    (
    '20171214100145021040141377', datetime.datetime(2017, 12, 14, 0, 0), 'Product4', 'Customer9', 'Store18', 'Channel1',
    2, Decimal('0.6'), Decimal('0.6'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 14)),
    ('20171215164554027330745161', datetime.datetime(2017, 12, 15, 0, 0), 'Product6', None, 'Store13', 'Channel1', 1,
     Decimal('2.7'), Decimal('2.7'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 15)),
    ('20171216065447030841034847', datetime.datetime(2017, 12, 16, 0, 0), 'Product17', 'Customer10', 'Store11',
     'Channel2', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 16)),
    ('20171216170539020390291592', datetime.datetime(2017, 12, 16, 0, 0), 'Product17', 'Customer15', 'Store11',
     'Channel2', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 16)),
    ('20171217170539020302039029', datetime.datetime(2017, 12, 17, 0, 0), 'Product29', 'Customer10', 'Store11',
     'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 17)),
    ('20171217170539020390291592', datetime.datetime(2017, 12, 17, 0, 0), 'Product29', 'Customer15', 'Store1',
     'Channel1', 1, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201742, datetime.date(2017, 12, 17)),
    ('20171218154137234428937498', datetime.datetime(2017, 12, 18, 0, 0), 'Product1', 'Customer16', 'Store24',
     'Channel1', 1, Decimal('1.24'), Decimal('1.24'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 18)),
    ('20171218154137037970823411', datetime.datetime(2017, 12, 18, 0, 0), 'Product1', None, 'Store20', 'Channel1', 1,
     Decimal('1.24'), Decimal('1.24'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 18)),
    ('20171219181319979212133431', datetime.datetime(2017, 12, 19, 0, 0), 'Product9', 'Customer14', 'Store23',
     'Channel1', 2, Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 19)),
    ('20171219181319021700096809', datetime.datetime(2017, 12, 19, 0, 0), 'Product9', None, 'Store12', 'Channel1', 2,
     Decimal('1.0'), Decimal('1.0'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 19)),
    ('20171220213338029620756325', datetime.datetime(2017, 12, 20, 0, 0), 'Product18', 'Customer1', 'Store22',
     'Channel1', 2, Decimal('2.0'), Decimal('1.33'), Decimal('0.67'), 2017, 201743, datetime.date(2017, 12, 20)),
    ('20171221213338064864816485', datetime.datetime(2017, 12, 21, 0, 0), 'Product18', 'Customer1', 'Store22',
     'Channel1', 2, Decimal('2.0'), Decimal('1.33'), Decimal('0.67'), 2017, 201743, datetime.date(2017, 12, 21)),
    ('20171221174247064890026667', datetime.datetime(2017, 12, 21, 0, 0), 'Product23', None, 'Store32', 'Channel1', 1,
     Decimal('0.39'), Decimal('0.39'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 21)),
    ('20171222214737575304746565', datetime.datetime(2017, 12, 22, 0, 0), 'Product13', 'Customer1', 'Store30',
     'Channel1', 2, Decimal('2.0'), Decimal('1.33'), Decimal('0.67'), 2017, 201743, datetime.date(2017, 12, 22)),
    ('20171222173256020232532303', datetime.datetime(2017, 12, 22, 0, 0), 'Product10', 'Customer18', 'Store2',
     'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 22)),
    ('20171222173256020730588687', datetime.datetime(2017, 12, 22, 0, 0), 'Product4', 'Customer13', 'Store20',
     'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 22)),
    ('20171223173256023532523232', datetime.datetime(2017, 12, 23, 0, 0), 'Product0', 'Customer13', 'Store20',
     'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 23)),
    ('20171222173256234593899311', datetime.datetime(2017, 12, 22, 0, 0), 'Product19', 'Customer12', 'Store5',
     'Channel1', 1, Decimal('0.35'), Decimal('0.35'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 22)),
    ('20171223095737061960142624', datetime.datetime(2017, 12, 23, 0, 0), 'Product11', 'Customer6', 'Store24',
     'Channel1', 1, Decimal('3.0'), Decimal('3.0'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 23)),
    ('20171224115651032120238394', datetime.datetime(2017, 12, 24, 0, 0), 'Product22', 'Customer11', 'Store26',
     'Channel1', 2, Decimal('1.98'), Decimal('1.98'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 24)),
    ('20171225210537038850806205', datetime.datetime(2017, 12, 24, 0, 0), 'Product30', None, 'Store29', 'Channel1', 1,
     Decimal('63.84'), Decimal('63.84'), Decimal('0.0'), 2017, 201743, datetime.date(2017, 12, 24)),
    ('20171226174448062910023178', datetime.datetime(2017, 12, 26, 0, 0), 'Product13', None, 'Store14', 'Channel1', 1,
     Decimal('2.5'), Decimal('2.5'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 26)),
    ('20171227123719054340847535', datetime.datetime(2017, 12, 27, 0, 0), 'Product19', 'Customer19', 'Store30',
     'Channel1', 1, Decimal('2.3'), Decimal('2.3'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 27)),
    ('20171228224443056530713473', datetime.datetime(2017, 12, 28, 0, 0), 'Product14', None, 'Store15', 'Channel1', 2,
     Decimal('1.38'), Decimal('1.38'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 28)),
    ('20171229121555032201011627', datetime.datetime(2017, 12, 29, 0, 0), 'Product2', 'Customer3', 'Store3', 'Channel1',
     1, Decimal('7.0'), Decimal('5.6'), Decimal('1.4'), 2017, 201744, datetime.date(2017, 12, 29)),
    (
    '20171229121274759874987987', datetime.datetime(2017, 12, 29, 0, 0), 'Product2', 'Customer18', 'Store3', 'Channel1',
    1, Decimal('7.0'), Decimal('5.6'), Decimal('1.4'), 2017, 201744, datetime.date(2017, 12, 29)),
    ('20171230104316033800147802', datetime.datetime(2017, 12, 30, 0, 0), 'Product21', 'Customer16', 'Store31',
     'Channel1', 1, Decimal('2.1'), Decimal('2.1'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
    ('20171230104274398723235321', datetime.datetime(2017, 12, 30, 0, 0), 'Product21', 'Customer11', 'Store31',
     'Channel1', 1, Decimal('2.1'), Decimal('2.1'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
    ('20171230151553021020019894', datetime.datetime(2017, 12, 30, 0, 0), 'Product26', 'Customer12', 'Store19',
     'Channel1', 1, Decimal('9.0'), Decimal('9.0'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
    ('20171231151274398749837878', datetime.datetime(2017, 12, 30, 0, 0), 'Product26', 'Customer12', 'Store19',
     'Channel1', 1, Decimal('9.0'), Decimal('9.0'), Decimal('0.0'), 2017, 201744, datetime.date(2017, 12, 30)),
    ('20180101134623025441005632', datetime.datetime(2018, 1, 2, 0, 0), 'Product25', None, 'Store17', 'Channel1', 1,
     Decimal('2.0'), Decimal('2.0'), Decimal('0.0'), 2018, 201745, datetime.date(2018, 1, 2)),
    (
    '20180102121555032230251627', datetime.datetime(2018, 1, 2, 0, 0), 'Product2', 'Customer3', 'Store3', 'Channel1', 1,
    Decimal('7.0'), Decimal('5.6'), Decimal('1.4'), 2018, 201745, datetime.date(2018, 1, 2)),
    (
    '20180103104736033500123025', datetime.datetime(2018, 1, 3, 0, 0), 'Product21', 'Customer16', 'Store24', 'Channel1',
    1, Decimal('2.1'), Decimal('2.1'), Decimal('0.0'), 2018, 201745, datetime.date(2018, 1, 3))
]

"""
purchase_fct
"""
purchases_schema = pt.StructType([
    pt.StructField("Basket", pt.StringType(), True),
    pt.StructField("Division", pt.StringType(), True),
    pt.StructField("Section", pt.StringType(), True),
    pt.StructField("Group", pt.StringType(), True),
    pt.StructField("Subgroup", pt.StringType(), True),
    pt.StructField("Product", pt.StringType(), True),
    pt.StructField("Customer", pt.StringType(), True),
    pt.StructField("Store", pt.StringType(), True),
    pt.StructField("Banner", pt.StringType(), True),
    pt.StructField("FulfillmentStore", pt.StringType(), True),
    pt.StructField("PreferredStore1", pt.StringType(), True),
    pt.StructField("PreferredStore2", pt.StringType(), True),
    pt.StructField("PreferredStore3", pt.StringType(), True),
    pt.StructField("Channel", pt.StringType(), True),
    pt.StructField("Quantity", pt.DecimalType(24, 2), True),
    pt.StructField("NetSpendAmount", pt.DecimalType(38, 2), True),
    pt.StructField("SpendAmount", pt.DecimalType(38, 2), True),
    pt.StructField("DiscountAmount", pt.DecimalType(38, 2), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("date_id", pt.DateType(), True),
])
purchases_lst = [
    ('20171204132046039250829023', 'C', 'C1', 'C1B', 'C1B2', 'Product30', 'Customer14', 'Store23', 'Banner5', 'Store23',
     'Store23', 'Store20', 'Store27', 'Channel1', Decimal('1.00'), Decimal('47.93'), Decimal('47.93'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 4)),
    ('20171205172100023100165409', 'B', 'B2', 'B2B', 'B2B1', 'Product16', 'Customer8', 'Store7', 'Banner2', 'Store8',
     'Store7', 'Store18', 'Store19', 'Channel1', Decimal('1.00'), Decimal('4.00'), Decimal('4.00'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 5)),
    ('20171206151619325325435331', 'C', 'C2', 'C2A', 'C2A1', 'Product28', 'Customer18', 'Store2', 'Banner1', 'Store2',
     'Store2', 'Store3', 'Store4', 'Channel1', Decimal('1.00'), Decimal('0.99'), Decimal('0.99'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 6)),
    ('20171206151619060560788167', 'C', 'C2', 'C2A', 'C2A1', 'Product28', None, 'Store8', 'Banner2', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('0.99'), Decimal('0.99'), Decimal('0.00'), '201741',
     datetime.date(2017, 12, 6)),
    ('20171207194616042343535787', 'B', 'B1', 'B1B', 'B1B1', 'Product7', 'Customer20', 'Store16', 'Banner4', 'Store18',
     'Store16', 'Store17', 'Store19', 'Channel1', Decimal('1.00'), Decimal('10.00'), Decimal('10.00'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 7)),
    ('20171208155253059040314327', 'D', 'D2', 'D2B', 'D2B1', 'Product12', 'Customer5', 'Store28', 'Banner6', 'Store20',
     'Store28', 'Store2', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('2.00'), Decimal('3.00'), Decimal('3.60'),
     Decimal('0.60'), '201741', datetime.date(2017, 12, 8)),
    ('20171208155253052347723957', 'A', 'A1', 'A1B', 'A1B1', 'Product4', 'Customer5', 'Store28', 'Banner6', 'Store20',
     'Store28', 'Store2', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('2.00'), Decimal('3.00'), Decimal('3.60'),
     Decimal('0.60'), '201741', datetime.date(2017, 12, 8)),
    ('20171209193441008064406123', 'C', 'C2', 'C2B', 'C2B1', 'Product27', 'Customer4', 'Store20', 'Banner4', 'Store27',
     'Store20', 'Store22', 'Store30', 'Channel1', Decimal('1.00'), Decimal('20.00'), Decimal('20.00'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 9)),
    ('20171209095798274987398474', 'D', 'D2', 'D2A', 'D2A1', 'Product11', 'Customer6', 'Store24', 'Banner5', 'Store24',
     'Store24', 'Store4', 'Store23', 'Channel1', Decimal('1.00'), Decimal('3.00'), Decimal('3.00'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 9)),
    ('20171209193441051090806440', 'A', 'A1', 'A1A', 'A1A1', 'Product1', 'Customer7', 'Store25', 'Banner5', 'Store8',
     'Store25', 'UNKNOWN_DIMENSION', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('1.00'), Decimal('20.00'),
     Decimal('20.00'), Decimal('0.00'), '201741', datetime.date(2017, 12, 9)),
    ('20171209193441008064100806', 'C', 'C2', 'C2B', 'C2B1', 'Product27', 'Customer11', 'Store18', 'Banner4', 'Store18',
     'Store18', 'Store26', 'Store31', 'Channel1', Decimal('1.00'), Decimal('20.00'), Decimal('20.00'), Decimal('0.00'),
     '201741', datetime.date(2017, 12, 9)),
    ('20171209193441051090911618', 'C', 'C2', 'C2B', 'C2B1', 'Product27', None, 'Store25', 'Banner5', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('20.00'), Decimal('20.00'), Decimal('0.00'), '201741',
     datetime.date(2017, 12, 9)),
    ('20171210141252063990066053', 'C', 'C1', 'C1A', 'C1A1', 'Product3', None, 'Store6', 'Banner2', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('0.10'), Decimal('0.10'), Decimal('0.00'), '201741',
     datetime.date(2017, 12, 10)),
    ('20171211183244053040092730', 'B', 'B1', 'B1A', 'B1A1', 'Product20', None, 'Store21', 'Banner5', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('16.00'), Decimal('16.00'), Decimal('0.00'), '201742',
     datetime.date(2017, 12, 11)),
    ('20171212211524643666341111', 'D', 'D2', 'D2B', 'D2B1', 'Product12', None, 'Store26', 'Banner6', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('1.00'), Decimal('1.00'), Decimal('0.00'), '201742',
     datetime.date(2017, 12, 12)),
    ('20171212211525033110016688', 'B', 'B2', 'B2A', 'B2A1', 'Product15', 'Customer17', 'Store10', 'Banner2', 'Store11',
     'Store10', 'Store20', 'Store12', 'Channel1', Decimal('1.00'), Decimal('1.00'), Decimal('1.00'), Decimal('0.00'),
     '201742', datetime.date(2017, 12, 12)),
    ('20171213054908064401417129', 'B', 'B1', 'B1B', 'B1B1', 'Product7', 'Customer13', 'Store5', 'Banner1', 'Store6',
     'Store20', 'Store5', 'Store1', 'Channel2', Decimal('2.00'), Decimal('3.20'), Decimal('3.20'), Decimal('0.00'),
     '201742', datetime.date(2017, 12, 13)),
    ('20171214100145021040141377', 'A', 'A1', 'A1B', 'A1B1', 'Product4', 'Customer9', 'Store18', 'Banner4', 'Store18',
     'Store18', 'Store11', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('2.00'), Decimal('0.60'), Decimal('0.60'),
     Decimal('0.00'), '201742', datetime.date(2017, 12, 14)),
    ('20171215164554027330745161', 'C', 'C1', 'C1A', 'C1A2', 'Product6', None, 'Store13', 'Banner3', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('2.70'), Decimal('2.70'), Decimal('0.00'), '201742',
     datetime.date(2017, 12, 15)),
    ('20171216065447030841034847', 'D', 'D1', 'D1B', 'D1B2', 'Product17', 'Customer10', 'Store11', 'Banner3', 'Store11',
     'Store11', 'Store8', 'Store18', 'Channel2', Decimal('1.00'), Decimal('3.00'), Decimal('3.00'), Decimal('0.00'),
     '201742', datetime.date(2017, 12, 16)),
    ('20171216170539020390291592', 'D', 'D1', 'D1B', 'D1B2', 'Product17', 'Customer15', 'Store11', 'Banner3', 'store12',
     'store1', 'store10', 'store11', 'Channel2', Decimal('1.00'), Decimal('3.00'), Decimal('3.00'), Decimal('0.00'),
     '201742', datetime.date(2017, 12, 16)),
    ('20171217170539020390291592', 'B', 'B1', 'B1B', 'B1B2', 'Product29', 'Customer15', 'Store1', 'Banner1', 'store12',
     'store1', 'store10', 'store11', 'Channel1', Decimal('1.00'), Decimal('1.00'), Decimal('1.00'), Decimal('0.00'),
     '201742', datetime.date(2017, 12, 17)),
    ('20171217170539020302039029', 'B', 'B1', 'B1B', 'B1B2', 'Product29', 'Customer10', 'Store11', 'Banner3', 'Store11',
     'Store11', 'Store8', 'Store18', 'Channel1', Decimal('1.00'), Decimal('1.00'), Decimal('1.00'), Decimal('0.00'),
     '201742', datetime.date(2017, 12, 17)),
    ('20171218154137234428937498', 'A', 'A1', 'A1A', 'A1A1', 'Product1', 'Customer16', 'Store24', 'Banner5', 'Store24',
     'Store24', 'Store31', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('1.00'), Decimal('1.24'), Decimal('1.24'),
     Decimal('0.00'), '201743', datetime.date(2017, 12, 18)),
    ('20171218154137037970823411', 'A', 'A1', 'A1A', 'A1A1', 'Product1', None, 'Store20', 'Banner4', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('1.24'), Decimal('1.24'), Decimal('0.00'), '201743',
     datetime.date(2017, 12, 18)),
    ('20171219181319021700096809', 'D', 'D1', 'D1B', 'D1B1', 'Product9', None, 'Store12', 'Banner3', None, None, None,
     None, 'Channel1', Decimal('2.00'), Decimal('1.00'), Decimal('1.00'), Decimal('0.00'), '201743',
     datetime.date(2017, 12, 19)),
    ('20171219181319979212133431', 'D', 'D1', 'D1B', 'D1B1', 'Product9', 'Customer14', 'Store23', 'Banner5', 'Store23',
     'Store23', 'Store20', 'Store27', 'Channel1', Decimal('2.00'), Decimal('1.00'), Decimal('1.00'), Decimal('0.00'),
     '201743', datetime.date(2017, 12, 19)),
    ('20171220213338029620756325', 'A', 'A2', 'A2B', 'A2B1', 'Product18', 'Customer1', 'Store22', 'Banner5', 'Store30',
     'Store22', 'Store30', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('2.00'), Decimal('1.33'), Decimal('2.00'),
     Decimal('0.67'), '201743', datetime.date(2017, 12, 20)),
    ('20171221174247064890026667', 'A', 'A2', 'A2A', 'A2A2', 'Product23', None, 'Store32', 'Banner7', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('0.39'), Decimal('0.39'), Decimal('0.00'), '201743',
     datetime.date(2017, 12, 21)),
    ('20171221213338064864816485', 'A', 'A2', 'A2B', 'A2B1', 'Product18', 'Customer1', 'Store22', 'Banner5', 'Store30',
     'Store22', 'Store30', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('2.00'), Decimal('1.33'), Decimal('2.00'),
     Decimal('0.67'), '201743', datetime.date(2017, 12, 21)),
    ('20171222173256020730588687', 'A', 'A1', 'A1B', 'A1B1', 'Product4', 'Customer13', 'Store20', 'Banner4', 'Store6',
     'Store20', 'Store5', 'Store1', 'Channel1', Decimal('1.00'), Decimal('0.35'), Decimal('0.35'), Decimal('0.00'),
     '201743', datetime.date(2017, 12, 22)),
    ('20171222173256020232532303', 'D', 'D1', 'D1A', 'D1A2', 'Product10', 'Customer18', 'Store2', 'Banner1', 'Store2',
     'Store2', 'Store3', 'Store4', 'Channel1', Decimal('1.00'), Decimal('0.35'), Decimal('0.35'), Decimal('0.00'),
     '201743', datetime.date(2017, 12, 22)),
    ('20171222214737575304746565', 'D', 'D2', 'D2A', 'D2A1', 'Product13', 'Customer1', 'Store30', 'Banner6', 'Store30',
     'Store22', 'Store30', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('2.00'), Decimal('1.33'), Decimal('2.00'),
     Decimal('0.67'), '201743', datetime.date(2017, 12, 22)),
    ('20171222173256234593899311', 'D', 'D2', 'D2B', 'D2B2', 'Product19', 'Customer12', 'Store5', 'Banner1', 'Store5',
     'Store5', 'Store19', 'Store14', 'Channel1', Decimal('1.00'), Decimal('0.35'), Decimal('0.35'), Decimal('0.00'),
     '201743', datetime.date(2017, 12, 22)),
    ('20171223095737061960142624', 'D', 'D2', 'D2A', 'D2A1', 'Product11', 'Customer6', 'Store24', 'Banner5', 'Store24',
     'Store24', 'Store4', 'Store23', 'Channel1', Decimal('1.00'), Decimal('3.00'), Decimal('3.00'), Decimal('0.00'),
     '201743', datetime.date(2017, 12, 23)),
    ('20171223173256023532523232', 'UNKNOWN_DIMENSION', 'UNKNOWN_DIMENSION', 'UNKNOWN_DIMENSION', 'UNKNOWN_DIMENSION',
     'Product0', 'Customer13', 'Store20', 'Banner4', 'Store6', 'Store20', 'Store5', 'Store1', 'Channel1',
     Decimal('1.00'), Decimal('0.35'), Decimal('0.35'), Decimal('0.00'), '201743', datetime.date(2017, 12, 23)),
    ('20171224115651032120238394', 'A', 'A1', 'A1B', 'A1B1', 'Product22', 'Customer11', 'Store26', 'Banner6', 'Store18',
     'Store18', 'Store26', 'Store31', 'Channel1', Decimal('2.00'), Decimal('1.98'), Decimal('1.98'), Decimal('0.00'),
     '201743', datetime.date(2017, 12, 24)),
    ('20171225210537038850806205', 'C', 'C1', 'C1B', 'C1B2', 'Product30', None, 'Store29', 'Banner6', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('63.84'), Decimal('63.84'), Decimal('0.00'), '201743',
     datetime.date(2017, 12, 24)),
    ('20171226174448062910023178', 'D', 'D2', 'D2A', 'D2A1', 'Product13', None, 'Store14', 'Banner3', None, None, None,
     None, 'Channel1', Decimal('1.00'), Decimal('2.50'), Decimal('2.50'), Decimal('0.00'), '201744',
     datetime.date(2017, 12, 26)),
    ('20171227123719054340847535', 'D', 'D2', 'D2B', 'D2B2', 'Product19', 'Customer19', 'Store30', 'Banner6', 'Store31',
     'Store30', 'Store12', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('1.00'), Decimal('2.30'), Decimal('2.30'),
     Decimal('0.00'), '201744', datetime.date(2017, 12, 27)),
    ('20171228224443056530713473', 'A', 'A2', 'A2A', 'A2A1', 'Product14', None, 'Store15', 'Banner3', None, None, None,
     None, 'Channel1', Decimal('2.00'), Decimal('1.38'), Decimal('1.38'), Decimal('0.00'), '201744',
     datetime.date(2017, 12, 28)),
    ('20171229121555032201011627', 'B', 'B1', 'B1A', 'B1A1', 'Product2', 'Customer3', 'Store3', 'Banner1', 'Store3',
     'Store3', 'UNKNOWN_DIMENSION', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('1.00'), Decimal('5.60'), Decimal('7.00'),
     Decimal('1.40'), '201744', datetime.date(2017, 12, 29)),
    ('20171229121274759874987987', 'B', 'B1', 'B1A', 'B1A1', 'Product2', 'Customer18', 'Store3', 'Banner1', 'Store2',
     'Store2', 'Store3', 'Store4', 'Channel1', Decimal('1.00'), Decimal('5.60'), Decimal('7.00'), Decimal('1.40'),
     '201744', datetime.date(2017, 12, 29)),
    ('20171230104316033800147802', 'A', 'A1', 'A1A', 'A1A1', 'Product21', 'Customer16', 'Store31', 'Banner7', 'Store24',
     'Store24', 'Store31', 'UNKNOWN_DIMENSION', 'Channel1', Decimal('1.00'), Decimal('2.10'), Decimal('2.10'),
     Decimal('0.00'), '201744', datetime.date(2017, 12, 30)),
    ('20171230151553021020019894', 'C', 'C2', 'C2A', 'C2A1', 'Product26', 'Customer12', 'Store19', 'Banner4', 'Store5',
     'Store5', 'Store19', 'Store14', 'Channel1', Decimal('1.00'), Decimal('9.00'), Decimal('9.00'), Decimal('0.00'),
     '201744', datetime.date(2017, 12, 30)),
    ('20171230104274398723235321', 'A', 'A1', 'A1A', 'A1A1', 'Product21', 'Customer11', 'Store31', 'Banner7', 'Store18',
     'Store18', 'Store26', 'Store31', 'Channel1', Decimal('1.00'), Decimal('2.10'), Decimal('2.10'), Decimal('0.00'),
     '201744', datetime.date(2017, 12, 30)),
    ('20171231151274398749837878', 'C', 'C2', 'C2A', 'C2A1', 'Product26', 'Customer12', 'Store19', 'Banner4', 'Store5',
     'Store5', 'Store19', 'Store14', 'Channel1', Decimal('1.00'), Decimal('9.00'), Decimal('9.00'), Decimal('0.00'),
     '201744', datetime.date(2017, 12, 30))
]

"""
all_all_all_all_summary
"""
all_all_all_all_summary_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets", pt.LongType(), True),
    pt.StructField("basketweeks", pt.IntegerType(), True),
    pt.StructField("discount", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("quantity", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend", pt.DecimalType(38, 2), True),
    pt.StructField("netspend", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate", pt.IntegerType(), True),
    pt.StructField("minpurchasedate", pt.IntegerType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
])
all_all_all_all_summary_lst = [
    ("All", "All", "All", "All", 13, 1, Decimal("1.20"), Decimal("47.93"), Decimal("0.10"),
     Decimal("47.93"), Decimal("0.10"), Decimal("15.00"), Decimal("12.00"), None, None,
     Decimal("4.00"), Decimal("154.21"), Decimal("153.01"), 17510, 17504, "201741"),
    ("All", "All", "All", "All", 10, 1, Decimal("0.00"), Decimal("16.00"), Decimal("0.30"),
     Decimal("16.00"), Decimal("0.30"), Decimal("12.00"), Decimal("5.00"), Decimal("2.00"), None,
     Decimal("4.00"), Decimal("32.50"), Decimal("32.50"), 17517, 17511, "201742"),
    ("All", "All", "All", "All", 15, 1, Decimal("2.01"), Decimal("63.84"), Decimal("0.35"),
     Decimal("63.84"), Decimal("0.35"), Decimal("21.00"), Decimal("12.00"), Decimal("4.00"), None,
     Decimal("8.00"), Decimal("81.09"), Decimal("79.08"), 17524, 17518, "201743"),
    ("All", "All", "All", "All", 9, 1, Decimal("2.80"), Decimal("9.00"), Decimal("0.69"),
     Decimal("9.00"), Decimal("0.69"), Decimal("10.00"), Decimal("2.00"), Decimal("4.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("42.38"), Decimal("39.58"), 17530, 17526,
     "201744"),
]

"""
product_customer_all_all_summary
"""
product_customer_all_all_summary_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets", pt.LongType(), True),
    pt.StructField("basketweeks", pt.IntegerType(), True),
    pt.StructField("discount", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("quantity", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend", pt.DecimalType(38, 2), True),
    pt.StructField("netspend", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate", pt.IntegerType(), True),
    pt.StructField("minpurchasedate", pt.IntegerType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
])
product_customer_all_all_summary_lst = [
    ("Product4", "Customer5", "All", "All", 1, 1, Decimal("0.60"),
     Decimal("1.80"), Decimal("1.80"), Decimal("1.50"), Decimal("1.50"), Decimal("2.00"),
     Decimal("2.00"), None, None, None, Decimal("3.60"), Decimal("3.00"), 17508, 17508, "201741"),
    ("Product1", "Customer7", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("20.00"), Decimal("20.00"), 17509, 17509, "201741"),
    ("Product7", "Customer20", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("10.00"), Decimal("10.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("10.00"), Decimal("10.00"), 17507, 17507, "201741"),
    ("Product16", "Customer8", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("4.00"), Decimal("4.00"), Decimal("4.00"), Decimal("4.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("4.00"), Decimal("4.00"), 17505, 17505, "201741"),
    ("Product30", "Customer14", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("47.93"), Decimal("47.93"), Decimal("47.93"), Decimal("47.93"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("47.93"), Decimal("47.93"), 17504, 17504,
     "201741"),
    ("Product28", "Customer18", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("0.99"), Decimal("0.99"), 17506, 17506,
     "201741"),
    ("Product27", "Customer4", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("20.00"), Decimal("20.00"), 17509, 17509, "201741"),
    ("Product27", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), 17509, 17509,
     "201741"),
    ("Product12", "Customer5", "All", "All", 1, 1, Decimal("0.60"),
     Decimal("1.80"), Decimal("1.80"), Decimal("1.50"), Decimal("1.50"), Decimal("2.00"),
     Decimal("2.00"), None, None, None, Decimal("3.60"), Decimal("3.00"), 17508, 17508, "201741"),
    ("Product11", "Customer6", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17509, 17509,
     "201741"),
    ("Product4", "Customer9", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.30"), Decimal("0.30"), Decimal("0.30"), Decimal("0.30"), Decimal("2.00"),
     Decimal("2.00"), None, None, Decimal("2.00"), Decimal("0.60"), Decimal("0.60"), 17514, 17514,
     "201742"),
    ("Product7", "Customer13", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.60"), Decimal("1.60"), Decimal("1.60"), Decimal("1.60"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("3.20"), Decimal("3.20"), 17513, 17513, "201742"),
    ("Product29", "Customer15", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, None, Decimal("1.00"), Decimal("1.00"), 17517, 17517, "201742"),
    ("Product29", "Customer10", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), 17517, 17517,
     "201742"),
    ("Product15", "Customer17", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("1.00"), Decimal("1.00"), 17512, 17512, "201742"),
    ("Product17", "Customer10", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17516, 17516,
     "201742"),
    ("Product17", "Customer15", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), None,
     None, None, None, Decimal("3.00"), Decimal("3.00"), 17516, 17516, "201742"),
    ("Product1", "Customer16", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.24"), Decimal("1.24"), Decimal("1.24"), Decimal("1.24"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("1.24"), Decimal("1.24"), 17518, 17518,
     "201743"),
    ("Product4", "Customer13", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("0.35"), Decimal("0.35"), 17522, 17522, "201743"),
    ("Product22", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("1.98"), Decimal("1.98"), 17524, 17524, "201743"),
    ("Product18", "Customer1", "All", "All", 2, 1, Decimal("1.34"),
     Decimal("1.00"), Decimal("1.00"), Decimal("0.67"), Decimal("0.67"), Decimal("4.00"),
     Decimal("4.00"), None, None, None, Decimal("4.00"), Decimal("2.66"), 17521, 17520, "201743"),
    ("Product9", "Customer14", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.50"), Decimal("0.50"), Decimal("0.50"), Decimal("0.50"), Decimal("2.00"),
     Decimal("2.00"), None, None, Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), 17519, 17519,
     "201743"),
    ("Product10", "Customer18", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), 17522, 17522,
     "201743"),
    ("Product13", "Customer1", "All", "All", 1, 1, Decimal("0.67"),
     Decimal("1.00"), Decimal("1.00"), Decimal("0.67"), Decimal("0.67"), Decimal("2.00"), None,
     Decimal("2.00"), None, Decimal("2.00"), Decimal("2.00"), Decimal("1.33"), 17522, 17522,
     "201743"),
    ("Product19", "Customer12", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), 17522, 17522,
     "201743"),
    ("Product11", "Customer6", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17523, 17523,
     "201743"),
    ("Product0", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, Decimal("0.35"), Decimal("0.35"), 17523, 17523, "201743"),
    ("Product21", "Customer16", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None,
     Decimal("1.00"), None, None, Decimal("2.10"), Decimal("2.10"), 17530, 17530, "201744"),
    ("Product21", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None,
     None, Decimal("1.00"), None, Decimal("2.10"), Decimal("2.10"), 17530, 17530, "201744"),
    ("Product2", "Customer3", "All", "All", 1, 1, Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("7.00"), Decimal("5.60"), 17529, 17529,
     "201744"),
    ("Product2", "Customer18", "All", "All", 1, 1, Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), None,
     Decimal("1.00"), None, None, Decimal("7.00"), Decimal("5.60"), 17529, 17529, "201744"),
    ("Product26", "Customer12", "All", "All", 2, 1, Decimal("0.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("18.00"), Decimal("18.00"), 17531, 17530, "201744"),
    ("Product19", "Customer19", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("2.30"), Decimal("2.30"), 17527, 17527, "201744"),
]

"""
subgroup_all_all_all_summary
"""
subgroup_all_all_all_summary_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets", pt.LongType(), True),
    pt.StructField("basketweeks", pt.IntegerType(), True),
    pt.StructField("discount", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("quantity", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend", pt.DecimalType(38, 2), True),
    pt.StructField("netspend", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate", pt.IntegerType(), True),
    pt.StructField("minpurchasedate", pt.IntegerType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
])
subgroup_all_all_all_summary_lst = [
    ("A1B1", "All", "All", "All", 1, 1, Decimal("0.60"), Decimal("1.80"), Decimal("1.80"),
     Decimal("1.50"), Decimal("1.50"), Decimal("2.00"), Decimal("2.00"), None, None, None,
     Decimal("3.60"), Decimal("3.00"), 17508, 17508, "201741"),
    ("A1A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("20.00"), Decimal("20.00"), 17509, 17509, "201741"),
    ("B1B1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("10.00"), Decimal("10.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("10.00"), Decimal("10.00"), 17507, 17507, "201741"),
    ("B2B1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("4.00"), Decimal("4.00"),
     Decimal("4.00"), Decimal("4.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("4.00"), Decimal("4.00"), 17505, 17505, "201741"),
    ("C1B2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("47.93"), Decimal("47.93"),
     Decimal("47.93"), Decimal("47.93"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("47.93"), Decimal("47.93"), 17504, 17504, "201741"),
    ("C1A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.10"), Decimal("0.10"),
     Decimal("0.10"), Decimal("0.10"), Decimal("1.00"), None, None, None, None, Decimal("0.10"),
     Decimal("0.10"), 17510, 17510, "201741"),
    ("C2A1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("0.99"), Decimal("0.99"),
     Decimal("0.99"), Decimal("0.99"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("1.98"), Decimal("1.98"), 17506, 17506, "201741"),
    ("C2B1", "All", "All", "All", 3, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("3.00"), Decimal("2.00"), None, None,
     Decimal("1.00"), Decimal("60.00"), Decimal("60.00"), 17509, 17509, "201741"),
    ("D2B1", "All", "All", "All", 1, 1, Decimal("0.60"), Decimal("1.80"), Decimal("1.80"),
     Decimal("1.50"), Decimal("1.50"), Decimal("2.00"), Decimal("2.00"), None, None, None,
     Decimal("3.60"), Decimal("3.00"), 17508, 17508, "201741"),
    ("D2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17509, 17509, "201741"),
    ("A1B1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.30"), Decimal("0.30"),
     Decimal("0.30"), Decimal("0.30"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("0.60"), Decimal("0.60"), 17514, 17514, "201742"),
    ("B1A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("16.00"), Decimal("16.00"),
     Decimal("16.00"), Decimal("16.00"), Decimal("1.00"), None, None, None, None, Decimal("16.00"),
     Decimal("16.00"), 17511, 17511, "201742"),
    ("B1B1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.60"), Decimal("1.60"),
     Decimal("1.60"), Decimal("1.60"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("3.20"), Decimal("3.20"), 17513, 17513, "201742"),
    ("B1B2", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("2.00"), Decimal("2.00"), 17517, 17517, "201742"),
    ("B2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("1.00"), Decimal("1.00"), 17512, 17512, "201742"),
    ("C1A2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.70"), Decimal("2.70"),
     Decimal("2.70"), Decimal("2.70"), Decimal("1.00"), None, None, None, None, Decimal("2.70"),
     Decimal("2.70"), 17515, 17515, "201742"),
    ("D1B2", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("6.00"), Decimal("6.00"), 17516, 17516, "201742"),
    ("D2B1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None, None, Decimal("1.00"),
     Decimal("1.00"), 17512, 17512, "201742"),
    ("A1A1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("1.24"), Decimal("1.24"),
     Decimal("1.24"), Decimal("1.24"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("2.48"), Decimal("2.48"), 17518, 17518, "201743"),
    ("A1B1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("0.99"), Decimal("0.35"),
     Decimal("0.99"), Decimal("0.35"), Decimal("3.00"), Decimal("1.00"), Decimal("2.00"), None,
     None, Decimal("2.33"), Decimal("2.33"), 17524, 17522, "201743"),
    ("A2B1", "All", "All", "All", 2, 1, Decimal("1.34"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.67"), Decimal("0.67"), Decimal("4.00"), Decimal("4.00"), None, None, None,
     Decimal("4.00"), Decimal("2.66"), 17521, 17520, "201743"),
    ("A2A2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.39"), Decimal("0.39"),
     Decimal("0.39"), Decimal("0.39"), Decimal("1.00"), None, None, None, None, Decimal("0.39"),
     Decimal("0.39"), 17521, 17521, "201743"),
    ("D1B1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("0.50"), Decimal("0.50"),
     Decimal("0.50"), Decimal("0.50"), Decimal("4.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("2.00"), Decimal("2.00"), 17519, 17519, "201743"),
    ("D1A2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), 17522, 17522, "201743"),
    ("D2A1", "All", "All", "All", 2, 1, Decimal("0.67"), Decimal("3.00"), Decimal("1.00"),
     Decimal("3.00"), Decimal("0.67"), Decimal("3.00"), Decimal("1.00"), Decimal("2.00"), None,
     Decimal("3.00"), Decimal("5.00"), Decimal("4.33"), 17523, 17522, "201743"),
    ("D2B2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), 17522, 17522, "201743"),
    ("UNKNOWN_DIMENSION", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, Decimal("0.35"), Decimal("0.35"), 17523, 17523, "201743"),
    ("A1A1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.00"), None, Decimal("1.00"), Decimal("1.00"),
     None, Decimal("4.20"), Decimal("4.20"), 17530, 17530, "201744"),
    ("A2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.69"), Decimal("0.69"),
     Decimal("0.69"), Decimal("0.69"), Decimal("2.00"), None, None, None, None, Decimal("1.38"),
     Decimal("1.38"), 17528, 17528, "201744"),
    ("B1A1", "All", "All", "All", 2, 1, Decimal("2.80"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), None,
     Decimal("1.00"), Decimal("14.00"), Decimal("11.20"), 17529, 17529, "201744"),
    ("C1B2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("63.84"), Decimal("63.84"),
     Decimal("63.84"), Decimal("63.84"), Decimal("1.00"), None, None, None, None, Decimal("63.84"),
     Decimal("63.84"), 17525, 17525, "201744"),
    ("C2A1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("18.00"), Decimal("18.00"), 17531, 17530, "201744"),
    ("D2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.50"), Decimal("2.50"),
     Decimal("2.50"), Decimal("2.50"), Decimal("1.00"), None, None, None, None, Decimal("2.50"),
     Decimal("2.50"), 17526, 17526, "201744"),
    ("D2B2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("2.30"), Decimal("2.30"), 17527, 17527, "201744"),
]

"""
subgroup_customer_all_all_summary
"""
subgroup_customer_all_all_summary_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets", pt.LongType(), True),
    pt.StructField("basketweeks", pt.IntegerType(), True),
    pt.StructField("discount", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice", pt.DecimalType(38, 2), True),
    pt.StructField("quantity", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend", pt.DecimalType(38, 2), True),
    pt.StructField("netspend", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate", pt.IntegerType(), True),
    pt.StructField("minpurchasedate", pt.IntegerType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
])
subgroup_customer_all_all_summary_lst = [
    ("A1B1", "Customer5", "All", "All", 1, 1, Decimal("0.60"), Decimal("1.80"), Decimal("1.80"),
     Decimal("1.50"), Decimal("1.50"), Decimal("2.00"), Decimal("2.00"), None, None, None,
     Decimal("3.60"), Decimal("3.00"), 17508, 17508, "201741"),
    ("A1A1", "Customer7", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("20.00"), Decimal("20.00"), 17509, 17509, "201741"),
    ("B1B1", "Customer20", "All", "All", 1, 1, Decimal("0.00"), Decimal("10.00"), Decimal("10.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("10.00"), Decimal("10.00"), 17507, 17507, "201741"),
    ("B2B1", "Customer8", "All", "All", 1, 1, Decimal("0.00"), Decimal("4.00"), Decimal("4.00"),
     Decimal("4.00"), Decimal("4.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("4.00"), Decimal("4.00"), 17505, 17505, "201741"),
    ("C1B2", "Customer14", "All", "All", 1, 1, Decimal("0.00"), Decimal("47.93"), Decimal("47.93"),
     Decimal("47.93"), Decimal("47.93"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("47.93"), Decimal("47.93"), 17504, 17504, "201741"),
    ("C1B1", "Customer20", "All", "All", 1, 1, Decimal("0.00"), Decimal("10.00"), Decimal("10.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("10.00"), Decimal("10.00"), 17507, 17507, "201741"),
    ("C2A1", "Customer18", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.99"), Decimal("0.99"),
     Decimal("0.99"), Decimal("0.99"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.99"), Decimal("0.99"), 17506, 17506, "201741"),
    ("C2B1", "Customer4", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("20.00"), Decimal("20.00"), 17509, 17509, "201741"),
    ("C2B1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), 17509, 17509, "201741"),
    ("D2B1", "Customer5", "All", "All", 1, 1, Decimal("0.60"), Decimal("1.80"), Decimal("1.80"),
     Decimal("1.50"), Decimal("1.50"), Decimal("2.00"), Decimal("2.00"), None, None, None,
     Decimal("3.60"), Decimal("3.00"), 17508, 17508, "201741"),
    ("D2A1", "Customer6", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17509, 17509, "201741"),
    ("A1B1", "Customer9", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.30"), Decimal("0.30"),
     Decimal("0.30"), Decimal("0.30"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("0.60"), Decimal("0.60"), 17514, 17514, "201742"),
    ("B1B1", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.60"), Decimal("1.60"),
     Decimal("1.60"), Decimal("1.60"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("3.20"), Decimal("3.20"), 17513, 17513, "201742"),
    ("B1B2", "Customer15", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None, None, Decimal("1.00"),
     Decimal("1.00"), 17517, 17517, "201742"),
    ("B1B2", "Customer10", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), 17517, 17517, "201742"),
    ("B2A1", "Customer17", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("1.00"), Decimal("1.00"), 17512, 17512, "201742"),
    ("D1B2", "Customer10", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17516, 17516, "201742"),
    ("D1B2", "Customer15", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), None, None, None, None, Decimal("3.00"),
     Decimal("3.00"), 17516, 17516, "201742"),
    ("A1A1", "Customer16", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.24"), Decimal("1.24"),
     Decimal("1.24"), Decimal("1.24"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("1.24"), Decimal("1.24"), 17518, 17518, "201743"),
    ("A1B1", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("0.35"), Decimal("0.35"), 17522, 17522, "201743"),
    ("A1B1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.99"), Decimal("0.99"),
     Decimal("0.99"), Decimal("0.99"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("1.98"), Decimal("1.98"), 17524, 17524, "201743"),
    ("A2B1", "Customer1", "All", "All", 2, 1, Decimal("1.34"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.67"), Decimal("0.67"), Decimal("4.00"), Decimal("4.00"), None, None, None,
     Decimal("4.00"), Decimal("2.66"), 17521, 17520, "201743"),
    ("D1B1", "Customer14", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.50"), Decimal("0.50"),
     Decimal("0.50"), Decimal("0.50"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), 17519, 17519, "201743"),
    ("D1A2", "Customer18", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), 17522, 17522, "201743"),
    ("D2A1", "Customer1", "All", "All", 1, 1, Decimal("0.67"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.67"), Decimal("0.67"), Decimal("2.00"), None, Decimal("2.00"), None,
     Decimal("2.00"), Decimal("2.00"), Decimal("1.33"), 17522, 17522, "201743"),
    ("D2B2", "Customer12", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), 17522, 17522, "201743"),
    ("D2A1", "Customer6", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), 17523, 17523, "201743"),
    ("DEFAULT_HIERARCHY", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, Decimal("0.35"), Decimal("0.35"), 17523, 17523, "201743"),
    ("A1A1", "Customer16", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("2.10"), Decimal("2.10"), 17530, 17530, "201744"),
    ("A1A1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None, None, Decimal("1.00"), None,
     Decimal("2.10"), Decimal("2.10"), 17530, 17530, "201744"),
    ("B1A1", "Customer3", "All", "All", 1, 1, Decimal("1.40"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("7.00"), Decimal("5.60"), 17529, 17529, "201744"),
    ("B1A1", "Customer18", "All", "All", 1, 1, Decimal("1.40"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("7.00"), Decimal("5.60"), 17529, 17529, "201744"),
    ("C2A1", "Customer12", "All", "All", 2, 1, Decimal("0.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("18.00"), Decimal("18.00"), 17531, 17530, "201744"),
    ("D2B2", "Customer19", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("2.30"), Decimal("2.30"), 17527, 17527, "201744"),
]

"""
feature_distinct_tab_summary
"""
feature_distinct_tab_summary_schema = pt.StructType([
    pt.StructField("division", pt.StringType(), True),
    pt.StructField("section", pt.StringType(), True),
    pt.StructField("group", pt.StringType(), True),
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
])
feature_distinct_tab_summary_lst = [
    ("A", "A1", "A1B", "A1B1", "Product4", "Customer5", "201741"),
    ("A", "A1", "A1A", "A1A1", "Product1", "Customer7", "201741"),
    ("B", "B1", "B1B", "B1B1", "Product7", "Customer20", "201741"),
    ("B", "B2", "B2B", "B2B1", "Product16", "Customer8", "201741"),
    ("C", "C1", "C1B", "C1B2", "Product30", "Customer14", "201741"),
    ("C", "C1", "C1A", "C1A1", "Product3", None, "201741"),
    ("C", "C2", "C2A", "C2A1", "Product28", "Customer18", "201741"),
    ("C", "C2", "C2A", "C2A1", "Product28", None, "201741"),
    ("C", "C2", "C2B", "C2B1", "Product27", "Customer4", "201741"),
    ("C", "C2", "C2B", "C2B1", "Product27", "Customer11", "201741"),
    ("C", "C2", "C2B", "C2B1", "Product27", None, "201741"),
    ("D", "D2", "D2B", "D2B1", "Product12", "Customer5", "201741"),
    ("D", "D2", "D2A", "D2A1", "Product11", "Customer6", "201741"),
    ("A", "A1", "A1B", "A1B1", "Product4", "Customer9", "201742"),
    ("B", "B1", "B1A", "B1A1", "Product20", None, "201742"),
    ("B", "B1", "B1B", "B1B1", "Product7", "Customer13", "201742"),
    ("B", "B1", "B1B", "B1B2", "Product29", "Customer15", "201742"),
    ("B", "B1", "B1B", "B1B2", "Product29", "Customer10", "201742"),
    ("B", "B2", "B2A", "B2A1", "Product15", "Customer17", "201742"),
    ("C", "C1", "C1A", "C1A2", "Product6", None, "201742"),
    ("D", "D1", "D1B", "D1B2", "Product17", "Customer10", "201742"),
    ("D", "D1", "D1B", "D1B2", "Product17", "Customer15", "201742"),
    ("D", "D2", "D2B", "D2B1", "Product12", None, "201742"),
    ("A", "A1", "A1A", "A1A1", "Product1", "Customer16", "201743"),
    ("A", "A1", "A1A", "A1A1", "Product1", None, "201743"),
    ("A", "A1", "A1B", "A1B1", "Product4", "Customer13", "201743"),
    ("A", "A1", "A1B", "A1B1", "Product22", "Customer11", "201743"),
    ("A", "A2", "A2B", "A2B1", "Product18", "Customer1", "201743"),
    ("A", "A2", "A2A", "A2A2", "Product23", None, "201743"),
    ("D", "D1", "D1B", "D1B1", "Product9", None, "201743"),
    ("D", "D1", "D1B", "D1B1", "Product9", "Customer14", "201743"),
    ("D", "D1", "D1A", "D1A2", "Product10", "Customer18", "201743"),
    ("D", "D2", "D2A", "D2A1", "Product13", "Customer1", "201743"),
    ("D", "D2", "D2B", "D2B2", "Product19", "Customer12", "201743"),
    ("D", "D2", "D2A", "D2A1", "Product11", "Customer6", "201743"),
    ("UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "Product0", "Customer13",
     "201743"),
    ("A", "A1", "A1A", "A1A1", "Product21", "Customer16", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product21", "Customer11", "201744"),
    ("A", "A2", "A2A", "A2A1", "Product14", None, "201744"),
    ("B", "B1", "B1A", "B1A1", "Product2", "Customer3", "201744"),
    ("B", "B1", "B1A", "B1A1", "Product2", "Customer18", "201744"),
    ("C", "C1", "C1B", "C1B2", "Product30", None, "201744"),
    ("C", "C2", "C2A", "C2A1", "Product26", "Customer12", "201744"),
    ("D", "D2", "D2A", "D2A1", "Product13", None, "201744"),
    ("D", "D2", "D2B", "D2B2", "Product19", "Customer19", "201744"),
]

"""
Aggregation - all_all_all_all - 1w1w, 1w4w
"""
all_all_all_all_1w1w_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("divisioncount_1w1w", pt.LongType(), True),
    pt.StructField("sectioncount_1w1w", pt.LongType(), True),
    pt.StructField("groupcount_1w1w", pt.LongType(), True),
    pt.StructField("subgroupcount_1w1w", pt.LongType(), True),
    pt.StructField("productcount_1w1w", pt.LongType(), True),
    pt.StructField("customercount_1w1w", pt.LongType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
all_all_all_all_1w1w_lst = [
    ("All", "All", "All", "All", 9, 1, Decimal("2.80"), Decimal("9.00"), Decimal("0.69"),
     Decimal("9.00"), Decimal("0.69"), Decimal("10.00"), Decimal("2.00"), Decimal("4.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("42.38"), Decimal("39.58"), "2017-12-30",
     "2017-12-26", Decimal("6.75"), Decimal("8.55"), 4, 6, 7, 7, 7, 6, "201744")
]
all_all_all_all_1w4w_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("divisioncount_1w4w", pt.LongType(), True),
    pt.StructField("sectioncount_1w4w", pt.LongType(), True),
    pt.StructField("groupcount_1w4w", pt.LongType(), True),
    pt.StructField("subgroupcount_1w4w", pt.LongType(), True),
    pt.StructField("productcount_1w4w", pt.LongType(), True),
    pt.StructField("customercount_1w4w", pt.LongType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
all_all_all_all_1w4w_lst = [
    ("All", "All", "All", "All", 47, 4, Decimal("6.01"), Decimal("63.84"), Decimal("0.10"),
     Decimal("63.84"), Decimal("0.10"), Decimal("58.00"), Decimal("31.00"), Decimal("10.00"),
     Decimal("1.00"), Decimal("17.00"), Decimal("310.18"), Decimal("304.17"), "2017-12-30",
     "2017-12-04", Decimal("23.52"), Decimal("41.25"), 5, 9, 17, 22, 27, 19, "201744")
]

"""
Aggregation - product_customer_all_all - 1w1w, 1w4w
"""
product_customer_all_all_1w1w_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
product_customer_all_all_1w1w_lst = [
    ("Product21", "Customer16", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None,
     Decimal("1.00"), None, None, Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30",
     Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product21", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None,
     None, Decimal("1.00"), None, Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30",
     Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product2", "Customer3", "All", "All", 1, 1, Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("7.00"), Decimal("5.60"), "2017-12-29",
     "2017-12-29", Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product2", "Customer18", "All", "All", 1, 1, Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), None,
     Decimal("1.00"), None, None, Decimal("7.00"), Decimal("5.60"), "2017-12-29", "2017-12-29",
     Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product26", "Customer12", "All", "All", 2, 1, Decimal("0.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("18.00"), Decimal("18.00"), "2017-12-31", "2017-12-30",
     Decimal("1.50"), Decimal("1.90"), "201744"),
    ("Product19", "Customer19", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("2.30"), Decimal("2.30"), "2017-12-27",
     "2017-12-27", Decimal("0.75"), Decimal("0.95"), "201744")
]
product_customer_all_all_1w4w_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets1w4w", pt.LongType(), True),
    pt.StructField("basketweeks1w4w", pt.IntegerType(), True),
    pt.StructField("discount1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore11w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore21w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore31w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks751w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks951w4w", pt.DecimalType(38, 2), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
product_customer_all_all_1w4w_lst = [
    ("Product4", "Customer5", "All", "All", 1, 1, Decimal("0.60"),
     Decimal("1.80"), Decimal("1.80"), Decimal("1.50"), Decimal("1.50"), Decimal("2.00"),
     Decimal("2.00"), None, None, None, Decimal("3.60"), Decimal("3.00"), "2017-12-08",
     "2017-12-08", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product1", "Customer7", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("20.00"), Decimal("20.00"), "2017-12-09",
     "2017-12-09", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product7", "Customer20", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("10.00"), Decimal("10.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("10.00"), Decimal("10.00"), "2017-12-07",
     "2017-12-07", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product16", "Customer8", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("4.00"), Decimal("4.00"), Decimal("4.00"), Decimal("4.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("4.00"), Decimal("4.00"), "2017-12-05",
     "2017-12-05", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product30", "Customer14", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("47.93"), Decimal("47.93"), Decimal("47.93"), Decimal("47.93"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("47.93"), Decimal("47.93"), "2017-12-04",
     "2017-12-04", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product28", "Customer18", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("0.99"), Decimal("0.99"), "2017-12-06",
     "2017-12-06", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product27", "Customer4", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("20.00"), Decimal("20.00"), "2017-12-09",
     "2017-12-09", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product27", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("20.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), "2017-12-09",
     "2017-12-09", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product12", "Customer5", "All", "All", 1, 1, Decimal("0.60"),
     Decimal("1.80"), Decimal("1.80"), Decimal("1.50"), Decimal("1.50"), Decimal("2.00"),
     Decimal("2.00"), None, None, None, Decimal("3.60"), Decimal("3.00"), "2017-12-08",
     "2017-12-08", Decimal("0.32"), Decimal("0.81"), "201744"),
    ("Product11", "Customer6", "All", "All", 2, 2, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("2.00"),
     Decimal("2.00"), None, None, Decimal("2.00"), Decimal("6.00"), Decimal("6.00"), "2017-12-23",
     "2017-12-09", Decimal("0.88"), Decimal("1.72"), "201744"),
    ("Product4", "Customer9", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.30"), Decimal("0.30"), Decimal("0.30"), Decimal("0.30"), Decimal("2.00"),
     Decimal("2.00"), None, None, Decimal("2.00"), Decimal("0.60"), Decimal("0.60"), "2017-12-14",
     "2017-12-14", Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product7", "Customer13", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.60"), Decimal("1.60"), Decimal("1.60"), Decimal("1.60"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("3.20"), Decimal("3.20"), "2017-12-13", "2017-12-13",
     Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product29", "Customer15", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, None, Decimal("1.00"), Decimal("1.00"), "2017-12-17", "2017-12-17",
     Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product29", "Customer10", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), "2017-12-17",
     "2017-12-17", Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product15", "Customer17", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("1.00"), Decimal("1.00"), "2017-12-12",
     "2017-12-12", Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product17", "Customer10", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), "2017-12-16",
     "2017-12-16", Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product17", "Customer15", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), None,
     None, None, None, Decimal("3.00"), Decimal("3.00"), "2017-12-16", "2017-12-16",
     Decimal("0.42"), Decimal("0.86"), "201744"),
    ("Product1", "Customer16", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("1.24"), Decimal("1.24"), Decimal("1.24"), Decimal("1.24"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("1.24"), Decimal("1.24"), "2017-12-18",
     "2017-12-18", Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product4", "Customer13", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("0.35"), Decimal("0.35"), "2017-12-22",
     "2017-12-22", Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product22", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("0.99"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("1.98"), Decimal("1.98"), "2017-12-24", "2017-12-24",
     Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product18", "Customer1", "All", "All", 2, 1, Decimal("1.34"),
     Decimal("1.00"), Decimal("1.00"), Decimal("0.67"), Decimal("0.67"), Decimal("4.00"),
     Decimal("4.00"), None, None, None, Decimal("4.00"), Decimal("2.66"), "2017-12-21",
     "2017-12-20", Decimal("1.13"), Decimal("1.81"), "201744"),
    ("Product9", "Customer14", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.50"), Decimal("0.50"), Decimal("0.50"), Decimal("0.50"), Decimal("2.00"),
     Decimal("2.00"), None, None, Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), "2017-12-19",
     "2017-12-19", Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product10", "Customer18", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), "2017-12-22",
     "2017-12-22", Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product13", "Customer1", "All", "All", 1, 1, Decimal("0.67"),
     Decimal("1.00"), Decimal("1.00"), Decimal("0.67"), Decimal("0.67"), Decimal("2.00"), None,
     Decimal("2.00"), None, Decimal("2.00"), Decimal("2.00"), Decimal("1.33"), "2017-12-22",
     "2017-12-22", Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product19", "Customer12", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), "2017-12-22",
     "2017-12-22", Decimal("0.56"), Decimal("0.90"), "201744"),
    ("Product0", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, Decimal("0.35"), Decimal("0.35"), "2017-12-23", "2017-12-23", Decimal("0.56"),
     Decimal("0.90"), "201744"),
    ("Product21", "Customer16", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None,
     Decimal("1.00"), None, None, Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30",
     Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product21", "Customer11", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None,
     None, Decimal("1.00"), None, Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30",
     Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product2", "Customer3", "All", "All", 1, 1, Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("7.00"), Decimal("5.60"), "2017-12-29",
     "2017-12-29", Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product2", "Customer18", "All", "All", 1, 1, Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), None,
     Decimal("1.00"), None, None, Decimal("7.00"), Decimal("5.60"), "2017-12-29", "2017-12-29",
     Decimal("0.75"), Decimal("0.95"), "201744"),
    ("Product26", "Customer12", "All", "All", 2, 1, Decimal("0.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None,
     Decimal("2.00"), None, None, Decimal("18.00"), Decimal("18.00"), "2017-12-31", "2017-12-30",
     Decimal("1.50"), Decimal("1.90"), "201744"),
    ("Product19", "Customer19", "All", "All", 1, 1, Decimal("0.00"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, Decimal("2.30"), Decimal("2.30"), "2017-12-27",
     "2017-12-27", Decimal("0.75"), Decimal("0.95"), "201744"),
]
product_customer_all_all_1w1w_schema_supplementary = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("division", pt.StringType(), True),
    pt.StructField("group", pt.StringType(), True),
    pt.StructField("section", pt.StringType(), True),
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
product_customer_all_all_1w1w_lst_supplementary = [
    ("Product0", "Customer13", "All", "All", 1, 1, "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "201743"),
    ("Product1", "Customer16", "All", "All", 1, 1, "A", "A1A", "A1", "A1A1", "201743"),
    ("Product10", "Customer18", "All", "All", 1, 1, "D", "D1A", "D1", "D1A2", "201743"),
    ("Product11", "Customer6", "All", "All", 1, 1, "D", "D2A", "D2", "D2A1", "201743"),
    ("Product13", "Customer1", "All", "All", 1, 1, "D", "D2A", "D2", "D2A1", "201743"),
    ("Product18", "Customer1", "All", "All", 2, 1, "A", "A2B", "A2", "A2B1", "201743"),
    ("Product19", "Customer12", "All", "All", 1, 1, "D", "D2B", "D2", "D2B2", "201743"),
    ("Product22", "Customer11", "All", "All", 1, 1, "A", "A1B", "A1", "A1B1", "201743"),
    ("Product4", "Customer13", "All", "All", 1, 1, "A", "A1B", "A1", "A1B1", "201743"),
    ("Product9", "Customer14", "All", "All", 1, 1, "D", "D1B", "D1", "D1B1", "201743"),
]
product_customer_all_all_1w4w_schema_supplementary = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets1w4w", pt.LongType(), True),
    pt.StructField("basketweeks1w4w", pt.IntegerType(), True),
    pt.StructField("division", pt.StringType(), True),
    pt.StructField("group", pt.StringType(), True),
    pt.StructField("section", pt.StringType(), True),
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
product_customer_all_all_1w4w_lst_supplementary = [
    ("Product0", "Customer13", "All", "All", 1, 1, "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "201743"),
    ("Product1", "Customer16", "All", "All", 1, 1, "A", "A1A", "A1", "A1A1", "201743"),
    ("Product1", "Customer7", "All", "All", 1, 1, "A", "A1A", "A1", "A1A1", "201743"),
    ("Product10", "Customer18", "All", "All", 1, 1, "D", "D1A", "D1", "D1A2", "201743"),
    ("Product11", "Customer6", "All", "All", 2, 2, "D", "D2A", "D2", "D2A1", "201743"),
    ("Product12", "Customer5", "All", "All", 1, 1, "D", "D2B", "D2", "D2B1", "201743"),
    ("Product13", "Customer1", "All", "All", 1, 1, "D", "D2A", "D2", "D2A1", "201743"),
    ("Product15", "Customer17", "All", "All", 1, 1, "B", "B2A", "B2", "B2A1", "201743"),
    ("Product16", "Customer8", "All", "All", 1, 1, "B", "B2B", "B2", "B2B1", "201743"),
    ("Product17", "Customer10", "All", "All", 1, 1, "D", "D1B", "D1", "D1B2", "201743"),
    ("Product17", "Customer15", "All", "All", 1, 1, "D", "D1B", "D1", "D1B2", "201743"),
    ("Product18", "Customer1", "All", "All", 2, 1, "A", "A2B", "A2", "A2B1", "201743"),
    ("Product19", "Customer12", "All", "All", 1, 1, "D", "D2B", "D2", "D2B2", "201743"),
    ("Product22", "Customer11", "All", "All", 1, 1, "A", "A1B", "A1", "A1B1", "201743"),
    ("Product27", "Customer11", "All", "All", 1, 1, "C", "C2B", "C2", "C2B1", "201743"),
    ("Product27", "Customer4", "All", "All", 1, 1, "C", "C2B", "C2", "C2B1", "201743"),
    ("Product28", "Customer18", "All", "All", 1, 1, "C", "C2A", "C2", "C2A1", "201743"),
    ("Product29", "Customer10", "All", "All", 1, 1, "B", "B1B", "B1", "B1B2", "201743"),
    ("Product29", "Customer15", "All", "All", 1, 1, "B", "B1B", "B1", "B1B2", "201743"),
    ("Product30", "Customer14", "All", "All", 1, 1, "C", "C1B", "C1", "C1B2", "201743"),
    ("Product4", "Customer13", "All", "All", 1, 1, "A", "A1B", "A1", "A1B1", "201743"),
    ("Product4", "Customer5", "All", "All", 1, 1, "A", "A1B", "A1", "A1B1", "201743"),
    ("Product4", "Customer9", "All", "All", 1, 1, "A", "A1B", "A1", "A1B1", "201743"),
    ("Product7", "Customer13", "All", "All", 1, 1, "B", "B1B", "B1", "B1B1", "201743"),
    ("Product7", "Customer20", "All", "All", 1, 1, "B", "B1B", "B1", "B1B1", "201743"),
    ("Product9", "Customer14", "All", "All", 1, 1, "D", "D1B", "D1", "D1B1", "201743")
]

"""
Aggregation - subgroup_all_all_all - 1w1w, 1w4w
"""
subgroup_all_all_all_1w1w_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("productcount_1w1w", pt.LongType(), True),
    pt.StructField("customercount_1w1w", pt.LongType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
subgroup_all_all_all_1w1w_lst = [
    ("A1A1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.00"), None, Decimal("1.00"), Decimal("1.00"),
     None, Decimal("4.20"), Decimal("4.20"), "2017-12-30", "2017-12-30", Decimal("1.50"),
     Decimal("1.90"), 1, 2, "201744"),
    ("A2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.69"), Decimal("0.69"),
     Decimal("0.69"), Decimal("0.69"), Decimal("2.00"), None, None, None, None, Decimal("1.38"),
     Decimal("1.38"), "2017-12-28", "2017-12-28", Decimal("0.75"), Decimal("0.95"), 1, 0, "201744"),
    ("B1A1", "All", "All", "All", 2, 1, Decimal("2.80"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), None,
     Decimal("1.00"), Decimal("14.00"), Decimal("11.20"), "2017-12-29", "2017-12-29",
     Decimal("1.50"), Decimal("1.90"), 1, 2, "201744"),
    ("C1B2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("63.84"), Decimal("63.84"),
     Decimal("63.84"), Decimal("63.84"), Decimal("1.00"), None, None, None, None, Decimal("63.84"),
     Decimal("63.84"), "2017-12-25", "2017-12-25", Decimal("0.75"), Decimal("0.95"), 1, 0,
     "201744"),
    ("C2A1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("18.00"), Decimal("18.00"), "2017-12-31", "2017-12-30", Decimal("1.50"),
     Decimal("1.90"), 1, 1, "201744"),
    ("D2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.50"), Decimal("2.50"),
     Decimal("2.50"), Decimal("2.50"), Decimal("1.00"), None, None, None, None, Decimal("2.50"),
     Decimal("2.50"), "2017-12-26", "2017-12-26", Decimal("0.75"), Decimal("0.95"), 1, 0, "201744"),
    ("D2B2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("2.30"), Decimal("2.30"), "2017-12-27", "2017-12-27", Decimal("0.75"), Decimal("0.95"),
     1, 1, "201744")
]
subgroup_all_all_all_1w4w_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("productcount_1w4w", pt.LongType(), True),
    pt.StructField("customercount_1w4w", pt.LongType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
subgroup_all_all_all_1w4w_lst = [
    ("A1B1", "All", "All", "All", 4, 3, Decimal("0.60"), Decimal("1.80"), Decimal("0.30"),
     Decimal("1.50"), Decimal("0.30"), Decimal("7.00"), Decimal("5.00"), Decimal("2.00"), None,
     Decimal("2.00"), Decimal("6.53"), Decimal("5.93"), "2017-12-24", "2017-12-08", Decimal("1.86"),
     Decimal("3.48"), 2, 4, "201744"),
    ("A1A1", "All", "All", "All", 5, 3, Decimal("0.00"), Decimal("20.00"), Decimal("1.24"),
     Decimal("20.00"), Decimal("1.24"), Decimal("5.00"), Decimal("2.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("26.68"), Decimal("26.68"), "2017-12-30",
     "2017-12-09", Decimal("2.94"), Decimal("4.52"), 2, 3, "201744"),
    ("B1B1", "All", "All", "All", 2, 2, Decimal("0.00"), Decimal("10.00"), Decimal("1.60"),
     Decimal("10.00"), Decimal("1.60"), Decimal("3.00"), Decimal("1.00"), Decimal("2.00"), None,
     None, Decimal("13.20"), Decimal("13.20"), "2017-12-13", "2017-12-07", Decimal("0.74"),
     Decimal("1.67"), 1, 2, "201744"),
    ("B2B1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("4.00"), Decimal("4.00"),
     Decimal("4.00"), Decimal("4.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("4.00"), Decimal("4.00"), "2017-12-05", "2017-12-05", Decimal("0.32"), Decimal("0.81"),
     1, 1, "201744"),
    ("C1B2", "All", "All", "All", 2, 2, Decimal("0.00"), Decimal("63.84"), Decimal("47.93"),
     Decimal("63.84"), Decimal("47.93"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("111.77"), Decimal("111.77"), "2017-12-25", "2017-12-04",
     Decimal("1.07"), Decimal("1.76"), 1, 1, "201744"),
    ("C1A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.10"), Decimal("0.10"),
     Decimal("0.10"), Decimal("0.10"), Decimal("1.00"), None, None, None, None, Decimal("0.10"),
     Decimal("0.10"), "2017-12-10", "2017-12-10", Decimal("0.32"), Decimal("0.81"), 1, 0, "201744"),
    ("C2A1", "All", "All", "All", 4, 2, Decimal("0.00"), Decimal("9.00"), Decimal("0.99"),
     Decimal("9.00"), Decimal("0.99"), Decimal("4.00"), Decimal("1.00"), Decimal("2.00"), None,
     Decimal("1.00"), Decimal("19.98"), Decimal("19.98"), "2017-12-31", "2017-12-06",
     Decimal("2.13"), Decimal("3.53"), 2, 2, "201744"),
    ("C2B1", "All", "All", "All", 3, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("3.00"), Decimal("2.00"), None, None,
     Decimal("1.00"), Decimal("60.00"), Decimal("60.00"), "2017-12-09", "2017-12-09",
     Decimal("0.95"), Decimal("2.44"), 1, 2, "201744"),
    ("D2B1", "All", "All", "All", 2, 2, Decimal("0.60"), Decimal("1.80"), Decimal("1.00"),
     Decimal("1.50"), Decimal("1.00"), Decimal("3.00"), Decimal("2.00"), None, None, None,
     Decimal("4.60"), Decimal("4.00"), "2017-12-12", "2017-12-08", Decimal("0.74"), Decimal("1.67"),
     1, 1, "201744"),
    ("D2A1", "All", "All", "All", 4, 3, Decimal("0.67"), Decimal("3.00"), Decimal("1.00"),
     Decimal("3.00"), Decimal("0.67"), Decimal("5.00"), Decimal("2.00"), Decimal("2.00"), None,
     Decimal("4.00"), Decimal("10.50"), Decimal("9.83"), "2017-12-26", "2017-12-09",
     Decimal("2.19"), Decimal("3.57"), 2, 2, "201744"),
    ("B1A1", "All", "All", "All", 3, 2, Decimal("2.80"), Decimal("16.00"), Decimal("7.00"),
     Decimal("16.00"), Decimal("5.60"), Decimal("3.00"), Decimal("1.00"), Decimal("1.00"), None,
     Decimal("1.00"), Decimal("30.00"), Decimal("27.20"), "2017-12-29", "2017-12-11",
     Decimal("1.92"), Decimal("2.76"), 2, 2, "201744"),
    ("B1B2", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("2.00"), Decimal("2.00"), "2017-12-17", "2017-12-17", Decimal("0.84"),
     Decimal("1.71"), 1, 2, "201744"),
    ("B2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("1.00"), Decimal("1.00"), "2017-12-12", "2017-12-12", Decimal("0.42"), Decimal("0.86"),
     1, 1, "201744"),
    ("C1A2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.70"), Decimal("2.70"),
     Decimal("2.70"), Decimal("2.70"), Decimal("1.00"), None, None, None, None, Decimal("2.70"),
     Decimal("2.70"), "2017-12-15", "2017-12-15", Decimal("0.42"), Decimal("0.86"), 1, 0, "201744"),
    ("D1B2", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("2.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("6.00"), Decimal("6.00"), "2017-12-16", "2017-12-16", Decimal("0.84"),
     Decimal("1.71"), 1, 2, "201744"),
    ("A2B1", "All", "All", "All", 2, 1, Decimal("1.34"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.67"), Decimal("0.67"), Decimal("4.00"), Decimal("4.00"), None, None, None,
     Decimal("4.00"), Decimal("2.66"), "2017-12-21", "2017-12-20", Decimal("1.13"), Decimal("1.81"),
     1, 1, "201744"),
    ("A2A2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.39"), Decimal("0.39"),
     Decimal("0.39"), Decimal("0.39"), Decimal("1.00"), None, None, None, None, Decimal("0.39"),
     Decimal("0.39"), "2017-12-21", "2017-12-21", Decimal("0.56"), Decimal("0.90"), 1, 0, "201744"),
    ("D1B1", "All", "All", "All", 2, 1, Decimal("0.00"), Decimal("0.50"), Decimal("0.50"),
     Decimal("0.50"), Decimal("0.50"), Decimal("4.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("2.00"), Decimal("2.00"), "2017-12-19", "2017-12-19", Decimal("1.13"),
     Decimal("1.81"), 1, 1, "201744"),
    ("D1A2", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), "2017-12-22", "2017-12-22", Decimal("0.56"),
     Decimal("0.90"), 1, 1, "201744"),
    ("D2B2", "All", "All", "All", 2, 2, Decimal("0.00"), Decimal("2.30"), Decimal("0.35"),
     Decimal("2.30"), Decimal("0.35"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("1.00"), Decimal("2.65"), Decimal("2.65"), "2017-12-27", "2017-12-22", Decimal("1.31"),
     Decimal("1.85"), 1, 2, "201744"),
    ("UNKNOWN_DIMENSION", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, Decimal("0.35"), Decimal("0.35"), "2017-12-23", "2017-12-23", Decimal("0.56"),
     Decimal("0.90"), 1, 1, "201744"),
    ("A2A1", "All", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.69"), Decimal("0.69"),
     Decimal("0.69"), Decimal("0.69"), Decimal("2.00"), None, None, None, None, Decimal("1.38"),
     Decimal("1.38"), "2017-12-28", "2017-12-28", Decimal("0.75"), Decimal("0.95"), 1, 0, "201744")
]

"""
Aggregation - subgroup_customer_all_all - 1w1w, 1w4w
"""
subgroup_customer_all_all_1w1w_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("productcount_1w1w", pt.LongType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
subgroup_customer_all_all_1w1w_lst = [
    ("A1A1", "Customer16", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30", Decimal("0.75"), Decimal("0.95"),
     1, "201744"),
    ("A1A1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None, None, Decimal("1.00"), None,
     Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30", Decimal("0.75"), Decimal("0.95"),
     1, "201744"),
    ("B1A1", "Customer3", "All", "All", 1, 1, Decimal("1.40"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("7.00"), Decimal("5.60"), "2017-12-29", "2017-12-29", Decimal("0.75"),
     Decimal("0.95"), 1, "201744"),
    ("B1A1", "Customer18", "All", "All", 1, 1, Decimal("1.40"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("7.00"), Decimal("5.60"), "2017-12-29", "2017-12-29", Decimal("0.75"), Decimal("0.95"),
     1, "201744"),
    ("C2A1", "Customer12", "All", "All", 2, 1, Decimal("0.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("18.00"), Decimal("18.00"), "2017-12-31", "2017-12-30", Decimal("1.50"),
     Decimal("1.90"), 1, "201744"),
    ("D2B2", "Customer19", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("2.30"), Decimal("2.30"), "2017-12-27", "2017-12-27", Decimal("0.75"), Decimal("0.95"),
     1, "201744")
]
subgroup_customer_all_all_1w4w_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("productcount_1w4w", pt.LongType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
subgroup_customer_all_all_1w4w_lst = [
    ("A1B1", "Customer5", "All", "All", 1, 1, Decimal("0.60"), Decimal("1.80"), Decimal("1.80"),
     Decimal("1.50"), Decimal("1.50"), Decimal("2.00"), Decimal("2.00"), None, None, None,
     Decimal("3.60"), Decimal("3.00"), "2017-12-08", "2017-12-08", Decimal("0.32"), Decimal("0.81"),
     1, "201744"),
    ("A1A1", "Customer7", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("20.00"), Decimal("20.00"), "2017-12-09", "2017-12-09", Decimal("0.32"),
     Decimal("0.81"), 1, "201744"),
    ("B1B1", "Customer20", "All", "All", 1, 1, Decimal("0.00"), Decimal("10.00"), Decimal("10.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("10.00"), Decimal("10.00"), "2017-12-07", "2017-12-07", Decimal("0.32"),
     Decimal("0.81"), 1, "201744"),
    ("B2B1", "Customer8", "All", "All", 1, 1, Decimal("0.00"), Decimal("4.00"), Decimal("4.00"),
     Decimal("4.00"), Decimal("4.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("4.00"), Decimal("4.00"), "2017-12-05", "2017-12-05", Decimal("0.32"), Decimal("0.81"),
     1, "201744"),
    ("C1B2", "Customer14", "All", "All", 1, 1, Decimal("0.00"), Decimal("47.93"), Decimal("47.93"),
     Decimal("47.93"), Decimal("47.93"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("47.93"), Decimal("47.93"), "2017-12-04", "2017-12-04",
     Decimal("0.32"), Decimal("0.81"), 1, "201744"),
    ("C1B1", "Customer20", "All", "All", 1, 1, Decimal("0.00"), Decimal("10.00"), Decimal("10.00"),
     Decimal("10.00"), Decimal("10.00"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("10.00"), Decimal("10.00"), "2017-12-07", "2017-12-07", Decimal("0.32"),
     Decimal("0.81"), None, "201744"),
    ("C2A1", "Customer18", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.99"), Decimal("0.99"),
     Decimal("0.99"), Decimal("0.99"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.99"), Decimal("0.99"), "2017-12-06", "2017-12-06", Decimal("0.32"),
     Decimal("0.81"), 1, "201744"),
    ("C2B1", "Customer4", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("20.00"), Decimal("20.00"), "2017-12-09", "2017-12-09", Decimal("0.32"),
     Decimal("0.81"), 1, "201744"),
    ("C2B1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("20.00"), Decimal("20.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("20.00"), Decimal("20.00"), "2017-12-09", "2017-12-09",
     Decimal("0.32"), Decimal("0.81"), 1, "201744"),
    ("D2B1", "Customer5", "All", "All", 1, 1, Decimal("0.60"), Decimal("1.80"), Decimal("1.80"),
     Decimal("1.50"), Decimal("1.50"), Decimal("2.00"), Decimal("2.00"), None, None, None,
     Decimal("3.60"), Decimal("3.00"), "2017-12-08", "2017-12-08", Decimal("0.32"), Decimal("0.81"),
     1, "201744"),
    ("D2A1", "Customer6", "All", "All", 2, 2, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("6.00"), Decimal("6.00"), "2017-12-23", "2017-12-09", Decimal("0.88"),
     Decimal("1.72"), 1, "201744"),
    ("A1B1", "Customer9", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.30"), Decimal("0.30"),
     Decimal("0.30"), Decimal("0.30"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("0.60"), Decimal("0.60"), "2017-12-14", "2017-12-14", Decimal("0.42"),
     Decimal("0.86"), 1, "201744"),
    ("B1B1", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.60"), Decimal("1.60"),
     Decimal("1.60"), Decimal("1.60"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("3.20"), Decimal("3.20"), "2017-12-13", "2017-12-13", Decimal("0.42"), Decimal("0.86"),
     1, "201744"),
    ("B1B2", "Customer15", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None, None, Decimal("1.00"),
     Decimal("1.00"), "2017-12-17", "2017-12-17", Decimal("0.42"), Decimal("0.86"), 1, "201744"),
    ("B1B2", "Customer10", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), "2017-12-17", "2017-12-17", Decimal("0.42"),
     Decimal("0.86"), 1, "201744"),
    ("B2A1", "Customer17", "All", "All", 1, 1, Decimal("0.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("1.00"), Decimal("1.00"), "2017-12-12", "2017-12-12", Decimal("0.42"), Decimal("0.86"),
     1, "201744"),
    ("D1B2", "Customer10", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("3.00"), Decimal("3.00"), "2017-12-16", "2017-12-16", Decimal("0.42"),
     Decimal("0.86"), 1, "201744"),
    ("D1B2", "Customer15", "All", "All", 1, 1, Decimal("0.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("3.00"), Decimal("3.00"), Decimal("1.00"), None, None, None, None, Decimal("3.00"),
     Decimal("3.00"), "2017-12-16", "2017-12-16", Decimal("0.42"), Decimal("0.86"), 1, "201744"),
    ("A1A1", "Customer16", "All", "All", 2, 2, Decimal("0.00"), Decimal("2.10"), Decimal("1.24"),
     Decimal("2.10"), Decimal("1.24"), Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), None,
     Decimal("1.00"), Decimal("3.34"), Decimal("3.34"), "2017-12-30", "2017-12-18", Decimal("1.31"),
     Decimal("1.85"), 2, "201744"),
    ("A1B1", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("0.35"), Decimal("0.35"), "2017-12-22", "2017-12-22", Decimal("0.56"), Decimal("0.90"),
     1, "201744"),
    ("A1B1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.99"), Decimal("0.99"),
     Decimal("0.99"), Decimal("0.99"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("1.98"), Decimal("1.98"), "2017-12-24", "2017-12-24", Decimal("0.56"), Decimal("0.90"),
     1, "201744"),
    ("A2B1", "Customer1", "All", "All", 2, 1, Decimal("1.34"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.67"), Decimal("0.67"), Decimal("4.00"), Decimal("4.00"), None, None, None,
     Decimal("4.00"), Decimal("2.66"), "2017-12-21", "2017-12-20", Decimal("1.13"), Decimal("1.81"),
     1, "201744"),
    ("D1B1", "Customer14", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.50"), Decimal("0.50"),
     Decimal("0.50"), Decimal("0.50"), Decimal("2.00"), Decimal("2.00"), None, None,
     Decimal("2.00"), Decimal("1.00"), Decimal("1.00"), "2017-12-19", "2017-12-19", Decimal("0.56"),
     Decimal("0.90"), 1, "201744"),
    ("D1A2", "Customer18", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), "2017-12-22", "2017-12-22", Decimal("0.56"),
     Decimal("0.90"), 1, "201744"),
    ("D2A1", "Customer1", "All", "All", 1, 1, Decimal("0.67"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.67"), Decimal("0.67"), Decimal("2.00"), None, Decimal("2.00"), None,
     Decimal("2.00"), Decimal("2.00"), Decimal("1.33"), "2017-12-22", "2017-12-22", Decimal("0.56"),
     Decimal("0.90"), 1, "201744"),
    ("D2B2", "Customer12", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("0.35"), Decimal("0.35"), "2017-12-22", "2017-12-22", Decimal("0.56"),
     Decimal("0.90"), 1, "201744"),
    ("DEFAULT_HIERARCHY", "Customer13", "All", "All", 1, 1, Decimal("0.00"), Decimal("0.35"),
     Decimal("0.35"), Decimal("0.35"), Decimal("0.35"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, Decimal("0.35"), Decimal("0.35"), "2017-12-23", "2017-12-23", Decimal("0.56"),
     Decimal("0.90"), None, "201744"),
    ("A1A1", "Customer11", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), None, None, Decimal("1.00"), None,
     Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30", Decimal("0.75"), Decimal("0.95"),
     1, "201744"),
    ("B1A1", "Customer3", "All", "All", 1, 1, Decimal("1.40"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("1.00"), Decimal("7.00"), Decimal("5.60"), "2017-12-29", "2017-12-29", Decimal("0.75"),
     Decimal("0.95"), 1, "201744"),
    ("B1A1", "Customer18", "All", "All", 1, 1, Decimal("1.40"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), None, Decimal("1.00"), None, None,
     Decimal("7.00"), Decimal("5.60"), "2017-12-29", "2017-12-29", Decimal("0.75"), Decimal("0.95"),
     1, "201744"),
    ("C2A1", "Customer12", "All", "All", 2, 1, Decimal("0.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), None, Decimal("2.00"), None, None,
     Decimal("18.00"), Decimal("18.00"), "2017-12-31", "2017-12-30", Decimal("1.50"),
     Decimal("1.90"), 1, "201744"),
    ("D2B2", "Customer19", "All", "All", 1, 1, Decimal("0.00"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), None, None, None,
     Decimal("2.30"), Decimal("2.30"), "2017-12-27", "2017-12-27", Decimal("0.75"), Decimal("0.95"),
     1, "201744")
]

"""
Aggregation - feature_distinct_tab - 1w1w, 1w4w
"""
feature_distinct_tab_1w1w_schema = pt.StructType([
    pt.StructField("division", pt.StringType(), True),
    pt.StructField("section", pt.StringType(), True),
    pt.StructField("group", pt.StringType(), True),
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
feature_distinct_tab_1w1w_lst = [
    ("A", "A1", "A1A", "A1A1", "Product21", "Customer16", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product21", "Customer11", "201744"),
    ("A", "A2", "A2A", "A2A1", "Product14", None, "201744"),
    ("B", "B1", "B1A", "B1A1", "Product2", "Customer3", "201744"),
    ("B", "B1", "B1A", "B1A1", "Product2", "Customer18", "201744"),
    ("C", "C1", "C1B", "C1B2", "Product30", None, "201744"),
    ("C", "C2", "C2A", "C2A1", "Product26", "Customer12", "201744"),
    ("D", "D2", "D2A", "D2A1", "Product13", None, "201744"),
    ("D", "D2", "D2B", "D2B2", "Product19", "Customer19", "201744"),
]
feature_distinct_tab_1w4w_schema = pt.StructType([
    pt.StructField("division", pt.StringType(), True),
    pt.StructField("section", pt.StringType(), True),
    pt.StructField("group", pt.StringType(), True),
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
feature_distinct_tab_1w4w_lst = [
    ("A", "A1", "A1B", "A1B1", "Product4", "Customer5", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product1", "Customer7", "201744"),
    ("B", "B1", "B1B", "B1B1", "Product7", "Customer20", "201744"),
    ("B", "B2", "B2B", "B2B1", "Product16", "Customer8", "201744"),
    ("C", "C1", "C1B", "C1B2", "Product30", "Customer14", "201744"),
    ("C", "C1", "C1A", "C1A1", "Product3", None, "201744"),
    ("C", "C2", "C2A", "C2A1", "Product28", "Customer18", "201744"),
    ("C", "C2", "C2A", "C2A1", "Product28", None, "201744"),
    ("C", "C2", "C2B", "C2B1", "Product27", "Customer4", "201744"),
    ("C", "C2", "C2B", "C2B1", "Product27", "Customer11", "201744"),
    ("C", "C2", "C2B", "C2B1", "Product27", None, "201744"),
    ("D", "D2", "D2B", "D2B1", "Product12", "Customer5", "201744"),
    ("D", "D2", "D2A", "D2A1", "Product11", "Customer6", "201744"),
    ("D", "D2", "D2B", "D2B1", "Product12", None, "201744"),
    ("A", "A1", "A1B", "A1B1", "Product4", "Customer9", "201744"),
    ("B", "B1", "B1A", "B1A1", "Product20", None, "201744"),
    ("B", "B1", "B1B", "B1B1", "Product7", "Customer13", "201744"),
    ("B", "B1", "B1B", "B1B2", "Product29", "Customer15", "201744"),
    ("B", "B1", "B1B", "B1B2", "Product29", "Customer10", "201744"),
    ("B", "B2", "B2A", "B2A1", "Product15", "Customer17", "201744"),
    ("C", "C1", "C1A", "C1A2", "Product6", None, "201744"),
    ("D", "D1", "D1B", "D1B2", "Product17", "Customer10", "201744"),
    ("D", "D1", "D1B", "D1B2", "Product17", "Customer15", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product1", "Customer16", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product1", None, "201744"),
    ("A", "A1", "A1B", "A1B1", "Product4", "Customer13", "201744"),
    ("A", "A1", "A1B", "A1B1", "Product22", "Customer11", "201744"),
    ("A", "A2", "A2B", "A2B1", "Product18", "Customer1", "201744"),
    ("A", "A2", "A2A", "A2A2", "Product23", None, "201744"),
    ("D", "D1", "D1B", "D1B1", "Product9", None, "201744"),
    ("D", "D1", "D1B", "D1B1", "Product9", "Customer14", "201744"),
    ("D", "D1", "D1A", "D1A2", "Product10", "Customer18", "201744"),
    ("D", "D2", "D2A", "D2A1", "Product13", "Customer1", "201744"),
    ("D", "D2", "D2B", "D2B2", "Product19", "Customer12", "201744"),
    ("UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION",
     "Product0", "Customer13", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product21", "Customer16", "201744"),
    ("A", "A1", "A1A", "A1A1", "Product21", "Customer11", "201744"),
    ("A", "A2", "A2A", "A2A1", "Product14", None, "201744"),
    ("B", "B1", "B1A", "B1A1", "Product2", "Customer3", "201744"),
    ("B", "B1", "B1A", "B1A1", "Product2", "Customer18", "201744"),
    ("C", "C1", "C1B", "C1B2", "Product30", None, "201744"),
    ("C", "C2", "C2A", "C2A1", "Product26", "Customer12", "201744"),
    ("D", "D2", "D2A", "D2A1", "Product13", None, "201744"),
    ("D", "D2", "D2B", "D2B2", "Product19", "Customer19", "201744")
]

"""
Merge - all_all_all_all
"""
all_all_all_all_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("divisioncount_1w1w", pt.LongType(), True),
    pt.StructField("divisioncount_1w4w", pt.LongType(), True),
    pt.StructField("sectioncount_1w1w", pt.LongType(), True),
    pt.StructField("sectioncount_1w4w", pt.LongType(), True),
    pt.StructField("groupcount_1w1w", pt.LongType(), True),
    pt.StructField("groupcount_1w4w", pt.LongType(), True),
    pt.StructField("subgroupcount_1w1w", pt.LongType(), True),
    pt.StructField("subgroupcount_1w4w", pt.LongType(), True),
    pt.StructField("productcount_1w1w", pt.LongType(), True),
    pt.StructField("productcount_1w4w", pt.LongType(), True),
    pt.StructField("customercount_1w1w", pt.LongType(), True),
    pt.StructField("customercount_1w4w", pt.LongType(), True),
    pt.StructField("basketsflag_1w1w", pt.BooleanType(), True),
    pt.StructField("basketsflag_1w4w", pt.BooleanType(), True),
    pt.StructField("discountperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencydays_1w1w", pt.IntegerType(), True),
    pt.StructField("recencydays_1w4w", pt.IntegerType(), True),
    pt.StructField("cyclessincelastpurchase_1w1w", pt.DecimalType(6, 2), True),
    pt.StructField("cyclessincelastpurchase_1w4w", pt.DecimalType(6, 2), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
all_all_all_all_lst = [
    ("All", "All", "All", "All", 9, 47, 1, 4, Decimal("2.80"), Decimal("6.01"), Decimal("9.00"),
     Decimal("63.84"), Decimal("0.69"), Decimal("0.10"), Decimal("9.00"), Decimal("63.84"),
     Decimal("0.69"), Decimal("0.10"), Decimal("10.00"), Decimal("58.00"), Decimal("2.00"),
     Decimal("31.00"), Decimal("4.00"), Decimal("10.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("17.00"), Decimal("42.38"), Decimal("310.18"), Decimal("39.58"),
     Decimal("304.17"), "2017-12-30", "2017-12-30", "2017-12-26", "2017-12-04", Decimal("6.75"),
     Decimal("23.52"), Decimal("8.55"), Decimal("41.25"), 4, 5, 6, 9, 7, 17, 7, 22, 7, 27, 6, 19,
     True, True, Decimal("0.31"), Decimal("0.13"), Decimal("6.61"), Decimal("1.94"),
     Decimal("4.24"), Decimal("5.35"), Decimal("1.11"), Decimal("1.23"), Decimal("4.40"),
     Decimal("6.47"), Decimal("0.50"), Decimal("0.57"), 2, 2, Decimal("4.00"), Decimal("3.54"),
     "201744")
]

"""
Merge - product_customer_all_all
"""
product_customer_all_all_schema = pt.StructType([
    pt.StructField("product", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("basketsflag_1w1w", pt.BooleanType(), True),
    pt.StructField("basketsflag_1w4w", pt.BooleanType(), True),
    pt.StructField("discountperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencydays_1w1w", pt.IntegerType(), True),
    pt.StructField("recencydays_1w4w", pt.IntegerType(), True),
    pt.StructField("cyclessincelastpurchase_1w1w", pt.DecimalType(6, 2), True),
    pt.StructField("cyclessincelastpurchase_1w4w", pt.DecimalType(6, 2), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
product_customer_all_all_lst = [
    ("Product4", "Customer5", "All", "All", None, 1, None, 1, None,
     Decimal("0.60"), None, Decimal("1.80"), None, Decimal("1.80"), None, Decimal("1.50"), None,
     Decimal("1.50"), None, Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None,
     None, None, Decimal("3.60"), None, Decimal("3.00"), None, "2017-12-08", None, "2017-12-08",
     None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.60"), None,
     Decimal("16.67"), None, Decimal("1.80"), None, Decimal("2.00"), None, Decimal("3.00"), None,
     None, None, 24, None, None, "201744"),
    ("Product1", "Customer7", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None,
     Decimal("20.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     None, None, Decimal("20.00"), None, Decimal("20.00"), None, "2017-12-09", None, "2017-12-09",
     None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"), None,
     None, None, 23, None, None, "201744"),
    ("Product7", "Customer20", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("10.00"), None, Decimal("10.00"), None, Decimal("10.00"), None,
     Decimal("10.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     None, None, Decimal("10.00"), None, Decimal("10.00"), None, "2017-12-07", None, "2017-12-07",
     None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("10.00"), None, Decimal("1.00"), None, Decimal("10.00"), None,
     None, None, 25, None, None, "201744"),
    ("Product16", "Customer8", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("4.00"), None, Decimal("4.00"), None, Decimal("4.00"), None,
     Decimal("4.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     None, None, Decimal("4.00"), None, Decimal("4.00"), None, "2017-12-05", None, "2017-12-05",
     None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("4.00"), None, Decimal("1.00"), None, Decimal("4.00"), None,
     None, None, 27, None, None, "201744"),
    ("Product30", "Customer14", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("47.93"), None, Decimal("47.93"), None, Decimal("47.93"), None,
     Decimal("47.93"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("47.93"), None, Decimal("47.93"), None, "2017-12-04", None,
     "2017-12-04", None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("47.93"), None, Decimal("1.00"), None, Decimal("47.93"),
     None, None, None, 28, None, None, "201744"),
    ("Product28", "Customer18", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.99"), None, Decimal("0.99"), None, Decimal("0.99"), None,
     Decimal("0.99"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("0.99"), None, Decimal("0.99"), None, "2017-12-06", None,
     "2017-12-06", None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("0.99"), None, Decimal("1.00"), None, Decimal("0.99"),
     None, None, None, 26, None, None, "201744"),
    ("Product27", "Customer4", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None,
     Decimal("20.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     None, None, Decimal("20.00"), None, Decimal("20.00"), None, "2017-12-09", None, "2017-12-09",
     None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"), None,
     None, None, 23, None, None, "201744"),
    ("Product27", "Customer11", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None,
     Decimal("20.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, "2017-12-09", None,
     "2017-12-09", None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"),
     None, None, None, 23, None, None, "201744"),
    ("Product12", "Customer5", "All", "All", None, 1, None, 1, None,
     Decimal("0.60"), None, Decimal("1.80"), None, Decimal("1.80"), None, Decimal("1.50"), None,
     Decimal("1.50"), None, Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None,
     None, None, Decimal("3.60"), None, Decimal("3.00"), None, "2017-12-08", None, "2017-12-08",
     None, Decimal("0.32"), None, Decimal("0.81"), False, True, None, Decimal("0.60"), None,
     Decimal("16.67"), None, Decimal("1.80"), None, Decimal("2.00"), None, Decimal("3.00"), None,
     None, None, 24, None, None, "201744"),
    ("Product11", "Customer6", "All", "All", None, 2, None, 2, None,
     Decimal("0.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None,
     Decimal("3.00"), None, Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None,
     Decimal("2.00"), None, Decimal("6.00"), None, Decimal("6.00"), None, "2017-12-23", None,
     "2017-12-09", None, Decimal("0.88"), None, Decimal("1.72"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"),
     None, Decimal("14.00"), None, 9, None, Decimal("0.64"), "201744"),
    ("Product4", "Customer9", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.30"), None, Decimal("0.30"), None, Decimal("0.30"), None,
     Decimal("0.30"), None, Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None,
     Decimal("2.00"), None, Decimal("0.60"), None, Decimal("0.60"), None, "2017-12-14", None,
     "2017-12-14", None, Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("0.30"), None, Decimal("2.00"), None, Decimal("0.60"),
     None, None, None, 18, None, None, "201744"),
    ("Product7", "Customer13", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("1.60"), None, Decimal("1.60"), None, Decimal("1.60"), None,
     Decimal("1.60"), None, Decimal("2.00"), None, None, None, Decimal("2.00"), None, None, None,
     None, None, Decimal("3.20"), None, Decimal("3.20"), None, "2017-12-13", None, "2017-12-13",
     None, Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("1.60"), None, Decimal("2.00"), None, Decimal("3.20"), None,
     None, None, 19, None, None, "201744"),
    ("Product29", "Customer15", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None, None, None,
     Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-17", None, "2017-12-17", None,
     Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     None, None, 15, None, None, "201744"),
    ("Product29", "Customer10", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-17", None,
     "2017-12-17", None, Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"),
     None, None, None, 15, None, None, "201744"),
    ("Product15", "Customer17", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     None, None, Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-12", None, "2017-12-12",
     None, Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     None, None, 20, None, None, "201744"),
    ("Product17", "Customer10", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None,
     Decimal("3.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, "2017-12-16", None,
     "2017-12-16", None, Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"),
     None, None, None, 16, None, None, "201744"),
    ("Product17", "Customer15", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None,
     Decimal("3.00"), None, Decimal("1.00"), None, None, None, None, None, None, None, None, None,
     Decimal("3.00"), None, Decimal("3.00"), None, "2017-12-16", None, "2017-12-16", None,
     Decimal("0.42"), None, Decimal("0.86"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"), None,
     None, None, 16, None, None, "201744"),
    ("Product1", "Customer16", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("1.24"), None, Decimal("1.24"), None, Decimal("1.24"), None,
     Decimal("1.24"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("1.24"), None, Decimal("1.24"), None, "2017-12-18", None,
     "2017-12-18", None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("1.24"), None, Decimal("1.00"), None, Decimal("1.24"),
     None, None, None, 14, None, None, "201744"),
    ("Product4", "Customer13", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("0.35"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     None, None, Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-22", None, "2017-12-22",
     None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None,
     None, None, 10, None, None, "201744"),
    ("Product22", "Customer11", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.99"), None, Decimal("0.99"), None, Decimal("0.99"), None,
     Decimal("0.99"), None, Decimal("2.00"), None, None, None, Decimal("2.00"), None, None, None,
     None, None, Decimal("1.98"), None, Decimal("1.98"), None, "2017-12-24", None, "2017-12-24",
     None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.99"), None, Decimal("2.00"), None, Decimal("1.98"), None,
     None, None, 8, None, None, "201744"),
    ("Product18", "Customer1", "All", "All", None, 2, None, 1, None,
     Decimal("1.34"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("0.67"), None,
     Decimal("0.67"), None, Decimal("4.00"), None, Decimal("4.00"), None, None, None, None, None,
     None, None, Decimal("4.00"), None, Decimal("2.66"), None, "2017-12-21", None, "2017-12-20",
     None, Decimal("1.13"), None, Decimal("1.81"), False, True, None, Decimal("0.67"), None,
     Decimal("33.50"), None, Decimal("1.00"), None, Decimal("2.00"), None, Decimal("1.33"), None,
     Decimal("1.00"), None, 11, None, Decimal("11.00"), "201744"),
    ("Product9", "Customer14", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.50"), None, Decimal("0.50"), None, Decimal("0.50"), None,
     Decimal("0.50"), None, Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None,
     Decimal("2.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-19", None,
     "2017-12-19", None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("0.50"), None, Decimal("2.00"), None, Decimal("1.00"),
     None, None, None, 13, None, None, "201744"),
    ("Product10", "Customer18", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("0.35"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-22", None,
     "2017-12-22", None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"),
     None, None, None, 10, None, None, "201744"),
    ("Product13", "Customer1", "All", "All", None, 1, None, 1, None,
     Decimal("0.67"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("0.67"), None,
     Decimal("0.67"), None, Decimal("2.00"), None, None, None, Decimal("2.00"), None, None, None,
     Decimal("2.00"), None, Decimal("2.00"), None, Decimal("1.33"), None, "2017-12-22", None,
     "2017-12-22", None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.67"),
     None, Decimal("33.50"), None, Decimal("1.00"), None, Decimal("2.00"), None, Decimal("1.33"),
     None, None, None, 10, None, None, "201744"),
    ("Product19", "Customer12", "All", "All", None, 1, None, 1, None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("0.35"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None,
     Decimal("1.00"), None, Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-22", None,
     "2017-12-22", None, Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"),
     None, None, None, 10, None, None, "201744"),
    ("Product0", "Customer13", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-23", None, "2017-12-23", None,
     Decimal("0.56"), None, Decimal("0.90"), False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None,
     None, None, 9, None, None, "201744"),
    ("Product21", "Customer16", "All", "All", 1, 1, 1, 1, Decimal("0.00"),
     Decimal("0.00"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("1.00"), None, None, None, None,
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30",
     "2017-12-30", "2017-12-30", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"),
     True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), Decimal("1.00"), Decimal("2.10"),
     Decimal("2.10"), None, None, 2, 2, None, None, "201744"),
    ("Product21", "Customer11", "All", "All", 1, 1, 1, 1, Decimal("0.00"),
     Decimal("0.00"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"),
     Decimal("1.00"), None, None, None, None, Decimal("1.00"), Decimal("1.00"), None, None,
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30",
     "2017-12-30", "2017-12-30", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"),
     True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), Decimal("1.00"), Decimal("2.10"),
     Decimal("2.10"), None, None, 2, 2, None, None, "201744"),
    ("Product2", "Customer3", "All", "All", 1, 1, 1, 1, Decimal("1.40"),
     Decimal("1.40"), Decimal("7.00"), Decimal("7.00"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None, None, Decimal("1.00"),
     Decimal("1.00"), Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"),
     "2017-12-29", "2017-12-29", "2017-12-29", "2017-12-29", Decimal("0.75"), Decimal("0.75"),
     Decimal("0.95"), Decimal("0.95"), True, True, Decimal("1.40"), Decimal("1.40"),
     Decimal("20.00"), Decimal("20.00"), Decimal("7.00"), Decimal("7.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("5.60"), Decimal("5.60"), None, None, 3, 3, None, None, "201744"),
    ("Product2", "Customer18", "All", "All", 1, 1, 1, 1, Decimal("1.40"),
     Decimal("1.40"), Decimal("7.00"), Decimal("7.00"), Decimal("7.00"), Decimal("7.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"),
     Decimal("1.00"), None, None, Decimal("1.00"), Decimal("1.00"), None, None, None, None,
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), "2017-12-29", "2017-12-29",
     "2017-12-29", "2017-12-29", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"),
     True, True, Decimal("1.40"), Decimal("1.40"), Decimal("20.00"), Decimal("20.00"),
     Decimal("7.00"), Decimal("7.00"), Decimal("1.00"), Decimal("1.00"), Decimal("5.60"),
     Decimal("5.60"), None, None, 3, 3, None, None, "201744"),
    ("Product26", "Customer12", "All", "All", 2, 2, 1, 1, Decimal("0.00"),
     Decimal("0.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("2.00"),
     Decimal("2.00"), None, None, Decimal("2.00"), Decimal("2.00"), None, None, None, None,
     Decimal("18.00"), Decimal("18.00"), Decimal("18.00"), Decimal("18.00"), "2017-12-31",
     "2017-12-31", "2017-12-30", "2017-12-30", Decimal("1.50"), Decimal("1.50"), Decimal("1.90"),
     Decimal("1.90"), True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("0.00"), Decimal("9.00"), Decimal("9.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("1.00"), Decimal("1.00"), 1, 1, Decimal("1.00"),
     Decimal("1.00"), "201744"),
    ("Product19", "Customer19", "All", "All", 1, 1, 1, 1, Decimal("0.00"),
     Decimal("0.00"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None, None, None, None,
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), "2017-12-27", "2017-12-27",
     "2017-12-27", "2017-12-27", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"),
     True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), Decimal("2.30"),
     Decimal("2.30"), None, None, 5, 5, None, None, "201744"),
]

"""
Merge - subgroup_all_all_all
"""
subgroup_all_all_all_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("productcount_1w1w", pt.LongType(), True),
    pt.StructField("productcount_1w4w", pt.LongType(), True),
    pt.StructField("customercount_1w1w", pt.LongType(), True),
    pt.StructField("customercount_1w4w", pt.LongType(), True),
    pt.StructField("basketsflag_1w1w", pt.BooleanType(), True),
    pt.StructField("basketsflag_1w4w", pt.BooleanType(), True),
    pt.StructField("discountperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencydays_1w1w", pt.IntegerType(), True),
    pt.StructField("recencydays_1w4w", pt.IntegerType(), True),
    pt.StructField("cyclessincelastpurchase_1w1w", pt.DecimalType(6, 2), True),
    pt.StructField("cyclessincelastpurchase_1w4w", pt.DecimalType(6, 2), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
subgroup_all_all_all_lst = [
    ("B1A1", "All", "All", "All", 2, 3, 1, 2, Decimal("2.80"), Decimal("2.80"), Decimal("7.00"),
     Decimal("16.00"), Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("16.00"),
     Decimal("5.60"), Decimal("5.60"), Decimal("2.00"), Decimal("3.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, Decimal("1.00"),
     Decimal("1.00"), Decimal("14.00"), Decimal("30.00"), Decimal("11.20"), Decimal("27.20"),
     "2017-12-29", "2017-12-29", "2017-12-29", "2017-12-11", Decimal("1.50"), Decimal("1.92"),
     Decimal("1.90"), Decimal("2.76"), 1, 2, 2, 2, True, True, Decimal("1.40"), Decimal("0.93"),
     Decimal("20.00"), Decimal("9.33"), Decimal("7.00"), Decimal("10.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("5.60"), Decimal("9.07"), Decimal("0.00"), Decimal("9.00"), 3, 3,
     None, Decimal("0.33"), "201744"),
    ("B1B2", "All", "All", "All", None, 2, None, 1, None, Decimal("0.00"), None, Decimal("1.00"),
     None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("2.00"),
     None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None, Decimal("2.00"),
     None, Decimal("2.00"), None, "2017-12-17", None, "2017-12-17", None, Decimal("0.84"), None,
     Decimal("1.71"), None, 1, None, 2, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("0.00"),
     None, 15, None, None, "201744"),
    ("B2A1", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None, Decimal("1.00"),
     None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"),
     None, Decimal("1.00"), None, None, None, None, None, None, None, Decimal("1.00"), None,
     Decimal("1.00"), None, "2017-12-12", None, "2017-12-12", None, Decimal("0.42"), None,
     Decimal("0.86"), None, 1, None, 1, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, 20,
     None, None, "201744"),
    ("C1A2", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None, Decimal("2.70"),
     None, Decimal("2.70"), None, Decimal("2.70"), None, Decimal("2.70"), None, Decimal("1.00"),
     None, None, None, None, None, None, None, None, None, Decimal("2.70"), None, Decimal("2.70"),
     None, "2017-12-15", None, "2017-12-15", None, Decimal("0.42"), None, Decimal("0.86"), None, 1,
     None, 0, False, True, None, Decimal("0.00"), None, Decimal("0.00"), None, Decimal("2.70"),
     None, Decimal("1.00"), None, Decimal("2.70"), None, None, None, 17, None, None, "201744"),
    ("D1B2", "All", "All", "All", None, 2, None, 1, None, Decimal("0.00"), None, Decimal("3.00"),
     None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("2.00"),
     None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None, Decimal("6.00"),
     None, Decimal("6.00"), None, "2017-12-16", None, "2017-12-16", None, Decimal("0.84"), None,
     Decimal("1.71"), None, 1, None, 2, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"), None, Decimal("0.00"),
     None, 16, None, None, "201744"),
    ("A2B1", "All", "All", "All", None, 2, None, 1, None, Decimal("1.34"), None, Decimal("1.00"),
     None, Decimal("1.00"), None, Decimal("0.67"), None, Decimal("0.67"), None, Decimal("4.00"),
     None, Decimal("4.00"), None, None, None, None, None, None, None, Decimal("4.00"), None,
     Decimal("2.66"), None, "2017-12-21", None, "2017-12-20", None, Decimal("1.13"), None,
     Decimal("1.81"), None, 1, None, 1, False, True, None, Decimal("0.67"), None, Decimal("33.50"),
     None, Decimal("1.00"), None, Decimal("2.00"), None, Decimal("1.33"), None, Decimal("1.00"),
     None, 11, None, Decimal("11.00"), "201744"),
    ("A2A2", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None, Decimal("0.39"),
     None, Decimal("0.39"), None, Decimal("0.39"), None, Decimal("0.39"), None, Decimal("1.00"),
     None, None, None, None, None, None, None, None, None, Decimal("0.39"), None, Decimal("0.39"),
     None, "2017-12-21", None, "2017-12-21", None, Decimal("0.56"), None, Decimal("0.90"), None, 1,
     None, 0, False, True, None, Decimal("0.00"), None, Decimal("0.00"), None, Decimal("0.39"),
     None, Decimal("1.00"), None, Decimal("0.39"), None, None, None, 11, None, None, "201744"),
    ("D1B1", "All", "All", "All", None, 2, None, 1, None, Decimal("0.00"), None, Decimal("0.50"),
     None, Decimal("0.50"), None, Decimal("0.50"), None, Decimal("0.50"), None, Decimal("4.00"),
     None, Decimal("2.00"), None, None, None, None, None, Decimal("2.00"), None, Decimal("2.00"),
     None, Decimal("2.00"), None, "2017-12-19", None, "2017-12-19", None, Decimal("1.13"), None,
     Decimal("1.81"), None, 1, None, 1, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("0.50"), None, Decimal("2.00"), None, Decimal("1.00"), None, Decimal("0.00"),
     None, 13, None, None, "201744"),
    ("D1A2", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None, Decimal("0.35"),
     None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("1.00"),
     None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None, Decimal("0.35"),
     None, Decimal("0.35"), None, "2017-12-22", None, "2017-12-22", None, Decimal("0.56"), None,
     Decimal("0.90"), None, 1, None, 1, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None, None, None, 10,
     None, None, "201744"),
    ("D2B2", "All", "All", "All", 1, 2, 1, 2, Decimal("0.00"), Decimal("0.00"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("0.35"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("0.35"), Decimal("1.00"), Decimal("2.00"), Decimal("1.00"),
     Decimal("2.00"), None, None, None, None, None, Decimal("1.00"), Decimal("2.30"),
     Decimal("2.65"), Decimal("2.30"), Decimal("2.65"), "2017-12-27", "2017-12-27", "2017-12-27",
     "2017-12-22", Decimal("0.75"), Decimal("1.31"), Decimal("0.95"), Decimal("1.85"), 1, 1, 1, 2,
     True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("2.30"), Decimal("1.33"), Decimal("1.00"), Decimal("1.00"), Decimal("2.30"),
     Decimal("1.33"), None, Decimal("5.00"), 5, 5, None, Decimal("1.00"), "201744"),
    ("UNKNOWN_DIMENSION", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-23", None, "2017-12-23", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, None, 1, False, True, None, Decimal("0.00"),
     None, Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"),
     None, None, None, 9, None, None, "201744"),
    ("A2A1", "All", "All", "All", 1, 1, 1, 1, Decimal("0.00"), Decimal("0.00"), Decimal("0.69"),
     Decimal("0.69"), Decimal("0.69"), Decimal("0.69"), Decimal("0.69"), Decimal("0.69"),
     Decimal("0.69"), Decimal("0.69"), Decimal("2.00"), Decimal("2.00"), None, None, None, None,
     None, None, None, None, Decimal("1.38"), Decimal("1.38"), Decimal("1.38"), Decimal("1.38"),
     "2017-12-28", "2017-12-28", "2017-12-28", "2017-12-28", Decimal("0.75"), Decimal("0.75"),
     Decimal("0.95"), Decimal("0.95"), 1, 1, 0, 0, True, True, Decimal("0.00"), Decimal("0.00"),
     Decimal("0.00"), Decimal("0.00"), Decimal("0.69"), Decimal("0.69"), Decimal("2.00"),
     Decimal("2.00"), Decimal("1.38"), Decimal("1.38"), None, None, 4, 4, None, None, "201744"),
    ("A1B1", "All", "All", "All", None, 4, None, 3, None, Decimal("0.60"), None, Decimal("1.80"),
     None, Decimal("0.30"), None, Decimal("1.50"), None, Decimal("0.30"), None, Decimal("7.00"),
     None, Decimal("5.00"), None, Decimal("2.00"), None, None, None, Decimal("2.00"), None,
     Decimal("6.53"), None, Decimal("5.93"), None, "2017-12-24", None, "2017-12-08", None,
     Decimal("1.86"), None, Decimal("3.48"), None, 2, None, 4, False, True, None, Decimal("0.15"),
     None, Decimal("9.19"), None, Decimal("0.93"), None, Decimal("1.75"), None, Decimal("1.48"),
     None, Decimal("5.33"), None, 8, None, Decimal("1.50"), "201744"),
    ("A1A1", "All", "All", "All", 2, 5, 1, 3, Decimal("0.00"), Decimal("0.00"), Decimal("2.10"),
     Decimal("20.00"), Decimal("2.10"), Decimal("1.24"), Decimal("2.10"), Decimal("20.00"),
     Decimal("2.10"), Decimal("1.24"), Decimal("2.00"), Decimal("5.00"), None, Decimal("2.00"),
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, Decimal("1.00"),
     Decimal("4.20"), Decimal("26.68"), Decimal("4.20"), Decimal("26.68"), "2017-12-30",
     "2017-12-30", "2017-12-30", "2017-12-09", Decimal("1.50"), Decimal("2.94"), Decimal("1.90"),
     Decimal("4.52"), 1, 2, 2, 3, True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("0.00"), Decimal("2.10"), Decimal("5.34"), Decimal("1.00"), Decimal("1.00"),
     Decimal("2.10"), Decimal("5.34"), Decimal("0.00"), Decimal("5.25"), 2, 2, None,
     Decimal("0.38"), "201744"),
    ("B1B1", "All", "All", "All", None, 2, None, 2, None, Decimal("0.00"), None, Decimal("10.00"),
     None, Decimal("1.60"), None, Decimal("10.00"), None, Decimal("1.60"), None, Decimal("3.00"),
     None, Decimal("1.00"), None, Decimal("2.00"), None, None, None, None, None, Decimal("13.20"),
     None, Decimal("13.20"), None, "2017-12-13", None, "2017-12-07", None, Decimal("0.74"), None,
     Decimal("1.67"), None, 1, None, 2, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("4.40"), None, Decimal("1.50"), None, Decimal("6.60"), None, Decimal("6.00"),
     None, 19, None, Decimal("3.17"), "201744"),
    ("B2B1", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None, Decimal("4.00"),
     None, Decimal("4.00"), None, Decimal("4.00"), None, Decimal("4.00"), None, Decimal("1.00"),
     None, Decimal("1.00"), None, None, None, None, None, None, None, Decimal("4.00"), None,
     Decimal("4.00"), None, "2017-12-05", None, "2017-12-05", None, Decimal("0.32"), None,
     Decimal("0.81"), None, 1, None, 1, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("4.00"), None, Decimal("1.00"), None, Decimal("4.00"), None, None, None, 27,
     None, None, "201744"),
    ("C1B2", "All", "All", "All", 1, 2, 1, 2, Decimal("0.00"), Decimal("0.00"), Decimal("63.84"),
     Decimal("63.84"), Decimal("63.84"), Decimal("47.93"), Decimal("63.84"), Decimal("63.84"),
     Decimal("63.84"), Decimal("47.93"), Decimal("1.00"), Decimal("2.00"), None, Decimal("1.00"),
     None, None, None, None, None, Decimal("1.00"), Decimal("63.84"), Decimal("111.77"),
     Decimal("63.84"), Decimal("111.77"), "2017-12-25", "2017-12-25", "2017-12-25", "2017-12-04",
     Decimal("0.75"), Decimal("1.07"), Decimal("0.95"), Decimal("1.76"), 1, 1, 0, 1, True, True,
     Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("63.84"),
     Decimal("55.89"), Decimal("1.00"), Decimal("1.00"), Decimal("63.84"), Decimal("55.89"), None,
     Decimal("21.00"), 7, 7, None, Decimal("0.33"), "201744"),
    ("C1A1", "All", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None, Decimal("0.10"),
     None, Decimal("0.10"), None, Decimal("0.10"), None, Decimal("0.10"), None, Decimal("1.00"),
     None, None, None, None, None, None, None, None, None, Decimal("0.10"), None, Decimal("0.10"),
     None, "2017-12-10", None, "2017-12-10", None, Decimal("0.32"), None, Decimal("0.81"), None, 1,
     None, 0, False, True, None, Decimal("0.00"), None, Decimal("0.00"), None, Decimal("0.10"),
     None, Decimal("1.00"), None, Decimal("0.10"), None, None, None, 22, None, None, "201744"),
    ("C2A1", "All", "All", "All", 2, 4, 1, 2, Decimal("0.00"), Decimal("0.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("0.99"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("0.99"), Decimal("2.00"), Decimal("4.00"), None, Decimal("1.00"),
     Decimal("2.00"), Decimal("2.00"), None, None, None, Decimal("1.00"), Decimal("18.00"),
     Decimal("19.98"), Decimal("18.00"), Decimal("19.98"), "2017-12-31", "2017-12-31", "2017-12-30",
     "2017-12-06", Decimal("1.50"), Decimal("2.13"), Decimal("1.90"), Decimal("3.53"), 1, 2, 1, 2,
     True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("9.00"), Decimal("5.00"), Decimal("1.00"), Decimal("1.00"), Decimal("9.00"),
     Decimal("5.00"), Decimal("1.00"), Decimal("8.33"), 1, 1, Decimal("1.00"), Decimal("0.12"),
     "201744"),
    ("C2B1", "All", "All", "All", None, 3, None, 1, None, Decimal("0.00"), None, Decimal("20.00"),
     None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("3.00"),
     None, Decimal("2.00"), None, None, None, None, None, Decimal("1.00"), None, Decimal("60.00"),
     None, Decimal("60.00"), None, "2017-12-09", None, "2017-12-09", None, Decimal("0.95"), None,
     Decimal("2.44"), None, 1, None, 2, False, True, None, Decimal("0.00"), None, Decimal("0.00"),
     None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"), None, Decimal("0.00"),
     None, 23, None, None, "201744"),
    ("D2B1", "All", "All", "All", None, 2, None, 2, None, Decimal("0.60"), None, Decimal("1.80"),
     None, Decimal("1.00"), None, Decimal("1.50"), None, Decimal("1.00"), None, Decimal("3.00"),
     None, Decimal("2.00"), None, None, None, None, None, None, None, Decimal("4.60"), None,
     Decimal("4.00"), None, "2017-12-12", None, "2017-12-08", None, Decimal("0.74"), None,
     Decimal("1.67"), None, 1, None, 1, False, True, None, Decimal("0.30"), None, Decimal("13.04"),
     None, Decimal("1.53"), None, Decimal("1.50"), None, Decimal("2.00"), None, Decimal("4.00"),
     None, 20, None, Decimal("5.00"), "201744"),
    ("D2A1", "All", "All", "All", 1, 4, 1, 3, Decimal("0.00"), Decimal("0.67"), Decimal("2.50"),
     Decimal("3.00"), Decimal("2.50"), Decimal("1.00"), Decimal("2.50"), Decimal("3.00"),
     Decimal("2.50"), Decimal("0.67"), Decimal("1.00"), Decimal("5.00"), None, Decimal("2.00"),
     None, Decimal("2.00"), None, None, None, Decimal("4.00"), Decimal("2.50"), Decimal("10.50"),
     Decimal("2.50"), Decimal("9.83"), "2017-12-26", "2017-12-26", "2017-12-26", "2017-12-09",
     Decimal("0.75"), Decimal("2.19"), Decimal("0.95"), Decimal("3.57"), 1, 2, 0, 2, True, True,
     Decimal("0.00"), Decimal("0.17"), Decimal("0.00"), Decimal("6.38"), Decimal("2.50"),
     Decimal("2.10"), Decimal("1.00"), Decimal("1.25"), Decimal("2.50"), Decimal("2.46"), None,
     Decimal("5.67"), 6, 6, None, Decimal("1.06"), "201744"),
]

"""
Merge - subgroup_customer_all_all
"""
subgroup_customer_all_all_schema = pt.StructType([
    pt.StructField("subgroup", pt.StringType(), True),
    pt.StructField("customer", pt.StringType(), True),
    pt.StructField("store", pt.StringType(), True),
    pt.StructField("channel", pt.StringType(), True),
    pt.StructField("baskets_1w1w", pt.LongType(), True),
    pt.StructField("baskets_1w4w", pt.LongType(), True),
    pt.StructField("basketweeks_1w1w", pt.IntegerType(), True),
    pt.StructField("basketweeks_1w4w", pt.IntegerType(), True),
    pt.StructField("discount_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discount_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("maximumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("minimumnetprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantity_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantity_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore1_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore2_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityprefstore3_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w1w", pt.DecimalType(24, 2), True),
    pt.StructField("quantityfulfillmentstore_1w4w", pt.DecimalType(24, 2), True),
    pt.StructField("grossspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("grossspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspend_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("maxpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("maxpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w1w", pt.StringType(), True),
    pt.StructField("minpurchasedate_1w4w", pt.StringType(), True),
    pt.StructField("recencyweightedbasketweeks75_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks75_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("recencyweightedbasketweeks95_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("productcount_1w1w", pt.LongType(), True),
    pt.StructField("productcount_1w4w", pt.LongType(), True),
    pt.StructField("basketsflag_1w1w", pt.BooleanType(), True),
    pt.StructField("basketsflag_1w4w", pt.BooleanType(), True),
    pt.StructField("discountperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("discountpercent_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averageprice_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("quantityperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("netspendperbasket_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w1w", pt.DecimalType(38, 2), True),
    pt.StructField("averagepurchasecycle_1w4w", pt.DecimalType(38, 2), True),
    pt.StructField("recencydays_1w1w", pt.IntegerType(), True),
    pt.StructField("recencydays_1w4w", pt.IntegerType(), True),
    pt.StructField("cyclessincelastpurchase_1w1w", pt.DecimalType(6, 2), True),
    pt.StructField("cyclessincelastpurchase_1w4w", pt.DecimalType(6, 2), True),
    pt.StructField("cadence_week", pt.StringType(), True),
])
subgroup_customer_all_all_lst = [
    ("D1B2", "Customer15", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None,
     Decimal("1.00"), None, None, None, None, None, None, None, None, None, Decimal("3.00"), None,
     Decimal("3.00"), None, "2017-12-16", None, "2017-12-16", None, Decimal("0.42"), None,
     Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None, Decimal("0.00"), None,
     Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"), None, None, None, 16, None,
     None, "201744"),
    ("A1A1", "Customer16", "All", "All", 1, 2, 1, 2, Decimal("0.00"), Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.24"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("1.24"), Decimal("1.00"), Decimal("2.00"), None,
     Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), None, None, None, Decimal("1.00"),
     Decimal("2.10"), Decimal("3.34"), Decimal("2.10"), Decimal("3.34"), "2017-12-30", "2017-12-30",
     "2017-12-30", "2017-12-18", Decimal("0.75"), Decimal("1.31"), Decimal("0.95"), Decimal("1.85"),
     1, 2, True, True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"),
     Decimal("2.10"), Decimal("1.67"), Decimal("1.00"), Decimal("1.00"), Decimal("2.10"),
     Decimal("1.67"), None, Decimal("12.00"), 2, 2, None, Decimal("0.17"), "201744"),
    ("A1B1", "Customer13", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-22", None, "2017-12-22", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None,
     None, None, 10, None, None, "201744"),
    ("A1B1", "Customer11", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.99"), None, Decimal("0.99"), None, Decimal("0.99"), None, Decimal("0.99"), None,
     Decimal("2.00"), None, None, None, Decimal("2.00"), None, None, None, None, None,
     Decimal("1.98"), None, Decimal("1.98"), None, "2017-12-24", None, "2017-12-24", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.99"), None, Decimal("2.00"), None, Decimal("1.98"), None,
     None, None, 8, None, None, "201744"),
    ("A2B1", "Customer1", "All", "All", None, 2, None, 1, None, Decimal("1.34"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("0.67"), None, Decimal("0.67"), None,
     Decimal("4.00"), None, Decimal("4.00"), None, None, None, None, None, None, None,
     Decimal("4.00"), None, Decimal("2.66"), None, "2017-12-21", None, "2017-12-20", None,
     Decimal("1.13"), None, Decimal("1.81"), None, 1, False, True, None, Decimal("0.67"), None,
     Decimal("33.50"), None, Decimal("1.00"), None, Decimal("2.00"), None, Decimal("1.33"), None,
     Decimal("1.00"), None, 11, None, Decimal("11.00"), "201744"),
    ("D1B1", "Customer14", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.50"), None, Decimal("0.50"), None, Decimal("0.50"), None, Decimal("0.50"), None,
     Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None, Decimal("2.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-19", None, "2017-12-19", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.50"), None, Decimal("2.00"), None, Decimal("1.00"), None,
     None, None, 13, None, None, "201744"),
    ("D1A2", "Customer18", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-22", None, "2017-12-22", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None,
     None, None, 10, None, None, "201744"),
    ("D2A1", "Customer1", "All", "All", None, 1, None, 1, None, Decimal("0.67"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("0.67"), None, Decimal("0.67"), None,
     Decimal("2.00"), None, None, None, Decimal("2.00"), None, None, None, Decimal("2.00"), None,
     Decimal("2.00"), None, Decimal("1.33"), None, "2017-12-22", None, "2017-12-22", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, False, True, None, Decimal("0.67"), None,
     Decimal("33.50"), None, Decimal("1.00"), None, Decimal("2.00"), None, Decimal("1.33"), None,
     None, None, 10, None, None, "201744"),
    ("D2B2", "Customer12", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-22", None, "2017-12-22", None,
     Decimal("0.56"), None, Decimal("0.90"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None,
     None, None, 10, None, None, "201744"),
    ("DEFAULT_HIERARCHY", "Customer13", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None, Decimal("0.35"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("0.35"), None, Decimal("0.35"), None, "2017-12-23", None, "2017-12-23", None,
     Decimal("0.56"), None, Decimal("0.90"), None, None, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.35"), None, Decimal("1.00"), None, Decimal("0.35"), None,
     None, None, 9, None, None, "201744"),
    ("A1A1", "Customer11", "All", "All", 1, 1, 1, 1, Decimal("0.00"), Decimal("0.00"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), Decimal("1.00"), Decimal("1.00"), None,
     None, None, None, Decimal("1.00"), Decimal("1.00"), None, None, Decimal("2.10"),
     Decimal("2.10"), Decimal("2.10"), Decimal("2.10"), "2017-12-30", "2017-12-30", "2017-12-30",
     "2017-12-30", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"), 1, 1, True,
     True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("2.10"),
     Decimal("2.10"), Decimal("1.00"), Decimal("1.00"), Decimal("2.10"), Decimal("2.10"), None,
     None, 2, 2, None, None, "201744"),
    ("B1A1", "Customer3", "All", "All", 1, 1, 1, 1, Decimal("1.40"), Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("7.00"), Decimal("7.00"), Decimal("5.60"),
     Decimal("5.60"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), None, None, None, None, Decimal("1.00"), Decimal("1.00"),
     Decimal("7.00"), Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), "2017-12-29", "2017-12-29",
     "2017-12-29", "2017-12-29", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"),
     1, 1, True, True, Decimal("1.40"), Decimal("1.40"), Decimal("20.00"), Decimal("20.00"),
     Decimal("7.00"), Decimal("7.00"), Decimal("1.00"), Decimal("1.00"), Decimal("5.60"),
     Decimal("5.60"), None, None, 3, 3, None, None, "201744"),
    ("B1A1", "Customer18", "All", "All", 1, 1, 1, 1, Decimal("1.40"), Decimal("1.40"),
     Decimal("7.00"), Decimal("7.00"), Decimal("7.00"), Decimal("7.00"), Decimal("5.60"),
     Decimal("5.60"), Decimal("5.60"), Decimal("5.60"), Decimal("1.00"), Decimal("1.00"), None,
     None, Decimal("1.00"), Decimal("1.00"), None, None, None, None, Decimal("7.00"),
     Decimal("7.00"), Decimal("5.60"), Decimal("5.60"), "2017-12-29", "2017-12-29", "2017-12-29",
     "2017-12-29", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"), 1, 1, True,
     True, Decimal("1.40"), Decimal("1.40"), Decimal("20.00"), Decimal("20.00"), Decimal("7.00"),
     Decimal("7.00"), Decimal("1.00"), Decimal("1.00"), Decimal("5.60"), Decimal("5.60"), None,
     None, 3, 3, None, None, "201744"),
    ("C2A1", "Customer12", "All", "All", 2, 2, 1, 1, Decimal("0.00"), Decimal("0.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("9.00"), Decimal("9.00"), Decimal("2.00"), Decimal("2.00"), None,
     None, Decimal("2.00"), Decimal("2.00"), None, None, None, None, Decimal("18.00"),
     Decimal("18.00"), Decimal("18.00"), Decimal("18.00"), "2017-12-31", "2017-12-31", "2017-12-30",
     "2017-12-30", Decimal("1.50"), Decimal("1.50"), Decimal("1.90"), Decimal("1.90"), 1, 1, True,
     True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("9.00"),
     Decimal("9.00"), Decimal("1.00"), Decimal("1.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("1.00"), Decimal("1.00"), 1, 1, Decimal("1.00"), Decimal("1.00"), "201744"),
    ("D2B2", "Customer19", "All", "All", 1, 1, 1, 1, Decimal("0.00"), Decimal("0.00"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), Decimal("1.00"), Decimal("1.00"),
     Decimal("1.00"), Decimal("1.00"), None, None, None, None, None, None, Decimal("2.30"),
     Decimal("2.30"), Decimal("2.30"), Decimal("2.30"), "2017-12-27", "2017-12-27", "2017-12-27",
     "2017-12-27", Decimal("0.75"), Decimal("0.75"), Decimal("0.95"), Decimal("0.95"), 1, 1, True,
     True, Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("0.00"), Decimal("2.30"),
     Decimal("2.30"), Decimal("1.00"), Decimal("1.00"), Decimal("2.30"), Decimal("2.30"), None,
     None, 5, 5, None, None, "201744"),
    ("A1B1", "Customer5", "All", "All", None, 1, None, 1, None, Decimal("0.60"), None,
     Decimal("1.80"), None, Decimal("1.80"), None, Decimal("1.50"), None, Decimal("1.50"), None,
     Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None, None, None,
     Decimal("3.60"), None, Decimal("3.00"), None, "2017-12-08", None, "2017-12-08", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.60"), None,
     Decimal("16.67"), None, Decimal("1.80"), None, Decimal("2.00"), None, Decimal("3.00"), None,
     None, None, 24, None, None, "201744"),
    ("A1A1", "Customer7", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("20.00"), None, Decimal("20.00"), None, "2017-12-09", None, "2017-12-09", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"), None,
     None, None, 23, None, None, "201744"),
    ("B1B1", "Customer20", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("10.00"), None, Decimal("10.00"), None, Decimal("10.00"), None, Decimal("10.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("10.00"), None, Decimal("10.00"), None, "2017-12-07", None, "2017-12-07", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("10.00"), None, Decimal("1.00"), None, Decimal("10.00"), None,
     None, None, 25, None, None, "201744"),
    ("B2B1", "Customer8", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("4.00"), None, Decimal("4.00"), None, Decimal("4.00"), None, Decimal("4.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("4.00"), None, Decimal("4.00"), None, "2017-12-05", None, "2017-12-05", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("4.00"), None, Decimal("1.00"), None, Decimal("4.00"), None,
     None, None, 27, None, None, "201744"),
    ("C1B2", "Customer14", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("47.93"), None, Decimal("47.93"), None, Decimal("47.93"), None, Decimal("47.93"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("47.93"), None, Decimal("47.93"), None, "2017-12-04", None, "2017-12-04", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("47.93"), None, Decimal("1.00"), None, Decimal("47.93"), None,
     None, None, 28, None, None, "201744"),
    ("C1B1", "Customer20", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("10.00"), None, Decimal("10.00"), None, Decimal("10.00"), None, Decimal("10.00"), None,
     Decimal("1.00"), None, None, None, Decimal("1.00"), None, None, None, None, None,
     Decimal("10.00"), None, Decimal("10.00"), None, "2017-12-07", None, "2017-12-07", None,
     Decimal("0.32"), None, Decimal("0.81"), None, None, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("10.00"), None, Decimal("1.00"), None, Decimal("10.00"), None,
     None, None, 25, None, None, "201744"),
    ("C2A1", "Customer18", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.99"), None, Decimal("0.99"), None, Decimal("0.99"), None, Decimal("0.99"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("0.99"), None, Decimal("0.99"), None, "2017-12-06", None, "2017-12-06", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.99"), None, Decimal("1.00"), None, Decimal("0.99"), None,
     None, None, 26, None, None, "201744"),
    ("C2B1", "Customer4", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("20.00"), None, Decimal("20.00"), None, "2017-12-09", None, "2017-12-09", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"), None,
     None, None, 23, None, None, "201744"),
    ("C2B1", "Customer11", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None, Decimal("20.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("20.00"), None, Decimal("20.00"), None, "2017-12-09", None, "2017-12-09", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("20.00"), None, Decimal("1.00"), None, Decimal("20.00"), None,
     None, None, 23, None, None, "201744"),
    ("D2B1", "Customer5", "All", "All", None, 1, None, 1, None, Decimal("0.60"), None,
     Decimal("1.80"), None, Decimal("1.80"), None, Decimal("1.50"), None, Decimal("1.50"), None,
     Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None, None, None,
     Decimal("3.60"), None, Decimal("3.00"), None, "2017-12-08", None, "2017-12-08", None,
     Decimal("0.32"), None, Decimal("0.81"), None, 1, False, True, None, Decimal("0.60"), None,
     Decimal("16.67"), None, Decimal("1.80"), None, Decimal("2.00"), None, Decimal("3.00"), None,
     None, None, 24, None, None, "201744"),
    ("D2A1", "Customer6", "All", "All", None, 2, None, 2, None, Decimal("0.00"), None,
     Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None,
     Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None, Decimal("2.00"), None,
     Decimal("6.00"), None, Decimal("6.00"), None, "2017-12-23", None, "2017-12-09", None,
     Decimal("0.88"), None, Decimal("1.72"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"), None,
     Decimal("14.00"), None, 9, None, Decimal("0.64"), "201744"),
    ("A1B1", "Customer9", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("0.30"), None, Decimal("0.30"), None, Decimal("0.30"), None, Decimal("0.30"), None,
     Decimal("2.00"), None, Decimal("2.00"), None, None, None, None, None, Decimal("2.00"), None,
     Decimal("0.60"), None, Decimal("0.60"), None, "2017-12-14", None, "2017-12-14", None,
     Decimal("0.42"), None, Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("0.30"), None, Decimal("2.00"), None, Decimal("0.60"), None,
     None, None, 18, None, None, "201744"),
    ("B1B1", "Customer13", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("1.60"), None, Decimal("1.60"), None, Decimal("1.60"), None, Decimal("1.60"), None,
     Decimal("2.00"), None, None, None, Decimal("2.00"), None, None, None, None, None,
     Decimal("3.20"), None, Decimal("3.20"), None, "2017-12-13", None, "2017-12-13", None,
     Decimal("0.42"), None, Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("1.60"), None, Decimal("2.00"), None, Decimal("3.20"), None,
     None, None, 19, None, None, "201744"),
    ("B1B2", "Customer15", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     Decimal("1.00"), None, None, None, None, None, None, None, None, None, Decimal("1.00"), None,
     Decimal("1.00"), None, "2017-12-17", None, "2017-12-17", None, Decimal("0.42"), None,
     Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None, Decimal("0.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, None, None, 15, None,
     None, "201744"),
    ("B1B2", "Customer10", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-17", None, "2017-12-17", None,
     Decimal("0.42"), None, Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     None, None, 15, None, None, "201744"),
    ("B2A1", "Customer17", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, None, None,
     Decimal("1.00"), None, Decimal("1.00"), None, "2017-12-12", None, "2017-12-12", None,
     Decimal("0.42"), None, Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("1.00"), None, Decimal("1.00"), None, Decimal("1.00"), None,
     None, None, 20, None, None, "201744"),
    ("D1B2", "Customer10", "All", "All", None, 1, None, 1, None, Decimal("0.00"), None,
     Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None, Decimal("3.00"), None,
     Decimal("1.00"), None, Decimal("1.00"), None, None, None, None, None, Decimal("1.00"), None,
     Decimal("3.00"), None, Decimal("3.00"), None, "2017-12-16", None, "2017-12-16", None,
     Decimal("0.42"), None, Decimal("0.86"), None, 1, False, True, None, Decimal("0.00"), None,
     Decimal("0.00"), None, Decimal("3.00"), None, Decimal("1.00"), None, Decimal("3.00"), None,
     None, None, 16, None, None, "201744"),
]

"""
Stub class implementation for Transactions & Purchases - used in unit test cases
"""


class Transactions(TransactionsBase):
    """
    Transactions entity stub implementation
    """

    def __init__(self):
        """
        Define the Transactions schema and column or columns that uniquely define a Transaction
        """
        super(Transactions, self).__init__()

        self.get_data()
        self.get_most_recent_transaction_date()

    @property
    def database(self):
        return 'client_media_mart'


class Purchases(PurchasesBase):
    """
    Purchases entity stub implementation
    """

    def __init__(self, config):
        """
        Constructor of Purchases entity
        :param config: config info from config.json
        """
        self.config = config
        super(Purchases, self).__init__(config=config)
        self.get_data()


class PurchasingFeatureGenerator(PurchasingFeatureGeneratorBase):
    """
    Purchasing feature generator stub implementation - used in test cases
    """

    def __init__(self, config, cadence_attribute, run_date):
        super(PurchasingFeatureGenerator, self).__init__(config=config,
                                                         cadence_attribute=cadence_attribute,
                                                         run_date=run_date)
        self._refresh_denorm = False
        self._refresh_summary = False
        self.features_specifications = [
            {
                "name": "All_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "All",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                                               "BasketsDecay1w13wvs1w52w"],
                "distinct_features": [item + "Count" for item in self._product_hierarchy] +
                                     ["CustomerCount"]
            },
            {
                "name": "Product_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Product",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                                               "BasketsDecay1w13wvs1w52w"],
                "distinct_features": None
            },
            {
                "name": "Subgroup_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Subgroup",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                                               "BasketsDecay1w13wvs1w52w"],
                "distinct_features": [item + "Count"
                                      for item in self._product_hierarchy
                                      [self._product_hierarchy.index("Subgroup") + 1:]] +
                                     ["CustomerCount"]
            },
            {
                "name": "Subgroup_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Subgroup",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice",
                                  "MinimumPrice", "MaximumNetPrice", "MinimumNetPrice", "Quantity",
                                  "QuantityPrefStore1", "QuantityPrefStore2", "QuantityPrefStore3",
                                  "QuantityFulfillmentStore", "GrossSpend", "NetSpend",
                                  "MaxPurchaseDate", "MinPurchaseDate",
                                  "RecencyWeightedBasketWeeks75", "RecencyWeightedBasketWeeks95"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent",
                                     "AveragePrice", "QuantityPerBasket", "NetSpendPerBasket",
                                     "AveragePurchaseCycle", "RecencyDays",
                                     "CyclesSinceLastPurchase"],
                "dependent_derived_features": ["BasketsDecay1w13wvs1w26w",
                                               "BasketsDecay1w13wvs1w52w"],
                "distinct_features": [item + "Count"
                                      for item in self._product_hierarchy
                                      [self._product_hierarchy.index("Subgroup") + 1:]]
            },
            {
                "name": deepcopy(self.config["SSEFeatureDistinctTab"]),
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4), (1, 13), (1, 26), (1, 52)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    # These should be list of attribute, please don't mention all instead use empty
                    # list in place of all
                    "ProductAttribute": deepcopy(self._product_hierarchy),
                    "CustomerAttribute": ["Customer"],
                    "StoreAttribute": [],
                    "ChannelAttribute": []
                },
                "base_features": [],
                "derived_features": [],
                "dependent_derived_features": [],
                "distinct_features": None
            },
        ]

    @property
    def purchases(self):
        """
        Return Purchases entity object, should be used for only accessing/deleting metadata info,
        if used for data access they will result in full scan of object/fact table
        :return: purchases: test.dunnhumby.cmp_features.purchasing_feature_generator_base.\
        sample_data_set.Purchases
        """
        if self._purchases is None:
            self._purchases = Purchases(config=self.config)
        return self._purchases

    @property
    def transactions(self):
        """
        Return Transactions entity object, should be used for only accessing metadata info and
        reading single partitions only else will result in full scan of object/fact table
        :return: transactions: test.dunnhumby.cmp_features.purchasing_feature_generator_base.\
        sample_data_set.Transactions
        """
        if self._transactions is None:
            self._transactions = Transactions()
        return self._transactions

    @property
    def customers_df(self):
        """
        Return Customers entity's data (only required columns) as spark dataframe
        :return: customers_df: Dataframe
        """
        if self._customer_df is None:
            self._customer_df = sqlContext.createDataFrame(customer_lst, customer_schema). \
                select("Customer", "FulfillmentStore", "PreferredStore1", "PreferredStore2", "PreferredStore3")
        return self._customer_df

    @customers_df.setter
    def customers_df(self, customers_df):
        """
        Accommodate any changes in customer_df, doesn't do any kind check before assigning
        :param customers_df: dataframe containing information about customer entity
        :return: None
        """
        self._customer_df = customers_df

    @property
    def products_df(self):
        """
        Return Products entity's data (only required columns) as spark dataframe
        :return: products_df: Dataframe
        """
        if self._products_df is None:
            self._products_df = sqlContext.createDataFrame(product_lst, product_schema). \
                select(["prod_id"] + self._product_hierarchy)
        return self._products_df

    @products_df.setter
    def products_df(self, products_df):
        """
        Accommodate any changes in products_df, doesn't do any kind check before assigning
        :param products_df: dataframe containing information about product entity
        :return: None
        """
        self._products_df = products_df

    @property
    def stores_df(self):
        """
        Return Stores entity's data (only required columns) as spark dataframe
        :return: stores_df: Dataframe
        """
        if self._stores_df is None:
            stores_df = sqlContext.createDataFrame(store_lst, store_schema). \
                select("store_id", "Store", "Banner")
            self._stores_df = stores_df
        return self._stores_df

    @stores_df.setter
    def stores_df(self, stores_df):
        """
        Accommodate any changes in stores_df, doesn't do any kind check before assigning
        :param stores_df: dataframe containing information about store entity
        :return: None
        """

        self._stores_df = stores_df


    @property
    def dates_df(self):
        """
        Return Dates entity's data as spark dataframe
        :return: dates_df: Dataframe
        """
        if self._dates_df is None:
            self._dates_df = sqlContext.createDataFrame(date_lst, date_schema)
        return self._dates_df


class PurchasingFeatureGeneratorSupplementary(PurchasingFeatureGeneratorBase):
    """
    Purchasing feature generator stub implementation - used in test cases
    One of the feature requires supplementary/extra dim attributes
    """

    def __init__(self, config, cadence_attribute, run_date):
        super(PurchasingFeatureGeneratorSupplementary, self).__init__(config=config,
                                                                      cadence_attribute=
                                                                      cadence_attribute,
                                                                      run_date=run_date)
        self._refresh_denorm = False
        self._refresh_summary = False
        self.features_specifications = [
            {
                "name": "Product_Customer_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "Product",
                    "CustomerAttribute": "Customer",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "dimension_attribute_null_filter": ["Product", "Customer"],
                "base_features": ["Baskets", "BasketWeeks"],
                "derived_features": None,
                "dependent_derived_features": None,
                "distinct_features": None,
                "additional_dimension_attribute": [
                    {
                        "dimension": "Product",
                        "attribute": ["Division", "Section", "Group", "Subgroup"],
                        "join_key": ["Product"]
                    }
                ]
            }
        ]

    @property
    def purchases(self):
        """
        Return Purchases entity object, should be used for only accessing/deleting metadata info,
        if used for data access they will result in full scan of object/fact table
        :return: purchases: test.dunnhumby.cmp_features.purchasing_feature_generator_base.\
        sample_data_set.Purchases
        """
        if self._purchases is None:
            self._purchases = Purchases(config=self.config)
        return self._purchases

    @property
    def transactions(self):
        """
        Return Transactions entity object, should be used for only accessing metadata info and
        reading single partitions only else will result in full scan of object/fact table
        :return: transactions: test.dunnhumby.cmp_features.purchasing_feature_generator_base.\
        sample_data_set.Transactions
        """
        if self._transactions is None:
            self._transactions = Transactions()
        return self._transactions

    @property
    def customers_df(self):
        """
        Return Customers entity's data (only required columns) as spark dataframe
        :return: customers_df: Dataframe
        """
        if self._customer_df is None:
            self._customer_df = sqlContext.createDataFrame(customer_lst, customer_schema). \
                select("Customer", "FulfillmentStore", "PreferredStore1",
                       "PreferredStore2", "PreferredStore3")
        return self._customer_df

    @customers_df.setter
    def customers_df(self, customers_df):
        """
        Accommodate any changes in customer_df, doesn't do any kind check before assigning
        :param customers_df: dataframe containing information about customer entity
        :return: None
        """
        self._customer_df = customers_df

    @property
    def products_df(self):
        """
        Return Products entity's data (only required columns) as spark dataframe
        :return: products_df: Dataframe
        """
        if self._products_df is None:
            self._products_df = sqlContext.createDataFrame(product_lst, product_schema). \
                select(self._product_hierarchy)
        return self._products_df

    @products_df.setter
    def products_df(self, products_df):
        """
        Accommodate any changes in products_df, doesn't do any kind check before assigning
        :param products_df: dataframe containing information about product entity
        :return: None
        """
        self._products_df = products_df

    @property
    def stores_df(self):
        """
        Return Stores entity's data (only required columns) as spark dataframe
        :return: stores_df: Dataframe
        """
        if self._stores_df is None:
            stores_df = sqlContext.createDataFrame(store_lst, store_schema). \
                select("Store", "Banner")
            self._stores_df = stores_df
        return self._stores_df

    @stores_df.setter
    def stores_df(self, stores_df):
        """
        Accommodate any changes in stores_df, doesn't do any kind check before assigning
        :param stores_df: dataframe containing information about store entity
        :return: None
        """

        self._stores_df = stores_df


    @property
    def dates_df(self):
        """
        Return Dates entity's data as spark dataframe
        :return: dates_df: Dataframe
        """
        if self._dates_df is None:
            dates_df = self.transactions.data.select('date_id', 'fis_week_id', 'fis_year_id').drop_duplicates()
            dayofweek = pf.udf(lambda date: datetime.datetime.weekday(date) + 1)
            dates_df = dates_df.withColumn('fis_day_of_week_num', dayofweek('date_id'))
            ## Caching dates_df here to avoid repeated computation over transactions
            dates_df.cache()
            self._dates_df = dates_df
        return self._dates_df

    def register_supplementary_tables(self):
        """
        Client implementation to register supplementary table required to derive extra dimension
        attribute or any other supplementary column/information.
        :return: (True/False, tab_lst): (boolean, list() of supplementary table)
        """
        work_db = self.config["SSEHiveWorkdb"]
        tab_lst = []
        products_df = sqlContext.createDataFrame(product_lst, product_schema).select(self.config["SSEProductHierarchy"])
        products_df = products_df.select(["Division", "Section", "Group", "Subgroup", "Product"])
        temp_table = work_db + "." + "Product_dim_tab"
        self.sqlContext.sql("DROP TABLE IF EXISTS " + temp_table)
        products_df.repartition(1).write.saveAsTable(temp_table, format="parquet", mode="overwrite")
        tab_lst.append("Product_dim_tab")
        db_tab_lst = [item.name.lower() for item in self.sqlContext.catalog.listTables(dbName=work_db) if
                      item.tableType == "MANAGED"]
        return all([True for item in tab_lst if item.lower() in db_tab_lst]), tab_lst

    def delete_supplementary_tables(self, tab_lst):
        """
        Client implementation to delete supplementary tables required to derive extra dimension
        attribute or any other supplementary column/information.
        :param tab_lst: list() of supplementary table
        :return: True/False: boolean
        """
        work_db = self.config["SSEHiveWorkdb"]
        for tab in tab_lst:
            self.sqlContext.sql("DROP TABLE IF EXISTS " + work_db + "." + tab)
        return True


class PurchasingFeatureGeneratorDefective(PurchasingFeatureGeneratorBase):
    """
    Purchasing feature generator defective stub implementation without features_specifications
    """

    def __init__(self, config, cadence_attribute, run_date):
        super(PurchasingFeatureGeneratorDefective, self).__init__(config=config,
                                                                  cadence_attribute=
                                                                  cadence_attribute,
                                                                  run_date=run_date)

    @property
    def purchases(self):
        """
        Return Purchases entity object, should be used for only accessing/deleting metadata info,
        if used for data access they will result in full scan of object/fact table
        :return: purchases: None
        """
        return None

    @property
    def transactions(self):
        """
        Return Transactions entity object, should be used for only accessing metadata info and
        reading single partitions only else will result in full scan of object/fact table
        :return: transactions: test.dunnhumby.cmp_features.purchasing_feature_generator_base.\
        sample_data_set.Transactions
        """
        if self._transactions is None:
            self._transactions = Transactions()
        return self._transactions

    @property
    def customers_df(self):
        """
        Return Customers entity's data (only required columns) as spark dataframe
        :return: customers_df: Dataframe
        """
        return None

    @property
    def products_df(self):
        """
        Return Products entity's data (only required columns) as spark dataframe
        :return: products_df: Dataframe
        """
        return None

    @property
    def stores_df(self):
        """
        Return Stores entity's data (only required columns) as spark dataframe
        :return: stores_df: Dataframe
        """
        return None

    @property
    def channels_df(self):
        """
        Return Channels entity's data (only required columns) as spark dataframe
        :return: channels_df: Dataframe
        """
        return None

    @property
    def dates_df(self):
        """
        Return Dates entity's data as spark dataframe
        :return: dates_df: Dataframe
        """
        if self._dates_df is None:
            dates_df = self.transactions.data.select('date_id', 'fis_week_id', 'fis_year_id').drop_duplicates()
            dayofweek = pf.udf(lambda date: datetime.datetime.weekday(date) + 1)
            dates_df = dates_df.withColumn('fis_day_of_week_num', dayofweek('date_id'))
            ## Caching dates_df here to avoid repeated computation over transactions
            dates_df.cache()
            self._dates_df = dates_df
        return self._dates_df
