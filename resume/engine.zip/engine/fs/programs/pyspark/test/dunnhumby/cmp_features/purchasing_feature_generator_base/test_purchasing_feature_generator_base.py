"""
Purchasing feature generator base class - Unit test cases
"""


import unittest
import time
import re
from random import choice
from itertools import groupby
from copy import deepcopy
from datetime import datetime as dt
from test.dunnhumby.cmp_features.purchasing_feature_generator_base.sample_data_set import \
    test_config, setup_sql, result_set, trans_lst, trans_schema, purchases_lst, purchases_schema, \
    all_all_all_all_summary_lst, all_all_all_all_summary_schema, \
    product_customer_all_all_summary_lst, product_customer_all_all_summary_schema, \
    subgroup_all_all_all_summary_lst, subgroup_all_all_all_summary_schema, \
    subgroup_customer_all_all_summary_lst, subgroup_customer_all_all_summary_schema, \
    feature_distinct_tab_summary_lst, feature_distinct_tab_summary_schema, \
    all_all_all_all_1w1w_lst, all_all_all_all_1w1w_schema, all_all_all_all_1w4w_lst, \
    all_all_all_all_1w4w_schema, product_customer_all_all_1w1w_lst, \
    product_customer_all_all_1w1w_schema, product_customer_all_all_1w4w_lst, \
    product_customer_all_all_1w4w_schema, subgroup_all_all_all_1w1w_lst, \
    subgroup_all_all_all_1w1w_schema, subgroup_all_all_all_1w4w_lst, \
    subgroup_all_all_all_1w4w_schema, subgroup_customer_all_all_1w1w_lst, \
    subgroup_customer_all_all_1w1w_schema, subgroup_customer_all_all_1w4w_lst, \
    subgroup_customer_all_all_1w4w_schema, feature_distinct_tab_1w1w_schema, \
    feature_distinct_tab_1w1w_lst, feature_distinct_tab_1w4w_schema, \
    feature_distinct_tab_1w4w_lst, all_all_all_all_lst, all_all_all_all_schema, \
    product_customer_all_all_lst, product_customer_all_all_schema, subgroup_all_all_all_lst, \
    subgroup_all_all_all_schema, subgroup_customer_all_all_lst, subgroup_customer_all_all_schema, \
    PurchasingFeatureGeneratorDefective, PurchasingFeatureGenerator, \
    PurchasingFeatureGeneratorSupplementary, product_customer_all_all_1w1w_schema_supplementary, \
    product_customer_all_all_1w1w_lst_supplementary, \
    product_customer_all_all_1w4w_schema_supplementary, \
    product_customer_all_all_1w4w_lst_supplementary
from dunnhumby import contexts
from dunnhumby.cmp_features.purchasing_feature_generator_base import PurchasingFeatureGeneratorBase
from dunnhumby.cmp_features.purchasing_feature_util import Denormalization_res_tuple, \
    Statement_tuple, Exec_res_tuple, Summary_info_tuple, Aggregate_info_tuple, Merge_info_tuple, \
    View_info_tuple
from pyspark.sql import types as pt
import mock

import logging

logger = logging.getLogger(__name__)


class TestPurchasingFeatureGeneratorBase(unittest.TestCase):
    """
    Unit test cases for class PurchasingFeatureGeneratorBase
    """

    @classmethod
    def setUpClass(cls):
        cls.run_date = dt.strptime("2018-01-02", "%Y-%m-%d").date()
        # Set required hive & spark config and create databases & tables
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("hive.exec.dynamic.partition", "true")
        cls.sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
        cls.sqlContext.conf.set("spark.sql.parquet.compression.codec", "gzip")
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")
        cls.sqlContext.sql(setup_sql["drop_db_media_mart"])
        cls.sqlContext.sql(setup_sql["drop_db_ssework"])
        cls.sqlContext.sql(setup_sql["drop_db_pob"])
        cls.sqlContext.sql(setup_sql["create_db_media_mart"])
        cls.sqlContext.sql(setup_sql["create_db_ssework"])
        cls.sqlContext.sql(setup_sql["create_db_pob"])
        # Create temp tables
        cls.sqlContext.createDataFrame(trans_lst, trans_schema). \
            write.saveAsTable("client_ssework.temp_trans")
        cls.sqlContext.createDataFrame(purchases_lst, purchases_schema). \
            write.saveAsTable("client_ssework.temp_purchase")
        cls.sqlContext.createDataFrame(all_all_all_all_summary_lst,
                                       all_all_all_all_summary_schema). \
            write.saveAsTable("client_ssework.temp_all_all_all_all_summary")
        cls.sqlContext.createDataFrame(product_customer_all_all_summary_lst,
                                       product_customer_all_all_summary_schema). \
            write.saveAsTable("client_ssework.temp_product_customer_all_all_summary")
        cls.sqlContext.createDataFrame(subgroup_all_all_all_summary_lst,
                                       subgroup_all_all_all_summary_schema). \
            write.saveAsTable("client_ssework.temp_subgroup_all_all_all_summary")
        cls.sqlContext.createDataFrame(subgroup_customer_all_all_summary_lst,
                                       subgroup_customer_all_all_summary_schema). \
            write.saveAsTable("client_ssework.temp_subgroup_customer_all_all_summary")
        cls.sqlContext.createDataFrame(feature_distinct_tab_summary_lst,
                                       feature_distinct_tab_summary_schema). \
            write.saveAsTable("client_ssework.temp_feature_distinct_tab_summary")
        cls.sqlContext.createDataFrame(all_all_all_all_1w1w_lst, all_all_all_all_1w1w_schema).\
            write.saveAsTable("client_ssework.temp_all_all_all_all_1w1w")
        cls.sqlContext.createDataFrame(all_all_all_all_1w4w_lst, all_all_all_all_1w4w_schema). \
            write.saveAsTable("client_ssework.temp_all_all_all_all_1w4w")
        cls.sqlContext.createDataFrame(product_customer_all_all_1w1w_lst,
                                       product_customer_all_all_1w1w_schema). \
            write.saveAsTable("client_ssework.temp_product_customer_all_all_1w1w")
        cls.sqlContext.createDataFrame(product_customer_all_all_1w4w_lst,
                                       product_customer_all_all_1w4w_schema). \
            write.saveAsTable("client_ssework.temp_product_customer_all_all_1w4w")
        cls.sqlContext.createDataFrame(subgroup_all_all_all_1w1w_lst,
                                       subgroup_all_all_all_1w1w_schema). \
            write.saveAsTable("client_ssework.temp_subgroup_all_all_all_1w1w")
        cls.sqlContext.createDataFrame(subgroup_all_all_all_1w4w_lst,
                                       subgroup_all_all_all_1w4w_schema). \
            write.saveAsTable("client_ssework.temp_subgroup_all_all_all_1w4w")
        cls.sqlContext.createDataFrame(subgroup_customer_all_all_1w1w_lst,
                                       subgroup_customer_all_all_1w1w_schema). \
            write.saveAsTable("client_ssework.temp_subgroup_customer_all_all_1w1w")
        cls.sqlContext.createDataFrame(subgroup_customer_all_all_1w4w_lst,
                                       subgroup_customer_all_all_1w4w_schema). \
            write.saveAsTable("client_ssework.temp_subgroup_customer_all_all_1w4w")
        cls.sqlContext.createDataFrame(feature_distinct_tab_1w1w_lst,
                                       feature_distinct_tab_1w1w_schema). \
            write.saveAsTable("client_ssework.temp_feature_distinct_tab_1w1w")
        cls.sqlContext.createDataFrame(feature_distinct_tab_1w4w_lst,
                                       feature_distinct_tab_1w4w_schema). \
            write.saveAsTable("client_ssework.temp_feature_distinct_tab_1w4w")
        cls.sqlContext.createDataFrame(all_all_all_all_lst, all_all_all_all_schema). \
            write.saveAsTable("client_pob.temp_all_all_all_all")
        cls.sqlContext.createDataFrame(product_customer_all_all_lst,
                                       product_customer_all_all_schema). \
            write.saveAsTable("client_pob.temp_product_customer_all_all")
        cls.sqlContext.createDataFrame(subgroup_all_all_all_lst, subgroup_all_all_all_schema). \
            write.saveAsTable("client_pob.temp_subgroup_all_all_all")
        cls.sqlContext.createDataFrame(subgroup_customer_all_all_lst,
                                       subgroup_customer_all_all_schema). \
            write.saveAsTable("client_pob.temp_subgroup_customer_all_all")
        # Create transaction_item_fct table
        cls.sqlContext.sql(setup_sql["drop_transaction_item_fct"])
        cls.sqlContext.sql(setup_sql["create_transaction_item_fct"])
        cls.sqlContext.sql(setup_sql["ins_transaction_item_fct"])

    @classmethod
    def tearDownClass(cls):
        # Drop databases and tables
        cls.sqlContext.sql(setup_sql["drop_db_media_mart"])
        cls.sqlContext.sql(setup_sql["drop_db_ssework"])
        cls.sqlContext.sql(setup_sql["drop_db_pob"])

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def refresh_purchase_table(self, fis_week_id=None):
        """
        Drop & recreate purchase_fct table
        :param fis_week_id: if mentioned then data of only that fis_week_id is loaded in table
        :return: None
        """
        self.sqlContext.sql("REFRESH TABLE client_ssework.temp_purchase")
        self.sqlContext.sql(setup_sql["drop_purchase_fct"])
        self.sqlContext.sql(setup_sql["create_purchase_fct"])
        where_clause = ""
        if fis_week_id:
            where_clause = " WHERE fis_week_id IN ({0})".format(",".join(["'" + item + "'"
                                                                          for item in fis_week_id]))
        self.sqlContext.sql(setup_sql["ins_purchase_fct"] + where_clause)

    def refresh_work_table(self, tab_name, fis_week_id=None):
        """
        Drop & recreate specified work table (summary, aggregation, merge)
        :param tab_name: table name
        :param fis_week_id: if mentioned then data of only that date_id is loaded in table
        :return: None
        """
        self.sqlContext.sql(setup_sql["drop_" + tab_name])
        self.sqlContext.sql(setup_sql["create_" + tab_name])
        where_clause = ""
        if fis_week_id:
            where_clause = " WHERE fis_week_id IN ({0})".format(",".join(["'" + item + "'"
                                                                          for item in fis_week_id]))
        self.sqlContext.sql(setup_sql["ins_" + tab_name] + where_clause)

    def test_no_instance_creation(self):
        """
        Since PurchasingFeatureGeneratorBase is abstract class, it shouldn't be used directly
        through class object/instance (instance of class)
        :return: None
        """
        self.assertRaises(TypeError, PurchasingFeatureGeneratorBase, config=test_config,
                          cadence_attribute="fis_week_id", run_date=self.run_date)

    def test_features_specifications(self):
        """
        features_specifications (property/getter, setter) - unit test case
        :return:
        """
        pur_feat_gen = PurchasingFeatureGeneratorDefective(config=test_config,
                                                           cadence_attribute="fis_week_id",
                                                           run_date=self.run_date)
        with self.assertRaises(ValueError) as ve:
            self.assertIsNone(pur_feat_gen.features_specifications)
        self.assertIsInstance(ve.exception, ValueError)
        features_specifications = [
            {
                "name": "All_All_All_All",
                "cadence_attribute": "fis_week_id",
                "is_active": True,
                "summary_on": True,
                "durations": [(1, 1), (1, 4)],
                "rsd": 0.0,
                "dimension_attribute_grain": {
                    "ProductAttribute": "All",
                    "CustomerAttribute": "All",
                    "StoreAttribute": "All",
                    "ChannelAttribute": "All"
                },
                "base_features": ["Baskets", "BasketWeeks", "Discount", "MaximumPrice"],
                "derived_features": ["BasketsFlag", "DiscountPerBasket", "DiscountPercent"],
                "dependent_derived_features": ["BasketsDecay1w13wvs1w26w"],
                "distinct_features": ["CustomerCount"]
            }
        ]
        pur_feat_gen.features_specifications = features_specifications
        self.assertIsInstance(pur_feat_gen.features_specifications, list)

    def test_feature_mapping(self):
        """
        feature_mapping (property/getter) - unit test case
        :return: none
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsInstance(pur_feat_gen.feature_mapping, dict)
        # Get a random feature mapping
        feature = pur_feat_gen.feature_mapping[choice(pur_feat_gen.feature_mapping.keys())]
        self.assertIsInstance(feature, dict)
        self.assertGreaterEqual(len(feature.keys()), 5)

    def test_current_date(self):
        """
        current_date (property/getter) - unit test case
        :return:
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        current_dt = dt.today().date()
        self.assertEqual(pur_feat_gen.current_date, current_dt)

    def test_cadence(self):
        """
        cadence (property/getter) - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertEqual(pur_feat_gen.cadence, result_set["cadence_for_fis_week_id"])
        with self.assertRaises(ValueError) as ve:
            pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                      cadence_attribute="blah",
                                                      run_date=self.run_date)
            self.assertIsNone(pur_feat_gen.cadence)
        self.assertIsInstance(ve.exception, ValueError)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="date_short_name",
                                                  run_date=self.run_date)
        self.assertEqual(pur_feat_gen.cadence, result_set["cadence_for_date_short_name"])

    def test_cadence_week(self):
        """
        cadence_week (property/getter) - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertEqual(pur_feat_gen.cadence_week, result_set["cadence_week_for_fis_week_id"])
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="date_short_name",
                                                  run_date=self.run_date)
        self.assertEqual(pur_feat_gen.cadence_week, result_set["cadence_week_date_short_name"])

    def test_since_date(self):
        """
        since_date (property/getter) - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertEqual(pur_feat_gen.since_date, result_set["since_date"])

    def test_required_fis_weeks(self):
        """
        required_fis_weeks (property/getter) - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        required_fis_weeks = sorted(result_set["required_fis_weeks"])
        test_req_fis_weeks = pur_feat_gen.required_fis_weeks
        test_req_fis_weeks.sort()
        self.assertEqual(test_req_fis_weeks, required_fis_weeks)
        self.assertEqual(len(test_req_fis_weeks), len(required_fis_weeks))

    def test_register_udfs(self):
        """
        register_udfs - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsNotNone(pur_feat_gen)
        func_list = [item["function"] for item in self.sqlContext.sql("SHOW FUNCTIONS").collect()]
        self.assertIn("fisweekdiff", func_list)
        res = self.sqlContext.sql("SELECT fisweekdiff('201702', '201701') as res").first()["res"]
        self.assertEqual(res, 1)

    def test_write_purchase(self):
        """
        write_purchase method - unit test case
        :return: None
        """
        self.refresh_purchase_table(fis_week_id=["201741"])
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        purchase_old_cnt = pur_feat_gen.purchases.data.count()
        # Randomly pick a transaction date which isn't available in purchase_fct
        rand_dt = choice(list(set([item[19] for item in purchases_lst if item[18] != "201741"])))
        new_rows = [item for item in purchases_lst if item[19] == rand_dt]
        res = pur_feat_gen.write_purchase(date_id=rand_dt)
        # Refresh table metadata & call get_data, so that purchases df can point to updated data.
        self.sqlContext.catalog.refreshTable(pur_feat_gen.purchases.table_name)
        pur_feat_gen.purchases.get_data()
        purchase_new_cnt = pur_feat_gen.purchases.data.count()
        self.assertIsInstance(res, Denormalization_res_tuple)
        self.assertTrue(res.result)
        self.assertEqual(res.date_id, rand_dt)
        self.assertEqual(purchase_new_cnt, purchase_old_cnt + len(new_rows))


    def test_execute_sql(self):
        """
        execute_sql method - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        drop_st = setup_sql["drop_purchase_fct"]
        create_st = setup_sql["create_purchase_fct"]
        ins_st = setup_sql["ins_purchase_fct"]
        # Check for ddl statements
        stmt_tup = Statement_tuple(feature_name="", tab_type="table", tab_name="purchase_fct",
                                   stmt_type="ddl-drop", sql_stmt=drop_st, log=False,
                                   section="unit-test", wave=1)
        res = pur_feat_gen.execute_sql(stmt_tup=stmt_tup)
        self.assertIsInstance(res, Exec_res_tuple)
        self.assertTrue(res.result)
        self.assertNotIn("purchase_fct", [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName="client_ssework")
                            if item.tableType == "MANAGED"]
        )
        stmt_tup = Statement_tuple(feature_name="", tab_type="table", tab_name="purchase_fct",
                                   stmt_type="ddl-create", sql_stmt=create_st, log=False,
                                   section="unit-test", wave=1)
        res = pur_feat_gen.execute_sql(stmt_tup=stmt_tup)
        self.assertIsInstance(res, Exec_res_tuple)
        self.assertTrue(res.result)
        self.assertIn("client_ssework.purchase_fct", [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName="client_ssework")
                            if item.tableType == "MANAGED"]
                        )
        # Check for dml statements
        stmt_tup = Statement_tuple(feature_name="", tab_type="table", tab_name="purchase_fct",
                                   stmt_type="dml", sql_stmt=ins_st, log=False, section="unit-test",
                                   wave=1)
        res = pur_feat_gen.execute_sql(stmt_tup=stmt_tup)
        self.assertIsInstance(res, Exec_res_tuple)
        self.assertTrue(res.result)
        self.assertGreater(self.sqlContext.table("client_ssework.purchase_fct").count(), 0)

    def test_get_partition_info(self):
        """
        get_partition_info method - unit test case
        :return: None
        """

        table_name = 'subgroup_customer_all_all_summary'
        self.refresh_work_table(tab_name=table_name)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        part_info = pur_feat_gen.get_partition_info(tab_name='.'.join(["client_ssework", table_name]))
        self.assertIsInstance(part_info, list)
        part_info.sort()
        trans_dt = sorted(list(set([item[-1] for item in subgroup_customer_all_all_summary_lst])))
        self.assertListEqual(part_info, trans_dt)

    def test_del_partition(self):
        """
        del_partition method - unit test case
        :return: None
        """
        tab_name = "all_all_all_all_summary"
        self.refresh_work_table(tab_name=tab_name)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        pur_feat_gen.del_partition(tab_name="client_media_mart.transactions")
        drop_part = choice([item[20] for item in all_all_all_all_summary_lst])
        pur_feat_gen.del_partition(tab_name="client_ssework." + tab_name, fis_week_id=drop_part)
        part_info = pur_feat_gen.get_partition_info(tab_name="client_ssework." + tab_name)
        self.assertNotIn(drop_part, part_info)

    def test_gen_summary_statements(self):
        """
        gen_summary_statements method - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        # Generate summary statements
        name = "All_All_All_All"
        feature_spec = [item for item in pur_feat_gen.features_specifications
                        if item["name"] == name][0]
        res = pur_feat_gen.gen_summary_statements(features_spec=feature_spec)
        self.assertIsInstance(res, Summary_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name]["summary"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name]["summary"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name]["summary"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name]["summary"]["wave"])
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name]["summary"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name]["summary"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name]["summary"]["group_info"]))
        # Generate summary statements
        name = "Subgroup_All_All_All"
        feature_spec = [item for item in pur_feat_gen.features_specifications
                        if item["name"] == name][0]
        res = pur_feat_gen.gen_summary_statements(features_spec=feature_spec)
        self.assertIsInstance(res, Summary_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name]["summary"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name]["summary"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name]["summary"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name]["summary"]["wave"])
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name]["summary"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name]["summary"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name]["summary"]["group_info"]))

    def test_gen_aggregate_statements(self):
        """
        gen_aggregate_statements method - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        name = "All_All_All_All"
        agg_info = [((1, 1), deepcopy(item)) for item in pur_feat_gen.features_specifications
                    if item["name"] == name][0]
        # Generate aggregation statements
        res = pur_feat_gen.gen_aggregate_statements(agg_info=agg_info)
        self.assertIsInstance(res, Aggregate_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name]["aggregation"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name]["aggregation"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name]["aggregation"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name]["aggregation"]["wave"])
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name]["aggregation"]["group_info"]))
        name = "Subgroup_All_All_All"
        agg_info = [((1, 1), deepcopy(item)) for item in pur_feat_gen.features_specifications
                    if item["name"] == name][0]
        res = pur_feat_gen.gen_aggregate_statements(agg_info=agg_info)
        self.assertIsInstance(res, Aggregate_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name]["aggregation"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name]["aggregation"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name]["aggregation"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name]["aggregation"]["wave"])
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name]["aggregation"]["group_info"]))
        # Test one grain with supplementary tables (feature with additional dim attribute)
        pur_feat_gen = PurchasingFeatureGeneratorSupplementary(config=test_config,
                                                               cadence_attribute="fis_week_id",
                                                               run_date=self.run_date)
        agg_info = [((1, 1), deepcopy(item)) for item in pur_feat_gen.features_specifications
                    if item["name"] == "Product_Customer_All_All"][0]
        name = "Product_Customer_All_All_supplementary"
        # Generate aggregation statements
        res = pur_feat_gen.gen_aggregate_statements(agg_info=agg_info)
        self.assertIsInstance(res, Aggregate_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name]["aggregation"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name]["aggregation"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name]["aggregation"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name]["aggregation"]["wave"])
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name]["aggregation"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name]["aggregation"]["group_info"]))

    def test_gen_merge_statements(self):
        """
        gen_merge_statements method - unit test case
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        name, merge_info_lst = ["All_All_All_All", "Subgroup_All_All_All"], []
        # Generate aggregation statements
        feature_dur_lst = [(dur, deepcopy(item))
                           for item in pur_feat_gen.features_specifications
                           if item["name"] in name for dur in pur_feat_gen.durations
                           if pur_feat_gen.is_duration(item["durations"], dur)]
        agg_info_lst = map(pur_feat_gen.gen_aggregate_statements, feature_dur_lst)
        # Generate merge statements
        agg_info_lst = sorted([item for item in agg_info_lst if item.feature_name.lower() !=
                               pur_feat_gen.config["SSEFeatureDistinctTab"].lower()],
                              key=lambda x: x.feature_name)
        for key, group in groupby(agg_info_lst, key=lambda x: x.feature_name):
            agg_tabs, durations, sel_col, group_info = [], [], set(), []
            for item in group:
                durations.append(item.duration)
                agg_tabs.append((item.tab_name, item.duration))
                for col in item.sel_col:
                    sel_col.add(col)
                group_info = item.group_info
            durations.sort(key=lambda x: int(x[1]), reverse=True)
            agg_tabs.sort(key=lambda x: int(x[1][1]), reverse=True)
            sel_col = list(sel_col)
            sel_col.sort(key=lambda x: int(x.col_num * 1000 + sum(
                [int(match_digit) for match_digit in re.findall("\d+", x.colname)])), reverse=False)
            temp = Merge_info_tuple(feature_name=key, tab_name=None, durations=durations,
                                    agg_tabs=agg_tabs, run_mode=None, ddl_drop=None,
                                    ddl_create=None, dml=None, group_info=group_info,
                                    sel_col=sel_col, part_col=None, wave=None)
            merge_info_lst.append(temp)
        res = pur_feat_gen.gen_merge_statements(merge_info_lst[0])
        self.assertIsInstance(res, Merge_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name[0]]["merge"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name[0]]["merge"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name[0]]["merge"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name[0]]["merge"]["wave"])
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name[0]]["merge"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name[0]]["merge"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name[0]]["merge"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name[0]]["merge"]["group_info"]))
        res = pur_feat_gen.gen_merge_statements(merge_info_lst[1])
        self.assertIsInstance(res, Merge_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name[1]]["merge"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name[1]]["merge"]["tab_name"].lower())
        self.assertEqual(res.run_mode.lower(), result_set[name[1]]["merge"]["run_mode"].lower())
        self.assertEqual(res.wave, result_set[name[1]]["merge"]["wave"])
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name[1]]["merge"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name[1]]["merge"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.dml.replace(" ", "").lower(),
                         result_set[name[1]]["merge"]["dml"].replace(" ", "").lower())
        self.assertListEqual(sorted(res.group_info),
                             sorted(result_set[name[1]]["merge"]["group_info"]))

    def test_gen_view_statements(self):
        """
        gen_view_statements method - unit test case
        :return: None:
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        name, merge_info_lst = ["All_All_All_All", "Subgroup_All_All_All"], []
        feature_dur_lst = [(dur, deepcopy(item))
                           for item in pur_feat_gen.features_specifications
                           if item["name"] in name for dur in pur_feat_gen.durations
                           if pur_feat_gen.is_duration(item["durations"], dur)]
        # Generate aggregation statements
        agg_info_lst = map(pur_feat_gen.gen_aggregate_statements, feature_dur_lst)
        # Generate merge statements
        agg_info_lst = sorted([item for item in agg_info_lst if item.feature_name.lower() !=
                               pur_feat_gen.config["SSEFeatureDistinctTab"].lower()],
                              key=lambda x: x.feature_name)
        for key, group in groupby(agg_info_lst, key=lambda x: x.feature_name):
            agg_tabs, durations, sel_col, group_info = [], [], set(), []
            for item in group:
                durations.append(item.duration)
                agg_tabs.append((item.tab_name, item.duration))
                for col in item.sel_col:
                    sel_col.add(col)
                group_info = item.group_info
            durations.sort(key=lambda x: int(x[1]), reverse=True)
            agg_tabs.sort(key=lambda x: int(x[1][1]), reverse=True)
            sel_col = list(sel_col)
            sel_col.sort(key=lambda x: int(x.col_num * 1000 + sum(
                [int(match_digit) for match_digit in re.findall("\d+", x.colname)])), reverse=False)
            temp = Merge_info_tuple(feature_name=key, tab_name=None, durations=durations,
                                    agg_tabs=agg_tabs, run_mode=None, ddl_drop=None,
                                    ddl_create=None, dml=None, group_info=group_info,
                                    sel_col=sel_col, part_col=None, wave=None)
            merge_info_lst.append(temp)
        merge_res = pur_feat_gen.gen_merge_statements(merge_info_lst[0])
        # Generate view statements
        res = pur_feat_gen.gen_view_statements(merge_res)
        self.assertIsInstance(res, View_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name[0]]["view"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name[0]]["view"]["tab_name"].lower())
        self.assertEqual(res.view_name.lower(), result_set[name[0]]["view"]["view_name"].lower())
        self.assertEqual(res.current_view_name.lower(),
                         result_set[name[0]]["view"]["current_view_name"].lower())
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name[0]]["view"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name[0]]["view"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.current_ddl_drop.replace(" ", "").lower(),
                         result_set[name[0]]["view"]["current_ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.current_ddl_create.replace(" ", "").lower(),
                         result_set[name[0]]["view"]["current_ddl_create"].replace(" ", "").lower())
        merge_res = pur_feat_gen.gen_merge_statements(merge_info_lst[1])
        res = pur_feat_gen.gen_view_statements(merge_res)
        self.assertIsInstance(res, View_info_tuple)
        self.assertEqual(res.feature_name.lower(),
                         result_set[name[1]]["view"]["feature_name"].lower())
        self.assertEqual(res.tab_name.lower(), result_set[name[1]]["view"]["tab_name"].lower())
        self.assertEqual(res.view_name.lower(), result_set[name[1]]["view"]["view_name"].lower())
        self.assertEqual(res.current_view_name.lower(),
                         result_set[name[1]]["view"]["current_view_name"].lower())
        self.assertEqual(res.ddl_drop.replace(" ", "").lower(),
                         result_set[name[1]]["view"]["ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.ddl_create.replace(" ", "").lower(),
                         result_set[name[1]]["view"]["ddl_create"].replace(" ", "").lower())
        self.assertEqual(res.current_ddl_drop.replace(" ", "").lower(),
                         result_set[name[1]]["view"]["current_ddl_drop"].replace(" ", "").lower())
        self.assertEqual(res.current_ddl_create.replace(" ", "").lower(),
                         result_set[name[1]]["view"]["current_ddl_create"].replace(" ", "").lower())

    def test_log_tab(self):
        """
        create_log_tab and write_to_log methods - unit test case
        :return: None
        """
        log_tab = test_config["SSEHiveWorkdb"] + "." + test_config["SSEFeatureLogTab"]
        self.sqlContext.sql("DROP TABLE IF EXISTS {0}".format(log_tab))
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        res = pur_feat_gen.create_log_tab()
        self.assertTrue(res)
        self.assertIn(log_tab,
                      [item.database.lower() + "." + item.name.lower() for item in
                       self.sqlContext.catalog.listTables(dbName=test_config["SSEHiveWorkdb"])
                       if item.tableType == "MANAGED"])
        old_cnt = self.sqlContext.table(log_tab).count()
        temp_lst = [("2017-12-31", "201744", "fis_week_id", int(time.time()), "unit-test", "blah",
                     "blah")]
        feature_run_log_schema = pt.StructType([
            pt.StructField("cadence", pt.StringType(), True),
            pt.StructField("cadence_week", pt.StringType(), True),
            pt.StructField("cadence_attribute", pt.StringType(), True),
            pt.StructField("run_epoch", pt.LongType(), True),
            pt.StructField("section", pt.StringType(), True),
            pt.StructField("tab_name", pt.StringType(), True),
            pt.StructField("stmt_type", pt.StringType(), True)
        ])
        temp_df = self.sqlContext.createDataFrame(temp_lst, feature_run_log_schema)
        pur_feat_gen.write_to_log(temp_lst)
        pur_feat_gen.write_to_log(temp_df)
        new_cnt = self.sqlContext.table(log_tab).count()
        self.assertEqual(new_cnt, old_cnt + len(temp_lst) * 2)

    def test_pre_run(self):
        """
        pre_run method - unit test case
        :return: None
        """
        log_tab = test_config["SSEHiveWorkdb"] + "." + test_config["SSEFeatureLogTab"]
        self.sqlContext.sql("DROP TABLE IF EXISTS {0}".format(log_tab))
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        pur_feat_gen.pre_run(clean_run=True)
        self.assertIn(log_tab,
                      [item.database.lower() + "." + item.name.lower() for item in
                       self.sqlContext.catalog.listTables(dbName=test_config["SSEHiveWorkdb"])
                       if item.tableType == "MANAGED"]
                      )
        self.assertTrue(pur_feat_gen._clean_run)
        self.assertEqual(pur_feat_gen.cadence, result_set["cadence_for_fis_week_id"])
        self.assertEqual(pur_feat_gen.cadence_week, result_set["cadence_week_for_fis_week_id"])

    def test_post_run(self):
        """
        post_run method - unit test case
        :return: None
        """
        log_tab = test_config["SSEHiveWorkdb"] + "." + test_config["SSEFeatureLogTab"]
        self.sqlContext.sql("DROP TABLE IF EXISTS {0}".format(log_tab))
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        log_res = pur_feat_gen.create_log_tab()
        self.assertTrue(log_res)
        # sample rows with one row older than 2 month
        temp_lst = [("2017-12-31", "201744", "fis_week_id", int(time.time()), "aggregation", "blah",
                     "dml - insert"),
                    ("2017-12-31", "201744", "fis_week_id", int(time.time()) - (61 * 24 * 60 * 60),
                     "aggregation", "blah", "dml - insert")]
        feature_run_log_schema = pt.StructType([
            pt.StructField("cadence", pt.StringType(), True),
            pt.StructField("cadence_week", pt.StringType(), True),
            pt.StructField("cadence_attribute", pt.StringType(), True),
            pt.StructField("run_epoch", pt.LongType(), True),
            pt.StructField("section", pt.StringType(), True),
            pt.StructField("tab_name", pt.StringType(), True),
            pt.StructField("stmt_type", pt.StringType(), True)
        ])
        temp_df = self.sqlContext.createDataFrame(temp_lst, feature_run_log_schema)
        pur_feat_gen.write_to_log(temp_df)
        res = pur_feat_gen.post_run()
        new_cnt = self.sqlContext.table(log_tab).count()
        self.assertTrue(res)
        self.assertEqual(new_cnt, len(temp_lst) - 1)

    def test_is_duration(self):
        """
        is_duration method - unit test case
        :return: None
        """
        res = PurchasingFeatureGenerator.is_duration([(1, 1), (1, 4)], (1, 1))
        self.assertTrue(res)
        res = PurchasingFeatureGenerator.is_duration([(1, 1), (1, 4)], (1, 26))
        self.assertFalse(res)

    def test_denormalization_section(self):
        """
        denormalization_section method - unit test case
        :return: None
        """
        purchase_fis_weeks = ['201741']
        self.refresh_purchase_table(fis_week_id=purchase_fis_weeks)
        missing_fis_week = [item for item in result_set["required_fis_weeks"]
                            if item not in purchase_fis_weeks]
        input_rows = [item[19] for item in purchases_lst if str(item[18]) in missing_fis_week]
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        old_purchase_cnt = pur_feat_gen.purchases.data.count()
        denorm_res = pur_feat_gen.denormalization_section()
        self.assertIsInstance(denorm_res, list)
        self.assertIsInstance(choice(denorm_res), Denormalization_res_tuple)
        succ_result = [item.result for item in denorm_res if item.result]


        self.assertTrue(all(succ_result))
        # Refresh table metadata & call get_data, so that purchases df can point to updated data.
        self.sqlContext.catalog.refreshTable(pur_feat_gen.purchases.table_name)
        pur_feat_gen.purchases.get_data()
        new_purchase_cnt = pur_feat_gen.purchases.data.count()
        purchases_cnt = len([item[19] for item in purchases_lst
                         if str(item[18]) in result_set["required_fis_weeks"]])
        self.assertEqual(new_purchase_cnt, old_purchase_cnt + len(input_rows))
        self.assertEqual(new_purchase_cnt, purchases_cnt)
        # Match generated purchase data against result set
        result_df = self.sqlContext.createDataFrame(purchases_lst, purchases_schema)

        self.assertEqual(pur_feat_gen.purchases.data.subtract(result_df).count(), 0)
        self.assertEqual(result_df.subtract(pur_feat_gen.purchases.data).count(), 0)
        # Match data for single sample row from purchase to transaction
        purchases_dt = choice(input_rows)
        sample_purchases_row = choice([item for item in purchases_lst if item[19] == purchases_dt])
        row_in_transaction = [item for item in trans_lst if (item[0] == sample_purchases_row[0]) &
                              (item[12] == sample_purchases_row[19])]
        self.assertEqual(sample_purchases_row[14], row_in_transaction[0][6])
        self.assertEqual(sample_purchases_row[16], row_in_transaction[0][7])
        self.assertEqual(sample_purchases_row[15], row_in_transaction[0][8])
        self.assertEqual(sample_purchases_row[17], row_in_transaction[0][9])

    def test_summary_section(self):
        """
        summary_section method - unit test case
        :return: None
        """
        # Create required purchase table
        self.refresh_purchase_table()
        # Remove any old summary tables
        work_db = test_config["SSEHiveWorkdb"]
        tab_lst = [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]
        drop_sum_tab = ["DROP TABLE IF EXISTS {0}".format(work_db + "." + item) for item in tab_lst
                        if item in result_set["summary_tab_list"]]
        map(self.sqlContext.sql, drop_sum_tab)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        # Create required summary tables
        summary_res, summary_info_lst = pur_feat_gen.summary_section()
        self.assertIsInstance(summary_res, list)
        self.assertIsInstance(choice(summary_res), Exec_res_tuple)
        self.assertTrue(all([item.result for item in summary_res]))
        self.assertIsInstance(choice(summary_info_lst), Summary_info_tuple)
        summary_tabs = sorted([item.tab_name.split(".")[1].lower() for item in summary_info_lst])
        self.assertListEqual(summary_tabs, sorted(result_set["summary_tab_list"]))
        tab_lst = sorted([item for item in [item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]
                          if item in result_set["summary_tab_list"]])
        self.assertListEqual(tab_lst, sorted(result_set["summary_tab_list"]))
        # Test populated summary tables against available results
        for summary_tab in result_set["summary_tab_list"]:
            generated_df = self.sqlContext.table(work_db + "." + summary_tab)
            df_schema = globals()[summary_tab + "_schema"]
            df_lst = globals()[summary_tab + "_lst"]
            result_df = self.sqlContext.createDataFrame(df_lst, df_schema)
            # Get minus/diff/subtract of dfs, row count of minus df would be zero for identical df
            minus_df = generated_df.subtract(result_df)
            minus_df1 = result_df.subtract(generated_df)
            self.assertEqual(minus_df.count(), 0)
            self.assertEqual(minus_df1.count(), 0)

    def test_aggregate_section(self):
        """
        aggregate_section method - unit test case
        :return: None
        """
        # Create required summary tables
        for item in result_set["summary_tab_list"]:
            self.refresh_work_table(tab_name=item)
        # Remove any old aggregation tables
        work_db = test_config["SSEHiveWorkdb"]
        tab_lst = [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]

        drop_agg_tab = ["DROP TABLE IF EXISTS {0}".format(work_db + "." + item) for item in tab_lst
                        if item in result_set["aggregation_tab_list"]]
        map(self.sqlContext.sql, drop_agg_tab)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        # Drop & recreate log table
        log_tab = work_db + "." + test_config["SSEFeatureLogTab"]
        self.sqlContext.sql("DROP TABLE IF EXISTS " + log_tab)
        pur_feat_gen.create_log_tab()
        # Create required aggregation tables
        aggregation_res, populated_agg_tab, agg_info_lst = pur_feat_gen.aggregate_section()
        self.assertIsInstance(aggregation_res, list)
        self.assertIsInstance(choice(aggregation_res), Exec_res_tuple)
        self.assertTrue(all([item.result for item in aggregation_res]))
        self.assertIsInstance(choice(agg_info_lst), Aggregate_info_tuple)
        aggregate_tabs = sorted([item.tab_name.split(".")[1].lower() for item in agg_info_lst])
        self.assertListEqual(aggregate_tabs, sorted(result_set["aggregation_tab_list"]))
        tab_lst = sorted([item for item in [item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]
                          if item in result_set["aggregation_tab_list"]])
        self.assertListEqual(tab_lst, sorted(result_set["aggregation_tab_list"]))
        # Test populated aggregation tables against available results
        for aggregate_tab in result_set["aggregation_tab_list"]:
            generated_df = self.sqlContext.table(work_db + "." + aggregate_tab)
            df_schema = globals()[aggregate_tab + "_schema"]
            df_lst = globals()[aggregate_tab + "_lst"]
            result_df = self.sqlContext.createDataFrame(df_lst, df_schema)
            # Get minus/diff/subtract of dfs, row count of minus df would be zero for identical df
            minus_df = generated_df.subtract(result_df)
            minus_df1 = result_df.subtract(generated_df)
            self.assertEqual(minus_df.count(), 0)
            self.assertEqual(minus_df1.count(), 0)
        # Check entry in log table
        log_tab_df = self.sqlContext.table(log_tab)
        self.assertEqual(log_tab_df.count(), len(result_set["aggregation_tab_list"]))
        # Test one grain with supplementary tables (feature with additional dim attribute)
        # Remove any old aggregation tables
        tab_lst = [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]

        drop_agg_tab = ["DROP TABLE IF EXISTS {0}".format(work_db + "." + item) for item in tab_lst
                        if item in result_set["aggregation_tab_list_supplementary"]]
        map(self.sqlContext.sql, drop_agg_tab)
        pur_feat_gen = PurchasingFeatureGeneratorSupplementary(config=test_config,
                                                               cadence_attribute="fis_week_id",
                                                               run_date=self.run_date)
        # Create required aggregation tables
        aggregation_res, populated_agg_tab, agg_info_lst = pur_feat_gen.aggregate_section()
        self.assertIsInstance(aggregation_res, list)
        tab_lst = sorted([item for item in [item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=work_db)
                            if item.tableType == "MANAGED"]
                          if item in result_set["aggregation_tab_list_supplementary"]])
        self.assertListEqual(tab_lst, sorted(result_set["aggregation_tab_list_supplementary"]))
        aggregate_tabs = sorted([item.tab_name.split(".")[1].lower() for item in agg_info_lst])
        self.assertListEqual(aggregate_tabs,
                             sorted(result_set["aggregation_tab_list_supplementary"]))
        # Test populated aggregation tables against available results
        for aggregate_tab in result_set["aggregation_tab_list_supplementary"]:
            generated_df = self.sqlContext.table(work_db + "." + aggregate_tab)
            df_schema = globals()[aggregate_tab + "_schema_supplementary"]
            df_lst = globals()[aggregate_tab + "_lst_supplementary"]
            result_df = self.sqlContext.createDataFrame(df_lst, df_schema)
            # Get minus/diff/subtract of dfs, row count of minus df would be zero for identical df
            minus_df = generated_df.subtract(result_df)
            minus_df1 = result_df.subtract(generated_df)
            self.assertEqual(minus_df.count(), 0)
            self.assertEqual(minus_df1.count(), 0)
        # Check entry in log table
        log_tab_df = self.sqlContext.table(log_tab)
        self.assertEqual(log_tab_df.count(), len(result_set["aggregation_tab_list"]) +
                         len(result_set["aggregation_tab_list_supplementary"]))

    def test_merge_section(self):
        """
        merge_section method - unit test case
        :return: None
        """
        # Create required aggregation tables
        for item in result_set["aggregation_tab_list"]:
            self.refresh_work_table(tab_name=item)
        # Remove any old merge tables
        pob_db = test_config["SSEHivePobdb"]
        tab_lst = [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=pob_db)
                            if item.tableType == "MANAGED"]

        drop_merge_tab = ["DROP TABLE IF EXISTS {0}".format(pob_db + "." + item) for item in tab_lst
                          if item in result_set["merge_tab_list"]]
        map(self.sqlContext.sql, drop_merge_tab)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        # Drop & recreate log table
        log_tab = test_config["SSEHiveWorkdb"] + "." + test_config["SSEFeatureLogTab"]
        self.sqlContext.sql("DROP TABLE IF EXISTS " + log_tab)
        pur_feat_gen.create_log_tab()
        feature_dur_lst = [(dur, deepcopy(item)) for item in pur_feat_gen.features_specifications
                           for dur in pur_feat_gen.durations]
        # Generate aggregation statements
        agg_info_lst = map(pur_feat_gen.gen_aggregate_statements, feature_dur_lst)
        # Create required merge tables
        merge_res, populated_mergetab, merge_info_lst = pur_feat_gen.merge_section(agg_info_lst)
        self.assertIsInstance(merge_res, list)
        self.assertIsInstance(choice(merge_res), Exec_res_tuple)
        self.assertTrue(all([item.result for item in merge_res]))
        self.assertIsInstance(choice(merge_info_lst), Merge_info_tuple)
        merge_tabs = sorted([item.tab_name.split(".")[1].lower() for item in merge_info_lst])
        self.assertListEqual(merge_tabs, sorted(result_set["merge_tab_list"]))
        tab_lst = sorted([item for item in [item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=pob_db)
                            if item.tableType == "MANAGED"]
                          if item in result_set["merge_tab_list"]])
        self.assertListEqual(tab_lst, sorted(result_set["merge_tab_list"]))
        # Test populated merge tables against available results
        for merge_tab in result_set["merge_tab_list"]:
            generated_df = self.sqlContext.table(pob_db + "." + merge_tab)
            df_schema = globals()[merge_tab + "_schema"]
            df_lst = globals()[merge_tab + "_lst"]
            result_df = self.sqlContext.createDataFrame(df_lst, df_schema)
            # Get minus/diff/subtract of dfs, row count of minus df would be zero for identical df
            minus_df = generated_df.subtract(result_df)
            minus_df1 = result_df.subtract(generated_df)
            self.assertEqual(minus_df.count(), 0)
            self.assertEqual(minus_df1.count(), 0)

        # Check entry in log table
        log_tab_df = self.sqlContext.table(log_tab)
        self.assertEqual(log_tab_df.count(), len(result_set["merge_tab_list"]))

    def test_view_creation_section(self):
        """
        view_creation_section method - unit test case
        :return: None
        """
        # Create required merge tables
        for item in result_set["merge_tab_list"]:
            self.refresh_work_table(tab_name=item)
        # Remove any old views
        pob_db = test_config["SSEHivePobdb"]
        tab_lst = [item.database.lower() + "." + item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=pob_db)
                            if item.tableType == "MANAGED"]
        drop_view = ["DROP VIEW IF EXISTS {0}".format(pob_db + "." + item) for item in tab_lst
                     if item in result_set["view_list"]]
        map(self.sqlContext.sql, drop_view)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        # Generate aggregation statements
        feature_dur_lst = [(dur, deepcopy(item)) for item in pur_feat_gen.features_specifications
                           for dur in pur_feat_gen.durations]
        agg_info_lst = map(pur_feat_gen.gen_aggregate_statements, feature_dur_lst)
        # Generate merge statements
        merge_info_lst = []
        agg_info_lst = sorted([item for item in agg_info_lst if item.feature_name.lower() !=
                               pur_feat_gen.config["SSEFeatureDistinctTab"].lower()],
                              key=lambda x: x.feature_name)
        for key, group in groupby(agg_info_lst, key=lambda x: x.feature_name):
            agg_tabs, durations, sel_col, group_info = [], [], set(), []
            for item in group:
                durations.append(item.duration)
                agg_tabs.append((item.tab_name, item.duration))
                for col in item.sel_col:
                    sel_col.add(col)
                group_info = item.group_info
            durations.sort(key=lambda x: int(x[1]), reverse=True)
            agg_tabs.sort(key=lambda x: int(x[1][1]), reverse=True)
            sel_col = list(sel_col)
            sel_col.sort(key=lambda x: int(x.col_num * 1000 + sum(
                [int(match_digit) for match_digit in re.findall("\d+", x.colname)])), reverse=False)
            temp = Merge_info_tuple(feature_name=key, tab_name=None, durations=durations,
                                    agg_tabs=agg_tabs, run_mode=None, ddl_drop=None,
                                    ddl_create=None, dml=None, group_info=group_info,
                                    sel_col=sel_col, part_col=None, wave=None)
            merge_info_lst.append(temp)
        merge_info_lst = map(pur_feat_gen.gen_merge_statements, merge_info_lst)
        # Create required view
        view_res, view_info_lst = pur_feat_gen.view_creation_section(merge_info_lst)
        self.assertTrue(view_res)
        self.assertIsInstance(choice(view_info_lst), View_info_tuple)
        views = sorted([view.split(".")[1].lower() for item in view_info_lst
                        for view in [item.view_name, item.current_view_name]])
        self.assertListEqual(views, sorted(result_set["view_list"]))
        view_in_db = sorted([item for item in [item.name.lower() for item in
                            self.sqlContext.catalog.listTables(dbName=pob_db)]
                             if item in result_set["view_list"]])
        self.assertListEqual(view_in_db, sorted(result_set["view_list"]))
        # Test views against merge tables & available results
        for item in view_info_lst:
            merge_tab_df = self.sqlContext.table(pob_db + "." + item.feature_name.lower())
            view_df = self.sqlContext.table(item.view_name.lower())
            current_view_df = self.sqlContext.table(item.current_view_name.lower())
            merge_df_lst = globals()[item.feature_name.lower() + "_lst"]
            self.assertEqual(view_df.count(), merge_tab_df.count())
            self.assertEqual(current_view_df.count(), merge_tab_df.count())
            self.assertEqual(view_df.count(), len(merge_df_lst))
            self.assertEqual(current_view_df.count(), len(merge_df_lst))
            # view & current view should be identical
            minus_df = view_df.subtract(current_view_df)
            self.assertEqual(minus_df.count(), 0)


    @mock.patch('test.dunnhumby.cmp_features.purchasing_feature_generator_base.sample_data_set.'
                'PurchasingFeatureGenerator.current_date', new_callable=mock.PropertyMock)
    def test_data_purge_section(self, mock_current_date):
        """
        data_purge_section method - unit test case
        :param mock_current_date: mocked value for PurchasingFeatureGenerator.current_date
        :return: None
        """
        # Using mocked value for current_date to have uniform value for current_date & predictable
        # outcome when unit test cases are run on different dates/days.
        # So data will be retained for T - n (for 2018-01-08 T will be 201746), hence for summary
        # data in range (201746 to 201743) & for merge data in range (201746) will be retained
        mock_current_date.return_value = dt.strptime('2018-01-08', '%Y-%m-%d')
        # Create required denorm/purchase, summary and merge tables
        self.refresh_purchase_table()
        for item in result_set["summary_tab_list"] + result_set["merge_tab_list"]:
            self.refresh_work_table(tab_name=item)
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        # Checking data_purge_section with SSEFeatureDataPurge set to False
        old_purchase_part = sorted(list(set(
            [item[0] for item in pur_feat_gen.purchases.get_partition_info(refresh=True)])))


        # Calling data purge method
        res = pur_feat_gen.data_purge_section()
        self.assertTrue(res)
        new_purchase_part = sorted(list(set(
            [item[0] for item in pur_feat_gen.purchases.get_partition_info(refresh=True)])))
        self.assertListEqual(old_purchase_part, new_purchase_part)
        # Checking with SSEFeatureDataPurge set to True & other appropriate setting values.
        temp_config = deepcopy(test_config)
        temp_config["SSEFeatureDataPurge"] = "True"
        temp_config["SSEFeatureDataPurgeRetentionWeekNum"] = 3
        temp_config["SSEFeatureDataPurgePublishedRetentionWeekNum"] = 0
        pur_feat_gen = PurchasingFeatureGenerator(config=temp_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)


        old_purchase_part = sorted(list(set(
            [item[0] for item in pur_feat_gen.purchases.get_partition_info()])))


        wdb = temp_config["SSEHiveWorkdb"]
        pobdb = temp_config["SSEHivePobdb"]
        old_summary_part = {item: sorted(pur_feat_gen.get_partition_info(tab_name=wdb + "." + item))
                            for item in result_set["summary_tab_list"]}
        old_merge_part = {item: sorted(pur_feat_gen.get_partition_info(tab_name=pobdb + "." + item))
                          for item in result_set["merge_tab_list"]}
        # Calling data purge method
        res = pur_feat_gen.data_purge_section()
        self.assertTrue(res)
        new_purchase_part = sorted(list(set(
            [item[0] for item in pur_feat_gen.purchases.get_partition_info(refresh=True)])))
        new_summary_part = {item: sorted(pur_feat_gen.get_partition_info(tab_name=wdb + "." + item))
                            for item in result_set["summary_tab_list"]}
        new_merge_part = {item: sorted(pur_feat_gen.get_partition_info(tab_name=pobdb + "." + item))
                          for item in result_set["merge_tab_list"]}
        denorm_summary_part = sorted(result_set["denorm_summary_data_retain_week"])
        self.assertListEqual(new_purchase_part, denorm_summary_part)
        for part in set(old_purchase_part) - set(denorm_summary_part):
            self.assertNotIn(part, new_purchase_part)
        for item in result_set["summary_tab_list"]:
            self.assertListEqual(new_summary_part[item], denorm_summary_part)
            for part in set(old_summary_part[item]) - set(denorm_summary_part):
                self.assertNotIn(part, new_summary_part[item])
        for item in result_set["merge_tab_list"]:
            self.assertListEqual(new_merge_part[item], sorted(result_set["merge_data_retain_week"]))
            for part in set(old_merge_part[item]) - set(result_set["merge_data_retain_week"]):
                self.assertNotIn(part, new_merge_part[item])
