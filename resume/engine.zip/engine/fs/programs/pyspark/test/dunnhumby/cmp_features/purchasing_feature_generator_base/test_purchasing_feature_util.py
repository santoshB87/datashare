"""
Purchasing feature util file - Unit test cases
"""


import unittest
from dunnhumby.cmp_features.purchasing_feature_util import EPOCH_DATE, Summary_info_tuple, \
    Aggregate_info_tuple, Merge_info_tuple, View_info_tuple, Sel_col_tuple, Agg_sel_col_tuple, \
    Statement_tuple, Denormalization_res_tuple, Exec_res_tuple, Date_tuple, Col_tuple, \
    match_table_structure
from dunnhumby import contexts


class TestPurchasingFeatureUtil(unittest.TestCase):
    """
    Unit test cases for purchasing feature util
    """

    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")
        cls.sqlContext.sql("DROP DATABASE IF EXISTS client_ssework CASCADE")
        cls.sqlContext.sql("CREATE DATABASE IF NOT EXISTS client_ssework "
                           "LOCATION '/user/hive/warehouse/client_ssework'")
        cls.sqlContext.sql("DROP TABLE IF EXISTS client_ssework.test_tab")
        cls.sqlContext.sql("DROP TABLE IF EXISTS client_ssework.test_tab_part")
        cls.sqlContext.sql("CREATE TABLE IF NOT EXISTS client_ssework.test_tab (col1 string) STORED"
                           " AS PARQUET")
        cls.sqlContext.sql("CREATE TABLE IF NOT EXISTS client_ssework.test_tab_part (col1 string) "
                           "PARTITIONED BY (col2 string) STORED AS PARQUET")

    @classmethod
    def tearDownClass(cls):
        cls.sqlContext.sql("DROP TABLE IF EXISTS client_ssework.test_tab")
        cls.sqlContext.sql("DROP TABLE IF EXISTS client_ssework.test_tab_part")
        cls.sqlContext.sql("DROP DATABASE IF EXISTS client_ssework CASCADE")

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_date_tuple(self):
        """

        :return: None
        """
        temp_tuple = Date_tuple(fis_week_id="201801", date_id="2018-01-01", fis_year_id="2018")
        self.assertIsInstance(temp_tuple, Date_tuple)

    def test_col_tuple(self):
        """

        :return: None
        """
        temp_tuple = Col_tuple(col_name="col1", data_type="string")
        self.assertIsInstance(temp_tuple, Col_tuple)

    def test_epoch_date(self):
        """

        :return: None
        """
        self.assertEqual("1970-01-01", EPOCH_DATE)

    def test_denormalization_res_tuple(self):
        """

        :return: None
        """
        temp_tuple = Denormalization_res_tuple(date_id="2018-03-31", result=True, time_taken=0)
        self.assertIsInstance(temp_tuple, Denormalization_res_tuple)

    def test_summary_info_tuple(self):
        """

        :return: None
        """
        temp_tuple = Summary_info_tuple(feature_name="", tab_name="", run_mode="", ddl_drop="",
                                        ddl_create="", dml="", group_info="", sel_col="",
                                        part_col="", wave=1)
        self.assertIsInstance(temp_tuple, Summary_info_tuple)

    def test_aggregate_info_tuple(self):
        """

        :return: None
        """
        temp_tuple = Aggregate_info_tuple(feature_name="", tab_name="", duration=[(1, 1)],
                                          run_mode="", ddl_drop="", ddl_create="", dml="",
                                          group_info="", sel_col="", part_col="", wave=1)
        self.assertIsInstance(temp_tuple, Aggregate_info_tuple)

    def test_merge_info_tuple(self):
        """

        :return: None
        """
        temp_tuple = Merge_info_tuple(feature_name="", tab_name="", durations="", agg_tabs="",
                                      run_mode="", ddl_drop="", ddl_create="", dml="",
                                      group_info="", sel_col="", part_col="", wave=1)
        self.assertIsInstance(temp_tuple, Merge_info_tuple)

    def test_view_info_tuple(self):
        """

        :return: None
        """
        temp_tuple = View_info_tuple(feature_name="", tab_name="", view_name="",
                                     current_view_name="", sel_col="", ddl_drop="", ddl_create="",
                                     current_ddl_drop="", current_ddl_create="")
        self.assertIsInstance(temp_tuple, View_info_tuple)

    def test_sel_col_tuple(self):
        """

        :return: None
        """
        temp_tuple = Sel_col_tuple(colname="", select_expr="", hive_datatype="", col_num=1)
        self.assertIsInstance(temp_tuple, Sel_col_tuple)

    def test_agg_sel_col_tuple(self):
        """

        :return: None
        """
        temp_tuple = Agg_sel_col_tuple(colname="", in_select_expr="", out_select_expr="",
                                       hive_datatype="", col_num=1)
        self.assertIsInstance(temp_tuple, Agg_sel_col_tuple)

    def test_statement_tuple(self):
        """

        :return: None
        """
        temp_tuple = Statement_tuple(feature_name="", tab_type="", tab_name="", stmt_type="",
                                     sql_stmt="", log=False, section="", wave=None)
        self.assertIsInstance(temp_tuple, Statement_tuple)

    def test_exec_res_tuple(self):
        """

        :return: None
        """
        temp_tuple = Exec_res_tuple(feature_name="", tab_name="", result=True, time_taken=0,
                                    log=False, section="")
        self.assertIsInstance(temp_tuple, Exec_res_tuple)

    def test_match_table_structure(self):
        """

        :return: None
        """
        db_name = "client_ssework"
        tab_name_non_existing = "test_tab_not_exists"
        tab_name = "test_tab"
        tab_name_part = "test_tab_part"
        col_info_one = [Col_tuple("col1", "string")]
        col_info_two = [Col_tuple("col1", "string"), Col_tuple("col2", "string")]
        col_info_three = [Col_tuple("col1", "int")]
        part_info_empty = []
        part_info_one = ["col2"]
        part_info_two = ["col3"]
        # Non existing table
        self.assertFalse(match_table_structure(self.sqlContext, db_name, tab_name_non_existing,
                                               col_info_one, part_info_one))
        # Matching non partitioned table
        self.assertTrue(match_table_structure(self.sqlContext, db_name, tab_name, col_info_one,
                                              part_info_empty))
        # Non matching table
        self.assertFalse(match_table_structure(self.sqlContext, db_name, tab_name, col_info_two,
                                               part_info_empty))
        # Non matching table - datatype change
        self.assertFalse(match_table_structure(self.sqlContext, db_name, tab_name, col_info_three,
                                               part_info_empty))
        # Matching partitioned table
        self.assertTrue(match_table_structure(self.sqlContext, db_name, tab_name_part,
                                              col_info_two, part_info_one))
        # Non matching partitioned table
        self.assertFalse(match_table_structure(self.sqlContext, db_name, tab_name_part,
                                               col_info_two, part_info_empty))
        self.assertFalse(match_table_structure(self.sqlContext, db_name, tab_name_part,
                                               col_info_two, part_info_two))
