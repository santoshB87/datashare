# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestDimensions(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    """Ensure that all dimensions exist in the returned dataframe
    This test was created when did some work to eliminate data skew problems in the feature generator.
    Those dataskew problems reared their head when transactions were aggregated to "All Customers" and there were lots
    of unknown members in the Customer dimension - this caused all data for the unknown Customer to appear in one
    RDD partition and hence...data skew problems.
    To solve that problem we chose to remove any dimensions aggregated to "All" from the actual aggregation,
    and instead pass the literal "All". Doing so eliminates data skew problems caused by this situation (well, at the
    time of writing we're *hoping* it eliminates them, yet to be tested :) )
    """
    def test_when_aggregated_to_all_all_dimensions_are_still_returned(self):
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=self.df,
            customer_attribute='All',
            store_attribute='All',
            product_attribute='All',
            channel_attribute='All'
        )
        field_names = [field.name for field in output_df.schema.fields]
        output = output_df.collect()
        self.assertEqual(len(output), 1)
        self.assertTrue('Customer' in field_names)
        self.assertEqual(output[0]['Customer'], 'All')
        self.assertTrue('Store' in field_names)
        self.assertEqual(output[0]['Store'], 'All')
        self.assertTrue('Product' in field_names)
        self.assertEqual(output[0]['Product'], 'All')
        self.assertTrue('Channel' in field_names)
        self.assertEqual(output[0]['Channel'], 'All')


