# coding: latin-1
from __future__ import absolute_import, print_function
from decimal import *
import datetime
from pyspark.sql.types import StructField, StructType, StringType, \
    TimestampType, IntegerType, DecimalType
from pyspark.sql import DataFrame

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestFeaturesBuilderGeneric(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_if_df_parameter_is_not_a_dataframe_then_throw_error(self):
        features = PurchasingFeatureGenerator(rsd=0.0)
        # I admit I don't really understand why using a lambda here makes this
        # work, this explains it: http://stackoverflow.com/a/6103930
        self.assertRaises(
            TypeError,
            lambda: features.get_data(purchases_df='not a dataframe')
        )

    def test_if_df_does_not_contain_column_called_date_then_throw_error(self):
        schema = StructType([StructField("foo", StringType(), True)])
        l = [('bar',)]
        df = self.sqlContext.createDataFrame(l, schema=schema)
        features = PurchasingFeatureGenerator(rsd=0.0)
        self.assertRaises(
            RuntimeError,
            lambda: features.get_data(self.as_at, df)
        )

    def test_valid_dataframe_does_not_raise_an_error(self):
        features = PurchasingFeatureGenerator(rsd=0.0)
        output_df = features.get_data(self.as_at, self.df)
        self.assertTrue(isinstance(output_df, DataFrame))

    def test_transaction_date_with_timestamp_raises_an_error(self):
        """
        In February 2017 a problem was found where the exposure rate for HYF for Tesco was way down. The problem was
        eventually traced back to the fact that a change upstream meant that transaction date (transaction_dttm) had
        suddenly started coming through with time precision (i.e. not occurring at the stroke of midnight). This
        caused a join condition to filter out rows that were needed for HYF, and hence why exposure rates were down.
        The issue and the fix are documented at http://jira.dunnhumby.co.uk/browse/SCE-587.
        At the time of writing our features only need to know on which date a transaction occurred, not at what
        time of day, hence to prevent similar issues in the future let us mandate that a DateType is passed in,
        not a TimestampType.
        :return:
        """
        schema = StructType([
            StructField("Date", TimestampType(), True),
            StructField("Customer", StringType(), True),
            StructField("Product", StringType(), True),
            StructField("Basket", StringType(), True),
            StructField("Quantity", IntegerType(), True),
            StructField("SpendAmount", DecimalType(), True)
        ])
        l = [(datetime.datetime(2017, 2, 2), 'Customer1', 'Product1', 'Basket1', 1, Decimal('1.0'))]
        df = self.sqlContext.createDataFrame(l, schema=schema)
        features = PurchasingFeatureGenerator(rsd=0.0)
        self.assertRaises(
            RuntimeError,
            lambda: features.get_data(self.as_at, df)
        )
