# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestQuantity(test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_Quantity_xw_one_customer_one_product_one_store(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerDarthVadar
        ).filter(
            self.df.Product == self.productCheddarMature
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(output_df[0]['Quantity_1w4w'], 2)
        self.assertEqual(output_df[0]['Quantity_1w13w'], 3)
        self.assertEqual(output_df[0]['Quantity_1w26w'], 4)
        self.assertEqual(output_df[0]['Quantity_1w52w'], 5)
        self.assertEqual(output_df[0]['Quantity_1w56w'], 7)

    def test_Quantity_xw_one_customer_one_product_one_store_via_get_data_method(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerDarthVadar
        ).filter(
            self.df.Product == self.productCheddarMature
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(output_df[0]['Quantity_1w4w'], 2)
        self.assertEqual(output_df[0]['Quantity_1w13w'], 3)
        self.assertEqual(output_df[0]['Quantity_1w26w'], 4)
        self.assertEqual(output_df[0]['Quantity_1w52w'], 5)
        self.assertEqual(output_df[0]['Quantity_1w56w'], 7)

    def test_Quantity_xw_two_customers_two_products_one_store(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLukeSkywalker)
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 3)
        setharmstrong_cheddarmature_df = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (
            row.Product == self.productCheddarMature)]
        self.assertEqual(len(setharmstrong_cheddarmature_df), 1)
        self.assertEqual(setharmstrong_cheddarmature_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(setharmstrong_cheddarmature_df[0]['Quantity_1w4w'], 2)
        self.assertEqual(setharmstrong_cheddarmature_df[0]['Quantity_1w13w'], 3)
        self.assertEqual(setharmstrong_cheddarmature_df[0]['Quantity_1w26w'], 4)
        self.assertEqual(setharmstrong_cheddarmature_df[0]['Quantity_1w52w'], 5)
        self.assertEqual(setharmstrong_cheddarmature_df[0]['Quantity_1w56w'], 7)
        setharmstrong_fetacheesemild_df = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (
            row.Product == self.productFetaCheeseMild)]
        self.assertEqual(len(setharmstrong_fetacheesemild_df), 1)
        self.assertEqual(setharmstrong_fetacheesemild_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_df[0]['Quantity_1w4w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_df[0]['Quantity_1w13w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_df[0]['Quantity_1w26w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_df[0]['Quantity_1w52w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_df[0]['Quantity_1w56w'], 1)
        joemangle_cheddarmature_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productCheddarMature)]
        self.assertEqual(len(joemangle_cheddarmature_df), 1)
        self.assertEqual(joemangle_cheddarmature_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(joemangle_cheddarmature_df[0]['Quantity_1w4w'], 1)
        self.assertEqual(joemangle_cheddarmature_df[0]['Quantity_1w13w'], 1)
        self.assertEqual(joemangle_cheddarmature_df[0]['Quantity_1w26w'], 1)
        self.assertEqual(joemangle_cheddarmature_df[0]['Quantity_1w52w'], 1)
        self.assertEqual(joemangle_cheddarmature_df[0]['Quantity_1w56w'], 1)
        joemangle_fetacheesemild_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productFetaCheeseMild)]
        self.assertEqual(len(joemangle_fetacheesemild_df), 0)

    def test_Quantity_xw_two_customers_two_products_one_store_aggregated_to_customer_and_product_attributes(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLukeSkywalker)
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            self.df.Store == self.storeBG
        )
        customer_attributes_df = self.sqlContext.createDataFrame(
            [(self.customerDarthVadar, 'Male'), (self.customerLukeSkywalker, 'Male')], ['Customer', 'Gender'])
        product_attributes_df = self.sqlContext.createDataFrame(
            [(self.productFetaCheeseMild, 'Cheese'),(self.productCheddarMature, 'Cheese')], ['Product', 'LevelX'])
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attributes_df=customer_attributes_df,
            product_attributes_df=product_attributes_df,
            customer_attribute='Gender',
            product_attribute='LevelX'
        ).collect()
        self.assertEqual(len(output_df), 1)
        #Ensure that even though we are aggregating to LevelX/Gender, the identifiers still get passed in fields
        #called Product & Customer respectively
        self.assertEqual('Product' in output_df[0].__fields__, True)
        self.assertEqual('Customer' in output_df[0].__fields__, True)
        self.assertEqual('LevelX' in output_df[0].__fields__, False)
        self.assertEqual('Gender' in output_df[0].__fields__, False)
        self.assertEqual(output_df[0]['Quantity_1w1w'], 3)
        self.assertEqual(output_df[0]['Quantity_1w4w'], 4)
        self.assertEqual(output_df[0]['Quantity_1w13w'], 5)
        self.assertEqual(output_df[0]['Quantity_1w26w'], 6)
        self.assertEqual(output_df[0]['Quantity_1w52w'], 7)
        self.assertEqual(output_df[0]['Quantity_1w56w'], 9)

    def test_Quantity_preferred_and_fulfillment_xw_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar)
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            (self.df.Store == self.storeBG) |
            (self.df.Store == self.storeEA)
        )
        input_df = input_df.withColumn('PreferredStore1', f.lit(self.storeEA))
        input_df = input_df.withColumn('PreferredStore2', f.lit(self.storeBG))
        input_df = input_df.withColumn('PreferredStore3', f.lit(None))
        input_df = input_df.withColumn('FulfillmentStore', f.lit(self.storeEA))
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 2)
        setharmstrong_cheddarmature_storeBG_df = [row for row in output_df if
                                                  (row.Customer == self.customerDarthVadar) & (
                                                      row.Product == self.productCheddarMature) & (
                                                      row.Store == self.storeBG)]
        self.assertEqual(len(setharmstrong_cheddarmature_storeBG_df), 1)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore1_1w1w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore1_1w4w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore1_1w13w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore1_1w26w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore1_1w52w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore1_1w56w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore2_1w1w'], 1)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore2_1w4w'], 2)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore2_1w13w'], 3)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore2_1w26w'], 4)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore2_1w52w'], 5)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore2_1w56w'], 7)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore3_1w1w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore3_1w4w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore3_1w13w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore3_1w26w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore3_1w52w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityPrefStore3_1w56w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityFulfillmentStore_1w1w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityFulfillmentStore_1w4w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityFulfillmentStore_1w13w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityFulfillmentStore_1w26w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityFulfillmentStore_1w52w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['QuantityFulfillmentStore_1w56w'], 0)
        setharmstrong_cheddarmature_storeEA_df = [row for row in output_df if
                                                  (row.Customer == self.customerDarthVadar) & (
                                                      row.Product == self.productCheddarMature) & (
                                                      row.Store == self.storeEA)]
        self.assertEqual(len(setharmstrong_cheddarmature_storeEA_df), 1)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore1_1w1w'], 1)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore1_1w4w'], 2)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore1_1w13w'], 3)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore1_1w26w'], 4)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore1_1w52w'], 5)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore1_1w56w'], 7)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore2_1w1w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore2_1w4w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore2_1w13w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore2_1w26w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore2_1w52w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore2_1w56w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore3_1w1w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore3_1w4w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore3_1w13w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore3_1w26w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore3_1w52w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityPrefStore3_1w56w'], 0)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityFulfillmentStore_1w1w'], 1)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityFulfillmentStore_1w4w'], 2)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityFulfillmentStore_1w13w'], 3)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityFulfillmentStore_1w26w'], 4)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityFulfillmentStore_1w52w'], 5)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['QuantityFulfillmentStore_1w56w'], 7)

    def test_Quantity_xw_two_customers_two_products_two_stores(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLukeSkywalker)
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            (self.df.Store == self.storeBG) |
            (self.df.Store == self.storeEA)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 6)
        setharmstrong_cheddarmature_storeBG_df = [row for row in output_df if
                                                  (row.Customer == self.customerDarthVadar) & (
                                                      row.Product == self.productCheddarMature) & (
                                                      row.Store == self.storeBG)]
        self.assertEqual(len(setharmstrong_cheddarmature_storeBG_df), 1)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['Quantity_1w4w'], 2)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['Quantity_1w13w'], 3)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['Quantity_1w26w'], 4)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['Quantity_1w52w'], 5)
        self.assertEqual(setharmstrong_cheddarmature_storeBG_df[0]['Quantity_1w56w'], 7)
        setharmstrong_fetacheesemild_storeBG_df = [row for row in output_df if
                                                   (row.Customer == self.customerDarthVadar) & (
                                                       row.Product == self.productFetaCheeseMild) & (
                                                       row.Store == self.storeBG)]
        self.assertEqual(len(setharmstrong_fetacheesemild_storeBG_df), 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeBG_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeBG_df[0]['Quantity_1w4w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeBG_df[0]['Quantity_1w13w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeBG_df[0]['Quantity_1w26w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeBG_df[0]['Quantity_1w52w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeBG_df[0]['Quantity_1w56w'], 1)
        joemangle_cheddarmature_storeBG_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productCheddarMature) & (row.Store == self.storeBG)]
        self.assertEqual(len(joemangle_cheddarmature_storeBG_df), 1)
        self.assertEqual(joemangle_cheddarmature_storeBG_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeBG_df[0]['Quantity_1w4w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeBG_df[0]['Quantity_1w13w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeBG_df[0]['Quantity_1w26w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeBG_df[0]['Quantity_1w52w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeBG_df[0]['Quantity_1w56w'], 1)
        joemangle_fetacheesemild_storeBG_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productFetaCheeseMild) & (row.Store == self.storeBG)]
        self.assertEqual(len(joemangle_fetacheesemild_storeBG_df), 0)
        setharmstrong_cheddarmature_storeEA_df = [row for row in output_df if
                                                  (row.Customer == self.customerDarthVadar) & (
                                                      row.Product == self.productCheddarMature) & (
                                                      row.Store == self.storeEA)]
        self.assertEqual(len(setharmstrong_cheddarmature_storeEA_df), 1)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['Quantity_1w4w'], 2)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['Quantity_1w13w'], 3)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['Quantity_1w26w'], 4)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['Quantity_1w52w'], 5)
        self.assertEqual(setharmstrong_cheddarmature_storeEA_df[0]['Quantity_1w56w'], 7)
        setharmstrong_fetacheesemild_storeEA_df = [row for row in output_df if
                                                   (row.Customer == self.customerDarthVadar) & (
                                                       row.Product == self.productFetaCheeseMild) & (
                                                       row.Store == self.storeEA)]
        self.assertEqual(len(setharmstrong_fetacheesemild_storeEA_df), 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeEA_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeEA_df[0]['Quantity_1w4w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeEA_df[0]['Quantity_1w13w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeEA_df[0]['Quantity_1w26w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeEA_df[0]['Quantity_1w52w'], 1)
        self.assertEqual(setharmstrong_fetacheesemild_storeEA_df[0]['Quantity_1w56w'], 1)
        joemangle_cheddarmature_storeEA_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productCheddarMature) & (row.Store == self.storeEA)]
        self.assertEqual(len(joemangle_cheddarmature_storeEA_df), 1)
        self.assertEqual(joemangle_cheddarmature_storeEA_df[0]['Quantity_1w1w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeEA_df[0]['Quantity_1w4w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeEA_df[0]['Quantity_1w13w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeEA_df[0]['Quantity_1w26w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeEA_df[0]['Quantity_1w52w'], 1)
        self.assertEqual(joemangle_cheddarmature_storeEA_df[0]['Quantity_1w56w'], 1)
        joemangle_fetacheesemild_storeEA_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productFetaCheeseMild) & (row.Store == self.storeEA)]
        self.assertEqual(len(joemangle_fetacheesemild_storeEA_df), 0)
