# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestBaskets(test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_Baskets_xw_one_customer_one_product_one_store_multiple_quantities_multiple_baskets(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_1w1w'], 2)
        self.assertEqual(output_df[0]['Baskets_1w4w'], 3)
        self.assertEqual(output_df[0]['Baskets_1w13w'], 3)
        self.assertEqual(output_df[0]['Baskets_1w26w'], 3)
        self.assertEqual(output_df[0]['Baskets_1w52w'], 3)
        self.assertEqual(output_df[0]['Baskets_1w56w'], 3)
        self.assertEqual(output_df[0]['BasketsDecay_1w13wvs1w26w'], 1)
        self.assertEqual(output_df[0]['BasketsDecay_1w13wvs1w52w'], 1)

    def test_Baskets_53w78w_one_customer_one_product_one_store(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            self.df.Store == self.storeEA
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_53w78w'], 0)

    def test_Baskets_53w104w_one_customer_one_product_one_store(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            self.df.Store == self.storeEA
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_53w104w'], 1)

    def test_Baskets_53w104w_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            (self.df.Store == self.storeEA) |
            (self.df.Store == self.storeBG)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_53w104w'], 2)

    def test_Baskets_101w107w_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            (self.df.Store == self.storeEA) |
            (self.df.Store == self.storeBG)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_101w107w'], 0)

    def test_Baskets_153w159w_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            (self.df.Store == self.storeEA) |
            (self.df.Store == self.storeBG)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_153w159w'], 0)

    def test_Baskets_205w211w_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerObiWan
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            (self.df.Store == self.storeEA) |
            (self.df.Store == self.storeBG)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_205w211w'], 1)
