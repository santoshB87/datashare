# coding: latin-1
from __future__ import absolute_import, print_function
from pyspark.sql.functions import from_unixtime, unix_timestamp
from pyspark.sql.types import TimestampType

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestDimensions(test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_all_dimensions_are_returned_from_get_data_when_aggregated_to_all(self):
        """
        Useful to check that the minimum set of expected columns (i.e. the 
        dimensions) always get returned
        """
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        input_df = self.df.withColumn(
            'DateTime',
            from_unixtime(unix_timestamp(self.df.Date) + (13 * 60 * 60) + 60, "YYYY-MM-dd HH:mm:ss").cast(
                TimestampType())
        ).drop(self.df.Date)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All',
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            timeofday_attribute='All'
        )
        self.assertTrue('Customer' in [field.name for field in output_df.schema.fields])
        self.assertTrue('Product' in [field.name for field in output_df.schema.fields])
        self.assertTrue('Store' in [field.name for field in output_df.schema.fields])
        self.assertTrue('Channel' in [field.name for field in output_df.schema.fields])
        self.assertTrue('TimeOfDay' in [field.name for field in output_df.schema.fields])