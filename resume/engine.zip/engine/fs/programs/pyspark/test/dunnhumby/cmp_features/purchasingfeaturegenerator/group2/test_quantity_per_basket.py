# coding: latin-1
from __future__ import absolute_import, print_function

from decimal import *

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestQuantityPerBasket(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_quantityperbasket_one_customer_one_product_one_store(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerDarthVadar
        ).filter(
            self.df.Product == self.productCheddarMature
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            product_attribute='All',
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['QuantityPerBasket_1w1w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w4w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w13w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w26w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w52w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w56w'], Decimal('1.17'))

    def test_quantityperbasket_one_customer_two_products_one_store(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerDarthVadar
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            product_attribute='All',
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['QuantityPerBasket_1w1w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w4w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w13w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w26w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w52w'], Decimal('1'))
        self.assertEqual(output_df[0]['QuantityPerBasket_1w56w'], Decimal('1.14'))
