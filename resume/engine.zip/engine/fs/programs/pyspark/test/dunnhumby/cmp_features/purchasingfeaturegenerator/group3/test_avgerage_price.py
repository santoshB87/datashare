# coding: latin-1
from __future__ import absolute_import, print_function

from decimal import *

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestAveragePrice(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_AverageNetPrice_two_customers_one_product_one_store(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerHanSolo)
        ).filter(
            self.df.Product == self.productCheddarMature
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All',
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['AverageNetPrice_1w1w'], Decimal('1.12'))


