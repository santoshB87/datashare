# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestBasketWeeks(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_basketweeks_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerDarthVadar
        ).filter(
            (self.df.Product == self.productCheddarMature)
        ).filter(
            (self.df.Store == self.storeBG) |
            (self.df.Store == self.storeEA)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['BasketWeeks_1w1w'], 1)
        self.assertEqual(output_df[0]['BasketWeeks_1w4w'], 2)
        self.assertEqual(output_df[0]['BasketWeeks_1w13w'], 3)
        self.assertEqual(output_df[0]['BasketWeeks_1w26w'], 4)
        self.assertEqual(output_df[0]['BasketWeeks_1w52w'], 5)
        self.assertEqual(output_df[0]['BasketWeeks_1w56w'], 6)
        
    def test_basketweeks_one_customer_two_products_two_stores_multiple_purchases_in_same_week(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerLeiaOrgana
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productBakedBeans)
        ).filter(
            (self.df.Store == self.storeBG) |
            (self.df.Store == self.storeEA)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 2)
        cheddarmature_df = [row for row in output_df if row.Product == self.productCheddarMature]
        self.assertEqual(cheddarmature_df[0]['BasketWeeks_1w1w'], 1)
        self.assertEqual(cheddarmature_df[0]['BasketWeeks_1w4w'], 2)
        self.assertEqual(cheddarmature_df[0]['BasketWeeks_1w13w'], 2)
        self.assertEqual(cheddarmature_df[0]['BasketWeeks_1w26w'], 2)
        self.assertEqual(cheddarmature_df[0]['BasketWeeks_1w52w'], 2)
        self.assertEqual(cheddarmature_df[0]['BasketWeeks_1w56w'], 2)
        bakedbeans_df = [row for row in output_df if row.Product == self.productBakedBeans]
        self.assertEqual(bakedbeans_df[0]['BasketWeeks_1w1w'], 0)
        self.assertEqual(bakedbeans_df[0]['BasketWeeks_1w4w'], 1)
        self.assertEqual(bakedbeans_df[0]['BasketWeeks_1w13w'], 1)
        self.assertEqual(bakedbeans_df[0]['BasketWeeks_1w26w'], 1)
        self.assertEqual(bakedbeans_df[0]['BasketWeeks_1w52w'], 1)
        self.assertEqual(bakedbeans_df[0]['BasketWeeks_1w56w'], 1)

