# coding: latin-1
from __future__ import absolute_import, print_function

from decimal import *

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestNetSpend(test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_NetSpend_xw_two_customers_two_products_one_store_aggregated_to_all_customers_all_products(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLukeSkywalker)
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All',
            product_attribute='All'
        ).collect()
        storebg_df = [row for row in output_df if (row.Store == self.storeBG)]
        self.assertEqual(storebg_df[0]['NetSpend_1w1w'], Decimal('5.97'))
        self.assertEqual(storebg_df[0]['NetSpend_1w4w'], Decimal('7.96'))
        self.assertEqual(storebg_df[0]['NetSpend_1w13w'], Decimal('9.95'))
        self.assertEqual(storebg_df[0]['NetSpend_1w26w'], Decimal('11.94'))
        self.assertEqual(storebg_df[0]['NetSpend_1w52w'], Decimal('13.93'))
        self.assertEqual(storebg_df[0]['NetSpend_1w56w'], Decimal('15.92'))

    def test_NetSpend_xw_two_customers_two_products_one_store_aggregated_to_all_customers(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLukeSkywalker)
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All'
        ).collect()
        cheddarmature_df = [row for row in output_df if row.Product == self.productCheddarMature]
        self.assertEqual(cheddarmature_df[0]['NetSpend_1w1w'], Decimal('3.98'))
        self.assertEqual(cheddarmature_df[0]['NetSpend_1w4w'], Decimal('5.97'))
        self.assertEqual(cheddarmature_df[0]['NetSpend_1w13w'], Decimal('7.96'))
        self.assertEqual(cheddarmature_df[0]['NetSpend_1w26w'], Decimal('9.95'))
        self.assertEqual(cheddarmature_df[0]['NetSpend_1w52w'], Decimal('11.94'))
        self.assertEqual(cheddarmature_df[0]['NetSpend_1w56w'], Decimal('13.93'))
        fetaCheeseMild_df = [row for row in output_df if row.Product == self.productFetaCheeseMild]
        self.assertEqual(fetaCheeseMild_df[0]['NetSpend_1w1w'], Decimal('1.99'))
        self.assertEqual(fetaCheeseMild_df[0]['NetSpend_1w4w'], Decimal('1.99'))
        self.assertEqual(fetaCheeseMild_df[0]['NetSpend_1w13w'], Decimal('1.99'))
        self.assertEqual(fetaCheeseMild_df[0]['NetSpend_1w26w'], Decimal('1.99'))
        self.assertEqual(fetaCheeseMild_df[0]['NetSpend_1w52w'], Decimal('1.99'))
        self.assertEqual(fetaCheeseMild_df[0]['NetSpend_1w56w'], Decimal('1.99'))

    def test_NetSpend_xw_two_customers_two_products_one_store_aggregated_to_all_stores(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLukeSkywalker)
        ).filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All'
        ).collect()
        setharmstrong_cheddarmature_df = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (
        row.Product == self.productCheddarMature)]
        self.assertEqual(setharmstrong_cheddarmature_df[0]['NetSpend_1w1w'], Decimal('1.99'))
        self.assertEqual(setharmstrong_cheddarmature_df[0]['NetSpend_1w4w'], Decimal('3.98'))
        self.assertEqual(setharmstrong_cheddarmature_df[0]['NetSpend_1w13w'], Decimal('5.97'))
        self.assertEqual(setharmstrong_cheddarmature_df[0]['NetSpend_1w26w'], Decimal('7.96'))
        self.assertEqual(setharmstrong_cheddarmature_df[0]['NetSpend_1w52w'], Decimal('9.95'))
        self.assertEqual(setharmstrong_cheddarmature_df[0]['NetSpend_1w56w'], Decimal('11.94'))
        setharmstrong_fetaCheeseMild_df = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (
            row.Product == self.productFetaCheeseMild)]
        self.assertEqual(setharmstrong_fetaCheeseMild_df[0]['NetSpend_1w1w'], Decimal('1.99'))
        self.assertEqual(setharmstrong_fetaCheeseMild_df[0]['NetSpend_1w4w'], Decimal('1.99'))
        self.assertEqual(setharmstrong_fetaCheeseMild_df[0]['NetSpend_1w13w'], Decimal('1.99'))
        self.assertEqual(setharmstrong_fetaCheeseMild_df[0]['NetSpend_1w26w'], Decimal('1.99'))
        self.assertEqual(setharmstrong_fetaCheeseMild_df[0]['NetSpend_1w52w'], Decimal('1.99'))
        self.assertEqual(setharmstrong_fetaCheeseMild_df[0]['NetSpend_1w56w'], Decimal('1.99'))
        joemangle_cheddarmature_df = [row for row in output_df if (row.Customer == self.customerLukeSkywalker) & (
            row.Product == self.productCheddarMature)]
        self.assertEqual(joemangle_cheddarmature_df[0]['NetSpend_1w1w'], Decimal('1.99'))
        self.assertEqual(joemangle_cheddarmature_df[0]['NetSpend_1w4w'], Decimal('1.99'))
        self.assertEqual(joemangle_cheddarmature_df[0]['NetSpend_1w13w'], Decimal('1.99'))
        self.assertEqual(joemangle_cheddarmature_df[0]['NetSpend_1w26w'], Decimal('1.99'))
        self.assertEqual(joemangle_cheddarmature_df[0]['NetSpend_1w52w'], Decimal('1.99'))
        self.assertEqual(joemangle_cheddarmature_df[0]['NetSpend_1w56w'], Decimal('1.99'))
