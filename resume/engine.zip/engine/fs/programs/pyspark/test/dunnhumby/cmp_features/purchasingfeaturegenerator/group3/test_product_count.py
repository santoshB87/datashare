# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestProductCount(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    """
    ProductCount is defined as "Distinct count of products that have been purchased". That means we don't care how many
    of the product were purchased, we don't care how many baskets they were purchased over, only whether a Product was
    purchased or not.
    Thus, calculating productCount when product_attribute = 'Product' is utterly useless, because it will always be 1.
    It only makes sense to calculate ProductCount when the data is aggregated to an attribute of the Product entity. For
    example, if we sell 15 cheese products and only 2 of them have ever been bought then ProductCount for Cheese=2,
    regardless of many times they have been bought.
    """
    def test_productcount_three_products_are_bought_and_data_is_not_aggregated(self):
        input_df = self.df.filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild) |
            (self.df.Product == self.productWholeMilk)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All',
            channel_attribute='All',
            customer_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 3)
        output_cheddarMature_df = [row for row in output_df if row.Product == self.productCheddarMature]
        self.assertEqual(output_cheddarMature_df[0]['ProductCount_1w56w'], 1)
        output_cheddarMature_df = [row for row in output_df if row.Product == self.productFetaCheeseMild]
        self.assertEqual(output_cheddarMature_df[0]['ProductCount_1w56w'], 1)
        output_cheddarMature_df = [row for row in output_df if row.Product == self.productWholeMilk]
        self.assertEqual(output_cheddarMature_df[0]['ProductCount_1w56w'], 1)

    def test_productcount_three_products_are_bought_and_data_is_aggregated_to_a_product_attribute(self):
        input_df = self.df.filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild) |
            (self.df.Product == self.productWholeMilk)
        )
        product_attributes_df = self.sqlContext.createDataFrame(
            [(self.productFetaCheeseMild, 'Cheese'),
             (self.productCheddarMature, 'Cheese'),
             (self.productWholeMilk, 'Milk')
             ], ['Product', 'Group'])
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            product_attribute='Group',
            store_attribute='All',
            channel_attribute='All',
            customer_attribute='All',
            product_attributes_df=product_attributes_df
        ).collect()
        self.assertEqual(len(output_df), 2)
        output_cheddarMature_df = [row for row in output_df if row.Product == 'Cheese']
        self.assertEqual(output_cheddarMature_df[0]['ProductCount_1w56w'], 2)
        output_cheddarMature_df = [row for row in output_df if row.Product == 'Milk']
        self.assertEqual(output_cheddarMature_df[0]['ProductCount_1w56w'], 1)

    def test_productcount_three_products_are_bought_and_data_is_aggregated_to_all_products(self):
        input_df = self.df.filter(
            (self.df.Product == self.productCheddarMature) |
            (self.df.Product == self.productFetaCheeseMild) |
            (self.df.Product == self.productWholeMilk)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            customer_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['ProductCount_1w56w'], 3)

