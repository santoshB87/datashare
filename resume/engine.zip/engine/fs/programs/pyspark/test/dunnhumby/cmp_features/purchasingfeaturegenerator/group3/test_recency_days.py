# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestRecencyDays(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_RecencyDays_xw_one_customer_one_product_two_stores(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerAdmiralAckbar
        ).filter(
            self.df.Product == self.productCheddarMature
        ).filter(
            (self.df.Store == self.storeBG) |
            (self.df.Store == self.storeEA)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 2)
        storeBG_df = [row for row in output_df if row.Store == self.storeBG]
        self.assertEqual(storeBG_df[0]['RecencyDays_1w1w'], None)
        self.assertEqual(storeBG_df[0]['RecencyDays_1w4w'], 21)
        self.assertEqual(storeBG_df[0]['RecencyDays_1w13w'], 21)
        self.assertEqual(storeBG_df[0]['RecencyDays_1w26w'], 21)
        self.assertEqual(storeBG_df[0]['RecencyDays_1w52w'], 21)
        self.assertEqual(storeBG_df[0]['RecencyDays_1w56w'], 21)
        storeEA_df = [row for row in output_df if row.Store == self.storeEA]
        self.assertEqual(storeEA_df[0]['RecencyDays_1w1w'], None)
        self.assertEqual(storeEA_df[0]['RecencyDays_1w4w'], None)
        self.assertEqual(storeEA_df[0]['RecencyDays_1w13w'], None)
        self.assertEqual(storeEA_df[0]['RecencyDays_1w26w'], None)
        self.assertEqual(storeEA_df[0]['RecencyDays_1w52w'], 189)
        self.assertEqual(storeEA_df[0]['RecencyDays_1w56w'], 189)
