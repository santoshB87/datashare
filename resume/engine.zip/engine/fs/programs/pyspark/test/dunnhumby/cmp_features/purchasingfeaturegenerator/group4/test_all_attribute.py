# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestAllAttribute(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    """
    Specifying "All" for one of the attributes is a special case. We shouldn't need to supply a df that maps
    all of the members to "All", and likewise we shouldn't require the consumer to do anything special.
    If the consumer wants stuff aggregated to "All" then we should support that
    """
    def test__aggregating_all_dimensions_to_all_returns_one_row(self):
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=self.df,
            customer_attribute="All",
            product_attribute="All",
            store_attribute="All",
            channel_attribute="All"
        ).collect()
        self.assertEqual(len(output_df), 1)