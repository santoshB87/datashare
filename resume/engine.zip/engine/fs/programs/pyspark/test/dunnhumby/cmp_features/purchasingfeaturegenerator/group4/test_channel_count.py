# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestchannelCount(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_one_channels_has_purchases(self):
        input_df = self.df.filter(
            (self.df.Channel == self.channelInstore)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            channel_attribute='All',
            product_attribute='All',
            customer_attribute='All',
            store_attribute='All'
        ).select('ChannelCount_1w52w').collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(1, output_df[0]['ChannelCount_1w52w'])