# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestCustomerCountxw(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_two_customers_purchasing_something_in_five_different_baskets_in_the_same_week(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerRey) |
            (self.df.Customer == self.customerFinn)
        ).filter(
            (self.df.Product == self.productWholeMilk)
        ).filter(
            self.df.Store == self.storeBG
        ).filter(
            self.df.Channel == self.channelInstore
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        #Including fop here because I want to demonstrate the difference between fop & customercount
        #if two customers bought the same product in 5 different baskets each then fop=10, but customercount=2
        self.assertEqual(output_df[0]['Baskets_1w1w'], 10)
        self.assertEqual(output_df[0]['CustomerCount_1w1w'], 2)
        self.assertEqual(output_df[0]['CustomerCount_53w78w'], 0)

        #now let's use the same dataset but this time don't aggregate to all customers
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 2)
        output_customerRey_df = [row for row in output_df if row.Customer == self.customerRey]
        output_customerFinn_df = [row for row in output_df if row.Customer == self.customerFinn]
        self.assertEqual(output_customerRey_df[0]['Baskets_1w1w'], 5)
        self.assertEqual(output_customerRey_df[0]['CustomerCount_1w1w'], 1)
        self.assertEqual(output_customerRey_df[0][''
                                                  'CustomerCount_53w78w'], 0)
        self.assertEqual(output_customerFinn_df[0]['Baskets_1w1w'], 5)
        self.assertEqual(output_customerFinn_df[0]['CustomerCount_1w1w'], 1)
        self.assertEqual(output_customerFinn_df[0]['CustomerCount_53w78w'], 0)