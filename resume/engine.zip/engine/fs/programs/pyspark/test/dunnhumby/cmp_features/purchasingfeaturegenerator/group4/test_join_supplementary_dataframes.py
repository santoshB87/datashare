# coding: latin-1
from __future__ import absolute_import, print_function

from pyspark.sql.dataframe import DataFrame as DF

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.featuregeneratorbase import *


class DummyFeatureGenerator(CMPFeatureGenerator):
    """base class is an abstract class hence can't be instantiated. Need to instantiate it in order to test its method(s)"""

    def __init__(self):
        super(DummyFeatureGenerator, self).__init__()

    def get_data(self):
        pass

    @staticmethod
    def add_description_metadata(df, dimension_attribute_grain={}):
        return df


class TestJoinSupplementaryDataframes(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")
        cls.df = cls.sqlContext.createDataFrame([('Alice', 'Beans', 'London', 'Instore')],
                                                ['Customer', 'Product', 'Store', 'Channel'])
        cls.df2 = cls.sqlContext.createDataFrame([('Alice', 1)], ['Name', 'Age'])

    def test_if_main_df_is_not_a_dataframe_raise_an_error(self):
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(TypeError, 'must be a pyspark DataFrame object'):
            fg.join_supplementary_dataframes(main_df='not a dataframe', supplementary_dfs=[], dimension_grain=[])

    def test_main_df_not_having_all_fields_from_dimension_grain_raises_error(self):
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(RuntimeError,
                                     'Main df with schema .* does not include all fields from dimension grain'):
            fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=[],
                                             dimension_grain={'Customer', 'Product', 'Store', 'Channel', 'Promotion'})

    def test_if_supplementary_dfs_is_not_a_list_raise_an_error(self):
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(TypeError, 'must be a list'):
            fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs='this is not a list',
                                             dimension_grain={'Customer'})

    def test_each_element_of_supplementary_dfs_is_a_dataframe(self):
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(TypeError, 'supplementary_dfs must be a list of dataframes'):
            fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=['not a dataframe'],
                                             dimension_grain={'Customer'})

    def test_dimension_grain_must_be_a_set(self):
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(TypeError, 'Value supplied for dimension_grain must be a set'):
            fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=[], dimension_grain='not a set')

    def test_unknown_dimension_in_dimension_grain_raises_valueerror(self):
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(ValueError, ' is not a valid dimension. Valid dimensions are '):
            fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=[],
                                             dimension_grain={'Product', 'Customer', 'Stroe'})

    def test_supplementary_df_having_no_fields_from_dimension_grain_raises_error(self):
        supplementary_df1 = self.sqlContext.createDataFrame([('Alice', 1)], ['name', 'age'])
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(RuntimeError,
                                     'Supplementary df with schema .* does not include any fields from dimension grain'):
            fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=[supplementary_df1],
                                             dimension_grain={'Product', 'Customer', 'Store', 'Channel'})

    def test_with_valid_main_df_and_one_supplementary_df_a_dataframe_is_returned(self):
        supplementary_df1 = self.sqlContext.createDataFrame([('Alice', 1)], ['Customer', 'age'])
        fg = DummyFeatureGenerator()
        joined_df = fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=[supplementary_df1],
                                                     dimension_grain={'Customer', 'Product', 'Store', 'Channel'})
        self.assertIsInstance(joined_df, DF)

    def test_with_valid_main_df_and_one_supplementary_df_returned_dataframe_contains_all_columns_from_both(self):
        supplementary_df1 = self.sqlContext.createDataFrame([('Alice', 1)], ['Customer', 'Age'])
        fg = DummyFeatureGenerator()
        joined_df = fg.join_supplementary_dataframes(main_df=self.df, supplementary_dfs=[supplementary_df1],
                                                     dimension_grain={'Customer', 'Product', 'Store', 'Channel'})
        self.assertEquals(
            [field.name for field in joined_df.schema.fields].sort(),
            ['Age', 'Customer', 'Product', 'Store', 'Channel'].sort()
        )

    def test_with_valid_main_df_and_two_supplementary_dfs_returned_dataframe_contains_all_columns_from_all(self):
        supplementary_df1 = self.sqlContext.createDataFrame([('Alice', 1)], ['Customer', 'Age'])
        supplementary_df2 = self.sqlContext.createDataFrame([('Beans', 'Canned Food')], ['Product', 'ProductGroup'])
        fg = DummyFeatureGenerator()
        joined_df = fg.join_supplementary_dataframes(main_df=self.df,
                                                     supplementary_dfs=[supplementary_df1, supplementary_df2],
                                                     dimension_grain={'Customer', 'Product', 'Store', 'Channel'})
        self.assertEquals(
            [field.name for field in joined_df.schema.fields].sort(),
            ['Age', 'Customer', 'Product', 'Store', 'Channel', 'ProductGroup'].sort()
        )

    def test_when_supplementary_df_does_not_have_uniqueness_over_dimension_grain_fields_an_error_is_raised(self):
        """
        it is important that each supplementary_df is unique over the fields on which it is to be joined to main_df. If
        it is not then the join will cause duplicate rows to be returned.
        Checking for uniqueness is an expensive operation however its a necessary one. The old adage "I would rather have
        it slow and correct than fast and wrong" applies here. Integrity of our data is paramount, and is more
        important than the speed at which it can be delivered.
        """
        supplementary_df1 = self.sqlContext.createDataFrame([('Alice', 1),('Alice', 1)], ['Customer', 'Age'])
        fg = DummyFeatureGenerator()
        with self.assertRaisesRegexp(RuntimeError,
                                     'Supplementary df with schema .* is not unique over fields .* duplicate rows exist.'):
            fg.join_supplementary_dataframes(main_df=self.df,
                                            supplementary_dfs=[supplementary_df1],
                                            dimension_grain={'Customer', 'Product', 'Store', 'Channel'})

    def test_all_rows_from_main_df_are_returned_even_when_there_are_no_matching_rows_in_supplementary_df(self):
        supplementary_df1 = self.sqlContext.createDataFrame([('Jake', 1)], ['Customer', 'Age'])
        fg = DummyFeatureGenerator()
        joined_df = fg.join_supplementary_dataframes(main_df=self.df,
                                                     supplementary_dfs=[supplementary_df1],
                                                     dimension_grain={'Customer', 'Product', 'Store', 'Channel'})
        joined_df = joined_df.where(joined_df.Customer != 'Jake')
        self.assertEqual(self.df.count(), joined_df.count())

    def test_all_rows_from_supplementary_df_are_returned_even_when_there_are_no_matching_rows_in_main_df(self):
        supplementary_df1 = self.sqlContext.createDataFrame([('Jake', 1)], ['Customer', 'Age'])
        fg = DummyFeatureGenerator()
        joined_df = fg.join_supplementary_dataframes(main_df=self.df,
                                                     supplementary_dfs=[supplementary_df1],
                                                     dimension_grain={'Customer', 'Product', 'Store', 'Channel'})
        joined_df = joined_df.where(joined_df.Customer == 'Jake')
        self.assertEqual(supplementary_df1.count(), joined_df.count())


