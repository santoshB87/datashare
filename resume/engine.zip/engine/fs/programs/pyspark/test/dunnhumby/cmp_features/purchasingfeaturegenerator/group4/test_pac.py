# coding: latin-1
from __future__ import absolute_import, print_function
import pyspark.sql.functions as funcs
from pyspark.sql.types import StructType, StructField, StringType
import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestPACs(test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_features_calculated_correctly_for_pacs(self):
        """
        At the time of writing this test demonstrates how to calculate features for a product affinity cluster (PAC)
        however it should be realised that a PAC is simply a definition of a collection of products, and there are
        other things that can take this general form (e.g. a nomination). Hence, even though this test explicitly refers
        to PACs, in the more general form it demonstrates how to calculate features over an arbitrary grouping of
        products.
        A characteristic of PACs is that a Product can appear in more than 1 PAC. i.e. There is a many-to-many
        relationship between Product & PAC. This is different from the normal case where there is a one-to-many
        relationship between Product attribute and Product. This characteristic warrants special treatment as
        is demonstrated in this test.
        :return:
        """
        df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerLeiaOrgana)
        )
        df = df.join(self.product_entity, 'Product')
        pac1_name = "Feta and beans PAC"
        pac2_name = "CheddarMature and beans PAC"
        pac3_name = "Cheese and beans PAC"
        product_affinity_clusters = [
            {
                "name": pac1_name,
                "product_attribute": "Product",
                "members": [self.productBakedBeans, self.productFetaCheeseMild]
            }
            ,
            {
                "name": pac2_name,
                "product_attribute": "Product",
                "members": [self.productBakedBeans, self.productCheddarMature]
            }
            ,
            {
                "name": pac3_name,
                "product_attribute": "Subgroup",
                "members": ['Cheese', 'Beans']
            }
        ]
        all_pac_transactions_df = self.sqlContext.createDataFrame([], df.schema)
        all_pac_products = []
        for product_affinity_cluster in product_affinity_clusters:
            # Feature generator expects the Products passed to product_attributes_df to be unique. Given a Product can be
            # in multiple PACs and we are calculating features for multiple PACs at the same time (i.e. there is a
            # many-to-many relationship between Product and PaC) we ensure uniqueness by concatenating the PAC name to
            # the Product identifier.
            # The data gets aggregated to PAC anyway so the concatenated values will never be visible, they simply
            # exist to ensure uniqueness
            # For each PAC we :
            #  1)get the relevant transactions and append them to the transactions gotten for earlier PACs
            #  2)get the Products in each PAC and append them to the products gotten for earlier PACs
            all_pac_transactions_df = all_pac_transactions_df.unionAll(
                df[df[product_affinity_cluster['product_attribute']].isin(product_affinity_cluster['members'])]
                    .withColumn(
                    'Product',
                    funcs.concat(
                        df['Product'],
                        funcs.lit(product_affinity_cluster['name'])
                    )
                )
            )
            all_pac_products = all_pac_products + [
                (member.Product + product_affinity_cluster['name'], product_affinity_cluster['name'])
                for member in self.product_entity[
                    self.product_entity[product_affinity_cluster['product_attribute']]
                        .isin(product_affinity_cluster['members']
                              )
                ].collect()
            ]
        all_pac_products_df = self.sqlContext.createDataFrame(
            all_pac_products,
            StructType([StructField("Product", StringType(), True), StructField("PAC", StringType(), True)])
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=all_pac_transactions_df,
            product_attribute='PAC',
            store_attribute='All',
            channel_attribute='All',
            product_attributes_df=all_pac_products_df
        ).collect()
        self.assertEqual(len(output_df), 6)
        #Check values for pac1
        leiaorgana_fetaandbeans_features = [row for row in output_df if (row.Customer == self.customerLeiaOrgana) & (row.Product == pac1_name)]
        self.assertEqual(leiaorgana_fetaandbeans_features[0]['Baskets_1w52w'], 1)
        darthvadar_fetaandbeans_features = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (row.Product == pac1_name)]
        self.assertEqual(darthvadar_fetaandbeans_features[0]['Baskets_1w52w'], 2)
        #Check values for pac2
        leiaorgana_cheddarmatureandbeans_features = [row for row in output_df if (row.Customer == self.customerLeiaOrgana) & (row.Product == pac2_name)]
        self.assertEqual(leiaorgana_cheddarmatureandbeans_features[0]['Baskets_1w52w'], 4)
        darthvadar_cheddarmatureandbeans_features = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (row.Product == pac2_name)]
        self.assertEqual(darthvadar_cheddarmatureandbeans_features[0]['Baskets_1w52w'], 10)
        #Check values for pac3
        leiaorgana_cheeseandbeans_features = [row for row in output_df if (row.Customer == self.customerLeiaOrgana) & (row.Product == pac3_name)]
        self.assertEqual(leiaorgana_cheeseandbeans_features[0]['Baskets_1w52w'], 4)
        darthvadar_cheeseandbeans_features = [row for row in output_df if (row.Customer == self.customerDarthVadar) & (row.Product == pac3_name)]
        self.assertEqual(darthvadar_cheeseandbeans_features[0]['Baskets_1w52w'], 12)
