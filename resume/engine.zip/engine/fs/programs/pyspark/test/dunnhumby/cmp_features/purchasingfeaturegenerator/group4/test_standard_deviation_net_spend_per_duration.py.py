# coding: latin-1
from __future__ import absolute_import, print_function
import datetime
from decimal import *
from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType, DecimalType
import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *
from pyspark.sql.functions import when, lit


class TestStandardDeviationNetSpendPerDuration \
            (test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_stddev_netspend_per_duration(self):
        """
        test standard deviation of the number of baskets that a customer buys each
        duration (week/day/etc...)
        """
        data = [
            ('000', self.as_at - datetime.timedelta(weeks=1), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('001', self.as_at - datetime.timedelta(weeks=1), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('002', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('003', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('004', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('005', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('006', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('007', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('008', self.as_at - datetime.timedelta(weeks=1), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('008', self.as_at - datetime.timedelta(weeks=2), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('009', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('010', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('011', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('012', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('013', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('014', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('015', self.as_at - datetime.timedelta(weeks=2), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('016', self.as_at - datetime.timedelta(weeks=3), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('017', self.as_at - datetime.timedelta(weeks=3), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('018', self.as_at - datetime.timedelta(weeks=3), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('019', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('020', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('021', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('022', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('023', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('024', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('025', self.as_at - datetime.timedelta(weeks=3), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('026', self.as_at - datetime.timedelta(weeks=4), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('027', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('028', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('029', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('030', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('031', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('032', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('033', self.as_at - datetime.timedelta(weeks=4), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('034', self.as_at - datetime.timedelta(weeks=5), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('035', self.as_at - datetime.timedelta(weeks=5), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('036', self.as_at - datetime.timedelta(weeks=5), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('037', self.as_at - datetime.timedelta(weeks=5), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('038', self.as_at - datetime.timedelta(weeks=5), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('039', self.as_at - datetime.timedelta(weeks=5), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('040', self.as_at - datetime.timedelta(weeks=5), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('041', self.as_at - datetime.timedelta(weeks=6), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('042', self.as_at - datetime.timedelta(weeks=6), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('043', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('044', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('045', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('046', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('047', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('048', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('049', self.as_at - datetime.timedelta(weeks=6), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('050', self.as_at - datetime.timedelta(weeks=52), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('051', self.as_at - datetime.timedelta(weeks=52), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('052', self.as_at - datetime.timedelta(weeks=52), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('053', self.as_at - datetime.timedelta(weeks=52), self.productCheddarMature, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('054', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('055', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('056', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('057', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('058', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('059', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25),
            ('060', self.as_at - datetime.timedelta(weeks=52), self.productFetaCheeseMild, self.customerLukeSkywalker,
             self.storeBG, self.channelInstore, 1, self.spendAmount_1_99, self.netSpendAmount_1_99, self.Discount_0_25)
        ]
        schema = StructType(
            [
                StructField("Basket", StringType(), True),
                StructField("Date", DateType(), True),
                StructField("Product", StringType(), True),
                StructField("Customer", StringType(), True),
                StructField("Store", StringType(), True),
                StructField("Channel", StringType(), True),
                StructField("Quantity", IntegerType(), True),
                StructField("SpendAmount", DecimalType(18, 2), True),
                StructField("NetSpendAmount", DecimalType(18, 2), True),
                StructField("DiscountAmount", DecimalType(18, 2), True)
            ]
        )
        input_df = self.sqlContext.createDataFrame(data, schema)
        """
        At the time of writing, when this df is run through this code:

        df = _add_fields_week_number_and_recency_days(as_at, df)
        df.groupBy(['Customer', 'Product', 'week_number']).agg(
            f.sum(df.NetSpendAmount).alias('SumNetSpend'), 
            f.count(df.NetSpendAmount).alias('Cnt')
        ).orderBy(['Product', 'week_number']).toPandas()

        (_add_fields_week_number_and_recency_days() is in class CMPFeatureGenerator)

        it outputs:

                Customer	Product	week_number	SumNetSpend	Cnt
        0	Luke Skywalker	CheddarMature	1	3.98	2
        1	Luke Skywalker	CheddarMature	2	1.99	1
        2	Luke Skywalker	CheddarMature	3	5.97	3
        3	Luke Skywalker	CheddarMature	4	1.99	1
        4	Luke Skywalker	CheddarMature	5	1.99	1
        5	Luke Skywalker	CheddarMature	6	3.98	2
        6	Luke Skywalker	CheddarMature	52	7.96	4
        7	Luke Skywalker	FetaCheeseMild	1	13.93	7
        8	Luke Skywalker	FetaCheeseMild	2	13.93	7
        9	Luke Skywalker	FetaCheeseMild	3	13.93	7
        10	Luke Skywalker	FetaCheeseMild	4	13.93	7
        11	Luke Skywalker	FetaCheeseMild	5	11.94	6
        12	Luke Skywalker	FetaCheeseMild	6	13.93	7
        13	Luke Skywalker	FetaCheeseMild	52	13.93	7

        which is a good dataset for testing this feature
        """
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All',
            channel_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 2)
        self.assertEqual([row for row in output_df if row['Product'] == self.productCheddarMature][0][
                             'StdDevNetSpendPerDuration_1w52w'], Decimal('2.297854'))
        self.assertEqual([row for row in output_df if row['Product'] == self.productFetaCheeseMild][0][
                             'StdDevNetSpendPerDuration_1w52w'], Decimal('0.752149'))

        input_df = input_df.withColumn(
            'IsCheddar',
            when(input_df.Product == self.productCheddarMature, lit(True)).otherwise(lit(False))
        )
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All',
            channel_attribute='All',
            feature_filters=[['Cheddar']]
        ).collect()
        self.assertEqual(len(output_df), 2)
        self.assertEqual([row for row in output_df if row['Product'] == self.productCheddarMature][0][
                             'StdDevNetSpendPerDuration_Cheddar_1w52w'], Decimal('2.297854'))
        self.assertEqual([row for row in output_df if row['Product'] == self.productFetaCheeseMild][0][
                             'StdDevNetSpendPerDuration_Cheddar_1w52w'], Decimal('0.0'))