# coding: latin-1
from __future__ import absolute_import, print_function

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestStoreCount(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_two_stores_have_purchases(self):
        input_df = self.df.filter(
            (self.df.Store == self.storeBG) |
            (self.df.Store == self.storeEA)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            store_attribute='All',
            product_attribute='All',
            customer_attribute='All',
            channel_attribute='All'
        ).select('StoreCount_1w52w').collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(2, output_df[0]['StoreCount_1w52w'])