# coding: latin-1
from __future__ import absolute_import, print_function

from decimal import *

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *

logger = logging.getLogger(__name__)

class TestAveragePurchaseCycle(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_averageprice_one_customer_one_product_four_purchases(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerLandoCalrissian
        ).filter(
            self.df.Product == self.productWholeMilk
        ).filter(
            (self.df.Store == self.storeBG)
        ).filter(
            (self.df.Channel == self.channelInstore)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['AveragePurchaseCycle_1w13w'], Decimal('7'))
        self.assertEqual(output_df[0]['AveragePurchaseCycle_1w26w'], Decimal('7'))
        self.assertEqual(output_df[0]['AveragePurchaseCycle_1w52w'], Decimal('7'))
        self.assertEqual(output_df[0]['AveragePurchaseCycle_1w56w'], Decimal('7'))

    def test_averagepurchasecycle_only_one_purchase_should_not_cause_divide_by_zero(self):
        input_df = self.df.filter(
            self.df.Customer == self.customerJynErso
        ).filter(
            self.df.Product == self.productWholeMilk
        ).filter(
            (self.df.Store == self.storeBG)
        ).filter(
            (self.df.Channel == self.channelInstore)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(output_df[0]['Baskets_1w13w'], 1) #ensures we do have just one purchase
        self.assertEqual(output_df[0]['AveragePurchaseCycle_1w13w'], None)


