# coding: latin-1
from __future__ import absolute_import, print_function

from decimal import *

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestCyclesSinceLastPurchase(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):

    def test_NetSpend_xw_two_customers_two_products_one_store_aggregated_to_all_customers_all_products(self):
        input_df = self.df.filter(
            (self.df.Customer == self.customerLandoCalrissian)
        ).filter(
            (self.df.Product == self.productWholeMilk)
        ).filter(
            self.df.Store == self.storeBG
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df
        ).collect()
        self.assertEqual(output_df[0]['CyclesSinceLastPurchase_1w56w'], Decimal('5.00'))

