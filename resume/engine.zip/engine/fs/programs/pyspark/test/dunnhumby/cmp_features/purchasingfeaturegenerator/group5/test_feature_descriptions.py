# coding: latin-1
from __future__ import absolute_import, print_function
from dunnhumby.cmp_features.purchasingfeaturegenerator import PurchasingFeatureGenerator
import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestFeatureDescriptions(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):

    def test_get_duration_constituents(self):
        self.assertEqual((1, 'week', 52, 'weeks'), PurchasingFeatureGenerator._get_duration_constituents('Baskets_1w52w'))
        self.assertEqual((12, 'weeks', 52, 'weeks'), PurchasingFeatureGenerator._get_duration_constituents('Baskets_12w52w'))
        self.assertEqual((156, 'days', 157, 'days'), PurchasingFeatureGenerator._get_duration_constituents('Baskets_156d157d'))
        self.assertEqual((1, 'year', 2, 'years'), PurchasingFeatureGenerator._get_duration_constituents('Baskets_1y2y'))
        self.assertEqual((1, 'month', 2, 'months'), PurchasingFeatureGenerator._get_duration_constituents('Baskets_1m2m'))
        self.assertEqual((1, 'month', 1, 'month'), PurchasingFeatureGenerator._get_duration_constituents('Baskets_1m1m'))

    def test_feature_descriptions(self):
        df = self.df.filter(self.df.Product == 'nothing')
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            customer_attribute='All',
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            timeofday_attribute='All'
        )
        self.assertEqual(
            "Tally of baskets bought between 1 week ago and 52 weeks ago (inclusive)",
            [field for field in output_df.schema.fields if field.name == 'Baskets_1w52w'][0].metadata['Description']
        )
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            customer_attribute='All',
            product_attribute='Product',
            store_attribute='All',
            channel_attribute='All',
            timeofday_attribute='All'
        )
        self.assertEqual(
            "Tally of baskets containing Product bought between 1 week ago and 52 weeks ago (inclusive)",
            [field for field in output_df.schema.fields if field.name == 'Baskets_1w52w'][0].metadata['Description']
        )
        product_attributes_df = self.sqlContext.createDataFrame(
            [(self.productFetaCheeseMild, 'Cheese'), (self.productCheddarMature, 'Cheese')], ['Product', 'Subgroup'])
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            customer_attribute='All',
            product_attribute='Subgroup',
            store_attribute='All',
            channel_attribute='All',
            timeofday_attribute='All',
            product_attributes_df=product_attributes_df
        )
        self.assertEqual(
            "Tally of baskets containing Subgroup bought between 1 week ago and 52 weeks ago (inclusive)",
            [field for field in output_df.schema.fields if field.name == 'Baskets_1w52w'][0].metadata['Description']
        )
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            customer_attribute='Customer',
            product_attribute='Subgroup',
            store_attribute='All',
            channel_attribute='All',
            timeofday_attribute='All',
            product_attributes_df=product_attributes_df
        )
        self.assertEqual(
            "Tally of baskets containing Subgroup bought by Customer bought between 1 week ago and 52 weeks ago (inclusive)",
            [field for field in output_df.schema.fields if field.name == 'Baskets_1w52w'][0].metadata['Description']
        )


    def test_Baskets_feature_descriptions(self):
        self.assertEqual(
            "Tally of baskets containing Product bought by Customer bought between 1 week ago and 52 weeks ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w52w',
                                                                 {
                                                                     'ProductAttribute': 'Product',
                                                                     'CustomerAttribute': 'Customer'
                                                                 })['Description'])
        self.assertEqual(
            "Tally of baskets containing Product bought between 1 week ago and 1 week ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w1w',
                                                                 {
                                                                     'ProductAttribute': 'Product'
                                                                 })['Description'])
        self.assertEqual(
            "Tally of baskets bought by Customer bought between 1 week ago and 1 week ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w1w',
                                                                 {
                                                                     'CustomerAttribute': 'Customer'
                                                                 })['Description'])
        self.assertEqual(
            "Tally of baskets bought in Store bought between 1 week ago and 1 week ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w1w',
                                                                 {
                                                                     'StoreAttribute': 'Store'
                                                                 })['Description'])
        self.assertEqual(
            "Tally of baskets bought in Channel bought between 1 week ago and 1 week ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w1w',
                                                                 {
                                                                     'ChannelAttribute': 'Channel'
                                                                 })['Description'])
        self.assertEqual(
            "Tally of baskets containing Product bought by Customer bought in Store bought in Channel bought between 1 week ago and 1 week ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w1w',
                                                                 {
                                                                     'StoreAttribute': 'Store',
                                                                     'ProductAttribute': 'Product',
                                                                     'CustomerAttribute': 'Customer',
                                                                     'ChannelAttribute': 'Channel'
                                                                 })['Description'])
        self.assertEqual(
            "Tally of baskets containing Subgroup bought by CustomerGender bought in Store bought in Channel bought between 1 week ago and 1 week ago (inclusive)",
            PurchasingFeatureGenerator._get_baskets_feature_description('Baskets_1w1w',
                                                                 {
                                                                     'StoreAttribute': 'Store',
                                                                     'ProductAttribute': 'Subgroup',
                                                                     'CustomerAttribute': 'CustomerGender',
                                                                     'ChannelAttribute': 'Channel'
                                                                 })['Description'])
