# coding: latin-1
from __future__ import absolute_import, print_function
from decimal import *
import datetime
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType, \
    DateType, IntegerType, DecimalType

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestFeatureFilters(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_valid_feature_filters(self):
        l = [['a', 'b'], 'c']
        self.assertEquals(PurchasingFeatureGenerator._check_feature_filters(l), l)
        l = [['b', 'a'], 'c']
        self.assertEquals(PurchasingFeatureGenerator._check_feature_filters(l), [['a', 'b'], ['c']])
        l = ['a']
        self.assertEquals(PurchasingFeatureGenerator._check_feature_filters(l), [['a']])
        l = 'a'
        self.assertEquals(PurchasingFeatureGenerator._check_feature_filters(l), [[l]])
        l = [['a']]
        self.assertEquals(PurchasingFeatureGenerator._check_feature_filters(l), l)

    def test_check_integer_feature_filter_raises_error(self):
        with self.assertRaisesRegexp(RuntimeError,
                                     "Each feature filter must be either a string or a list of strings. 1 is neither"):
            PurchasingFeatureGenerator._check_feature_filters(1)
        with self.assertRaisesRegexp(RuntimeError,
                                     "Each feature filter must be either a string or a list of strings. 1 is neither"):
            PurchasingFeatureGenerator._check_feature_filters([1])
        with self.assertRaisesRegexp(RuntimeError,
                                     "Each feature filter must be either a string or a list of strings. 1 is neither"):
            PurchasingFeatureGenerator._check_feature_filters(['a', [1]])

    def test_isfuel_and_isluxury(self):
        as_at = datetime.date(2017, 2, 2)
        schema = StructType(
            [
                StructField("Basket", StringType(), True),
                StructField("Date", DateType(), True),
                StructField("Product", StringType(), True),
                StructField("Customer", StringType(), True),
                StructField("Store", StringType(), True),
                StructField("Channel", StringType(), True),
                StructField("Quantity", IntegerType(), True),
                StructField("SpendAmount", DecimalType(18, 2), True),
                StructField("NetSpendAmount", DecimalType(18, 2), True),
                StructField("DiscountAmount", DecimalType(18, 2), True)
            ]
        )
        l = [
            ('000', as_at - datetime.timedelta(weeks=4), 'Petrol', 'John Doe', 'Store1', 'Channel1', 3, Decimal(4.0),
             Decimal(3.50), Decimal(0.5)),
            ('001', as_at - datetime.timedelta(weeks=5), 'Diesel', 'Jane Doe', 'Store1', 'Channel1', 4, Decimal(3.0),
             Decimal(2.50), Decimal(0.5)),
            ('002', as_at - datetime.timedelta(weeks=3), 'Apples', 'John Doe', 'Store1', 'Channel1', 5, Decimal(2.0),
             Decimal(1.50), Decimal(0.5))
        ]
        df = self.sqlContext.createDataFrame(l, schema)
        product_attributes_df = self.sqlContext.createDataFrame(
            [
                ('Petrol', True, True),
                ('Diesel', True, False),
                ('Apples', False, True)
            ], ['Product', 'IsFuel', 'IsLuxury']
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            product_attribute='All',
            customer_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            product_attributes_df=product_attributes_df,
            feature_filters=[['Fuel'], ['Luxury'], ['Luxury', 'Fuel']]
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['Baskets_1w52w'], 3)
        self.assertEqual(output_df[0]['Baskets_Fuel_1w52w'], 2)
        self.assertEqual(output_df[0]['Baskets_Luxury_1w52w'], 2)
        self.assertEqual(output_df[0]['Baskets_FuelLuxury_1w52w'], 1)
        self.assertEqual(output_df[0]['BasketWeeks_1w52w'], 3)
        self.assertEqual(output_df[0]['BasketWeeks_Fuel_1w52w'], 2)
        self.assertEqual(output_df[0]['BasketWeeks_Luxury_1w52w'], 2)
        self.assertEqual(output_df[0]['Quantity_1w52w'], 12)
        self.assertEqual(output_df[0]['Quantity_Fuel_1w52w'], 7)
        self.assertEqual(output_df[0]['Quantity_Luxury_1w52w'], 8)
        self.assertEqual(output_df[0]['Quantity_FuelLuxury_1w52w'], 3)
        self.assertEqual(output_df[0]['CustomerCount_1w52w'], 2)
        self.assertEqual(output_df[0]['CustomerCount_Fuel_1w52w'], 2)
        self.assertEqual(output_df[0]['CustomerCount_Luxury_1w52w'], 1)
        self.assertEqual(output_df[0]['CustomerCount_FuelLuxury_1w52w'], 1)
        self.assertEqual(output_df[0]['ProductCount_1w52w'], 3)
        self.assertEqual(output_df[0]['ProductCount_Fuel_1w52w'], 2)
        self.assertEqual(output_df[0]['ProductCount_Luxury_1w52w'], 2)
        self.assertEqual(output_df[0]['ProductCount_FuelLuxury_1w52w'], 1)
        self.assertEqual(output_df[0]['RecencyDays_1w52w'], 21)
        self.assertEqual(output_df[0]['RecencyDays_Fuel_1w52w'], 28)
        self.assertEqual(output_df[0]['min_purchase_date_1w52w'], datetime.date(2016, 12, 29))
        self.assertEqual(output_df[0]['min_purchase_date_Fuel_1w52w'], datetime.date(2016, 12, 29))
        self.assertEqual(output_df[0]['max_purchase_date_1w52w'], datetime.date(2017, 1, 12))
        self.assertEqual(output_df[0]['max_purchase_date_Fuel_1w52w'], datetime.date(2017, 1, 5))
        self.assertEqual(output_df[0]['GrossSpend_1w52w'], 9)
        self.assertEqual(output_df[0]['GrossSpend_Fuel_1w52w'], 7)
        self.assertEqual(output_df[0]['NetSpend_1w52w'], 7.5)
        self.assertEqual(output_df[0]['NetSpend_Fuel_1w52w'], 6)
        self.assertEqual(output_df[0]['Discount_1w52w'], 1.5)
        self.assertEqual(output_df[0]['Discount_Fuel_1w52w'], 1.0)

    def test_grossspend_excluding_fuel(self):
        as_at = datetime.date(2017, 2, 2)
        schema = StructType(
            [
                StructField("Basket", StringType(), True),
                StructField("Date", DateType(), True),
                StructField("Product", StringType(), True),
                StructField("Customer", StringType(), True),
                StructField("Store", StringType(), True),
                StructField("Channel", StringType(), True),
                StructField("Quantity", IntegerType(), True),
                StructField("SpendAmount", DecimalType(18, 2), True),
                StructField("NetSpendAmount", DecimalType(18, 2), True),
                StructField("DiscountAmount", DecimalType(18, 2), True)
            ]
        )
        l = [
            ('000', as_at - datetime.timedelta(weeks=4), 'Petrol', 'John Doe', 'Store1', 'Channel1', 3, Decimal(4.0),
             Decimal(3.50), Decimal(0.5)),
            ('001', as_at - datetime.timedelta(weeks=5), 'Diesel', 'Jane Doe', 'Store1', 'Channel1', 4, Decimal(3.0),
             Decimal(2.50), Decimal(0.5)),
            ('002', as_at - datetime.timedelta(weeks=3), 'Apples', 'John Doe', 'Store1', 'Channel1', 5, Decimal(2.0),
             Decimal(1.50), Decimal(0.5))
        ]
        df = self.sqlContext.createDataFrame(l, schema)
        product_attributes_df = self.sqlContext.createDataFrame(
            [
                ('Petrol', True, True),
                ('Diesel', True, False),
                ('Apples', False, True)
            ], ['Product', 'IsFuel', 'IsLuxury']
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            product_attributes_df=product_attributes_df,
            feature_filters='Fuel'
        )
        output_df = output_df.select(
            output_df.Customer,
            (output_df.GrossSpend_1w52w - output_df.GrossSpend_Fuel_1w52w).alias('GrossSpend_ExcludingFuel_1w52w')
        )
        self.assertEqual(output_df.count(), 2)
        self.assertEqual(
            output_df.where(output_df.Customer == 'John Doe').collect()[0]['GrossSpend_ExcludingFuel_1w52w'], 2.0)
        self.assertEqual(
            output_df.where(output_df.Customer == 'Jane Doe').collect()[0]['GrossSpend_ExcludingFuel_1w52w'], 0.0)

    def test_basketweeks_with_feature_filters(self):
        """BasketWeeks is fairly unique in the way it is calculated and as a consequence has to be treated
        differently where feature_filters are being used"""
        as_at = datetime.date(2017, 2, 2)
        schema = StructType(
            [
                StructField("Basket", StringType(), True),
                StructField("Date", DateType(), True),
                StructField("Product", StringType(), True),
                StructField("Customer", StringType(), True),
                StructField("Store", StringType(), True),
                StructField("Channel", StringType(), True),
                StructField("Quantity", IntegerType(), True),
                StructField("SpendAmount", DecimalType(18, 2), True),
                StructField("NetSpendAmount", DecimalType(18, 2), True),
                StructField("DiscountAmount", DecimalType(18, 2), True)
            ]
        )
        l = [
            ('000', as_at - datetime.timedelta(weeks=4), 'Petrol', 'John Doe', 'Store1', 'Channel1', 3, Decimal(4.0),
             Decimal(3.50), Decimal(0.5)),
            ('002', as_at - datetime.timedelta(weeks=4), 'Apples', 'John Doe', 'Store1', 'Channel1', 5, Decimal(2.0),
             Decimal(1.50), Decimal(0.5))
        ]
        df = self.sqlContext.createDataFrame(l, schema)
        product_attributes_df = self.sqlContext.createDataFrame(
            [
                ('Petrol', True),
                ('Diesel', True),
                ('Apples', False)
            ], ['Product', 'IsFuel']
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=df,
            product_attribute='All',
            customer_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            product_attributes_df=product_attributes_df,
            feature_filters=[['Fuel']]
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['BasketWeeks_1w52w'], 1)
        self.assertEqual(output_df[0]['BasketWeeks_Fuel_1w52w'], 1)
