import unittest
from dunnhumby import contexts
from dunnhumby.cmp_features.purchasingfeaturegenerator import PurchasingFeatureGenerator
from pyspark.sql.types import *


class TestFilterOutPurchasesWithMissingDimensionAttributes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_filter_out_purchases_with_missing_dimension_attributes(self):

        schema = StructType([StructField("customer", StringType(), True),
                             StructField("product", StringType(), True),
                             StructField("channel", StringType(), True),
                             StructField("store", StringType(), True),
                             StructField("checksum", IntegerType(), True)])
        l = [( None,     'Something', 'Somehow', 'Somewhere', 1), #Should be excluded when customer_attribute is customer
             ('Someone',  None,       'Somehow', 'Somewhere', 3), #Should be excluded when product_attribute is product
             ('Someone', 'Something',  None,     'Somewhere', 5), #Should not be excluded when channel_attribute is All
             ('Someone', 'Something', 'Somehow',  None,       7)] #Should not be excluded when store_attribute is All
        purchases_df = TestFilterOutPurchasesWithMissingDimensionAttributes.sqlContext.createDataFrame(l, schema)

        pfg = PurchasingFeatureGenerator()

        filtered_purchases_df = pfg.filter_out_purchases_with_missing_dimension_attributes(purchases_df, 'customer',
                                                                                            'product', 'All', 'All')
        self.assertEquals(filtered_purchases_df.groupBy().sum('checksum').collect()[0][0], 12)
