# coding: latin-1
from __future__ import absolute_import, print_function
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType
import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestJoinSupplementaryDataframesInPurchasingFeaturesgenerator(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_customer_supplementary_df_is_joined_to_features(self):
        """
        aim here is to ensure that customer_df is joined on to features generated in purchasingfeaturegenerator.
        Notice that the customers for which the features are generated (Darth Vadar, Han Solo) is different from the
        customers supplied in customer_df (Darth Vadar). This is deliberate. There is no insistence that
        the supplied supplementary dataframe contains a match for every row in the generated features.
        :return:
        """
        input_df = self.df.filter(
            (self.df.Customer == self.customerDarthVadar) |
            (self.df.Customer == self.customerHanSolo)
        )
        customer_df = self.sqlContext.createDataFrame([(self.customerDarthVadar, 83)],
                                                      StructType(
                                                          [
                                                              StructField('Customer', StringType(), True),
                                                              StructField('Age', LongType(), True)
                                                          ]
                                                      )
                                                      )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            supplementary_dataframes=[customer_df]
        )
        self.assertEqual(output_df.count(), 2)
        self.assertIn('Age', [field.name for field in output_df.schema.fields])
        self.assertEqual(output_df.where(output_df.Customer == self.customerDarthVadar).first()['Age'], 83)
