# coding: latin-1
from __future__ import absolute_import, print_function
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from pyspark.sql.functions import from_unixtime, unix_timestamp

import test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder
from dunnhumby.cmp_features.purchasingfeaturegenerator import *


class TestTimeOfDayDimension(
    test.dunnhumby.cmp_features.purchasingfeaturegenerator.test_features_builder.TestFeaturesBuilder):
    def test_purchases_df_cannot_have_both_date_and_datetime_fields(self):
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        input_df = self.df.withColumn(
            'DateTime',
            from_unixtime(unix_timestamp(self.df.Date) + 60, "YYYY-MM-dd HH:mm:ss").cast(TimestampType())
        )
        with self.assertRaisesRegexp(RuntimeError, 'purchases_df must contain either a column called Date or a column called DateTime, not both'):
            output_df = featuresBuilder.get_data(
                as_at=self.as_at,
                purchases_df=input_df,
                customer_attribute='All',
                product_attribute='All',
                store_attribute='All',
                channel_attribute='All',
                timeofday_attribute='All'
            )

    def test_datetime_column_causes_timeofday_dimension(self):
        """If the df has a datetime column instead of a date column a timeofday dimension
        should be returned.
        By default this dimension will be aggregated to "All". This is different behaviour to existing dimensions
        where by default the dimension is aggregated to the attribute with the same name as the dimension (i.e. the
        identifying attribute). The reasn for aggregating to "All" is so that existing behaviour is unchanged, we don't
        want to inadvertently slice the data over timeofday in case the end user has made a mistake and is not
        expecting the tiemofday dimension.
        """
        input_df = self.df.filter(
            self.df.Customer == self.customerJynErso
        ).filter(
            (self.df.Product == self.productWholeMilk)
        ).filter(
            (self.df.Store == self.storeBG)
        )
        # Replace Date field with Datetime
        input_df = input_df.withColumn(
            'DateTime',
            from_unixtime(unix_timestamp(input_df.Date) + (13 * 60 * 60) + 60, "YYYY-MM-dd HH:mm:ss").cast(
                TimestampType())
        ).drop(input_df.Date)
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        #note no value supplied for timeofday_attribute parameter
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All',
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertTrue('TimeOfDay' in output_df[0].__fields__)
        self.assertEqual(output_df[0]['TimeOfDay'], 'All')

    def test_date_column_causes_no_timeofday_dimension(self):
        """If the df has a date column then the returned dataframe should not contain a TimeOfDay dimension.
        """
        input_df = self.df.filter(
            self.df.Customer == self.customerJynErso
        ).filter(
            (self.df.Product == self.productWholeMilk)
        ).filter(
            (self.df.Store == self.storeBG)
        )
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All',
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All'
        ).collect()
        self.assertTrue('TimeOfDay' not in output_df[0].__fields__)

    def test_timeofday_attribute_generates_appropriate_features(self):
        # Simple test, just pick one transaction
        input_df = self.df.filter(
            self.df.Customer == self.customerJynErso
        ).filter(
            (self.df.Product == self.productWholeMilk)
        ).filter(
            (self.df.Store == self.storeBG)
        )
        # Replace Date field with Datetime
        input_df = input_df.withColumn(
            'DateTime',
            from_unixtime(unix_timestamp(input_df.Date) + (13 * 60 * 60) + 60, "YYYY-MM-dd HH:mm:ss").cast(TimestampType())
        ).drop(input_df.Date)
        featuresBuilder = PurchasingFeatureGenerator(rsd=0.0)
        output_df = featuresBuilder.get_data(
            as_at=self.as_at,
            purchases_df=input_df,
            customer_attribute='All',
            product_attribute='All',
            store_attribute='All',
            channel_attribute='All',
            timeofday_attribute='TimeOfDay'
        ).collect()
        self.assertEqual(len(output_df), 1)
        self.assertEqual(output_df[0]['BasketWeeks_1w13w'], 1)
        self.assertEqual(output_df[0]['TimeOfDay'], '13:01')
