"""
This package exsts simply as a place in which to put a single test class from under featuresbuilder so that it
can be tested in isolation using PyCharm's test running abilities.
Tests class files should only appear here temporarily
"""