# coding: latin-1
from __future__ import absolute_import, print_function
import unittest
import datetime
from decimal import *
from pyspark import SparkConf
from pyspark.sql.types import *
from dunnhumby import contexts


# inject a local spark context into our contexts module
conf = SparkConf().setMaster('local').setAppName('test').set('spark.sql.shuffle.partitions', 1)
contexts.sc(conf)


class TestFeaturesBuilder(unittest.TestCase):
    @classmethod
    def setUpClass(cls):

        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")
        cls.as_at = datetime.date(2017, 2, 2)
        # set up dataframes containing test data
        # Fake customers set up using soap opera characters well-known to UK audiences because, well, why not?
        cls.customerDarthVadar = 'Darth Vadar'
        cls.customerLukeSkywalker = 'Luke Skywalker'
        cls.customerObiWan = 'Obi Wan'
        cls.customerAdmiralAckbar = 'Admiral Ackbar'
        cls.customerLeiaOrgana = 'Leia Organa'
        cls.customerHanSolo = 'Han Solo'
        cls.customerChewbacca = 'Chewbacca'
        cls.customerLandoCalrissian = 'Lando Calrissian'
        cls.customerJynErso = 'Jyn Erso'
        cls.customerRey = 'Rey'
        cls.customerFinn = 'Finn'
        cls.productCheddarMature = 'Cheddar Mature'
        cls.productFetaCheeseMild = 'Feta Cheese Mild'
        cls.productBakedBeans = 'Baked Beans'
        cls.productSkimmedMilk = 'Semi-Skimmed Milk'
        cls.productWholeMilk = 'Whole Milk'
        cls.storeBG = 'Brook Green'
        cls.storeEA = 'Ealing'
        cls.channelInstore = 'InStore Channel'
        cls.spendAmount_1_99 = Decimal('1.99')
        cls.netSpendAmount_1_99 = Decimal('1.99')
        cls.spendAmount_0_50 = Decimal('0.50')
        cls.netSpendAmount_0_50 = Decimal('0.50')
        cls.Discount_0_25 = Decimal('0.25')
        schema = StructType(
            [
                StructField("Basket", StringType(), True),
                StructField("Date", DateType(), True),
                StructField("Product", StringType(), True),
                StructField("Customer", StringType(), True),
                StructField("Store", StringType(), True),
                StructField("Channel", StringType(), True),
                StructField("Quantity", IntegerType(), True),
                StructField("SpendAmount", DecimalType(18, 2), True),
                StructField("NetSpendAmount", DecimalType(18, 2), True),
                StructField("DiscountAmount", DecimalType(18, 2), True)
            ]
        )
        l = [
              ('000', cls.as_at - datetime.timedelta(weeks=500), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25) # very old transaction to ensure it doesn't affect anything
            , ('001', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerLukeSkywalker, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('002', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('003', cls.as_at - datetime.timedelta(weeks=4), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('004', cls.as_at - datetime.timedelta(weeks=12), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('005', cls.as_at - datetime.timedelta(weeks=24), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('006', cls.as_at - datetime.timedelta(weeks=51), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('007', cls.as_at - datetime.timedelta(weeks=55), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 2, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('008', cls.as_at - datetime.timedelta(weeks=57), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 2, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('009', cls.as_at - datetime.timedelta(weeks=1), cls.productFetaCheeseMild, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('010', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerObiWan, cls.storeBG, cls.channelInstore, 2, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('010', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerObiWan, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('011', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerObiWan, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('012', cls.as_at - datetime.timedelta(weeks=3), cls.productCheddarMature, cls.customerObiWan, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('013', cls.as_at - datetime.timedelta(weeks=500), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25) # very old transaction to ensure it doesn't affect anything
            , ('014', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerLukeSkywalker, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('015', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('016', cls.as_at - datetime.timedelta(weeks=4), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('017', cls.as_at - datetime.timedelta(weeks=12), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('018', cls.as_at - datetime.timedelta(weeks=24), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('019', cls.as_at - datetime.timedelta(weeks=51), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('020', cls.as_at - datetime.timedelta(weeks=55), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 2, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('021', cls.as_at - datetime.timedelta(weeks=57), cls.productCheddarMature, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 2, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('022', cls.as_at - datetime.timedelta(weeks=1), cls.productFetaCheeseMild, cls.customerDarthVadar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('023', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerObiWan, cls.storeEA, cls.channelInstore, 2, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('023', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerObiWan, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('024', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerObiWan, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('025', cls.as_at - datetime.timedelta(weeks=3), cls.productCheddarMature, cls.customerObiWan, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('026', cls.as_at - datetime.timedelta(weeks=90), cls.productCheddarMature, cls.customerObiWan, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('027', cls.as_at - datetime.timedelta(weeks=90), cls.productCheddarMature, cls.customerObiWan, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('028', cls.as_at - datetime.timedelta(weeks=3), cls.productCheddarMature, cls.customerAdmiralAckbar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('029', cls.as_at - datetime.timedelta(weeks=27), cls.productCheddarMature, cls.customerAdmiralAckbar, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('030', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerLeiaOrgana, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('031', cls.as_at - datetime.timedelta(weeks=3), cls.productCheddarMature, cls.customerLeiaOrgana, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('032', cls.as_at - datetime.timedelta(weeks=3), cls.productCheddarMature, cls.customerLeiaOrgana, cls.storeEA, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('033', cls.as_at - datetime.timedelta(weeks=3), cls.productBakedBeans, cls.customerLeiaOrgana, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('034', cls.as_at - datetime.timedelta(weeks=1), cls.productCheddarMature, cls.customerHanSolo, cls.storeBG, cls.channelInstore, 2, cls.spendAmount_0_50, cls.netSpendAmount_0_50, cls.Discount_0_25)
            , ('035', cls.as_at - datetime.timedelta(weeks=102), cls.productCheddarMature, cls.customerDarthVadar, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('036', cls.as_at - datetime.timedelta(weeks=211), cls.productCheddarMature, cls.customerObiWan, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('037', cls.as_at - datetime.timedelta(weeks=40), cls.productCheddarMature, cls.customerChewbacca, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25) #Need a customer that has only bought something between 26 and 52 weeks ago, so don't create any more transactions for this customer
            , ('038', cls.as_at - datetime.timedelta(weeks=5), cls.productWholeMilk, cls.customerLandoCalrissian, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('039', cls.as_at - datetime.timedelta(weeks=6), cls.productWholeMilk, cls.customerLandoCalrissian, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('040', cls.as_at - datetime.timedelta(weeks=7), cls.productWholeMilk, cls.customerLandoCalrissian, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('041', cls.as_at - datetime.timedelta(weeks=8), cls.productWholeMilk, cls.customerLandoCalrissian, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('042', cls.as_at - datetime.timedelta(weeks=8), cls.productWholeMilk, cls.customerJynErso, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('043', cls.as_at - datetime.timedelta(days=1), cls.productWholeMilk, cls.customerRey, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('044', cls.as_at - datetime.timedelta(days=1), cls.productWholeMilk, cls.customerRey, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('045', cls.as_at - datetime.timedelta(days=2), cls.productWholeMilk, cls.customerRey, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('046', cls.as_at - datetime.timedelta(days=2), cls.productWholeMilk, cls.customerRey, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('047', cls.as_at - datetime.timedelta(days=3), cls.productWholeMilk, cls.customerRey, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('048', cls.as_at - datetime.timedelta(days=1), cls.productWholeMilk, cls.customerFinn, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('049', cls.as_at - datetime.timedelta(days=1), cls.productWholeMilk, cls.customerFinn, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('050', cls.as_at - datetime.timedelta(days=2), cls.productWholeMilk, cls.customerFinn, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('051', cls.as_at - datetime.timedelta(days=2), cls.productWholeMilk, cls.customerFinn, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
            , ('052', cls.as_at - datetime.timedelta(days=3), cls.productWholeMilk, cls.customerFinn, cls.storeBG, cls.channelInstore, 1, cls.spendAmount_1_99, cls.netSpendAmount_1_99, cls.Discount_0_25)
        ]
        cls.df = cls.sqlContext.createDataFrame(l, schema)
        cls.product_entity = cls.sqlContext.createDataFrame(
            [
                (cls.productCheddarMature, 'Cheese', 'Dairy'),
                (cls.productFetaCheeseMild, 'Cheese', 'Dairy'),
                (cls.productBakedBeans, 'Beans', 'Canned food'),
                (cls.productWholeMilk, 'Milk', 'Dairy'),
                (cls.productSkimmedMilk, 'Milk', 'Dairy')
            ],
            StructType([
                StructField("Product", StringType(), True),
                StructField("Subgroup", StringType(), True),
                StructField("Group", StringType(), True)
            ])
        )
        #We used to cache the dataframe, but in tests we found out that doing so took the test suite ~15% longer to run,
        # thus its been commented out
        #cls.df.cache() #Going to be used in lots of different tests, so let's cache it

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass
