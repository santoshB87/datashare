import logging
import unittest
from decimal import Decimal
from dunnhumby import contexts
from pyspark.sql import types  as T
from dunnhumby.cmp_science.utilities import read_pmml_root
from dunnhumby.cmp_science.scoring_prepare import insert

__author__ = 'rudraps and millan'
abspath = os.path.abspath(__file__)
abspath = abspath.replace('test_scoring_prepare.py','proposition.standard.pmml')
class TestScoringPrepare(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = {
            "task_name": "proposition_standard_data_preparation",
            "client_name": "client",
            "proposition": "proposition",
            "model": "standard",
            "pmml_path": abspath,
            "source_schema": "client_pob",
            "features_CustomerAll_dataset": "cadenceattributefis_week_id_customercustomer_productall_channelall_storeall_current",
            "features_ProductAll_dataset": "cadenceattributefis_week_id_customerall_productproduct_channelall_storeall_current",
            "features_CustomerProduct_dataset": "cadenceattributefis_week_id_customercustomer_productproduct_channelall_storeall_current",
            "features_CustomerProductSubgroup_dataset": "cadenceattributefis_week_id_customercustomer_productsubgroup_channelall_storeall_current",
            "destination_schema": "client_ssemo",
            "destination_entity": "standard_scoring_features_proposition",
            "CustomerAll_grain": "customercustomer_productall_channelall_storeall",
            "ProductAll_grain": "customerall_productproduct_channelall_storeall",
            "CustomerProduct_grain": "customercustomer_productproduct_channelall_storeall",
            "CustomerProductSubgroup_grain": "customercustomer_productsubgroup_channelall_storeall"
        }
        cls.logger = logging.getLogger(__name__)
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists %s' % self.config['source_schema'])
        self.sqlContext.sql('create database if not exists %s' % self.config['destination_schema'])
        self.sqlContext.sql('drop table if exists {hive_db}.{table}'.format(
            hive_db=self.config['source_schema'], table=self.config['features_CustomerAll_dataset']))
        self.sqlContext.sql('drop table if exists {hive_db}.{table}'.format(
            hive_db=self.config['source_schema'], table=self.config['features_ProductAll_dataset']))
        self.sqlContext.sql('drop table if exists {hive_db}.{table}'.format(
            hive_db=self.config['source_schema'], table=self.config['features_CustomerProduct_dataset']))
        self.sqlContext.sql('drop table if exists {hive_db}.{table}'.format(
            hive_db=self.config['destination_schema'], table=self.config['destination_entity']))

    def tearDown(self):
        pass

    def test_std_scoring_data_prepare_for_at_least_one_transaction_record(self):
        """
        Standard scoring data preparation program takes input data of `Products`, `Customers`,
        `client_pob.proposition_conv_standard_latest`,
        `client_pob.cadenceattributefis_week_id_customercustomer_productall_channelall_storeall_current`,
        `client_pob.cadenceattributefis_week_id_customerall_productproduct_channelall_storeall_current` and
        `client_pob.cadenceattributefis_week_id_customercustomer_productproduct_channelall_storeall_current`,
        then prepare conversion scoring input data in `client_ssemo.standard_scoring_features_proposition`
        as per conversion soring PMML file.

        So, we need to prepare the input data sets with sample data for each of data source and run the
        conversion scoring data preparation program to test the program by asserting over resulted output.
        """
        # create dataframe with data of 'proposition_conv_standard_latest'
        schema = T.StructType([
            T.StructField('customercustomer_productproduct_channelall_storeall_customer',T.StringType(),True),
            T.StructField('customercustomer_productproduct_channelall_storeall_product',T.StringType(),True),
            T.StructField('prob_proposition_conversion',T.DecimalType(38,10),True)
            ])
        sample = [('0000000008', '100000', Decimal('0.4498304981'))
                  ]
        std_conv_df = self.sqlContext.createDataFrame(sample, schema)

        # create dataframe with data of 'Products'
        schema = T.StructType([
            T.StructField('Product', T.StringType(), True),
            T.StructField('productsubgroup', T.StringType(), True),
            T.StructField('productgroup', T.StringType(), True),
            T.StructField('productdivision', T.StringType(), True)
        ])
        sample = [('100000', '0681505368053055050010', '05368053055050010', '010'),
                  ('100296', '0403001040010015010010', '01040010015010010', '010')
                  ]
        prod_df = self.sqlContext.createDataFrame(sample, schema)

        # create dataframe for data of 'Customers'
        schema = T.StructType([
            T.StructField('Customer',T.StringType(),True),
            T.StructField('IsEmailable',T.BooleanType(),True),
            T.StructField('SloyaltyHigh',T.StringType(),True),
            T.StructField('SloyaltyLow',T.StringType(),True),
            T.StructField('FulfillmentStore',T.StringType(),True),
            T.StructField('PreferredStore1',T.StringType(),True),
            T.StructField('PreferredStore2',T.StringType(),True),
            T.StructField('PreferredStore3',T.StringType(),True)
        ])
        sample = [('0000000008', False, None, None, None, None, None, None)
                  ]
        cust_df = self.sqlContext.createDataFrame(sample, schema)

        # Create grain level features entities
        # client_pob.cadenceattributefis_week_id_customercustomer_productall_channelall_storeall_current
        schema = T.StructType([
            T.StructField('customer', T.StringType(), True),
            T.StructField('customerattribute', T.StringType(), True),
            T.StructField('product', T.StringType(), True),
            T.StructField('productattribute', T.StringType(), True),
            T.StructField('channel', T.StringType(), True),
            T.StructField('channelattribute', T.StringType(), True),
            T.StructField('store', T.StringType(), True),
            T.StructField('storeattribute', T.StringType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_basketweeks_1w13w', T.LongType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_basketweeks_1w26w', T.LongType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_basketweeks_1w52w', T.LongType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_baskets_1w26w', T.LongType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_baskets_1w52w', T.LongType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_averagepurchasecycle_1w13w',
                          T.DecimalType(6, 2), True),
            T.StructField('customercustomer_productall_channelall_storeall_averagepurchasecycle_1w26w',
                          T.DecimalType(6, 2), True),
            T.StructField('customercustomer_productall_channelall_storeall_averagepurchasecycle_1w52w',
                          T.DecimalType(6, 2), True),
            T.StructField('customercustomer_productall_channelall_storeall_netspend_1w52w', T.DecimalType(28, 2), True),
            T.StructField('customercustomer_productall_channelall_storeall_netspendperbasket_1w52w',
                          T.DecimalType(8, 2), True),
            T.StructField('customercustomer_productall_channelall_storeall_recencydays_1w26w', T.ShortType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_recencydays_1w52w', T.ShortType(), True),
            T.StructField('customercustomer_productall_channelall_storeall_quantityperbasket_1w52w',
                          T.DecimalType(8, 2), True)
        ])
        sample = [('0000000008', 'Customer', 'All', 'All', 'All', 'All', 'All', 'All', 2, 2, 2, 2, 2,
                   Decimal('18.00'), Decimal('18.00'), Decimal('18.00'), Decimal('182280.00'), Decimal('91140.00'),
                   1, 1, Decimal('15.50'))
                  ]
        self.sqlContext.createDataFrame(sample, schema).saveAsTable('{hive_db}.{table}'.format(
            hive_db=self.config['source_schema'], table=self.config['features_CustomerAll_dataset']))

        # client_pob.cadenceattributefis_week_id_customerall_productproduct_channelall_storeall_current
        schema = T.StructType([
            T.StructField('customer', T.StringType(), True),
            T.StructField('customerattribute', T.StringType(), True),
            T.StructField('product', T.StringType(), True),
            T.StructField('productattribute', T.StringType(), True),
            T.StructField('channel', T.StringType(), True),
            T.StructField('channelattribute', T.StringType(), True),
            T.StructField('store', T.StringType(), True),
            T.StructField('storeattribute', T.StringType(), True),
            T.StructField('customerall_productproduct_channelall_storeall_basketsflag_1w1w',
                          T.BooleanType(), True),
            T.StructField('customerall_productproduct_channelall_storeall_baskets_1w52w',
                          T.LongType(), True),
            T.StructField('customerall_productproduct_channelall_storeall_quantity_1w1w',
                          T.LongType(), True),
            T.StructField('customerall_productproduct_channelall_storeall_minimumnetprice_1w1w',
                          T.DecimalType(38, 10), True),
            T.StructField('customerall_productproduct_channelall_storeall_averagenetprice_1w1w',
                          T.DecimalType(38, 10), True)
        ])
        sample = [('All', 'All', '100000', 'Product', 'All', 'All', 'All', 'All',
                   True, 245, 24, Decimal('5012.0000000000'), Decimal('6354.8333333333'))
                  ]
        self.sqlContext.createDataFrame(sample, schema).saveAsTable('{hive_db}.{table}'.format(
            hive_db=self.config['source_schema'], table=self.config['features_ProductAll_dataset']))

        # client_pob.cadenceattributefis_week_id_customercustomer_productproduct_channelall_storeall_current
        schema = T.StructType([
            T.StructField('customer', T.StringType(), True),
            T.StructField('customerattribute', T.StringType(), True),
            T.StructField('product', T.StringType(), True),
            T.StructField('productattribute', T.StringType(), True),
            T.StructField('channel', T.StringType(), True),
            T.StructField('channelattribute', T.StringType(), True),
            T.StructField('store', T.StringType(), True),
            T.StructField('storeattribute', T.StringType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_averagepurchasecycle_1w13w',
                          T.DecimalType(6, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_averagepurchasecycle_1w26w',
                          T.DecimalType(6, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_averagepurchasecycle_1w52w',
                          T.DecimalType(6, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_baskets_1w1w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_baskets_1w26w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_baskets_1w52w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_basketweeks_1w13w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_basketweeks_1w1w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_basketweeks_1w26w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_quantity_1w13w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_quantity_1w1w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_quantity_1w26w', T.LongType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_recencydays_1w13w', T.ShortType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_recencydays_1w26w', T.ShortType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_recencydays_1w52w', T.ShortType(), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_recencyweightedbasketweeks75_1w52w',
                          T.DecimalType(38, 10), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_recencyweightedbasketweeks95_1w52w',
                          T.DecimalType(38, 10), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_basketsflag_50w57w', T.BooleanType(),
                          True),
            T.StructField('customercustomer_productproduct_channelall_storeall_netspend_1w13w', T.DecimalType(28, 2),
                          True),
            T.StructField('customercustomer_productproduct_channelall_storeall_netspend_1w1w', T.DecimalType(28, 2),
                          True),
            T.StructField('customercustomer_productproduct_channelall_storeall_netspend_1w26w', T.DecimalType(28, 2),
                          True),
            T.StructField('customercustomer_productproduct_channelall_storeall_netspendperbasket_1w13w',
                          T.DecimalType(8, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_netspendperbasket_1w1w',
                          T.DecimalType(8, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_netspendperbasket_1w26w',
                          T.DecimalType(8, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_basketsdecay_1w13wvs1w26w',
                          T.DecimalType(38, 2), True),
            T.StructField('customercustomer_productproduct_channelall_storeall_basketsdecay_1w13wvs1w52w',
                          T.DecimalType(38, 2), True)
        ])
        sample = [('0000000008', 'Customer', '100000', 'Product', 'All', 'All', 'All', 'All',
                   None, None, None, 0, 1, 1, 1, 0, 1, 1, 0, 1, 17, 17, 17, Decimal('0.5625000000'),
                   Decimal('0.9025000000'), False, Decimal('3860.00'), Decimal('0.00'), Decimal('3860.00'),
                   Decimal('3860.00'), None, Decimal('3860.00'), Decimal('1.00'), Decimal('1.00'))
                  ]
        self.sqlContext.createDataFrame(sample, schema).saveAsTable('{hive_db}.{table}'.format(
            hive_db=self.config['source_schema'], table=self.config['features_CustomerProduct_dataset']))

        # Invoke conversion data preparation method
        pmml_root = read_pmml_root(self.config['pmml_path'])
        insert(self.logger, self.sqlContext, self.config, std_conv_df, prod_df, cust_df, pmml_root)

        # Collect prepared conversion records from output entity
        df = self.sqlContext.table('{hive_db}.{table}'.format(
            hive_db=self.config['destination_schema'], table=self.config['destination_entity']))

        # assertion - result entity must have one row as output
        std_scoring_prepared_entity_rows_cnt = df.count()
        self.assertEquals(std_scoring_prepared_entity_rows_cnt, 1)
