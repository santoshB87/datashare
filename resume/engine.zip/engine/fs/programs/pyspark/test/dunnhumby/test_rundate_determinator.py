import unittest
import datetime
import dunnhumby.rundate_determinator as rundate_determinator


class TestBaseRundateDeterminator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def test_base_rundate_determinator(self):
        rundate_determinator_obj = rundate_determinator.RunDateDeterminator()
        self.assertEquals(rundate_determinator_obj.run_date, datetime.date.today())
