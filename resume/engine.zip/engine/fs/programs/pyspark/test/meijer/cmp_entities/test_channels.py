import unittest
from dunnhumby import contexts
from meijer.cmp_entities.channels import Channels
from pyspark.sql.types import *


class TestChannels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists meijer_media_mart')
        self.sqlContext.sql('drop table if exists meijer_media_mart.channels')
        self.schema = StructType(
            [StructField("Channel", StringType(), True),
             StructField("ChannelDescription", StringType(), True),
             StructField("fis_week_id", IntegerType(), True)
             ])

    def tearDown(self):
        self.sqlContext.sql('drop table if exists meijer_media_mart.channels')
        self.sqlContext.sql('drop database if exists meijer_media_mart')

    def test_one_row_returned_if_data_exists_in_all_underlying_tables(self):
        l = [('Instore', 'Instore', 201818)]
        self.sqlContext.createDataFrame(l, self.schema).write.saveAsTable('meijer_media_mart.channels')

        channels = Channels()
        channels_df = channels.data.collect()
        self.assertEquals(len(channels_df), 1)
