import unittest
from dunnhumby import contexts
from meijer.cmp_entities.customers import Customers
from pyspark.sql.types import *


class TestCustomers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists meijer_media_mart')
        self.sqlContext.sql('drop table if exists meijer_media_mart.customers')
        self.schema = StructType(
            [StructField("Customer", StringType(), True),
             StructField("FulfillmentStore", StringType(), True),
             StructField("PreferredStore1", StringType(), True),
             StructField("PreferredStore2", StringType(), True),
             StructField("PreferredStore3", StringType(), True),
             StructField("CustomerGender", StringType(), True),
             StructField("CustomerAge", IntegerType(), True),
             StructField("CustomerSloyaltyHigh", StringType(), True),
             StructField("CustomerSloyaltyHighDescription", StringType(), True),
             StructField("CustomerSloyaltyLow", StringType(), True),
             StructField("CustomerSloyaltyLowDescription", StringType(), True),
             StructField("CustomerRegion", StringType(), True),
             StructField("CustomerFamilyCustomPanelName", StringType(), True),
             StructField("CustomerLifeStage", StringType(), True),
             StructField("CustomerLifeStageDescription", StringType(), True),
             StructField("CustomerPriceSensitivity", StringType(), True),
             StructField("CustomerPriceSensitivityDescription", StringType(), True),
             StructField("CustomerLifeStyle", StringType(), True),
             StructField("CustomerLifeStyleDescription", StringType(), True),
             StructField("IsBlacklisted", BooleanType(), True),
             StructField("IsEmailable", BooleanType(), True),
             StructField("IsMailable", BooleanType(), True),
             StructField("IsScottish", BooleanType(), True),
             StructField("IsBabyCompliant", BooleanType(), True),
             StructField("IsBabyAddrSupress", BooleanType(), True),
             StructField("IsBereaved", BooleanType(), True),
             StructField("IsDiabetic", BooleanType(), True),
             StructField("IsHalal", BooleanType(), True),
             StructField("IsKosher", BooleanType(), True),
             StructField("IsTeetotal", BooleanType(), True),
             StructField("IsAddrSuppress", BooleanType(), True),
             StructField("IsVegetarian", BooleanType(), True),
             StructField("fis_week_id", IntegerType(), True)
             ])

    def tearDown(self):
        self.sqlContext.sql('drop table if exists meijer_media_mart.customers')

    def test_one_row_returned_if_data_exists_in_all_underlying_tables(self):
        l = [('000000000000232', None, '106', None, None, None, None, None, None, 'UN', 'Uncommitted', None, None, None, None, 'MM', None, None, None, None, None, False, None, None, None, None, None, None, None, None, None, None, 201818)]
        self.sqlContext.createDataFrame(l, self.schema).write.\
            saveAsTable('meijer_media_mart.customers')
        customers = Customers()
        customers_df = customers.data.collect()
        self.assertEquals(len(customers_df), 1)
