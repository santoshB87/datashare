import unittest
from dunnhumby import contexts
from meijer.cmp_entities.products import Products
from pyspark.sql.types import *


class TestProducts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists meijer_media_mart')
        self.sqlContext.sql('drop table if exists meijer_media_mart.products')

    def tearDown(self):
        self.sqlContext.sql('drop table if exists meijer_media_mart.products')
        self.sqlContext.sql('drop database if exists meijer_media_mart')

    def test_one_row_in_prod_dim_c_should_return_one_row_from_cmp_entity(self):
        schema = StructType([StructField('product', StringType(), True),
                             StructField('productdescription', StringType(), True),
                             StructField('productalternate', StringType(), True),
                             StructField('subgroup', StringType(), True),
                             StructField('subgroupdescription', StringType(), True),
                             StructField('group', StringType(), True),
                             StructField('groupdescription', StringType(), True),
                             StructField('section', StringType(), True),
                             StructField('sectiondescription', StringType(), True),
                             StructField('department', StringType(), True),
                             StructField('departmentdescription', StringType(), True),
                             StructField('division', StringType(), True),
                             StructField("divisiondescription", StringType(), True),
                             StructField("producthiearchytype", StringType(), True),
                             StructField("productbrand", StringType(), True),
                             StructField("productsupplier", StringType(), True),
                             StructField("isalcohol", BooleanType(), True),
                             StructField("isfuel", BooleanType(), True),
                             StructField("isbaby", BooleanType(), True),
                             StructField("ispet", BooleanType(), True),
                             StructField("issoldbyweight", BooleanType(), True),
                             StructField("productimage", StringType(), True),
                             StructField("isnew", BooleanType(), True),
                             StructField("newproductlaunchdatetime", TimestampType(), True),
                             StructField("fis_week_id", IntegerType(), True)
                             ])
        l = [
            ('000000000000000539', '*', None,  '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'PROD_HIER', None, None, None, None, None, None, None, None, None, None, 201818)]
        self.sqlContext.createDataFrame(l, schema).write.saveAsTable('meijer_media_mart.products')
        products = Products()
        products.get_data()
        products_rows_cnt = products.data.count()
        self.assertEquals(products_rows_cnt, 1)
