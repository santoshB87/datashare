"""
meijer product_on_promotion_in_store test module
"""
import unittest
import datetime
from dunnhumby import contexts
from pyspark.sql.types import *
from meijer.cmp_entities.promotions import Promotions


class TestPromotions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists meijer_media_mart')
        self.sqlContext.sql('drop table if exists meijer_media_mart.promotions')

    def tearDown(self):
        self.sqlContext.sql('drop table if exists meijer_media_mart.promotions')
        self.sqlContext.sql('drop database if exists meijer_media_mart')

    def test_get_data_returns_one_row_for_one_row_in_promo_lookup(self):

        schema = StructType(
            [StructField("promotion", StringType(), True),
             StructField("promotiondescription", StringType(), True),
             StructField("product", StringType(), True),
             StructField("store", StringType(), True),
             StructField("channel", StringType(), True),
             StructField("mechaniccode", StringType(), True),
             StructField("promotiontype", StringType(), True),
             StructField("promotionstartdatetime", TimestampType(), True),
             StructField("promotionenddatetime", TimestampType(), True),
             StructField("fis_week_id", IntegerType(), True),
             StructField("pricepromoamt", DecimalType(), True),
             StructField("priceprepromoamt", DecimalType(), True),
             StructField("discountamount", DecimalType(), True),
             StructField("discountpercent", DecimalType(), True),
             StructField("sponsored", IntegerType(), True)])
        l_promo = [('01_201802_002', None, "000000000000000539", "190", None, None, None,   datetime.datetime(2018, 12, 16), datetime.datetime(2018, 12, 16), 201846, None, None, None, None, 1)]
        self.sqlContext.createDataFrame(l_promo, schema).write.saveAsTable('meijer_media_mart.promotions')
        promotions_df = Promotions()
        promotions_df = promotions_df.data.collect()
        self.assertEquals(len(promotions_df), 1)

