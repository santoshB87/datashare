"""
Test Monoprix channels
"""
import unittest

from pyspark.sql.types import StringType, StructField, StructType, IntegerType

from dunnhumby import contexts
from monoprix.cmp_entities.channels import Channels
from test.monoprix.test_setup import TestSetup


class TestChannels(unittest.TestCase):
    """
    Test Monoprix channels
    """
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()

    def tearDown(self):
        pass

    def test_channel_entity_returns_data_when_data_exists_in_channel_dim_c(self):
        """if data in channel_dimc, etity should provide data"""
        schema = StructType()\
            .add(StructField("channel_id", IntegerType(), True))\
            .add(StructField("channel_code", StringType(), True))\
            .add(StructField("channel_name", StringType(), True))
        data = [(1, '1', 'Online Shop'), (2, '2', 'Store')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.channel_dim_c')

        channels = Channels({"SSEHiveDatabasePrefix": "client"})
        channels.get_data()
        channels_df = channels.data.collect()
        self.assertEquals(len(channels_df), 2)
