"""
Monoprix Customers entity tests
"""
import datetime
import unittest

from dunnhumby import contexts
from monoprix.cmp_entities.customers import Customers
from test.monoprix.test_setup import TestSetup, create_empty_tables


class TestCustomers(unittest.TestCase):
    """
    Monoprix Customers entity tests
    """
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()

    def tearDown(self):
        pass

    def test_is_emailable(self):
        """
        If prsn_suppress_email_flag='Y' then customer cannot be emailed
        If prsn_suppress_email_flag='N' then customer can be emailed
        """
        schema = TestSetup().get_card_dim_c_schema()
        data = [
            (
                556286300, 269002535, 'BSK_100203427', 'N', None, '2',
                datetime.datetime(2017, 9, 19, 18, 26, 1), 'Paris'
            ),
            (
                556286301, 269002536, 'BSK_100203428', 'Y', None, '2',
                datetime.datetime(2017, 9, 19, 18, 26, 1), 'Paris'
            )
        ]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)

        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers_df = customers.data.toPandas()
        self.assertEquals(
            customers_df[(customers_df.Customer == 'BSK_100203427')]
            .iloc[0]['IsEmailable'],
            True)
        self.assertEquals(
            customers_df[(customers_df.Customer == 'BSK_100203428')]
            .iloc[0]['IsEmailable'],
            False
        )

    def test_two_rows_in_card_dim_c_for_same_prsn_code_with_different_attribute_values_return_one_row_from_entity(self):
        """
        duplicates in card_dim_c must be accounted for
        :return:
        """
        schema = TestSetup().get_card_dim_c_schema()
        # This is real customer data, the only difference being that I've
        # modified prsn_email_suppress_flag in one case
        data = [
            (
                556286300, 269002535, 'BSK_100203427', 'N', None,
                '2', datetime.datetime(2017, 9, 19, 18, 26, 1), 'Paris'
            ),
            (
                306018719, 269002535, 'BSK_100203427', 'Y', None,
                '2', datetime.datetime(2017, 9, 25, 11, 26, 30), 'Nantes'
            )
        ]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)

        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers_df = customers.data.collect()
        self.assertEquals(len(customers_df), 1)

    def test_two_rows_in_card_dim_c_for_same_prsn_code_with_same_attribute_values_and_same_modified_date_return_one_row_from_entity(self):
        """
        duplicates in card_dim_c must be accounted for
        :return:
        """
        schema = TestSetup().get_card_dim_c_schema()
        # This is real customer data, the only difference being that I've
        # modified prsn_email_suppress_flag in one case
        data = [
            (
                556286300, 269002535, 'BSK_100203427', 'Y', None, '2',
                datetime.datetime(2017, 9, 19, 18, 26, 1), 'Paris'
            ),
            (
                306018719, 269002535, 'BSK_100203427', 'Y', None, '2',
                datetime.datetime(2017, 9, 19, 18, 26, 1), 'Nantes'
            )
        ]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)

        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers.get_data()
        customers_df = customers.data.collect()
        self.assertEquals(len(customers_df), 1)

    def test_40yearold_customer_has_correct_agerange(self):
        """
        40 year old should be in 40-49 age range
        :return:
        """
        schema = TestSetup().get_card_dim_c_schema()
        data = TestSetup().get_card_dim_c_data_one_row_johndoe()
        row = list(data[0])
        row[4] = datetime.date(
            datetime.date.today().year - 40,
            datetime.date.today().month,
            datetime.date.today().day
        )
        data[0] = tuple(row)
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)
        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers.get_data()
        customers_df = customers.data.collect()
        self.assertEquals(customers_df[0]['CustomerAgeRange'], '40-49')

    def test_prsn_title_name_equaling_1_causes_gender_to_be_male(self):
        """
        We have been reliably informed that prsn_title_name=1 means "Monsieur", hence Male
        """
        schema = TestSetup().get_card_dim_c_schema()
        data = TestSetup().get_card_dim_c_data_one_row_johndoe()
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)
        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers.get_data()
        customers_df = customers.data.collect()
        self.assertEquals(customers_df[0]['CustomerGender'], 'Male')

    def test_prsn_title_name_equaling_2_causes_gender_to_be_female(self):
        """
        We have been reliably informed that prsn_title_name=2 means "Madame", hence Female
        """
        schema = TestSetup().get_card_dim_c_schema()
        data = [(1, 1, 'JaneDoe', 'Y', None, 2, datetime.date(1970, 1, 1), 'Paris')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)
        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers.get_data()
        customers_df = customers.data.collect()
        self.assertEquals(customers_df[0]['CustomerGender'], 'Female')

    def test_prsn_title_name_equaling_3_causes_gender_to_be_female(self):
        """
        We have been reliably informed that prsn_title_name=3 means "Madamoiselle", hence Femle
        """
        schema = TestSetup().get_card_dim_c_schema()
        data = [(1, 1, 'JaneDoe', 'Y', None, 3, datetime.date(1970, 1, 1), 'Paris')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)
        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers.get_data()
        customers_df = customers.data.collect()
        self.assertEquals(customers_df[0]['CustomerGender'], 'Female')

    def test_one_row_in_card_dim_c_should_return_one_row_from_cmp_entity_even_if_no_data_in_other_tables(self):
        """
        Lack of data in tables other than card_dim_c should nt prevent data
        from being provided by the entity
        :return:
        """
        schema = TestSetup().get_card_dim_c_schema()
        data = TestSetup().get_card_dim_c_data_one_row_johndoe()
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        create_empty_tables(self.sqlContext)

        customers = Customers({"SSEHiveDatabasePrefix": "client"})
        customers.get_data()
        customers_df = customers.data.collect()
        self.assertEquals(len(customers_df), 1)
