"""
Monoprix dates tests
"""
import unittest
from datetime import datetime

import pyspark.sql.types as T

from dunnhumby import contexts
from monoprix.cmp_entities.dates import Dates
from test.monoprix.test_setup import TestSetup


class TestDates(unittest.TestCase):
    """
    Monoprix dates tests
    """
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()

    def tearDown(self):
        pass

    def test_one_row_in_date_dim_should_return_one_row_from_cmp_entity(self):
        """
         Creating a test table date_dim and loading with a sample record with required schema.
         Then same data is pulled by the Source class to check schema level
         matching of data and source class.
        """
        schema = T.StructType([
            T.StructField("date_id", T.DateType(), True),
            T.StructField("date_name", T.StringType(), True),
            T.StructField("date_short_name", T.StringType(), True),
            T.StructField("day_of_week_name", T.StringType(), True),
            T.StructField("fis_week_id", T.StringType(), True),
            T.StructField("fis_day_of_week_num", T.ShortType(), True)
        ])
        data = [(datetime.strptime('2017-09-18 00:00:00', '%Y-%m-%d %H:%M:%S'),
                 'SEPTEMBER 18, 2017', '2017-09-18', 'MONDAY', '201738', 1)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.date_dim')
        dates = Dates({"SSEHiveDatabasePrefix": "client"})
        dates.get_data()
        dates_rows_cnt = dates.data.count()
        self.assertEquals(dates_rows_cnt, 1)
