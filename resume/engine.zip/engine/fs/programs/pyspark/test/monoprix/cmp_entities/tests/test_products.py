"""
Monoprix Products entity tests
"""
import unittest
from pyspark.sql import types as pt
from dunnhumby import contexts
from monoprix.cmp_entities.products import Products
from test.monoprix.test_setup import TestSetup


class TestProducts(unittest.TestCase):
    """
    Monoprix Products entity tests
    """

    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()
        # Important to clear the cache between tests because there is a
        # danger that cached DFs may ge reused in different tests (this has
        # happened to me, and it was hair-tearing-out-time trying to figure
        # out what was going on)
        self.sqlContext.clearCache()
        self.pac_section_table_schema = pt.StructType(
            [pt.StructField("affinityclusternum", pt.StringType(), True),
                pt.StructField("prod_comml_l22_code", pt.StringType(), True), ])
        self.pac_InstoreShelf_table_schema = pt.StructType(
            [pt.StructField("affinityclusternum", pt.StringType(), True),
                pt.StructField("prod_comml_l20_code", pt.StringType(), True), ])
        self.sqlContext.createDataFrame([], self.pac_section_table_schema).saveAsTable(
            'client_ssewh.pacs_info_prod_comml_l22_code')
        self.sqlContext.createDataFrame([], self.pac_InstoreShelf_table_schema).saveAsTable(
            'client_ssewh.pacs_info_prod_comml_l20_code')

    def tearDown(self):
        pass

    def test_product_entity_returns_data_when_data_exists_in_prod_dim_c(self):
        """prod_dim_c is the driver table, so any data in it should cause
        the entity to return some data"""
        schema = TestSetup.get_prod_dim_c_schema()

        data = [(1, '3760114521262', '*100G MEDAILLON LAND.TRUF&FG', 'CA0606_2021300701',
                 'CONSERVES LEGUMES / VIANDES', 'CA0606_20', 'EPICERIE FINE', 'CA06213007',
                 'CONS LEG VIAND POISSPLTSCUIS', 'CA06213', 'EPICERIE FINE', 'CA06',
                 'EPICERIE/ENTRETIEN', 'CA', 'ALIMENTAIRE NON PERISSABLE', 'C', 'ALIMENTAIRE',
                 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0', 'Abcd'), (
            2, '8777', 'TAB BONHEUR LAIT', 'PI1616_0257600220', 'DALLOYAU 5,5%', 'PI1616_02',
            'PARTENAIRE GL', 'PI16576002', 'PARTENAIRE GL NON TR', 'PI16576',
            'PARTENAIRE GL NON TR', 'PI16', 'CAFETERIA', 'CA', 'CAFETERIA ET ESSENCE', 'C',
            'CAFETERIA ET ESSENCE', 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0', 'Abcd')]

        # PI16-CAFETERIA isn't really in CA-CAFETERIA ET ESSENCE - I just had to change to satisfy
        # some new business rules. Its only test data, so regard it as such.
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.prod_dim_c')

        schema_vendor = TestSetup.get_vendor_lkp_c_schema()

        data_vendor = [('A', 'A'), ]
        self.sqlContext.createDataFrame(data_vendor, schema_vendor).saveAsTable(
            'client_ssewh.vendor_lkp_c')

        products = Products({"SSEHiveDatabasePrefix": "client"})
        products_df = products.data.collect()
        self.assertEquals(len(products_df), 2)

    def test_product_entity_raises_error_when_onetomanys_are_violated(self):
        """raise error when one-to-manys are violated"""
        schema = TestSetup.get_prod_dim_c_schema()
        data = [(1, '3760114521262', '*100G MEDAILLON LAND.TRUF&FG', 'CA0606_2021300701',
                 'CONSERVES LEGUMES / VIANDES', 'CA0606_20', 'EPICERIE FINE', 'CA06213007',
                 'CONS LEG VIAND POISSPLTSCUIS', 'CA06213', 'EPICERIE FINE', 'CA06',
                 'EPICERIE/ENTRETIEN', 'CA', 'ALIMENTAIRE NON PERISSABLE', 'C', 'ALIMENTAIRE',
                 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0', 'abcd'), (
            2, '8777', 'TAB BONHEUR LAIT', 'CA0606_2021300701', 'CONSERVES LEGUMES / VIANDES',
            'PI1616_02', 'PARTENAIRE GL', 'PI16576002', 'PARTENAIRE GL NON TR', 'PI16576',
            'PARTENAIRE GL NON TR', 'PI16', 'CAFETERIA', 'CA', 'CAFETERIA ET ESSENCE', 'C',
            'CAFETERIA ET ESSENCE', 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0', 'abcd')]
        # PI16-CAFETERIA isn't really in CA-CAFETERIA ET ESSENCE - I just had to change to satisfy
        # some new business rules. Its only test data, so regard it as such.
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.prod_dim_c')
        schema_vendor = TestSetup.get_vendor_lkp_c_schema()

        data_vendor = [('A', 'A'), ]
        self.sqlContext.createDataFrame(data_vendor, schema_vendor).saveAsTable(
            'client_ssewh.vendor_lkp_c')
        with self.assertRaisesRegexp(ValueError,
                "Incoming dataframe does not meet referential integrity rules defined in one_to_manys"):
            Products({"SSEHiveDatabasePrefix": "client"})

    def test_isalcohol(self):
        """If product appears on a shelf pertaining to alcohol
        then the product should have IsAlcohol=True"""
        schema = schema = TestSetup.get_prod_dim_c_schema()
        data = [(
            2344018204, '3760029980222', 'BIERE NINKASI BLONDE 75CL', 'CA0707_4028000201', 'BLONDE',
            'CA0707_40', 'BIERES ET CIDRES', 'CA07280002', 'VERRE', 'CA07280',
            'BIERES DE SPECIALITE', 'CA07', 'LIQUIDES', 'CA', 'ALIMENTAIRE NON PERISSABLE', 'C',
            'ALIMENTAIRE', 'NINKASI', 'A', 'image/url', '9999-12-31 00:00:00.0', 'abcd'), (
            2, '456', 'TAB BONHEUR LAIT', 'CA0606_2021300701', 'CONSERVES LEGUMES / VIANDES',
            'PI1616_02', 'PARTENAIRE GL', 'PI16576002', 'PARTENAIRE GL NON TR', 'PI16576',
            'PARTENAIRE GL NON TR', 'PI16', 'CAFETERIA', 'CA', 'CAFETERIA ET ESSENCE', 'C',
            'CAFETERIA ET ESSENCE', 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0', 'abcd')]
        # PI16-CAFETERIA isn't really in CA-CAFETERIA ET ESSENCE - I just had to change to satisfy
        # some new business rules. Its only test data, so regard it as such.
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.prod_dim_c')
        schema_vendor = TestSetup.get_vendor_lkp_c_schema()

        data_vendor = [('A', 'A'), ]
        self.sqlContext.createDataFrame(data_vendor, schema_vendor).saveAsTable(
            'client_ssewh.vendor_lkp_c')
        products = Products({"SSEHiveDatabasePrefix": "client"})
        products_df = products.data.collect()
        self.assertEquals(len(products_df), 2)
        self.assertTrue(
            [product_ for product_ in products_df if product_['Product'] == '3760029980222'][0][
                'IsAlcohol'])
        self.assertTrue(
            not [product_ for product_ in products_df if product_['Product'] != '3760029980222'][0][
                'IsAlcohol'])
