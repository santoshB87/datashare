"""
Monoprix Stores tests
"""
import unittest

from pyspark.sql.types import StructType, StructField, StringType

from dunnhumby import contexts
from monoprix.cmp_entities.stores import Stores
from test.monoprix.test_setup import TestSetup


class TestStores(unittest.TestCase):
    """
    Monprix Stores tests
    """
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()

    def tearDown(self):
        pass

    def test_store_entity_returns_data_when_data_exists_in_store_dim_c(self):
        """At the time of writing Stores data for Monoprix is gotten from
        store_dim_c. In the future (probably in a Mercury-driven world) we
        expect data will be gotten fromm elsewhere at which time this test
        will probably have to change. Which is fine."""
        schema = StructType()\
            .add(StructField("store_id", StringType(), True))\
            .add(StructField("store_code", StringType(), True))\
            .add("store_name", StringType(), True)\
            .add("banner_name", StringType(), True)\
            .add("store_mgmt_l20_desc", StringType(), True)
        # Here's a query that can pull out some sample data
        #     sqlContext.table('mond_ssewh.store_dim_c') \
        #     .select('store_code','store_name','banner_name','store_mgmt_l20_desc') \
        #     .limit(10).toPandas()
        data = [
            (1, '0072', 'MONO MULHOUSE', 'MONOPRIX', 'Est'),
            (2, '4409', 'STATION GARE STRASBOURG', 'DAILY', 'Est'),
            (3, '9959', 'FAO BEAUTY MONOP', 'BEAUTY', 'Paris')
        ]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.store_dim_c')

        stores = Stores({"SSEHiveDatabasePrefix": "client"})
        stores.get_data()
        stores_df = stores.data.collect()
        self.assertEquals(len(stores_df), 3)
