"""
Monoprix transactions entity tests
"""
import datetime
import unittest
from decimal import Decimal

from pyspark.sql.types import StringType, StructField, StructType, IntegerType

from dunnhumby import contexts
from monoprix.cmp_entities.transactions import Transactions
from test.monoprix.test_setup import TestSetup


class TestTransactions(unittest.TestCase):
    """
    Monoprix transactions entity tests
    """
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    def setUp(self):
        TestSetup().create_empty_database()
        schema = TestSetup().get_transaction_item_fct_schema()
        data = [('aaa', '2010-03-31 00:00:00.0', 1, 1, 1, 1, Decimal('1.0'), Decimal('1.0'))]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_ssewh.transaction_item_fct')
        schema = StructType(
            [StructField("prod_id", IntegerType(), True),
             StructField("prod_code", StringType(), True),
             StructField("prod_comml_l20_code", StringType(), True),
             StructField("prod_comml_l24_code", StringType(), True)])
        data = [(1, 'Bananas', '', 'CA')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.prod_dim_c')
        schema = StructType(
            [StructField("card_id", IntegerType(), True),
             StructField("prsn_code", StringType(), True)])
        data = [(1, 'JohnDoe')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        schema = StructType() \
            .add(StructField("store_id", StringType(), True)) \
            .add(StructField("store_code", StringType(), True)) \
            .add("store_name", StringType(), True) \
            .add("banner_name", StringType(), True) \
            .add("store_mgmt_l20_desc", StringType(), True)
        data = [
            (1, '0072', 'MONO MULHOUSE', 'MONOPRIX', 'Est'),
            (2, '4409', 'STATION GARE STRASBOURG', 'DAILY', 'Est'),
            (3, '9959', 'FAO BEAUTY MONOP', 'BEAUTY', 'Paris')
        ]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.store_dim_c')
        schema = StructType(
            [StructField("channel_id", IntegerType(), True),
             StructField("channel_code", StringType(), True),
             StructField("channel_name", StringType(), True)])
        data = [(1, '1', 'Instore')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.channel_dim_c')


    def tearDown(self):
        pass

    def test_get_data_returns_one_row_for_one_row_in_transaction_item_fct(self):
        """
        data in tranaction_item_fct means data provided via entity
        :return:
        """
        transactions = Transactions({"SSEHiveDatabasePrefix": "client"})
        transactions_df = transactions.data.collect()
        self.assertEquals(len(transactions_df), 1)

    def test_most_recent_transaction_date_property_returns_the_correct_value(self):
        """
        most_recent_transaction_date returns the correct value
        :return:
        """
        transactions = Transactions({"SSEHiveDatabasePrefix": "client"})
        transactions_df = transactions.most_recent_transaction_date.collect()
        self.assertEquals(
            transactions_df[0]['most_recent_transaction_date'],
            datetime.date(2010, 3, 31))
