"""
Monoprix mocked sample data set - being used in unit test cases of PurchasingFeatureGenerator
"""


from decimal import Decimal
from datetime import datetime as dt
from pyspark.sql import types as pt


"""
Client config for test cases
"""
test_config = {
    "SSEHiveDatabasePrefix": "client",
    "SSEProductHierarchy": ["InstoreAisle", "PacSection", "PacInstoreShelf", "InstoreShelf",
                            "Section", "Group", "Subgroup", "Product"],
    "SSEFeaturePacColumns": ["PacSection", "PacInstoreShelf"],
    "SSEHiveWarehousePath": "/user/hive/warehouse",
    "SSEHiveWarehousedb": "client_ssewh",
    "SSEHiveWorkdb": "client_ssework",
    "SSEHivePobdb": "client_pob",
    "SSEHivePurchaseTab": "purchase_fct",
    "SSEHiveTransactionTab": "transaction_item_fct",
    "SSEFeatureLogTab": "feature_run_log",
    "SSEFeatureDistinctTab": "feature_distinct_tab",
    "Sseraw_dataHdfsRootPath": "/dummay_path",
    "SSEFeatureDurations": [[1, 1], [1, 4]],
    "SSEFeatureCleanRun": "False",
    "SSEFeaturePacFlag": "True",
    "SSEFeatureBucketingFlag": "False",
    "SSEFeaturePaarFlag": "True",
    "filters": {
        "products": {
          "filter_condition": "(prod_code is not null) and ((prod_comml_l10_code is not null) or (prod_comml_l20_code is not null) or (prod_comml_l21_code is not null) or (prod_comml_l22_code is not null) or (prod_comml_l23_code is not null) or (prod_comml_l24_code is not null) or (prod_comml_l30_code is not null))"
        }
    },
    # Data purging feature is controlled by SSEFeatureDataPurge (accept boolean value), it can be
    # tuned on/off. Specific behaviour of data retention in different stages are controlled by their
    # respective config values.
    # SSEFeatureDataPurgeMergeRetentionWeekNum - define data retention period for purchases and
    # summary tables. Any data beyond (T - n) weeks will be deleted (here T is week of day on which
    # process is launched/executed).
    # SSEFeatureDataPurgeMergeRetentionWeekNum - define data retention period for merge tables.
    # Any feature generated beyond (T - n) weeks will be deleted (here T is week of day on which
    # process is launched/executed).
    "SSEFeatureDataPurge": "False",
    "SSEFeatureDataPurgeRetentionWeekNum": 108,
    "SSEFeatureDataPurgePublishedRetentionWeekNum": 6,
    # Number of partition used for coalescing, before writing denorm/purchase table to disk/hive
    "SSEFeaturePurchaseRePartitionNum": 1,
    # In wave we are specifying two types of setting which will determine extent of parallelism in
    # our feature calculation process WorkerNum specifies how many parallel job can run and
    # ShufflePart will used to set value for spark.sql.shuffle.partitions
    # In denom section customer_df would be repartitioned as per shufflePart value
    "SSEFeatureDenormWave": {'WorkerNum': 2, 'ShufflePart': 1, "cacheReplica": 1},
    "SSEFeatureSummaryWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureSummaryWave2": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave2": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave3": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureAggregationWave4": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureMergeWave1": {'WorkerNum': 1, 'ShufflePart': 1},
    "SSEFeatureMergeWave2": {'WorkerNum': 1, 'ShufflePart': 1},
}

"""
Setup sqls
"""
setup_sql = {
    "drop_db_ssewh": "DROP DATABASE IF EXISTS client_ssewh CASCADE",
    "drop_db_ssework": "DROP DATABASE IF EXISTS client_ssework CASCADE",
    "drop_db_pob": "DROP DATABASE IF EXISTS client_pob CASCADE",
    "create_db_ssewh": "CREATE DATABASE IF NOT EXISTS client_ssewh "
                       "LOCATION '/user/hive/warehouse/client_ssewh'",
    "create_db_ssework": "CREATE DATABASE IF NOT EXISTS client_ssework "
                         "LOCATION '/user/hive/warehouse/client_ssework'",
    "create_db_pob": "CREATE DATABASE IF NOT EXISTS client_pob LOCATION "
                     "'/user/hive/warehouse/client_pob'",
    "drop_transaction_item_fct": "DROP TABLE IF EXISTS client_ssewh.transaction_item_fct",
    "drop_purchase_fct": "DROP TABLE IF EXISTS client_ssework.purchase_fct",
    "create_transaction_item_fct": "CREATE TABLE client_ssewh.transaction_item_fct( "
                                   "transaction_fid string, prod_id bigint, store_id bigint, "
                                   "card_id bigint, item_qty decimal(24,2), "
                                   "net_spend_amt decimal(38,2), spend_amt decimal(38,2), "
                                   "item_discount_amt decimal(38,2), channel_id bigint, "
                                   "fis_week_id string) "
                                   "PARTITIONED BY (date_id string) STORED AS PARQUET",
    "ins_transaction_item_fct": "INSERT INTO client_ssewh.transaction_item_fct PARTITION(date_id) "
                                "SELECT * FROM client_ssework.temp_trans",
    "create_purchase_fct": "CREATE TABLE IF NOT EXISTS client_ssework.purchase_fct (basket string, "
                           "instoreaisle string, pacsection string,pacinstoreshelf string, "
                           "instoreshelf string, section string, group string,subgroup string, "
                           "product string, customer string, store string, fulfillmentstore string,"
                           " preferredstore1 string, preferredstore2 string, preferredstore3 "
                           "string, channel string, quantity decimal(24,2), netspendamount "
                           "decimal(38,2), spendamount decimal(38,2), discountamount decimal(38,2))"
                           " PARTITIONED BY (fis_week_id string, date string) STORED AS PARQUET "
                           'TBLPROPERTIES ("parquet.compression"="gzip")',
    "ins_purchase_fct": "INSERT INTO client_ssework.purchase_fct PARTITION(fis_week_id, date) "
                        "SELECT * FROM client_ssework.temp_purchase",
}

"""
Result set
"""
result_set = {
    "required_fis_weeks": ["201744", "201743", "201742", "201741"],
    "merge_tab_list": ["product_customer_all_all", "instoresubarea_all_all_all"],
    "view_list": {
        "product_customer_all_all": "v_cadenceattributefis_week_id_channelall_customercustomer_"
                                    "productproduct_storeall_current",
        "instoresubarea_all_all_all": "v_cadenceattributefis_week_id_channelall_customerall_"
                                      "productinstoresubarea_storeall_current",
    },
    "cadence_week_for_fis_week_id": "201744",
    "since_date": dt.strptime("2017-12-04", "%Y-%m-%d").date(),
}

"""
channel_dim_c
"""
channel_schema = pt.StructType([
    pt.StructField("channel_id", pt.LongType(), True),
    pt.StructField("channel_code", pt.StringType(), True),
    pt.StructField("channel_name", pt.StringType(), True),
])
channel_lst = [
    (-1, "UNKNOWN_DIMENSION", None),
    (1, "Channel1", "Channel 1 stores"),
    (2, "Channel2", "Channel 2 dotcom"),
    (6, "Channel6", "Channel 6 web"),
]

"""
store_dim_c
"""
store_schema = pt.StructType([
    pt.StructField("store_id", pt.LongType(), True),
    pt.StructField("store_code", pt.StringType(), True),
    pt.StructField("store_name", pt.StringType(), True),
    pt.StructField("banner_name", pt.LongType(), True),
    pt.StructField("store_mgmt_l20_desc", pt.StringType(), True),
    pt.StructField("BannerDescription", pt.StringType(), True),
])
store_lst = [
    (-1, "UNKNOWN_DIMENSION", None, None, None, None),
    (1, "Store1", None, None, None, None),
    (2, "Store2", None, None, None, None),
    (3, "Store3", None, None, None, None),
    (4, "Store4", None, None, None, None),
    (5, "Store5", None, None, None, None),
    (6, "Store6", None, None, None, None),
    (7, "Store7", None, None, None, None),
    (8, "Store8", None, None, None, None),
    (9, "Store9", None, None, None, None),
    (10, "Store10", None, None, None, None),
    (11, "Store11", None, None, None, None),
    (12, "Store12", None, None, None, None),
    (13, "Store13", None, None, None, None),
    (14, "Store14", None, None, None, None),
    (15, "Store15", None, None, None, None),
    (16, "Store16", None, None, None, None),
    (17, "Store17", None, None, None, None),
    (18, "Store18", None, None, None, None),
    (19, "Store19", None, None, None, None),
    (20, "Store20", None, None, None, None),
    (21, "Store21", None, None, None, None),
    (22, "Store22", None, None, None, None),
    (23, "Store23", None, None, None, None),
    (24, "Store24", None, None, None, None),
    (25, "Store25", None, None, None, None),
    (26, "Store26", None, None, None, None),
    (27, "Store27", None, None, None, None),
    (28, "Store28", None, None, None, None),
    (29, "Store29", None, None, None, None),
    (30, "Store30", None, None, None, None),
    (31, "Store31", None, None, None, None),
    (32, "Store32", None, None, None, None),
    (33, "Store33", None, None, None, None),
    (34, "Store34", None, None, None, None),
    (35, "Store35", None, None, None, None),
    (36, "Store36", None, None, None, None),
    (37, "Store37", None, None, None, None),
    (38, "Store38", None, None, None, None),
    (39, "Store39", None, None, None, None),
    (40, "Store40", None, None, None, None),
    (41, "Store41", None, None, None, None),
    (42, "Store42", None, None, None, None),
    (43, "Store43", None, None, None, None),
    (44, "Store44", None, None, None, None),
    (45, "Store45", None, None, None, None),
    (46, "Store46", None, None, None, None),
    (47, "Store47", None, None, None, None),
    (48, "Store48", None, None, None, None),
    (49, "Store49", None, None, None, None),
    (50, "Store50", None, None, None, None),
    (51, "Store51", None, None, None, None),
    (52, "Store52", None, None, None, None),
    (53, "Store53", None, None, None, None),
    (54, "Store54", None, None, None, None),
    (55, "Store55", None, None, None, None),
    (56, "Store56", None, None, None, None),
    (57, "Store57", None, None, None, None),
    (58, "Store58", None, None, None, None),
    (59, "Store59", None, None, None, None),
    (60, "Store60", None, None, None, None),
    (61, "Store61", None, None, None, None),
    (62, "Store62", None, None, None, None),
    (63, "Store63", None, None, None, None),
    (64, "Store64", None, None, None, None),
    (65, "Store65", None, None, None, None),
    (66, "Store66", None, None, None, None),
    (67, "Store67", None, None, None, None),
    (68, "Store68", None, None, None, None),
    (69, "Store69", None, None, None, None),
    (70, "Store70", None, None, None, None),
    (71, "Store71", None, None, None, None),
]

"""
prod_dim_c
"""
product_schema = pt.StructType([
    pt.StructField("prod_id", pt.StringType(), True),
    pt.StructField("prod_code", pt.StringType(), True),
    pt.StructField("commercial_designation", pt.StringType(), True),
    pt.StructField("prod_comml_l10_code", pt.StringType(), True),
    pt.StructField("prod_comml_l10_desc", pt.StringType(), True),
    pt.StructField("prod_comml_l21_code", pt.StringType(), True),
    pt.StructField("prod_comml_l21_desc", pt.StringType(), True),
    pt.StructField("prod_comml_l22_code", pt.StringType(), True),
    pt.StructField("prod_comml_l22_desc", pt.StringType(), True),
    pt.StructField("prod_comml_l24_code", pt.StringType(), True),
    pt.StructField("prod_comml_l24_desc", pt.StringType(), True),
    pt.StructField("prod_comml_l30_code", pt.StringType(), True),
    pt.StructField("prod_comml_l30_desc", pt.StringType(), True),
    pt.StructField("prod_comml_l20_code", pt.StringType(), True),
    pt.StructField("prod_comml_l20_desc", pt.StringType(), True),
    pt.StructField("prod_comml_l23_code", pt.StringType(), True),
    pt.StructField("prod_comml_l23_desc", pt.StringType(), True),
    pt.StructField("brand_name", pt.StringType(), True),
    pt.StructField("vendor_id", pt.StringType(), True),
    pt.StructField("image_url", pt.StringType(), True),
    pt.StructField("delist_date", pt.StringType(), True),
    pt.StructField("prod_desc", pt.StringType(), True),
])
product_lst = [
    (1, "Product01", None, "Product1", None, "F52CF", None, "F52C", None, "F52", None, "F5", None,
     "F", None, "F52CF", None, "F52C", None, "F5", "2018-01-01 00:00:00.0", None),
    (3, "Product03", None, "Product3", None, "G18AM", None, "G18A", None, "G18", None, "G1", None,
     "G", None, "G18AM", None, "G1S", None, "G1", "2018-01-01 00:00:00.0", None),
    (4, "Product04", None, "Product4", None, "Z65KH", None, "Z65K", None, "Z65", None, "Z6", None,
     "Z", None, "Z65KH", None, "E2A", None, "E2", "2018-01-01 00:00:00.0", None),
    (5, "Product05", None, "Product5", None, "G62RC", None, "G62R", None, "G62", None, "G6", None,
     "G", None, "G62RC", None, "S3E", None, "S3", "2018-01-01 00:00:00.0", None),
    (6, "Product06", None, "Product6", None, "W61DD", None, "W61D", None, "W61", None, "W6", None,
     "W", None, "W61DD", None, "W1G", None, "W1", "2018-01-01 00:00:00.0", None),
    (7, "Product07", None, "Product7", None, "G71BF", None, "G71B", None, "G71", None, "G7", None,
     "G", None, "G71BF", None, "S4E", None, "S4", "2018-01-01 00:00:00.0", None),
    (8, "Product08", None, "Product8", None, "G12AE", None, "G12A", None, "G12", None, "G1", None,
     "G", None, "G12AE", None, "G1G", None, "G1", "2018-01-01 00:00:00.0", None),
    (9, "Product09", None, "Product9", None, "G41MF", None, "G41M", None, "G41", None, "G4", None,
     "G", None, "G41MF", None, "G1P", None, "G1", "2018-01-01 00:00:00.0", None),
    (10, "Product10", None, "Product10", None, "T51AD", None, "T51A", None, "T51", None, "T5", None,
     "T", None, "T51AD", None, "K5A", None, "K5", "2018-01-01 00:00:00.0", None),
    (11, "Product11", None, "Product11", None, "W47DE", None, "W47D", None, "W47", None, "W4", None,
     "W", None, "W47DE", None, "W2C", None, "W2", "2018-01-01 00:00:00.0", None),
    (12, "Product12", None, "Product12", None, "H17AA", None, "H17A", None, "H17", None, "H1", None,
     "H", None, "H17AA", None, "H2A", None, "H2", "2018-01-01 00:00:00.0", None),
    (13, "Product13", None, "Product13", None, "F11AE", None, "F11A", None, "F11", None, "F1", None,
     "F", None, "F11AE", None, "P3D", None, "P3", "2018-01-01 00:00:00.0", None),
    (14, "Product14", None, "Product14", None, "G76AC", None, "G76A", None, "G76", None, "G7", None,
     "G", None, "G76AC", None, "S1L", None, "S1", "2018-01-01 00:00:00.0", None),
    (15, "Product15", None, "Product15", None, "N56CK", None, "N56C", None, "N56", None, "N5", None,
     "N", None, "N56CK", None, "N3D", None, "N3", "2018-01-01 00:00:00.0", None),
    (16, "Product16", None, "Product16", None, "G78BF", None, "G78B", None, "G78", None, "G7", None,
     "G", None, "G78BF", None, "S2E", None, "S2", "2018-01-01 00:00:00.0", None),
    (17, "Product17", None, "Product17", None, "H38AB", None, "H38A", None, "H38", None, "H3", None,
     "H", None, "H38AB", None, "U1A", None, "U1", "2018-01-01 00:00:00.0", None),
    (18, "Product18", None, "Product18", None, "H79GL", None, "H79G", None, "H79", None, "H7", None,
     "H", None, "H79GL", None, "T1C", None, "T1", "2018-01-01 00:00:00.0", None),
    (19, "Product19", None, "Product19", None, "G71CB", None, "G71C", None, "G71", None, "G7", None,
     "G", None, "G71CB", None, "S4A", None, "S4", "2018-01-01 00:00:00.0", None),
    (20, "Product20", None, "Product20", None, "H17AE", None, "H17A", None, "H17", None, "H1", None,
     "H", None, "H17AE", None, "H2A", None, "H2", "2018-01-01 00:00:00.0", None),
    (21, "Product21", None, "Product21", None, "N55DJ", None, "N55D", None, "N55", None, "N5", None,
     "N", None, "N55DJ", None, "N3B", None, "N3", "2018-01-01 00:00:00.0", None),
    (22, "Product22", None, "Product22", None, "F54TH", None, "F54T", None, "F54", None, "F5", None,
     "F", None, "F54TH", None, "D2G", None, "D2", "2018-01-01 00:00:00.0", None),
    (23, "Product23", None, "Product23", None, "F13BB", None, "F13B", None, "F13", None, "F1", None,
     "F", None, "F13BB", None, "P4C", None, "P4", "2018-01-01 00:00:00.0", None),
    (24, "Product24", None, "Product24", None, "F11GE", None, "F11G", None, "F11", None, "F1", None,
     "F", None, "F11GE", None, "P3H", None, "P3", "2018-01-01 00:00:00.0", None),
    (25, "Product25", None, "Product25", None, "F83AG", None, "F83A", None, "F83", None, "F8", None,
     "F", None, "F83AG", None, "P1A", None, "P1", "2018-01-01 00:00:00.0", None),
    (26, "Product26", None, "Product26", None, "F51CJ", None, "F51C", None, "F51", None, "F5", None,
     "F", None, "F51CJ", None, "F51C", None, "F5", "2018-01-01 00:00:00.0", None),
    (27, "Product27", None, "Product27", None, "F72DB", None, "F72D", None, "F72", None, "F7", None,
     "F", None, "F72DB", None, "R1D", None, "R1", "2018-01-01 00:00:00.0", None),
    (28, "Product28", None, "Product28", None, "G46MA", None, "G46M", None, "G46", None, "G4", None,
     "G", None, "G46MA", None, "G3E", None, "G3", "2018-01-01 00:00:00.0", None),
    (29, "Product29", None, "Product29", None, "N55GG", None, "N55G", None, "N55", None, "N5", None,
     "N", None, "N55GG", None, "N3Q", None, "N3", "2018-01-01 00:00:00.0", None),
    (30, "Product30", None, "Product30", None, "B31DJ", None, "B31D", None, "B31", None, "B3", None,
     "B", None, "B31DJ", None, "B1B", None, "B1", "2018-01-01 00:00:00.0", None),
]

"""
card_dim_c
"""
card_schema = pt.StructType([
    pt.StructField("card_id", pt.LongType(), True),
    pt.StructField("prsn_id", pt.LongType(), True),
    pt.StructField("prsn_code", pt.StringType(), True),
    pt.StructField("card_code", pt.StringType(), True),
    pt.StructField("prsn_email_suppress_flag", pt.StringType(), True),
    pt.StructField("prsn_birth_date", pt.StringType(), True),
    pt.StructField("prsn_title_name", pt.StringType(), True),
    pt.StructField("prsn_address_city_name", pt.StringType(), True)
])
card_lst = [
    (1, 1, "Customer1", "Customer1", "S67 1", "2018-01-01 00:00:00.0", None, None),
    (2, 2, "Customer2", "Customer2", "S70 1", "2018-01-01 00:00:00.0", None, None),
    (3, 3, "Customer3", "Customer3", "S51 1", "2018-01-01 00:00:00.0", None, None),
    (5, 5, "Customer5", "Customer5", "SS15 1", "2018-01-01 00:00:00.0", None, None),
    (6, 6, "Customer6", "Customer6", "S65 1", "2018-01-01 00:00:00.0", None, None),
    (7, 7, "Customer7", "Customer7", "S71 1", "2018-01-01 00:00:00.0", None, None),
    (8, 8, "Customer8", "Customer8", "S68 1", "2018-01-01 00:00:00.0", None, None),
    (9, 9, "Customer9", "Customer9", "S38 1", "2018-01-01 00:00:00.0", None, None),
    (10, 10, "Customer10", "Customer10", "S48 1", "2018-01-01 00:00:00.0", None, None),
    (11, 11, "Customer11", "Customer11", "S26 1", "2018-01-01 00:00:00.0", None, None),
    (12, 12, "Customer12", "Customer12", "S66 1", "2018-01-01 00:00:00.0", None, None),
    (13, 13, "Customer13", "Customer13", "S16 1", "2018-01-01 00:00:00.0", None, None),
    (14, 14, "Customer14", "Customer14", "S53 1", "2018-01-01 00:00:00.0", None, None),
    (15, 15, "Customer15", "Customer15", "S47 1", "2018-01-01 00:00:00.0", None, None),
    (16, 16, "Customer16", "Customer16", "S64 1", "2018-01-01 00:00:00.0", None, None),
    (17, 17, "Customer17", "Customer17", "S3 1", "2018-01-01 00:00:00.0", None, None),
    (18, 18, "Customer18", "Customer18", "S69 1", "2018-01-01 00:00:00.0", None, None),
    (19, 19, "Customer19", "Customer19", "S4 1", "2018-01-01 00:00:00.0", None, None),
    (20, 20, "Customer20", "Customer20", "S40 1", "2018-01-01 00:00:00.0", None, None),
]

"""
prsn_pref_seg
"""
prsn_pref_seg_schema = pt.StructType([
    pt.StructField("prsn_id", pt.LongType(), True),
    pt.StructField("prsn_seg_pref_store_1_id", pt.LongType(), True),
    pt.StructField("prsn_seg_pref_store_2_id", pt.LongType(), True),
    pt.StructField("prsn_seg_pref_store_3_id", pt.LongType(), True),
])
prsn_pref_seg_lst = [
    (14, 53, 31, 13),
    (17, 3, 30, -1),
    (13, 16, 39, 28),
    (15, 47, 5, 43),
    (6, 35, 9, 61),
    (3, 8, 51, -1),
    (19, 4, 24, 60),
    (10, 48, -1, -1),
    (8, 10, 27, -1),
    (1, 62, 13, 56),
    (4, 29, 49, -1),
    (2, 44, 12, 45),
    (9, 38, -1, -1),
    (20, 18, 41, 32),
    (5, 37, 50, 55),
    (18, 21, 34, 63),
    (16, 15, 13, 11),
    (11, 26, 20, 33),
    (12, 22, 23, -1),
    (7, 52, 19, 2),
]

"""
prsn_loyalty_seg
"""
prsn_loyalty_seg_schema = pt.StructType([
    pt.StructField("prsn_id", pt.LongType(), True),
    pt.StructField("prsn_seg_loyalty_low_id", pt.LongType(), True),
    pt.StructField("prsn_seg_loyalty_high_id", pt.LongType(), True),
])
prsn_loyalty_seg_lst = [
    (7, 1, 106),
    (10, 0, 105),
    (4, 2, 106),
    (13, 1, 106),
    (16, 1, 106),
    (6, 9, 107),
    (17, 8, 107),
    (5, 1, 106),
    (8, 1, 106),
    (12, 1, 106),
    (18, 1, 106),
    (20, 1, 106),
    (1, 8, 107),
    (9, 1, 106),
    (14, 1, 106),
    (2, 1, 106),
    (15, 1, 106),
    (11, 0, 105),
    (19, 1, 106),
    (3, 8, 107),
]

"""
seg_value_dim_c
"""
seg_value_dim_c_schema = pt.StructType([
    pt.StructField("seg_value_id", pt.LongType(), True),
    pt.StructField("seg_value_code", pt.StringType(), True),
    pt.StructField("seg_type_code", pt.StringType(), True),
])
seg_value_dim_c_lst = [
    (8, "HSL8", "HSHD_SLOYALTY_LOW"),
    (9, "HSL9", "HSHD_SLOYALTY_LOW"),
    (1, "HSL1", "HSHD_SLOYALTY_LOW"),
    (106, "HSH106", "HSHD_SLOYALTY_HIGH"),
    (105, "HSH105", "HSHD_SLOYALTY_HIGH"),
    (107, "HSH107", "HSHD_SLOYALTY_HIGH"),
    (0, "HSL0", "HSHD_SLOYALTY_LOW"),
    (2, "HSL2", "HSHD_SLOYALTY_LOW"),
]

"""
raw_data/fulfillment_store/dotcom_store_postcode.csv
"""
fulfillment_store_schema = pt.StructType([
    pt.StructField("POST_CODE", pt.StringType(), True),
    pt.StructField("RETAIL_OUTLET_NUMBER", pt.StringType(), True),
    pt.StructField("SERVICE_NUMBER", pt.LongType(), True)
])
fulfillment_store_lst = [
    # POST_CODE,RETAIL_OUTLET_NUMBER,SERVICE_NUMBER
    ("S64 1", "Store64", 1),
    ("S16 1", "Store16", 1),
    ("S65 1", "Store65", 1),
    ("S37 1", "Store37", 1),
    ("S47 1", "Store47", 1),
    ("S40 1", "Store40", 1),
    ("S38 1", "Store38", 1),
    ("S66 1", "Store66", 1),
    ("S67 1", "Store67", 1),
    ("S68 1", "Store68", 1),
    ("S29 1", "Store29", 1),
    ("S69 1", "Store69", 1),
    ("S51 1", "Store51", 1),
    ("S4 1", "Store4", 1),
    ("S3 1", "Store3", 1),
    ("S48 1", "Store48", 1),
    ("S70 1", "Store70", 1),
    ("S26 1", "Store26", 1),
    ("S71 1", "Store71", 1),
    ("S53 1", "Store53", 1)
]

"""
raw_data/dotcom_id_lookup/dotcom_id_lookup.csv
"""
dotcom_id_lookup_schema = pt.StructType([
    pt.StructField("PRSN_GHS_CUST_CODE", pt.StringType(), True),
    pt.StructField("HSHD_CODE", pt.StringType(), True),
    pt.StructField("UNIQUE_CUST_CODE", pt.StringType(), True)
])
dotcom_id_lookup_lst = [
    # PRSN_GHS_CUST_CODE,HSHD_CODE,UNIQUE_CUST_CODE
    ("PRSN_GHS_CUST_CODE-C16", "Customer16", "UNIQUE_CUST_CODE-C16"),
    ("PRSN_GHS_CUST_CODE-C1", "Customer1", "UNIQUE_CUST_CODE-C1"),
    ("PRSN_GHS_CUST_CODE-C15", "Customer15", "UNIQUE_CUST_CODE-C15"),
    ("PRSN_GHS_CUST_CODE-C6", "Customer6", "UNIQUE_CUST_CODE-C6"),
    ("PRSN_GHS_CUST_CODE-C19", "Customer19", "UNIQUE_CUST_CODE-C19"),
    ("PRSN_GHS_CUST_CODE-C2", "Customer2", "UNIQUE_CUST_CODE-C2"),
    ("PRSN_GHS_CUST_CODE-C20", "Customer20", "UNIQUE_CUST_CODE-C20"),
    ("PRSN_GHS_CUST_CODE-C8", "Customer8", "UNIQUE_CUST_CODE-C8"),
    ("PRSN_GHS_CUST_CODE-C14", "Customer14", "UNIQUE_CUST_CODE-C14"),
    ("PRSN_GHS_CUST_CODE-C14", "Customer14", "UNIQUE_CUST_CODE-C14"),
]

"""
date_dim/date_df - 42 rows for each date_id between 2017-11-27 & 2018-01-07
"""
date_schema = pt.StructType([
    pt.StructField("date_id", pt.DateType(), True),
    pt.StructField("date_name", pt.StringType(), True),
    pt.StructField("date_short_name", pt.StringType(), True),
    pt.StructField("day_of_week_name", pt.StringType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("fis_day_of_week_num", pt.ShortType(), True)

])
date_lst = [
    (dt.strptime("2017-11-27 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 27, 2017", "2017-11-27",
     "MONDAY", "201740", 1),
    (dt.strptime("2017-11-28 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 28, 2017", "2017-11-28",
     "TUESDAY", "201740", 2),
    (dt.strptime("2017-11-29 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 29, 2017", "2017-11-29",
     "WEDNESDAY", "201740", 3),
    (dt.strptime("2017-11-30 00:00:00", "%Y-%m-%d %H:%M:%S"), "NOVEMBER 30, 2017", "2017-11-30",
     "THURSDAY", "201740", 4),
    (dt.strptime("2017-12-01 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 01, 2017", "2017-12-01",
     "FRIDAY", "201740", 5),
    (dt.strptime("2017-12-02 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 02, 2017", "2017-12-02",
     "SATURDAY", "201740", 6),
    (dt.strptime("2017-12-03 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 03, 2017", "2017-12-03",
     "SUNDAY", "201740", 7),
    (dt.strptime("2017-12-04 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 04, 2017", "2017-12-04",
     "MONDAY", "201741", 1),
    (dt.strptime("2017-12-05 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 05, 2017", "2017-12-05",
     "TUESDAY", "201741", 2),
    (dt.strptime("2017-12-06 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 06, 2017", "2017-12-06",
     "WEDNESDAY", "201741", 3),
    (dt.strptime("2017-12-07 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 07, 2017", "2017-12-07",
     "THURSDAY", "201741", 4),
    (dt.strptime("2017-12-08 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 08, 2017", "2017-12-08",
     "FRIDAY", "201741", 5),
    (dt.strptime("2017-12-09 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 09, 2017", "2017-12-09",
     "SATURDAY", "201741", 6),
    (dt.strptime("2017-12-10 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 10, 2017", "2017-12-10",
     "SUNDAY", "201741", 7),
    (dt.strptime("2017-12-11 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 11, 2017", "2017-12-11",
     "MONDAY", "201742", 1),
    (dt.strptime("2017-12-12 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 12, 2017", "2017-12-12",
     "TUESDAY", "201742", 2),
    (dt.strptime("2017-12-13 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 13, 2017", "2017-12-13",
     "WEDNESDAY", "201742", 3),
    (dt.strptime("2017-12-14 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 14, 2017", "2017-12-14",
     "THURSDAY", "201742", 4),
    (dt.strptime("2017-12-15 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 15, 2017", "2017-12-15",
     "FRIDAY", "201742", 5),
    (dt.strptime("2017-12-16 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 16, 2017", "2017-12-16",
     "SATURDAY", "201742", 6),
    (dt.strptime("2017-12-17 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 17, 2017", "2017-12-17",
     "SUNDAY", "201742", 7),
    (dt.strptime("2017-12-18 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 18, 2017", "2017-12-18",
     "MONDAY", "201743", 1),
    (dt.strptime("2017-12-19 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 19, 2017", "2017-12-19",
     "TUESDAY", "201743", 2),
    (dt.strptime("2017-12-20 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 20, 2017", "2017-12-20",
     "WEDNESDAY", "201743", 3),
    (dt.strptime("2017-12-21 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 21, 2017", "2017-12-21",
     "THURSDAY", "201743", 4),
    (dt.strptime("2017-12-22 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 22, 2017", "2017-12-22",
     "FRIDAY", "201743", 5),
    (dt.strptime("2017-12-23 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 23, 2017", "2017-12-23",
     "SATURDAY", "201743", 6),
    (dt.strptime("2017-12-24 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 24, 2017", "2017-12-24",
     "SUNDAY", "201743", 7),
    (dt.strptime("2017-12-25 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 25, 2017", "2017-12-25",
     "MONDAY", "201744", 1),
    (dt.strptime("2017-12-26 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 26, 2017", "2017-12-26",
     "TUESDAY", "201744", 2),
    (dt.strptime("2017-12-27 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 27, 2017", "2017-12-27",
     "WEDNESDAY", "201744", 3),
    (dt.strptime("2017-12-28 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 28, 2017", "2017-12-28",
     "THURSDAY", "201744", 4),
    (dt.strptime("2017-12-29 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 29, 2017", "2017-12-29",
     "FRIDAY", "201744", 5),
    (dt.strptime("2017-12-30 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 30, 2017", "2017-12-30",
     "SATURDAY", "201744", 6),
    (dt.strptime("2017-12-31 00:00:00", "%Y-%m-%d %H:%M:%S"), "DECEMBER 31, 2017", "2017-12-31",
     "SUNDAY", "201744", 7),
    (dt.strptime("2018-01-01 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 01, 2018", "2018-01-01",
     "MONDAY", "201745", 1),
    (dt.strptime("2018-01-02 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 02, 2018", "2018-01-02",
     "TUESDAY", "201745", 2),
    (dt.strptime("2018-01-03 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 03, 2018", "2018-01-03",
     "WEDNESDAY", "201745", 3),
    (dt.strptime("2018-01-04 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 04, 2018", "2018-01-04",
     "THURSDAY", "201745", 4),
    (dt.strptime("2018-01-05 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 05, 2018", "2018-01-05",
     "FRIDAY", "201745", 5),
    (dt.strptime("2018-01-06 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 06, 2018", "2018-01-06",
     "SATURDAY", "201745", 6),
    (dt.strptime("2018-01-07 00:00:00", "%Y-%m-%d %H:%M:%S"), "JANUARY 07, 2018", "2018-01-07",
     "SUNDAY", "201745", 7)
]

"""
transaction_item_fct - 32 rows for each date_id between 2017-12-01 & 2018-01-01
"""
trans_schema = pt.StructType([
    pt.StructField("transaction_fid", pt.StringType(), True),
    pt.StructField("prod_id", pt.LongType(), True),
    pt.StructField("store_id", pt.LongType(), True),
    pt.StructField("card_id", pt.LongType(), True),
    pt.StructField("item_qty", pt.DecimalType(24, 2), True),
    pt.StructField("net_spend_amt", pt.DecimalType(38, 2), True),
    pt.StructField("spend_amt", pt.DecimalType(38, 2), True),
    pt.StructField("item_discount_amt", pt.DecimalType(38, 2), True),
    pt.StructField("channel_id", pt.LongType(), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("date_id", pt.StringType(), True)
])
trans_lst = [
    # Week - 201740
    ("20171201100950023960194157", 9, 48, 10, Decimal("2.00"), Decimal("3.00"), Decimal("3.76"),
     Decimal("0.76"), 1, "201740", "2017-12-01"),
    ("20171202084727039160822244", 1, 39, 13, Decimal("1.00"), Decimal("41.99"), Decimal("41.99"),
     Decimal("0.00"), 1, "201740", "2017-12-02"),
    ("20171203144007026950149675", 22, 21, 18, Decimal("1.00"), Decimal("1.10"), Decimal("1.29"),
     Decimal("0.19"), 1, "201740", "2017-12-03"),
    # Week - 201741
    ("20171204132046039250829023", 30, 14, 15, Decimal("1.00"), Decimal("47.93"), Decimal("47.93"),
     Decimal("0.00"), 1, "201741", "2017-12-04"),
    ("20171205172100023100165409", 29, 44, 2, Decimal("1.00"), Decimal("4.00"), Decimal("4.00"),
     Decimal("0.00"), 1, "201741", "2017-12-05"),
    ("20171206151619060560788167", 13, 46, -1, Decimal("1.00"), Decimal("0.99"), Decimal("0.99"),
     Decimal("0.00"), 1, "201741", "2017-12-06"),
    ("20171207194616043570212117", 18, 62, 1, Decimal("1.00"), Decimal("10.00"), Decimal("10.00"),
     Decimal("0.00"), 1, "201741", "2017-12-07"),
    ("20171208155253059040314327", 26, 22, 12, Decimal("2.00"), Decimal("3.00"), Decimal("3.60"),
     Decimal("0.60"), 1, "201741", "2017-12-08"),
    ("20171209193441051090911618", 12, 17, -1, Decimal("1.00"), Decimal("20.00"), Decimal("20.00"),
     Decimal("0.00"), 1, "201741", "2017-12-09"),
    ("20171210141252063990066053", 17, 42, -1, Decimal("1.00"), Decimal("0.10"), Decimal("0.10"),
     Decimal("0.00"), 1, "201741", "2017-12-10"),
    # Week - 201742
    ("20171211183244053040092730", 6, 7, -1, Decimal("1.00"), Decimal("16.00"), Decimal("16.00"),
     Decimal("0.00"), 1, "201742", "2017-12-11"),
    ("20171212211525033110016688", 30, 52, 7, Decimal("1.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.00"), 1, "201742", "2017-12-12"),
    ("20171213054908064401417129", 21, 40, 20, Decimal("2.00"), Decimal("3.20"), Decimal("3.20"),
     Decimal("0.00"), 2, "201742", "2017-12-13"),
    ("20171214100145021040141377", 19, 3, 17, Decimal("2.00"), Decimal("0.60"), Decimal("0.60"),
     Decimal("0.00"), 1, "201742", "2017-12-14"),
    ("20171215164554027330745161", 20, 57, -1, Decimal("1.00"), Decimal("2.70"), Decimal("2.70"),
     Decimal("0.00"), 1, "201742", "2017-12-15"),
    ("20171216065447030841034847", 1, 53, 14, Decimal("1.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("0.00"), 2, "201742", "2017-12-16"),
    ("20171217170539020390291592", 14, 35, 6, Decimal("1.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.00"), 1, "201742", "2017-12-17"),
    # Week - 201743
    ("20171218154137037970823411", 16, 6, -1, Decimal("1.00"), Decimal("1.24"), Decimal("1.24"),
     Decimal("0.00"), 1, "201743", "2017-12-18"),
    ("20171219181319021700096809", 23, 54, -1, Decimal("2.00"), Decimal("1.00"), Decimal("1.00"),
     Decimal("0.00"), 1, "201743", "2017-12-19"),
    ("20171220213338029620756325", 3, 8, 3, Decimal("2.00"), Decimal("1.33"), Decimal("2.00"),
     Decimal("0.67"), 1, "201743", "2017-12-20"),
    ("20171221174247064890026667", 8, 36, -1, Decimal("1.00"), Decimal("0.39"), Decimal("0.39"),
     Decimal("0.00"), 1, "201743", "2017-12-21"),
    ("20171222173256020730525703", 24, 37, 5, Decimal("1.00"), Decimal("0.35"), Decimal("0.35"),
     Decimal("0.00"), 1, "201743", "2017-12-22"),
    ("20171223095737061960142624", 25, 15, 16, Decimal("1.00"), Decimal("3.00"), Decimal("3.00"),
     Decimal("0.00"), 1, "201743", "2017-12-23"),
    ("20171224115651032120238394", 7, 20, 11, Decimal("2.00"), Decimal("1.98"), Decimal("1.98"),
     Decimal("0.00"), 1, "201743", "2017-12-24"),
    # Week - 201744
    ("20171225210537038850806205", 31, 25, -1, Decimal("1.00"), Decimal("63.84"), Decimal("63.84"),
     Decimal("0.00"), 1, "201744", "2017-12-25"),
    ("20171226174448062910023178", 27, 58, -1, Decimal("1.00"), Decimal("2.50"), Decimal("2.50"),
     Decimal("0.00"), 1, "201744", "2017-12-26"),
    ("20171227123719054340847535", 4, 27, 8, Decimal("1.00"), Decimal("2.30"), Decimal("2.30"),
     Decimal("0.00"), 1, "201744", "2017-12-27"),
    ("20171228224443056530713473", 28, 59, -1, Decimal("2.00"), Decimal("1.38"), Decimal("1.38"),
     Decimal("0.00"), 1, "201744", "2017-12-28"),
    ("20171229121555032201011627", 15, 38, 9, Decimal("1.00"), Decimal("5.60"), Decimal("7.00"),
     Decimal("1.40"), 1, "201744", "2017-12-29"),
    ("20171230104316033800147802", 5, 29, 4, Decimal("1.00"), Decimal("2.10"), Decimal("2.10"),
     Decimal("0.00"), 1, "201744", "2017-12-30"),
    ("20171231151553021020019894", 11, 4, 19, Decimal("1.00"), Decimal("9.00"), Decimal("9.00"),
     Decimal("0.00"), 1, "201744", "2017-12-31"),
    # Week - 201745
    ("20180101134623025441005632", 10, 1, -1, Decimal("1.00"), Decimal("2.00"), Decimal("2.00"),
     Decimal("0.00"), 1, "201745", "2018-01-01"),
]

"""
purchase_fct
"""
purchases_schema = pt.StructType([
    pt.StructField("Basket", pt.StringType(), True),
    pt.StructField("InstoreAisle", pt.StringType(), True),
    pt.StructField("PacSection", pt.StringType(), True),
    pt.StructField("PacInstoreShelf", pt.StringType(), True),
    pt.StructField("InstoreShelf", pt.StringType(), True),
    pt.StructField("Section", pt.StringType(), True),
    pt.StructField("Group", pt.StringType(), True),
    pt.StructField("Subgroup", pt.StringType(), True),
    pt.StructField("Product", pt.StringType(), True),
    pt.StructField("Customer", pt.StringType(), True),
    pt.StructField("Store", pt.StringType(), True),
    pt.StructField("FulfillmentStore", pt.StringType(), True),
    pt.StructField("PreferredStore1", pt.StringType(), True),
    pt.StructField("PreferredStore2", pt.StringType(), True),
    pt.StructField("PreferredStore3", pt.StringType(), True),
    pt.StructField("Channel", pt.StringType(), True),
    pt.StructField("Quantity", pt.DecimalType(24, 2), True),
    pt.StructField("NetSpendAmount", pt.DecimalType(38, 2), True),
    pt.StructField("SpendAmount", pt.DecimalType(38, 2), True),
    pt.StructField("DiscountAmount", pt.DecimalType(38, 2), True),
    pt.StructField("fis_week_id", pt.StringType(), True),
    pt.StructField("Date", pt.StringType(), True),
])
purchases_lst = [
    ("20171204132046039250829023", "B31DJ", None, None, "B", "B31D", "B31DJ", "Product30",
     "Product30", "Customer15", "Store14", None, "Store47", "Store5", "Store43", "Channel1",
     Decimal("1.00"), Decimal("47.93"), None, None, "201741", "2017-12-04"),
    ("20171205172100023100165409", "N55GG", None, None, "N", "N55G", "N55GG", "Product29",
     "Product29", "Customer2", "Store44", None, "Store44", "Store12", "Store45", "Channel1",
     Decimal("1.00"), Decimal("4.00"), None, None, "201741", "2017-12-05"),
    ("20171206151619060560788167", "F11AE", None, None, "F", "F11A", "F11AE", "Product13",
     "Product13", None, "Store46", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("0.99"), None, None, "201741", "2017-12-06"),
    ("20171207194616043570212117", "H79GL", None, None, "H", "H79G", "H79GL", "Product18",
     "Product18", "Customer1", "Store62", None, "Store62", "Store13", "Store56", "Channel1",
     Decimal("1.00"), Decimal("10.00"), None, None, "201741", "2017-12-07"),
    ("20171208155253059040314327", "F51CJ", None, None, "F", "F51C", "F51CJ", "Product26",
     "Product26", "Customer12", "Store22", None, "Store22", "Store23", "UNKNOWN_DIMENSION",
     "Channel1", Decimal("2.00"), Decimal("3.00"), None, None, "201741", "2017-12-08"),
    ("20171209193441051090911618", "H17AA", None, None, "H", "H17A", "H17AA", "Product12",
     "Product12", None, "Store17", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("20.00"), None, None, "201741", "2017-12-09"),
    ("20171210141252063990066053", "H38AB", None, None, "H", "H38A", "H38AB", "Product17",
     "Product17", None, "Store42", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("0.10"), None, None, "201741", "2017-12-10"),
    ("20171211183244053040092730", "W61DD", None, None, "W", "W61D", "W61DD", "Product6",
     "Product06", None, "Store7", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("16.00"), None, None, "201742", "2017-12-11"),
    ("20171212211525033110016688", "B31DJ", None, None, "B", "B31D", "B31DJ", "Product30",
     "Product30", "Customer7", "Store52", None, "Store52", "Store19", "Store2", "Channel1",
     Decimal("1.00"), Decimal("1.00"), None, None, "201742", "2017-12-12"),
    ("20171213054908064401417129", "N55DJ", None, None, "N", "N55D", "N55DJ", "Product21",
     "Product21", "Customer20", "Store40", None, "Store18", "Store41", "Store32", "Channel2",
     Decimal("2.00"), Decimal("3.20"), None, None, "201742", "2017-12-13"),
    ("20171214100145021040141377", "G71CB", None, None, "G", "G71C", "G71CB", "Product19",
     "Product19", "Customer17", "Store3", None, "Store3", "Store30", "UNKNOWN_DIMENSION",
     "Channel1", Decimal("2.00"), Decimal("0.60"), None, None, "201742", "2017-12-14"),
    ("20171215164554027330745161", "H17AE", None, None, "H", "H17A", "H17AE", "Product20",
     "Product20", None, "Store57", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("2.70"), None, None, "201742", "2017-12-15"),
    ("20171216065447030841034847", "F52CF", None, None, "F", "F52C", "F52CF", "Product1",
     "Product01", "Customer14", "Store53", None, "Store53", "Store31", "Store13", "Channel2",
     Decimal("1.00"), Decimal("3.00"), None, None, "201742", "2017-12-16"),
    ("20171217170539020390291592", "G76AC", None, None, "G", "G76A", "G76AC", "Product14",
     "Product14", "Customer6", "Store35", None, "Store35", "Store9", "Store61", "Channel1",
     Decimal("1.00"), Decimal("1.00"), None, None, "201742", "2017-12-17"),
    ("20171218154137037970823411", "G78BF", None, None, "G", "G78B", "G78BF", "Product16",
     "Product16", None, "Store6", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("1.24"), None, None, "201743", "2017-12-18"),
    ("20171219181319021700096809", "F13BB", None, None, "F", "F13B", "F13BB", "Product23",
     "Product23", None, "Store54", None, None, None, None, "Channel1", Decimal("2.00"),
     Decimal("1.00"), None, None, "201743", "2017-12-19"),
    ("20171220213338029620756325", "G18AM", None, None, "G", "G18A", "G18AM", "Product3",
     "Product03", "Customer3", "Store8", None, "Store8", "Store51", "UNKNOWN_DIMENSION", "Channel1",
     Decimal("2.00"), Decimal("1.33"), None, None, "201743", "2017-12-20"),
    ("20171221174247064890026667", "G12AE", None, None, "G", "G12A", "G12AE", "Product8",
     "Product08", None, "Store36", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("0.39"), None, None, "201743", "2017-12-21"),
    ("20171222173256020730525703", "F11GE", None, None, "F", "F11G", "F11GE", "Product24",
     "Product24", "Customer5", "Store37", None, "Store37", "Store50", "Store55", "Channel1",
     Decimal("1.00"), Decimal("0.35"), None, None, "201743", "2017-12-22"),
    ("20171223095737061960142624", "F83AG", None, None, "F", "F83A", "F83AG", "Product25",
     "Product25", "Customer16", "Store15", None, "Store15", "Store13", "Store11", "Channel1",
     Decimal("1.00"), Decimal("3.00"), None, None, "201743", "2017-12-23"),
    ("20171224115651032120238394", "G71BF", None, None, "G", "G71B", "G71BF", "Product7",
     "Product07", "Customer11", "Store20", None, "Store26", "Store20", "Store33", "Channel1",
     Decimal("2.00"), Decimal("1.98"), None, None, "201743", "2017-12-24"),
    ("20171226174448062910023178", "F72DB", None, None, "F", "F72D", "F72DB", "Product27",
     "Product27", None, "Store58", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("2.50"), None, None, "201744", "2017-12-26"),
    ("20171228224443056530713473", "G46MA", None, None, "G", "G46M", "G46MA", "Product28",
     "Product28", None, "Store59", None, None, None, None, "Channel1", Decimal("2.00"),
     Decimal("1.38"), None, None, "201744", "2017-12-28"),
    ("20171230104316033800147802", "G62RC", None, None, "G", "G62R", "G62RC", "Product5",
     "Product05", None, "Store29", None, None, None, None, "Channel1", Decimal("1.00"),
     Decimal("2.10"), None, None, "201744", "2017-12-30"),
    ("20171229121555032201011627", "N56CK", None, None, "N", "N56C", "N56CK", "Product15",
     "Product15", "Customer9", "Store38", None, "Store38", "UNKNOWN_DIMENSION", "UNKNOWN_DIMENSION",
     "Channel1", Decimal("1.00"), Decimal("5.60"), None, None, "201744", "2017-12-29"),
    ("20171231151553021020019894", "W47DE", None, None, "W", "W47D", "W47DE", "Product11",
     "Product11", "Customer19", "Store4", None, "Store4", "Store24", "Store60", "Channel1",
     Decimal("1.00"), Decimal("9.00"), None, None, "201744", "2017-12-31"),
    ("20171227123719054340847535", "Z65KH", None, None, "Z", "Z65K", "Z65KH", "Product4",
     "Product04", "Customer8", "Store27", None, "Store10", "Store27", "UNKNOWN_DIMENSION",
     "Channel1", Decimal("1.00"), Decimal("2.30"), None, None, "201744", "2017-12-27"),
    ("20171225210537038850806205", None, None, None, None, None, None, None,
     None, None, "Store25", None, None, None, None, "Channel1", Decimal("1.00"), Decimal("63.84"),
     None, None, "201744", "2017-12-25")
]

"""
pacs_info_prod_comml_l22_code
"""
pacs_info_prod_comml_l22_code_schema = pt.StructType([
    pt.StructField("affinityclusternum", pt.StringType(), True),
    pt.StructField("prod_comml_l22_code", pt.StringType(), True),
])
pacs_info_prod_comml_l22_code_lst = [
    ("1", "XY23423"),
    ("1", "XY21438"),
    ("1", "XY23886"),
    ("2", "YZ06616"),
    ("2", "YZ06651"),
    ("2", "XY14979"),
    ("2", "XY14978"),
    ("2", "XY14977"),
    ("2", "XY14449"),
    ("2", "XY28327"),
    ("2", "XY28161"),
    ("2", "XY28028"),
    ("3", "YZ06174"),
    ("3", "YZ06173"),
    ("3", "XY13000"),
    ("3", "XY10490"),
    ("3", "YZ06329"),
    ("3", "YZ06169"),
    ("3", "YZ06176"),
    ("3", "XY18018"),
    ("3", "XY18073"),
    ("3", "XY17439"),
    ("3", "XY28961"),
    ("4", "XY26999"),
    ("4", "XY26339"),
    ("4", "XY14480"),
    ("4", "XY26701"),
    ("4", "XY13389"),
    ("4", "XY14305"),
    ("4", "XY11071")
]

"""
pacs_info_prod_comml_l20_code
"""
pacs_info_prod_comml_l20_code_schema = pt.StructType([
    pt.StructField("affinityclusternum", pt.StringType(), True),
    pt.StructField("prod_comml_l20_code", pt.StringType(), True)
])
pacs_info_prod_comml_l20_code_lst = [
    ("1", "AB5151_16"),
    ("1", "AB5151_60"),
    ("1", "AB5151_17"),
    ("1", "AB5151_50"),
    ("1", "AB5151_27"),
    ("1", "AB5151_65"),
    ("1", "AB5151_70"),
    ("1", "AB5151_19"),
    ("2", "AC3131_50"),
    ("2", "AC3131_54"),
    ("2", "AC3131_56"),
    ("2", "AC3131_65"),
    ("2", "AC3131_70"),
    ("2", "AC3131_74"),
    ("2", "AC3131_75"),
    ("2", "AC3131_79"),
    ("2", "AC3131_82"),
    ("2", "AC3131_84"),
    ("2", "AC3131_88"),
    ("2", "AC3131_89"),
    ("3", "AD0606_06"),
    ("3", "AD0606_10"),
    ("3", "AD0606_24"),
    ("3", "AD0606_32"),
    ("3", "AD0606_61"),
    ("3", "AD0606_64"),
    ("3", "AD0606_77"),
    ("3", "AE1414_08"),
    ("3", "AE1414_10"),
    ("3", "AE1414_12"),
    ("4", "AE1111_01"),
    ("4", "AE1717_02"),
    ("4", "AE1717_04"),
    ("4", "AE1717_05"),
    ("4", "AE1717_06"),
    ("4", "AE1717_11"),
    ("4", "AE1717_13"),
    ("4", "AE1717_27"),
    ("4", "AE1717_28"),
    ("4", "AE1717_29"),
    ("4", "AE1717_30"),
    ("4", "AE1717_31")
]

prsn_pricesense_seg_schema = pt.StructType([
    pt.StructField("prsn_id", pt.StringType(), True),
    pt.StructField("prsn_seg_pricesense_id", pt.StringType(), True)
])
prsn_pricesense_seg_lst = [
    ("4", "AE1717_29"),
    ("4", "AE1717_30"),
]

vendor_lkp_c_schema = pt.StructType([
    pt.StructField("vendor_id", pt.StringType(), True),
    pt.StructField("vendor_code", pt.StringType(), True)
])
vendor_lkp_c_lst = [
    ("4", "AE1717_29"),
    ("4", "AE1717_30")
]
