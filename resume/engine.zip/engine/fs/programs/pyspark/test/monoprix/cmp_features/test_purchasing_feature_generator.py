"""
Monoprix Purchasing feature generator class - Unit test cases
"""


import unittest
from datetime import datetime as dt
from random import choice
from test.monoprix.cmp_features.sample_data_set import test_config, setup_sql, result_set, \
    channel_schema, channel_lst, store_schema, store_lst, product_schema, product_lst, card_schema,\
    card_lst, prsn_pref_seg_schema, prsn_pref_seg_lst, prsn_loyalty_seg_schema, \
    prsn_loyalty_seg_lst, seg_value_dim_c_schema, seg_value_dim_c_lst, date_schema, date_lst, \
    trans_schema, trans_lst, purchases_schema, purchases_lst, pacs_info_prod_comml_l22_code_schema,\
    pacs_info_prod_comml_l22_code_lst, pacs_info_prod_comml_l20_code_schema, \
    pacs_info_prod_comml_l20_code_lst, prsn_pricesense_seg_schema , prsn_pricesense_seg_lst, \
    vendor_lkp_c_schema, vendor_lkp_c_lst
from dunnhumby import contexts
from dunnhumby.cmp_features.purchasing_feature_generator_base import PurchasingFeatureGeneratorBase
from monoprix.cmp_features.purchasing_feature_generator import PurchasingFeatureGenerator
from monoprix.cmp_entities.purchases import Purchases
from monoprix.cmp_entities.transactions_new import TransactionsNew
from pyspark.sql import DataFrame


class TestPurchasingFeatureGenerator(unittest.TestCase):
    """
    Unit test cases for class PurchasingFeatureGenerator
    """

    @classmethod
    def setUpClass(cls):
        cls.run_date = dt.strptime("2018-01-02", "%Y-%m-%d").date()
        # Set required hive & spark config and create databases & tables
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("hive.exec.dynamic.partition", "true")
        cls.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
        cls.sqlContext.setConf("spark.sql.parquet.compression.codec", "gzip")
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")
        cls.sqlContext.sql(setup_sql["drop_db_ssewh"])
        cls.sqlContext.sql(setup_sql["drop_db_ssework"])
        cls.sqlContext.sql(setup_sql["drop_db_pob"])
        cls.sqlContext.sql(setup_sql["create_db_ssewh"])
        cls.sqlContext.sql(setup_sql["create_db_ssework"])
        cls.sqlContext.sql(setup_sql["create_db_pob"])
        # Create temp tables
        cls.sqlContext.createDataFrame(trans_lst, trans_schema). \
            write.saveAsTable("client_ssework.temp_trans")
        cls.temp_purchase_lst = [item for item in purchases_lst if item[16] in ["201741", "201742",
                                                                                "201743"]]
        cls.sqlContext.createDataFrame(cls.temp_purchase_lst, purchases_schema). \
            write.saveAsTable("client_ssework.temp_purchase")
        # Create transaction_item_fct table
        cls.sqlContext.sql(setup_sql["drop_transaction_item_fct"])
        cls.sqlContext.sql(setup_sql["create_transaction_item_fct"])
        cls.sqlContext.sql(setup_sql["ins_transaction_item_fct"])
        # Create purchase_item table
        cls.sqlContext.sql(setup_sql["drop_purchase_fct"])
        cls.sqlContext.sql(setup_sql["create_purchase_fct"])
        cls.sqlContext.sql(setup_sql["ins_purchase_fct"])
        # Create dim tables
        cls.sqlContext.createDataFrame(channel_lst, channel_schema).\
            write.saveAsTable("client_ssewh.channel_dim_c")
        cls.sqlContext.createDataFrame(store_lst, store_schema). \
            write.saveAsTable("client_ssewh.store_dim_c")
        cls.sqlContext.createDataFrame(product_lst, product_schema). \
            write.saveAsTable("client_ssewh.prod_dim_c")
        cls.sqlContext.createDataFrame(card_lst, card_schema). \
            write.saveAsTable("client_ssewh.card_dim_c")
        cls.sqlContext.createDataFrame(prsn_pref_seg_lst, prsn_pref_seg_schema). \
            write.saveAsTable("client_ssewh.prsn_pref_seg")
        cls.sqlContext.createDataFrame(prsn_loyalty_seg_lst, prsn_loyalty_seg_schema). \
            write.saveAsTable("client_ssewh.prsn_loyalty_seg")
        cls.sqlContext.createDataFrame(seg_value_dim_c_lst, seg_value_dim_c_schema). \
            write.saveAsTable("client_ssewh.seg_value_dim_c")
        cls.sqlContext.createDataFrame(prsn_pricesense_seg_lst, prsn_pricesense_seg_schema). \
            write.saveAsTable("client_ssewh.prsn_pricesense_seg")
        cls.sqlContext.createDataFrame(vendor_lkp_c_lst, vendor_lkp_c_schema). \
            write.saveAsTable("client_ssewh.vendor_lkp_c")
        cls.sqlContext.createDataFrame(pacs_info_prod_comml_l20_code_lst,
                                       pacs_info_prod_comml_l20_code_schema).\
            write.saveAsTable("client_ssewh.pacs_info_prod_comml_l20_code")
        cls.sqlContext.createDataFrame(pacs_info_prod_comml_l22_code_lst,
                                       pacs_info_prod_comml_l22_code_schema). \
            write.saveAsTable("client_ssewh.pacs_info_prod_comml_l22_code")
        cls.sqlContext.createDataFrame(date_lst, date_schema). \
            write.saveAsTable("client_ssewh.date_dim")

    @classmethod
    def tearDownClass(cls):
        # Drop databases and tables
        cls.sqlContext.sql(setup_sql["drop_db_ssewh"])
        cls.sqlContext.sql(setup_sql["drop_db_ssework"])
        cls.sqlContext.sql(setup_sql["drop_db_pob"])

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        """
        Unit test case for __init__()
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsInstance(pur_feat_gen, PurchasingFeatureGenerator)
        self.assertTrue(issubclass(PurchasingFeatureGenerator, PurchasingFeatureGeneratorBase))
        self.assertIsInstance(pur_feat_gen.features_specifications, list)
        self.assertIsInstance(choice(pur_feat_gen.features_specifications), dict)

    def test_purchases(self):
        """
        Unit test case for purchases (property/getter) method
        :return: None
        """
        # Create purchase_item table
        self.sqlContext.sql(setup_sql["drop_purchase_fct"])
        self.sqlContext.sql(setup_sql["create_purchase_fct"])
        self.sqlContext.sql(setup_sql["ins_purchase_fct"])
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)

        self.assertIsInstance(pur_feat_gen.purchases, Purchases)
        self.assertEqual(pur_feat_gen.purchases.data.count(), len(self.temp_purchase_lst))

    def test_transactions(self):
        """
        Unit test case for transactions (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsInstance(pur_feat_gen.transactions, TransactionsNew)
        self.assertEqual(pur_feat_gen.transactions.data.count(), len(trans_lst))

    def test_customers_df(self):
        """
        Unit test case for customers_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ["card_id", "Customer", "FulfillmentStore", "PreferredStore1", "PreferredStore2",
                   "PreferredStore3"]
        self.assertIsInstance(pur_feat_gen.customers_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.customers_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.customers_df.count(), len(card_lst))

    def test_products_df(self):
        """
        Unit test case for products_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ["prod_id"] + test_config["SSEProductHierarchy"]
        self.assertIsInstance(pur_feat_gen.products_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.products_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.products_df.count(),
                         len([item for item in product_lst if not item[3].startswith("-")]))

    def test_stores_df(self):
        """
        Unit test case for stores_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ["store_id", "Store"]
        self.assertIsInstance(pur_feat_gen.stores_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.stores_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.stores_df.count(), len(store_lst))

    def test_channels_df(self):
        """
        Unit test case for channels_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ["channel_id", "Channel"]
        self.assertIsInstance(pur_feat_gen.channels_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.channels_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.channels_df.count(),
                         len([item for item in channel_lst if item[1] != "CBP"]))

    def test_dates_df(self):
        """
        Unit test case for dates_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ["date_id", "date_name", "date_short_name", "day_of_week_name", "fis_week_id",
                   "fis_day_of_week_num"]
        self.assertIsInstance(pur_feat_gen.dates_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.dates_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.dates_df.count(), len(date_lst))

    def test_generate_and_write_features(self):
        """
        Unit test case for customers_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        res = pur_feat_gen.generate_and_write_features(clean_run=False)
        self.assertTrue(res)
        # Check/Test date/fis_week ranges
        dates_in_date_df = pur_feat_gen.required_fis_weeks
        purchases_date = pur_feat_gen.purchases.data.select("fis_week_id").distinct().collect()
        purchases_date = [x["fis_week_id"] for x in purchases_date if x["fis_week_id"] in dates_in_date_df]
        self.assertListEqual(sorted(purchases_date),
                             sorted(result_set["required_fis_weeks"]))
        self.assertEqual(pur_feat_gen.cadence_week, result_set["cadence_week_for_fis_week_id"])
        self.assertEqual(pur_feat_gen.since_date, result_set["since_date"])
        # Check/Test conditions against purchase_fct table (purchases entity)
        # Refresh purchases_fct table metadata
        self.sqlContext.refreshTable(pur_feat_gen.purchases.table_name)
        pur_feat_gen.purchases.get_data()
        self.assertEqual(pur_feat_gen.purchases.data.count(), len(purchases_lst))
        result_df = self.sqlContext.createDataFrame(purchases_lst, purchases_schema)
        pur_feat_gen.purchases.data.subtract(result_df).show(n=10, truncate=False)
        result_df.subtract(pur_feat_gen.purchases.data).show(n=10, truncate=False)
        self.assertEqual(pur_feat_gen.purchases.data.subtract(result_df).count(), 0)
        self.assertEqual(result_df.subtract(pur_feat_gen.purchases.data).count(), 0)
        purchase_part = sorted(list(set(
            [item[0] for item in pur_feat_gen.purchases.get_partition_info(refresh=True)])))
        self.assertListEqual(purchase_part, sorted(result_set["required_fis_weeks"]))
        # Check/Test conditions against summary tables
        for item in range(2):
            random_feature = choice(pur_feat_gen.features_specifications)["name"]
            sum_tab = test_config["SSEHiveWorkdb"] + "." + random_feature + "_summary"
            part_info = sorted(list(set(pur_feat_gen.get_partition_info(tab_name=sum_tab))))
            self.assertListEqual(part_info, sorted(result_set["required_fis_weeks"]))
