"""
Test cmp_audience_selection_integration
"""
import datetime
import unittest
from decimal import Decimal

from pyspark.sql.types import StructType, StructField, IntegerType, StringType

from dunnhumby import contexts
from monoprix.cmp_audience_selection_integration import GenerateCsvForAudienceSelection
from test.monoprix.test_setup import TestSetup


class TestCmpAudienceSelectionIntegration(unittest.TestCase):
    """Test cmp_audience_selection_integration"""

    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")
        cls.audience_dataframe_module = GenerateCsvForAudienceSelection(
            {"SSEHiveDatabasePrefix": "client", "cadence_date": "201806"})

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()
        schema = TestSetup().get_transaction_item_fct_schema()
        data = [
            ('aaa', '2010-03-31 00:00:00.0', 1, 556286300, 1, 1, Decimal('1.0'), Decimal('1.0')),
            ('aaa', '2010-03-31 00:00:00.0', 2, 556286301, 1, 1, Decimal('1.0'), Decimal('1.0'))]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_ssewh.transaction_item_fct')
        schema = TestSetup().get_card_dim_c_schema()
        data = [(556286300, 269002535, 'BSK_100203427', 'N', None, '2',
                 datetime.datetime(2017, 9, 19, 18, 26, 1), 'Paris'), (
                    556286301, 269002536, 'BSK_100203428', 'Y', None, '2',
                    datetime.datetime(2017, 9, 19, 18, 26, 1), 'Paris')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        self.prsn_loyalty_seg_schema = StructType(
            [StructField("prsn_seg_loyalty_high_id", IntegerType(), True),
             StructField("prsn_seg_loyalty_low_id", IntegerType(), True),
             StructField("prsn_id", IntegerType(), True)])
        self.prsn_pref_seg_schema = StructType([StructField("prsn_id", IntegerType(), True),
                                                StructField("prsn_seg_pref_store_1_ID",
                                                            IntegerType(), True),
                                                StructField("prsn_seg_pref_store_2_ID",
                                                            IntegerType(), True),
                                                StructField("prsn_seg_pref_store_3_ID",
                                                            IntegerType(), True), ])
        self.seg_value_dim_c_schema = StructType([StructField("seg_type_code", StringType(), True),
                                                  StructField("seg_value_id", IntegerType(), True),
                                                  StructField("seg_value_code", StringType(),
                                                              True)])

        schema = TestSetup.get_prod_dim_c_schema()

        data = [(1, '3760114521262', '*100G MEDAILLON LAND.TRUF&FG', 'CA0606_2021300701',
                 'CONSERVES LEGUMES / VIANDES', 'MB6767_92', 'EPICERIE FINE', 'MB6767_50',
                 'CONS LEG VIAND POISSPLTSCUIS', 'CA06213', 'EPICERIE FINE', 'CA06',
                 'EPICERIE/ENTRETIEN', 'CA', 'ALIMENTAIRE NON PERISSABLE', 'C', 'ALIMENTAIRE',
                 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0', 'abcd'), (
                    2, '8777', 'TAB BONHEUR LAIT', 'PI1616_0257600220', 'DALLOYAU 5,5%',
                    'MB6767_98', 'PARTENAIRE GL', 'PI1616_02', 'PARTENAIRE GL NON TR', 'PI16576',
                    'PARTENAIRE GL NON TR', 'MC56', 'CAFETERIA', 'MC', 'CAFETERIA ET ESSENCE', 'C',
                    'CAFETERIA ET ESSENCE', 'HEINZ', 'A', 'image/url', '9999-12-31 00:00:00.0',
                    'abcd')]

        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.prod_dim_c')
        schema = StructType().add(StructField("store_id", StringType(), True)).add(
            StructField("store_code", StringType(), True)).add("store_name", StringType(),
                                                               True).add("banner_name",
                                                                         StringType(), True).add(
            "store_mgmt_l20_desc", StringType(), True)
        data = [(1, '0072', 'MONO MULHOUSE', 'MONOPRIX', 'Est'),
                (2, '4409', 'STATION GARE STRASBOURG', 'DAILY', 'Est'),
                (3, '9959', 'FAO BEAUTY MONOP', 'BEAUTY', 'Paris')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.store_dim_c')
        schema = StructType([StructField("channel_id", IntegerType(), True),
                             StructField("channel_code", StringType(), True),
                             StructField("channel_name", StringType(), True)])
        data = [(1, '1', 'Instore')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.channel_dim_c')

        schema_vendor = TestSetup.get_vendor_lkp_c_schema()

        data_vendor = [('A', 'A'), ]
        self.sqlContext.createDataFrame(data_vendor, schema_vendor).saveAsTable(
            'client_ssewh.vendor_lkp_c')

        schema = TestSetup.get_audience_selection_retention_schema()
        data = [(269002535, '3760114521262', True, True, True, True),
                (269002536, '8777', True, True, True, True)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_pob.monodeal_audience_science_current')

        schema = TestSetup.get_monodeal_audience_science_penetration_categories_current_schema()
        data = [(269002535, '3760114521262', True, True), (269002536, '8777', True, True)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_pob.monodeal_audience_science_penetration_categories_current')

        schema = TestSetup.get_product_all_all_all_1w52w_schema()
        data = [('201806', 'ALL', '3760114521262', '12', '1', 12),
                ('201806', 'ALL', '8777', '12', '1', 12)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_pob.product_all_all_all_1w52w')

        schema = TestSetup.get_product_customer_all_all_1w52w_schema()
        data = [('201806', '269002535', '3760114521262', '12', '1', 12),
                ('201806', '269002536', '8777', '12', '1', 12)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_pob.product_customer_all_all_1w52w')

        schema = TestSetup.get_instoreshelf_customer_all_all_1w52w_schema()
        data = [('201806', '269002535', 'MB6767_92', '12', '1', 12),
                ('201806', '269002536', 'MB6767_98', '12', '1', 12)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_pob.instoreshelf_customer_all_all_1w52w')

        schema = TestSetup.get_group_customer_all_all_1w52w_schema()
        data = [('201806', '269002535', 'MB6767_50', '12', '1', 12),
                ('201806', '269002536', 'PI1616_02', '12', '1', 12)]
        self.sqlContext.createDataFrame(data, schema).saveAsTable(
            'client_pob.group_customer_all_all_1w52w')

        l = [(1, 2, 556286300)]
        self.sqlContext.createDataFrame(l, self.prsn_loyalty_seg_schema).saveAsTable(
            'client_ssewh.prsn_loyalty_seg')

        l = [(556286300, 2, 1, 1)]
        self.sqlContext.createDataFrame(l, self.prsn_pref_seg_schema).saveAsTable(
            'client_ssewh.prsn_pref_seg')

        l = [('PRSN_SLOYALTY_LOW', 2, '2')]
        self.sqlContext.createDataFrame(l, self.seg_value_dim_c_schema).saveAsTable(
            'client_ssewh.seg_value_dim_c')

        self.sqlContext.createDataFrame([(556286300, 1)], StructType(
            [StructField("prsn_id", IntegerType(), True),
             StructField("prsn_seg_pricesense_id", IntegerType(), True)])).saveAsTable(
            'client_ssewh.prsn_pricesense_seg')
        self.pac_section_table_schema = StructType(
            [StructField("affinityclusternum", StringType(), True),
                StructField("prod_comml_l22_code", StringType(), True), ])
        self.pac_InstoreShelf_table_schema = StructType(
            [StructField("affinityclusternum", StringType(), True),
                StructField("prod_comml_l20_code", StringType(), True), ])
        self.sqlContext.createDataFrame([], self.pac_section_table_schema).saveAsTable(
            'client_ssewh.pacs_info_prod_comml_l22_code')
        self.sqlContext.createDataFrame([], self.pac_InstoreShelf_table_schema).saveAsTable(
            'client_ssewh.pacs_info_prod_comml_l20_code')

    def tearDown(self):
        pass

    def test_generate_audience_data_for_product_all_grain_functioning(self):
        """This function ensure the functioning of the function"""
        df = self.audience_dataframe_module.generate_audience_data_for_product_all_grain(
            '/path/').collect()
        self.assertEquals(len(df), 2)

    def test_generate_audience_data_for_multiple_customer_product_grain_functioning(self):
        """This function ensure the functioning of the function"""
        df = self.audience_dataframe_module.generate_audience_data_for_multiple_customer_product_grain(
            '/path/').collect()
        self.assertEquals(len(df), 2)

    def test_generate_audience_data_for_customer_product_grain_functioning(self):
        """This function ensure the functioning of the function"""
        df = self.audience_dataframe_module.generate_audience_data_for_customer_product_grain(
            '/path/').collect()
        self.assertEquals(len(df), 1)

    def test_generate_audience_data_for_customer_instoreshelf_grain_functioning(self):
        """This function ensure the functioning of the function"""
        df = self.audience_dataframe_module.generate_audience_data_for_customer_instoreshelf_grain(
            '/path/').collect()
        self.assertEquals(len(df), 1)

    def test_generate_audience_data_for_customer_group_grain_functioning(self):
        """This function ensure the functioning of the function"""
        df = self.audience_dataframe_module.generate_audience_data_for_customer_group_grain(
            '/path/').collect()
        self.assertEquals(len(df), 1)
