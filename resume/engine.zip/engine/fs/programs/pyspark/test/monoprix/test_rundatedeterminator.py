"""
Test rundate_determinator
"""
import datetime
import unittest
from decimal import Decimal

from pyspark.sql.types import StructType, StructField, IntegerType, StringType

from dunnhumby import contexts
from monoprix.rundate_determinator import RunDateDeterminator
from test.monoprix.test_setup import TestSetup


class TestRundateDeterminator(unittest.TestCase):
    """Test rundate_determinator"""

    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.setConf("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        TestSetup().create_empty_database()
        schema = TestSetup().get_transaction_item_fct_schema()
        data = [('aaa', '2010-03-31 00:00:00.0', 1, 1, 1, 1, Decimal('1.0'), Decimal('1.0'))]
        self.sqlContext.createDataFrame(data, schema)\
            .saveAsTable('client_ssewh.transaction_item_fct')
        schema = StructType(
            [StructField("prod_id", IntegerType(), True),
             StructField("prod_code", StringType(), True),
             StructField("prod_comml_l20_code", StringType(), True),
             StructField("prod_comml_l24_code", StringType(), True)])
        data = [(1, 'Bananas', '', 'CA')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.prod_dim_c')
        schema = StructType(
            [StructField("card_id", IntegerType(), True),
             StructField("prsn_code", StringType(), True)])
        data = [(1, 'JohnDoe')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.card_dim_c')
        schema = StructType() \
            .add(StructField("store_id", StringType(), True)) \
            .add(StructField("store_code", StringType(), True)) \
            .add("store_name", StringType(), True) \
            .add("banner_name", StringType(), True) \
            .add("store_mgmt_l20_desc", StringType(), True)
        data = [
            (1, '0072', 'MONO MULHOUSE', 'MONOPRIX', 'Est'),
            (2, '4409', 'STATION GARE STRASBOURG', 'DAILY', 'Est'),
            (3, '9959', 'FAO BEAUTY MONOP', 'BEAUTY', 'Paris')
        ]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.store_dim_c')
        schema = StructType(
            [StructField("channel_id", IntegerType(), True),
             StructField("channel_code", StringType(), True),
             StructField("channel_name", StringType(), True)])
        data = [(1, '1', 'Instore')]
        self.sqlContext.createDataFrame(data, schema).saveAsTable('client_ssewh.channel_dim_c')

    def tearDown(self):
        pass

    def test_rundate_determinator_returns_most_recent_txn(self):
        """Where tansactions exist, return most recent rundate"""
        rundate_determinator = RunDateDeterminator({"SSEHiveDatabasePrefix": "client"})
        run_date = rundate_determinator.run_date
        self.assertEquals(run_date, datetime.date(2010, 4, 1))
