"""
Utilities to aid with unit testing
"""
import datetime
from dunnhumby import contexts
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, DateType, \
    DecimalType, BooleanType


class TestSetup(object):
    """
    Utilities to aid with unit testing
    """

    def __init__(self):
        self.sqlContext = contexts.sql_context()
        self.sqlContext.setConf("spark.sql.shuffle.partitions", "1")
        self.sc = contexts.sc()

    def create_datebase_if_not_exists(self, client, database):
        """create {client}_{database} if it does not exist"""
        self.sqlContext.sql(
            'create database if not exists {client}_{database}'.format(client=client,
                                                                       database=database))

    def drop_table_if_exists(self, client, database, table):
        """drop {client}_{database}.{table} if it exists"""
        self.sqlContext.sql(
            'drop table if exists {client}_{db}.{table}'.format(client=client, db=database,
                                                                table=table))

    def create_empty_database(self, client='client'):
        """
        Creates an empty "ssewh database if it does not already exist
        :param client:
        :return:
        """
        self.sqlContext.sql('create database if not exists {client}_ssewh'.format(client=client))
        self.sqlContext.sql('create database if not exists {client}_pob'.format(client=client))
        self.drop_table_if_exists(client, 'ssewh', 'transaction_item_fct')
        self.drop_table_if_exists(client, 'ssewh', 'prod_dim_c')
        self.drop_table_if_exists(client, 'ssewh', 'pacs_info_prod_comml_l22_code')
        self.drop_table_if_exists(client, 'ssewh', 'pacs_info_prod_comml_l20_code')
        self.drop_table_if_exists(client, 'ssewh', 'card_dim_c')
        self.drop_table_if_exists(client, 'ssewh', 'store_dim_c')
        self.drop_table_if_exists(client, 'ssewh', 'channel_dim_c')
        self.drop_table_if_exists(client, 'ssewh', 'date_dim')
        self.drop_table_if_exists(client, 'ssewh', 'prsn_loyalty_seg')
        self.drop_table_if_exists(client, 'ssewh', 'seg_value_dim_c')
        self.drop_table_if_exists(client, 'ssewh', 'vendor_lkp_c')
        self.drop_table_if_exists(client, 'ssewh', 'prsn_pref_seg')
        self.drop_table_if_exists(client, 'ssewh', 'prsn_pricesense_seg')
        self.drop_table_if_exists(client, 'pob', 'channel_customer_product_store_features')
        self.drop_table_if_exists(client, 'pob', 'monodeal_audience_science_current')
        self.drop_table_if_exists(client, 'pob',
                                  'monodeal_audience_science_penetration_categories_current')
        self.drop_table_if_exists(client, 'pob', 'product_all_all_all_1w52w')
        self.drop_table_if_exists(client, 'pob', 'product_customer_all_all_1w52w')
        self.drop_table_if_exists(client, 'pob', 'instoreshelf_customer_all_all_1w52w')
        self.drop_table_if_exists(client, 'pob', 'group_customer_all_all_1w52w')

    @staticmethod
    def get_prod_dim_c_schema():
        """returns a StructType for prod_dim_c"""
        return StructType().add(StructField("prod_id", IntegerType(), True)).add(
            StructField("prod_code", StringType(), True)).add("commercial_designation",
                                                              StringType(), True).add(
            "prod_comml_l10_code", StringType(), True).add("prod_comml_l10_desc", StringType(),
                                                           True).add("prod_comml_l20_code",
                                                                     StringType(), True).add(
            "prod_comml_l20_desc", StringType(), True).add("prod_comml_l21_code", StringType(),
                                                           True).add("prod_comml_l21_desc",
                                                                     StringType(), True).add(
            "prod_comml_l22_code", StringType(), True).add("prod_comml_l22_desc", StringType(),
                                                           True).add("prod_comml_l23_code",
                                                                     StringType(), True).add(
            "prod_comml_l23_desc", StringType(), True).add("prod_comml_l24_code", StringType(),
                                                           True).add("prod_comml_l24_desc",
                                                                     StringType(), True).add(
            "prod_comml_l30_code", StringType(), True).add("prod_comml_l30_desc", StringType(),
                                                           True).add("brand_name", StringType(),
                                                                     True).add('vendor_id',
                                                                               StringType(),
                                                                               True).add(
            'image_url', StringType(), True).add('delist_date', StringType(), True).add('prod_desc',
                                                                                        StringType(),
                                                                                        True)

    @staticmethod
    def get_vendor_lkp_c_schema():
        """returns a StructType for vendor_lkp_c"""
        return StructType([StructField("vendor_id", StringType(), True),
                           StructField("vendor_code", StringType(), True)])

    @staticmethod
    def get_transaction_item_fct_schema():
        """returns a StructType for transaction_item_fct"""
        return StructType([StructField("transaction_fid", StringType(), True),
                           StructField("date_id", StringType(), True),
                           StructField("prod_id", IntegerType(), True),
                           StructField("card_id", IntegerType(), True),
                           StructField("store_id", IntegerType(), True),
                           StructField("channel_id", IntegerType(), True),
                           StructField("item_qty", DecimalType(18, 2), True),
                           StructField("net_spend_amt", DecimalType(18, 2), True)])

    @staticmethod
    def get_card_dim_c_schema():
        """returns a StructType for card_dim_c"""
        return StructType([StructField("card_id", IntegerType(), True),
                           StructField("prsn_id", IntegerType(), True),
                           StructField("prsn_code", StringType(), True),
                           StructField("prsn_email_suppress_flag", StringType(), True),
                           StructField("prsn_birth_date", DateType(), True),
                           StructField("prsn_title_name", StringType(), True),
                           StructField("modified_dttm", DateType(), True),
                           StructField("prsn_address_city_name", StringType(), True)])

    @staticmethod
    def get_audience_selection_retention_schema():
        """returns a StructType for audience_selection_retenntion"""
        return StructType([StructField("customer", StringType(), True),
                           StructField("product", StringType(), True),
                           StructField("isfrequencyincreasecandidate", BooleanType(), True),
                           StructField("isrewardloyalcandidate", BooleanType(), True),
                           StructField("isincreaseaveragerevenueperusercandidate", BooleanType(),
                                       True),
                           StructField("isconsumerrecovercandidate", BooleanType(), True)])

    @staticmethod
    def get_monodeal_audience_science_penetration_categories_current_schema():
        """returns a StructType for monodeal_audience_science_penetration_categories_current"""
        return StructType([StructField("customer", StringType(), True),
                           StructField("category", StringType(), True),
                           StructField("category_attribute", StringType(), True),
                           StructField("isincreasepenetrationcandidate", BooleanType(), True)])

    @staticmethod
    def get_product_all_all_all_1w52w_schema():
        """returns a StructType for product_all_all_all_1w52w"""
        return StructType([StructField("cadence_week", StringType(), True),
                           StructField("customer", StringType(), True),
                           StructField("product", StringType(), True),
                           StructField("store", StringType(), True),
                           StructField("channel", StringType(), True),
                           StructField("baskets_1w52w", IntegerType(), True)])

    @staticmethod
    def get_product_customer_all_all_1w52w_schema():
        """returns a StructType for product_customer_all_all_1w52w"""
        return StructType([StructField("cadence_week", StringType(), True),
                           StructField("customer", StringType(), True),
                           StructField("product", StringType(), True),
                           StructField("store", StringType(), True),
                           StructField("channel", StringType(), True),
                           StructField("baskets_1w52w", IntegerType(), True)])

    @staticmethod
    def get_instoreshelf_customer_all_all_1w52w_schema():
        """returns a StructType for instoreshelf_customer_all_all_1w52w"""
        return StructType([StructField("cadence_week", StringType(), True),
                           StructField("customer", StringType(), True),
                           StructField("instoreshelf", StringType(), True),
                           StructField("store", StringType(), True),
                           StructField("channel", StringType(), True),
                           StructField("baskets_1w52w", IntegerType(), True)])

    @staticmethod
    def get_group_customer_all_all_1w52w_schema():
        """returns a StructType for group_customer_all_all_1w52w"""
        return StructType([StructField("cadence_week", StringType(), True),
                           StructField("customer", StringType(), True),
                           StructField("group", StringType(), True),
                           StructField("store", StringType(), True),
                           StructField("channel", StringType(), True),
                           StructField("baskets_1w52w", IntegerType(), True)])

    @staticmethod
    def get_monodeal_audience_science_category_lookup_current_schema():
        """returns a StructType for monodeal_audience_science_category_lookup_current"""
        return StructType([StructField("product", StringType(), True),
                           StructField("category", StringType(), True),
                           StructField("category_attribute", StringType(), True)])

    @staticmethod
    def get_card_dim_c_data_one_row_johndoe():
        """Return a 1-element list where the element is a tuple for JohnDoe"""
        return [(1, 1, 'JohnDoe', 'Y', None, 1, datetime.date(1970, 1, 1), 'Paris')]


def create_empty_tables(sqlContext):
    """Many of these tests were creating the same identical, empty, tables:
    store_dim_c
    prsn_loyalty_seg
    seg_value_dim_c
    prsn_pref_seg
    prsn_pricesense_seg
    so I've refactored that code into this
    function"""
    sqlContext.createDataFrame([], StructType([StructField("store_id", IntegerType(), True),
                                               StructField("store_code", StringType(),
                                                           True)])).saveAsTable(
        'client_ssewh.store_dim_c')
    sqlContext.createDataFrame([], StructType(
        [StructField("prsn_seg_loyalty_high_id", IntegerType(), True),
         StructField("prsn_seg_loyalty_low_id", IntegerType(), True),
         StructField("prsn_id", IntegerType(), True)])).saveAsTable('client_ssewh.prsn_loyalty_seg')
    sqlContext.createDataFrame([], StructType([StructField("seg_type_code", IntegerType(), True),
                                               StructField("seg_value_id", IntegerType(), True),
                                               StructField("seg_value_code", IntegerType(),
                                                           True)])).saveAsTable(
        'client_ssewh.seg_value_dim_c')
    sqlContext.createDataFrame([], StructType([StructField("prsn_id", IntegerType(), True),
                                               StructField("prsn_seg_pref_store_1_id",
                                                           IntegerType(), True),
                                               StructField("prsn_seg_pref_store_2_id",
                                                           IntegerType(), True),
                                               StructField("prsn_seg_pref_store_3_id",
                                                           IntegerType(), True)])).saveAsTable(
        'client_ssewh.prsn_pref_seg')
    sqlContext.createDataFrame([], StructType([StructField("prsn_id", IntegerType(), True),
                                               StructField("prsn_seg_pricesense_id", IntegerType(),
                                                           True)])).saveAsTable(
        'client_ssewh.prsn_pricesense_seg')
