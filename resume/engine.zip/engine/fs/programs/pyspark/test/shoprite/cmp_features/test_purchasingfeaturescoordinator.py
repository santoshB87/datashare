"""
Meijer Purchasing feature generator class - Unit test cases
"""


import unittest
from datetime import datetime as dt
from random import choice
from test.shoprite.cmp_features.sample_data_set import \
    test_config, feature_specs, setup_sql, result_set, \
    product_schema, product_lst,\
    customer_schema, customer_lst,\
    date_schema, date_lst, \
    trans_schema, trans_lst,\
    purchases_schema, purchases_lst,\
    pac_subgroup_lst, pac_subgroup_schema,\
    stores_schema, stores_lst

from dunnhumby import contexts
from dunnhumby.cmp_features.purchasing_feature_generator_base import PurchasingFeatureGeneratorBase
from shoprite.cmp_features.purchasing_feature_generator import PurchasingFeatureGenerator
from shoprite.cmp_entities.purchases import Purchases
from shoprite.cmp_entities.transactions import Transactions
from pyspark.sql import DataFrame
import mock


import logging
logger = logging.getLogger(__name__)


class TestPurchasingFeatureGenerator(unittest.TestCase):
    """
    Unit test cases for class TestPurchasingFeatureGenerator
    """

    @classmethod
    def setUpClass(cls):
        cls.run_date = dt.strptime("2018-01-02", "%Y-%m-%d").date()
        # Set required hive & spark config and create databases & tables
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.catalog.clearCache()
        cls.sqlContext.conf.set("hive.exec.dynamic.partition", "true")
        cls.sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
        cls.sqlContext.conf.set("spark.sql.parquet.compression.codec", "gzip")
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")
        cls.sqlContext.sql(setup_sql["drop_db_ssewh"])
        cls.sqlContext.sql(setup_sql["drop_db_ssework"])
        cls.sqlContext.sql(setup_sql["drop_db_pob"])
        cls.sqlContext.sql(setup_sql["create_db_ssewh"])
        cls.sqlContext.sql(setup_sql["create_db_ssework"])
        cls.sqlContext.sql(setup_sql["create_db_pob"])
        # Create temp tables
        cls.sqlContext.createDataFrame(trans_lst, trans_schema). \
            write.saveAsTable("client_ssework.temp_trans")
        cls.temp_purchase_lst = [item for item in purchases_lst if item[18] in ["201741", "201742",
                                                                                "201743"]]
        cls.sqlContext.createDataFrame(cls.temp_purchase_lst, purchases_schema). \
            write.saveAsTable("client_ssework.temp_purchase")
        # Create transaction_item_fct table
        cls.sqlContext.sql(setup_sql["drop_transaction_item_fct"])
        cls.sqlContext.sql(setup_sql["create_transaction_item_fct"])
        cls.sqlContext.sql(setup_sql["ins_transaction_item_fct"])
        # Create purchase_item table
        cls.sqlContext.sql(setup_sql["drop_purchase_fct"])
        cls.sqlContext.sql(setup_sql["create_purchase_fct"])
        cls.sqlContext.sql(setup_sql["ins_purchase_fct"])
        cls.sqlContext.createDataFrame(product_lst, product_schema). \
            write.saveAsTable("shoprite_media_mart.products")
        cls.sqlContext.createDataFrame(customer_lst, customer_schema). \
            write.saveAsTable("shoprite_media_mart.customers")
        cls.sqlContext.createDataFrame(stores_lst, stores_schema). \
            write.saveAsTable("shoprite_media_mart.stores")
        cls.sqlContext.createDataFrame(pac_subgroup_lst, pac_subgroup_schema)\
            .write.saveAsTable("client_ssework.pac_subgroup_table")
        cls.sqlContext.createDataFrame(date_lst, date_schema) \
            .write.saveAsTable("shoprite_media_mart.dates")


    @classmethod
    def tearDownClass(cls):
        # Drop databases and tables
        cls.sqlContext.sql(setup_sql["drop_db_ssewh"])
        cls.sqlContext.sql(setup_sql["drop_db_ssework"])
        cls.sqlContext.sql(setup_sql["drop_db_pob"])

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        """
        Unit test case for __init__()
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsInstance(pur_feat_gen, PurchasingFeatureGenerator)
        self.assertTrue(issubclass(PurchasingFeatureGenerator, PurchasingFeatureGeneratorBase))
        self.assertIsInstance(pur_feat_gen.features_specifications, list)
        self.assertIsInstance(choice(pur_feat_gen.features_specifications), dict)

    def test_purchases(self):
        """
        Unit test case for purchases (property/getter) method
        :return: None
        """
        # Create purchase_item table
        self.sqlContext.sql(setup_sql["drop_purchase_fct"])
        self.sqlContext.sql(setup_sql["create_purchase_fct"])
        self.sqlContext.sql(setup_sql["ins_purchase_fct"])
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsInstance(pur_feat_gen.purchases, Purchases)
        pur_feat_gen.purchases.data.show(n=100, truncate=False)
        self.assertEqual(pur_feat_gen.purchases.data.count(), len(self.temp_purchase_lst))

    def test_transactions(self):
        """
        Unit test case for transactions (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        self.assertIsInstance(pur_feat_gen.transactions, Transactions)
        self.assertEqual(pur_feat_gen.transactions.data.count(), len(trans_lst))

    def test_customers_df(self):
        """
        Unit test case for customers_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ['Customer', 'FulfillmentStore', 'PreferredStore1', 'PreferredStore2', 'PreferredStore3']
        self.assertIsInstance(pur_feat_gen.customers_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.customers_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.customers_df.count(), len(customer_lst))

    def test_products_df(self):
        """
        Unit test case for products_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = test_config["SSEProductHierarchy"]
        self.assertIsInstance(pur_feat_gen.products_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.products_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.products_df.count(), len([item for item in product_lst if not item[3].startswith("-")]))

    def test_dates_df(self):
        """
        Unit test case for dates_df (property/getter) method
        :return: None
        """
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        col_lst = ["date_id", "fis_week_id", "fis_year_id","fis_day_of_week_num"]
        self.assertIsInstance(pur_feat_gen.dates_df, DataFrame)
        self.assertListEqual(sorted(pur_feat_gen.dates_df.columns), sorted(col_lst))
        self.assertEqual(pur_feat_gen.dates_df.count(), len(date_lst))

    @mock.patch("shoprite.cmp_features.purchasing_feature_generator.PurchasingFeatureGenerator.current_date", new_callable=mock.PropertyMock)
    def test_generate_and_write_features(self, mock_current_date,):
        """
        Unit test case for customers_df (property/getter) method
        :param mock_current_date: mocked value for PurchasingFeatureGenerator.current_date
        :return: None
        """
        mock_current_date.return_value = dt.strptime('2018-01-08', '%Y-%m-%d').date()
        pur_feat_gen = PurchasingFeatureGenerator(config=test_config,
                                                  feature_specs=feature_specs,
                                                  cadence_attribute="fis_week_id",
                                                  run_date=self.run_date)
        res = pur_feat_gen.generate_and_write_features(clean_run=False)
        self.assertTrue(res)
        # Check/Test date/fis_week ranges
        self.assertListEqual(sorted(pur_feat_gen.required_fis_weeks),
                             sorted(result_set["required_fis_weeks"]))
        self.assertEqual(pur_feat_gen.cadence_week, result_set["cadence_week_for_fis_week_id"])
        self.assertEqual(pur_feat_gen.since_date, result_set["since_date"])
        # Check/Test conditions against purchase_fct table (purchases entity)
        # Refresh purchases_fct table metadata
        self.sqlContext.catalog.refreshTable(pur_feat_gen.purchases.table_name)
        pur_feat_gen.purchases.get_data()
        self.assertEqual(pur_feat_gen.purchases.data.count(), len(purchases_lst))
        result_df = self.sqlContext.createDataFrame(purchases_lst, purchases_schema)

        pur_feat_gen.purchases.data.show(48, False)
        result_df.show(48, False)
        logger.debug("pur_feat_gen.purchases.data.printSchema() ->>")
        pur_feat_gen.purchases.data.printSchema()
        logger.debug("result_df.printSchema() ->>")
        result_df.printSchema()
        print("pur_feat_gen.purchases.data count ->> {}".format(pur_feat_gen.purchases.data.count()))
        print("result_df count ->> {}".format(result_df.count()))

        self.assertEqual(pur_feat_gen.purchases.data.subtract(result_df).count(), 0)
        self.assertEqual(result_df.subtract(pur_feat_gen.purchases.data).count(), 0)
        purchase_part = sorted(list(set([item[0] for item in pur_feat_gen.purchases.get_partition_info(refresh=True)])))
        self.assertListEqual(purchase_part, sorted(result_set["required_fis_weeks"]))
