import unittest
from pyspark.sql.types import *
from datetime import datetime
from dunnhumby import contexts
from smu_cl.cmp_entities.dates import Dates


class TestDates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists smu_cl_media_mart')
        self.sqlContext.sql('drop table if exists smu_cl_media_mart.dates')
        self.schema = StructType([StructField("date_id", DateType(), True),
                                StructField("date_name", StringType(), True),
                                StructField("date_short_name", StringType(), True),
                                StructField("day_of_week_name", StringType(), True),
                                StructField("fis_week_id", StringType(), True),
                                StructField("fis_day_of_week_num", ShortType(), True)
                             ])

    def test_one_row_returned_if_data_exists_in_all_underlying_tables(self):
        l = [(datetime.strptime('2017-09-18 00:00:00', '%Y-%m-%d %H:%M:%S'),
              'SEPTEMBER 18, 2017', '2017-09-18', 'MONDAY', '201738', 1)]
        self.sqlContext.createDataFrame(l, self.schema).write. \
            saveAsTable('smu_cl_media_mart.dates')
        dates = Dates()
        dates_df = dates.data.collect()
        self.assertEquals(len(dates_df), 1)

    def tearDown(self):
        self.sqlContext.sql('drop table if exists smu_cl_media_mart.dates')
