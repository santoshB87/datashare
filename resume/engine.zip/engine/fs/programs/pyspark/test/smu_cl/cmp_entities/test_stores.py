import unittest
from dunnhumby import contexts
from smu_cl.cmp_entities.stores import Stores
from pyspark.sql.types import *


class TestStores(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sqlContext = contexts.sql_context()
        cls.sqlContext.conf.set("spark.sql.shuffle.partitions", "1")

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.sqlContext.sql('create database if not exists smu_cl_media_mart')
        self.sqlContext.sql('drop table if exists smu_cl_media_mart.stores')

    def tearDown(self):
        self.sqlContext.sql('drop table if exists smu_cl_media_mart.stores')
        self.sqlContext.sql('drop database if exists smu_cl_media_mart')

    def test_one_row_in_store_dim_c_should_return_one_row_from_cmp_entity(self):
        schema = StructType([StructField('store', StringType(), True),
                             StructField('storedescription', StringType(), True),
                             StructField('banner', StringType(), True),
                             StructField('bannerdescription', StringType(), True),
                             StructField('storeformat', StringType(), True),
                             StructField('storeregion', StringType(), True),
                             StructField('storedivision', StringType(), True),
                             StructField("fis_week_id", IntegerType(), True)
                             ])
        sample_data = [('190', 'Angola IN', None, None, None, 'Central', None, 201818)]
        self.sqlContext.createDataFrame(sample_data, schema).write.saveAsTable('smu_cl_media_mart.stores')
        stores = Stores()
        stores_rows_cnt = stores.data.count()
        self.assertEquals(stores_rows_cnt, 1)
