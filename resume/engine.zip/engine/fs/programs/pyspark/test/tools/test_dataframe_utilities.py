from __future__ import absolute_import, print_function
import os
import unittest
import shutil
import tempfile
import datetime
from dunnhumby import contexts
from pyspark import SparkContext, SQLContext, HiveContext, SparkConf
import tools.dataframe_utilities as df_util
from pyspark.sql.types import *


class DataFrameUtilitiesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # create local spark/sql contexts
        if "SPARK_HOME" not in os.environ:
            os.environ['SPARK_HOME'] = '/opt/cloudera/parcels/CDH/lib/spark'
        if "JAVA_HOME" not in os.environ:
            os.environ['JAVA_HOME'] = '/usr/java/jdk1.7.0_67-cloudera'
        conf = SparkConf().setMaster('local').setAppName('test').\
            set('spark.sql.shuffle.partitions', 1)
        cls.spark_context = contexts.sc(spark_conf=conf)
        cls.sqlContext = contexts.sql_context()

        # create a local directory to save test data into (with file:// prefix to stop spark trying
        # to reach HDFS)
        cls.temp_folder = tempfile.mkdtemp(dir=os.path.expanduser('~'))
        cls.temp_folder_spark = 'file://' + cls.temp_folder
        cls.proposition = 'test_df_utilities'
        cls.dttm = '1234'

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.temp_folder)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_most_recent_last_day_of_the_week_when_last_day_of_the_week_is_sunday(self):
        as_at = datetime.date(2017, 2, 2)  # Thursday 2nd Feb 2017
        last_day_of_the_week = 7  # Sunday
        self.assertEqual(
            df_util.get_most_recent_last_day_of_the_week(as_at, last_day_of_the_week),
            datetime.date(2017,1,29)  # Sunday 29th Jan 2017
        )

    def test_get_most_recent_last_day_of_the_week_when_last_day_of_the_week_is_saturday(self):
        """
        Having a last day of the week that is not Sunday is (I suspect) unlikely but we do allow for
        it, should a client think that there weeks end on a day other than Sunday.
        """
        as_at = datetime.date(2017, 2, 2)  # Thursday 2nd Feb 2017
        last_day_of_the_week = 6  # Saturday
        self.assertEqual(
            df_util.get_most_recent_last_day_of_the_week(as_at, last_day_of_the_week),
            datetime.date(2017, 1, 28)  # Saturday 28th Jan 2017
        )

    def test_get_dataframe_of_previous_weeks_returns_dataframe_containing_specified_number_of_rows(self):
        self.assertEqual(
            df_util.get_dataframe_of_previous_weeks(
                sc=self.spark_context,sqlContext=self.sqlContext,tally_of_weeks=10
            ).count(),
            10
        )

    def test_get_dataframe_of_previous_weeks_for_one_week_returns_correct_first_day_of_week(self):
        as_at = datetime.date(2017, 2, 2)  # Thursday 2nd Feb 2017
        last_day_of_the_week = 7  # Sunday
        self.assertEqual(
            df_util.get_dataframe_of_previous_weeks(
                self.spark_context,
                self.sqlContext,
                as_at=as_at,
                tally_of_weeks=1
            ).first()['first_day_of_week'],
            datetime.date(2017, 1, 23)  # Monday 23rd Jan 2017
        )

    def test_get_dataframe_of_previous_weeks_for_one_week_returns_correct_last_day_of_week(self):
        as_at = datetime.date(2017, 2, 2)  # Thursday 2nd Feb 2017
        last_day_of_the_week = 7  # Sunday
        last_day_of_week = df_util.get_dataframe_of_previous_weeks(
                self.spark_context,
                self.sqlContext,
                as_at=as_at,
                tally_of_weeks=1
            ).first()['last_day_of_week']
        self.assertEqual(last_day_of_week,datetime.date(2017, 1, 29))

    def test_get_df_from_parquet(self):
        mock_data = [(1, 1, 'a', 'H5', 1, 12),
                     (1, 2, 'd', 'P7', 4, 9),
                     (1, 3, 'g', 'H5', 3, 14),
                     (2, 1, 'a', 'H5', 8, 23),
                     (2, 2, 'd', 'P7', 2, 22),
                     (2, 3, 'g', 'H5', 5, 12),
                     (2, 4, 'f', 'B6', 2, 11),
                     (3, 1, 'a', 'H5', 1, 2), ]

        schema = ['col1', 'col2', 'col3', 'col4', 'col5', 'col6']
        mock_df = self.sqlContext.createDataFrame(data=mock_data, schema=schema)
        filename = '_'.join([self.proposition, self.dttm])
        mock_df.write.mode('overwrite').parquet(os.path.join(self.temp_folder_spark, filename))

        df = df_util.get_df_from_parquet(
            hive_context=self.sqlContext,
            file_name=os.path.join(self.temp_folder_spark, filename))
        self.assertEqual(sorted(df.collect()), sorted(mock_df.collect()))

    def test_get_df_from_hive(self):
        # cant test in local mode as there is no hive service to poke
        pass

    def test_create_product_consumption_type(self):
        #  create mock score data
        mock_data = [(1, 'N5', True),
                     (2, 'B3', False),
                     (3, 'A6', False),
                     (4, 'C8', False),
                     (5, 'N5', True),
                     (6, 'N5', True),
                     (7, 'B3', False),
                     (8, 'N5', True),
                     (9, 'N5', True),
                     (10, 'N5', True)
                     ]

        schema = ['col1', 'col2', 'expected_boolean']
        mock_df = self.sqlContext.createDataFrame(data=mock_data, schema=schema)

        df = df_util.create_feature_using_instr(
            input_df=mock_df,
            new_feature_column='boolean_feature',
            substring_column='col2',
            substr='N5')

        # check row count remains the same
        count_actual = df.count()
        count_expected = mock_df.count()
        self.assertEqual(count_actual, count_expected)

        # check one extra column added
        count_column_actual = len(df.columns)
        count_column_expected = len(mock_df.columns) + 1
        self.assertEqual(count_column_actual, count_column_expected)

        # check requested column name added to df
        self.assertTrue('boolean_feature' in df.columns)

        # compare derived product type with expected hard coded in mock data
        count_error = df.where(df["boolean_feature"] != df["expected_boolean"]).count()
        # commented out the following line as its got a .show() in it which doesn't seem quite right
        #  to me
        # self.assertEqual(count_error, 0,
        #                  df.where(df["boolean_feature"] != df["expected_boolean"]).show())

    def test_check_columns(self):
        mock_data = [(1, 1, 'apple', 'H5', 1, 12),
                     (1, 2, 'gin', 'P7', 4, 9),
                     (1, 3, 'banana', 'H5', 3, 14),
                     (2, 1, 'apple', 'H5', 8, 23),
                     (2, 2, 'gin', 'P7', 2, 22),
                     (2, 3, 'banana', 'H5', 5, 12),
                     (2, 4, 'pasta', 'B6', 2, 11),
                     (3, 1, 'apple', 'H5', 1, 2), ]

        schema = ['col1', 'col2', 'col3', 'col4', 'col5', 'col6']
        mock_df = self.sqlContext.createDataFrame(data=mock_data, schema=schema)

        # check RuntimeError is raised if feature column not on input df
        self.assertRaises(
            RuntimeError,
            df_util.check_columns,
            df=mock_df,
            column_list=['col1', 'col9']
        )

        # check if no errors are raised when all the columns are in the input datatframe
        df = df_util.check_columns(
            df=mock_df,
            column_list=['col1', 'col2', 'col5']
        )

        self.assertEqual(df, None)

    def test_drop_all(self):
        mock_data = [(1, 1, 'apple', 'H5', 1, 12),
                     (1, 2, 'gin', 'P7', 4, 9),
                     (1, 3, 'banana', 'H5', 3, 14),
                     (2, 1, 'apple', 'H5', 8, 23),
                     (3, 1, 'apple', 'H5', 1, 2), ]

        schema = ['col1', 'col2', 'col3', 'col4', 'col5', 'col6']
        mock_df = self.sqlContext.createDataFrame(data=mock_data, schema=schema)
        drop_col_list = ['col1', 'col2', 'col3']

        df = df_util.drop_all(mock_df,
                              *drop_col_list)

        # check row count remains the same
        count_actual = df.count()
        count_expected = mock_df.count()
        self.assertEqual(count_actual, count_expected)

        # check 3 columns have been removed
        count_column_actual = len(df.columns)
        count_column_expected = len(mock_df.columns) - 3
        self.assertEqual(count_column_actual, count_column_expected)

        # check 3 column removed from df
        for col_name in drop_col_list:
            self.assertFalse(col_name in df.columns)

    def test_check_is_dataframe_raises_error_when_not_dataframe_is_passed(self):
        self.assertRaises(
            TypeError,
            lambda: df_util.check_is_dataframe('some value that is not a dataframe')
        )

    def test_check_is_dataframe_does_not_raise_error_when_dataframe_is_passed(self):
        df = self.sqlContext.createDataFrame([('Alice', 1)], ['name', 'age'])
        df.withColumn('age2', df.age + 2).collect()
        self.assertEqual(None, df_util.check_is_dataframe(df))

    def test_check_df_for_duplicates_raises_error_when_not_list_is_passed(self):
        df = self.sqlContext.createDataFrame([('Alice', 1)], ['name', 'age'])
        self.assertRaises(
            TypeError,
            lambda: df_util.check_df_for_duplicates(df, {})
        )

    def test_check_df_for_duplicates_raises_error_when_single_column_has_a_duplicate(self):
        df = self.sqlContext.createDataFrame([('Alice', 1), ('Alice', 2)], ['name', 'age'])
        self.assertRaises(
            RuntimeError,
            lambda: df_util.check_df_for_duplicates(df, ['name'])
        )

    def test_check_df_for_duplicates_raises_error_when_combination_of_two_columns_has_a_duplicate(self):
        df = self.sqlContext.createDataFrame([('Alice', 1, 'Leeds'), ('Alice', 2, 'Leeds')],
                                             ['name', 'age', 'city'])
        self.assertRaises(
            RuntimeError,
            lambda: df_util.check_df_for_duplicates(df, ['name','city'])
        )

    def test_check_df_for_duplicates_does_not_raise_error_when_df_has_no_duplicates(self):
        df = self.sqlContext.createDataFrame([('Alice', 1, 'Leeds'),('Alice', 2, 'Leeds')],
                                             ['name', 'age', 'city'])
        self.assertEqual(
            None,
            df_util.check_df_for_duplicates(df, ['name','city','age'])
        )

    def test_check_df_for_duplicates_raises_error_when_column_does_not_exist_in_df(self):
        df = self.sqlContext.createDataFrame([('Alice', 1, 'Leeds'),('Alice', 2, 'Leeds')],
                                             ['name', 'age', 'city'])
        self.assertRaises(
            RuntimeError,
            lambda: df_util.check_df_for_duplicates(df, ['non_existent_column'])
        )

    def test_get_df_field_names(self):
        df = self.sqlContext.createDataFrame([('Alice', 1, 'Leeds'), ('Alice', 2, 'Leeds')],
                                             ['name', 'age', 'city'])
        fieldNames = df_util.get_df_field_names(df)
        self.assertEqual(len(fieldNames), 3)
        self.assertTrue('name' in fieldNames)
        self.assertTrue('age' in fieldNames)
        self.assertTrue('city' in fieldNames)

    def test_get_sql_column_definition_from_dataframe_field_string(self):
        schema = StructType([StructField("foo", StringType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo STRING')

    def test_get_sql_column_definition_from_dataframe_field_boolean(self):
        schema = StructType([StructField("foo", BooleanType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo BOOLEAN')

    def test_get_sql_column_definition_from_dataframe_field_date(self):
        schema = StructType([StructField("foo", DateType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo DATE')

    def test_get_sql_column_definition_from_dataframe_field_timestamp(self):
        schema = StructType([StructField("foo", TimestampType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo TIMESTAMP')

    def test_get_sql_column_definition_from_dataframe_field_decimal(self):
        schema = StructType([StructField("foo", DecimalType(18,2), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo DECIMAL(18,2)')

    def test_get_sql_column_definition_from_dataframe_field_double(self):
        schema = StructType([StructField("foo", DoubleType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo DOUBLE')

    def test_get_sql_column_definition_from_dataframe_field_float(self):
        schema = StructType([StructField("foo", FloatType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo FLOAT')

    def test_get_sql_column_definition_from_dataframe_field_integer(self):
        schema = StructType([StructField("foo", IntegerType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo INT')

    def test_get_sql_column_definition_from_dataframe_field_long(self):
        schema = StructType([StructField("foo", LongType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo BIGINT')

    def test_get_sql_column_definition_from_dataframe_field_short(self):
        schema = StructType([StructField("foo", ShortType(), True)])
        df = self.sqlContext.createDataFrame([], schema)
        self.assertEqual(df_util.get_sql_column_definition_from_dataframe_field(
            df.schema.fields[0]), 'foo SMALLINT')

    def test_check_week_id_conforms_to_iso8601(self):
        schema = StructType([StructField("fis_week_id", StringType(), True)])
        df = self.sqlContext.createDataFrame([('2017W12',)], schema)
        self.assertTrue(df_util.check_week_id_conforms_to_iso8601(df, 'fis_week_id'))

    def test_check_week_id_conforms_to_iso8601_throws_error_when_invalid_fis_week_id_is_passed(self):
        schema = StructType([StructField("fis_week_id", StringType(), True)])
        df = self.sqlContext.createDataFrame([('2017w12',)], schema)
        self.assertRaises(
            RuntimeError,
            lambda: df_util.check_week_id_conforms_to_iso8601(df, 'fis_week_id')
        )
