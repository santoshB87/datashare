import logging

# set up basic logger with stream handler
logger = logging.getLogger(__name__)
sh = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', '%y/%m/%d %H:%M:%S')
sh.setLevel(logging.DEBUG)
sh.setFormatter(fmt)
logger.setLevel(logging.INFO)
logger.addHandler(sh)