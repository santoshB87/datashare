import logging
from client import *

# set up basic logger with stream handler
logger = logging.getLogger(__name__)

