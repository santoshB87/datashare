from tools.config.market import get_market_from_config

def get_client_from_config(config):
    """
    In late 2016 there was a directive within dunnhumby to refer to clients rather than markets given that
    we now are seeking to have multiple clients per market rather than a single JV per market.
    Up until that time SSE had always referred to markets, in order that we now refer to clients but still maintain
     backward compatibility this function exists that effectively aliases market as client
    :param config:
    :return: client identifier
    """
    client = get_market_from_config(config)
    check_client_is_valid(client)
    return client

def get_clients():
    """This is a master list of clients that can be validated against. No work should ever be done for a client
    that is not in this list
    Nothing to say this list should not increase over time of course"""
    return [
        {"client":"thu",    "client_name":"TI Hungary"          },
        {"client":"tuk",    "client_name":"Tesco UK"            },
        {"client":"tkr",    "client_name":"Korea Homeplus"      },  #used to be owned by tesco hence the tkr
        {"client":"met",    "client_name":"Metro Canada"        },
        {"client":"mon",    "client_name":"Monoprix"            },
        {"client":"casbr",  "client_name":"Casino Brazil"       },
        {"client":"casco",  "client_name":"Casino Columbia"     },
        {"client":"cno",    "client_name":"COOP Norway"         },
        {"client":"rdg",    "client_name":"Drogasil"            },
        {"client":"sza",    "client_name":"Shoprite"            },
        {"client":"tie",    "client_name":"Tesco Ireland"       },
        {"client":"tcn",    "client_name":"TI China"            },
        {"client":"tcz",    "client_name":"TI Czech"            },
        {"client":"tmp",    "client_name":"TI Malaysia"         },
        {"client":"tpl",    "client_name":"TI Poland"           },
        {"client":"tsk",    "client_name":"TI Slovakia"         },
        {"client":"tth",    "client_name":"TI Thailand"         },
        {"client":"ttu",    "client_name":"TI Turkey"           }
    ]

def check_client_is_valid(client):
    if not (client in [client_dict['client'] for client_dict in get_clients()]):
        raise RuntimeError('{client} is not a valid client'.format(client=client))
