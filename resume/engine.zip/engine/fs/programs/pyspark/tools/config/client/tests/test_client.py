from __future__ import absolute_import, print_function
import unittest
from tools.config.client import *


class ClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_invalid_client_throws_an_error(self):
        #The commented out code raised an error,
        #    TypeError: failUnlessRaises() takes at least 3 arguments (2 given)
        #which I did not understand, so I'm using the lambda method instead
        #with self.assertRaises(RuntimeError):
        #    check_client_is_valid('doesnotexist')
        self.assertRaises(
            RuntimeError,
            lambda: check_client_is_valid('doesnotexist')
        )

