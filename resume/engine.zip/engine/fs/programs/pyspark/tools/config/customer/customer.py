def get_customer_identifying_attribute_from_config(config):
    return_value = config['CustomerIdentifyingAttribute']
    return return_value