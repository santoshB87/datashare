def get_environment_from_config(config):
    environment = config['EnvironmentIdentifier']
    check_environment_is_valid(environment)
    return environment

def get_environments():
    """This is a master list of environments that can be validated against. No work should ever be done for a environment
    that is not in this list.
    Nothing to say this list should not increase over time of course"""
    return ['dev','test','prod']

def check_environment_is_valid(environment):
    if not (environment in [environment for environment in get_environments()]):
        raise RuntimeError('{environment} is not a valid environment'.format(environment=environment))
