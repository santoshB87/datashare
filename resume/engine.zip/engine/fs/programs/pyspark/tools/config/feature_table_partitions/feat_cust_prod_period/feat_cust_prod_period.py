import types


def get_list_of_feat_cust_prod_period_partition_specifications_from_config(config):
    return_value = config['FeatureTablePartitions']['feat_cust_prod_period']
    if not isinstance(return_value, types.ListType):
        raise TypeError('{0} should be a list'.format(return_value))
    return return_value
