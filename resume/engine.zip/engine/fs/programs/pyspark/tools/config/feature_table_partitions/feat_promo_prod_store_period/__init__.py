import logging
from feat_promo_prod_store_period import *

# set up basic logger with stream handler
logger = logging.getLogger(__name__)

