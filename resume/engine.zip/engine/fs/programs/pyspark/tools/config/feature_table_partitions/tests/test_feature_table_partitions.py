from __future__ import absolute_import, print_function
import unittest
import tools.config.feature_table_partitions as funcs
import json
import types

class ConfigFeatureTablePartitionsTests(unittest.TestCase):
    config_str = '''
{"FeatureTablePartitions":  {
                                   "feat_cust_period":  [
                                                            {
                                                                "cust_code_type":  "hshd_code",
                                                                "period_code_type":  "fis_week_id",
                                                                "PrTransTable":  "trans"
                                                            },
                                                            {
                                                                "cust_code_type":  "hshd_code",
                                                                "period_code_type":  "date_short_name"
                                                            }
                                                        ],
                                   "feat_prod_period":  [
                                                            {
                                                                "cust_code_type":  "hshd_code",
                                                                "period_code_type":  "fis_week_id",
                                                                "PrTransTable":  "trans",
                                                                "prod_code_type":  "prod_group_code"
                                                            },
                                                            {
                                                                "cust_code_type":  "hshd_code",
                                                                "period_code_type":  "fis_week_id",
                                                                "PrTransTable":  "trans",
                                                                "prod_code_type":  "prod_merch_l10_code"
                                                            },
                                                            {
                                                                "cust_code_type":  "hshd_code",
                                                                "period_code_type":  "date_short_name",
                                                                "prod_code_type":  "prod_group_code"
                                                            }
                                                        ],
                                   "feat_promo_prod_store_period":  [
                                                                        {
                                                                            "promo_code_type":  "promo_group_code",
                                                                            "period_code_type":  "fis_week_id",
                                                                            "store_code_type":  "store_code",
                                                                            "prod_code_type":  "prod_group_code"
                                                                        }
                                                                    ],
                                   "feat_cust_prod_period":  [
                                                                 {
                                                                     "cust_code_type":  "hshd_code",
                                                                     "period_code_type":  "fis_week_id",
                                                                     "PrTransTable":  "trans",
                                                                     "prod_code_type":  "prod_group_code"
                                                                 },
                                                                 {
                                                                     "cust_code_type":  "hshd_code",
                                                                     "period_code_type":  "fis_week_id",
                                                                     "PrTransTable":  "trans",
                                                                     "prod_code_type":  "prod_merch_l10_code"
                                                                 },
                                                                 {
                                                                     "cust_code_type":  "hshd_code",
                                                                     "period_code_type":  "fis_week_id",
                                                                     "PrTransTable":  "trans",
                                                                     "prod_code_type":  "prod_merch_l21_code"
                                                                 },
                                                                 {
                                                                     "cust_code_type":  "hshd_code",
                                                                     "period_code_type":  "date_short_name",
                                                                     "prod_code_type":  "prod_group_code"
                                                                 }
                                                             ]
                               }
}
'''
    config = json.loads(config_str)

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_list_of_feat_promo_prod_store_period_partition_specifications(self):
        return_value = funcs.get_list_of_feat_promo_prod_store_period_partition_specifications_from_config(self.config)
        self.assertEqual(type(return_value),types.ListType)

    def test_get_list_of_feat_cust_prod_period_partition_specifications(self):
        return_value = funcs.get_list_of_feat_cust_prod_period_partition_specifications_from_config(self.config)
        self.assertEqual(type(return_value),types.ListType)

    def test_get_list_of_feat_prod_period_partition_specifications(self):
        return_value = funcs.get_list_of_feat_prod_period_partition_specifications_from_config(self.config)
        self.assertEqual(type(return_value),types.ListType)

    def test_get_list_of_feat_cust_period_partition_specifications(self):
        return_value = funcs.get_list_of_feat_cust_period_partition_specifications_from_config(self.config)
        self.assertEqual(type(return_value),types.ListType)

    def test_get_list_of_feat_cust_period_partition_specifications_when_config_does_not_contain_a_list_of_partitions_specifications(self):
        config = json.loads('{"FeatureTablePartitions":{"feat_cust_period":"someValueThatIsNotAList"}}')
        self.assertRaises(TypeError, funcs.get_list_of_feat_cust_period_partition_specifications_from_config, config)

    def test_get_list_of_feat_prod_period_partition_specifications_when_config_does_not_contain_a_list_of_partitions_specifications(self):
        config = json.loads('{"FeatureTablePartitions":{"feat_prod_period":"someValueThatIsNotAList"}}')
        self.assertRaises(TypeError, funcs.get_list_of_feat_prod_period_partition_specifications_from_config, config)

    def test_get_list_of_feat_cust_prod_period_partition_specifications_when_config_does_not_contain_a_list_of_partitions_specifications(self):
        config = json.loads('{"FeatureTablePartitions":{"feat_cust_prod_period":"someValueThatIsNotAList"}}')
        self.assertRaises(TypeError, funcs.get_list_of_feat_cust_prod_period_partition_specifications_from_config, config)

    def test_get_list_of_feat_promo_prod_store_period_partition_specifications_when_config_does_not_contain_a_list_of_partitions_specifications(self):
        config = json.loads('{"FeatureTablePartitions":{"feat_promo_prod_store_period":"someValueThatIsNotAList"}}')
        self.assertRaises(TypeError, funcs.get_list_of_feat_promo_prod_store_period_partition_specifications_from_config, config)
