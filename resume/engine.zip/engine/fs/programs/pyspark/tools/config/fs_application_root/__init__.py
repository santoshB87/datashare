import logging
from fs_application_root import *

# set up basic logger with stream handler
logger = logging.getLogger(__name__)

