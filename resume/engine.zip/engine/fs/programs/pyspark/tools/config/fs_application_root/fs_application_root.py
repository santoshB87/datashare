def get_fs_application_root_from_config(config):
    fs_application_root = config['FSApplicationRoot']
    return fs_application_root

