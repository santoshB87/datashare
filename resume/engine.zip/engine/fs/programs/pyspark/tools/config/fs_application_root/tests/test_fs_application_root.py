from __future__ import absolute_import, print_function
import unittest
from tools.config.fs_application_root import *


class ClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_fs_application_root_returns_correct_value_when_passed_valid_config(self):
        config = {"FSApplicationRoot": "/some/real/path"}
        self.assertEquals(get_fs_application_root_from_config(config), "/some/real/path")

