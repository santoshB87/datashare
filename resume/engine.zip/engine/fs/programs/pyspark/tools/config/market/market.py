def get_market_from_config(config):
    return_value = config['Market']
    if not return_value.islower():
        raise ValueError(
            "Market must be all lower case. {return_value} invalidates this rule".format(return_value=return_value))
    return return_value
