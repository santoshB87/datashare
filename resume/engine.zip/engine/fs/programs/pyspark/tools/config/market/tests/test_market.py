import unittest
from tools.config.market import get_market_from_config

class MarketTest(unittest.TestCase):

    def setUp(self):
        """Call before every test case"""

    def tearDown(self):
        """Call after every test case"""

    def test_get_market_returns_correct_value(self):
        config = {"Market": "tuk"}
        market = get_market_from_config(config)
        assert market == "tuk"

    def test_market_must_be_defined_in_lower_case(self):
        config = {"Market": "Tuk"}
        with self.assertRaises(ValueError):
            get_market_from_config(config)


