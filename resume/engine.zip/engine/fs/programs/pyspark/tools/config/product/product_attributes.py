
def get_product_product_attribute_from_config(config):
    return_value = config['ProductProductAttribute']
    return return_value


def get_product_subgroup_attribute_from_config(config):
    return_value = config['ProductSubgroupAttribute']
    return return_value


def get_product_group_attribute_from_config(config):
    return_value = config['ProductGroupAttribute']
    return return_value


def get_product_division_attribute_from_config(config):
    return_value = config['ProductDivisionAttribute']
    return return_value


def get_product_identifying_attribute_from_config(config):
    return_value = config['ProductIdentifyingAttribute']
    return return_value


def get_product_attribute_mappings_from_config(config):
    return_value = config['ProductAttributeMappings']
    return return_value
