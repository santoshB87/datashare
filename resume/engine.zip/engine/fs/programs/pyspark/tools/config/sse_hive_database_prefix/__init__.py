import logging
from sse_hive_database_prefix import *

# set up basic logger with stream handler
logger = logging.getLogger(__name__)

