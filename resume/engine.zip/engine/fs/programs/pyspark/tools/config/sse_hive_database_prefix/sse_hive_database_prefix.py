

def get_sse_hive_database_prefix_from_config(config):
    return_value = config['SSEHiveDatabasePrefix']
    return return_value
