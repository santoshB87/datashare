from __future__ import absolute_import, print_function
import unittest
import tools.config.sse_hive_database_prefix as funcs
import json

class ConfigSseHiveDatabaseprefixTests(unittest.TestCase):
    config_str = {"SSEHiveDatabasePrefix":  "someprefix"}

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_sse_hive_database_prefix(self):
        return_value = funcs.get_sse_hive_database_prefix_from_config(self.config_str)
        self.assertEqual(return_value,'someprefix')