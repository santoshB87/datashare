import logging
from store import *

# set up basic logger with stream handler
logger = logging.getLogger(__name__)

