def get_store_from_config(config):
    store = config['StoreIdentifyingAttribute']
    return store

