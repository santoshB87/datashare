import json
import logging
import pprint as pp


class Config(object):

    def __init__(self, logger=None):
        super(Config, self).__init__()
        self.store = dict()
        self.mandatory_exceptions = False
        self.failed_keys = list()
        self.logger = logger
        self.file_name = None

    def add_source_file(self, path):
        if self.file_name:
            raise RuntimeError('Config object already loaded from file: "{0}"'.format(self.file_name))
        try:
            self.store.update(json.load(open(path, 'r')))
            self.file_name = path
        except (OSError, IOError) as err:
            raise RuntimeError('Unable to open file {0} for read: {1}'.format(path, err))
        except ValueError as err:
            raise RuntimeError('Failed to parse file {0} as JSON: {1} '.format(path, err))
        else:
            self._log('Config loaded from file: "{0}"'.format(path))
        return self

    def add_dict(self, d):
        if not isinstance(d, dict):
            raise RuntimeError('add_dict expects a dict object, got {0}'.format(type(d)))
        self.store.update(d)
        return self

    def add_keys(self, **kwargs):
        self.store.update(**kwargs)

    def get_item(self, keys, mandatory=False, default=None):
        # if keys is passed in as a string convert it to a single element tuple to stop iteration over each character
        if type(keys) in (str, unicode):
            keys = (keys,)
        try:
            value = self._get_nested_item(keys)
            pretty_value = pp.pformat(value)
            trunc_value = (pretty_value[:75] + '..') if len(pretty_value) > 77 else pretty_value
            self._log('Config: "{0}" = {1}'.format(self._join_keys(keys), trunc_value), level=logging.INFO)
        except (KeyError, TypeError):
            if mandatory:
                self.mandatory_exceptions = True
                self._log('Config: "{0}" not found (mandatory value)'.format(self._join_keys(keys)), level=logging.ERROR)
                value = None
                self.failed_keys.append(self._join_keys(keys))
            else:
                self._log('Config: "{0}" = {1} (default value)'.format(self._join_keys(keys), default), level=logging.WARNING)
                value = default
        return value

    def error_on_mandatory_exceptions(self):
        if self.mandatory_exceptions:
            raise RuntimeError('One or more mandatory keys not found in properties: {0}'.format(self.failed_keys))

    def _get_nested_item(self, keys):
        d = self.store
        for key in keys:
            d = d[key]
        return d

    @staticmethod
    def _join_keys(keys):
        return '.'.join(str(key) for key in keys)

    def _log(self, message, level=logging.INFO):
        if self.logger:
            self.logger.log(level, message)
