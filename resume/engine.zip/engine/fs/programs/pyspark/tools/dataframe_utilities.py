"""
Data frame utilities module.
"""
from __future__ import absolute_import, print_function
import pyspark.sql.functions as func
from pyspark.sql import DataFrame
from pyspark.sql.dataframe import DataFrame as DF
from pyspark.sql.utils import AnalysisException
from py4j.java_gateway import Py4JError
from pyspark.sql.types import *
from pyspark.sql.types import StructField as SF
import pyspark.sql.types as sqltypes
import logging
import datetime

logger = logging.getLogger(__name__)


def get_most_recent_last_day_of_the_week(as_at=datetime.date.today(), last_day_of_the_week=7):
    """
    Given:
      a date (let's assume today)
      a specification of which day of the week is considered to be the last day of the week
    return the most recent last day of the week.
    For example, if today is Thursday, 2nd February 2017 and last day of the week is day 7 (i.e. Sunday)
      then this function will return datetime.date(2017,1,29) which is the most recent Sunday
    :param as_at: a date for which to return the most recent last day of the week
    :param last_day_of_the_week: the day of the week considered to be the last day of the week. 1 means Monday, 2 means Tuesday etc
    :return: datetime.date
    """
    if last_day_of_the_week not in range(1, 8):
        raise RuntimeError(
            "{last_day_of_the_week} is not a day of the week".format(last_day_of_the_week=last_day_of_the_week))
    ordinal_day_of_the_week = (as_at.weekday() + 1) % 7
    return as_at - datetime.timedelta(days=7 - last_day_of_the_week + ordinal_day_of_the_week)


def get_dataframe_of_previous_weeks(sc, sqlContext, as_at=datetime.date.today(), last_day_of_the_week=7,
                                    tally_of_weeks=211):
    """
    Given:
      a date (let's assume today)
      a specification of which day of the week is considered to be the last day of the week
      number of weeks
    return a dataframe of the last {number of weeks} weeks, with the start date and end date of that week
    :param sc: Spark context
    :sqlContext Spark sql context
    :param as_at: a date for which to return the most recent last day of the week
    :param last_day_of_the_week: the day of the week considered to be the last day of the week. 1 means Monday, 2 means Tuesday etc
    :param tally_of_weeks: Tally of weeks to return i.e. Number of rows in the returned dataframe
    :return: datetime.date
    """
    weeks = []
    most_recent_last_day_of_the_week = get_most_recent_last_day_of_the_week(as_at=as_at,
                                                                            last_day_of_the_week=last_day_of_the_week)
    for week_number in range(1, tally_of_weeks + 1):
        last_day_of_week_number = most_recent_last_day_of_the_week - datetime.timedelta(weeks=week_number - 1)
        first_day_of_week_number = last_day_of_week_number - datetime.timedelta(days=6)
        weeks.append((week_number, first_day_of_week_number, last_day_of_week_number))
    schema = StructType(
        [
            StructField("week_number", IntegerType(), True),
            StructField("first_day_of_week", DateType(), True),
            StructField("last_day_of_week", DateType(), True)
        ]
    )
    return sqlContext.createDataFrame(weeks, schema)


def get_df_from_parquet(hive_context, file_name):
    """Get a data frame from a HDFS file location."""
    try:
        return hive_context.read.parquet(file_name)
    except Py4JError as err:
        raise RuntimeError(err.java_exception)


def get_df_from_hive(hive_context, table_name):
    """Get a data frame from hive by name."""
    return hive_context.table(table_name)


def check_columns(df, column_list):
    """
    Check all columns in column list exist in input dataframe.

    The function will pass silently if all columns are present.

    Args:
        df (pyspark.DataFrame): Data frame to check columns exist.
        column_list (list of str): Names of columns that should exist
            on table.

    Raises:
        RuntimeError: In the event that columns are missing.
    """
    if isinstance(column_list, basestring):
        column_list = [column_list]

    missing_cols = list(set(column_list) - set(df.columns))

    if missing_cols:
        raise RuntimeError('The following columns were not found in the input dataframe: {0}. The input dataframe contains columns {1}'
                           .format(', '.join(missing_cols), ','.join([field.name for field in df.schema.fields])))


def create_feature_using_instr(input_df,
                               new_feature_column,
                               substring_column,
                               substr):
    """Create a new boolean column/feature in a DataFrame :
            Values : True if the substr column begins with the given string 'substr' ; False otherwise
            Args:
                input_df: dataframe
                new_feature_column: the name of the new boolean column
                substring_column: the substr column name to be checked
                substr: the given string.
    """

    logger.info("Create {0} feature".format(new_feature_column))
    check_columns(df=input_df, column_list=[substring_column])
    input_df.withColumn(new_feature_column, func
                        .when(
        func.instr(func.col(substring_column), substr).alias(substring_column) == 1, True)
                        .otherwise(False))

    return input_df.withColumn(new_feature_column, func
                               .when(
        func.instr(func.col(substring_column), substr).alias(substring_column) == 1, True)
                               .otherwise(False))


def sql_drop_table(target_table,
                   sqlContext):
    drop_sql = "DROP TABLE IF EXISTS {0}".format(target_table)
    logger.info('Issuing SQL: %s', drop_sql)
    sqlContext.sql(drop_sql)


def sql_query(sqlContext, query):
    """Issue an SQL query to the sqlContext."""
    logger.info("Issuing SQL: %s", query)
    return sqlContext.sql(query)


def sql_insert_into(sqlContext,
                    target_table,
                    partition_column,
                    select_columns,
                    source_table):
    print(target_table)

    print(partition_column)
    print(select_columns, source_table)
    insert_sql = "INSERT INTO TABLE {0} PARTITION ({1}) SELECT {2}  FROM {3}".format(target_table, partition_column,
                                                                                     select_columns, source_table)
    print(insert_sql)
    logger.info('Issuing SQL: {0}'.format(insert_sql))
    sqlContext.sql(insert_sql)


def drop_all(df, *cols):
    """
        Args:
            dfs:  requires list of data frames to be joined
        Return
            One data frame of multiple data frames content
    """
    return reduce(DataFrame.drop, cols, df)


def get_df_from_csv(hive_context, file_name):
    try:
        return hive_context.read \
            .format("com.databricks.spark.csv") \
            .option("header", "true") \
            .option("nullValue", "true") \
            .load(file_name)
    except Py4JError as err:
        raise RuntimeError(err.java_exception)


def is_dataframe(df):
    """Return bool indicating whether ``df`` is a dataframe."""
    return isinstance(df, DF)


def check_is_dataframe(df):
    """
    Ensure an object is a data frame.

    Args:
        df (obj): An object to check.

    Raises:
        TypeError: In the event the object is not a data frame.
    """
    if not is_dataframe(df):
        raise TypeError('Object is not a pyspark.sql.dataframe.DataFrame')

def get_tally_of_duplicates(df, column_list):
    """
    Check a data frame for duplicates.

    Args:
        df (pyspark.DataFrame): Data frame to check for duplicates.
        column_list (list of str): A list of columns to check for duplicates.

    This function was introduced after check_df_for_duplicates(). check_df_for_duplicates() would
    throw an error whereas it was realised that what was really required was a function that merely informed
    whether uniqueness was enforced or not and then the caller could choose the correct course of action.
    check_df_for_duplicates() has been modified to use get_tally_of_duplicates() accordingly"""
    # Assert that the input df is a dataframe
    if not is_dataframe(df):
        raise TypeError('Expected a data frame.  Instead got "%s".' % type(df))

    # Allow convert column list to list if a string is passed.
    if isinstance(column_list, basestring):
        column_list = [column_list]

    if not isinstance(column_list, list):
        raise TypeError('Expected list or string for column_list.  Instead got "%s".' % type(column_list))

    # Assert that columns are present on data
    check_columns(df, column_list)

    tally_of_duplicates = df.groupBy(column_list).count().alias(
        'tally').filter(func.col('count') > 1).count()
    return tally_of_duplicates


def check_df_for_duplicates(df, column_list):
    """
    Check a data frame for duplicates.

    Args:
        df (pyspark.DataFrame): Data frame to check for duplicates.
        column_list (list of str): A list of columns to check for duplicates.
    """
    tally_of_duplicates = get_tally_of_duplicates(df, column_list)
    if tally_of_duplicates > 0:
        raise RuntimeError('There are {tally_of_duplicates} duplicated identifiers across columns {column_list}'
                           .format(tally_of_duplicates=tally_of_duplicates,
                                   column_list=column_list
                                   )
                           )


def get_df_field_names(df):
    """Get the schema fields for a data frame."""
    check_is_dataframe(df)
    return [field.name for field in df.schema.fields]


def get_sql_column_definition_from_dataframe_field(field):
    """
    Often one might need to create a hive table based on the schema of a dataframe. In such a situation the hive table
    will require columns types suitable to store the values in the dataframe thus there needs to be a mapping
    between the datatype of a Spark field to what the SQL would need to be in order to create a column to store the
    values in that column.
    Basically this function maps a spark field datatype to a hive column datatype
    :param field:
    :return:
    """
    if not isinstance(field, SF):
        raise TypeError('parameter field must be of type pyspark.sql.types.StructField')
    if isinstance(field.dataType, sqltypes.StringType):
        return '{name} STRING'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.BooleanType):
        return '{name} BOOLEAN'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.DateType):
        return '{name} DATE'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.FloatType):
        return '{name} FLOAT'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.TimestampType):
        return '{name} TIMESTAMP'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.DecimalType):
        precision, scale = str(field.dataType).replace('DecimalType(', '').replace(')', '').split(',')
        return '{name} DECIMAL({precision},{scale})'.format(name=field.name, precision=precision, scale=scale)
    elif isinstance(field.dataType, sqltypes.DoubleType):
        return '{name} DOUBLE'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.IntegerType):
        return '{name} INT'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.LongType):
        return '{name} BIGINT'.format(name=field.name)
    elif isinstance(field.dataType, sqltypes.ShortType):
        return '{name} SMALLINT'.format(name=field.name)
    else:
        raise NotImplementedError('No mapping specified for type {type}'.format(field.dataType))


def check_week_id_conforms_to_iso8601(df, field_containing_week_id):
    reqd_regexp = '[0-9][0-9][0-9][0-9]W[0-9][0-9]'
    df = df.filter(~(df[field_containing_week_id].rlike(reqd_regexp)))
    invalid_format_week_id_tally = df.count()
    if invalid_format_week_id_tally > 0:
        raise RuntimeError(
            '{invalid_format_week_id_tally} rows do not match required regexp {reqd_regexp} in field {field_containing_week_id}'.format(
                invalid_format_week_id_tally=invalid_format_week_id_tally,
                reqd_regexp=reqd_regexp,
                field_containing_week_id=field_containing_week_id
            ))
    return True

def write_csv_to_hdfs(input_df,
                      hdfs_path,
                      file_format='com.databricks.spark.csv',
                      file_saveMode='overwrite'):
    """

    :param input_df:
    :param hdfs_path:
    :param file_format:
    :param file_saveMode:
    :return:
    """
    return input_df.write.mode(file_saveMode) \
        .format(file_format) \
        .option('nullValue', '') \
        .save(hdfs_path)

def write_csv_to_nfs(input_df,
                     nfs_path,
                     file_format='com.databricks.spark.csv',
                     file_saveMode='overwrite'):
    """

    :param input_df:
    :param nfs_path:
    :param file_format:
    :param file_saveMode:
    :return:
    """

    return input_df.write.mode(file_saveMode) \
        .format(file_format) \
        .option("header", "true") \
        .save(nfs_path)