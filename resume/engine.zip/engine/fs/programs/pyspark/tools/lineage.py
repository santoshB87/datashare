import datetime
from pyspark.sql.types import *
import logging

logger = logging.getLogger(__name__)


def log_insert(config,
               sc,
               sqlContext,
               inserted_object,
               partition_spec=None,
               start_time=None,
               end_time=None,
               insert_tally=None
               ):
    target_location = config['PobHdfsRootPath'] + '/insertLineage'
    year = datetime.datetime.now().year
    month = datetime.datetime.now().month
    day = datetime.datetime.now().day
    data = [(day, partition_spec, start_time, end_time, insert_tally, year, month, inserted_object)]
    append_or_overwrite = 'append'
    schema = StructType([
        StructField('day', IntegerType(), True),
        StructField('partitionSpec', StringType(), True),
        StructField('startTime', TimestampType(), True),
        StructField('endTime', TimestampType(), True),
        StructField('insertTally', LongType(), True),
        StructField('year', IntegerType(), True),
        StructField('month', IntegerType(), True),
        StructField('insertedObject', StringType(), True)
    ])
    df = sqlContext.createDataFrame(data, schema)
    try:
        sqlContext.read.parquet('{target_location}/year={year}/month={month}/insertedObject={insertedObject}'
                                .format(target_location=target_location,
                                        year=str(year),
                                        month=str(month),
                                        insertedObject=inserted_object
                                        )
                                )
    except:
        append_or_overwrite = 'overwrite'
    logger.info(
        ('log_insert\n ' +
         'target_location: {target_location}\n' +
         ' append_or_overwrite: {append_or_overwrite}' +
         '\n df: {df}\n data: {data}').format(
            target_location=target_location,
            append_or_overwrite=append_or_overwrite,
            df=str(df),
            data=str(data)
        )
    )
    df.write.partitionBy('year', 'month', 'insertedObject').parquet(
        target_location.format(target_location=target_location), append_or_overwrite)
