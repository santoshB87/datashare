# ES Data Loader

 - A utility which will create the customers data using the data prepared by Meda-X in parquet file format and then will upload the data to the desired Elasticsearch cluster.

## Branches Pipeline Status and Code Coverage
### Master
[![pipeline status](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/badges/master/pipeline.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/commits/master)

[![coverage report](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/badges/master/coverage.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/commits/master)

### Develop
[![pipeline status](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/badges/develop/pipeline.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/commits/develop)

[![coverage report](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/badges/develop/coverage.svg)](https://dhgitlab.dunnhumby.co.uk/CMP/es-data-loader/commits/develop)

## Repository Introduction

 - This repository is responsible for both customers data creation and also upload to the created data to the ES cluster.
 - It contains the following components:-
    - `ESDataLoadSparkJob.scala` - This is the main class which orchestrates the flow. It reads the command line params creates a Map of it and passes it to the other classes responsible for running data creation and upload. It also contains the initialization code snippet for spark session. The job provides a flexibility on whether to run the create job or upload job or both which can be controlled through the command line arguments.
    - `ESDataCreation.scala` - The data creation occurs here. It takes a Map of persisted data created by Meda-X. The persisted data information which is basically the objectives are specified in the client configuration file. The data for customers with additional attributes are created and written in a parquet format to the file system.
    - `ESDataUpload.scala` - Data is uploaded to the customers index and pacs, products and hierarchy indices are created. Aliases are switched to point to latest customer index and old customers indices are deleted. The elasticsearch data upload using spark is a bulk upload. The upload configuration tuning can be performed by changing the parameters from the client configuration config. The same class is also compatible to run upload on Big Query.
    - `init.sh` - This shell script is to be run once, manually while deploying ES based Audience selection to any client. This script registers basic index settings template. This step can be done as part of ES cluster setup.

## Deployment Steps
 - ### Manual Deployment
      * Tag/Branch to be deployed :-
         * clone the repository - git clone git@dhgitlab.dunnhumby.co.uk:CMP/es-data-loader.git
         * cd es-data-loader/
         * go to the particular tag/branch - git checkout <tag> or git checkout <branch>

      * Steps to run ES-Data-Loader
         * Add the configuration file for the new client. Generally the naming convention for the file is followed as <client_name>_es.conf.
         * Create the dependencies jar using the command `sbt assemblyPackageDependency`
         * Create the code jar using the command `sbt package`
         * Deploy both the jars to the desired location.
         * Following command line arguments are essential to be provided to run the job:-
             * `appLocalPath`=gs://<client_bucket_name>/<location> [Location containing the asket nominations data] [can be both cloud bucket path or hdfs]
             * `cadenceWeek`=202016
             * `cadenceWeekElastic`=202018 // optional
             * `dimensionPathOrDb`=<client_name>_mart [can be both cloud hive table or path]
             * `featuresDbName`=<db name>
             * `job`=both //(can be `create` or `upload` or `both`)
             * `writePath`=gs://<client_bucket_name>/<location> [can be both cloud bucket path or hdfs]
             * `client`=<client_name> [should be same with which the configuration file is created without the `_es` part]
             * `environment`=test [can be `test` or `prod`]
             * `persistentDataDB`=<db name> [Location where Meda-x writes the objectives data]
             * `pacPath`=<db name> // optional
             * `productPath`=gs://<client_bucket_name>/<location> [can be both cloud bucket path or hdfs]
             * `isMultiTenant`=false // optional
             * `sink`=bq // [can be `bq` or `es` depending upon where we want to upload the data]

  - ### Automated Deployment using Airflow
       * Tag/Branch to be deployed :-
          * clone the repository - git clone git@dhgitlab.dunnhumby.co.uk:CMP/Scheduler.git
          * cd Scheduler/
          * go to the particular tag/branch - git checkout <tag> or git checkout <branch>

       * Steps to deploy ES-Data-Loader on Airflow -
          * Traverse to the folder location `airflow/es_loader_tasks/config`.
          * 2 files are present one for deploying on staging environment and the other for production environment.
          * Make the changes in the file by adding a new configuration config for the client.[Refer to the existing config for creating a new one].
          * Upload the whole folder to the client airflow location with the config folder only containing the connfig of the desired deployment. [staging or production]
          * Also upload the file elasticsearch_dataload_dag.py on the location where the former folder was uploaded.
          * Now go to the airflow UI and run the dag for fetching new artifacts.
          * `Voila!!` The elasticsearch dag is deployed.

## Releases

### Develop
 - Contains the latest code base and would be deployed using the above steps mentioned.
 - The schema is according the 2.2.1 deployment.

### v1.1.0
 - Contains the code containing the class to only load the data and not create it. In this version the data was created using the Meda-X repo and only upload functionality is present. All the parameters have to be specified in the client configuration file that is created.
 - Command line arguments :-
   - <client>, <environment>, <cadenceWeek>, <isMultiTenant>
