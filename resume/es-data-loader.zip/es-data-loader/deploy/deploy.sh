json="$(cat ${1})"
for config in $(echo "${json}" | jq -r '.[] | @base64'); do

         _get() {
                echo ${config} | base64 --decode | jq -r ${1}
        }

        _deploy() {
                server=$(_get '.server')
                path=$(_get '.location')
                username=$(_get '.username')
                password=$(_get '.password')
                export SSHPASS="$(echo ${password} | envsubst)"
                sshpass -e scp -q -o stricthostkeychecking=no ${2} ${username}@${server}:${path}
        }

        _deploy ${config} ${2}
done