package com.dunnhumby.esdataloader.conf

/**
  * Created By shriyam on 05/05/2020.
  */

import java.io.File

import com.typesafe.config.{Config, ConfigFactory, ConfigObject, ConfigValue}

import scala.collection.JavaConverters._

class AppConfiguration(configurationFactoryDataLoadConfig: Config, environment: String) {

  val configurationFactoryPersistentDataConfig: Config =
    configurationFactoryDataLoadConfig.getConfig("persistentData")

  val configurationFactoryDataCreationConfig: Config =
    configurationFactoryDataLoadConfig.getConfig("dataCreate")

  val configurationFactoryDataUploadConfig: Config =
    configurationFactoryDataLoadConfig.getConfig("dataUpload")

  private def getConfig(key: String): Config = {
    configurationFactoryDataUploadConfig.getConfig(s"${environment}.${key}")
  }

  private def getString(key: String): String = {
    configurationFactoryDataUploadConfig.getString(s"${environment}.${key}")
  }

  private def getInt(key: String): Int = {
    configurationFactoryDataUploadConfig.getInt(s"${environment}.${key}")
  }

  private def getStringList(key: String): Seq[String] = {
    configurationFactoryDataUploadConfig.getStringList(s"${environment}.${key}").asScala
  }

  private def getBoolean(key: String): Boolean = {
    configurationFactoryDataUploadConfig.getBoolean(s"${environment}.${key}")
  }

  private def getHierarchy: Map[String, (Int,Boolean)] = {
    val list: Iterable[ConfigObject] = this.configurationFactoryDataUploadConfig.getObjectList(s"hierarchies").asScala
    (for {
      item <- list
      hierarchy = item.get("Level").unwrapped().toString
      rank = item.get("Order").unwrapped().toString.toInt
      isSelectable = item.get("IsSelectable").unwrapped().toString.toBoolean
    } yield (hierarchy, (rank,isSelectable))).toMap
  }

  private def getBQOptionMap(key: String): Map[String, String] = {
    val optionMap = configurationFactoryDataUploadConfig.getConfig(s"${environment}.${key}")
      .entrySet().asScala.toList.map{entry =>
      (entry.getKey, entry.getValue.unwrapped().toString)
    }.toMap
    optionMap
  }

  val hiearchies: Map[String, (Int,Boolean)] = getHierarchy
  val esNodes: Seq[String] = getStringList("esNodes")
  val batchSizeInMb: Int = getInt("batchSizeInMb")
  val batchEntries: Int = getInt("batchEntries")
  val port: Int = getInt("esPort")
  val wanMode: Boolean = getBoolean("wanMode")
  val enableProxy: Boolean = getBoolean("enableProxy")
  val proxyHost: String = getString("proxyHost")
  val proxyPort: Int = getInt("proxyPort")
  val dataPath: Config = getConfig("customerData")
  val productsPath: Config = getConfig("productsEntity")
  val storesEntity: Config = getConfig("storesEntity")
  val enableSSL: Boolean = getBoolean("enableSSL")
  val adminUserName: String = getString("adminUserName")
  val authEnabled: Boolean = getBoolean("authEnabled")
  val l10: String = getString("l10")
  val enableIdempotentInserts: Boolean = getBoolean("enableIdempotentInserts")
  val generateEntityIndexes: Boolean = getBoolean("generateEntityIndexes")
  val chunkedIndex: Boolean = getBoolean("chunkedIndex")
  val pacTable: Config = getConfig("pacTable")
  val clusterNumColumn: String = getString("clusterNumColumn")
  val batchRetryCount: Int = getInt("batchRetryCount")
  val batchWriteRetryWait: Int = getInt("batchWriteRetryWait")
  val lowestHierarchyNeeded: Boolean = getBoolean("lowestHierarchyNeeded")
  val switchAliases: Boolean = getBoolean("switchAliases")
  val clientPostFix: String = getString("clientPostfix")

  val bqOptionMap: Map[String, String] = getBQOptionMap("bqOptionMap")

  val temporaryGCSBucket: String = bqOptionMap("temporaryGCSBucket")
  val projectName: String = bqOptionMap("projectName")
  val databaseName: String = bqOptionMap("databaseName")
}

object AppConfiguration {
  def apply(environment: String, clientName: String): AppConfiguration = {

    val defaultConfigurationConfig = ConfigFactory.load()

    val configurationFactoryDataLoadConfig = ConfigFactory
      .parseFile(new File(s"${clientName}_es.conf"))
      .withFallback(defaultConfigurationConfig).resolve()

    new AppConfiguration(configurationFactoryDataLoadConfig, environment)
  }
}
