package com.dunnhumby.esdataloader.executor

import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.esdataloader.conf.AppConfiguration
import com.dunnhumby.esdataloader.utils.Helpers
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SparkSession, functions => F, types => T}
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse

import scala.collection.JavaConverters._
import scala.collection.mutable

/**
  * Created By shriyam on 05/05/2020.
  */

class ESDataCreation(sparkSession: SparkSession, applicationConfiguration: AppConfiguration) {

  private val oldNames = List("quantity_1w52w", "baskets_1w52w", "netspend_1w52w", "quantityperbasket_1w52w",
    "netspendperbasket_1w52w", "quantity_1w26w", "baskets_1w26w", "netspend_1w26w", "quantityperbasket_1w26w",
    "netspendperbasket_1w26w", "quantity_1w13w", "baskets_1w13w", "netspend_1w13w", "quantityperbasket_1w13w",
    "netspendperbasket_1w13w", "quantity_1w8w", "baskets_1w8w", "netspend_1w8w", "quantityperbasket_1w8w",
    "netspendperbasket_1w8w", "quantity_1w4w", "baskets_1w4w", "netspend_1w4w", "quantityperbasket_1w4w",
    "netspendperbasket_1w4w", "quantity_1w1w", "baskets_1w1w", "netspend_1w1w", "quantityperbasket_1w1w",
    "netspendperbasket_1w1w")
  private val newNames = List("q_52", "b_52", "n_52", "qpv_52", "npv_52", "q_26", "b_26", "n_26", "qpv_26", "npv_26", "q_13",
    "b_13", "n_13", "qpv_13", "npv_13", "q_8", "b_8", "n_8", "qpv_8", "npv_8", "q_4", "b_4", "n_4", "qpv_4", "npv_4",
    "q_1", "b_1", "n_1", "qpv_1", "npv_1")
  private val featureCols = newNames.map(F.col)
  
  val helpers: Helpers = Helpers(sparkSession)
  implicit val formats: DefaultFormats.type = DefaultFormats

  def elasticsearchHandler(writePath: String, paramMap: Map[String, Any])
  : Unit = {
      val handlerConfigString = Helpers(sparkSession)
        .convertConfigToJSONString(applicationConfiguration.configurationFactoryDataCreationConfig)
      val parsedConfigMap = parse(handlerConfigString).extract[Map[String, Any]]
      val extraParams = Helpers(sparkSession).mergeMapsLeftBiased(paramMap, parsedConfigMap)
      val persistentDataKeys = applicationConfiguration.configurationFactoryPersistentDataConfig
        .root().keySet().asScala.toList

      val persistentDataMap = persistentDataKeys.map {
        dataKey =>
          val objectiveName = applicationConfiguration.configurationFactoryPersistentDataConfig
            .getString(s"$dataKey.objectiveName")
          val dataConfig = applicationConfiguration.configurationFactoryPersistentDataConfig
            .getConfig(s"$dataKey.readConfig")
          val dataDF = DataFrameReadWriteFormat(dataConfig)
            .readDataFrame(sparkSession.sqlContext)
          (dataKey, (dataDF, objectiveName))
      }.toMap

      val esData = constructEsFormatData(persistentDataMap, extraParams)
      helpers.writeOuput(writePath, esData)
  }

  private def constructEsFormatData(objectivesDfMap: Map[String, (DataFrame, String)],
                                    extraParams: Map[String, Any]): DataFrame = {

    val bannerFlag = extraParams.get("bannerFlag").fold(false) { x =>
      x.asInstanceOf[String] match {
        case "true" | "True" | "TRUE" => true
        case _ => false
      }
    }

    val brandFlag = extraParams.get("brandFlag").fold(false) { x =>
      x.asInstanceOf[String] match {
        case "true" | "True" | "TRUE" => true
        case _ => false
      }
    }

    val customerFiltersAndSuppressions = extraParams.get("customerFiltersAndSuppressions").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val custFiltersAndSuppressionsShortName = extraParams.get("custFiltersAndSuppressionsShortName")
      .fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    if (customerFiltersAndSuppressions.length != custFiltersAndSuppressionsShortName.length) {
      throw new IllegalArgumentException("\n\n ES Column Rename failed!")
    }
    val featureData = constructFeatureData(objectivesDfMap, extraParams)
    val customerDf = constructCustomerLevelData(extraParams)
    val allCustomerAllAllDf = constructFeaturesDataHelper(extraParams, List.empty, "all", "customer", "all", "all")
    val pacDf = constructPacData(extraParams, oldNames, newNames)
    val categoryDf = constructCategoryData(extraParams, objectivesDfMap)
    val appLocalPath = extraParams("appLocalPath").toString

    val elasticFormatDf = featureData.join(customerDf, Seq("customer"), "left_outer")
      .join(helpers.renameMultipleColumns(
        helpers.castSparkDFTypestoES(allCustomerAllAllDf), oldNames, newNames), Seq("customer"), "left_outer")
      .join(pacDf, Seq("customer"), "left_outer")
      .join(categoryDf, Seq("customer"), "left_outer")
      //.join(nonPurchasedProd, Seq("customer"), "left_outer")
      .join(objectivesDfMap("outsideCategoryAcquisitionStd")._1, Seq("customer"), "left_outer")

    val elasticFormatBrandDF = if(brandFlag) {
      val categoryBrandDf = constructCategoryBrandData(extraParams, objectivesDfMap)
      elasticFormatDf.join(categoryBrandDf, Seq("customer"), "left_outer")
    } else {
      elasticFormatDf
    }

    val finalDF = if (bannerFlag) {
      val bannerData = constructCustomerLevelBannerData(extraParams)
      val productBannerData = constructCPLevelBannerData(extraParams, objectivesDfMap)
      val categoryBannerData = constructCategoryLevelBannerData(extraParams, objectivesDfMap)
      val esData = elasticFormatBrandDF.join(bannerData, Seq("customer"), "left_outer")
        .join(productBannerData, Seq("customer"), "left_outer")
        .join(categoryBannerData, Seq("customer"), "left_outer")
      val esDataBannerBrandData = if(brandFlag) {
        val categoryBrandBannerData = constructCategoryBrandLevelBannerData(extraParams, objectivesDfMap)
        esData.join(categoryBrandBannerData, Seq("customer"), "left_outer")
      } else {
        esData
      }
     helpers.renameMultipleColumns(esDataBannerBrandData, customerFiltersAndSuppressions, custFiltersAndSuppressionsShortName)
    } else {
      helpers.renameMultipleColumns(elasticFormatBrandDF, customerFiltersAndSuppressions, custFiltersAndSuppressionsShortName)
    }

    val customerBandDFPath = helpers.combinePaths(appLocalPath, "customerBasketNominationMetrics", "basketMetrics")
    val customerBandDF: DataFrame = helpers.readInput(customerBandDFPath)
      .select(F.col("Customer").alias("custid"), F.col("band_id").alias("band"))

    finalDF.join(customerBandDF, Seq("custid"), "left").na.fill("Band_-2147483648_-1", Seq("band"))
  }

  private def getUnionPersistentData(objectivesDfMap: Map[String, (DataFrame, String)],
                                     persistentDataType: String): DataFrame = {
    val filteredObjectiveMap = objectivesDfMap.filter(_._1.toLowerCase.contains(s"_$persistentDataType"))
    if(filteredObjectiveMap.isEmpty) {
      val schema = StructType(
        Array(
          StructField("customer", StringType, true),
          StructField("item", StringType, true),
          StructField("objective", StringType, true)
        )
      )
      if (persistentDataType.contains("brand")) {
        schema.add("productbrand", StringType)
      }
      sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row], schema)
    } else {
      val headObjective = filteredObjectiveMap.head._2
      val headObjectiveDF = headObjective._1.withColumn("objective", F.lit(headObjective._2))
      if(filteredObjectiveMap.tail.nonEmpty) {
        filteredObjectiveMap.tail.foldLeft(headObjectiveDF) {
          case (df, objectives) =>
            df.union(objectives._2._1.withColumn("objective", F.lit(objectives._2._2)))
        }
      } else {
        headObjectiveDF
      }
    }
  }

  private def constructFeatureData(objectivesDfMap: Map[String, (DataFrame, String)],
                                   extraParams: Map[String, Any]): DataFrame = {

    val allObjectiveDf = getUnionPersistentData(objectivesDfMap, "product")
        .groupBy("customer", "item").agg(F.collect_list("objective").alias("objectives"))
        .withColumnRenamed("item", "product")

    val allFeaturesDf = constructFeaturesDataHelper(extraParams, List("product"), "product", "customer", "all", "all")
    val featureCustProdDf = allFeaturesDf.join(allObjectiveDf, List("customer", "product"), "left_outer").na.fill(0.0)
    val allProductCols = List(F.col("product")) ::: featureCols ::: List(F.col("objectives"))

    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(featureCustProdDf), oldNames, newNames)
      .withColumn("products", F.struct(allProductCols: _*))
      .groupBy("customer").agg(F.collect_list("products").alias("products"))
  }

  private def constructFeaturesDataHelper(extraParams: Map[String, Any], prodHierarchyList: Seq[String],
                                          product: String = "product", customer: String = "customer",
                                          store: String = "all", channel: String = "all", brandFlag: Boolean = false): DataFrame = {
    val timegrainMap = extraParams.get("prodTimegrainFeaturesMap")
      .fold(Map.empty[String, Seq[String]])(x => x.asInstanceOf[Map[String, Seq[String]]])
    helpers.getOneLevelAllTimegrainsFeatures(prodHierarchyList,
      timegrainMap,
      extraParams.get("cadenceWeek").asInstanceOf[Option[String]].fold("")(identity),
      extraParams.get("featuresDbName").asInstanceOf[Option[String]].fold("")(identity),
      product, customer, store, channel, brandFlag
    ).na.fill(0.0)
  }

  private def constructCustomerLevelData(extraParams: Map[String, Any]) = {
    val dimensionPathOrDb = extraParams("dimensionPathOrDb").asInstanceOf[String]
    val customerFlags = extraParams.get("customerFlags").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val dropCols = extraParams.get("customerDropCols").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val customerDim = helpers.readPersistedDim(dimensionPathOrDb, "customers").drop(dropCols: _*)
    val objectivesReplaceValues = customerFlags.map{flag => false}
    val customerDimDf = helpers.replaceMultipleColumnsNull(customerDim, customerFlags, objectivesReplaceValues)
    val compact = F.udf((data: mutable.WrappedArray[Boolean]) => {
      customerFlags.zip(data.toList).collect { case (k, true) => k }
    })
    val custArrCols = F.array(customerFlags.map{x => F.col(x)}.map(_.cast(T.BooleanType)): _*)
    val customerDimData = customerDimDf.withColumn("custFlags", custArrCols)
      .withColumn("customerFlags", compact(F.col("custFlags"))).drop(customerFlags: _*).drop("custFlags").na.fill("")

    customerDimData
  }

  private def constructPacData(extraParams: Map[String, Any], oldNames: List[String], newNames: List[String]): DataFrame = {

    val pacHierarchy = extraParams.get("pacHierarchy").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val structCols = List(F.col(s"${pacHierarchy.last}").alias("pac")) ::: newNames.map(F.col)
    val customerPacDf = constructFeaturesDataHelper(extraParams, pacHierarchy, pacHierarchy.last, "customer", "all", "all")
    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(customerPacDf), oldNames, newNames)
      .withColumn("PACs", F.struct(structCols: _*))
      .groupBy("customer").agg(F.collect_list("PACs").alias("pacs"))
  }

  private def constructCategoryData(extraParams: Map[String, Any], objectivesDfMap: Map[String, (DataFrame, String)]) = {
    val categoryHierarchy = extraParams.get("categoryHierarchyList").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val categoryDfData = constructFeaturesDataHelper(extraParams, categoryHierarchy, categoryHierarchy.last, "customer", "all", "all")
      .join(constructCatCouponCustomerLevelData(objectivesDfMap, categoryHierarchy.last), Seq("customer", categoryHierarchy.last), "left_outer")
    val categoryCols = List(F.col(s"${categoryHierarchy.last}").alias("category")) ::: featureCols ::: List(F.col("objectives"))

    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(categoryDfData), oldNames, newNames)
      .withColumn("categories", F.struct(categoryCols: _*))
      .groupBy("customer").agg(F.collect_list("categories").alias("categories"))
  }

  private def constructCategoryBrandData(extraParams: Map[String, Any], objectivesDfMap: Map[String, (DataFrame, String)]) = {

    val categoryHierarchy = extraParams.get("categoryHierarchyList").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val categoryData = constructFeaturesDataHelper(extraParams, categoryHierarchy, categoryHierarchy.last ,
      "customer", "all", "all", true)

    val categoryDfData = categoryData
      .join(constructCatBrandCouponCustomerLevelData(objectivesDfMap, categoryHierarchy.last),
        Seq("customer", categoryHierarchy.last, "productbrand"),
        "left_outer")

    val categoryCols = List(F.col(s"${categoryHierarchy.last}").alias("category"),
      F.col("productbrand").alias("brand")) ::: featureCols ::: List(F.col("objectives"))

    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(categoryDfData), oldNames, newNames)
      .withColumn("categories_brand", F.struct(categoryCols: _*))
      .groupBy("customer").agg(F.collect_list("categories_brand").alias("categories_brand"))
  }

  private def constructCatCouponCustomerLevelData(objectivesDfMap: Map[String, (DataFrame, String)],
                                                  cmpCategoryName: String) = {

    getUnionPersistentData(objectivesDfMap, "category")
      .groupBy("customer", "item").agg(F.collect_list("objective").alias("objectives"))
      .withColumnRenamed("item", cmpCategoryName)
  }

  private def constructCatBrandCouponCustomerLevelData(objectivesDfMap: Map[String, (DataFrame, String)],
                                                       cmpCategoryName: String) = {

    val unionPersistentData = getUnionPersistentData(objectivesDfMap, "brand")
    unionPersistentData.groupBy("customer", "item", "productbrand").agg(F.collect_list("objective").alias("objectives"))
      .withColumnRenamed("item", cmpCategoryName)
  }

  private def constructCustomerLevelBannerData(extraParams: Map[String, Any]): DataFrame = {
    val customerBannerData = constructFeaturesDataHelper(extraParams, List.empty, "all", "customer", "banner", "all")
    val bannerCols = List(F.col("banner")) ::: featureCols
    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(customerBannerData), oldNames, newNames)
      .withColumn("banners", F.struct(bannerCols: _*))
      .groupBy("customer").agg(F.collect_list("banners").alias("banners"))
  }

  private def constructCPLevelBannerData(extraParams: Map[String, Any], objectivesDfMap: Map[String, (DataFrame, String)]): DataFrame = {
    val allObjectiveDf = getUnionPersistentData(objectivesDfMap, "product")
      .groupBy("customer", "item").agg(F.collect_list("objective").alias("objectives"))
      .withColumnRenamed("item", "product")

    val bannerData = constructFeaturesDataHelper(extraParams, List("product"), "product", "customer", "banner", "all")
    val bannerDfData = bannerData
      .join(allObjectiveDf, List("customer", "product"), "left_outer").na.fill(0.0)

    val bannerCols = List(F.col("product"), F.col("banner")) ::: featureCols ::: List(F.col("objectives"))
    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(bannerDfData), oldNames, newNames)
      .withColumn("product_banners", F.struct(bannerCols: _*))
      .groupBy("customer").agg(F.collect_list("product_banners").alias("product_banners"))
  }

  private def constructCategoryLevelBannerData(extraParams: Map[String, Any], objectivesDfMap: Map[String, (DataFrame, String)]): DataFrame = {

    val categoryHierarchy = extraParams.get("categoryHierarchyList").fold(List.empty[String])(x => x.asInstanceOf[List[String]])
    val bannerData = constructFeaturesDataHelper(extraParams, categoryHierarchy, categoryHierarchy.last, "customer", "banner", "all")

    val bannerDfData = bannerData
      .join(constructCatCouponCustomerLevelData(objectivesDfMap, categoryHierarchy.last),
        Seq("customer", categoryHierarchy.last), "left_outer")

    val bannerCols = List(F.col(s"${categoryHierarchy.last}").alias("category"), F.col("banner")) ::: featureCols ::: List(F.col("objectives"))
    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(bannerDfData), oldNames, newNames)
      .withColumn("category_banners", F.struct(bannerCols: _*))
      .groupBy("customer").agg(F.collect_list("category_banners").alias("category_banners"))
  }

  private def constructCategoryBrandLevelBannerData(extraParams: Map[String, Any], objectivesDfMap: Map[String, (DataFrame, String)]): DataFrame = {
    val categoryHierarchy = extraParams.get("categoryHierarchyList").fold(List.empty[String])(x => x.asInstanceOf[List[String]])

    val bannerData = constructFeaturesDataHelper(extraParams, categoryHierarchy, categoryHierarchy.last ,
  "customer", "banner", "all", true)

    val bannerDfData = bannerData
      .join(constructCatBrandCouponCustomerLevelData(objectivesDfMap, categoryHierarchy.last),
        Seq("customer", categoryHierarchy.last, "productbrand"),
        "left_outer")

    val bannerCols = List(F.col(s"${categoryHierarchy.last}").alias("category"), F.col("banner")):::
      List(F.col("productbrand").alias("brand")) ::: featureCols ::: List(F.col("objectives"))

    helpers.renameMultipleColumns(helpers.castSparkDFTypestoES(bannerDfData), oldNames, newNames)
      .withColumn("category_banners_brand", F.struct(bannerCols: _*))
      .groupBy("customer").agg(F.collect_list("category_banners_brand").alias("category_banners_brand"))
  }
}

object ESDataCreation {
  def apply(sparkSession: SparkSession, applicationConfiguration: AppConfiguration): ESDataCreation
  = new ESDataCreation(sparkSession, applicationConfiguration)
}
