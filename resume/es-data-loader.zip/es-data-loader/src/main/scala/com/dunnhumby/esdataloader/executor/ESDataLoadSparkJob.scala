// scalastyle:off
package com.dunnhumby.esdataloader.executor

import com.dunnhumby.esdataloader.utils._
import com.dunnhumby.esdataloader.conf._
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession


/**
  * Created By shriyam on 05/05/2020.
  */

object ESDataLoadSparkJob {

  def main(args: Array[String]): Unit = {

    Logger.getRootLogger.setLevel(Level.ERROR)

    val sparkSession = SparkSession.builder()
      .appName("es-data-load-spark-job")
      .enableHiveSupport()
      .getOrCreate()

    sparkSession.sparkContext.setLogLevel("ERROR")

    val argsMap = Helpers(sparkSession).cliArgsToMap(args)
    val persistentDataDB = argsMap.getOrElse("persistentDataDB",
      throw new IllegalArgumentException(s"${getClass.getName} -" +
      s" persistentDataDB key is missing from command line arguments"))

    System.setProperty("persistentDataDB", persistentDataDB)

    val client = argsMap.getOrElse("client",
      throw new IllegalArgumentException(s"${getClass.getName} -" +
        s" clint key is missing from command line arguments"))

    val environment = argsMap.getOrElse("environment",
      throw new IllegalArgumentException(s"${getClass.getName} -" +
        s" environment key is missing from command line arguments"))

    val paramMap = argsMap ++ Defaults.defaults
    val applicationConfiguration = AppConfiguration(environment, client)
    val writePath = argsMap.getOrElse("writePath",
      throw new IllegalArgumentException("writePath not specified"))

    val jobType = argsMap.getOrElse("job", "both")

    jobType.toLowerCase match {
      case "create" =>
        ESDataCreation(sparkSession, applicationConfiguration).elasticsearchHandler(writePath, paramMap)
      case "upload" =>
        ESDataUpload(sparkSession, applicationConfiguration).uploadData(environment, argsMap, writePath)
      case _ =>
        ESDataCreation(sparkSession, applicationConfiguration).elasticsearchHandler(writePath, paramMap)
        ESDataUpload(sparkSession, applicationConfiguration).uploadData(environment, argsMap, writePath)
    }
  }
}
