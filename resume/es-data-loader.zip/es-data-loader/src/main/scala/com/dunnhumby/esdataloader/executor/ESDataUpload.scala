package com.dunnhumby.esdataloader.executor

//scalastyle:off
import com.dunnhumby.core.format.dataframe.DataFrameReadWriteFormat
import com.dunnhumby.esdataloader.conf.AppConfiguration
import com.dunnhumby.esdataloader.generators.Generator
import com.dunnhumby.esdataloader.utils.Utilities
import com.typesafe.config.ConfigValueFactory
import org.apache.spark.sql.{DataFrame, SparkSession, functions => F}
import org.apache.spark.sql.functions.{col, current_timestamp, lower, upper}
import org.elasticsearch.spark.sql._
import com.dunnhumby.esdataloader.utils.BQUtils._
import org.apache.spark.sql.types.StringType

/**
  * Created By shriyam on 05/05/2020.
  */

class ESDataUpload(sparkSession: SparkSession, appConfiguration: AppConfiguration) {

  import sparkSession.implicits._

  def uploadData(environment: String,
                 args: Map[String, String],
                 writePath: String): Unit = {

    val cadenceWeekOriginal = args.getOrElse("cadenceWeek",
      throw new IllegalArgumentException("cadence week not specified"))
    val cadenceWeek = args.getOrElse("cadenceWeekElastic", cadenceWeekOriginal)
    val isMultiTenant = args.getOrElse("isMultiTenant", "false").toBoolean
    val pacPath = args.get("pacPath")
    val productPath = args.get("productPath")
    val storesPath = args.get("storePath")
    val sink = args.getOrElse("sink",
      throw new IllegalArgumentException("sink not specified"))
    val hierarchy = appConfiguration.hiearchies
    val esNodes = appConfiguration.esNodes
    val wanOnly = appConfiguration.wanMode
    val enableProxy = appConfiguration.enableProxy
    val port = appConfiguration.port
    val batchSize = appConfiguration.batchSizeInMb
    val batchEntries = appConfiguration.batchEntries
    val esURL = s"http://${esNodes.head}:${port.toString}"
    val proxyHost = appConfiguration.proxyHost
    val proxyPort = appConfiguration.proxyPort
    val customerDataReadConfigWithoutPath = appConfiguration.dataPath
    val clientPostfix = appConfiguration.clientPostFix
    val optionMap = appConfiguration.bqOptionMap
    val productsReadConfig = if(productPath.isDefined) {
      appConfiguration.productsPath.withValue("option.path", ConfigValueFactory.fromAnyRef(productPath.get))
    } else {
      appConfiguration.productsPath
    }

    val enableSSL = appConfiguration.enableSSL
    val adminUsername = appConfiguration.adminUserName
    val authEnabled = appConfiguration.authEnabled
    val l10 = appConfiguration.l10
    val enableIdempotentInserts = appConfiguration.enableIdempotentInserts
    val generateEntityIndexes = appConfiguration.generateEntityIndexes
    val chunkedIndex = appConfiguration.chunkedIndex
    val pacTableReadConfig = if(pacPath.isDefined) {
      appConfiguration.pacTable.withValue("option.path", ConfigValueFactory.fromAnyRef(pacPath.get))
    } else {
      appConfiguration.pacTable
    }

    val storesEntityReadConfig = if(storesPath.isDefined) {
      appConfiguration.storesEntity.withValue("option.path", ConfigValueFactory.fromAnyRef(storesPath.get))
    } else {
      appConfiguration.storesEntity
    }
    val clusterNumCol = appConfiguration.clusterNumColumn
    val batchWriteRetryWait = appConfiguration.batchWriteRetryWait
    val batchRetryCount = appConfiguration.batchRetryCount
    val switchAliases = appConfiguration.switchAliases

    println(s"Chunked Index : ${chunkedIndex}")

    var esConf = Map[String, String]()
    esConf = esConf + ("es.nodes" -> esNodes.mkString(","))
    esConf = esConf + ("es.port" -> port.toString)

//  This is equivalent to setting index.refresh_index = -1. But even if you set this at index level the connector
//  property will override it. Hence disabling it from the connector. If you want to enable it, set it via template
//  customers template in init._es.sh file
    esConf = esConf + ("es.batch.write.refresh" -> "false")

    if (wanOnly) {
      println("Enabling Wan Only mode")
      esConf = esConf + ("es.nodes.wan.only" -> wanOnly.toString)
    }

    if (enableProxy) {
      println("Enabling Proxy settings")
      esConf = esConf + ("es.net.proxy.http.host" -> proxyHost)
      esConf = esConf + ("es.net.proxy.http.port" -> proxyPort.toString)
    }

    if (enableSSL) {
      println("Enabling SSL settings")
      esConf = esConf + ("es.net.ssl" -> "true")
      esConf = esConf + ("es.net.ssl.keystore.location" -> "identity.jks")
      esConf = esConf + ("es.net.ssl.cert.allow.self.signed" -> "true")
    }

    if (authEnabled) {
      println("Enabling Authentication settings")
      esConf = esConf + ("es.net.http.auth.user" -> adminUsername)
      esConf = esConf + ("es.keystore.location" -> "esh.keystore")
    }

//    This is a configurable part of indexing. Usually when you are running in production this should be enabled.
//    For POC purposes you can skip this section or when entity data is not published on HDFS.
//    Add default configurations here. Refer
//    https://www.elastic.co/guide/en/elasticsearch/hadoop/current/configuration.html for list of all configurations.

    if (generateEntityIndexes) {
      esConf = esConf + ("es.index.auto.create" -> "true")
      esConf = esConf + ("es.batch.size.bytes" -> (2 * 1024 * 1024).toString)

      val productsTemp = DataFrameReadWriteFormat(productsReadConfig).readDataFrame(sparkSession.sqlContext)
      val products = productsTemp.selectExpr(Utilities.normalizeColumns(productsTemp.columns): _*)
      val storesDf = DataFrameReadWriteFormat(storesEntityReadConfig).readDataFrame(sparkSession.sqlContext)
      val stores = storesDf.selectExpr(Utilities.normalizeColumns(storesDf.columns): _*)
      val keys: List[String] = hierarchy.toList.sortBy(_._2._1).map(_._1)

      println("Generating Hierarchy Browsing index.")

      val hierarchies = Generator.generateHierarchyIndexData(hierarchy, keys)
      val hierarchiesIndex = Utilities.formatIndexName("hierarchies", clientPostfix, isMultiTenant)

      println("Starting Hierarchy load")
      val hierarchiesDF = hierarchies.toDF("Level", "Order", "IsSelectable", "Index")

      val hierarchyIndexName = sink match {
        case "es" => s"$hierarchiesIndex/hierarchy"
        case "bq" => hierarchiesIndex
      }

      esBQUpload(hierarchiesDF, hierarchyIndexName, esConf + ("es.mapping.id" -> "Level"), sink, optionMap)

      for ((level1, level2) <- keys zip keys.drop(1)) {
        val df = Generator.generateHierarchy(products, level1, level2)
        val index = Utilities.formatIndexName(Utilities.getIndexName(level1), clientPostfix, isMultiTenant)
        println(s"Saving $index.")
        esBQUpload(df, index, esConf + ("es.mapping.id" -> "C"), sink, optionMap)
      }

      // generating Lowest Hierarchy index
      val bottomHierarchyDf = Generator.generateBottomHierarchy(products, keys.last)
      val index = Utilities.formatIndexName(Utilities.getIndexName(keys.last), clientPostfix, isMultiTenant)
      println(s"Saving $index.")
      esBQUpload(bottomHierarchyDf, index, esConf + ("es.mapping.id" -> "C"), sink, optionMap)

      println("Loading products data into index.")
      val productsIndex = Utilities.formatIndexName("products", clientPostfix, isMultiTenant)
      val productIndexWithType = sink match {
        case "es" => s"$productsIndex/product"
        case "bq" => productsIndex
      }
      esBQUpload(products, productIndexWithType, esConf + ("es.mapping.id" -> "product"), sink, optionMap)

      println("Loading Stores data into index")
      val storeIndex = Utilities.formatIndexName("stores", clientPostfix, isMultiTenant)
      val storeIndexWithType = sink match {
        case "es" => s"$storeIndex/store"
        case "bq" => storeIndex
      }
      esBQUpload(stores, storeIndexWithType, esConf + ("es.mapping.id" -> "store"), sink, optionMap)

      println("Loading PACS data into index")
      val pacs = if (pacTableReadConfig.isEmpty) {
        Generator.generatePACIndex(products, l10)
      } else {
        val pacDf = DataFrameReadWriteFormat(pacTableReadConfig).readDataFrame(sparkSession.sqlContext)
        Generator.generatePACIndex(products, l10, pacDf, clusterNumCol)
      }
      val pacIndex = Utilities.formatIndexName("pacs", clientPostfix, isMultiTenant)
      val pacIndexWithType = sink match {
        case "es" => s"$pacIndex/pac"
        case "bq" => pacIndex
      }
      esBQUpload(pacs, pacIndexWithType, esConf + ("es.mapping.id" -> "PAC"), sink, optionMap)
    }

    val customerIndex = Utilities.formatIndexName("customers", clientPostfix, isMultiTenant)
    val customerData = DataFrameReadWriteFormat(customerDataReadConfigWithoutPath
      .withValue("option.path", ConfigValueFactory.fromAnyRef(writePath)))
      .readDataFrame(sparkSession.sqlContext)

    val totalCustomers = customerData.count()
    println(s"Total customers $totalCustomers")

    sink match {
      case "bq" => {
        val indexName = s"${customerIndex}_${cadenceWeek}"
        println("Starting data load in customers table.")
        println("deleting old tables if there")

        val project = optionMap("projectName")
        val datasetName = optionMap("databaseName")
        deleteOldTables(project, datasetName, customerIndex)

        println("Initiating table upload.")
        esBQUpload(customerData, indexName, esConf, sink, optionMap)
        println("Data load bq finished.")
        if (switchAliases) {
          runCopyTable(project, datasetName, indexName, datasetName, customerIndex)
        }
      }
      case "es" => {
        val indexName = s"${customerIndex}_${cadenceWeek}"
        val indexNameWithDocumentType = s"${indexName}/customer"

        // Applying these settings here because we don't want to apply these settings to other indexing requests.

        esConf = esConf + ("es.batch.size.bytes" -> (batchSize * 1024 * 1024).toString)
        esConf = esConf + ("es.batch.size.entries" -> batchEntries.toString)
        esConf = esConf + ("es.batch.write.retry.count" -> batchRetryCount.toString)
        esConf = esConf + ("es.batch.write.retry.wait" -> batchWriteRetryWait.toString)

        println("deleting old indices if there")
        Utilities.deleteOldIndex(esURL, indexName)

        if (enableIdempotentInserts) {
          esConf = esConf + ("es.mapping.id" -> "custid")
        }

        val charToIntConverter = F.udf((value: String) => {
          value.map(x => x.toInt).sum
        })

        if (!chunkedIndex) {
          println("Initiating complete bulk index.")
          esBQUpload(customerData, indexNameWithDocumentType, esConf, sink, optionMap)
        }

        else {
          println("Initiating chunked bulk index. Chunk size 10")

          val customerDataWithAscii = customerData.withColumn("ascii_custid", charToIntConverter($"custid"))
          for (i <- 0 to 9) {
            println(s"Loading chunk -> $i")
            val start = System.currentTimeMillis
            val filteredCustomers = customerDataWithAscii.filter($"ascii_custid".endsWith(s"$i"))
            val counts = filteredCustomers.count()
            println(s"Customers in chunk $i -> $counts")
            Thread.sleep(10000)
            val droppedDF = filteredCustomers.drop("ascii_custid", "pacs")
            esBQUpload(droppedDF, indexNameWithDocumentType, esConf, sink, optionMap)
            val totalTime = System.currentTimeMillis - start
            println(s"Ended loading data for chunk $i. Total time elapsed(in Sec.) : ${totalTime / 1000}")
          }
        }
        println("Data load finished.")
        if (switchAliases) {
          val (removePattern, alias) = if(!isMultiTenant) ("customers*", "customers") else (s"customers@${clientPostfix}*", s"customers@${clientPostfix}")
          Utilities.postUploadOperations(esURL, indexName, alias, removePattern)
        }
      }
    }
  }

  def esBQUpload(inputDF: DataFrame,
                 indexName: String,
                 esConf: Map[String, String],
                 sink: String,
                 optionMap: Map[String, String]): Unit = {
    sink match {
      case "es" => inputDF.saveToEs(indexName, esConf)
      case "bq" =>
        val temporaryGcsBucket = optionMap("temporaryGCSBucket")
        val projectName = optionMap("projectName")
        val databaseName = optionMap("databaseName")
        val clusteredFields = if(optionMap.isDefinedAt("clusteredFields")) optionMap("clusteredFields") else ""
        if (sink == "bq" && indexName.contains("customer") && clusteredFields.nonEmpty) {
          val partitionField = if(optionMap.isDefinedAt("partitionField")) optionMap("partitionField") else "insert_time"
          val partitionedDF = if (inputDF.schema.fieldNames.toList.contains(partitionField)) {
            inputDF
          } else {
            inputDF.withColumn(partitionField, current_timestamp())
          }
          partitionedDF
            .write
            .format("com.google.cloud.spark.bigquery")
            .option("intermediateFormat", "ORC")
            .option("partitionField", partitionField)
            .option("clusteredFields", clusteredFields)
            .option("temporaryGcsBucket", temporaryGcsBucket)
            .option("table", s"${projectName}:${databaseName}." + indexName)
            .mode("overwrite")
            .save()
        } else {
          inputDF
            .write
            .format("com.google.cloud.spark.bigquery")
            .option("intermediateFormat", "ORC")
            .option("temporaryGcsBucket", temporaryGcsBucket)
            .option("table", s"${projectName}:${databaseName}." + indexName)
            .mode("overwrite")
            .save()
          }
    }
  }
}

object ESDataUpload {
  def apply(sparkSession: SparkSession, appConfiguration: AppConfiguration)
  : ESDataUpload = new ESDataUpload(sparkSession, appConfiguration)
}
