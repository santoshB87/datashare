package com.dunnhumby.esdataloader.generators

import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession, functions => F}
import com.dunnhumby.esdataloader.utils.Utilities

object Generator {

  def generateHierarchy(products: DataFrame, level1: String, level2: String): DataFrame = {
    println(s"Generating $level1 -> $level2")
    val index = Utilities.getIndexName(level1)
    //val array = getIndexName(level2)
    val array = "child_array"

    val productBrandLevel1 = products.groupBy(level1).agg(F.collect_set(products("productbrand")).alias("brands"))
    val productBrandLevel2 = products.groupBy(level2).agg(F.collect_set(F.col("productbrand")).alias(s"brands_$level2"))

    val productLevel2Joined = products.join(productBrandLevel2, Seq(level2), "leftouter")

    val productWithLevel2Brand = productLevel2Joined.select(
      F.col(level1).alias("Code"),
      F.col(Utilities.getDescriptionColumn(level1)).alias("Desc"),
      F.col(level2).alias("C"),
      F.col(Utilities.getDescriptionColumn(level2)).alias("D"),
      F.col(s"brands_$level2")
    ).withColumn(array, F.struct(F.col("C"), F.col("D"), F.col(s"brands_$level2").alias("B")))
      .groupBy("Code", "Desc").agg(F.collect_set(array).alias(array))
      .selectExpr("Code as C", "Desc as D", array)

    productWithLevel2Brand.join(productBrandLevel1, productWithLevel2Brand("C") === productBrandLevel1(level1),
      "leftouter").drop(productBrandLevel1(level1))
      .withColumnRenamed("brands", "B")
      .repartition(1)
  }

  def generateBottomHierarchy(products: DataFrame, hierarchyName: String): Dataset[Row] = {
    println(s"Generating hierarchy $hierarchyName")
    val groupedBrandAtHierarchy = products.groupBy(hierarchyName).agg(F.collect_set(products("productbrand")).alias("B"))

    val productWithBrand = products.select(hierarchyName,Utilities.getDescriptionColumn(hierarchyName)).distinct()
      .join(groupedBrandAtHierarchy, Seq(hierarchyName), "leftouter")
    productWithBrand.select(F.col(hierarchyName).alias("C"),
      F.col(Utilities.getDescriptionColumn(hierarchyName)).alias("D"),
      F.col("B"))
      .repartition(1)
  }

  private def getPACIndex (products: DataFrame, l10: String): DataFrame = {
    val pacCol = s"pac$l10"
    products.select(F.col(l10).alias("L10"), F.col(pacCol).cast(StringType).alias("PAC")).groupBy("PAC").agg(F.collect_set("L10").alias("L10s"))
  }

  def generatePACIndex(products: DataFrame, l10: String): DataFrame = {
    getPACIndex(products,l10)
  }

  def generatePACIndex(products: DataFrame, l10: String, pacDf: DataFrame, clusterNumCol: String): DataFrame = {
    val pacCol = s"pac$l10"
    val df = products.join(pacDf, Seq(l10)).withColumnRenamed(clusterNumCol, pacCol)
    getPACIndex(df, l10)
  }

  // 02-09-2021 - Changed hierarchy index name for subgroup from products to hierarchy_subgroup
  // as per Ashish Kumar's request.
  def generateHierarchyIndexData(hierarchy: Map[String, (Int,Boolean)], keys: List[String])
  : List[(String, Int, Boolean, String)] = {
    val maxRank = hierarchy.map(obj => obj._2._1).max + 2
    // We need to reverse the ranking of hierarchy because in Postgres we had ranking starting from bottom up.
    val reversedHierarchy = hierarchy.map(obj => (obj._1, (maxRank - obj._2._1, obj._2._2))) + ("Product" -> (1, true))
    hierarchy.toList.sortBy(_._2._1).map(_._1)
      .map(key => (key, reversedHierarchy(key)._1, reversedHierarchy(key)._2,
        Utilities.getIndexName(key))) :+
      ("Product", reversedHierarchy("Product")._1, reversedHierarchy("Product")._2, "products")
  }

}
