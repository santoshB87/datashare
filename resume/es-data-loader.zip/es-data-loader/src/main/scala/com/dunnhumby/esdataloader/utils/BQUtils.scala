package com.dunnhumby.esdataloader.utils

//scalastyle:off
import com.google.cloud.bigquery._
import scala.collection.JavaConverters._

object BQUtils {

  def runCopyTable(project: String, sourceDatasetName: String, sourceTableId: String, destinationDatasetName: String,
                   destinationTableId: String, deleteBeforeCopy: Boolean = true): Unit = {

    val bigQuery: BigQuery = BigQueryOptions.newBuilder().setProjectId(project).build().getService
    try {
      // Initialize client that will be used to send requests. This client only needs to be created
      // once, and can be reused for multiple requests.
      val sourceTable = TableId.of(project, sourceDatasetName, sourceTableId)
      val destinationTable = TableId.of(project, destinationDatasetName, destinationTableId)

      // For more information on CopyJobConfiguration see:
      // https://googleapis.dev/java/google-cloud-clients/latest/com/google/cloud/bigquery/JobConfiguration.html
      val configuration = CopyJobConfiguration.newBuilder(destinationTable, sourceTable).build
      if (deleteBeforeCopy) {
        runDeleteTable(project, destinationDatasetName, destinationTableId)
      }

      // For more information on Job see:
      // https://googleapis.dev/java/google-cloud-clients/latest/index.html?com/google/cloud/bigquery/package-summary.html
      val job = bigQuery.create(JobInfo.of(configuration))
      // Blocks until this job completes its execution, either failing or succeeding.
      val completedJob = job.waitFor()
      if (completedJob == null) {
        println("Job not executed since it no longer exists.")
      }
      else if (completedJob.getStatus.getError != null) {
        println("BigQuery was unable to copy table due to an error: \n" + job.getStatus.getError)
      } else {
        println("Table copied successfully.")
      }
    } catch {
      case e@(_: BigQueryException | _: InterruptedException) =>
        println("Table copying job was interrupted. \n" + e.toString)
    }
  }

  def runDeleteTable(project: String, datasetName: String, tableName: String): Int = {
    val bigQuery: BigQuery = BigQueryOptions.newBuilder().setProjectId(project).build().getService
    try {
      val success = bigQuery.delete(TableId.of(project, datasetName, tableName))
      if (success){
        println("Table deleted successfully")
        0
      } else {
        println("Table was not found")
        1
      }
    } catch {
      case e: BigQueryException => {
        println("Table was not deleted. \n" + e.toString)
        -1
      }
    }
  }

  def listTables(projectId: String, datasetName: String): List[String] = {
    val bigQuery: BigQuery = BigQueryOptions.newBuilder().setProjectId(projectId).build().getService
    try {
      val datasetId = DatasetId.of(projectId, datasetName)
      val tables = bigQuery.listTables(datasetId)
      val tableNames = tables.iterateAll.asScala.toList.map(table => table.getTableId.getTable)
      println("Tables listed successfully.")
      tableNames
    } catch {
      case e: BigQueryException => {
        println("Tables were not listed. Error occurred: " + e.toString)
        Nil
      }
    }
  }

  def deleteOldTables(projectId: String, datasetName: String, tablePrefix: String): List[Boolean] = {
    val tables = listTables(projectId, datasetName)
    val oldTables = tables.filter(table => table.contains(tablePrefix)).map(_.trim).diff(List(tablePrefix))

    oldTables.length match {
      case 0 | 1 =>
        println("\n\nNo deletion of tables required")
        List(true)
      case _: Int =>
        val result = oldTables.init.map {
          table =>
            println("Requesting to delete table : " + table)
            runDeleteTable(projectId, datasetName, table)
        }
        result.map{res =>
          res == 0
        }
    }
  }
}
