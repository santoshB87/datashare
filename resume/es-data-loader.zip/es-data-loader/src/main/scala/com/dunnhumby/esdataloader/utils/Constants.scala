package com.dunnhumby.esdataloader.utils

/**
  * Created By shriyam on 05/05/2020.
  */

object Constants {

  val DEFAULT_HANDLER = "hiveHandler"

  val HUNDRED = 100
  val FIFTYTWO = 52
  val TWENTYSIX = 26
  val THIRTEEN = 13
  val EIGHT = 8
  val FOUR = 4
  val ONE = 1
  val YEARLENGTH = 4
  val WEEKLENGTH = 2
  val TEN = 10
  val SIX = 6
  val FIVE = 5
  val THREE = 3
  val TWO = 2
}
