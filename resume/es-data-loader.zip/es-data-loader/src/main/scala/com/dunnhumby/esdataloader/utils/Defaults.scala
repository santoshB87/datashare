package com.dunnhumby.esdataloader.utils

/**
  * Created By shriyam on 15/05/2020.
  */

object Defaults {
  /**
    * The following map gets merged with the parameters
    * supplied via `objective_specs.json`. So, this comes in
    * handy when you create a `DataPreps` or `Objectives` method
    * that takes some default values.
    * This object stays here because currently I was unable to deal
    * with the methods that take default arguments; via reflection.
    */
  val defaults: Map[String, Any] = Map(
    "shareFeatures" -> Seq("baskets_share_1w52w", "quantity_share_1w52w", "netspend_share_1w52w"),
    "cadence" -> "1w52w"
  )
}
