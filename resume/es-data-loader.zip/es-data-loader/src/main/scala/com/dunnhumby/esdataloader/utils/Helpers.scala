package com.dunnhumby.esdataloader.utils

import java.nio.file.Paths

import org.apache.spark.sql.{DataFrame, Dataset, SparkSession, functions => F}
import org.apache.spark.sql.types.FloatType
import com.dunnhumby.esdataloader.utils.Constants._
import com.typesafe.config.{Config, ConfigRenderOptions}

import scala.annotation.tailrec
import scalaz.Scalaz._

/**
  * Created By shriyam on 05/05/2020.
  */

class Helpers(sparkSession: SparkSession) {

  /**
    * Create a map out of all the parameters passed through CLI
    *
    * @param cliArgs arguments passed via CLI
    * @return map of CLI arguments
    */
  def cliArgsToMap(cliArgs: Array[String]): Map[String, String] =
    cliArgs map { arg => val x = arg split "="; (x(0), x(1)) } toMap

  /**
    * This method replace the given column names(oldNames) with the new names
    *
    * @param dataFrame : any spark dataframe
    * @param oldNames  : Name of columns as present in dataframe
    * @param newNames  : Name of columns as expected in resultant dataframe
    * @return
    */
  @tailrec
  final def renameMultipleColumns(dataFrame: DataFrame, oldNames: List[String], newNames: List[String]): DataFrame =
    (oldNames, newNames) match {
      case (oldName :: oldTail, newName :: newTail) =>
        renameMultipleColumns(dataFrame.withColumnRenamed(oldName, newName), oldTail, newTail)
      case (Nil, Nil) => dataFrame
    }


  /**
    * Convert datatype of netspend and quantity features to FloatType.
    * This conversion at first place is needed as elasticsearch do not support Decimal Type.
    *
    * @param dataframe : any spark dataframe
    * @return : dataframe whose netspend and quantity columns are casted to FloatType.
    */
  def castSparkDFTypestoES(dataframe: DataFrame): DataFrame = {
    val grains = List(FIFTYTWO, TWENTYSIX, THIRTEEN, EIGHT, FOUR, ONE)
    val colsToCast = grains.map { x => s"netspend_1w${x}w" } ::: grains.map { x => s"quantity_1w${x}w" } :::
      grains.map { x => s"netspendperbasket_1w${x}w" } ::: grains.map { x => s"quantityperbasket_1w${x}w" }
    dataframe.select(
      dataframe.columns.map { column =>
        if (colsToCast.contains(column)) {
          dataframe(column).cast(FloatType)
        } else {
          dataframe(column)
        }
      }: _*
    )
  }

  /**
    * Get the Features for a given dimension level for all the timegrains.
    *
    * @param prodHierarchyList     ascending list of product hierarchy in the Dunnhumby CE world
    * @param timegrainsFeaturesMap Map with the timegrain as keys and list of features as values
    * @param cadenceWeek           fis_week_id to run Audience Science for
    * @param databaseName          name of the Features database
    * @param product               attribute to identify product dimension
    * @param customer              attribute to identify customer dimension
    * @param store                 attribute to identify store dimension
    * @param channel               attribute to identify channel dimension
    * @return DataFrame of Features as per above parameters
    */
  def getOneLevelAllTimegrainsFeatures(prodHierarchyList: Seq[String],
                                       timegrainsFeaturesMap: Map[String, Seq[String]],
                                       cadenceWeek: String,
                                       databaseName: String,
                                       product: String = "all",
                                       customer: String = "all",
                                       store: String = "all",
                                       channel: String = "all",
                                       brandFlag: Boolean = false): DataFrame = {
    val selectableDims = getSelectableDimsNames(prodHierarchyList, product, customer, store, channel, brandFlag)
    val readDFs = for {
      (tg, feats) <- timegrainsFeaturesMap
    } yield {
      val selectablesTemp = selectableDims ++ feats map F.col

      val (tblAttr, selectables) = if(brandFlag) {
        (composeAttributesMap(product + "_productbrand", customer, store, channel, tg), selectablesTemp :+ F.col("productbrand"))
      } else {
        (composeAttributesMap(product, customer, store, channel, tg), selectablesTemp)
      }

      readFeaturesTable(databaseName, tblAttr, cadenceWeek) select (selectables: _*)
    }
    readDFs reduceLeft ((left, right) => left.join(right, selectableDims, "left_outer"))
  }


  /**
    * This convenient method joins the paths given
    * as arguments but additionally preserves the
    * file system designator in the first uri.
    *
    * @param paths Paths that need to be combined
    * @return
    */
  def combinePaths(paths: String*): String = {
    val tails = paths.tail
    val fullRelativePath = Paths.get(tails.head, tails.tail: _*)
    s"${cleanPath(paths.head)}/$fullRelativePath"
  }

  private def cleanPath(s: String): String = if (s.last == '/') s.substring(0, s.length - 1) else s


  /**
    * Read the Features table for the given timegrain and level.
    *
    * @param databaseName    name of the Features database
    * @param tableAttributes attributes to compose the table name
    * @param cadenceWeek     fis_week_id to run Audience Science for
    * @return DataFrame of Features table read as per the above parameters
    */
  def readFeaturesTable(databaseName: String,
                        tableAttributes: Map[String, String],
                        cadenceWeek: String,
                        timegrain: String = ""): DataFrame =
    readInput(composeTableName(databaseName, tableAttributes, timegrain)).filter(s"cadence_week IN ($cadenceWeek)")


  /**
    * This method assumes that we can reference to only two types of data storage
    * 1) Parquet file 2) Hive table. The path identifier for Hive will contain a dot
    * whereas that for Parquet will not.
    *
    * @param path identifier which can either be the Hive table name
    *             or the HDFS path of the parquet file
    * @return DataFrame of content read from parquet or Hive
    */
  def readInput(path: String): DataFrame = if (path contains ".") readTable(path) else readParquet(path)

  /**
    * Read the parquet from the given HDFS path
    *
    * @param path HDFS path of the parquet
    * @return content of the parquet file as DataFrame
    */
  private def readParquet(path: String): DataFrame = sparkSession.read.load(path)

  /**
    * This method assumes that the identifier passed in refers to a Hive table.
    *
    * @param tableName name of the Hive table to be read
    * @return content of the Hive table as DataFrame
    */
  private def readTable(tableName: String): DataFrame = sparkSession.read.table(tableName)


  /**
    * This function has been written with the strong conviction
    * that only for the `product` column we need a whole list of
    * the desired hierarchies starting from the one supplied to
    * this function as the value of parameter `product` working our
    * way up the hierarchy levels and for the other dimensions we
    * care for only one identifier for each at a time. Also a
    * conventionally ordered list of product hierarchies is supplied
    * as the value of parameter `prodHierarchyList`. And, the identifiers
    * such as `all`, `1w52w` etc. don't make any sense with respect
    * to the features tables so, we filter them out.
    *
    * @param prodHierarchyList ascending sequence of product hierarchy
    * @param product           value of the product dimension attribute
    * @param customer          value of the customer dimension attribute
    * @param store             value of the store dimension attribute
    * @param channel           value of the channel dimension attribute
    * @return the list of dimensions to be selected from the table
    */
  def getSelectableDimsNames(prodHierarchyList: Seq[String],
                             product: String = "all",
                             customer: String = "all",
                             store: String = "all",
                             channel: String = "all",
                             brandFlag: Boolean = false): Seq[String] = {
    val dims = (composeAttributesMap(product, customer, store, channel) toSeq) filter {
      case (_, v: String) => (v ne "all") && (v ne "1w52w")
    } flatMap {
      case (k: String, v: String) =>
        if (k eq "product") {
          getProdHierarchies(prodHierarchyList, v)
        }
        else {
          Seq(v)
        }
    }
    val finalDimensions = if(brandFlag) {
      dims :+ "productbrand"
    }
    else {
      dims
    }

    finalDimensions
  }


  /**
    * It has been noticed that in most cases, we need all the product
    * attributes from the product hierarchy starting from the given one
    * and working our way up the hierarchy.
    *
    * @param hiers          ascending sequence of product hierarchy
    * @param givenHierarchy hierarchy including and above which
    *                       all the attributes are required
    * @return inclusive sequence of higher product hierarchies
    */
  def getProdHierarchies(hiers: Seq[String], givenHierarchy: String): Seq[String] = {
    val (_, right) = hiers splitAt (hiers indexOf givenHierarchy)
    right
  }


  /**
    * Compose the map of all the attributes and their values
    * required to compose a Features table name.
    *
    * @param product   value of the product dimension attribute
    * @param customer  value of the customer dimension attribute
    * @param store     value of the store dimension attribute
    * @param channel   value of the channel dimension attribute
    * @param timegrain value of the timegrain dimension attribute
    * @return map of attributes and their values required
    *         to compose a Features table name
    */
  def composeAttributesMap(product: String = "all",
                           customer: String = "all",
                           store: String = "all",
                           channel: String = "all",
                           timegrain: String = "1w52w"): Map[String, String] = Map(
    "product" -> product,
    "customer" -> customer,
    "store" -> store,
    "channel" -> channel,
    "timegrain" -> timegrain
  )

  /**
    * Compose the name of particular Features table to be read
    *
    * @param databaseName        name of the Features database
    * @param tableAttributes     map of attributes and their values required
    *                            to compose a Features table name
    * @return name of the Features table to be read
    */
  def composeTableName(databaseName: String,
                       tableAttributes: Map[String, String],
                       timegrain: String,
                       tableNameAttributes: Seq[String] = Seq("product", "customer",
                         "store", "channel", "timegrain")): String = {
    if (timegrain.isEmpty) {
      databaseName |+| "." |+| (tableNameAttributes map (tableAttributes(_)) reduce (_ |+| "_" |+| _))
    } else {
      val attributes = Seq("product", "customer", "store", "channel")
      databaseName |+| "." |+| (attributes map (tableAttributes(_)) reduce (_ |+| "_" |+| _)) |+|
        s"_$timegrain"
    }
  }


  /**
    * This method replace null values for the specified columns with the respective replacement value for null given by
    * replaceValues.
    *
    * @param dataFrame     : any spark dataframe
    * @param colNames      : List of column names for which null is to be replaced with some default value for that column
    * @param replaceValues : List of default value respective to column name present in "colNames"
    * @return
    */
  @tailrec
  final def replaceMultipleColumnsNull(dataFrame: DataFrame, colNames: List[String], replaceValues: List[Boolean])
  : DataFrame = (colNames, replaceValues) match {
    case (colNameHead :: colNameTail, replaceValue :: replaceValueTail) =>
      replaceMultipleColumnsNull(dataFrame.na.fill(Map(colNameHead -> replaceValue)), colNameTail, replaceValueTail)
    case (Nil, Nil) => dataFrame
  }

  /**
    * Read the dimensions that have been persisted.
    *
    * @param dimensionPathOrDb HDFS path internal to the application
    * @param dimName      name of the persisted dimension to be read
    * @return DataFrame of the persisted dimension
    */
  def readPersistedDim(dimensionPathOrDb: String, dimName: String): DataFrame = {
    val entityBasePathOrTableName = if(dimensionPathOrDb.contains("/")) {
      combinePaths(dimensionPathOrDb, s"dim_${dimName toLowerCase}")
    } else {
      val databaseName = dimensionPathOrDb
      s"$databaseName.${dimName.toLowerCase}"
    }
    readInput(entityBasePathOrTableName)
  }

  /**
    * Along the similar lines as `readInput` method defined above, we also need to
    * abstract away what we write to.
    *
    * @param path name of the Hive table or regular HDFS path in case of parquet
    * @param ds   Dataset to be written
    */
  def writeOuput(path: String, ds: Dataset[_]): Unit =
    if (path contains ".") writeToTable(path, ds) else writeToParquet(path, ds)

  /**
    * Write the given dataset to parquet
    *
    * @param savePath HDFS path where the parquet needs to be saved down
    * @param ds       dataset to be written down
    */
  private def writeToParquet(savePath: String, ds: Dataset[_]) = {
    println("in write to parquet => ")
    ds.printSchema()
    ds.write.mode("overwrite").parquet(savePath)
  }

  /**
    * Write a given dataset to Hive
    *
    * @param tableName full qualified name of the table
    * @param ds        Dataset to be saved as table
    */
  private def writeToTable(tableName: String, ds: Dataset[_]) = ds.write.mode("overwrite").saveAsTable(tableName)

  def checkIfTableExists(databaseName: String, tableName: String): Boolean =
    sparkSession.catalog.tableExists(s"$databaseName.$tableName")


  /** Convert Type Safe Config to JSON String
    *
    * @param config Type Safe Config which is to be converted to Config
    * @param formatted String to be formatted or not
    * @return JSON String converted from Type Safe Config
    */
  def convertConfigToJSONString(config: Config,
                                formatted: Boolean = false): String = {
    config
      .root()
      .render(
        ConfigRenderOptions.concise().setFormatted(formatted).setJson(true))
  }

  /**
    * This method merges two maps safely in that it first looks up in the left map
    * for the existence of each element of the right map. If the key is found, it's
    * skipped else it's merged with the left map.
    *
    * @param mapL Left map
    * @param mapR Right map
    * @tparam A Type of keys for each of the maps
    * @return safely merged map
    */

  final def mergeMapsLeftBiased[A <: Any](mapL: Map[String, Any], mapR: Map[String, Any]): Map[String, Any] = {
    val localSeq = mapR toList
    val resultMap = if (mapL contains localSeq.head._1) mapL else mapL ++ Map(localSeq.head)
    if (localSeq.tail isEmpty) resultMap else mergeMapsLeftBiased(resultMap, localSeq.tail.toMap)
  }

}

object Helpers {
  def apply(sparkSession: SparkSession): Helpers
  = new Helpers(sparkSession)
}
