package com.dunnhumby.esdataloader.utils

import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{DataFrame, SparkSession}

import scalaj.http.{Http, HttpOptions, HttpResponse}


/*
    HELPER methods to facilitate few anciliaary tasks.
 */

// scalastyle:off
object Utilities {

  def getType(level: String): String = {
    level.toLowerCase
  }

  def getDescriptionColumn(level: String): String = {
    level + "Description"
  }

  def getIndexName(level: String, cadenceWeek: String): String = {
    getIndexName(level) + s"_${cadenceWeek}"
  }

  def getIndexName(level: String): String = {
    val name = level.last match {
      case 'f' => level.stripSuffix("f").toLowerCase + "ves"
      case _ => level.toLowerCase + "s"
    }
    s"hierarchy_$name"
  }

  def formatIndexName(indexName: String, clientPostfix: String, isMultiTenant: Boolean): String = {
    if (isMultiTenant)
      s"${indexName}@${clientPostfix}"
    else
      indexName
  }

  def normalizeColumns(cols: Seq[String]) : Seq[String] = {
    cols.map(c => String.format("%s AS %s",c,c.toLowerCase))
  }

  def readInput(path: String, spark: SparkSession): DataFrame = if (path contains ".") spark.read.table(path) else spark.read.parquet(path)

  def postUploadOperations(esURL: String, indexName: String, alias:String = "customers",
                           removePattern:String = "customers_*") = {
    val refreshIndex = refreshIndices(esURL, indexName)
    val switchAliasResult = switchAlias(esURL, indexName, alias, removePattern)
    val ilmResult = changeOldIndexILMPolicy(esURL, indexName)
    val settingUpdateResult = updateCustomerSetting(esURL, indexName)
    val result = ilmResult :+ settingUpdateResult :+ switchAliasResult :+ refreshIndex
    if (result.contains(false)) {
      throw new Exception("Post Upload Operation failed")
    }
    else
      println("Switch Alias operation is successful")

  }

  def refreshIndices(esURL: String, index: String): Boolean = {
    val result = Http(s"$esURL/$index/_refresh")
      .timeout(10000, 1200000)
      .header("content-type", "application/json")
      .header("Charset", "UTF-8")
      .option(HttpOptions.method("POST")).asString

    result.isNotError
  }

  private def switchAlias(esURL: String, indexName: String, alias: String, removePattern:String): Boolean = {
    val json =
      s"""
         |{"actions":[
         |{"remove":{"index":"$removePattern","alias":"$alias"}},
         |{"add":{"index":"$indexName","alias":"$alias"}}
         |]
         |}""".stripMargin

    println("executing Switch aliases command : " + json.toString)
    val aliasRequest = s"$esURL/_aliases"
    val result = Http(aliasRequest).postData(json)
      .header("content-type", "application/json")
      .header("Charset", "UTF-8")
      .timeout(10000, 1200000)
      .option(HttpOptions.method("POST")).asString
    println("Output of switch alias : \n" + result.body)
    val resultConfig = ConfigFactory.parseString(result.body)
    if(resultConfig.hasPath("acknowledged")) {
      resultConfig.getBoolean("acknowledged")
    } else {
      false
    }
  }

  private def updateCustomerSetting(esURL: String, indexName: String): Boolean = {
    val customerSettings =
      """{
        |"index": {
        |"refresh_interval":"30m",
        |"lifecycle.name": "customers"
        |}
        |}""".stripMargin
    val result = Http(s"$esURL/$indexName/_settings?pretty").put(customerSettings)
      .header("content-type", "application/json")
      .header("Charset", "UTF-8")
      .timeout(10000, 1200000)
      .option(HttpOptions.method("PUT")).asString

    val resultConfig = ConfigFactory.parseString(result.body)
    if(resultConfig.hasPath("acknowledged")) {
      resultConfig.getBoolean("acknowledged")
    } else {
      false
    }
  }

  private def getOldIndices(esURL: String, indexName: String): Array[String] = {

    val listIndex = s"$esURL/_cat/indices"
    val indexPrefix = indexName.substring(0, indexName.indexOf("_"))
    val listIndexresult = Http(listIndex).method("GET").asString
    listIndexresult.body.split("\n").filter(line => line.contains(indexPrefix))
      .map { filteredRows =>
        val indexMetadata = filteredRows.split(" ").map(x => x.trim)
        indexMetadata(2)
      }.diff(Array(indexName)).sorted
  }

  private def changeOldIndexILMPolicy(esURL: String, indexName: String): List[Boolean] = {
    val targetIndexes = getOldIndices(esURL, indexName)
    targetIndexes.length match {
      case 0 => println("\n No old index to change ilm policy")
        List(true)
      case value: Int => {
        val ilmPolicyOldIndex = """{
                                  |  "current_step": {
                                  |    "phase": "warm",
                                  |    "action": "complete",
                                  |    "name": "complete"
                                  |  },
                                  |  "next_step": {
                                  |    "phase": "cold",
                                  |    "action": "allocate",
                                  |    "name": "allocate"
                                  |  }
                                  |}
                                  |""".stripMargin

        val oldIndex = targetIndexes.last
        val ilmResult = Http(s"$esURL/_ilm/move/$oldIndex").postData(ilmPolicyOldIndex)
          .header("content-type", "application/json")
          .header("Charset", "UTF-8")
          .timeout(10000, 1200000)
          .option(HttpOptions.method("POST")).asString
        if (ilmResult.isError) {
          throw new IllegalArgumentException(s"${getClass.getSimpleName} - ILM policy could not" +
            s" be implemented on old customers index - ${ilmResult.body}")
        }
        println("\n ilm policy of old index changed successfully")
        List(true)
      }
    }
  }


  def deleteOldIndex(esURL: String, indexName: String): List[Boolean] = {
    val targetIndexes = getOldIndices(esURL, indexName)

    targetIndexes.length match {
      case 0 | 1 => println("\n\nNo deletion of indexes is required")
                List(true)
      case value: Int => {
          println("\n\n Indexes to be deleted : " + targetIndexes.init)
          val result = targetIndexes.init.map { indName =>
            println("Requesting to delete index : " + indName)
            Http(s"$esURL/$indName")
              .header("content-type", "application/json")
              .header("Charset", "UTF-8")
              .timeout(10000, 1200000)
              .option(HttpOptions.method("DELETE")).asString
          }
          result.map { response =>
            val resultConfig = ConfigFactory.parseString(response.body)
            if(resultConfig.hasPath("acknowledged")) {
              resultConfig.getBoolean("acknowledged")
            } else {
              false
            }
          }.toList
      }
    }
  }

}
