package com.dunnhumby.esdataloader.generators

import com.dunnhumby.core.unittest.dataframe.DataFrameUtility
import com.dunnhumby.core.unittest.sampledataframe.SampleDataFrame
import com.dunnhumby.core.unittest.sharedcontext.SharedSparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{ArrayType, StringType, StructField, StructType}
import org.scalatest.FunSuite
import org.elasticsearch.spark.sql._


/**
  * Created by miland on 03-10-2018.
  */
class GeneratorTest extends FunSuite with SharedSparkSession {

  test("Test hierarchy data creation: lowest hierarchy needed case") {
    val hierarchy: Map[String, (Int,Boolean)] = Map(
      "division" -> (1, false),
      "department" -> (2, false),
      "section" -> (3, false),
      "group" -> (4, true),
      "subgroup" -> (5, false)
    )
    val keys = List("division", "department", "section", "group", "subgroup")

    val expectedOutput = List(
      ("division",6,false,"hierarchy_divisions"),
      ("department",5,false,"hierarchy_departments"),
      ("section",4,false,"hierarchy_sections"),
      ("group",3,true,"hierarchy_groups"),
      ("subgroup",2,false,"hierarchy_subgroups"),
      ("Product",1,true,"products"))

    assert(Generator.generateHierarchyIndexData(hierarchy, keys) == expectedOutput)
  }

  test("Test hierarchy data creation: lowest hierarchy not needed case") {
    val hierarchy: Map[String, (Int,Boolean)] = Map(
      "division" -> (1, false),
      "department" -> (2, false),
      "section" -> (3, false),
      "group" -> (4, true),
      "subgroup" -> (5, false)
    )
    val keys = List("division", "department", "section", "group", "subgroup")

    val expectedOutput = List(
      ("division",6,false,"hierarchy_divisions"),
      ("department",5,false,"hierarchy_departments"),
      ("section",4,false,"hierarchy_sections"),
      ("group",3,true,"hierarchy_groups"),
      ("subgroup",2,false,"hierarchy_subgroups"),
      ("Product",1,true,"products"))

    assert(Generator.generateHierarchyIndexData(hierarchy, keys) == expectedOutput)
  }

  test("ElasticSearch Basic read write test") {

    // removing System proxies as it will not allow to hit our localhost.

    System.clearProperty("https.proxyHost")
    System.clearProperty("http.proxyPort")
    System.clearProperty("http.proxyHost")
    System.clearProperty("https.proxyPort")

    val esConf = Map(
      "es.nodes" -> "localhost",
      "es.port" -> "9200",
      "es.nodes.wan.only" -> "true")

    val expectedDF = SampleDataFrame.returnSampleDFType1(sqlContext)
    expectedDF.saveToEs("test/testing", esConf)

    val readDF = sqlContext.read.format("org.elasticsearch.spark.sql")
      .options(esConf).load("test" + "/" + "testing")

    DataFrameUtility.assertDataFrame(expectedDF, readDF)
  }

  test("Generator - generateHierarchy: generating hierarchy indices") {

    val level1 = "group"
    val level2 = "subgroup"
    val productsDF = sparkSession.read.option("header","true").csv("src/test/resources/data/products.csv")
    val actualDF = Generator.generateHierarchy(productsDF,level1,level2)

    val expectedData = Seq(
      Row("g1","default", Seq(Row("sub1","default",Seq("b1","b2")), Row("sub2","default",Seq("b1"))), Seq("b1","b2")),
      Row("g2","default",Seq(Row("sub3","default",Seq("b2")), Row("sub4","default",Seq("b1"))), Seq("b1","b2"))
    )

    val expectedSchema = StructType(
      List(
        StructField("C",StringType),
        StructField("D",StringType),
        StructField("child_array",ArrayType(
          StructType(
            List(
              StructField("C",StringType),
              StructField("D",StringType),
              StructField("B",ArrayType(StringType))
            )
          )
        )),
        StructField("B",ArrayType(StringType))
      )
    )

    val expectedRDD = sc.parallelize(expectedData)
    val expectedDF = sparkSession.createDataFrame(expectedRDD,expectedSchema)
    assert(actualDF.count() === expectedDF.count())
  }

  test("Generator - generateBottomHierarchy: generating bottom hierarchy") {
    val hierarchyName = "subgroup"
    val productsDF = sparkSession.read.option("header","true").csv("src/test/resources/data/products.csv")
    val actualDF = Generator.generateBottomHierarchy(productsDF,hierarchyName)

    val arrayStructureData = Seq(
      Row("sub1","default",Seq("b1","b2")),
      Row("sub2","default",Seq("b1")),
      Row("sub3","default",Seq("b2")),
      Row("sub4","default",Seq("b1"))
    )

    val arrayStructureSchema = StructType(
      List(
        StructField("C", StringType),
        StructField("D", StringType),
        StructField("B", ArrayType(StringType))
      )
    )
    val expectedRdd = sc.parallelize(arrayStructureData)
    val expectedDF = sparkSession.createDataFrame(expectedRdd, arrayStructureSchema)
    DataFrameUtility.assertDataFrame(actualDF, expectedDF)
  }

  test("Generator- generatePACIndex: generating PAC index") {

    val clusterNumCol = "affinityclusternum"
    val l10 = "subgroup"
    val productsDF = sparkSession.read.option("header","true").csv("src/test/resources/data/products.csv")
    val sampleData = Seq(
      Row("c1", "sub1"),
      Row("c1", "sub2"),
      Row("c2", "sub3")
    )
    val sampleSchema = StructType(
      List(
        StructField("affinityclusternum",StringType),
        StructField("subgroup", StringType)
      )
    )
    val sampleRdd = sc.parallelize(sampleData)
    val pacDF = sparkSession.createDataFrame(sampleRdd, sampleSchema)
    val actualDF = Generator.generatePACIndex(productsDF,l10,pacDF,clusterNumCol)

    val expectedData = Seq(
      Row("c1",Seq("sub1", "sub2")),
      Row("c2",Seq("sub3"))
    )

    val expectedSchema = StructType(
      List(
        StructField("PAC",StringType),
        StructField("L10s",ArrayType(StringType))
      )
    )
    val expectedRdd = sc.parallelize(expectedData)
    val expectedDF = sparkSession.createDataFrame(expectedRdd, expectedSchema)
    DataFrameUtility.assertDataFrame(actualDF, expectedDF)
  }
}
