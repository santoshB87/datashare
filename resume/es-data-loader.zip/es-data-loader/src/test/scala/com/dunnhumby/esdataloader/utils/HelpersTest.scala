package com.dunnhumby.esdataloader.utils

import com.dunnhumby.core.unittest.sharedcontext.SharedSparkSession
import com.dunnhumby.core.unittest.FileOperations
import com.dunnhumby.core.unittest.dataframe.DataFrameUtility
import com.typesafe.config.ConfigFactory
import org.mockito.Mockito.when
import org.scalatest.FunSuite
import org.scalatest.mockito.MockitoSugar

import scala.collection.mutable.ArrayBuffer

/**
  * Created By shriyam on 03/06/2020.
  */
class HelpersTest extends FunSuite with SharedSparkSession with MockitoSugar {

  override def beforeAll(): Unit = {
    super.beforeAll()
  }
  
  val helpers: Helpers = Helpers(sparkSession)
  val helpersMock: Helpers = mock[Helpers]

  test("Helpers - cliArgsToMap: Can I get all the CLI arguments in a map") {
    val args = Array("job=create","client=ce_dev")
    val argMap = Map(
      "job" -> "create",
      "client" -> "ce_dev")
    assert(helpers.cliArgsToMap(args) == argMap)
  }

  test("Helpers - renameMultipleColumns: Can I rename old column names with new names") {
    val oldNames = List("product","customer","baskets_1w1w","netspend_1w1w","quantity_1w1w")
    val newNames = List("product","customer","b_1","n_1","q_1")
    val sampleDF = sparkSession.read.option("header","true").csv("src/test/resources/data/sampleDf.csv")
    val actualDF = helpers.renameMultipleColumns(sampleDF,oldNames,newNames)
    val actualCols = actualDF.columns.toList
    assert(actualCols === newNames)
  }

  test("Helpers - renameMultipleColumns: When both oldNames and newNames lists are empty") {
    val oldNames = List.empty
    val newNames = List.empty
    val sampleDF = sparkSession.read.option("header","true").csv("src/test/resources/data/sampleDf.csv")
    val actualDF = helpers.renameMultipleColumns(sampleDF,oldNames,newNames)
    val actualCols = actualDF.columns.toList
    assert(actualCols === sampleDF.columns.toList)
  }

  test("Helpers - castSparkDFTypestoES: Can I convert decimal to float type") {
    val df = sparkSession.read.option("header", "true").csv("src/test/resources/data/sampleDf.csv")
    assert(helpers.castSparkDFTypestoES(df).schema.toString()
      .contains("StructField(netspend_1w1w,FloatType,true), StructField(quantity_1w1w,FloatType,true)"))
  }

  test("Helpers - composeTableName: Can I correctly compose Features-tables names") {
    val dbNm = "db"
    val attrMap = Map("product" -> "p", "customer" -> "c", "store" -> "s", "channel" -> "ch")
    val attrSeq = Seq("product", "customer", "store", "channel")
    assert(helpers.composeTableName(dbNm, attrMap, "", attrSeq) === "db.p_c_s_ch")
  }

  test("Helpers - composeTableName: Can I correctly compose Features-tables names with time grains") {
    val dbNm = "db"
    val attrMap = Map("product" -> "p", "customer" -> "c", "store" -> "s", "channel" -> "ch")
    val attrSeq = Seq("product", "customer", "store", "channel")
    assert(helpers.composeTableName(dbNm, attrMap, "1w1w", attrSeq) === "db.p_c_s_ch_1w1w")
  }

  test("Helpers - composeAttributesMap: Can I correctly compose Features-table attributes map?") {
    assert(helpers.composeAttributesMap("p", "c", "s", "ch") ===
      Map("channel" -> "ch", "store" -> "s", "customer" -> "c", "timegrain" -> "1w52w", "product" -> "p"))
  }

  test("Helpers - getProdHierarchies: Can I get hierarchies of products correctly?") {
    val hierList = Seq("l1", "l2", "l3", "l4")
    assert(helpers.getProdHierarchies(hierList, "l2") === Seq("l2", "l3", "l4"))
  }

  test("Helpers - getSelectableDimsNames: Can I get the selected dimensions from the table") {
    val prodHierarchyList = Seq("product", "subgroup")
    val dimensionNames = helpers.getSelectableDimsNames(prodHierarchyList, "subgroup","customer")
    val expectedSeq = ArrayBuffer("customer","subgroup")
    assert(dimensionNames == expectedSeq)
  }

  test("Helpers - getSelectableDimsNames: Can I get the selected dimensions from the table with brand") {
    val prodHierarchyList = Seq("product", "subgroup")
    val dimensionNames = helpers.getSelectableDimsNames(prodHierarchyList, "subgroup","customer", "all", "all", true)
    val expectedSeq = ArrayBuffer("customer","subgroup", "productbrand")
    assert(dimensionNames == expectedSeq)
  }

  test("Helpers - mergeMapsLeftBiased: Can I merge two maps safely?") {
    val mapL = Map("a" -> 1, "b" -> 2)
    val mapR1 = Map("b" -> 3, "c" -> 3)
    val op = Map("a" -> 1, "b" -> 2, "c" -> 3)
    val mapR2 = Map("a" -> 2, "b" -> 3)

    assert(helpers.mergeMapsLeftBiased(mapL, mapR1) === op)
    assert(helpers.mergeMapsLeftBiased(mapL, mapR2) === mapL)
  }

  test("Helpers - combinePaths: Can I compose the paths preserving FS designator if any") {
    val (base1, base2) = ("base/path", "fs://base/path")
    val tail = "tail"
    val (op1, op2) = ("base/path/tail", "fs://base/path/tail")

    assert(helpers.combinePaths(base1, tail) === op1)
    assert(helpers.combinePaths(base2, tail) === op2)
  }

  test("Helpers - convertConfigToJSONString: converting config string to a Json") {
    val configString =
      s"""
         |{
         |  "type": "table.hive"
         |  "option": {
         |     "path": "db.p_c_s_ch_1w1w",
         |     "mode": "overwrite"
         |  }
         |}
         |""".stripMargin
    val config = ConfigFactory.parseString(configString)
    val jsonString =
      s"""{"option":{"mode":"overwrite","path":"db.p_c_s_ch_1w1w"},"type":"table.hive"}""".stripMargin
    assert(helpers.convertConfigToJSONString(config) === jsonString)
  }

  test("Helpers - writeOutput: writing parquet files") {
    val sampleDf = sparkSession.read.option("header","true").csv("src/test/resources/data/sampleDf.csv")
    helpers.writeOuput("src/test/resources/temp/parquet", sampleDf)
    val expectedDf = sparkSession.read.parquet("src/test/resources/temp/parquet")
    DataFrameUtility.assertDataFrame(sampleDf, expectedDf)
  }

  test("Helpers - ReadInput: reading parquet files") {
    val sampleDf = sparkSession.read.option("header","true").csv("src/test/resources/data/sampleDf.csv")
    helpers.writeOuput("src/test/resources/temp/parquet/feature", sampleDf)
    val readParDf = sparkSession.read.load("src/test/resources/temp/parquet/feature")
    DataFrameUtility.assertDataFrame(readParDf,sampleDf)
  }

  test("Helpers- checkIfTableExists: Can I check the existence of Table in a Database") {
    val databaseName = "ce_dev_media_mart"
    val tableName = "transaction"
    val checkTableInstance = helpersMock.checkIfTableExists(databaseName,tableName)
    when(checkTableInstance === "ce_dev_media_mart.transaction") thenReturn(true)
  }

  override def afterAll(): Unit = {
    val parquetDeleteFolderPath = "src/test/resources/temp/parquet"
    FileOperations.removeParentFolder(parquetDeleteFolderPath)
    super.afterAll()
  }
}
