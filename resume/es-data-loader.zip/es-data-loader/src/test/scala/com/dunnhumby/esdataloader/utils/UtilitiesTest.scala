package com.dunnhumby.esdataloader.utils

import com.dunnhumby.core.unittest.FileOperations
import com.dunnhumby.core.unittest.dataframe.DataFrameUtility
import com.dunnhumby.core.unittest.sharedcontext.SharedSparkSession
import org.elasticsearch.spark.sql.sparkDatasetFunctions
import org.scalatest.{FunSuite, PrivateMethodTester}
import scalaj.http.{Http, HttpOptions}

class UtilitiesTest extends FunSuite with PrivateMethodTester with SharedSparkSession {

  override def beforeAll(): Unit = {
    super.beforeAll()
    val esConf = Map(
      "es.nodes" -> "localhost",
      "es.port" -> "9200",
      "es.nodes.wan.only" -> "true")
    val sampleDf1 = sparkSession.read.option("header", "true").csv("src/test/resources/data/sampleDf.csv")
    val sampleDf2 = sparkSession.read.option("header", "true").csv("src/test/resources/data/sampleDf.csv")
    val sampleDf3 = sparkSession.read.option("header", "true").csv("src/test/resources/data/sampleDf.csv")
    sampleDf1.saveToEs("customers_1/doc_1", esConf)
    sampleDf2.saveToEs("customers_2/doc_1", esConf)
    sampleDf3.saveToEs("customers_3/doc_1", esConf)
  }

  test("Utilities - getType: Can I get type of Level in hierarchies") {
    val level = "group"
    assert(Utilities.getType(level) === "group")
  }

  test("Utilities - getDescriptionColumn: Can I get Description column of given Level") {
    val level = "group"
    val desColumn = Utilities.getDescriptionColumn(level)
    assert(desColumn === "groupDescription")
  }

  test("Utilities - getIndexName: Can I get the Index name of given level and cadence week") {
    val level = "Group"
    val cadenceWeek = "201912"
    assert(Utilities.getIndexName(level, cadenceWeek) === "hierarchy_groups_201912")
  }

  test("Utilities - getIndexName: Can I get the Index name of given level") {
    val level = "Group"
    assert(Utilities.getIndexName(level) === "hierarchy_groups")
  }

  test("Utilities - formatIndexName: Can I format the Index name when the client is MultiTenet") {
    val indexName = "customers"
    val clientPostfix = "uk"
    val isMultiTenant = true
    assert(Utilities.formatIndexName(indexName, clientPostfix, isMultiTenant) === "customers@uk")
  }

  test("Utilities - formatIndexName: Can I format the Index name when the client is not MultiTenet") {
    val indexName = "customers"
    val clientPostfix = "uk"
    val isMultiTenet = false
    assert(Utilities.formatIndexName(indexName, clientPostfix, isMultiTenet) === "customers")
  }

  test("Utilities - normalizeColumns: Formatting column names to lowercase") {
    val cols = Seq("customerName", "age", "preferredFood")
    val formattedCols = Seq("customerName AS customername", "age AS age", "preferredFood AS preferredfood")
    assert(Utilities.normalizeColumns(cols) === formattedCols)
  }

  test("Utilities- readInput: reading parquet files") {
    val sampleDf = sparkSession.read.option("header","true").csv("src/test/resources/data/sampleDf.csv")
    sampleDf.write.mode("overwrite").parquet("src/test/resources/temp/parquet/feature")
    val actualDf = Utilities.readInput("src/test/resources/temp/parquet/feature", sparkSession)
    DataFrameUtility.assertDataFrame(actualDf,sampleDf)
  }

  test("Utilities - getOldIndices: Can I get old index") {
    val esURL = "http://localhost:9200"
    val indexName = "customers_3"
    val getOldIndices = PrivateMethod[Array[String]]('getOldIndices)
    val response = Utilities invokePrivate getOldIndices(esURL,indexName)
    val actualList = response.toList
    val expectedList = List("customers_1", "customers_2")
    assert(actualList === expectedList)
  }

  test("Utilities - deleteOldIndex: Deleting old indices") {
    val esURL = "http://localhost:9200"
    val indexName = "customers_3"
    val response = Utilities.deleteOldIndex(esURL,indexName)
    assert(response === List(true))
  }

  test("Utilities - refreshIndices: Can I refresh an index which does not exist") {
    val esURL = "http://localhost:9200"
    val indexName = "products_4"
    val response = Utilities.refreshIndices(esURL, indexName)
    val expectedResponse = false
    assert(response === expectedResponse)
  }

  test("Utilities - refreshIndices: Can I refresh an index") {
    val esURL = "http://localhost:9200"
    val indexName = "customers_2"
    val response = Utilities.refreshIndices(esURL, indexName)
    val expectedResponse = true
    assert(response === expectedResponse)
  }

  test("Utilities - switchAlias: Can I switch index name by an alias") {
    val esURL = "http://localhost:9200"
    val indexName = "customers_2"
    val removePattern = "customers_*"
    val alias = "customers"
    val esConf = Map(
      "es.nodes" -> "localhost",
      "es.port" -> "9200",
      "es.nodes.wan.only" -> "true")

    val switchAlias = PrivateMethod[Boolean]('switchAlias)
    Utilities invokePrivate switchAlias(esURL,indexName,alias,removePattern)

    val actualDF = sqlContext.read.format("org.elasticsearch.spark.sql")
      .options(esConf).load("customers_3" + "/" + "doc_1")
    val aliasDF = sqlContext.read.format("org.elasticsearch.spark.sql")
      .options(esConf).load("customers")
    DataFrameUtility.assertDataFrame(actualDF,aliasDF)
  }

  test("Utilities - switchAlias: Can I switch index name by an alias when index does not exist") {
    val esURL = "http://localhost:9200"
    val indexName = "customers_1999"
    val removePattern = "customers_*"
    val alias = "customers"
    val switchAlias = PrivateMethod[Boolean]('switchAlias)
    val response = Utilities invokePrivate switchAlias(esURL,indexName,alias,removePattern)
    assert(response === false)
  }

  test("Utilities- updateCustomerSetting: Can I update setting of an index") {
    val esURL = "http://localhost:9200"
    val indexName = "customers_2"
    val updateCustomerSetting = PrivateMethod[Boolean]('updateCustomerSetting)
    val response = Utilities invokePrivate updateCustomerSetting(esURL,indexName)
    assert(response === true)
  }

  test("Utilities- updateCustomerSetting: Can I update index setting when index does not exist") {
    val esURL = "http://localhost:9200"
    val indexName = "sales_2035"
    val updateCustomerSetting = PrivateMethod[Boolean]('updateCustomerSetting)
    val response = Utilities invokePrivate updateCustomerSetting(esURL,indexName)
    assert(response === false)
  }

  test("Utilities- changeOldIndexILMPolicy: ILM policy implementation where no index available") {
    val esURL = "http://localhost:9200"
    val indexName = "products_2"
    val changeOldIndexILMPolicy = PrivateMethod[List[Boolean]]('changeOldIndexILMPolicy)
    val actualOutput = Utilities invokePrivate changeOldIndexILMPolicy(esURL,indexName)
    val expectedOutput = List(true)
    assert(actualOutput === expectedOutput)
  }

  override def afterAll(): Unit = {
    val parquetDeleteFolderPath = "src/test/resources/temp/parquet/features"
    FileOperations.removeParentFolder(parquetDeleteFolderPath)
    val esURL = "http://localhost:9200"
    val indexNameList = List("customer_2", "customer_3")
    indexNameList.map { index =>
      Http(s"$esURL/$index")
        .header("content-type", "application/json")
        .header("Charset", "UTF-8")
        .timeout(10000, 1200000)
        .option(HttpOptions.method("DELETE")).asString
    }
    super.afterAll()
  }
}
