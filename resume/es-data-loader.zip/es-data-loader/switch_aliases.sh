esNode=$1
cadenceWeek=$2
adminPassword=$3
clientName=$4
isMultiTenant=$5


if [ "$isMultiTenant" = true ]
then
    currentIndex=`printf "%s_customers_%s" $clientName $cadenceWeek`
    aliasName=`printf "%s_customers" $clientName`
    searchPattern=`printf "%s_customers_[0-9]+" $clientName`
    removePattern=`printf "%s_customers_*" $clientName`
else
    currentIndex=`printf "customers_%s" $cadenceWeek`
    aliasName="customers"
    searchPattern="customers_[0-9]+"
    removePattern="customers_*"
fi
esUrl=`printf "%s:9200" $esNode`



# Switching alias to latest week's data.
json=`printf '{"actions":[{"remove":{"index":"%s","alias":"%s"}},{"add":{"index":"%s","alias":"%s"}}]}' $removePattern $aliasName $currentIndex $aliasName`
echo $json

curl -X POST -u admin:$adminPassword -H "Content-Type:application/json" "$esUrl/_aliases" -d "$json"

# Set the correct value for replication and refresh interval. 
# These two values are disabled by default for customer index (see init_es.sh for reference.) to enhance the bulk load performance.
# Currently replication is turned off because of space issues.

settingsUpdateUrl="$esUrl/$currentIndex/_settings?pretty" 
echo $currentIndex
curl -X PUT -u admin:$adminPassword $settingsUpdateUrl -H "Content-Type:application/json" -d '{"index":{"refresh_interval":"1s","number_of_replicas":"0"}}'


#Delete the old indexes
allIndexes=`curl -X GET -u admin:$adminPassword $esUrl/_cat/indices`
indexToDelete=`echo $allIndexes | egrep -o "$searchPattern" | grep -v $currentIndex`

echo $allIndexes
echo 'Deleting old customer index'
echo $indexToDelete

indexDeleteUrl="$esUrl/$indexToDelete"
echo $indexDeleteUrl

curl -X DELETE -u admin:$adminPassword -H "Content-Type:application/json" $indexDeleteUrl